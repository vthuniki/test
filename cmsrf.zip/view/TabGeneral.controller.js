jQuery.sap.require("sap.ui.cms.util.Service");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ui.cms.util.Controller");
jQuery.sap.require("sap.ui.cms.util.LanguageBundle");
jQuery.sap.require("sap.ui.cms.util.formatters.CRFCustomFormatter");
jQuery.sap.require("sap.ui.cms.util.NCButtonsHandlers");
util.Controller.extend(
	"sap.ui.cms.view.TabGeneral", {

		onInit: function () {

			this.bus = this.getEventBus();
			this.bus.subscribe("service", "changeSalesOrg",
				this.onChangeSalesOrg, this);
			this.bus.subscribe("service", "changeRequestUser",
				this.onChangeRequestUser, this);
				
			this.getControlReferences();
		},
		changeRequestProcType: function (oEvt) {
			//change the searchHelp data on the processor id control depending on the selected item 
			this.getView().byId("PROCESSOR_ID").data("shName", oEvt.getSource().getSelectedItem().data("sH"));
		},
		changeRequestStatus: function (oEvt) {
			var test;
		},
		
		onChangeRequestUser: function (channelId, eventId, data) {
			jQuery.sap.log.info(this.tag + ": onChangeRequestUser");
			var newValue = data.data;
			this.changeUser(null, newValue);
		},
		onChangeSalesOrg: function (channelId, eventId, data) {
			jQuery.sap.log.info(this.tag + ": onChangeSalesOrg");
			var newValue = data.data;
			this.changeSalesOrg(newValue);
		},

		changeSalesOrg: function (value) {
			this.oldSalesOrgValue = value;
			this.salesOrgInput.setValueState("None");
			
			//make request with the model
			if (mainModel) {
				var sRead = "/SRCHHELP_VKORG_SET('" + value + "')";
				sap.ui.core.BusyIndicator.show();
				mainModel.read(sRead, null, null, true,
					this.salesOrgInfoSuccess.bind(this),
					this.salesOrgInfoError.bind(this));

			}
		},
		handleChangeOfSalesOrg: function (oEvt) {
			this.salesOrgValue = oEvt.getSource().getValue();

			if (this.requestType.getSelectedItem()) {
				requestFormType = this.requestType
					.getSelectedItem().getKey();
			}

			if (requestFormType && this.oldSalesOrgValue && (this.salesOrgValue != this.oldSalesOrgValue)) {
				sap.m.MessageBox
					.show(
						"Do you really want to change the sales organization and reset the details area?", {
							icon: sap.m.MessageBox.Icon.QUESTION,
							title: "Are you sure?",
							actions: [
								sap.m.MessageBox.Action.YES,
								sap.m.MessageBox.Action.NO
							],
							onClose: this.handleSalesOrgDecision
								.bind(this)
						});
			} else {
				if (!this.oldSalesOrgValue || this.oldSalesOrgValue.length <= 0) {
					this.changeSalesOrg(this.salesOrgValue);
				} else {
					if (this.salesOrgValue != this.oldSalesOrgValue) {
						this.changeSalesOrg(this.salesOrgValue);
					}
				}
			}
		},
		handleSalesOrgDecision: function (oAction) {

			var that = this;

			if (oAction === sap.m.MessageBox.Action.YES) {
				sap.ui.cms.util.NCButtonsHandlers.changeSalesOrg.apply(that, [that]);
				this.changeSalesOrg(this.salesOrgValue);
			} else {
				this.salesOrgInput.setValue(this.oldSalesOrgValue);
			}
		},

		salesOrgInfoSuccess: function (oData, response) {

			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			var resultEntry = oData;
			if (resultEntry) {
				this.salesOrgInput.setValueState("None");

				this.salesOrgDescription
					.setValue(resultEntry.SALESORG_DESCR);
				salesOrgID = this.salesOrgInput.getValue();

				if (requestFormType) {
					this.activateTabs();
				}
			} else {
				this.salesOrgInput.setValueState("Error");
			}

		},
		test: function (oEvt) {
			var test = oEvt;
		},

		processorValueHelpTriggered: function (oEvt) {
			//we need to call it here, to get the context in the service class
			var searchHelpName = oEvt.getSource().data(
				"shName");

			util.Service.valueHelpRequestTriggered(oEvt,
				searchHelpName);
		},

		changeRequestType: function (oEvt) {
			debugger;
			var selectedItem = oEvt.getSource().getSelectedItem();
			var itemDesc = selectedItem.data("desc");

			this.desc.setValue(itemDesc);

			if (salesOrgID) {
				sap.m.MessageBox
					.show(
						"Do you really want to change the requestform type and reset the details area?", {
							icon: sap.m.MessageBox.Icon.QUESTION,
							title: "Are you sure?",
							actions: [
								sap.m.MessageBox.Action.YES,
								sap.m.MessageBox.Action.NO
							],
							onClose: this.switchRequestType
								.bind(this)
						});

			} else {
				//only save it when there is no salesOrgID -> it will be saved when the user clicks yes in the popup otherwise
				requestFormType = selectedItem.data("id");
				this.oldTypeValue = requestFormType;
			}
		},
		switchRequestType: function (oAction) {

			if (oAction === sap.m.MessageBox.Action.YES) {
				requestFormType = this.requestType.getSelectedKey();
				this.oldTypeValue = requestFormType;

				//clear the sales org input field, as the value depends on the request form types
				this.salesOrgInput.setValue("");
				salesOrgID = "";
				this.salesOrgDescription.setValue("");
				this.oldSalesOrgValue = "";
				this.salesOrgValue = "";

				this.enableTabs(false);
			} else {
				//set the requestform type to the last saved value because the user don´t wants to reset the detail area
				this.requestType.setSelectedKey(this.oldTypeValue);
			}
		},
		salesOrgListSuccess: function (oData, response) {
			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			var model = new sap.ui.model.json.JSONModel();
			model.setData(oData);
			this.useSalesOrgList(model);

		},
		salesOrgListError: function (oData, response) {
			sap.ui.core.BusyIndicator.hide();

		},
		useSalesOrgList: function (salesOrgListModel) {
			// create value help dialog
			if (!this.salesOrgSearchDialog) {
				this.salesOrgSearchDialog = sap.ui.xmlfragment(
					"sap.ui.cms.view.SalesOrgList", this);
				this.getView().addDependent(
					this.salesOrgSearchDialog);
			}
			this.salesOrgSearchDialog._oDialog
				.setModel(salesOrgListModel)

			// open value help dialog
			this.salesOrgSearchDialog.open();
		},
		handleSalesOrgSelection: function (oController) {
			this.salesOrgInputID = oController.oSource.sId;
			if (this.requestType.getSelectedItem()) {
				requestFormType = this.requestType
					.getSelectedItem().getKey();

				if (mainModel) {
					sap.ui.core.BusyIndicator.show();
					var sRead = "SearchHlpSalesOrg_Set/?$filter=RequestFormType%20eq%20%27" + requestFormType + "%27";
					mainModel.read(sRead, null,
						null, true, this.salesOrgListSuccess
						.bind(this),
						this.salesOrgListError.bind(this));
				}
			}

		},
		_handleSalesOrgSearch: function (oEvent) {

			var query = oEvent.getParameter("value");
			var oFilterByDescription = new sap.ui.model.Filter({
				path: "SalesOrgDescription",
				test: function (entryValue) {

					entryValue = entryValue.toUpperCase();
					var regpattern = "";
					if (query && query !== "") {
						regpattern = "^" + query.toUpperCase().replace(/\*/g, ".+") + "$";
						var re = new RegExp(regpattern);
						var myarray = re.exec(entryValue);
						if (myarray !== null && myarray.length && myarray.length === 1) {
							return true;
						}
						return false;
					}
					return true;

				}
			});

			var oFilterById = new sap.ui.model.Filter("SalesOrgID", sap.ui.model.FilterOperator.Contains, query);
			var oBinding = oEvent.getSource().getBinding("items");
			//	    oBinding.filter([oFilterByDescription]);

			oBinding.filter([new sap.ui.model.Filter([oFilterByDescription, oFilterById], false)]);

		},

		_handleSalesOrgDialogClose: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			this.salesOrgItem = oSelectedItem;
			if (this.requestType.getSelectedItem()) {
				requestFormType = this.requestType
					.getSelectedItem().getKey();
			}
			var productInput = this.getView().byId(
				this.salesOrgInputID);
			oldValue = productInput.getValue();
			if (oSelectedItem) {
				this.salesOrgValue = this.salesOrgItem.getTitle();
				if (requestFormType && oldValue && oldValue != oSelectedItem.getTitle()) {
					//show a confirmation popup if the user wants to change the sales org when it is another than before

					sap.m.MessageBox
						.show(
							"Do you really want to change the sales organization and reset the details area?", {
								icon: sap.m.MessageBox.Icon.QUESTION,
								title: "Are you sure?",
								actions: [
									sap.m.MessageBox.Action.YES,
									sap.m.MessageBox.Action.NO
								],
								onClose: this.salesOrgListSelection
									.bind(this)
							});
				} else {

					if (!oldValue || oldValue.length <= 0) {
						this.selectSalesOrg(oSelectedItem);
					} else {
						if (oldValue != oSelectedItem.getTitle()) {
							this.selectSalesOrg(oSelectedItem);
						}
					}

				}

			}
			evt.getSource().getBinding("items").filter([]);
		},
		salesOrgListSelection: function (oAction) {
			var that = this;
			var productInput = this.getView().byId(
				this.salesOrgInputID);
			if (oAction === sap.m.MessageBox.Action.YES) {
				sap.ui.cms.util.NCButtonsHandlers.changeSalesOrg.apply(that, [that]);
				this.selectSalesOrg(this.salesOrgItem);
			}
		},
		selectSalesOrg: function (item) {
			var productInput = this.getView().byId(
				this.salesOrgInputID);
			this.oldSalesOrgValue = item.getTitle();
			productInput.setValue(item.getTitle());
			salesOrgID = item.getTitle();
			this.salesOrgDescription
				.setValue(item.getDescription());

			if (requestFormType) {
				this.activateTabs();
			}
		},
		salesOrgInfoError: function (oError) {
			sap.ui.core.BusyIndicator.hide();
			this.salesOrgInput.setValueState("Error");
		},
		activateTabs: function () {
			var parentView = this.getView().getParent().getParent()
				.getParent().getParent().getParent();
			parentView.byId("contactFilter").setEnabled(true);
			parentView.byId("attachmentFilter").setEnabled(true);
			parentView.byId("createButton").setEnabled(true);
			// C5204963
			parentView.byId("draftButton").setEnabled(true);
			// C5204963

			if (!objectID) {
				//load CP Area content data
				this.bus.publish("service", "loadCPContent");
				//load detail area content
				this.bus.publish("service", "loadDetailContent");
			}
		},
		enableTabs: function (enable) {
			var parentView = this.getView().getParent().getParent()
				.getParent().getParent().getParent();
			parentView.byId("contactFilter").setEnabled(enable);
			parentView.byId("detailFilter").setEnabled(enable);
			parentView.byId("attachmentFilter").setEnabled(enable);
			parentView.byId("createButton").setEnabled(enable);
			// C5204963
			parentView.byId("draftButton").setEnabled(enable);
			// C5204963

		},

		//<!--changes for Button to accomodate Email c5234631			-->
		//var oMyButton = new sap.ui.commons.Button("userAssign");
		// onAssignMe: function(oEvt) { 
		// 	var oGetData = this.getView().byId("PROCESSOR_ID").getValue();
		// 		mainModel	
		// 		.read(
		// 											"/CRFRequestData_Set('"
		// 													+ oGetData
		// 													+ "')/?$expand=NavToCP,NavToSC,NavToCO,NavToDetail",
		// 											null, null, true );
		// 										//	this.onLoadDisplayDataSuccess
		// 											//		.bind(this),
		// 											//this.onLoadDisplayDataFailure
		// 												//	.bind(this)	);

		// 	var oButton = this.getView().byId("userAssign");
		// 	//alert("Venugopal"); 

		// },

		handleRequestorSelection: function (oEvt) {
			//open the search help for the user selection
			if (!this.userSearchDialog) {
				this.userSearchDialog = sap.ui.xmlfragment(
					"sap.ui.cms.view.UserSearchHelp", this);
				//make the dialog fullscreen when the device is a phone
				this.userSearchDialog
					.setStretch(jQuery.device.is.phone);
				this.getView().addDependent(this.userSearchDialog);
			}
			//						this.userSearchDialog.setModel(salesOrgListModel);

			//get the form out of the dialog to add the key down event on each input
			var form = this.userSearchDialog.getContent()[0];
			util.Service.addEnterEventOnCustomDialog(form);
			// open value help dialog
			this.userSearchDialog.open();
		},
		onCloseUserSearch: function (oEvt) {
			if (this.userSearchDialog) {
				this.userSearchDialog.close();
			}
		},
		onSearchForUser: function (oEvt) {
			var dialog;
			if (!jQuery.device.is.phone) {
				dialog = oEvt.getSource().getParent();
			} else {
				dialog = oEvt.getSource().getParent();
			}
			var content = dialog.getContent()[0];
			var firstNameInput = content.getContent()[1];
			var lastNameInput = content.getContent()[3];
			var userIDInput = content.getContent()[5];

			var firstName = firstNameInput.getValue();
			var lastName = lastNameInput.getValue();
			var UserId = userIDInput.getValue().toUpperCase();

			var filterString = "";

			if (firstName && firstName.length > 0) {
				filterString = filterString + "FirstName%20eq%20%27" + firstName + "%27";
			}

			if (lastName && lastName.length > 0) {
				if (filterString.length > 0) {
					filterString = filterString + "%20and%20";
				}
				filterString = filterString + "LastName%20eq%20%27" + lastName + "%27";
			}

			if (UserId && UserId.length > 0) {
				if (filterString.length > 0) {
					filterString = filterString + "and%20";
				}
				filterString = filterString + "UserId%20eq%20%27" + UserId + "%27";
			}

			if (mainModel) {
				var sRead = "/SRCHHELP_USERSet/?$filter=" + filterString + "&top=100";
				sap.ui.core.BusyIndicator.show();
				mainModel.read(sRead, null, null, true,
					this.getUserListSuccess.bind(this),
					this.getUserListError.bind(this));
			}
		},
		getUserListSuccess: function (oData, response) {
			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			var model = new sap.ui.model.json.JSONModel();
			model.setData(oData.results);

			if (this.userSearchDialog) {
				this.userSearchDialog.setModel(model);
			}
		},
		getUserListError: function (oData, response) {
			sap.ui.core.BusyIndicator.hide();
		},
		userListItemSelected: function (oEvt) {
			var source = oEvt.getSource();
			var fullName = source.getProperty("title");
			var userId = source.getProperty("description");

			this.requestorNameInput.setValue(fullName);
			this.requestorIDInput.setValueState("None");
			this.requestorIDInput.setValue(userId);

			if (this.userSearchDialog) {
				this.userSearchDialog.close();
				this.userSearchDialog.destroy();
				this.userSearchDialog = null;
			}
		},
		changeUser: function (oEvt, userID) {
			var id;
			if (userID) {
				id = userID;
			} else {
				id = oEvt.getSource().getValue();
				if (id) {
					//make the entered string uppercase
					id = id.toUpperCase();
				}
			}
			var validUser = /^[DCIdci]{1}[0-9]+$/.test(id);

			if (validUser) {
				this.requestorIDInput.setValueState("None");
				//make request with the model
				if (mainModel) {
					sap.ui.core.BusyIndicator.show();
					var sRead = "/SRCHHELP_USERSet('" + id + "')";

					mainModel.read(sRead, null, null, true,
						this.userInfoSuccess.bind(this),
						this.userInfoError.bind(this));
				}
			} else {
				this.requestorIDInput.setValueState("Error");
			}
		},
		userInfoSuccess: function (oData, response) {
			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			var resultEntry = oData;
			if (resultEntry) {
				this.requestorIDInput.setValueState("None");
				this.requestorNameInput
					.setValue(resultEntry.FirstName + " " + resultEntry.LastName);

			} else {
				this.requestorIDInput.setValueState("Error");
			}
		},
		openMessageBox: function (title, text) {
			sap.m.MessageBox.show(text, "sap-icon://alert", title, [sap.m.MessageBox.Action.OK]);
		},
		userInfoError: function (oError) {
			sap.ui.core.BusyIndicator.hide();
			this.requestorIDInput.setValueState("Error");
		},
		changeProcessor: function (oEvt, procID) {
			var id;
			if (procID) {
				id = procID;
			} else {
				id = oEvt.getSource().getValue();
				if (id) {
					//make the entered string uppercase
					id = id.toUpperCase();
				}
			}
			//make request with the model
			if (mainModel) {
				sap.ui.core.BusyIndicator.show();
				var sRead = "/ProcessorDetails_Set(ProcessorType='" + this.processorTypeInput.getSelectedKey() + "',ProcessorID='" + id + "')";

				mainModel.read(sRead, null, null, true,
					this.procInfoSuccess.bind(this),
					this.procInfoError.bind(this));
			}
		},
		procInfoSuccess: function (oData, response) {
			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			var resultEntry = oData;
			if (resultEntry && resultEntry.ProcessorDescription && resultEntry.ProcessorDescription.length > 0) {
				this.processorIdInput.setValueState("None");
				this.processorNameInput
					.setValue(resultEntry.ProcessorDescription);

			} else {
				this.processorIdInput.setValueState("Error");
			}
		},
		procInfoError: function (oError) {
			sap.ui.core.BusyIndicator.hide();
			this.processorIdInput.setValueState("Error");
		},
		getControlReferences: function () {
			this.requestorIDInput = this.getView().byId(
				'REQUESTUSER_ID');

			this.processorIdInput = this.getView().byId("PROCESSOR_ID");
			this.processorNameInput = this.getView().byId("processorName");
			this.processorTypeInput = this.getView().byId("PROCESSOR_TYPE");
			this.requestType = this.getView().byId(
				'REQUESTFORM_TYPE');
			this.requestorNameInput = this.getView().byId(
				'REQUESTOR_FULLNAME');
			this.salesOrgInput = this.getView().byId('SALESORG_ID');
			this.salesOrgDescription = this.getView().byId(
				'SALESORG_DESCR');
			// C5186104 Default Notes
			this.defaultNotes = this.getView().byId(
				'DEFAULT_ID');
			// C5186104 Default Notes
			this.adminInfo = this.getView().byId('adminInfo');
			this.desc = this.getView().byId('H_DESCRIPTION');
			//C5219274 for ITSDEO2C-16882
			this.lastNotemsg = this.getView().byId('conversationControl_ID');
		},

		OnCasepress: function (oEvent) {
			var CMSId = this.getView().byId('CMSCaseID').getText(); //this.CMSCaseID.getText();
			var oJsonModel = new sap.ui.model.json.JSONModel();
			this.createCMSPopOver();
			var CmsId = new sap.ui.model.Filter("CaseId", "EQ", CMSId);
			var filters = [];
			filters.push(CmsId);
			var that = this;
			var obj = oEvent.getSource();
			var srf = new sap.ui.cms.util.ServiceRequestFactory();
			var oModel = new sap.ui.model.odata.ODataModel(srf.buildURLZCONTRACT(),
				true);
			oModel.read("/CmsCaseDetailsSet", {
				method: "GET",
				filters: filters,
				success: function (oData, response) {
					var itemCount = oData.results.length;
					if (itemCount > 0) {
						oJsonModel.setData(oData.results);
						that.CMSAttachPopover.setModel(oJsonModel, "cmsattach");
						//that.CMSAttachPopover.openBy(obj);
					} else {
						sap.m.MessageToast.show(that.oMessage.getText("No_Pdf_Msg"));
					}
				},
				error: function (oError) {
					sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
			var oModel1 = new sap.ui.model.odata.ODataModel(srf.buildURLZCONTRACT(),
				true);
			var oJsonModel1 = new sap.ui.model.json.JSONModel();
			oModel1.read("/CRFDocumentsSet", {
				method: "GET",
				filters: filters,
				success: function (oData, response) {
					var itemCount = oData.results.length;
					if (itemCount > 0) {
						oJsonModel1.setData(oData.results);
						that.CMSAttachPopover.setModel(oJsonModel1, "cmsattach1");
						that.CMSAttachPopover.openBy(obj);
					} else {
						sap.m.MessageToast.show(that.oMessage.getText("No_Pdf_Msg"));
					}
				},
				error: function (oError) {
					sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		createCMSPopOver: function () {
			if (this.CMSAttachPopover) {
				this.CMSAttachPopover.destroy();
			}

			this.CMSAttachPopover = sap.ui.xmlfragment("sap.ui.cms.view.QuickLink", this);
			// this.CMSAttachPopover = sap.ui.xmlfragment("sap.ui.cms.view.QuickView", this);
			this.getView().addDependent(this.CMSAttachPopover);
		},
		onCMSAttachmentDownload: function (oEvent) {
			if (sap.ui.Device.system.phone === true) {
				sap.m.MessageBox.warning("Please use Desktop to download documents");
			} else {
				var oModelUrl = oEvent.getSource().getBindingContext("cmsattach1").getObject();
				/*	var reqno = this.getView().byId('requestID').getValue();
					var filename = oModelUrl.Filename;
					var creator  = oModelUrl.Createdby;
					var fileatr  = oModelUrl.Filename;*/
				var caseid = oModelUrl.CaseId;
				var documentid = oModelUrl.DocumentId;
				var arcid = oModelUrl.ArcDocId;
				var temp = oModelUrl.__metadata.uri;
				temp = temp.substr(0, temp.lastIndexOf('/') + 1);
				var url = "CMSAttachmentsSet(CaseId='{0}',DocumentId='{1}',ArcDocId='{2}')/$value";
				temp = temp + url;
				temp = temp.replace("{0}", caseid);
				temp = temp.replace("{1}", documentid);
				temp = temp.replace("{2}", arcid);
				/*		temp = temp.replace("{2}", creator);
						temp = temp.replace("{3}", fileatr);*/
				// sap.m.URLHelper.redirect(temp, true);

				window.open(temp, "_blank");
			}
			/*			var createdby = this.getView().byId().getValue();
						var srf = new sap.ui.cms.util.ServiceRequestFactory();
						var oModel = new sap.ui.model.odata.ODataModel(srf.buildURLZCONTRACT(),true);
						
						oModel = oModel + "/"
						var oModelUrl = oEvent.getSource().getBindingContext("OrderDetailsFromERP").getObject();
						oModelUrl = oModelUrl.__metadata.uri;
						oModelUrl = oModelUrl.replace("CmsDocumentsSet", "CmsAttachmentSet");
						oModelUrl = oModelUrl + "/$value";
						window.open(oModelUrl, "_blank");*/
		},

		getNotes: function (oEvent) {
			var oController = this;

			jQuery.sap.require("sap.ui.custom.control.input.CInput");
			jQuery.sap.require("sap.ui.custom.control.conversation.Config");
			jQuery.sap.require("sap.ui.custom.control.conversation.ConversationExchangeObject");
			jQuery.sap.require("sap.ui.custom.control.conversation.ConversationDialogBuilder");

			var inputFieldHoldingLastMessage = oEvent.getSource();

			sap.ui.custom.control.conversation.ConversationI18N.language = new sap.ui.model.resource.ResourceModel({
				bundleUrl: [jQuery.sap.getModulePath("sap.ui.cms.i18n"), "messageBundle.properties"].join("/")
			});
			//			sap.ui.custom.control.conversation.Config.allowSubmit = false; 

			var conversationExcahngeObject = new sap.ui.custom.control.conversation.ConversationExchangeObject();
			conversationExcahngeObject.currentUser = sap.ui.cms.NotesGlobal.currentUser;

			conversationExcahngeObject.fk1 = "";
			conversationExcahngeObject.fk2 = "";
			conversationExcahngeObject.fk3 = "";

			conversationExcahngeObject.jsonModel = sap.ui.cms.NotesGlobal.notesModel;
			/*Added by C5219274 for ITSDEO2C-16882*/
			var lastNotemsg = "";
		
			try {
				var oConversationDialog = new sap.ui.custom.control.conversation.ConversationDialogBuilder(conversationExcahngeObject);
				oConversationDialog.getBeginButton().attachPress(function () {
					var lastNote = oConversationDialog.getConversationExchangeObject().lastNote;
					if (lastNote && lastNote.message && lastNote.message !== null && lastNote.message !== "") {
						inputFieldHoldingLastMessage.setValue(lastNote.user + " (" + lastNote.timestamp + "): " + lastNote.message);
						inputFieldHoldingLastMessage.addStyleClass("sapUiCmsDawtextoverflow");
						//C5219274 for ITSDEO2C-16882
						lastNotemsg = lastNote.message;
						/*that.getView().byId('conversationControl_ID').getValue();*/
						var notelast = new sap.ui.model.json.JSONModel({
							lastnotemsg:lastNotemsg
				});
				notelast.setDefaultBindingMode("OneWay");
				sap.ui.getCore().setModel(notelast, "lastnotemsg");
				}
					/*End of changes by C5219274 for ITSDEO2C-16882*/
					
					if (sap.ui.cms.NotesGlobal.objectID) {
						//submit notes if in edit
						var payload = sap.ui.cms.util.NotesProcessor.prepareNotesForSubmit();

						if (payload.NavToNotes.length > 0) {
							sap.ui.cms.util.NotesProcessor.submitNotes.apply(oController, [oController, payload]);
						}
					}

					oConversationDialog.close();
					oConversationDialog.destroy();
					oConversationDialog = null;

				});
				oConversationDialog.getEndButton().attachPress(function () {
					oConversationDialog.close();
					oConversationDialog.destroy();
					oConversationDialog = null;
				});
				oConversationDialog.open();
			} catch (e) {
				sap.m.MessageBox.show(e.toString(), sap.m.MessageBox.Icon.ERROR,
					sap.ui.cms.util.LanguageBundle.language.getResourceBundle()
					.getText("CMSCRF_ERROR_TITLE"), [sap.m.MessageBox.Action.CLOSE]);
			}
		},
		onCasePress: function (oEvent) {
			// var sCaseId = oEvent.getSource().getProperty("text");
			var sCaseId = JSON.parse(this.CMSAttachPopover.getModel("cmsattach").getJSON())[0].CaseId;
			var oModel = this.getView().getModel();
			oModel.callFunction("/Get_CaseUrl", {
				urlParameters: {
					"I_CaseId": sCaseId
				},
				success: function (oSuccessData) {
					window.open(oSuccessData.CaseUrl, "_blank");
				},
				error: function (oErrodData) {
					sap.m.MessageBox.error(JSON.parse(oErrodData.responseText).error.message.value);
				}
			});
		}

	});