/**
 * Controller. Handles all events of the view.
 */
jQuery.sap.require("sap.ui.custom.control.conversation.Config");
jQuery.sap.require("sap.ui.cms.util.Service");
jQuery.sap.require("sap.ui.cms.util.Formatter");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.m.MessageToast");
jQuery.sap.require("sap.ui.core.format.DateFormat");
jQuery.sap.require("sap.ui.cms.util.NotesProcessor");
jQuery.sap.require("sap.ui.cms.util.UserService");
jQuery.sap.require("sap.ui.cms.util.ServiceEvents");
jQuery.sap.require("sap.ui.cms.util.NotesProcessor");
jQuery.sap.require("sap.ui.cms.view.DialogSFRTHandler");
jQuery.sap.require("sap.ui.cms.util.NCButtonsHandlers");

jQuery.sap.require("sap.ui.cms.util.Controller");
util.Controller
	.extend(
		"sap.ui.cms.view.Home", {

			/**
			 * Called when a controller is instantiated and its View
			 * controls (if available) are already created. Can be used
			 * to modify the View before it is displayed, to bind event
			 * handlers and do other one-time initialization.
			 */
			onInit: function () {

				// C5204479-IT Mobile usage reporting-ITSDEO2C-12288
				// var server = "https://";
				// var domain = "trackingshallwe.hana.ondemand.com";
				// jQuery
				// 	.getScript(
				// 		server + domain + "/tracking/web-client/web-tracking.js",
				// 		function (data, status, jqxhr) {
				// 			jQuery
				// 				.getScript(
				// 					server + domain + "/tracking/web-client/crypto-sha1.js",
				// 					function (data, status, jqxhr) {
				// 						try {
				// 							tracking = new GlobalITTracking(
				// 								"C2RCRF",
				// 								"1.0.8");
				// 							console.log(tracking);
				// 						} catch (e) {
				// 							if (console)
				// 								console
				// 								.log("Error: " + e);
				// 						}
				// 					});
				// 		});

				var that = this;

				this.tag = "Home.controller";
				this.getRouter().attachRouteMatched(
					this.onRouteMatched, this);
				this.bus = this.getEventBus();
				this.bus.subscribe("refresh", "reloadPage",
					this.onAfterRendering, this);

				var viewModel = new sap.ui.model.json.JSONModel({
					hasActions: false,
					editMode: false,
					displayMode: false,
					shownewcrf: false, //C5204479
					showProcessor: false,
					// C5186104 back te request status visibility 7003575000
					showStatus: false,
					// C5186104 back te request status visibility 7003575000
					creationMode: true,
					statusMessage: ""

				});
				viewModel.setDefaultBindingMode("OneWay");
				this.getView().setModel(viewModel, "view");
				// this is needed for the detail request to get the
				// dropdown metadata
				this.loadDropDownDataOnly = false;
				this.getControlReferences();
				this.routerInitialized = false;
				this.fillFields = true;
				this.copyattachments = true; // C5204479-Copy attachments flag
				sap.ui.cms.copycrf = false;
				this.actionModeSa = ""; //C5204479- No validation for action save
				var eventBus = sap.ui.getCore().getEventBus();
				eventBus
					.subscribe(
						sap.ui.cms.util.ServiceEvents.CHANEL,
						sap.ui.cms.util.ServiceEvents.EVENT_DISPLAY_LAST_NOTE,
						sap.ui.cms.util.NotesProcessor.displayLastNote,
						that);
			},
			onRouteMatched: function (oEvent) {
				var name = oEvent.getParameter("name");

				if (name !== "homeLanguage" && name !== "home" && name !== "homeObjectID" && name !== "homeRequestType" && name !==
					"homeRequestTypeLang" && name !== "homeObjectIDLang" && name !== "homeRequestTypeLangSalesOrg") { //new params added C5299813
					return;
				}
				// refresh the page if the user goes from detail mode
				// into creation mode and vice versa
				// TODO: make possible that no refresh is used
				if (objectID && name.search("home") !== -1 && name.search("Object") === -1 && this.routerInitialized) {
					// we are going from edit or detail mode into
					// creation mode
					window.location.reload();
					return;
				}
				if (!objectID && name.search("Object") !== -1 && this.routerInitialized) {
					// we are going from creation mode into detail mode
					window.location.reload();
					return;
				}
				if (!objectID && name.search("Request") !== -1 && this.routerInitialized) {
					// we are going from creation mode into detail mode
					window.location.reload();
					return;
				}

				// save the parameters
				var args = oEvent.getParameter("arguments");
				this.SalesOrgIDValue = oEvent.getParameter("arguments").sales_org;  //C5299813 New params
				//C5325212 new params
				CPQIDValue = oEvent.getParameter("arguments").cpq_id; 
				CMSCASEIDValue = oEvent.getParameter("arguments").cms_case_id; 
				//End changes
				
				language = args.language;
				if (language)
					language = language.trim();
				var id = args.id;
				var requestType = args.type;
				

				if (requestType)
					type = requestType;
				if (id) {
					objectID = id;
					sap.ui.cms.NotesGlobal.objectID = objectID;
				}

				// execute starting process
				// var url = jQuery.sap.getModulePath("sap.ui.cms") +
				// serviceUrl + "ZCONTRACTRF_SRV/";
				// var oModel = new sap.ui.model.odata.ODataModel(url,
				// true);
				// mainModel = oModel;

				this.routeArgs = args;

				if (!objectID || objectID.length <= 0) {
					this.loadDropDownDataOnly = false;
					this.getInitInformation();
				} else {
					this.loadDropDownDataOnly = true;
					this.getInitInformation();

				}

				// show no attachment tab when on phone or tablet
				if (!sap.ui.Device.system.desktop) {
					this.getView().byId("attachmentFilter").setVisible(
						false);
					// remove separator for attachments because they are
					// not visible -> separators cannot be set invisible
					// therefore it has to be removed!
					this.getView().byId("iconTabBar").removeItem(
						this.getView().byId(
							"attachmentIconSeparator"));

				} else {
					this.getView().byId("attachmentFilter").setVisible(
						true);
				}

				this.routerInitialized = true;
				this.copyattachments = true;
				sap.ui.cms.copycrf = false;
			},
			showActionSheet: function (isEditMode, hasActions) {
				if (isEditMode && hasActions) {
					return true;
				}

				return false;
			},
			openOverflow: function (oEvt) {
				var sheet = sap.ui.xmlfragment(
					"sap.ui.cms.view.ActionSheet", this);
				this.getView().addDependent(sheet);
				sheet.setModel("view", this.getView().getModel("view"));
				sheet.openBy(oEvt.getSource());
			},
			getInitInformation: function (oEvt) {
				sap.ui.core.BusyIndicator.show;
				if (!type) {
					this.typeInput.setEnabled(true);
					type = "";
				} else {
					var selectItem = new sap.ui.core.Item({
						key: type,
						text: type
					});
					this.typeInput.setSelectedItem(selectItem);
					this.typeInput.setEnabled(false);
					requestFormType = type;
				}

				if (mainModel) {
					var functionPath = "GeneralFormCollection_Set";
					sap.ui.core.BusyIndicator.show();
					var sRead = "/GeneralFormCollection_Set/?$filter=Section%20eq%20%27H%27%20and%20RequestformType%20eq%20%27" + type +
						"%27%20&$expand=NavToLoad";

					mainModel.read(sRead, null, null, true,
						this.onInitSuccess.bind(this),
						this.onInitFailure.bind(this));

					sap.ui.cms.util.UserService.loadUser.apply(this, [this]);

					if (sap.ui.cms.NotesGlobal.objectID) {
						sap.ui.cms.util.NotesProcessor.loadNotes.apply(
							this, [this]);
					}
				}

			},
			openMessageBox: function (title, text) {
				sap.m.MessageBox.show(text, "sap-icon://alert", title, [sap.m.MessageBox.Action.OK]);
			},
			fillDropdownMetaData: function (results) {
				if (results && results.length > 0) {
					for (var i in results) {
						var control = this.headerInfoView
							.byId(results[i].Fieldname);
						if (control) {
							if (results[i].NavToLoad.results && results[i].NavToLoad.results.length > 0) {
								var model = new sap.ui.model.json.JSONModel();
								model
									.setSizeLimit(results[i].NavToLoad.results.length + 1);
								model
									.setData(results[i].NavToLoad.results);
								control.setModel(model);
							}
							if (control instanceof sap.m.Select) {
								control
									.setSelectedKey(results[i].Fieldvalue);
								if (results[i].Fieldvalue && results[i].Fieldvalue.length > 0) {
									if (results[i].Fieldname == "REQUEST_STATUS") {
										// Hide processor fields for
										// status S1 and S7
										if (results[i].Fieldvalue == "S1" || results[i].Fieldvalue == "S7") {
											this
												.getView()
												.getModel("view")
												.setProperty(
													"/showProcessor",
													false);
											// C5186104 back te request status visibility 7003575000
											this
												.getView()
												.getModel("view")
												.setProperty(
													"/showStatus",
													false);
											// C5186104 back te request status visibility 7003575000
										} else {
											this
												.getView()
												.getModel("view")
												.setProperty(
													"/showProcessor",
													true);
											// C5186104 back te request status visibility 7003575000
											this
												.getView()
												.getModel("view")
												.setProperty(
													"/showStatus",
													true);
											// C5186104 back te request status visibility 7003575000
										}

									} else {

										control.fireChange();
									}

								}

								if (type && results[i].Fieldname
									.search("REQUESTFORM_TYPE") != -1) {
									control.setSelectedKey(type);
								}
							}
						}

					}

				}
				this._drsftCheck();
			},
			onInitSuccess: function (oData, response) {
				sap.ui.core.BusyIndicator.hide();
				util.Service.checkForSessionTimeout(response);
				this.getView().getModel("view").setProperty(
					"/creationMode", true);
				//C5204479
				this.getView().getModel("view").setProperty(
					"/shownewcrf", false);
				//C5204479
				this.getView().getModel("view").setProperty(
					"/displayMode", false);
				this.getView().getModel("view").setProperty(
					"/editMode", false);

				// this.conversationInput.setEnabled(true);
				sap.ui.custom.control.conversation.Config.allowSubmit = true;

				this.initDataResult = results;
				var results = oData.results;
				if (results && results.length > 0) {
					if (results.length == 1 && results[0].ErrorText.length > 0) {
						this.showErrorBox("Failed",
							results[0].ErrorText);

					} else {

						if (!this.loadDropDownDataOnly) {
							for (var i in results) {

								var control = this.headerInfoView
									.byId(results[i].Fieldname);

								if (control) {
									control
										.setValue(results[i].Fieldvalue);
									control.data("shName",
										results[i].SearchHelpName);
									if (results[i].Fieldname
										.search("FULL") != -1) {
										this.adminInfo
											.setText("Created by " + results[i].Fieldvalue + " on " + util.Service
												.getDateDDMMYYYY());
										this.adminInfo.setVisible(true);
									}
									if (results[i].Fieldname === "ChngdFullname") { //C5219274 for ITSDEO2C-15755
										this.ChangedByText.setText("Changed By " + results[i].Fieldvalue + " on " + Date(results[i].ChangedOn));
										this.ChangedByText.setVisible(true);
									}
								}
								// set the title when this fieldname
								// occurs
								if (results[i].Fieldname
									.search("T_DESCRIPTION") != -1) {
									// set the title only if the value
									// is set and not empty
									if (results[i].Fieldvalue && results[i].Fieldvalue.length > 0) {
										this
											.getView()
											.byId("page")
											.setTitle(
												results[i].Fieldvalue);
									}
								}
								//Insert C5299813 New Params added in Filter
								if(results[i].Fieldname === "SALESORG_ID" && this.SalesOrgIDValue){
									
									if (mainModel) {
											var sRead = "/SRCHHELP_VKORG_SET('" + this.SalesOrgIDValue + "')";
											sap.ui.core.BusyIndicator.show();
										mainModel.read(sRead, null, null, true,
											this.salesOrgInfoSuccess.bind(this),
											this.salesOrgInfoError.bind(this));
	
									}		
								}
								//End Insert 	
								
								if (results[i].Fieldname === "HIDE_CP_TAB") {
									// if the cp tab field is passed
									// over check for the boolean value
									// var cpTab =
									// this.getView().byId("contactFilter");
									if (results[i].Fieldvalue && results[i].Fieldvalue.length > 0) {
										// hide the cp tab
										this
											.getView()
											.byId("iconTabBar")
											.removeItem(
												this
												.getView()
												.byId(
													"cpSeparator"));
										this.getView().getModel("view")
											.setProperty(
												"/showCPTab",
												false);
									} else {
										this.getView().getModel("view")
											.setProperty(
												"/showCPTab",
												true);
									}
								}

							}

							currentUser = this.requestorIDInput
								.getValue();
							this.fillDropdownMetaData(results);
						} else {
							this.fillDropdownMetaData(results);
							this.loadDisplayData(objectID);
						}
					}

				}

				var eventBus = sap.ui.getCore().getEventBus();
				eventBus
					.publish(
						sap.ui.cms.util.ServiceEvents.CHANEL,
						sap.ui.cms.util.ServiceEvents.EVENT_DISPLAY_LAST_NOTE, {});

			},
			onInitFailure: function (oError) {
				sap.ui.core.BusyIndicator.hide();
				this
					.openMessageBox("Failed",
						"The connection to the backend could not be established!");
			},

			getContactFieldValues: function () {
				var contactFieldValues = [];
				var contactTable = this.getView()
					.byId("contactTabView").byId("contactTable");
				var tableItems = contactTable.getItems();
				for (var i in tableItems) {
					var object = new Object();
					var item = tableItems[i];
					var idInput = item.getCells()[1];
					var typeInput = item.getCells()[0];

					var id = idInput.getValue();
					var type = "";

					if (typeInput.getSelectedItem()) {
						type = typeInput.getSelectedItem().getKey();
					}

					object["SAPContactID"] = id;
					object["SAPContactType"] = type;
					if (this.getView().getModel("view").getProperty(
							"/editMode") === true) {
						object["RequestNumber"] = objectID;
					}

					contactFieldValues.push(object);

				}
				return contactFieldValues;
			},
			getContractFieldValues: function () {
				var contractFieldValues = [];
				var contractTable = this.getView().byId(
					"contactTabView").byId("contractTable");
				var tableItems = contractTable.getItems();
				for (var i in tableItems) {
					var object = new Object();
					var item = tableItems[i];
					var idInput = item.getCells()[1];
					var typeInput = item.getCells()[0];

					var id = idInput.getValue();
					var type = "";

					if (typeInput.getSelectedItem()) {
						type = typeInput.getSelectedItem().getKey();
					}

					object["ContractualPartyID"] = id;
					object["ContractualPartyType"] = type;
					if (this.getView().getModel("view").getProperty(
							"/editMode") === true) {
						object["RequestNumber"] = objectID;
					}

					contractFieldValues.push(object);

				}

				return contractFieldValues;
			},
			getSAPContactIDValues: function () {

				var sapContactIDFieldValues = [];
				var custContactTable = this.getView().byId(
					"contactTabView").byId("custContactTable");
				var tableItems = custContactTable.getItems();
				for (var i in tableItems) {
					var object = new Object();
					var item = tableItems[i];
					var idInput = item.getCells()[1];
					var typeSelect = item.getCells()[0];

					var id = idInput.getValue();

					object["ContactID"] = id;
					object["ContactType"] = typeSelect.getSelectedKey();
					if (this.getView().getModel("view").getProperty(
							"/editMode") === true) {
						object["RequestNumber"] = objectID;
					}

					sapContactIDFieldValues.push(object);

				}

				return sapContactIDFieldValues;

			},
			getDetailFieldValues: function () {
				var detailFieldValues = [];
				var detailForm = this.getView().byId("detailTabView")
					.byId("detailForm");
				var formInputControls = util.Service
					.getAllUsableControlsOutOfSimpleForm(detailForm);

				for (var i in formInputControls) {
					var control = formInputControls[i];
					var object = new Object();
					object["FieldName"] = control.data("itemId");
					var fieldValue = "";

					if (control instanceof sap.m.Input || control instanceof sap.m.TextArea) {
						fieldValue = control.getValue();
					} else if (control instanceof sap.m.Select) {
						var selectedItem = control.getSelectedItem();
						if (selectedItem) {
							fieldValue = selectedItem.getKey();
						}

					} else if (control instanceof sap.m.CheckBox) {
						fieldValue = util.Service
							.booleanToString(control.getSelected());
					} else if (control instanceof sap.m.DateTimeInput) {
						// remove the timezone and the time
						if (control.getDateValue()) {
							var dateFormat = sap.ui.core.format.DateFormat
								.getDateInstance({
									pattern: "yyyyMMdd"
								});
							var dateStr = dateFormat.format(control
								.getDateValue());
							fieldValue = dateStr;
						}
					}

					// the value must not be null -> set it to an empty
					// string
					if (!fieldValue) {
						fieldValue = "";
					}

					object["FieldValue"] = fieldValue;
					if (this.getView().getModel("view").getProperty(
							"/editMode") === true) {
						object["RequestNumber"] = objectID;
					}

					detailFieldValues.push(object);
				}
				return detailFieldValues;
			},
			validateDetailsArea: function () {
				var dataIsValid = true;
				var detailAreaForm = this.detailAreaView
					.byId("detailForm");
				var detailInputControls = util.Service
					.getAllUsableControlsOutOfSimpleForm(detailAreaForm);

				for (var i in detailInputControls) {
					var control = detailInputControls[i];
					var mandatoryControl = control.data("mandatory");
					if (control instanceof sap.m.Input || control instanceof sap.m.TextArea) {
						if (mandatoryControl && (!control.getValue() || control
								.getValue().length <= 0)) {
							control.setValueState("Error");
							dataIsValid = false;
						} else {
							control.setValueState("None");
						}
					} else if (control instanceof sap.m.ComboBox) {
						if (mandatoryControl && (!control.getSelectedItem() || !control.getSelectedItem()
								.getKey() || control
								.getSelectedItem().getKey().length <= 0)) {
							control.setValueState("Error");
							dataIsValid = false;
						} else {
							control.setValueState("None");
						}

					} else if (control instanceof sap.m.DateTimeInput) {
						if (mandatoryControl && (!control.getDateValue() || control
								.getDateValue().length <= 0)) {
							control.setValueState("Error");
							dataIsValid = false;
						} else {
							control.setValueState("None");
						}

					} else if (control instanceof sap.m.Select) {
						if (mandatoryControl && (!control.getSelectedItem() || !control.getSelectedItem()
								.getKey() || control.getSelectedItem()
								.getKey().length <= 0 || !control.getSelectedItem()
								.getText() || control
								.getSelectedItem().getText().length <= 0)) {
							dataIsValid = false;
						}
					}

				}

				// change the color of the tab depending on if it is
				// valid or not
				var tab = this.getView().byId("detailFilter");
				if (dataIsValid) {
					tab.setIconColor("Default");
				} else {
					tab.setIconColor("Critical");
				}
				return dataIsValid;
			},
			loadDisplayMode: function (objectId) {
				if (objectID === objectId) {
					window.location.reload();
					return;
				}
				this.getRouter().navTo("homeObjectID", {
					id: objectId
				});

			},
			triggerEditMode: function () {
				//email edit beign
				//	this.getView().getModel("view").setEnabled(
				//			"/showButton", true);
				//email edit end
				this.fillFields = false;

				// call backend to check if the user is allowed to go
				// into edit mode
				if (mainModel) {
					sap.ui.core.BusyIndicator.show();
					mainModel
						.read(
							"/CRFRequestData_Set/?$filter=RequestNumber%20eq%20%27" + objectID +
							"%27%20and%20ActionMode%20eq%20%27ED%27&$expand=NavToCP,NavToSC,NavToCO,NavToDetail,NavToAttach",
							null, null, true,
							this.onLoadDisplayDataSuccess
							.bind(this),
							this.onLoadDisplayDataFailure
							.bind(this));

				}
				// Start - Modification for ensuring that Attachments Tab Data is loaded when Edit is pressed - 08 / 06 / 2017
				if (mainModel && (!this.attachmentsData || !this.attachmentsData.length > 0)) {
					sap.ui.core.BusyIndicator.show();
					mainModel.read("/CRFRequestData_Set('" + objectID + "')/NavToAttach", null,
						null, true,
						this.onLoadAttachmentDataSuccess
						.bind(this),
						this.onLoadAttachmentDataFailure
						.bind(this));

				}
				// End - Modification for ensuring that Attachments Tab Data is loaded when Edit is pressed - 08 / 06 / 2017

			},
			triggerCancelEditMode: function () {
				this.fillFields = false;
				// call backend to notify that the user left the edit
				// mode
				if (mainModel) {
					sap.ui.core.BusyIndicator.show();
					mainModel
						.read(
							"/CRFRequestData_Set/?$filter=RequestNumber%20eq%20%27" + objectID +
							"%27%20and%20ActionMode%20eq%20%27CED%27&$expand=NavToCP,NavToSC,NavToCO,NavToDetail,NavToAttach",
							null, null, true,
							this.onLoadDisplayDataSuccess
							.bind(this),
							this.onLoadDisplayDataFailure
							.bind(this));

				}
			},
			edit: function (oEvt) {
				this.getView().getModel("view").setProperty(
					"/creationMode", false);
				this.getView().getModel("view").setProperty(
					"/displayMode", false);
				this.getView().getModel("view").setProperty(
					"/editMode", true);
				//C5204479
				this.getView().getModel("view").setProperty(
					"/shownewcrf", false);
				//C5204479
				this.switchToDisplayMode(objectID, true, true);
			},
			cancelEdit: function (oEvt) {
				this.getView().getModel("view").setProperty(
					"/creationMode", false);
				this.getView().getModel("view").setProperty(
					"/displayMode", true);
				this.getView().getModel("view").setProperty(
					"/editMode", false);
				//C5204479
				this.getView().getModel("view").setProperty(
					"/shownewcrf", true);
				//C5204479
				this.switchToDisplayMode(objectID, false, false);
			},
			save: function (oEvt) {},
			switchToDisplayMode: function (id, enableControls,
				isEditMode) {
				var lockMode = this.getView().getModel("config")
					.getProperty("/lockMode");
				var reqStatus = this.reqStatusInput.getSelectedKey(); //C5186104 /ITSDEO2C-7099
				if (!enableControls) {
					enableControls = false;
					if (lockMode == "E" || lockMode == "P") {
						enableControls = true;
						isEditMode = true;
						this.getView().getModel("view").setProperty(
							"/creationMode", false);
						this.getView().getModel("view").setProperty(
							"/displayMode", false);
						this.getView().getModel("view").setProperty(
							"/editMode", true);
						//C5204479
						// if(reqStatus == "S2" & lockMode == "P"){
						this.getView().getModel("view").setProperty(
							"/shownewcrf", false);
						// }
						//C5204479							
					} else {
						this.getView().getModel("view").setProperty(
							"/creationMode", false);
						if (reqStatus == "S3" || reqStatus == "S5" || reqStatus == "S4" || reqStatus == "S6") { //C5186104 /ITSDEO2C-7099 start
							this.getView().getModel("view").setProperty(
								"/displayMode", false);
							//C5204479
							this.getView().getModel("view").setProperty(
								"/shownewcrf", true);
							//C5204479
						} else {
							this.getView().getModel("view").setProperty(
								"/displayMode", true);
							//C5204479
							// if(reqStatus == "S2"){
							// this.getView().getModel("view").setProperty(
							// 	"/shownewcrf", false);
							// }else{
							this.getView().getModel("view").setProperty(
								"/shownewcrf", true);
							// }

							//C5204479
						}

						this.getView().getModel("view").setProperty(
							"/editMode", false);
					}

				}
				if (!isEditMode) {
					isEditMode = false;
				}

				// make the request id field visible when the app is
				// opened in the edit mode or when the controls are
				// disabled
				this.requestIDInput.setVisible(!enableControls || isEditMode);
				this.CMSCaseID
					.setVisible(!enableControls || isEditMode);
				//c5204479-Cms ID was not visible on header after confirm-Start
				if (this.CMSCaseID.getText() == "") {
					this.CMSCaseID
						.setVisible(false);
				}
				//c5204479-Cms ID was not visible on header after confirm-End
				if (id) {
					this.requestIDInput.setValue(id);
				}

				this.enableHeaderArea(false, lockMode);

				this.enableContactArea(enableControls);

				this.enableDetailsArea(enableControls);

				this.enableAttachmentArea(enableControls);

			},
			enableHeaderArea: function (enableControls, lockMode) {
				var isProcessorMode = false;
				if (lockMode == "P") {

					isProcessorMode = true;
				}
				// make all fields in the header area read only
				this.typeInput.setEnabled(enableControls);
				this.requestorIDInput.setEnabled(enableControls);
				// this.noteInput.setEditable(enableControls);

				if (this.getView().getModel("view").getProperty(
						"/editMode") && this.getView().getModel("view").getProperty(
						"/editMode") === true) {
					// this.conversationInput.setEnabled(true);
					sap.ui.custom.control.conversation.Config.allowSubmit = true;
				} else {
					// this.conversationInput.setEnabled(false);
					sap.ui.custom.control.conversation.Config.allowSubmit = false;
				}

				this.descriptionInput.setEnabled(enableControls);
				this.salesOrgInput.setEnabled(enableControls);

				this.procTypeInput.setEnabled(isProcessorMode);
				this.procIdInput.setEnabled(isProcessorMode);

				// C5204479-Copy new CRF and create new crf should invisible to processor
				var newCrfBt = this.getView().getModel("config")
					.getProperty("/newCrfBt");
				var reqStatus = this.reqStatusInput.getSelectedKey();
				if (reqStatus == "S2" & newCrfBt == "X") {
					this.getView().getModel("view").setProperty(
						"/shownewcrf", false);
				}

			},
			enableContactArea: function (enableControls) {

				this.getView().byId("contactTabView")
					.byId("contactAdd").setEnabled(enableControls);
				this.getView().byId("contactTabView").byId(
					"custContactAdd").setEnabled(enableControls);
				this.getView().byId("contactTabView").byId(
					"contractAdd").setEnabled(enableControls);

				this.getView().byId("contactTabView").byId(
					"contactRemove").setEnabled(enableControls);
				this.getView().byId("contactTabView").byId(
					"custContactRemove").setEnabled(enableControls);
				this.getView().byId("contactTabView").byId(
					"contractRemove").setEnabled(enableControls);
			},
			enableDetailsArea: function (enableControls) {
				// make all fields in the detail area read only
				var detailAreaForm = this.detailAreaView
					.byId("detailForm");
				var detailInputControls = util.Service
					.getAllUsableControlsOutOfSimpleForm(detailAreaForm);
				for (var i in detailInputControls) {
					var control = detailInputControls[i];
					if (control instanceof sap.m.TextArea) {
						control.setEditable(enableControls);
					} else {
						if (!(control instanceof sap.m.Text) && !(control instanceof sap.m.Button)) {
							control.setEnabled(enableControls);
						}
					}
				}
			},
			enableAttachmentArea: function (enableControls) {
				// make the attachments buttons read only
				this.getView().byId("attachmentTabView").byId(
					"attachmentAdd").setEnabled(enableControls);
				this.getView().byId("attachmentTabView").byId(
					"attachmentRemove").setEnabled(enableControls);
			},
			switchToCreationMode: function () {
				// make the request id field invisible
				this.requestIDInput.setVisible(false);
				this.CMSCaseID.setVisible(false);
				// enable all fields in the header area
				// enable all fields in the contact area
				// enable all fields in the detail area
				// enable the attachments
			},
			loadDisplayData: function (id) {
				// request the data of a specific entry with the given
				// id
				if (mainModel) {
					sap.ui.core.BusyIndicator.show();
					mainModel
						.read(
							"/CRFRequestData_Set('" + id + "')/?$expand=NavToCP,NavToSC,NavToCO,NavToDetail",
							null, null, true,
							this.onLoadDisplayDataSuccess
							.bind(this),
							this.onLoadDisplayDataFailure
							.bind(this));

				}
			},
			showWebDynproLink: function (objectId, requestFormType) {
				var bCompact = !!this.getView().$().closest(
					".sapUiSizeCompact").length;
				var oLayout = sap.ui.xmlfragment(
					"sap.ui.cms.view.LinkBox", this);
				var model = new sap.ui.model.json.JSONModel();
				model.setProperty("/link", util.Service
					.buildWebDynproLink(objectId, requestFormType));
				oLayout.setModel(model);

				// get the view and add the layout as a dependent. Since
				// the layout is being put
				// into an aggregation any possible binding will be
				// 'forwarded' to the layout.
				var oView = this.getView();
				oView.addDependent(oLayout);

				sap.m.MessageBox.show(oLayout, {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: "Information",
					actions: [sap.m.MessageBox.Action.OK]
				});

			},
			onLoadDisplayDataSuccess: function (oData, response) {
				sap.ui.core.BusyIndicator.hide();
				util.Service.checkForSessionTimeout(response);
				if (oData.results)
					oData = oData.results[0];
				this.getView().getModel("view").setProperty(
					"/creationMode", false);
				this.getView().getModel("view").setProperty(
					"/displayMode", true);
				this.getView().getModel("view").setProperty(
					"/editMode", false);
				//C5204479
				this.getView().getModel("view").setProperty(
					"/shownewcrf", true);
				//C5204479
				if (tracking)
					tracking.postEvent("Display item");
				this.getView().getModel("config").setProperty(
					"/showCPTab", !oData.HideCPTab);

				if (oData.HideCPTab && oData.HideCPTab === true) {
					this.getView().byId("iconTabBar").removeItem(
						this.getView().byId("cpSeparator"));
					this.getView().getModel("view").setProperty(
						"/showCPTab", false);
				}

				// ActionMode: "FO,SA,CL,CO,RE,CF"
				if (oData.ActionMode && oData.ActionMode.length > 0) {
					this.getView().getModel("view").setProperty(
						"/hasActions", true);
					this.getView().getModel("view").setProperty(
						"/possibleActions", oData.ActionMode);
				} else {
					this.getView().getModel("view").setProperty(
						"/hasActions", false);
					this.getView().getModel("view").setProperty(
						"/possibleActions", "");
				}
				var errorText = oData.ErrorText;
				if (errorText && errorText.length > 0 && oData.RequestUserID.length <= 0) {
					this.showErrorBox("There was an error!", errorText);
				} else {
					if (errorText && errorText.length > 0 && oData.RequestUserID.length > 0) {
						this.showWarningBox("Warning!", errorText);
					}
					if (!oData.CreatedByApp || oData.CreatedByApp.length <= 0) {
						this.showWebDynproLink(oData.RequestNumber,
							oData.RequestFormType);
					}
					this.updateDateTime = oData.UpdatedDateTime;
					this.getView().getModel("config").setProperty(
						"/lockMode", oData.LockMode);
					//C5204479 - Set the flag which indicates to whether to display copy or create new crf buttons
					this.getView().getModel("config").setProperty(
						"/newCrfBt", oData.NewCrfBt);
					this.getView().byId("contactFilter").setEnabled(
						true);
					this.getView().byId("attachmentFilter").setEnabled(
						true);

					this.fillFieldsWithData(oData);
					this.switchToDisplayMode(objectID);
					this.fillFields = true;
				}

				var eventBus = sap.ui.getCore().getEventBus();
				eventBus
					.publish(
						sap.ui.cms.util.ServiceEvents.CHANEL,
						sap.ui.cms.util.ServiceEvents.EVENT_DISPLAY_LAST_NOTE, {});
			},

			onLoadDisplayDataFailure: function (oData, response) {
				sap.ui.core.BusyIndicator.hide();
				this
					.openMessageBox("Failed",
						"The connection to the backend could not be established!");
			},
			fillFieldsWithData: function (oData) {

				var requestType = oData.RequestFormType;
				requestFormType = requestType;
				// set the title when this fieldname occurs
				if (oData.FormTitle && oData.FormTitle.length > 0) {
					// set the title only if the value is set and not
					// empty

					this.getView().byId("page").setTitle(
						oData.FormTitle);

				}
				//	this.attachmentList = oData.NavToAttach.results;
				
				var adminInfoText = "Created ";
				if (oData.CreatorFullname) {
					adminInfoText = adminInfoText + "by " + oData.CreatorFullname + " ";
				}
				if (oData.CreatedDate) {
					adminInfoText = adminInfoText + "on " + util.Formatter
						.getDateString(oData.CreatedDate);
				}
				if (adminInfoText.length > 0 && (oData.CreatedDate || oData.CreatorFullname)) {
					this.adminInfo.setText(adminInfoText);
					this.adminInfo.setVisible(true);
				}
				//C5219274 - For ITSDEO2C-15755 : Start
				var ChangedByText = "Changed ";

				if (oData.ChngdFullname) {
					ChangedByText = ChangedByText + "by " + oData.ChngdFullname + " ";
				}
				if (oData.ChangedOn) {
					ChangedByText = ChangedByText + "on " + util.Formatter
						.getDateString(oData.ChangedOn);
				}
				if (ChangedByText.length > 0 && (oData.ChngdFullname || oData.ChangedOn)) {
					this.ChangedByText.setText(ChangedByText);
					this.ChangedByText.setVisible(true);
				}
				//C5219274 - For ITSDEO2C-15755 : End

				if (oData.CMSCaseID && oData.CMSCaseID !== "") {
					this.CMSCaseID.setText(oData.CMSCaseID);
					this.CMSCaseID.setEnabled(true);
				} else {
					this.CMSCaseID.setVisible(false);
					//this.CMSCaseID.destroy();
				}

				var eventBusForType = "";
				// only show the description for the type, when it is
				// there!
				if (oData.RequestFormTdescr && oData.RequestFormTdescr.length > 0) {
					descriptionForType = " - " + oData.RequestFormTdescr;
				}
				var selectItem = new sap.ui.core.Item({
					key: requestType,
					text: requestType + descriptionForType
				});
				this.typeInput.setSelectedKey(requestType);
				var salesOrg = oData.SalesOrg;
				salesOrgID = salesOrg;
				this.salesOrgInput.setValue(salesOrg);
				this.bus.publish("service", "changeSalesOrg", {
					data: salesOrg
				});

				var requestUserId = oData.RequestUserID;
				// TODO: this is not correct at all! The request has to
				// deliver the user who has executed the service in
				// order to know what the correct current user id is!
				currentUser = requestUserId;

				this.requestorIDInput.setValue(requestUserId);
				this.requestorNameInput
					.setValue(oData.RequestorFullname);
				// C5186104 default Notes
				var note = oData.Note;
				this.defaultNotes.setValue(note);
				// C5186104 default Notes
				var description = oData.Description;
				this.descriptionInput.setValue(description);
				var selectItemProcType = new sap.ui.core.Item({
					key: oData.ProcessorType,
					text: oData.ProcessorType
				});
				// C5204479--Create new CRF
				if (oData.ProcessorID && oData.ProcessorID !== "") {
					this.procTypeInput
						.setSelectedKey(oData.ProcessorType);
					this.procIdInput.data("shName", this.procTypeInput
						.getSelectedItem().data("sH"));
					this.procIdInput.setValue(oData.ProcessorID);
					this.processorNameInput
						.setValue(oData.ProcessorDescription);

					var selectItemStatus = new sap.ui.core.Item({
						key: oData.RequestStatus,
						text: oData.RequestStatus
					});
					this.reqStatusInput.setSelectedKey(oData.RequestStatus);
					// trigger change function
					// this.reqStatusInput.fireChange();
					// this.headerInfoView.byId("PROCESSOR_ID").data("shName",
					// this.reqStatusInput.getSelectedItem().data("sH"));
					// Hide processor fields for status S1 and S7
					if (oData.RequestStatus == "S1" || oData.RequestStatus == "S7") {
						this.getView().getModel("view").setProperty(
							"/showProcessor", false);
						// C5186104 back te request status visibility 7003575000
						this.getView().getModel("view").setProperty(
							"/showStatus", true);
						// C5186104 back te request status visibility 7003575000
						//c5234631 email enable begin
						// this.getView().getModel("view").setEnabled(
						// 	"/showButton", false);
						//c5234631 email enable end

					} else {
						this.getView().getModel("view").setProperty(
							"/showProcessor", true);
						// C5186104 back te request status visibility 7003575000
						this.getView().getModel("view").setProperty(
							"/showStatus", true);
						// C5186104 back te request status visibility 7003575000
						//c5234631 email enable begin 
						//	this.getView().getModel("view").setEnabled(
						//	"/showButton", false);
						//c5234631 email enable end
					}
				} else {
					// this.procTypeInput.destroy();
					// this.procIdInput.destroy();
					// this.processorNameInput.destroy();
					this.procTypeInput.setVisible(false);
					this.procIdInput.setVisible(false);
					this.processorNameInput.setVisible(false);
					// this.processorNameInput.setValue("");
					// this.processorNameInput.setVisible(false);
					// this.processorNameInput.setEnabled(false);
					// this.reqStatusInput.setValue("");
					this.reqStatusInput.setVisible(false);
					// this.reqStatusInput.setEnabled(false);
				}
				// C5204479--Create new CRF
				var contacts = oData.NavToCO.results;
				var sapContacts = oData.NavToSC.results;
				var contractualParties = oData.NavToCP.results;
				this.fillContactAreaWithData(contacts, sapContacts,
					contractualParties);
				var detailAreaValues = oData.NavToDetail.results;
				this.fillDetailAreaWithData(detailAreaValues);

				var eventBus = sap.ui.getCore().getEventBus();
				eventBus
					.publish(
						sap.ui.cms.util.ServiceEvents.CHANEL,
						sap.ui.cms.util.ServiceEvents.EVENT_DISPLAY_LAST_NOTE, {});
			},
			fillDetailAreaWithData: function (data) {
				this.bus.publish("service", "loadDetailContent", {
					data: data
				});
			},
			fillContactAreaWithData: function (contacts, sapContacts,
				contractualParties) {
				// load CP Area content data
				this.bus.publish("service", "loadCPContent", {
					contacts: contacts,
					sapContacts: sapContacts,
					contractualParties: contractualParties
				});
			},
			validateSAPContacts: function () {
				var dataIsValid = true;
				return dataIsValid;
			},
			validateContractualParty: function () {
				var dataIsValid = true;

				return dataIsValid;
			},
			validateContacts: function () {
				var dataIsValid = true;

				return dataIsValid;
			},
			validateHeaderArea: function () {
				var dataIsValid = true;
				// the sales org id must be filled!
				if (!this.salesOrgInput.getValue() || this.salesOrgInput.getValue().length <= 0) {
					this.salesOrgInput.setValueState("Error");
					dataIsValid = false;
				} else {
					this.salesOrgInput.setValueState("None");
				}

				// the sales org id must be filled!
				if (!this.descriptionInput.getValue() || this.descriptionInput.getValue().length <= 0) {
					this.descriptionInput.setValueState("Error");
					dataIsValid = false;
				} else {
					this.descriptionInput.setValueState("None");
				}

				// the sales org id must be filled!
				if (!this.requestorIDInput.getValue() || this.requestorIDInput.getValue().length <= 0) {
					this.requestorIDInput.setValueState("Error");
					dataIsValid = false;
				} else {
					this.requestorIDInput.setValueState("None");
				}

				// change the color of the tab depending on if it is
				// valid or not
				var tab = this.getView().byId("tabHeaderInfoFilter");
				if (dataIsValid) {
					tab.setIconColor("Default");
				} else {
					tab.setIconColor("Critical");
				}

				return dataIsValid;
			},
			tabItemSelected: function (oEvt) {
				var that = this;
				// when in detail mode the attachment tab is selected,
				// while not already selected -> download the
				// attachments
				var selectedTabItem = oEvt.getParameters().item;

				if (selectedTabItem.getId().indexOf("detailFilter") > -1) {
					sap.ui.cms.util.NCButtonsHandlers.activateCreate
						.apply(that, [that]);
				}

				if (selectedTabItem == this.getView().byId(
						"attachmentFilter")) {
					// C5204479-Do not copy attachments for copied CRF
					if (this.copyattachments == true) {
						if (mainModel && (!this.attachmentsData || !this.attachmentsData.length > 0)) {
							sap.ui.core.BusyIndicator.show();
							// mainModel.create();
							mainModel.read("/CRFRequestData_Set('" + objectID + "')/NavToAttach", null,
								null, true,
								this.onLoadAttachmentDataSuccess
								.bind(this),
								this.onLoadAttachmentDataFailure
								.bind(this));

						}
					} else {
						a = this.attachmentTabView.byId("attachmentTable");
						a.destroyItems();
					}
				}

			},
			onClickAttachment: function (oEvt) {},
			onLoadAttachmentDataSuccess: function (oData, response) {
				sap.ui.core.BusyIndicator.hide();
				util.Service.checkForSessionTimeout(response);
				this.attachmentsData = oData.results;
				var attachmentTable = this.attachmentTabView
					.byId("attachmentTable");
				for (var i in this.attachmentsData) {
					var attach = this.attachmentsData[i];

					var newItem = new sap.m.ColumnListItem();

					var name = new sap.m.Input({
						enabled: false
					});

					//
					var creator = new sap.m.Input({
						enabled: false
					});

					name.setValue(attach.Filename);
					creator.setValue(attach.CreatedBy);

					newItem.insertCell(creator).insertCell(name);

					newItem.data("mime", attach.MimeType);
					newItem.data("requestNumber", attach.RequestNumber);
					newItem.data("FileAttribute", attach.FileAttribute);
					newItem.data("createdBy", attach.CreatedBy);
					newItem.data("name", attach.Filename);

					attachmentTable.addItem(newItem);
				}

				var eventBus = sap.ui.getCore().getEventBus();
				eventBus
					.publish(
						sap.ui.cms.util.ServiceEvents.CHANEL,
						sap.ui.cms.util.ServiceEvents.EVENT_DISPLAY_LAST_NOTE, {});

			},
			onLoadAttachmentDataFailure: function (oData, response) {
				sap.ui.core.BusyIndicator.hide();
			},
			validateFields: function () {
				var dataIsValid = true;

				var contactTabIsValid = true;

				if (!this.validateContacts()) {
					contactTabIsValid = false;

				}
				if (!this.validateContractualParty()) {
					contactTabIsValid = false;
				}
				if (!this.validateSAPContacts()) {
					contactTabIsValid = false;
				}

				var selectedKeyTabBar = this.getView().byId("iconTabBar").getSelectedKey();
				if (selectedKeyTabBar === this.getView().byId("contactFilter").getKey()) {
					// check if there are invalid fields in the contact tab
					// and color the tab depending on it
					var tab = this.getView().byId("contactFilter");
					if (contactTabIsValid) {
						tab.setIconColor("Default");
					} else {
						tab.setIconColor("Critical");
						dataIsValid = false;
					}

					if (!this.validateHeaderArea()) {
						dataIsValid = false;
					}
				} else if (selectedKeyTabBar === this.getView().byId("detailFilter").getKey()) {
					var tab = this.getView().byId("detailFilter");
					if (this.actionModeSa !== 'SA' && this.actionModeSa !== "") { //C5204479-No vlaidation for save mode
						if (this.validateDetailsArea()) {
							tab.setIconColor("Default");
						} else {
							tab.setIconColor("Critical");
							dataIsValid = false;
						}
					}

					if (!this.validateHeaderArea()) {
						dataIsValid = false;
					}
				}
				return dataIsValid;
			},
			triggerActionModeRequest: function (oEvt) {
				// get actionmode id
				var id = oEvt.getSource().data("id");
				// get action mode text
				if (id == 'SA' || id == "") { //C5204479- No vlidation for save mode
					this.actionModeSa = 'SA';
				} else {
					this.actionModeSa = id;
				}

				var text = oEvt.getSource().getText();
				var that = this;
				var callback = function (oAction) {
					if (oAction === sap.m.MessageBox.Action.YES) {
						//C5288178 - Show busy indicator
						that.create(oEvt, id);
					}
				};
				sap.m.MessageBox.confirm(
					"Do you really want to excecute the action '" + text + "'?", {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: "Please confirm!",
						actions: [sap.m.MessageBox.Action.YES,
							sap.m.MessageBox.Action.NO
						],
						onClose: callback
					});
			},
			create: function (oEvt, actionMode) {
				
				if (this.validateFields()) {
					this.copyattachments = true;
					sap.ui.cms.copycrf = false;
					var requestBody = new Object();
					requestBody["RequestNumber"] = "";
					// add the action mode if it is provided and the
					// form is in editmode
					if (this.getView().getModel("view").getProperty(
							"/editMode") === true && actionMode && actionMode.length > 0) {
						requestBody["ActionMode"] = actionMode;
						requestBody["RequestNumber"] = objectID;
					}
					
					requestBody["RequestFormType"] = requestFormType;
					requestBody["SalesOrg"] = salesOrgID;
					requestBody["UpdatedDateTime"] = this.updateDateTime;
					requestBody["RequestUserID"] = this.requestorIDInput
						.getValue();
					requestBody["ProcessorID"] = this.procIdInput
						.getValue();
						/*Added by C5219274 for ITSDEO2C-16882*/
						var lastnotemsg = sap.ui.getCore().getModel("lastnotemsg");
					if (lastnotemsg != null){
					requestBody["Lastnote"] = lastnotemsg.getData().lastnotemsg;
					}
					else{
						requestBody["Lastnote"] = "";
					}
					/*End of change by C5219274*/
					requestBody["ProcessorType"] = this.procTypeInput
						.getSelectedKey();
					requestBody["Description"] = this.descriptionInput
						.getValue();
					requestBody["Note"] = this.defaultNotes.getValue();

					// get values out of contract table
					requestBody["NavToCP"] = this
						.getContractFieldValues();
					// get values out of contact table
					requestBody["NavToSC"] = this
						.getContactFieldValues();
					// get sap contact information
					var sapContactIDValues = this
						.getSAPContactIDValues();
					if (sapContactIDValues != null) {
						requestBody["NavToCO"] = this
							.getSAPContactIDValues();
					}
					// get values out of the detail section
					requestBody["NavToDetail"] = this
						.getDetailFieldValues();

					// the data is ready!
					// fire the request!
					if (mainModel && this._loading !== true) {
						sap.ui.core.BusyIndicator.show();

						// "Content-No-Attachment",
						// "Content-Last-Attachment",
						//by I305777
						this.actionMode = actionMode;
						// C5186104 7003481764, CRF Close action removal of actionMode === "CO" || 
						if (actionMode === "CL") {
							var attachmentCells = [];
						} else {
							// if (this.copyattachments == true) {
							var attachmentCells = this
								.getAttachmentTableCells();

						}

						if (attachmentCells.length <= 0) {

							mainModel.setHeaders({
								"Content-No-Attachment": true
							});
						} else {
							this.copyattachments = true;
							mainModel.setHeaders({
								"Content-No-Attachment": false
							});
						}
						// this.attachmentsData = [];
						this._loading = true;
						// this.attachments = [];
						// //c5234631 Email begin
						// var that = this;
						// var callback = function(oAction) {
						// 	if (oAction === sap.m.MessageBox.Action.YES) {
						// 		that.loadDisplayMode(requestBody.RequestNumber);
						// 	}
						// 	bind(this)
						// };
						// if (requestBody.ProcessorID.includes("@SAP.COM") && actionMode === "CF") {
						// 	sap.m.MessageBox.show(
						// 		"Please enter your user-ID instead of email-id", {
						// 			icon: sap.m.MessageBox.Icon.WARNING,
						// 			title: "Please confirm!",
						// 			actions: [sap.m.MessageBox.Action.YES],
						// 			onClose: callback
						// 		});
						// 	return
						// } else {
						//c5234631 email end
						var response = mainModel.create(
							"/CRFRequestData_Set", requestBody, {
								success: this.createRequestSuccess
									.bind(this),
								error: this.createRequestError
									.bind(this),
								async: true
							});

						mainModel.setHeaders(null);
					}

					// }

				} else {
					var bCompact = !!this.getView().$().closest(
						".sapUiSizeCompact").length;
					sap.m.MessageBox
						.show(
							"Not all mandatory fields have been filled!", {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Action not possible!",
								actions: [sap.m.MessageBox.Action.OK],
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							});

				}

			},
			// C5204479 -Create new CRF or copy request with data
			createNewRequest: function () {

				this.getRouter().navTo("homeRequestTypeLang", {
					type: requestFormType,
					language: "EN"
						//-C5204479-Remove Language Parameter
				});
			},
			// C5204479-Create New CRF
			copyNewRequest: function () {

				this.copyattachments = false;
				this.fillFields = false;
				var oIconTabBar = this.getView().byId("iconTabBar");
				var oEvent = new sap.ui.base.Event("customSelect", oIconTabBar, {
					"key": "headerInfoTabKey",
					"item": oIconTabBar.getItems()[0]
				});
				this.tabItemSelected(oEvent);
				oIconTabBar.setSelectedKey("headerInfoTabKey");

				// call backend to check if the user is allowed to go
				// into edit mode
				if (mainModel) {
					sap.ui.core.BusyIndicator.show();
					mainModel
						.read(
							"/CRFRequestData_Set/?$filter=RequestNumber%20eq%20%27" + objectID +
							"%27%20and%20ActionMode%20eq%20%27ED%27&$expand=NavToCP,NavToSC,NavToCO,NavToDetail",
							null, null, true,
							this.onLoadCopyDisplayDataSuccess
							.bind(this),
							this.onLoadDisplayDataFailure
							.bind(this));

				}
				// Start - Modification for ensuring that Attachments Tab Data is loaded when Edit is pressed - 08 / 06 / 2017
				// if (mainModel && (!this.attachmentsData || !this.attachmentsData.length > 0)) {
				// 	sap.ui.core.BusyIndicator.show();
				// 	mainModel.read("/CRFRequestData_Set('" + objectID + "')/NavToAttach", null,
				// 		null, true,
				// 		this.onLoadAttachmentDataSuccess
				// 		.bind(this),
				// 		this.onLoadAttachmentDataFailure
				// 		.bind(this));

				// }
				// End - Modification for ensuring that Attachments Tab Data is loaded when Edit is pressed - 08 / 06 / 2017

			},
			onLoadCopyDisplayDataSuccess: function (oData, response) {

				sap.ui.core.BusyIndicator.hide();
				util.Service.checkForSessionTimeout(response);
				if (oData.results)
					oData = oData.results[0];
				this.getView().getModel("view").setProperty(
					"/creationMode", true);
				this.getView().getModel("view").setProperty(
					"/displayMode", false);
				this.getView().getModel("view").setProperty(
					"/editMode", false);
				this.getView().getModel("view").setProperty(
					"/hasActions", false);
				this.getView().getModel("view").setProperty(
					"/possibleActions", "");
				//C5204479
				this.getView().getModel("view").setProperty(
					"/shownewcrf", false);
				//C5204479

				if (tracking)
					tracking.postEvent("Display item");
				this.getView().getModel("config").setProperty(
					"/showCPTab", !oData.HideCPTab);

				if (oData.HideCPTab && oData.HideCPTab === true) {
					this.getView().byId("iconTabBar").removeItem(
						this.getView().byId("cpSeparator"));
					this.getView().getModel("view").setProperty(
						"/showCPTab", false);
				}

				this.requestIDInput.setVisible(false);
				this.descriptionInput.setEditable(true);
				this.descriptionInput.setEnabled(true);
				this.processorNameInput.setValue("");
				this.processorNameInput.setVisible(false);
				this.processorNameInput.setEnabled(false);
				this.reqStatusInput.setValue("");
				this.reqStatusInput.setVisible(false);
				this.reqStatusInput.setEnabled(false);
				this.requestorIDInput.setEditable(true);
				this.requestorIDInput.setEnabled(true);
				this.getView().getModel("view").setProperty(
					"/showProcessor", false);
				this.getView().getModel("view").setProperty(
					"/showStatus", false);
				oData.RequestStatus = "";
				oData.RequestNumber = "";
				oData.ProcessorID = "";
				oData.ProcessorType = "";
				oData.CMSCaseID = "";
				/*oData.Lastnote = ""; /*C5219274*/
				
				/* I354682 - check for CMS case ID in Copy CRF */
				this.CMSCaseID.setText("");
				this.CMSCaseID.setEnabled(false);
				this.CMSCaseID.setVisible(false);
				/*	this.CMSCaseID.setValue(""); */
				this.enableContactArea(true);
				this.enableAttachmentArea(true);
				sap.ui.custom.control.conversation.Config.allowSubmit = true;
				var conversationInputField;
				if (this.getView().byId("headerInfoTabView")) {
					conversationInputField = this.getView().byId("headerInfoTabView").byId(
						"conversationControl_ID");
				} else {
					conversationInputField = this.getView().byId("conversationControl_ID");
				}

				this.fillFieldsWithData(oData);

				var eventBus = sap.ui.getCore().getEventBus();
				eventBus
					.publish(
						sap.ui.cms.util.ServiceEvents.CHANEL,
						sap.ui.cms.util.ServiceEvents.EVENT_DISPLAY_LAST_NOTE, {});

				sap.ui.cms.copycrf = true;
				if (sap.ui.cms.copycrf == true) {
					// sap.ui.cms.NotesGlobal.conversationInputField.setValue("");
					conversationInputField.setValue("");
					sap.ui.cms.NotesGlobal.notesModel.setData([]);
					sap.ui.cms.NotesGlobal.objectID = "";
				}

			},
			// C5204479 Create new CRF
			// C5204963
			draftRequest: function (oEvt, actionMode) {
				// if (this.validateFields()) {

				var requestBody = new Object();
				requestBody["RequestNumber"] = "";
				// add the action mode if it is provided and the
				// form is in editmode
				if (this.getView().getModel("view").getProperty(
						"/editMode") === true && actionMode && actionMode.length > 0) {
					requestBody["ActionMode"] = actionMode;
					requestBody["RequestNumber"] = objectID;
				}

				requestBody["RequestFormType"] = requestFormType;
				requestBody["SalesOrg"] = salesOrgID;
				requestBody["UpdatedDateTime"] = this.updateDateTime;

				requestBody["RequestUserID"] = this.requestorIDInput
					.getValue();
				requestBody["ProcessorID"] = this.procIdInput
					.getValue();
				requestBody["ProcessorType"] = this.procTypeInput
					.getSelectedKey();
				requestBody["Description"] = this.descriptionInput
					.getValue();
				requestBody["Note"] = this.defaultNotes.getValue();
				/*Added by C5219274 for ITSDEO2C-16882*/
				var lastnotemsg1 = sap.ui.getCore().getModel("lastnotemsg");
				if (lastnotemsg1 != null){
					requestBody["Lastnote"] = lastnotemsg1.getData().lastnotemsg;
					}
					else{
						requestBody["Lastnote"] = "";
					}
				// get values out of contract table
				// C5204963
				requestBody["ActionMode"] = "DR";
				// C5204963
				requestBody["NavToCP"] = this
					.getContractFieldValues();
				// get values out of contact table
				requestBody["NavToSC"] = this
					.getContactFieldValues();
				// get sap contact information
				var sapContactIDValues = this
					.getSAPContactIDValues();
				if (sapContactIDValues != null) {
					requestBody["NavToCO"] = this
						.getSAPContactIDValues();
				}
				// get values out of the detail section
				requestBody["NavToDetail"] = this
					.getDetailFieldValues();

				// the data is ready!
				// fire the request!
				if (mainModel && this._loading !== true) {
					sap.ui.core.BusyIndicator.show();

					// "Content-No-Attachment",
					// "Content-Last-Attachment",
					//by I305777
					this.actionMode = actionMode;
					if (actionMode === "CO" || actionMode === "CL") {
						var attachmentCells = [];
					} else {
						var attachmentCells = this
							.getAttachmentTableCells();
					}
					///

					/*var attachmentCells = this
					.getAttachmentTableCells();*/

					if (attachmentCells.length <= 0) {
						// add the header that no more attachments
						// are there
						// mainModel.oHeaders["Content-No-Attachment"]
						// = true;
						mainModel.setHeaders({
							"Content-No-Attachment": true
						});
					} else {
						mainModel.setHeaders({
							"Content-No-Attachment": false
						});
					}
					this._loading = true;

					var response = mainModel.create(
						"/CRFRequestData_Set", requestBody, {
							success: this.createRequestSuccess
								.bind(this),
							error: this.createRequestError
								.bind(this),
							async: true
						});

					mainModel.setHeaders(null);

				}

				// } else {
				// 	var bCompact = !!this.getView().$().closest(
				// 			".sapUiSizeCompact").length;
				// 	sap.m.MessageBox
				// 			.show(
				// 					"Not all mandatory fields have been filled!",
				// 					{
				// 						icon : sap.m.MessageBox.Icon.ERROR,
				// 						title : "Action not possible!",
				// 						actions : [ sap.m.MessageBox.Action.OK ],
				// 						styleClass : bCompact ? "sapUiSizeCompact"
				// 								: ""
				// 					});

				// }
			},
			// C5204963
			showErrorBox: function (title, text) {
				var bCompact = !!this.getView().$().closest(
					".sapUiSizeCompact").length;
				sap.m.MessageBox.show(text, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: title,
					actions: [sap.m.MessageBox.Action.OK],
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
			},
			showWarningBox: function (title, text) {
				var bCompact = !!this.getView().$().closest(
					".sapUiSizeCompact").length;
				sap.m.MessageBox.show(text, {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: title,
					actions: [sap.m.MessageBox.Action.OK],
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
			},
			hasAttachmentsToUpload: function () {
				return false;
			},
			getAttachmentTableCells: function () {
				var attachmentTable = this.attachmentTabView
					.byId("attachmentTable");

				return attachmentTable.getItems();
			},
			highlightTab: function (tabName) {
				// B/C/D/A for Basic/Contractual Party/Detail/Attachment
				this.getView().byId("tabHeaderInfoFilter")
					.setIconColor("Default");
				this.getView().byId("contactFilter").setIconColor(
					"Default");
				this.getView().byId("detailFilter").setIconColor(
					"Default");
				this.getView().byId("attachmentFilter").setIconColor(
					"Default");
				if (tabName && tabName.length > 0) {
					if (tabName == "B") {
						this.getView().byId("tabHeaderInfoFilter")
							.setIconColor("Critical");
					} else if (tabName == "C") {
						this.getView().byId("contactFilter")
							.setIconColor("Critical");
					} else if (tabName == "D") {
						this.getView().byId("detailFilter")
							.setIconColor("Critical");
					} else if (tabName == "A") {
						this.getView().byId("attachmentFilter")
							.setIconColor("Critical");
					}
				}
			},
			getAttachmentsToBeDeleted: function (currentAttachments) {
				var attachmentsToBeDeleted = [];
				for (var i in this.attachmentList) {
					var initAttachment = this.attachmentList[i];

					//by I305777
					var deleteAttachment = true;
					//var deleteAttachment = false;
					//

					for (var z in currentAttachments) {
						var currentAttachment = currentAttachments[z];
						var currentFileAttribute = currentAttachment
							.data("FileAttribute");
						if (currentFileAttribute == initAttachment.FileAttribute) {
							//Start of changes for 8003337334 by c5234631

							//byI305777
							deleteAttachment = false;
							//deleteAttachment = true;
							//

							//deleteAttachment = false;
							//End of changes for 8003337334 by c5234631

						}
						//by I305777
						/*else{
							deleteAttachment = false;
						}*/
					}
					//by I305777
					if (deleteAttachment === true && this.actionMode !== "CL" && this.actionMode !== "CO") {
						/*c5234631 Begin of changes*/

						//End of changes
						attachmentsToBeDeleted.push(initAttachment);
					}
					/*if (deleteAttachment === true) {
						attachmentsToBeDeleted.push(initAttachment);
					}*/
					///
				}

				return attachmentsToBeDeleted;
			},
			getAttachmentsToBeCreated: function (currentAttachments) {
				var attachmentsToBeCreated = [];
				for (var i in currentAttachments) {
					var currentAttachment = currentAttachments[i];
					var createAttachment = true;
					for (var z in this.attachmentList) {
						var initAttachment = this.attachmentList[z];
						var currentName = currentAttachment
							.data("name");
						if (currentName == initAttachment.Filename) {
							createAttachment = false;
						}
					}
					if (createAttachment === true) {
						attachmentsToBeCreated.push(currentAttachment);
					}
				}

				return attachmentsToBeCreated;
			},
			deleteAttachment: function (attachment, requestId) {
				if (mainModel) {
					sap.ui.core.BusyIndicator.show();

					var response = mainModel.remove(
						"/CRFRequestAttachment_Set(RequestNumber='" + requestId + "',Filename='" + attachment.Filename + "',CreatedBy='" + attachment.CreatedBy +
						"',FileAttribute='" + attachment.FileAttribute + "')", {
							success: this.deleteAttachmentSuccess
								.bind(this),
							error: this.deleteAttachmentError
								.bind(this),
							async: true
						});

				}
			},
			createRequestSuccess: function (oData, response) {
				var oController = this;
				sap.ui.core.BusyIndicator.hide();
				this._loading = false;
				util.Service.checkForSessionTimeout(response);
				if (tracking)
					tracking.postEvent("Create new item");
				if (oData) {
					var errorText = oData.ErrorText;
					if (oData.RequestNumber.length <= 0 || (errorText && errorText.length > 0)) {
						this._loading = false;
						this.highlightTab(oData.ErrorTab);
						this.showErrorBox("There was an error!",
							"Message: " + errorText);
					} else {
						// get id and check if there are attachments to
						// be uploaded
						var requestID = oData.RequestNumber;
						this.updateDateTime = oData.UpdatedDateTime;
						// objectID = requestID;
						this.objId = requestID;

						// submit notes
						sap.ui.cms.NotesGlobal.objectID = requestID;

						if (sap.ui.cms.NotesGlobal.objectID) {
							// submit notes if in edit
							var payload = sap.ui.cms.util.NotesProcessor
								.prepareNotesForSubmit();

							if (payload.NavToNotes.length > 0) {
								sap.ui.cms.util.NotesProcessor.submitNotes
									.apply(oController, [
										oController, payload
									]);
							}
						}

						//by I305777
						// C5186104 7003481764, CRF Close action removal of actionMode === "CO" ||
						if (this.actionMode === "CL") {
							var attachmentCells = [];
						} else {
							var attachmentCells = this
								.getAttachmentTableCells();
						}
						////

						/*var attachmentCells = this
								.getAttachmentTableCells();*/

						// check for deleted attachments
						// if
						// (this.getView().getModel("view").getProperty("/editMode")
						// === false) {
						var attachments = attachmentCells;
						this.attachmentsToBeUploaded = attachmentCells.length;
						if (this.getView().getModel("view")
							.getProperty("/editMode") === true || this.getView().getModel("view")
							.getProperty("/creationMode") === true) {
							attachments = this
								.getAttachmentsToBeCreated(attachmentCells);
							this.attachmentsToBeUploaded = attachments.length;

						}
						var attachmentsToRemove = this
							.getAttachmentsToBeDeleted(attachmentCells);
						this.attachmentsToBeRemoved = attachmentsToRemove.length;
						if (attachmentsToRemove.length > 0) {
							for (var z in attachmentsToRemove) {
								var att = attachmentsToRemove[z];
								this.deleteAttachment(att, requestID);
							}
						}

						if (this.attachmentsToBeUploaded <= 0 && this.attachmentsToBeRemoved <= 0) {
							if (oData.RequestStatus == "") { // Added by C5219274 for ITSDEO2C-15268
								sap.m.MessageToast
									.show("The contract has been successfully created with the ID: " + requestID);
							} else {
								sap.m.MessageToast
									.show("The contract has been successfully updated with the ID: " + requestID);
							} // End of change by C5219274 for ITSDEO2C-15268
							this.loadDisplayMode(requestID);
						} else {
							for (var i in attachments) {

								var cell = attachments[i];
								// var fileResult = cell
								// .data("fileResult");
								if (cell && cell.data && cell.data("fileURI") != null) {
									var fileResult = cell
										.data("fileURI");
									var b64 = cell.data("fileB64");
									// var fileResult =
									// atob(cell.data("fileB64"));
									var file = cell.data("file");
									// var encodedFile =
									// btoa(fileResult);

									// upload the attachment now!
									if (mainModel) {

										sap.ui.core.BusyIndicator
											.show();
										var requestBody = new Object();
										requestBody = b64;

										if (parseInt(i) + parseInt(1) === attachmentCells.length) {
											// this is the last
											// attachment
											// to be uploaded!
											mainModel
												.setHeaders({
													// "Slug":
													// file.name,
													"Slug": encodeURIComponent(file.name),
													"Content-Transfer-Encoding": "BASE64",
													"Content-Attachment-Encoding": "BASE64",
													"requestnumber": requestID,
													"Content-Last-Attachment": true
												});
										} else {
											mainModel
												.setHeaders({
													// "Slug":
													// file.name,
													"Slug": encodeURIComponent(file.name),
													"Content-Transfer-Encoding": "BASE64",
													"Content-Attachment-Encoding": "BASE64",
													"requestnumber": requestID,
													"Content-Last-Attachment": false
												});
										}

										requestBody["SalesOrg"] = salesOrgID;
										var response = mainModel
											.create(
												"/CRFRequestAttachment_Set",
												requestBody, {
													success: this.uploadAttachmentSuccess
														.bind(this),
													error: this.uploadAttachmentError
														.bind(this),
													async: true
												});

										mainModel.setHeaders(null);
									}
								}

							}
							// have this until the attachment sucdcess
							// function works

						}

					}
				}
				// C5204479-Create new CRF-Start
				var oIconTabBar = this.getView().byId("iconTabBar");
				var oEvent = new sap.ui.base.Event("customSelect", oIconTabBar, {
					"key": "headerInfoTabKey",
					"item": oIconTabBar.getItems()[0]
				});
				this.tabItemSelected(oEvent);
				oIconTabBar.setSelectedKey("headerInfoTabKey");
				this.createButton.setEnabled(false);
				this.createButton.setVisible(false);
				this.draftButton.setEnabled(false);
				this.draftButton.setVisible(false);
				// C5204479-Create new CRF-End
			},
			uploadAttachmentSuccess: function (oData, response) {
				sap.ui.core.BusyIndicator.hide();
				this._loading = false;
				util.Service.checkForSessionTimeout(response);
				var requestID = this.objId;
				this.attachmentsToBeUploaded = this.attachmentsToBeUploaded - 1;
				if (this.attachmentsToBeUploaded <= 0 && this.attachmentsToBeRemoved <= 0) {
					sap.m.MessageToast
						.show("The contract has been successfully created with the ID: " + requestID);
					this.loadDisplayMode(requestID);
				}
			},
			uploadAttachmentError: function (oData, response) {
				sap.ui.core.BusyIndicator.hide();
				this._loading = false;
				this.attachmentsToBeUploaded = this.attachmentsToBeUploaded - 1;
				if (this.attachmentsToBeUploaded <= 0 && this.attachmentsToBeRemoved <= 0) {
					sap.m.MessageToast
						.show("The contract has been successfully created with the ID: " + requestID);
					this.loadDisplayMode(requestID);
				}
			},
			deleteAttachmentSuccess: function (oData, response) {
				sap.ui.core.BusyIndicator.hide();
				this._loading = false;
				util.Service.checkForSessionTimeout(response);
				var requestID = this.objId;
				this.attachmentsToBeRemoved = this.attachmentsToBeRemoved - 1;
				if (this.attachmentsToBeUploaded <= 0 && this.attachmentsToBeRemoved <= 0) {
					sap.m.MessageToast
						.show("The contract has been successfully created with the ID: " + requestID);
					this.loadDisplayMode(requestID);
				}
			},
			deleteAttachmentError: function (oData, response) {
				sap.ui.core.BusyIndicator.hide();
				this._loading = false;
				this.attachmentsToBeRemoved = this.attachmentsToBeRemoved - 1;
				if (this.attachmentsToBeUploaded <= 0 && this.attachmentsToBeRemoved <= 0) {
					sap.m.MessageToast
						.show("The contract has been successfully created with the ID: " + requestID);
					this.loadDisplayMode(requestID);
				}
			},
			createRequestError: function (oData, response) {
				sap.ui.core.BusyIndicator.hide();
				this._loading = false;
				// show error message
				sap.m.MessageToast
					.show("There was an error during the creation!");
			},

			getControlReferences: function () {
				this.iconTabBar = this.getView().byId('iconTabBar');

				this.advanceToNextTabButton = this.getView().byId(
					'advanceToNextTabButton');
				sap.ui.cms.GlobalRegistry.advanceToNextTabButton = this.advanceToNextTabButton;

				this.headerInfoView = this.getView().byId(
					'headerInfoTabView');
				this.detailAreaView = this.getView().byId(
					'detailTabView');
				this.attachmentTabView = this.getView().byId(
					'attachmentTabView');
				this.descriptionInput = this.headerInfoView
					.byId('H_DESCRIPTION');
				this.requestorIDInput = this.headerInfoView
					.byId('REQUESTUSER_ID');
				this.requestorNameInput = this.headerInfoView
					.byId('REQUESTOR_FULLNAME');
				this.salesOrgInput = this.headerInfoView
					.byId('SALESORG_ID');
				//C5325212 Salesorg desp changes	
				this.salesOrgDescription =this.headerInfoView.byId(
				'SALESORG_DESCR');
				// C5186104 Default Notes
				this.defaultNotes = this.headerInfoView
					.byId("DEFAULT_ID");
					/*C5219274*/
		/*		var lastNote = this.headerInfoView  
					.byId("conversationControl_ID"); 
				this.lastNotemsg = lastNote.message;*/
				// C5186104 Default Notes
				// this.noteInput =
				// this.headerInfoView.byId('noteInput');
				this.conversationInput = this.headerInfoView
					.byId("conversationControl_ID");
				this.requestIDInput = this.headerInfoView
					.byId('requestIDInput');
				this.typeInput = this.headerInfoView
					.byId('REQUESTFORM_TYPE');
				this.requestIDInput = this.headerInfoView
					.byId("requestID");

				this.CMSCaseID = this.headerInfoView.byId("CMSCaseID");

				this.reqStatusInput = this.headerInfoView
					.byId("REQUEST_STATUS");

				this.procTypeInput = this.headerInfoView
					.byId("PROCESSOR_TYPE");

				this.procIdInput = this.headerInfoView
					.byId("PROCESSOR_ID");

				this.processorNameInput = this.headerInfoView
					.byId('processorName');

				this.adminInfo = this.headerInfoView.byId('adminInfo');
				// C5204963
				this.ChangedByText = this.headerInfoView.byId('ChangeByText'); //C5219274 for ITSDEO2C-15755
				this.draftButton = this.getView().byId('draftButton');
				sap.ui.cms.GlobalRegistry.draftButton = this.draftButton;
				// C5204963

				this.createButton = this.getView().byId('createButton');
				sap.ui.cms.GlobalRegistry.createButton = this.createButton;

				this.saveButton = this.getView().byId('saveButton');
				this.editButton = this.getView().byId('editButton');
				this.cancelEditButton = this.getView().byId(
					'cancelEditButton');

			},

			_openDialogSelectRequestForm: function () {
				sap.ui.cms.view.DialogSFRTHandler._openDialogSelectRequestForm
					.apply(this, [this]);
			},

			_dsrftSelectOnChange: function (evt) {
				sap.ui.cms.view.DialogSFRTHandler._dsrftSelectOnChange
					.apply(this, [this, evt]);
			},

			_drsftCheck: function () {
				sap.ui.cms.view.DialogSFRTHandler._drsftCheck.apply(
					this, [this]);
			},
			advanceToNextTab: function (event) {
				var that = this;
				if (this.validateFields()) {
					sap.ui.cms.util.NCButtonsHandlers.advanceToNextTab
						.apply(that, [that]);
				} else {
					var bCompact = !!this.getView().$().closest(
						".sapUiSizeCompact").length;
					sap.m.MessageBox
						.show(
							"Not all mandatory fields have been filled!", {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Action not possible!",
								actions: [sap.m.MessageBox.Action.OK],
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							});

				}
			},
			salesOrgInfoSuccess: function (oData, response) {

			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			var resultEntry = oData;
			if (resultEntry) {
				// this.salesOrgInput.setValueState("None");
				this.salesOrgInput.setValue(resultEntry.SALESORG_ID);
				this.salesOrgDescription
					.setValue(resultEntry.SALESORG_DESCR);
				salesOrgID = this.salesOrgInput.getValue();

				if (requestFormType) {
					this.activateTabs();
				}
			} else {
				this.salesOrgInput.setValueState("Error");
			}

			},
			salesOrgInfoError: function (oError) {
				sap.ui.core.BusyIndicator.hide();
				this.salesOrgInput.setValueState("Error");
			},
			activateTabs: function () {
				this.getView().byId("contactFilter").setEnabled(true);
				this.getView().byId("detailFilter").setEnabled(true);
				this.getView().byId("attachmentFilter").setEnabled(true);
				this.getView().byId("createButton").setEnabled(true);
				this.getView().byId("draftButton").setEnabled(true);

				if (!objectID) {
				//load CP Area content data
				this.bus.publish("service", "loadCPContent");
				//load detail area content
				this.bus.publish("service", "loadDetailContent");
				} 
			}

		});