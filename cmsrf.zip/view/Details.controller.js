jQuery.sap.require("sap.ui.cms.util.Service");
jQuery.sap.require("sap.ui.cms.util.Controller");
jQuery.sap.require("sap.ui.cms.util.ServiceEvents");
util.Controller.extend(
	"sap.ui.cms.view.Details", {

		onInit: function() {

			this.bus = this.getEventBus();
			this.bus.subscribe("service", "loadDetailContent",
				this.onLoadDetailContent, this);
			//get simple form control, to add items on it
			this.detailForm = this.getView().byId("detailForm");
		},

		onLoadDetailContent: function(channelId, eventId, data) {
			jQuery.sap.log.info(this.tag + ": onLoadDetailContent");
			this.detailValueData = data.data;
			if (mainModel && salesOrgID && requestFormType) {
				sap.ui.core.BusyIndicator.show();

				var languageParameter = "";

				if (language && language.length > 0) {
					languageParameter = "%20and%20Spras%20eq%20%27" + language + "%27";
				}

				var read = "/CRF_StructureSet/?$filter=RequestformType%20eq%20%27" + requestFormType + "%27and%20Vkorg%20eq%20%27" + salesOrgID + "%27" +
					languageParameter + "&$expand=NavToDrop";

				mainModel.read(read, null, null, true,
					this.loadContentSuccess.bind(this),
					this.loadContentError.bind(this));
			}

		},
		loadContentSuccess: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			var parentView = this.getView().getParent().getParent()
				.getParent().getParent().getParent();
			parentView.byId("detailFilter").setEnabled(true);

			this.buildContent(oData);

		},
		buildContent: function(oData) {
			this.detailForm.removeAllContent();
			var results = oData.results;
			if (results && results.length > 0) {
			
				for (var i in results) {

					var isMandatoryField = util.Service
						.stringToBoolean(results[i].Mandatory)
					var labelForControl = new sap.m.Label({
						text: results[i].FieldLabel,
						tooltip: results[i].FieldLabel,
						required: isMandatoryField
					});
					if (results[i].Htmltype.search("SEPARATOR") != -1) {
						//when the control is a spearator, there should be no text on the label
						labelForControl.setText("");
					}
					var control = util.Service
						.buildControlWithStringObject(results[i]);
					//c5325212 new changes 12/07/2021	
					if (((control instanceof sap.m.TextArea) || (control instanceof sap.m.Input)) && results[i].Fieldname === "CASE_ID") {
									control
										.setValue(CMSCASEIDValue);
								} 
					else if	 (((control instanceof sap.m.TextArea) || (control instanceof sap.m.Input)) && results[i].Fieldname === "CALLIDUS_QUOTE_ID") {
									control
										.setValue(CPQIDValue);
								} 
				//End C5325212				
					if (this.detailValueData && control) {
						for (var n in this.detailValueData) {
							var entry = this.detailValueData[n];
							var controlName = control
								.data("itemId");
							if (entry.FieldName == controlName) {
								if ((control instanceof sap.m.TextArea) || (control instanceof sap.m.Input)) {
									control
										.setValue(entry.FieldValue);
								} else if ((control instanceof sap.m.CheckBox)) {
									var isChecked = false;
									if (entry.FieldValue == "X" || entry.FieldValue == true) {
										isChecked = true;
									}
									control.setSelected(isChecked);
								} else if ((control instanceof sap.m.ComboBox)) {

									control
										.setSelectedKey(entry.FieldValue);
								} else if ((control instanceof sap.m.DateTimeInput)) {
									var date = null;
									//only create a date out of the response, when the response is not null
									if (entry.FieldValue && entry.FieldValue.length > 0) {
										date = util.Service
											.parseDate(entry.FieldValue);
									}
									control.setDateValue(date);

								} else if ((control instanceof sap.m.Select)) {

									var selectItem = new sap.ui.core.Item({
										key: entry.FieldValue,
										text: entry.FieldValue
									});
									control
										.setSelectedKey(entry.FieldValue);
								}
								// SAP.M.LINK IS BEEN IMPLEMENTED FOR LINK URL C5262631 SAPJIRA ITSDEO2C-15975
								else if ((control instanceof sap.m.Link)){
									control.setText(results[i].PopupContent);
									control.setTarget("_blank");
									control.setHref(results[i].PopupContent);
									control.setEnabled(true);
								}

							}
							//when the control is a text area, it needs to be set to not editable instead of not enabled to make sure the scroll bar can be used
							//only do this if we are not in the edit mode
							if (this.getView().getModel("view").getProperty("/editMode") === false) {
								
								if (control instanceof sap.m.TextArea) {
									control.setEditable(false);
								} 
								// SAP.M.LINK IS BEEN IMPLEMENTED FOR LINK URL C5262631 SAPJIRA ITSDEO2C-15975
								else if(control instanceof sap.m.Link){
									control.setEnabled(true);
								}else {
									if (!(control instanceof sap.m.Text) && !(control instanceof sap.m.Button)) {
										control.setEnabled(false);
									}
								}
							}

						}
					}

					//add the label and the control onto the form
					if (control) {
						//only add a label if it is declared and if the control to be added is not a button
						if (labelForControl && !(control instanceof sap.m.Button)) {
							this.detailForm.addContent(labelForControl);
						}
						this.detailForm.addContent(control);
						// SAP.M.LINK IS BEEN IMPLEMENTED FOR LINK URL C5262631 SAPJIRA ITSDEO2C-15975
						if (results[i].PopupContent && results[i].Htmltype !== "SAP.M.LINK") {
							var popupControl = new sap.m.Button({
								icon: "sap-icon://sys-help",
								press: util.Service.openHelpPopover,
								layoutData: new sap.ui.layout.GridData({
									span: "L1 M1 S1"
								})
							});
							popupControl.data("popContent", results[i].PopupContent);
							this.detailForm.addContent(popupControl);
						}
					}
				}
			}

			var eventBus = sap.ui.getCore().getEventBus();
			eventBus
					.publish(
							sap.ui.cms.util.ServiceEvents.CHANEL,
							sap.ui.cms.util.ServiceEvents.EVENT_DISPLAY_LAST_NOTE,
							{});
			
		},
		loadContentError: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();

		}


	});