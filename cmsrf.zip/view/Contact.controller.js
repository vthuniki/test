jQuery.sap.require("sap.ui.cms.util.Service");
jQuery.sap.require("sap.ui.cms.util.Controller");
jQuery.sap.require("sap.ui.cms.util.ServiceEvents");
util.Controller.extend(
	"sap.ui.cms.view.Contact", {

		onInit: function() {
			this.bus = this.getEventBus();
			this.bus.subscribe("service", "loadCPContent",
				this.onLoadCPContent, this);

			this.contactTable = this.getView().byId("contactTable");
			this.custContactTable = this.getView().byId("custContactTable");
			this.contractTable = this.getView().byId(
				"contractTable");

			this.contactIDField = this.getView().byId(
				"contactIDInput");
			this.contactFullNameField = this.getView().byId(
				"nameInput");
		},
		onLoadCPContent: function(channelId, eventId, data) {
			jQuery.sap.log.info(this.tag + ": onLoadCPContent");
			this.contactsData = data.contacts;
			this.contractsData = data.contractualParties;
			this.sapContactData = data.sapContacts;
			if (mainModel) {
				sap.ui.core.BusyIndicator.show();
				mainModel
					.read(
						"/GeneralFormCollection_Set/?$filter=Section%20eq%20%27CP%27%20&$expand=NavToLoad",
						null, null, true,
						this.loadContentSuccess.bind(this),
						this.loadContentError.bind(this));
			}

		},

		getContractIdInfo: function(id, type) {
			if (mainModel) {
				sap.ui.core.BusyIndicator.show();
				mainModel.read(
					"/ContractualPartyCollection_Set(ContractualPartyType='" + type + "',ContractualPartyID='" + id + "')", null, null, true,
					this.loadContractInfoSuccess.bind(this),
					this.loadContractInfoError.bind(this));
			}
		},
		loadContractInfoSuccess: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			if (this.affectedContractRow && oData) {
				if (oData.ErrorText && oData.ErrorText.length > 0) {
					//mark the contract input field as error
					sap.m.MessageBox.information(oData.ErrorText);
					this.affectedContractRow
						.getCells()[1].setValueState("Error");
				} else {
					var resultCompanyName = oData.CompanyName;
					var resultCountry = oData.Country;
					var resultCity = oData.City;
					// C5234631 & C5186104
					var resultState = oData.State;
					// C5234631 & C5186104

					this.affectedContractRow
						.getCells()[1].setValueState("None");

					
					var companyNameField = this.affectedContractRow
						.getCells()[2];
					companyNameField.setValue(resultCompanyName);
					var cityField = this.affectedContractRow.getCells()[3];
					cityField.setValue(resultCity);
					// C5234631 & C5186104
					var stateField = this.affectedContractRow.getCells()[4];
					stateField.setValue(resultState);
					// C5234631 & C5186104
					var countryField = this.affectedContractRow
						.getCells()[5];
					countryField.setValue(resultCountry);
				}
			}
			
			var eventBus = sap.ui.getCore().getEventBus();
			eventBus
					.publish(
							sap.ui.cms.util.ServiceEvents.CHANEL,
							sap.ui.cms.util.ServiceEvents.EVENT_DISPLAY_LAST_NOTE,
							{});
			
		},
		loadContractInfoError: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
		},
		fillContactTableWithData: function() {
			if (this.sapContactData) {
				//clear the table
				this.contactTable.removeAllItems();

				for (var i in this.sapContactData) {
					var entry = this.sapContactData[i];
					this.onAddContactRow(null, entry);
				}
			}
		},
		fillContractTableWithData: function() {
			if (this.contractsData) {
				//clear the table
				this.contractTable.removeAllItems();

				for (var i in this.contractsData) {
					var entry = this.contractsData[i];
					this.onAddContractRow(null, entry);
				}
			}
		},
		fillSAPContact: function() {
			if (this.contactsData) {
				//clear the table
				this.custContactTable.removeAllItems();

				for (var i in this.contactsData) {
					var entry = this.contactsData[i];
					this.onAddCustContactRow(null, entry);
				}
			}
		},
		loadContentSuccess: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			//split the customizing data into the contract table and the contact table+
			this.contractTableSchema = [];

			this.contactTableSchema = [];
			this.custContactTableSchema = [];
			if (oData && oData.results && oData.results.length > 0) {
				for (var i in oData.results) {
					var obj = oData.results[i];
					if (obj.Fieldname.search("CONTRACT") != -1) {
						this.contractTableSchema.push(obj);
					} else if (obj.Fieldname.search("SAPCONTACT") != -1) {
						this.contactTableSchema.push(obj);
					} else if (obj.Fieldname.search("CUSTOMER") != -1) {
						this.custContactTableSchema.push(obj);
					}
				}
			}
			this.fillContactTableWithData();
			this.fillContractTableWithData();
			this.fillSAPContact();
			
			var eventBus = sap.ui.getCore().getEventBus();
			eventBus
					.publish(
							sap.ui.cms.util.ServiceEvents.CHANEL,
							sap.ui.cms.util.ServiceEvents.EVENT_DISPLAY_LAST_NOTE,
							{});
		},
		loadContentError: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();

		},
		addContactLeadingZeros: function(value) {
			if (value.length < 10) {
				var test = "";
				for (var i = 0; i < (10 - value.length); i++) {
					test = test + "0";
				}
				value = test + value;
			}
			return value;
		},
		onRemoveContractRow: function(oEvt) {
			//get selected item, to remove it
			var item = this.contractTable.getSelectedItem();
			if (item) {
				this.contractTable.removeItem(item);
			}
		},
		custContactRemove: function(oEvt) {
			//get selected item, to remove it
			var item = this.custContactTable.getSelectedItem();
			if (item) {
				this.custContactTable.removeItem(item);
			}
		},
		triggerContractValueHelp: function(oEvt) {
			var searchHelpName = oEvt.getSource().getParent()
				.getCells()[0].getSelectedItem().data(
					"searchHelpName");

			util.Service.valueHelpRequestTriggered(oEvt,
				searchHelpName);
		},
		triggerCustContactValueHelp: function(oEvt) {
			var searchHelpName = oEvt.getSource().getParent()
				.getCells()[0].getSelectedItem().data(
					"searchHelpName");

			util.Service.valueHelpRequestTriggered(oEvt,
				searchHelpName);
		},
		triggerChangeOfContract: function(oEvt) {
			var src = oEvt.getSource();
			var selectedContractType = oEvt.getSource().getParent()
				.getCells()[0].getSelectedKey();
			var contractId = oEvt.getSource().getValue();
			if (contractId) {
				//make the entered string uppercase
				contractId = contractId.toUpperCase();
			}
			this.affectedContractRow = oEvt.getSource().getParent();
			this
				.getContractIdInfo(contractId,
					selectedContractType);
		},
		triggerChangeOfContractType: function(oEvt) {
			var idInput = oEvt.getSource().getParent().getCells()[1];
			idInput.setShowValueHelp(true);
		},
		triggerChangeOfCustContactType: function(oEvt) {
			var idInput = oEvt.getSource().getParent().getCells()[1];
			idInput.setShowValueHelp(true);
		},
		onAddCustContactRow: function(oEvt, entry) {
			//build new item out of the contract table template
			var newItem = new sap.m.ColumnListItem();
			var contactIDField = util.Service
				.buildTableControlWithStringObject(
					this.custContactTableSchema[1],
					this.triggerCustContactValueHelp.bind(this),
					this.changeContact.bind(this));
			contactIDField.setShowValueHelp(true);

			var typeField = util.Service
				.buildTableControlWithStringObject(
					this.custContactTableSchema[2], null,
					this.triggerChangeOfCustContactType
					.bind(this));

			var nameField = new sap.m.Input();

			nameField.setEnabled(false);
			var emailField = new sap.m.Input();

			emailField.setEnabled(false);

			if (entry) {
				nameField.setValue(entry.ContactName);
				emailField.setValue(entry.ContactEmail);
				contactIDField.setEnabled(false);
				contactIDField.setValue(entry.ContactID);

				typeField.setSelectedKey(entry.ContactType);
				typeField.setEnabled(false);
			}

			newItem.insertCell(emailField).insertCell(nameField)
				.insertCell(contactIDField).insertCell(typeField);
			this.custContactTable.addItem(newItem);
		},
		onAddContractRow: function(oEvt, entry) {
			//build new item out of the contract table template
			var newItem = new sap.m.ColumnListItem();
			var contractIDField = util.Service
				.buildTableControlWithStringObject(
					this.contractTableSchema[0],
					this.triggerContractValueHelp
					.bind(this),
					this.triggerChangeOfContract.bind(this));
			contractIDField.setShowValueHelp(true);

			var contractTypeField = util.Service
				.buildTableControlWithStringObject(
					this.contractTableSchema[1], null,
					this.triggerChangeOfContractType
					.bind(this));

			var cpNameField = new sap.m.Input({
				enabled: false
			});
			var cityField = new sap.m.Input({
				enabled: false
			});
			// C5234631
			var stateField = new sap.m.Input({
				enabled: false
			});
			// C5234631 & C5186104
			var countryField = new sap.m.Input({
				enabled: false
			});

			if (entry) {
				contractIDField.setValue(entry.ContractualPartyID);

				var selectItem = new sap.ui.core.Item({
					key: entry.ContractualPartyType,
					text: entry.ContractualPartyType
				});
				contractTypeField
					.setSelectedKey(entry.ContractualPartyType);

				contractIDField.setEnabled(false);
				contractTypeField.setEnabled(false);

				cpNameField.setValue(entry.CompanyName);
				cityField.setValue(entry.City);
				// C5234631 & C5186104
				stateField.setValue(entry.State);
				// C5234631 & C5186104
				countryField.setValue(entry.Country);
			}

			
			// newItem.insertCell(countryField).insertCell(cityField)
			// 	.insertCell(cpNameField).insertCell(
			// 		contractIDField).insertCell(
			// 		contractTypeField);
			// this.contractTable.addItem(newItem);
			// C5234631 & C5186104
			newItem.insertCell(countryField).insertCell(stateField).insertCell(cityField)
				.insertCell(cpNameField).insertCell(
					contractIDField).insertCell(
					contractTypeField);
			this.contractTable.addItem(newItem);
			// C5234631 & C5186104
		},

		onRemoveContactRow: function(oEvt) {
			//get selected item, to remove it
			var item = this.contactTable.getSelectedItem();
			if (item) {
				this.contactTable.removeItem(item);
			}
		},
		onRemoveCustContactRow: function(oEvt) {
			//get selected item, to remove it
			var item = this.custContactTable.getSelectedItem();
			if (item) {
				this.custContactTable.removeItem(item);
			}
		},

		onAddContactRow: function(oEvt, entry) {
			//build new item out of the contract table template
			var newItem = new sap.m.ColumnListItem();
			var contactIDField = util.Service
				.buildTableControlWithStringObject(
					this.contactTableSchema[0],
					this.triggerContactValueHelp.bind(this),
					this.triggerChangeOfContact.bind(this));
			contactIDField.setShowValueHelp(true);

			//add value help to the contact id field
			var contactTypeField = util.Service
				.buildTableControlWithStringObject(this.contactTableSchema[1]);

			var nameField = new sap.m.Input();

			nameField.setEnabled(false);
			
			/*Add Email field - C5288178*/
			var emailField = new sap.m.Input();
			emailField.setEnabled(false);

			if (entry) {
				nameField.setValue(entry.SAPContactName);
				emailField.setValue(entry.SAPContactEmail);   /*C5288178*/
				var selectItem = new sap.ui.core.Item({
					key: entry.SAPContactType,
					text: entry.SAPContactType
				});
				contactTypeField
					.setSelectedKey(entry.SAPContactType);
				contactTypeField.setEnabled(false);
				contactIDField.setEnabled(false);
				contactIDField.setValue(entry.SAPContactID);
			}

			newItem.insertCell(emailField)    /*C5288178*/
		     	.insertCell(nameField)
				.insertCell(contactIDField).insertCell(
					contactTypeField);
			this.contactTable.addItem(newItem);
		},
		triggerContactValueHelp: function(oEvt) {
			var control = oEvt.getSource();
			this.currentContactIdField = control;
			if (!this.userSearchDialog) {
				this.userSearchDialog = sap.ui.xmlfragment(
					"sap.ui.cms.view.UserSearchHelp", this);
				//make the dialog fullscreen when the device is a phone
				this.userSearchDialog
					.setStretch(jQuery.device.is.phone);
			}

			//get the form out of the dialog to add the key down event on each input
			var form = this.userSearchDialog.getContent()[0];
			util.Service.addEnterEventOnCustomDialog(form);

			//change title of dialog
			this.userSearchDialog.setTitle("Contact Search");
			// open value help dialog
			this.userSearchDialog.open();

		},

		onCloseUserSearch: function(oEvt) {
			if (this.userSearchDialog) {
				this.userSearchDialog.close();
			}
		},
		onSearchForUser: function(oEvt) {
			var dialog;
			if (!jQuery.device.is.phone) {
				dialog = oEvt.getSource().getParent();
			} else {
				dialog = oEvt.getSource().getParent();
			}
			var content = dialog.getContent()[0];
			var firstNameInput = content.getContent()[1];
			var lastNameInput = content.getContent()[3];
			var userIDInput = content.getContent()[5];

			var firstName = firstNameInput.getValue();
			var lastName = lastNameInput.getValue();
			var UserId = userIDInput.getValue();
			
			if (UserId) {
				UserId = UserId.toUpperCase();
			}
			var regexValidUser = /^[DCIdci]{1}[0-9]\d{5,10}$/;
			var validUser = regexValidUser.test(UserId);
			var filterString = "";

			if (firstName && firstName.length > 0) {
				filterString = filterString + "FirstName%20eq%20%27" + firstName + "%27";
			}

			if (lastName && lastName.length > 0) {
				if (filterString.length > 0) {
					filterString = filterString + "%20and%20";
				}
				filterString = filterString + "LastName%20eq%20%27" + lastName + "%27";
			}

			if (UserId && UserId.length > 0 && validUser) {
				if (filterString.length > 0) {
					filterString = filterString + "and%20";
				}
				filterString = filterString + "UserId%20eq%20%27" + UserId + "%27";
			}

			if (mainModel) {
				var sRead = "/SRCHHELP_USERSet/?$filter=" + filterString + "&top=100";
				sap.ui.core.BusyIndicator.show();
				mainModel.read(sRead, null, null, true,
					this.getUserListSuccess.bind(this),
					this.getUserListError.bind(this));
			}
		},
		getUserListSuccess: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			var model = new sap.ui.model.json.JSONModel();
			model.setData(oData.results);

			if (this.userSearchDialog) {
				this.userSearchDialog.setModel(model);
			}
		},
		getUserListError: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
		},
		userListItemSelected: function(oEvt) {
			var source = oEvt.getSource();
			var fullName = source.getProperty("title");
			var userId = source.getProperty("description");
			var Email = source.getProperty("info");   /*C5288178*/

			var userNameField = this.currentContactIdField
				.getParent().getCells()[2];
				
			var userEmail = this.currentContactIdField
				.getParent().getCells()[3];			/*C5288178*/	

			this.currentContactIdField.setValueState("None");
			this.currentContactIdField.setValue(userId);
			userNameField.setValue(fullName);
			userEmail.setValue(Email);     /*C5288178*/

			if (this.userSearchDialog) {
				this.userSearchDialog.close();
				this.userSearchDialog.destroy();
				this.userSearchDialog = null;
			}
		},
		triggerChangeOfContact: function(oEvt) {
			var control = oEvt.getSource();
			this.currentContactIdField = control;
			var id = oEvt.getSource().getValue();
			if (id) {
				//make the entered string uppercase
				id = id.toUpperCase();
			}
			//make request with the model
			if (mainModel) {
				sap.ui.core.BusyIndicator.show();
				var sRead = "/SRCHHELP_USERSet('" + id + "')";

				mainModel.read(sRead, null, null, true,
					this.userInfoSuccess.bind(this),
					this.userInfoError.bind(this));
			}
		},
		userInfoSuccess: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			var resultEntry = oData;
			var userNameField = this.currentContactIdField
				.getParent().getCells()[2];
			var userEmail = this.currentContactIdField
				.getParent().getCells()[3];			/*C5288178*/
				
			if (resultEntry) {
				this.currentContactIdField.setValueState("None");
				userNameField.setValue(resultEntry.FirstName + " " + resultEntry.LastName);
				userEmail.setValue(resultEntry.Email);     /*C5288178*/

			} else {
				this.currentContactIdField.setValueState("Error");
			}
		},
		openMessageBox: function(title, text) {
			sap.m.MessageBox.show(text, "sap-icon://alert", title, [sap.m.MessageBox.Action.OK]);
		},
		userInfoError: function(oError) {
			sap.ui.core.BusyIndicator.hide();
			this.currentContactIdField.setValueState("Error");
		},

		openContactSH: function(oEvt) {
			this.currentCustContactField = oEvt.getSource();
			if (!this.contactSH) {
				this.contactSH = sap.ui.xmlfragment(
					"sap.ui.cms.view.ContractSearchHelp", this);
				this.getView().addDependent(this.contactSH);
				//make the dialog fullscreen when the device is a phone
				this.contactSH.setStretch(jQuery.device.is.phone);
			}
			//get the form out of the dialog to add the key down event on each input
			var form = this.contactSH.getContent()[0];
			util.Service.addEnterEventOnCustomDialog(form);
			// open value help dialog
			this.contactSH.open();
		},
		openContactSearchHelp: function(oEvt) {
			var that = this;
			var inputField = oEvt.getSource();
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: inputField.getValue(),
				title: "Test",
				modal: true,
				supportMultiselect: false,
				supportRanges: false,
				supportRangesOnly: false,

				ok: function(oControlEvent) {
					that.aTokens = oEvt
						.getParameter("tokens");
					that.theTokenInput
						.setTokens(that.aTokens);

					oValueHelpDialog.close();
				},

				cancel: function(oControlEvent) {
					sap.m.MessageToast
						.show("Cancel pressed!");
					oValueHelpDialog.close();
				},

				afterClose: function() {
					oValueHelpDialog.destroy();
				}
			});

			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
					label: "Company Code",
					template: "CompanyCode"
							}, {
					label: "Company Name",
					template: "CompanyName"
							}, {
					label: "City",
					template: "City"
							}, {
					label: "Currency Code",
					template: "CurrencyCode"
							}]
			});
			oValueHelpDialog.setModel(oColModel, "columns");

			oValueHelpDialog
				.setFilterBar(new sap.ui.comp.filterbar.FilterBar({
					advancedMode: true,
					filterItems: [new sap.ui.comp.filterbar.FilterItem({
						name: "s1",
						control: new sap.m.Input()
					})],
					filterGroupItems: [
													new sap.ui.comp.filterbar.FilterGroupItem({
							groupTitle: "foo",
							groupName: "gn1",
							name: "n1",
							label: "Company Code",
							control: new sap.m.Input()
						}),
													new sap.ui.comp.filterbar.FilterGroupItem({
							groupTitle: "foo",
							groupName: "gn1",
							name: "n2",
							label: "Company Name",
							control: new sap.m.Input()
						}),
													new sap.ui.comp.filterbar.FilterGroupItem({
							groupTitle: "foo",
							groupName: "gn1",
							name: "n3",
							label: "Currency Code",
							control: new sap.m.Input()
						})],
					search: function(oEvt) {
						sap.m.MessageToast
							.show("Search pressed ");
					}
				}));

			oValueHelpDialog.open();

		},

		onCloseContractSearchHelp: function(oEvt) {
			if (this.contactSH) {
				this.contactSH.close();
			}
		},
		onSearchForContract: function(oEvt) {
			var dialog;
			if (!jQuery.device.is.phone) {
				dialog = oEvt.getSource().getParent();
			} else {
				dialog = oEvt.getSource().getParent();
			}
			var content = dialog.getContent()[0];
			var firstNameInput = content.getContent()[1];
			var lastNameInput = content.getContent()[3];
			var userIDInput = content.getContent()[5];
			var contactPersonInput = content.getContent()[7];

			var firstName = firstNameInput.getValue();
			var lastName = lastNameInput.getValue();
			var CustID = userIDInput.getValue();
			var contactPers = contactPersonInput.getValue();

			var filterString = "";

			if (firstName && firstName.length > 0) {
				filterString = filterString + "ContactFirstName%20eq%20%27" + firstName + "%27";
			}

			if (lastName && lastName.length > 0) {
				if (filterString.length > 0) {
					filterString = filterString + "and%20";
				}
				filterString = filterString + "ContactLastName%20eq%20%27" + lastName + "%27";
			}

			if (CustID && CustID.length > 0) {
				if (filterString.length > 0) {
					filterString = filterString + "and%20";
				}
				filterString = filterString + "CustomerID%20eq%20%27" + CustID + "%27";
			}
			if (contactPers && contactPers.length > 0) {
				if (filterString.length > 0) {
					filterString = filterString + "and%20";
				}
				filterString = filterString + "ContactPerson%20eq%20%27" + this.addContactLeadingZeros(contactPers) + "%27";
			}

			if (mainModel) {
				var sRead = "/ContactPartyCollection_Set/?$filter=" + filterString + "&top=100";
				sap.ui.core.BusyIndicator.show();
				mainModel.read(sRead, null, null, true,
					this.getContractListSuccess.bind(this),
					this.getContractListError.bind(this));
			}
		},
		getContractListSuccess: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			var model = new sap.ui.model.json.JSONModel();
			model.setData(oData.results);

			if (this.contactSH) {
				this.contactSH.setModel(model);
			}
		},
		getContractListError: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
		},
		contactItemSelected: function(oEvt) {
			var source = oEvt.getSource();

			this.currentCustContactField.setValueState("None");
			var contactPerson = source.data("contactPerson");

			this.currentCustContactField.setValue(contactPerson);
			this.currentCustContactField.data("type", source.data("type"));
			this.changeContact(null, contactPerson);

			if (this.contactSH) {
				this.contactSH.close();
				this.contactSH.destroy();
				this.contactSH = null;
			}
		},
		changeContact: function(oEvt, field) {
			this.currentCustContactField = oEvt.getSource();
			if (field) {
				this.currentCustContactField = field;
			}
			var value = this.currentCustContactField.getValue();
			value = this.addContactLeadingZeros(value);
			this.currentCustContactField.setValueState("None");
			this.currentCustContactField.setValue(value);
			//make request with the model
			if (mainModel) {
				sap.ui.core.BusyIndicator.show();
				var sRead = "/ContactPartyCollection_Set('" + value + "')";

				mainModel.read(sRead, null, null, true,
					this.changeContactSuccess.bind(this),
					this.changeContactError.bind(this));
			}
		},
		changeContactSuccess: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			var resultEntry = oData;
			if (resultEntry) {

				var userNameField = this.currentCustContactField
					.getParent().getCells()[2];
				var emailField = this.currentCustContactField
					.getParent().getCells()[3];
				var typeField = this.currentCustContactField
					.getParent().getCells()[0];

				this.currentCustContactField.setValueState("None");
				this.currentCustContactField.data("type",
					resultEntry.ContactFunction);
				userNameField
					.setValue(resultEntry.ContactFullName);
				emailField
					.setValue(resultEntry.ContactEmail);
			} else {
				this.currentCustContactField.setValueState("Error");
			}
		},
		openMessageBox: function(title, text) {
			sap.m.MessageBox.show(text, "sap-icon://alert", title, [sap.m.MessageBox.Action.OK]);
		},
		changeContactError: function(oError) {
			sap.ui.core.BusyIndicator.hide();
			this.currentCustContactField.setValueState("Error");
		}

	});