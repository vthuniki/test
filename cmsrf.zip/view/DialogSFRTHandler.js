jQuery.sap.require("sap.ui.cms.util.DSRFTRegionService");
jQuery.sap.require("sap.ui.cms.util.DSRFTCountryService");
jQuery.sap.require("sap.ui.cms.util.DSRFTSectionService");
jQuery.sap.require("sap.ui.cms.util.DSRFTTypeService");
jQuery.sap.require("sap.ui.cms.util.DSRFTLangService");

jQuery.sap.declare("sap.ui.cms.view.DialogSFRTHandler");

sap.ui.cms.view.DialogSFRTHandler = {}

sap.ui.cms.view.DialogSFRTHandler._drsftCheck = function(oController) {
	var that = oController;
	if (oController.routeArgs && $.isEmptyObject(oController.routeArgs)) {
		oController._openDialogSelectRequestForm();
		var dSRFT = oController.dialogSelectRequestFormType;
		dSRFT
				.getBeginButton()
				.attachPress(
						function(evt, oController) {
							

							// get the value for request from type and set the
							// value in the form	 						
							var type = sap.ui.cms.view.DialogSFRTHandler.selectType.getSelectedKey();														
							
//							var language = sap.ui.cms.view.DialogSFRTHandler.selectLang
//							.getItemByKey(sap.ui.cms.view.DialogSFRTHandler.selectLang
//									.getSelectedKey()).data("typeId");
							// C5204479-Remove Language Parameter-Start
							// var language = "EN";
							// C5204479-Remove Language Parameter-END
							var params={
									type:type,
								    language:"EN" //-Remove Language Parameter
							};
									
							that.getRouter().navTo("homeRequestTypeLang",params,true);
							
							dSRFT.close();
							dSRFT.destroy();
							dSRFT = null;
							
						});
		dSRFT.open();

	} else {
	}
}

sap.ui.cms.view.DialogSFRTHandler._openDialogSelectRequestForm = function(
		oController) {
	if (!oController.dialogSelectRequestFormType) {
		oController.dialogSelectRequestFormType = sap.ui.xmlfragment(
				"sap.ui.cms.view.DialogSRFT", oController);
		oController.getView().addDependent(
				oController.dialogSelectRequestFormType);
	}

	sap.ui.cms.util.DSRFTRegionService.loadRegions.apply(oController,
			[ oController ]);

}

sap.ui.cms.view.DialogSFRTHandler._dsrftSelectOnChange = function(oController,
		evt) {
	var emptyData = null;
	emptyModel = new sap.ui.model.json.JSONModel(emptyData);

	sap.ui.cms.view.DialogSFRTHandler.selectRegion = sap.ui.getCore().byId(
			"sapUICmsrfDSRFTRegion");
	sap.ui.cms.view.DialogSFRTHandler.selectCountry = sap.ui.getCore().byId(
			"sapUICmsrfDSRFTCountry");
	sap.ui.cms.view.DialogSFRTHandler.selectSection = sap.ui.getCore().byId(
			"sapUICmsrfDSRFTSection");
	sap.ui.cms.view.DialogSFRTHandler.selectType = sap.ui.getCore().byId(
			"sapUICmsrfDSRFTType");
			/*C5204479-Language Parameter Remove-Start*/
/*	sap.ui.cms.view.DialogSFRTHandler.selectLang = sap.ui.getCore().byId(
			"sapUICmsrfDSRFTLang");*/
			/*C5204479-Language Parameter Remove-End*/
	sap.ui.cms.view.DialogSFRTHandler.buttonDSRFT = sap.ui.getCore().byId(
			"DSRFTButtonOK");

	sap.ui.cms.view.DialogSFRTHandler._checkRegionChange.apply(oController, [
			oController, evt ]);
	sap.ui.cms.view.DialogSFRTHandler._checkCountryChange.apply(oController, [
			oController, evt ]);
	sap.ui.cms.view.DialogSFRTHandler._checkSectionChange.apply(oController, [
			oController, evt ]);
	sap.ui.cms.view.DialogSFRTHandler._checkTypeChange.apply(oController, [
			oController, evt ]);
			/*C5204479-Language Parameter Remove-Start*/
	// sap.ui.cms.view.DialogSFRTHandler._checkLangChange.apply(oController, [
	// 		oController, evt ]);
	/*C5204479-Language Parameter Remove-End*/

}

sap.ui.cms.view.DialogSFRTHandler._checkRegionChange = function(oController,
		evt) {
	if (evt.getSource().getId() === "sapUICmsrfDSRFTRegion") {
		if (evt.getSource().getSelectedKey() !== "RSEL01") {
			sap.ui.cms.view.DialogSFRTHandler.selectCountry.setEnabled(false);
			oController.getView().setModel(emptyModel, "countries");
			sap.ui.cms.view.DialogSFRTHandler.selectCountry
					.setSelectedItem(null);
			sap.ui.cms.view.DialogSFRTHandler.selectSection.setEnabled(false);
			oController.getView().setModel(emptyModel, "sections");
			sap.ui.cms.view.DialogSFRTHandler.selectSection
					.setSelectedItem(null);
			sap.ui.cms.view.DialogSFRTHandler.selectType.setEnabled(false);
			oController.getView().setModel(emptyModel, "types");
			sap.ui.cms.view.DialogSFRTHandler.selectType.setSelectedItem(null);
			// C5204479--Language Parameter remove-Start-
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setEnabled(false);
			// oController.getView().setModel(emptyModel, "languages");
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setSelectedItem(null);
			// C5204479--Language Parameter remove-End-
			sap.ui.cms.view.DialogSFRTHandler.buttonDSRFT.setEnabled(false);

			var requestSP = {};			
			requestSP.R = sap.ui.cms.view.DialogSFRTHandler.selectRegion.getSelectedKey();
						
			sap.ui.cms.util.DSRFTCountryService.loadCountries.apply(
					oController, [ oController,
							requestSP ]);

			sap.ui.cms.view.DialogSFRTHandler.selectCountry.setEnabled(true);
		} else {
			sap.ui.cms.view.DialogSFRTHandler.selectCountry.setEnabled(false);
			oController.getView().setModel(emptyModel, "countries");
			sap.ui.cms.view.DialogSFRTHandler.selectCountry
					.setSelectedItem(null);
			sap.ui.cms.view.DialogSFRTHandler.selectSection.setEnabled(false);
			oController.getView().setModel(emptyModel, "sections");
			sap.ui.cms.view.DialogSFRTHandler.selectSection
					.setSelectedItem(null);
			sap.ui.cms.view.DialogSFRTHandler.selectType.setEnabled(false);
			oController.getView().setModel(emptyModel, "types");
			sap.ui.cms.view.DialogSFRTHandler.selectType.setSelectedItem(null);
			// C5204479--Language Parameter remove-Start-
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setEnabled(false);
			// oController.getView().setModel(emptyModel, "languages");
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setSelectedItem(null);
			// C5204479--Language Parameter remove-End-
			sap.ui.cms.view.DialogSFRTHandler.buttonDSRFT.setEnabled(false);
		}
	}
}

sap.ui.cms.view.DialogSFRTHandler._checkCountryChange = function(oController,
		evt) {

	if (evt.getSource().getId() === "sapUICmsrfDSRFTCountry") {
		if (evt.getSource().getSelectedKey() !== "CSEL01") {
			sap.ui.cms.view.DialogSFRTHandler.selectSection.setEnabled(false);
			oController.getView().setModel(emptyModel, "sections");
			sap.ui.cms.view.DialogSFRTHandler.selectSection
					.setSelectedItem(null);
			sap.ui.cms.view.DialogSFRTHandler.selectType.setEnabled(false);
			oController.getView().setModel(emptyModel, "types");
			sap.ui.cms.view.DialogSFRTHandler.selectType.setSelectedItem(null);
			// C5204479--Language Parameter remove-Start-
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setEnabled(false);
			// oController.getView().setModel(emptyModel, "languages");
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setSelectedItem(null);
			// C5204479--Language Parameter remove-End
			sap.ui.cms.view.DialogSFRTHandler.buttonDSRFT.setEnabled(false);
			
			var requestSP = {};			
			requestSP.R = sap.ui.cms.view.DialogSFRTHandler.selectRegion.getSelectedKey();
			requestSP.C = sap.ui.cms.view.DialogSFRTHandler.selectCountry.getSelectedKey();
			
//			sap.ui.cms.util.DSRFTSectionService.loadSections.apply(oController,
//					[ oController, evt.getSource().getSelectedKey() ]);
			
			sap.ui.cms.util.DSRFTSectionService.loadSections.apply(oController,
					[ oController, requestSP ]);

			sap.ui.cms.view.DialogSFRTHandler.selectSection.setEnabled(true);
		} else {
			sap.ui.cms.view.DialogSFRTHandler.selectSection.setEnabled(false);
			oController.getView().setModel(emptyModel, "sections");
			sap.ui.cms.view.DialogSFRTHandler.selectSection
					.setSelectedItem(null);
			sap.ui.cms.view.DialogSFRTHandler.selectType.setEnabled(false);
			oController.getView().setModel(emptyModel, "types");
			sap.ui.cms.view.DialogSFRTHandler.selectType.setSelectedItem(null);
			// C5204479--Language Parameter remove-Start-
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setEnabled(false);
			// oController.getView().setModel(emptyModel, "languages");
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setSelectedItem(null);
			// C5204479--Language Parameter remove-End
			sap.ui.cms.view.DialogSFRTHandler.buttonDSRFT.setEnabled(false);
		}
	}
}

sap.ui.cms.view.DialogSFRTHandler._checkSectionChange = function(oController,
		evt) {
	if (evt.getSource().getId() === "sapUICmsrfDSRFTSection") {
		if (evt.getSource().getSelectedKey() !== "SSEL01") {

			sap.ui.cms.view.DialogSFRTHandler.selectType.setEnabled(false);
			oController.getView().setModel(emptyModel, "types");
			sap.ui.cms.view.DialogSFRTHandler.selectType.setSelectedItem(null);
			// C5204479--Language Parameter remove-Start-
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setEnabled(false);
			// oController.getView().setModel(emptyModel, "languages");
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setSelectedItem(null);
			// C5204479--Language Parameter remove-end-
			sap.ui.cms.view.DialogSFRTHandler.buttonDSRFT.setEnabled(false);

			var requestSP = {};			
			requestSP.R = sap.ui.cms.view.DialogSFRTHandler.selectRegion.getSelectedKey();
			requestSP.C = sap.ui.cms.view.DialogSFRTHandler.selectCountry.getSelectedKey();
			requestSP.S = sap.ui.cms.view.DialogSFRTHandler.selectSection.getSelectedKey();
			
			sap.ui.cms.util.DSRFTTypeService.loadTypes.apply(oController, [
					oController, requestSP ]);

			sap.ui.cms.view.DialogSFRTHandler.selectType.setEnabled(true);
		} else {
			sap.ui.cms.view.DialogSFRTHandler.selectType.setEnabled(false);
			oController.getView().setModel(emptyModel, "types");
			sap.ui.cms.view.DialogSFRTHandler.selectType.setSelectedItem(null);
			// C5204479--Language Parameter remove-Start-
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setEnabled(false);
			// oController.getView().setModel(emptyModel, "languages");
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setSelectedItem(null);
			// C5204479--Language Parameter remove-Start-
			sap.ui.cms.view.DialogSFRTHandler.buttonDSRFT.setEnabled(false);
		}
	}
}

sap.ui.cms.view.DialogSFRTHandler._checkTypeChange = function(oController, evt) {
	if (evt.getSource().getId() === "sapUICmsrfDSRFTType") {
		if (evt.getSource().getSelectedKey() !== "TSEL01") {
			// C5204479--Language Parameter remove-Start-
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setEnabled(false);
			// oController.getView().setModel(emptyModel, "languages");
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setSelectedItem(null);
			// C5204479--Language Parameter remove-End-
			sap.ui.cms.view.DialogSFRTHandler.buttonDSRFT.setEnabled(true);

			// var requestSP = {};			
			// requestSP.R = sap.ui.cms.view.DialogSFRTHandler.selectRegion.getSelectedKey();
			// requestSP.C = sap.ui.cms.view.DialogSFRTHandler.selectCountry.getSelectedKey();
			// requestSP.S = sap.ui.cms.view.DialogSFRTHandler.selectSection.getSelectedKey();
			// requestSP.T = sap.ui.cms.view.DialogSFRTHandler.selectType.getSelectedKey();
						
			// sap.ui.cms.util.DSRFTLangService.loadLanguages.apply(oController, [
			// 		oController, requestSP ]);

			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setEnabled(true);
		} else {
			// C5204479--Language Parameter remove-Start-
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setEnabled(false);
			// oController.getView().setModel(emptyModel, "languages");
			// sap.ui.cms.view.DialogSFRTHandler.selectLang.setSelectedItem(null);
			// C5204479--Language Parameter remove-End-
			sap.ui.cms.view.DialogSFRTHandler.buttonDSRFT.setEnabled(false);
		}
	}
}

sap.ui.cms.view.DialogSFRTHandler._checkLangChange = function(oController, evt) {
	if (evt.getSource().getId() === "sapUICmsrfDSRFTLang") {
		if (evt.getSource().getSelectedKey() !== "LSEL01") {
			sap.ui.cms.view.DialogSFRTHandler.buttonDSRFT.setEnabled(true);
		} else {
			sap.ui.cms.view.DialogSFRTHandler.buttonDSRFT.setEnabled(false);
		}
	}
}