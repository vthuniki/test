jQuery.sap.require("sap.ui.cms.util.Controller");
util.Controller.extend(
	"sap.ui.cms.view.Attachments", {

		onInit: function() {

			this.attachmentTable = this.getView().byId(
				"attachmentTable");
			this.files = [];
		},
		onAddAttachment: function(oEvt) {
			var up = this.getView().byId("fileUploader");

		},
		onFileDeleted: function(oEvent) {
			var oData = this.oView.getModel().getData();
			var aItems = oData.items;
			var sDocumentId = oEvent.getParameter("documentId");
			var bSetData = false;

			jQuery
				.each(
					aItems,
					function(index) {
						if (aItems[index] && aItems[index].documentId === sDocumentId) {
							aItems.splice(index, 1);
							bSetData = true;
						};
					});
			if (bSetData === true) {
				this.oView.getModel().setData(oData);
			};
		},

		onFileRenamed: function(oEvent) {
			var oData = this.oView.getModel().getData();
			var aItems = oData.items;
			var sDocumentId = oEvent.getParameter("documentId");
			var bSetData = false;

			jQuery
				.each(
					aItems,
					function(index) {
						if (aItems[index] && aItems[index].documentId === sDocumentId) {
							aItems[index].fileName = oEvent
								.getParameter("fileName");
						};
					});
			this.oView.getModel().setData(oData);
		},

		onUploadComplete: function(oEvent) {
			var fnCurrentDate = function() {
				var date = new Date();
				var day = date.getDate();
				var month = date.getMonth() + 1;
				var year = date.getFullYear();

				if (day < 10) {
					day = '0' + day
				};
				if (month < 10) {
					month = '0' + month
				}
				return year + '-' + month + '-' + day;
			};

			if (oEvent) {
				var oData = this.oView.getModel().getData();
				var oItem = {};
				var sUploadedFiles = oEvent.getParameters().oSource.mProperties.value;
				if (oEvent.getSource()._oFileUploader.getMultiple() && !(sap.ui.Device.browser.msie && sap.ui.Device.browser.version <= 9)) {
					sUploadedFiles = sUploadedFiles.substring(1,
						sUploadedFiles.length - 2);
				}
				var aUploadedFiles = sUploadedFiles.split(/\" "/);
				for (var i = 0; i < aUploadedFiles.length; i++) {
					oItem = {
						"contributor": "You",
						"documentId": oData.items[1].documentId,
						"fileName": aUploadedFiles[i],
						"fileSize": 10, // TODO get file size
						"mimeType": "",
						"thumbnailUrl": "",
						"uploadedDate": fnCurrentDate(),
						"url": "myUrl"
					};
					oData.items.unshift(oItem);
				};
				this.oView.getModel().setData(oData);
				sap.m.MessageToast.show("Upload successful");
			}
		},

		onLoadAttachmentDataSuccess: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			this.downloadAttachmentWithDataURL(response.body);

		},
		downloadAttachmentWithDataURL: function(dataURL) {
			var body = dataURL.replace(/"/g, "");
			var blob = this.dataURItoBlob(body, "octet-stream");
			var url = window.URL.createObjectURL(blob);
			var a = document.createElement('a');
			a.setAttribute("download",
				this.currentSelectedAttachmentName);
			a.setAttribute("href", body);
			//this is actually only supported currently by google chrome
			a.click();
			window.URL.revokeObjectURL(url);

			//needed for internet explorer support
			if ((window.Blob && window.navigator.msSaveOrOpenBlob)) {
				window.navigator.msSaveBlob(blob,
					this.currentSelectedAttachmentName);
			}

		},

		dataURItoBlob: function(dataURI, dataTYPE) {
			var binary = atob(dataURI.split(',')[1]),
				array = [];
			for (var i = 0; i < binary.length; i++)
				array.push(binary.charCodeAt(i));
			return new Blob([new Uint8Array(array)], {
				type: dataTYPE
			});
		},

		onLoadAttachmentDataFailure: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
		},

		onPress: function(oEvent) {
			jQuery.sap.require("sap.m.MessageToast");
			sap.m.MessageToast.show(oEvent.getSource().getId() + " Pressed");
		},

		onSelectChange: function(oEvent) {
			var oUploadCollection = sap.ui.getCore().byId(
				this.getView().getId() + "--UploadCollection");
			oUploadCollection.setShowSeparators(oEvent
				.getParameters().selectedItem
				.getProperty("key"));
		},
		handleFiles: function(e) {
			var reader = new FileReader();
			reader.onload = function(event) {

			};
			reader.readAsDataURL(e.target.files[0]);

		},
		onRemoveAttachment: function(oEvt) {
			//remove the selected attachment in the table
			var item = this.attachmentTable.getSelectedItem();
			if (item) {
//	Changes for ITD #8003040296 by  c5234631, Attachments in CRFs disappear 
				this.attachmentTable.removeItem(item);
				item.setVisible(false);
			} else {
				//no attachment has been selected
				sap.m.MessageBox.show("No attachment has been selected!", "sap-icon://alert", "Action not possible!", [sap.m.MessageBox.Action.OK]);
			}
		},
		onDownloadAttachment: function(oEvt) {
			var selItem = oEvt.getSource().getParent().getParent().getSelectedItem();

			if (selItem) {
				var item = selItem;
				var notUploadedYetAttachment = item
					.data("creationAttachment");
				//there is no onClick function for a table item -> only a selection change. This selection change can only occur once
				//							on the same item and therefore we need to deselect the selected item, to make sure that the next selection change could
				//							 be the same item
				//This should only happen when the attachment was already uploaded
				if (!notUploadedYetAttachment) {
					this.attachmentTable.setSelectedItem(item, false);
				}

				var mimeType = item.data("mime");
				var requestNumber = item.data("requestNumber");
				var fileAttribute = item.data("FileAttribute");
				var createdBy = item.data("createdBy");
				var name = item.data("name");
				this.currentSelectedAttachmentName = name;
				var notUploadedYetAttachment = item
					.data("creationAttachment");

				//only load the attachment, when the attachment in the list is not flagged as an attachment which has been created locally
				if (!notUploadedYetAttachment) {

                    //check for special characters
                    var name1 = item.data("name");
                    //name1 = '';
                    var regex = new RegExp(/[^A-Za-z0-9\-\_\.\s]/);
					var check = regex.test(name);  
                    if (check === true)
                    {
                        name1 = '';
                        var url = "/CRFRequestAttachment_Set(RequestNumber='" + requestNumber + "',Filename='" + name1 + "',CreatedBy='" + createdBy +
						"',FileAttribute='" + fileAttribute + "')/$value";
                    }
                    else{
                        var url = "/CRFRequestAttachment_Set(RequestNumber='" + requestNumber + "',Filename='" + name + "',CreatedBy='" + createdBy +
						"',FileAttribute='" + fileAttribute + "')/$value";
                    }
                    
                    //end check for special characters
                    
					//var url = "/CRFRequestAttachment_Set(RequestNumber='" + requestNumber + "',Filename='" + name + "',CreatedBy='" + createdBy +
					//	"',FileAttribute='" + fileAttribute + "')/$value";
					util.Service.downloadFile(url);
				} else {
					//in this case, we already have the data uri of the attachment and can download it directly!
					var uri = item.data("fileURI");
					this.downloadAttachmentWithDataURL(uri);
				}
			} else {
				//no attachment has been selected
				sap.m.MessageBox.show("No attachment has been selected!", "sap-icon://alert", "Action not possible!", [sap.m.MessageBox.Action.OK]);
			}
		},
		checkForExistingNameOfFile: function(nameOfFile) {
			var items = this.attachmentTable.getItems();
			for (var i in items) {
				var item = items[i];
				var fileNameOfItem = item.data("name");
				if (fileNameOfItem && fileNameOfItem == nameOfFile) {
					return true;
				}

			}
			return false;
		},
		fileSelected: function(oEvent) {
			var bCompact = !!this.getView().$().closest(
				".sapUiSizeCompact").length;

			var upload = oEvent.getSource();

			if (upload.oFileUpload.files.length > 0) {

				var file = upload.oFileUpload.files[0];

				//check if the name inclusive the extension is longer than 50 chars -> this will lead to an error in the backend
				if (file.name.length > 50) {
					sap.m.MessageBox
						.show(
							"The file name length exceeds the limit of 50 characters!", {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Action not possible!",
								actions: [sap.m.MessageBox.Action.OK],
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							});
					return;
				}
				
				//check if Filename has special characters other than - , _ , .
//				else{
//					    var regex = new RegExp(/[^A-Za-z0-9\-\_\.\s]/);
//					     var check = regex.test(file.name);  
//                        if (check === true)
//                        {  
//                            sap.m.MessageBox
//						.show(
//							"The file name cannot have special characters other than dot(.),underscore(_),dash(-) ", {
//								icon: sap.m.MessageBox.Icon.ERROR,
//								title: "Action not possible!",
//								actions: [sap.m.MessageBox.Action.OK],
//								styleClass: bCompact ? "sapUiSizeCompact" : ""
//							});
//							return;
//                        }
//				}
                
				//check if the file exceeds the maximum file size
				var fileSizeMB = (file.size / 1024) / 1024;
				if (fileSizeMB > maxAttachmentSize) {
					sap.m.MessageBox
						.show(
							"The file size exceeds the limit of " + maxAttachmentSize + " MB!", {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Action not possible!",
								actions: [sap.m.MessageBox.Action.OK],
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							});
					return;
				}
				//check if there is already a file with the same name!
				if (!this.checkForExistingNameOfFile(file.name)) {
					var reader = new FileReader(); //Lege neues Filereader-Objekt an

					// get data information
					reader.onload = (function(theFile,
						attachmentTable) {
						return function(e) {
							// Thumbnail erstellen
							var newItem = new sap.m.ColumnListItem();

							var name = new sap.m.Input({
								enabled: false
							});

							var creator = new sap.m.Input({
								enabled: false
							});

							if (theFile) {
								name.setValue(theFile.name);
								creator.setValue(currentUser);
							}

							newItem.insertCell(creator).insertCell(
								name);

							newItem.data("file", theFile);
							newItem.data("name", theFile.name);
							//get the base64 content out of the file result
							var b64 = e.target.result
								.split("base64,")[1];
							b64 = b64.replace(/"/g, "");

							var fileUri = "data:application/octet-stream;base64," + b64;
							newItem.data("fileURI", fileUri);
							newItem.data("fileB64", b64);
							newItem
								.data("creationAttachment",
									true);
							attachmentTable.addItem(newItem);
						};
					})(file, this.attachmentTable);

					reader.readAsDataURL(file);

				} else {
					//							there is already a file with the same name as the file which was selected!

					sap.m.MessageBox
						.show(
							"You have already added this file!", {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Action not possible!",
								actions: [sap.m.MessageBox.Action.OK],
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							});
				}
			}
		}

	});