jQuery.sap.declare("sap.ui.custom.control.list.CItem");

sap.ui.core.Item.extend("sap.ui.custom.control.list.CItem",{
		metadata:{
			properties:{
				description : {type : "string", group : "Misc", defaultValue : ""}
			}
		}
		
});