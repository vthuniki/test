jQuery.sap.declare("sap.ui.custom.control.conversation.ConversationI18N");
sap.ui.custom.control.conversation.ConversationI18N = {
		"language":new sap.ui.model.resource.ResourceModel({
            bundleUrl : [jQuery.sap.getModulePath("sap.ui.custom.control.conversation.i18n"), "messageBundle.properties"].join("/")
        })
};

/* usage:
 * sap.ui.custom.control.conversation.ConversationI18N.language
														.getResourceBundle()
														.getText(
																"CUSTOM_CONVERSATION_HELPBOX_DELETE_COMMENT_MESSAGEBOX_TITLE")
 */
 