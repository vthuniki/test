jQuery.sap.declare("sap.ui.custom.control.conversation.event.ConversationEvents");

sap.ui.custom.control.conversation.event.ConversationEvents = {};

sap.ui.custom.control.conversation.event.ConversationEvents.define = function(name, value) {
	Object.defineProperty(sap.ui.custom.control.conversation.event.ConversationEvents, name
			.toUpperCase(), {
		"value" : value,
		"writable" : false,
		"configurable" : false
	});
};


sap.ui.custom.control.conversation.event.ConversationEvents.define("CHANEL",
		"sap.ui.custom.control.conversation.chanel");

sap.ui.custom.control.conversation.event.ConversationEvents.define("EVENT_COMMENT_ROOT",
"eventCommentRoot");

sap.ui.custom.control.conversation.event.ConversationEvents.define("EVENT_COMMENT_REPLY",
"eventCommentReply");

sap.ui.custom.control.conversation.event.ConversationEvents.define("EVENT_COMMENT_DELETE",
"eventCommentDelete");

sap.ui.custom.control.conversation.event.ConversationEvents.define("EVENT_ENABLE_BEGIN_BUTTON",
"eventEnableBeginButton");

sap.ui.custom.control.conversation.event.ConversationEvents.define("EVENT_DISABLE_BEGIN_BUTTON",
"eventDisableBeginButton");