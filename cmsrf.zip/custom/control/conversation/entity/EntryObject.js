jQuery.sap.declare("sap.ui.custom.control.conversation.entity.EntryObject");
sap.ui.custom.control.conversation.entity.EntryObject = function(){
		var that=this;
//		this.Id = "";
		this.fk1 = "";
		this.fk2 = "";
		this.fk3 = "";
		this.firstName = "";
		this.lastName = "";
		this.userId = "";
		this.email = "";
		this.message = "";
		this.crTime = "";
		this.crDate = "";
		this.timestamp = "";
		this.noteParent = "";
		this.noteId = "";
		this.flag_New = false;
		this.isLast = false;
		
		this.getObjectToStore = function(){
			var obj = {};
			
			obj.FK1 = that.fk1;
			obj.FK2 = that.fk2;
			obj.FK3 = that.fk3;
			obj.firstName = that.firstName;
			obj.lastName = that.lastName;
			obj.Userid = that.userId;
			obj.userEmail = that.email;
			obj.Message = that.message;
			obj.CrTime = that.crTime;
			obj.CrDate = that.crDate;			
			obj.Parent = that.noteParent;
			obj.Id = that.noteId;
			obj.timestamp = that.timestamp;
			obj.flag_New = that.flag_New;
			return obj;
		};
};