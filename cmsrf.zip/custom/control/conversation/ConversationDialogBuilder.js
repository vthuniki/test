jQuery.sap.includeStyleSheet(jQuery.sap
		.getModulePath("sap.ui.custom.control.conversation.css")
		+ "/conversation.css");
jQuery.sap
		.require("sap.ui.custom.control.conversation.event.ConversationEvents");
jQuery.sap.require("sap.ui.custom.control.conversation.ConversationI18N");
jQuery.sap.require("sap.ui.custom.control.conversation.Config");

jQuery.sap
		.declare("sap.ui.custom.control.conversation.ConversationDialogBuilder");
sap.ui.custom.control.conversation.ConversationDialogBuilder = function(
		conversationExchangeObject) {

	var status = this._checkInitialization(conversationExchangeObject);
	if (status.code < 1) {
		throw status.message;
	}

	this.conversationExchangeObject = conversationExchangeObject;

	this.view = conversationExchangeObject.contextView;

	var oDialogNote = this._createDialog();

	oDialogNote.addContent(this._createConversation());
	if (sap.ui.custom.control.conversation.Config.allowSubmit === true) {
		oDialogNote.addContent(this._createCommentField());
	}

	this.eventBus = sap.ui.getCore().getEventBus();
// C5204479
	this.eventBus
			.subscribe(
					sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
					sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_DISABLE_BEGIN_BUTTON,
					this._disableBeginButton, this);
	this.eventBus
			.subscribe(
					sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
					sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_ENABLE_BEGIN_BUTTON,
					this._enableBeginButton, this);



	return oDialogNote;
};

/*
 * @returns {sap.m.Dialog}
 */
sap.ui.custom.control.conversation.ConversationDialogBuilder.prototype._createDialog = function() {
	var that = this;

	var beginButton = new sap.m.Button({
		text : sap.ui.custom.control.conversation.ConversationI18N.language
				.getResourceBundle().getText("CUSTOM_CONVERSATION_OK_BUTTON"),
		type : sap.m.ButtonType.Accept		
	});

	var oDialogNote = new sap.m.Dialog({
		contentWidth : sap.ui.Device.system.desktop ? "50%" : "85%",
		title : sap.ui.custom.control.conversation.ConversationI18N.language
				.getResourceBundle().getText("CUSTOM_CONVERSATION_TITLE"),
		endButton : new sap.m.Button({
			text : sap.ui.custom.control.conversation.ConversationI18N.language
					.getResourceBundle().getText(
							"CUSTOM_CONVERSATION_CANCEL_BUTTON"),
			type : sap.m.ButtonType.Reject

		}),
		beginButton : beginButton
	});
	beginButton.setEnabled(false);
	that.__beginButton = beginButton;

	oDialogNote.getConversationExchangeObject = function() {
		return that.conversationExchangeObject;
	};

	return oDialogNote;
};

/*
 * 
 * @returns {sap.ui.layout.Grid}
 */
sap.ui.custom.control.conversation.ConversationDialogBuilder.prototype._createCommentField = function() {
	// var that = this;

	// var oGridFormMain = new sap.ui.layout.Grid({
	// hSpacing : 1,
	// vSpacing : 1
	// });

	var oGridFormMain = new sap.ui.layout.VerticalLayout({
		width : "100%"
	});

	var oGridForm = new sap.ui.layout.Grid({
		hSpacing : 1,
		vSpacing : 1
	});

	var oButtonNewNote = new sap.m.Button({
		text : sap.ui.custom.control.conversation.ConversationI18N.language
				.getResourceBundle().getText("CUSTOM_CONVERSATION_NEW_BUTTON"),

		type : sap.m.ButtonType.Accept,
		layoutData : new sap.ui.layout.GridData({
			span : "L4 M4 S12"
		}),
		press : function() {
			this.setVisible(false);
			oGridForm.setVisible(true);
		}

	});

	var textAreaMaxLength = 200; //C5299813
	var textArea = new sap.m.TextArea({
		width : "100%",
		layoutData : new sap.ui.layout.GridData({
			span : "L8 M8 S12"
		})
	// maxLength : 1000
	});

	textArea.addStyleClass("sapUiCustomControlConversationTextArea");

	var divLeftChars = $("<div/>", {
		"id" : textArea.getId() + "_textarealeftchars",
		"data-textarealeftchars" : textArea.getId() + "_textarealeftchars",
		"class" : "sapUiCustomControlConversationCharsLeft"
	});

	oGridForm.addContent(textArea);

	textArea.onkeyup = function() {
		// var textLength = textArea.getValue().length;
		// var textRemaining = textArea.getMaxLength() - textLength;

		var elem = textArea;
		var maxlen = textAreaMaxLength;
		var value = elem.getValue();
		var len = value.replace(/\r\n/g, "~~").replace(/\n/g, "~~").length;
		if (len > maxlen) { // Truncation
			var lines = elem.getValue().split(/\r\n|\n/);
			value = "";
			var i = 0;
			while (value.length < maxlen && i < lines.length) {
				value += lines[i].substring(0, maxlen - value.length) + "\r\n";
				i++;
			}
			elem.setValue(value.substring(0, maxlen));
			len = maxlen;
		}

		var textRemaining = maxlen - len;

		divLeftChars.html(textRemaining
				+ " "
				+ sap.ui.custom.control.conversation.ConversationI18N.language
						.getResourceBundle().getText(
								"CUSTOM_CONVERSATION_CHARACTERS_REMAINING"));
	};

	textArea
			.addEventDelegate({
				onAfterRendering : function() {
					divLeftChars
							.html(textAreaMaxLength
									+ " "
									+ sap.ui.custom.control.conversation.ConversationI18N.language
											.getResourceBundle()
											.getText(
													"CUSTOM_CONVERSATION_CHARACTERS_REMAINING"));
					$(textArea.getDomRef()).append(divLeftChars);
				}
			});

	// var oTextField = new sap.ui.commons.TextField({
	// width:"100%",
	// layoutData : new sap.ui.layout.GridData({
	// span: "L8 M8 S12"
	// })
	// });

	var oButton = new sap.m.Button(
			{
				text : sap.ui.custom.control.conversation.ConversationI18N.language
						.getResourceBundle().getText(
								"CUSTOM_CONVERSATION_ADD_BUTTON"),
				width : "100%",
				type : sap.m.ButtonType.Accept,
				layoutData : new sap.ui.layout.GridData({
					span : "L4 M4 S12"
				}),
				press : function() {

					if (textArea.getValue() !== "") {

						var customData = {
							message : textArea.getValue()
						}; // anything you eventually want to pass
						var eventBus = sap.ui.getCore().getEventBus();
						textArea.setValue("");
						divLeftChars
								.html(textAreaMaxLength
										+ " "
										+ sap.ui.custom.control.conversation.ConversationI18N.language
												.getResourceBundle()
												.getText(
														"CUSTOM_CONVERSATION_CHARACTERS_REMAINING"));
						eventBus
								.publish(
										sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
										sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_COMMENT_ROOT,
										{
											customData : customData
										});

					} else {
						sap.m.MessageBox
								.alert(
										sap.ui.custom.control.conversation.ConversationI18N.language
												.getResourceBundle()
												.getText(
														"CUSTOM_CONVERSATION_INSERT_A_MESSAGE"),
										{
											title : sap.ui.custom.control.conversation.ConversationI18N.language
													.getResourceBundle()
													.getText(
															"CUSTOM_CONVERSATION_MESSAGEBOX_ALERT_TITLE"),
											onClose : null,
											styleClass : "",
											initialFocus : null,
											textDirection : sap.ui.core.TextDirection.Inherit,
											verticalScrolling : true,
											horizontalScrolling : true
										});
					}
				}
			});

	// oGridForm.addStyleClass("sapUiCustomControlConversationCommentField");

	// oGridForm.addContent(oTextField);
	oGridForm.addContent(oButton);

	oGridFormMain.addStyleClass("sapUiCustomControlConversationCommentField");

	if (this.conversationExchangeObject
			&& this.conversationExchangeObject.jsonModel
			&& this.conversationExchangeObject.jsonModel.getData()
			&& this.conversationExchangeObject.jsonModel.getData().length
			&& this.conversationExchangeObject.jsonModel.getData().length >= 1) {
		oGridForm.setVisible(false);
		oButtonNewNote.setVisible(true);
	} else {
		oGridForm.setVisible(true);
		oButtonNewNote.setVisible(false);
	}

	oGridFormMain.addContent(oButtonNewNote);
	oGridFormMain.addContent(oGridForm);

	return oGridFormMain;
};

sap.ui.custom.control.conversation.ConversationDialogBuilder.prototype._createConversation = function() {
	var that = this;
	// console.log("that.exchangeObject: ", that.conversationExchangeObject);
	jQuery.sap.require("sap.ui.custom.control.conversation.view.Conversation");
	var conversation = new sap.ui.custom.control.conversation.view.Conversation(
			{
				conversationExchangeObject : that.conversationExchangeObject
			});

	return conversation;
};

sap.ui.custom.control.conversation.ConversationDialogBuilder.prototype._checkInitialization = function(
		conversationExchangeObject) {
	var status = {
		code : 1,
		message : ""
	};
	if (!conversationExchangeObject) {
		status.code = -1;
		status.message = sap.ui.custom.control.conversation.ConversationI18N.language
				.getResourceBundle().getText(
						"CUSTOM_CONVERSATION_ERROR_NOT_PROPERLYINITIALIZED");
		return status;
	}
	if (!conversationExchangeObject.currentUser
			|| !conversationExchangeObject.currentUser.email
			|| conversationExchangeObject.currentUser.email === ""
			|| !conversationExchangeObject.currentUser.firstName
			|| conversationExchangeObject.currentUser.firstName === ""
			|| !conversationExchangeObject.currentUser.lastName
			|| conversationExchangeObject.currentUser.lastName === ""
			|| !conversationExchangeObject.currentUser.userId
			|| conversationExchangeObject.currentUser.userId === ""
			|| !conversationExchangeObject.currentUser.fullName
			|| conversationExchangeObject.currentUser.fullName === "") {
		status.code = -1;
		status.message = sap.ui.custom.control.conversation.ConversationI18N.language
				.getResourceBundle()
				.getText(
						"CUSTOM_CONVERSATION_ERROR_NOT_PROPERLYINITIALIZED_USER_MISSING_DATA");
		return status;
	}
	return status;
};

sap.ui.custom.control.conversation.ConversationDialogBuilder.prototype._enableBeginButton = function(
		event) {	
	this.__beginButton.setEnabled(true);
}

sap.ui.custom.control.conversation.ConversationDialogBuilder.prototype._disableBeginButton = function(
		event) {	
	this.__beginButton.setEnabled(false);
}
