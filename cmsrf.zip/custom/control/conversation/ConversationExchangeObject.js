jQuery.sap.declare("sap.ui.custom.control.conversation.ConversationExchangeObject");
sap.ui.custom.control.conversation.ConversationExchangeObject = function(){
	this.currentUser = null;
	this.fk1=null;
	this.fk2=null;
	this.fk3=null;
	this.lastNote={
			user: null,
			timestamp: null,
			message: null 
	};
	this.newNotes=[];
	this.jsonModel=null;
	
	this.contextController=null;
	this.contextView=null;
	this.contextInputFieldHoldingLastMessage=null;
};