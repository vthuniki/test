jQuery.sap.require("sap.ui.custom.control.conversation.util.DateTool");

jQuery.sap.declare("sap.ui.custom.control.conversation.util.ModelProcessor");
sap.ui.custom.control.conversation.util.ModelProcessor = function(jsonModel) {
	
	var data = jsonModel.getData();

	var groupedByResult=null;
	
	function groupBy(orig){
		 var newArr = [],
	        types = {},
	        i, j, cur;
		if(orig && orig.length > 0){ 
			for (i = 0, j = orig.length; i < j; i++) {
				cur = orig[i];
				if (!(cur.Parent in types)) {
					types[cur.Parent] = {Parent: cur.Parent, notes: []};
					newArr.push(types[cur.Parent]);
				}
				types[cur.Parent].notes.push(cur);
			}
		}
	    return newArr;
	}

	
	function parseJsonDate(jsonDate) {
    	var offset = new Date().getTimezoneOffset();
    	var parts = /\/Date\((-?\d+)([+-]\d{2})?(\d{2})?.*/.exec(jsonDate);

    	if (parts[2] === undefined){
    	    parts[2] = 0;
    	}

    	if (parts[3] === undefined){
    	    parts[3] = 0;
    	}

    	return new Date(+parts[1] + offset + parts[2] * 3600000 + parts[3] * 60000);
    }
			
	return {
		groupBy : function(){
			groupedByResult=groupBy(data);
			return groupedByResult;
		},
		
		orderBy : function(){
			var datetool = new sap.ui.custom.control.conversation.util.DateTool();
			
			for (var i in groupedByResult){
				var cur = groupedByResult[i];
				
				cur.notes.sort(function(x,y){			
					return datetool.createDateFromStrings(x.CrTime, x.CrDate)-datetool.createDateFromStrings(y.CrTime, y.CrDate);
				});
			}
			return groupedByResult;
		}
	};
};

