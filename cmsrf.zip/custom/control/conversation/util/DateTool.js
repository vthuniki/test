jQuery.sap.declare("sap.ui.custom.control.conversation.util.DateTool");
sap.ui.custom.control.conversation.util.DateTool = function() {

	function padStr(i) {
		return (i < 10) ? "0" + i : "" + i;
	}

	return {
		parseJsonDate : function(jsonDate) {
			var offset = new Date().getTimezoneOffset();
			var parts = /\/Date\((-?\d+)([+-]\d{2})?(\d{2})?.*/.exec(jsonDate);

			if (!parts[2]) {
				parts[2] = 0;
			}

			if (!parts[3]) {
				parts[3] = 0;
			}

			return new Date(+parts[1] + offset + parts[2] * 3600000 + parts[3]
					* 60000);
		},

		createDateFromStrings : function(time, date) {

			var hh = parseInt(time.substring(0, 2), 10);
			var mm = parseInt(time.substring(2, 4), 10);
			var ss = parseInt(time.substring(4, 6), 10);

			var year = parseInt(date.substring(0, 4), 10);
			var month = parseInt(date.substring(4, 6), 10);
			var day = parseInt(date.substring(6, 8), 10);

			var computedDate = new Date(year, month - 1, day, hh, mm, ss);

			return computedDate;
		},

		getTimeFromDate : function(date) {
			var timeStr = padStr(date.getHours()) + padStr(date.getMinutes())
					+ padStr(date.getSeconds());
			return timeStr;
		},

		getDateFromDate : function(date) {
			var dateStr = padStr(date.getFullYear())
					+ padStr(1 + date.getMonth()) + padStr(date.getDate());
			return dateStr;
		}
	};
};