jQuery.sap
		.require("sap.ui.custom.control.conversation.event.ConversationEvents");
jQuery.sap.require("sap.ui.custom.control.conversation.ConversationI18N");
jQuery.sap.require("sap.ui.custom.control.conversation.Config");
jQuery.sap.require("sap.ui.custom.control.conversation.util.DateTool");

sap.ui.core.Control
		.extend(
				"sap.ui.custom.control.conversation.view.ConversationEntryControl",
				{

					_commentGrid : null,

					metadata : {
						properties : {
							"fk1" : {
								type : "string"
							},
							"fk2" : {
								type : "string"
							},
							"fk3" : {
								type : "string"
							},
							"message" : {
								type : "string"
							},
							"crTime" : {
								type : "string"
							},
							"crDate" : {
								type : "string"
							},
							"timestamp" : {
								type : "string"
							},
							"firstName" : {
								type : "string"
							},
							"lastName" : {
								type : "string"
							},
							"userId" : {
								type : "string"
							},
							"email" : {
								type : "string"
							},
							"noteId" : {
								type : "string"
							},
							"noteParent" : {
								type : "string"
							},
							"flag_New" : {
								type : "boolean",
								defaultValue : false
							},
							"isLast" : {
								type : "boolean",
								defaultValue : false
							},							
							"padding" : {
								type : "int"
							}
						}
					},

					init : function() {
						var oControl = this;
						oControl._commentGrid = oControl._createCommentField();
						oControl._commentGrid
								.removeStyleClass("sapUiCustomControlConversationNoteCommentGridVisible");
						oControl._commentGrid
								.addStyleClass("sapUiCustomControlConversationNoteCommentGridNotVisible");
					},

					renderer : function(oRm, oControl) {

						function parseJsonDate(jsonDate) {
							var offset = new Date().getTimezoneOffset();
							var parts = /\/Date\((-?\d+)([+-]\d{2})?(\d{2})?.*/
									.exec(jsonDate);

							if (parts[2] === undefined)
								parts[2] = 0;

							if (parts[3] === undefined)
								parts[3] = 0;

							return new Date(+parts[1] + offset + parts[2]
									* 3600000 + parts[3] * 60000);
						}

						oRm.write('<div id="parentContainer_');
						oRm.writeEscaped(oControl.getNoteId()); 
						oRm.write('" ');

						oRm
								.write('data-noteid="');
						oRm.writeEscaped(oControl.getNoteId());
						oRm.write('" ');
						oRm.write('data-parentcontainerid="');
						oRm.writeEscaped(oControl.getNoteId());
						oRm.write('" ');

						oRm.write(">");

						oRm.write("<div");
						oRm.writeControlData(oControl);
						if (oControl.getFlag_New()) {
							oRm
									.addClass("sapUiCustomControlConversationEntryNew");
						} else {
							oRm.addClass("sapUiCustomControlConversationEntry");
						}

						oRm.writeClasses();
						oRm.addStyle("margin-left", oControl.getPadding()
								+ "%;");
						oRm.writeStyles();

						oRm.write(">");

						oRm
								.write("<div class='sapUiCustomControlConversationEntryUser'>");
						oRm.writeEscaped(oControl.getFirstName());
						oRm.write(" ");
						oRm.writeEscaped(oControl.getLastName());
						oRm.write(" - ");
						oRm.writeEscaped(oControl.getUserId());
						oRm.write("</div>");
						oRm
								.write("<div class='sapUiCustomControlConversationEntryMessage'>");
						oRm.writeEscaped(oControl.getMessage());
//						oRm.writeEscaped(oControl.getMessage().replace(/\n/g, "<br />"));
						oRm.write("</div>");
						oRm
								.write("<div class='sapUiCustomControlConversationEntryDate'>");

						var datetool = new sap.ui.custom.control.conversation.util.DateTool();
						oRm.writeEscaped(datetool.createDateFromStrings(
								oControl.getCrTime(), oControl.getCrDate())
								.toLocaleString());

						var reply = new sap.ui.core.Icon(
								{
									src : sap.ui.core.IconPool
											.getIconURI('discussion'),
									size : "14px",
									width : "14px",
									color : "#FF9900",
									press : function() {
										oControl._commentGrid
												.removeStyleClass("sapUiCustomControlConversationNoteCommentGridNotVisible");
										oControl._commentGrid
												.addStyleClass("sapUiCustomControlConversationNoteCommentGridVisible");
									}

								});

						reply
								.addStyleClass("sapUiCustomControlConversationActionIcon");
						
						if(oControl.getIsLast()===true && !oControl.getFlag_New()){
							oControl._commentGrid
							.removeStyleClass("sapUiCustomControlConversationNoteCommentGridNotVisible");
							oControl._commentGrid
							.addStyleClass("sapUiCustomControlConversationNoteCommentGridVisible");
						}
						

						var ttext = new sap.m.Text();
						ttext
								.setText(sap.ui.custom.control.conversation.ConversationI18N.language
										.getResourceBundle()
										.getText(
												"CUSTOM_CONVERSATION_HELPBOX_DISPLAY_COMMENT_FORM"));

						var oCallout = new sap.ui.commons.Callout({
							content : ttext
						});

						reply.setTooltip(oCallout);

						var email = new sap.ui.core.Icon({
							src : sap.ui.core.IconPool.getIconURI("email"),
							size : "14px",
							width : "14px",
							color : "#FF9900",
							press : function() {
								document.location.href = "mailto:"
										+ oControl.getEmail()
										+ "?subject=Reply to "
										+ oControl.getMessage();
							}
						});

						var sHtml = sap.ui.custom.control.conversation.ConversationI18N.language
								.getResourceBundle()
								.getText(
										"CUSTOM_CONVERSATION_HELPBOX_REPLY_TO_PART1")
								+ "<br/>";
						sHtml += "<ul>";
						sHtml += "<li> "
								+ sap.ui.custom.control.conversation.ConversationI18N.language
										.getResourceBundle()
										.getText(
												"CUSTOM_CONVERSATION_HELPBOX_REPLY_TO_PART2")
								+ " " + oControl.getEmail() + "</li>";
						sHtml += "<li> "
								+ sap.ui.custom.control.conversation.ConversationI18N.language
										.getResourceBundle()
										.getText(
												"CUSTOM_CONVERSATION_HELPBOX_REPLY_TO_PART3")
								+ " " + oControl.getMessage() + "</li>";

						sHtml += "</ul>";

						var sValueState = sap.ui.custom.control.conversation.ConversationI18N.language
								.getResourceBundle().getText(
										"CUSTOM_CONVERSATION_HELPBOX_REPLY_TO");

						var oRttTextField = new sap.ui.commons.RichTooltip(
								{
									text : sHtml,
									valueStateText : sValueState,
									imageSrc : jQuery.sap
											.getModulePath("sap.ui.custom.control.conversation.img")
											+ "/ValueState_Info.png"
								});

						email.setTooltip(oRttTextField);

						email
								.addStyleClass("sapUiCustomControlConversationActionIcon");

						var deleteTooltipText = new sap.m.Text();
						deleteTooltipText
								.setText(sap.ui.custom.control.conversation.ConversationI18N.language
										.getResourceBundle()
										.getText(
												"CUSTOM_CONVERSATION_HELPBOX_DELETE"));

						var oCalloutDelete = new sap.ui.commons.Callout({
							content : deleteTooltipText
						});

						var deleteEntry = new sap.ui.core.Icon(
								{
									src : sap.ui.core.IconPool
											.getIconURI('delete'),
									size : "14px",
									color : "#FF9900",
									press : function(event) {

										function fnCallbackConfirm(confirmation) {
//											if (confirmation) {
												var eventBus = sap.ui.getCore()
														.getEventBus();
												eventBus
														.publish(
																sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
																sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_COMMENT_DELETE,
																{
																	noteId : oControl
																			.getNoteId()
																});
//											} else {
//											}
										}

										fnCallbackConfirm();
//										sap.ui.commons.MessageBox
//												.confirm(
//														sap.ui.custom.control.conversation.ConversationI18N.language
//																.getResourceBundle()
//																.getText(
//																		"CUSTOM_CONVERSATION_HELPBOX_DELETE_COMMENT_MESSAGEBOX_MESSAGE"),
//														fnCallbackConfirm,
//														sap.ui.custom.control.conversation.ConversationI18N.language
//																.getResourceBundle()
//																.getText(
//																		"CUSTOM_CONVERSATION_HELPBOX_DELETE_COMMENT_MESSAGEBOX_TITLE"));

									}
								});

						deleteEntry.setTooltip(oCalloutDelete);
						deleteEntry
								.addStyleClass("sapUiCustomControlConversationActionIcon");

						if (sap.ui.custom.control.conversation.Config.allowSubmit === true) {
							if(!oControl.getFlag_New()){
							oRm.renderControl(reply);
							oRm.renderControl(email);
							}
							if (oControl.getFlag_New()) {
								oRm.renderControl(deleteEntry);
							}

							oRm.renderControl(oControl._commentGrid);
						}
						oRm.write("</div>");

						oRm.write("</div>");
						oRm.write("</div>");

					},

					_createCommentField : function() {
						var oControl = this;

						var oGridForm = new sap.ui.layout.Grid({
							hSpacing : 1,
							vSpacing : 1
						});

						var textAreaMaxLength = 1000;
						var textArea = new sap.m.TextArea({							
							width : "100%",
							layoutData : new sap.ui.layout.GridData({
								span : "L8 M8 S12"
							})
//							maxLength : 1000
						});

						textArea
								.addStyleClass("sapUiCustomControlConversationTextArea");

						var divLeftChars = $("<div/>", {
							"id" : textArea.getId() + "_textarealeftchars",
							"data-textarealeftchars" : textArea.getId()
									+ "_textarealeftchars",
							"class" : "sapUiCustomControlConversationCharsLeft"
						});

						oGridForm.addContent(textArea);

						textArea.onkeyup = function() {
//							var text_length = textArea.getValue().length;
//							var text_remaining = textArea.getMaxLength()
//									- text_length;
							
							var elem = textArea;
							var maxlen = textAreaMaxLength; 
							var value = elem.getValue();
							var len = value.replace(/\r\n/g, "~~").replace(/\n/g, "~~").length;		
							if (len > maxlen) { // Truncation
								var lines = elem.getValue().split(/\r\n|\n/);
								value = "";
								var i = 0;
								while (value.length < maxlen && i < lines.length) {
									value += lines[i].substring(0, maxlen - value.length) + "\r\n";
									i++;
								}
								elem.setValue(value.substring(0, maxlen));
								len = maxlen;
							}
							
							var textRemaining = maxlen - len;
							
							
							divLeftChars
									.html(textRemaining
											+ " "
											+ sap.ui.custom.control.conversation.ConversationI18N.language
													.getResourceBundle()
													.getText(
															"CUSTOM_CONVERSATION_CHARACTERS_REMAINING"));
						};

						textArea
								.addEventDelegate({
									onAfterRendering : function() {
										divLeftChars
												.html(textAreaMaxLength
														+ " "
														+ sap.ui.custom.control.conversation.ConversationI18N.language
																.getResourceBundle()
																.getText(
																		"CUSTOM_CONVERSATION_CHARACTERS_REMAINING"));
										$(textArea.getDomRef()).append(
												divLeftChars);
									}
								});

						var oTextField = new sap.ui.commons.TextField({
							width : "100%",
							layoutData : new sap.ui.layout.GridData({
								span : "L8 M8 S12"
							})
						});

						var oButton = new sap.m.Button(
								{
									text : sap.ui.custom.control.conversation.ConversationI18N.language
											.getResourceBundle()
											.getText(
													"CUSTOM_CONVERSATION_REPLY_BUTTON"),
									width : "100%",
									type : sap.m.ButtonType.Accept,
									layoutData : new sap.ui.layout.GridData({
										span : "L4 M4 S12"
									}),
									press : function(event) {										
										
										if (textArea.getValue() !== ""){ 
										
											var customData = {
												message : textArea.getValue(),
												noteParent : oControl.getNoteId(),
												padding : oControl.getPadding()
											}; // anything you eventually want to
											// pass
											oControl._commentGrid
													.removeStyleClass("sapUiCustomControlConversationNoteCommentGridVisible");
											oControl._commentGrid
													.addStyleClass("sapUiCustomControlConversationNoteCommentGridNotVisible");
											var eventBus = sap.ui.getCore()
													.getEventBus();
											textArea.setValue("");
											divLeftChars
													.html(textAreaMaxLength
															+ " "
															+ sap.ui.custom.control.conversation.ConversationI18N.language
																	.getResourceBundle()
																	.getText(
																			"CUSTOM_CONVERSATION_CHARACTERS_REMAINING"));
											eventBus
													.publish(
															sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
															sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_COMMENT_REPLY,
															{
																customData : customData
															});
									
									}else{
										sap.m.MessageBox.alert(sap.ui.custom.control.conversation.ConversationI18N.language
												.getResourceBundle()
												.getText(
														"CUSTOM_CONVERSATION_INSERT_A_MESSAGE"), {
									    title: sap.ui.custom.control.conversation.ConversationI18N.language
										.getResourceBundle()
										.getText(
												"CUSTOM_CONVERSATION_MESSAGEBOX_ALERT_TITLE"),
									    onClose: null,                           
									    styleClass: "",                          
									    initialFocus: null,                      
									    textDirection: sap.ui.core.TextDirection.Inherit,     
									    verticalScrolling: true,                              
									    horizontalScrolling: true                            
										});			
									}
									
									}
								});

						oGridForm
								.addStyleClass("sapUiCustomControlConversationCommentFieldForReply");

						oGridForm.addContent(oButton);

						return oGridForm;
					}

				});