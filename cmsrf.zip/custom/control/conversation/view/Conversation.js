jQuery.sap
		.require("sap.ui.custom.control.conversation.ConversationExchangeObject");
jQuery.sap.require("sap.ui.custom.control.conversation.util.ModelProcessor");
jQuery.sap.require("sap.ui.custom.control.conversation.entity.EntryObject");
jQuery.sap.require("sap.ui.custom.control.conversation.util.DateTool");
jQuery.sap.require("sap.ui.custom.control.conversation.util.GUID");
jQuery.sap
		.require("sap.ui.custom.control.conversation.view.ConversationEntryControl");
jQuery.sap
		.require("sap.ui.custom.control.conversation.event.ConversationEvents");

sap.ui.core.Control
		.extend(
				"sap.ui.custom.control.conversation.view.Conversation",
				{

					metadata : {
						properties : {
							conversationExchangeObject : {
								type : "object"
							}
						}
					},

					init : function() {
						this.eventBus = sap.ui.getCore().getEventBus();

						if (sap.ui.custom.control.conversation.Config.allowSubmit === true) {
							this.eventBus
									.subscribe(
											sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
											sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_COMMENT_ROOT,
											this.handlePostRootCommentEvent,
											this);

							this.eventBus
									.subscribe(
											sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
											sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_COMMENT_REPLY,
											this.handlePostReplyCommentEvent,
											this);

							this.eventBus
									.subscribe(
											sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
											sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_COMMENT_DELETE,
											this.handleDeleteCommentEvent, this);
						}

					},

					handleDeleteCommentEvent : function(channel, event,
							eventData) {
						// for easier access we instantiate a new variable with
						// the reference of where the newNotes are stored
						var newNotes = this.getConversationExchangeObject().newNotes;

						// we computed which are the notes that need to be
						// removed
						// we do this by looking into the ui and find there
						// which are the notes that need to be deleted.
						// this is done starting from the container div
						// containing the note where the delete event originated
						// we extract the ids of the notes from the html
						// elements and use those to delete them from the
						// newNotes Array
						var notesToDelete = [];
						notesToDelete.push(eventData.noteId);

						var children = $('div[data-parentcontainerid="'
								+ eventData.noteId
								+ '"] div[data-parentcontainerid]');
						for (var i = 0; i < children.length; i++) {
							notesToDelete.push($(children[i]).data("noteid"));
						}

						// delete from newNotes Array
						for (i = 0; i < notesToDelete.length; i++) {
							for (var j = newNotes.length - 1; j >= 0; j--) {
								if (newNotes[j].noteId === notesToDelete[i]
										|| newNotes[j].Id === notesToDelete[i]) {
									newNotes.splice(j, 1);
									break;
								}
							}
						}

						var jsonModelDocs = this
								.getConversationExchangeObject().jsonModel
								.getData();

						for (i = 0; i < notesToDelete.length; i++) {
							for (j = jsonModelDocs.length - 1; j >= 0; j--) {
								if (jsonModelDocs[j].Id === notesToDelete[i]) {
									jsonModelDocs.splice(j, 1);
									break;
								}
							}
						}

						this.getConversationExchangeObject().jsonModel
								.setData(jsonModelDocs);
						// remove the notes from teh UI
						$(
								'div[data-parentcontainerid="'
										+ eventData.noteId + '"]').remove();

						newNotes.sort(function(x, y) {
							return x.timestamp - y.timestamp;
						});

						if (newNotes.length && newNotes.length > 0) {
							this.getConversationExchangeObject().lastNote.user = newNotes[length].firstName
									+ " " + newNotes[length].lastName;
							this.getConversationExchangeObject().lastNote.timestamp = newNotes[length].timestamp
									.toLocaleString();
							if (newNotes[length].message
									&& newNotes[length].message !== "") {
								this.getConversationExchangeObject().lastNote.message = newNotes[length].message;
							} else if (newNotes[length].Message
									&& newNotes[length].Message !== "") {
								this.getConversationExchangeObject().lastNote.message = newNotes[length].Message;
							}
						} else {

							if (this.getConversationExchangeObject().jsonModel
									.getData().length > 0) {

								var nott = this.getConversationExchangeObject().jsonModel
										.getData();
								var lNote = nott[nott.length - 1];
								this.getConversationExchangeObject().lastNote.user = lNote.firstName
										+ " " + lNote.lastName;
								var dateTool = new sap.ui.custom.control.conversation.util.DateTool();
								this.getConversationExchangeObject().lastNote.timestamp = dateTool
										.createDateFromStrings(lNote.CrTime,
												lNote.CrDate).toLocaleString();
								this.getConversationExchangeObject().lastNote.message = lNote.Message;
							} else {

								this.getConversationExchangeObject().lastNote.user = "";
								this.getConversationExchangeObject().lastNote.timestamp = "";
								this.getConversationExchangeObject().lastNote.message = "";
							}

						}

						if (newNotes.length < 1) {
							var eventBus = sap.ui.getCore().getEventBus();
							eventBus
									.publish(
											sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
											sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_DISABLE_BEGIN_BUTTON,
											{});
						}
					},

					handlePostRootCommentEvent : function(channel, event,
							eventData) {

						var currentDate = new Date();

						var conversationEntryObject = this._createEntryObject(
								eventData, currentDate);
						conversationEntryObject.noteParent = "0000000000";
						conversationEntryObject.flag_New = true;
						conversationEntryObject.padding = 0;
						conversationEntryObject.timestamp = currentDate;

						var cec = this
								._createConversationEntryControl(conversationEntryObject);
						cec.setPadding(0);
						cec.setFlag_New(true);

						var rm = sap.ui.getCore().createRenderManager();

						rm.renderControl(cec);
						rm.flush($("#" + this.getId()), false, true);
						rm.destroy();

						this.getConversationExchangeObject().lastNote.user = conversationEntryObject.firstName
								+ " " + conversationEntryObject.lastName;
						this.getConversationExchangeObject().lastNote.timestamp = currentDate
								.toLocaleString();
						this.getConversationExchangeObject().lastNote.message = conversationEntryObject.message;

						this.getConversationExchangeObject().newNotes
								.push(conversationEntryObject);

						var jsonModelDocs = this
								.getConversationExchangeObject().jsonModel
								.getData();

						jsonModelDocs.push(conversationEntryObject
								.getObjectToStore());
						this.getConversationExchangeObject().jsonModel
								.setData(jsonModelDocs);
						
						
						var eventBus = sap.ui.getCore().getEventBus();
						eventBus
								.publish(
										sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
										sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_ENABLE_BEGIN_BUTTON,
										{});

					},

					handlePostReplyCommentEvent : function(channel, event,
							eventData) {

						var currentDate = new Date();

						var conversationEntryObject = this._createEntryObject(
								eventData, currentDate);
						conversationEntryObject.flag_New = true;
						conversationEntryObject.padding = eventData.customData.padding + 4;
						conversationEntryObject.timestamp = currentDate;

						var cec = this
								._createConversationEntryControl(conversationEntryObject);
						cec.setFlag_New(true);

						var rm = sap.ui.getCore().createRenderManager();

						rm.renderControl(cec);
						rm.flush($('div[data-parentcontainerid="'
								+ cec.getNoteParent() + '"]')[0], false, true);
						rm.destroy();

						this.getConversationExchangeObject().lastNote.user = conversationEntryObject.firstName
								+ " " + conversationEntryObject.lastName;
						this.getConversationExchangeObject().lastNote.timestamp = currentDate
								.toLocaleString();
						this.getConversationExchangeObject().lastNote.message = conversationEntryObject.message;

						this.getConversationExchangeObject().newNotes
								.push(conversationEntryObject);

						var jsonModelDocs = this
								.getConversationExchangeObject().jsonModel
								.getData();

						jsonModelDocs.push(conversationEntryObject
								.getObjectToStore());
						this.getConversationExchangeObject().jsonModel
								.setData(jsonModelDocs);
						
						var eventBus = sap.ui.getCore().getEventBus();
						eventBus
								.publish(
										sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
										sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_ENABLE_BEGIN_BUTTON,
										{});
						
					},

					renderer : function(oRm, oControl) {
						oControl.exchangeObject = oControl
								.getConversationExchangeObject();

						var docs = oControl.exchangeObject.jsonModel.getData();

						for (var i = 0; i < docs.length; i++) {
							if (docs[i].flag_New && docs[i].flag_New === true) {
								oControl.exchangeObject.newNotes.push(docs[i]);
							}
						}

						oControl.modelProcessor = new sap.ui.custom.control.conversation.util.ModelProcessor(
								oControl.exchangeObject.jsonModel);
						oControl.exchangeObject.modelProcessor = oControl.modelProcessor;

						oRm.write("<div ");

						oRm.writeControlData(oControl);

						oRm
								.write(' data-parentcontainerid="conversationRootContainer"');
						oRm.addClass("sapUiCustomControlConversationContainer");

						oRm.writeClasses();
						oRm.writeStyles();
						oRm.write(">");
						oRm.write("</div>");

						oControl._utilityProcessing();
					},

					onAfterRendering : function() {
						// called after instance has been rendered (it's in the
						// DOM)
						var oControl = this;

						oControl.modelProcessor.groupBy();
						var notes = oControl.modelProcessor.orderBy();

						function findNotesById(id, notesArray) {
							var foundNotes;
							for (var i = 0; i < notesArray.length; i++) {
								if (notesArray[i].Parent === id) {
									foundNotes = notesArray.splice(i, 1);
									return foundNotes;
								}
							}
							return foundNotes;
						}

						function displayNotes(children, level) {
							try {

								if (children) {
									for (var i = 0; i < children[0].notes.length; i++) {
										var cur = children[0].notes[i];

										// 1 - create first note and display it
										var cec = new sap.ui.custom.control.conversation.view.ConversationEntryControl();
										cec.setMessage(cur.Message);
										cec.setCrTime(cur.CrTime);
										cec.setCrDate(cur.CrDate);
										cec.setNoteParent(cur.Parent);
										cec.setFk1(cur.FK1);
										cec.setFk2(cur.FK2);
										cec.setFk3(cur.FK3);
										cec.setNoteId(cur.Id);
										cec.setFirstName(cur.firstName);
										cec.setLastName(cur.lastName);
										cec.setUserId(cur.Userid);
										cec.setEmail(cur.userEmail);
										cec.setPadding(level);

										if (cur.isLast) {
											cec.setIsLast(cur.isLast);
										}

										if (cur.flag_New) {
											cec.setFlag_New(cur.flag_New);
										}

										var rm = sap.ui.getCore()
												.createRenderManager();
										rm.renderControl(cec);

										if (cec.getNoteParent() === "0000000000") {
											rm.flush($("#" + oControl.getId()),
													false, true);
										} else {
											rm
													.flush(
															$('div[data-parentcontainerid="'
																	+ cec
																			.getNoteParent()
																	+ '"]')[0],
															false, true);
										}

										rm.destroy();

										var childrenOfChildren;
										if (notes && notes.length > 0) {
											childrenOfChildren = findNotesById(
													cur.Id, notes);
											if (childrenOfChildren !== null
													&& childrenOfChildren) {
												displayNotes(
														childrenOfChildren,
														level + 4);
											}
										}
									}
								}

							} catch (e) {
								jQuery.sap.log.error(e);
							}
						}

						var rootNotes = findNotesById("0000000000", notes);
						displayNotes(rootNotes, 0);
					},

					exit : function() {

						if (sap.ui.custom.control.conversation.Config.allowSubmit === true) {

							this.eventBus
									.unsubscribe(
											sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
											sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_COMMENT_ROOT,
											this.handlePostRootCommentEvent,
											this);

							this.eventBus
									.unsubscribe(
											sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
											sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_COMMENT_REPLY,
											this.handlePostReplyCommentEvent,
											this);

							this.eventBus
									.unsubscribe(
											sap.ui.custom.control.conversation.event.ConversationEvents.CHANEL,
											sap.ui.custom.control.conversation.event.ConversationEvents.EVENT_COMMENT_DELETE,
											this.handleDeleteCommentEvent, this);
						}
					},

					_createEntryObject : function(eventData) {
						var guid = new sap.ui.custom.control.conversation.util.GUID();
						var conversationEntryObject = new sap.ui.custom.control.conversation.entity.EntryObject();

						conversationEntryObject.noteId = guid.generateID10();
						conversationEntryObject.firstName = this
								.getConversationExchangeObject().currentUser.firstName;
						conversationEntryObject.lastName = this
								.getConversationExchangeObject().currentUser.lastName;
						conversationEntryObject.userId = this
								.getConversationExchangeObject().currentUser.userId;
						conversationEntryObject.email = this
								.getConversationExchangeObject().currentUser.email;
						conversationEntryObject.message = eventData.customData.message;
						var datetool = new sap.ui.custom.control.conversation.util.DateTool();
						var currentDate = new Date();
						conversationEntryObject.timestamp = currentDate;
						conversationEntryObject.crTime = datetool
								.getTimeFromDate(currentDate);
						conversationEntryObject.crDate = datetool
								.getDateFromDate(currentDate);
						conversationEntryObject.noteParent = eventData.customData.noteParent;
						conversationEntryObject.padding = eventData.customData.padding + 4;
						conversationEntryObject.fk1 = this
								.getConversationExchangeObject().fk1;
						conversationEntryObject.fk2 = this
								.getConversationExchangeObject().fk2;
						conversationEntryObject.fk3 = this
								.getConversationExchangeObject().fk3;
						return conversationEntryObject;

					},

					_createConversationEntryControl : function(
							conversationEntryObject) {
						var cec = new sap.ui.custom.control.conversation.view.ConversationEntryControl();
						cec.setNoteId(conversationEntryObject.noteId);
						cec.setMessage(conversationEntryObject.message);
						// cec.setTimestamp(conversationEntryObject.timestamp.toLocaleString());
						cec.setCrTime(conversationEntryObject.crTime);
						cec.setCrDate(conversationEntryObject.crDate);
						cec.setNoteParent(conversationEntryObject.noteParent);
						cec.setNoteId(conversationEntryObject.noteId);
						cec.setFirstName(conversationEntryObject.firstName);
						cec.setLastName(conversationEntryObject.lastName);
						cec.setUserId(conversationEntryObject.userId);
						cec.setEmail(conversationEntryObject.email);
						cec.setPadding(conversationEntryObject.padding);
						cec.setFk1(conversationEntryObject.fk1);
						cec.setFk2(conversationEntryObject.fk1);
						cec.setFk3(conversationEntryObject.fk3);
						if (conversationEntryObject.isLast) {
							cec.isLast(conversationEntryObject.isLast);
						}
						return cec;
					},

					_utilityProcessing : function() {
						// this is related to the new notes and to the last
						// message mechanism
						// last message
						var dateTool = new sap.ui.custom.control.conversation.util.DateTool();
						function compare(x, y) {
							return dateTool.createDateFromStrings(x.CrTime,
									x.CrDate)
									- dateTool.createDateFromStrings(y.CrTime,
											y.CrDate);
						}

						var jsonModel = this.getConversationExchangeObject().jsonModel;
						var exchangeObject = this
								.getConversationExchangeObject();

						if (jsonModel.getData().length > 0) {
							// sort notes based on time
							var cdn = jsonModel.getData();
							cdn.sort(compare);
							var lNote = cdn[cdn.length - 1];
							for (var i = 0; i < cdn.length; i++) {
								cdn[i].isLast = false;
							}
							cdn[cdn.length - 1].isLast = true;
							exchangeObject.lastNote.user = lNote.firstName
									+ " " + lNote.lastName;
							exchangeObject.lastNote.timestamp = dateTool
									.createDateFromStrings(lNote.CrTime,
											lNote.CrDate).toLocaleString();
							exchangeObject.lastNote.message = lNote.Message;

						}

					}

				});