jQuery.sap.declare("sap.ui.custom.control.conversation.Config");
sap.ui.custom.control.conversation.Config = {
		allowSubmit : true
};
