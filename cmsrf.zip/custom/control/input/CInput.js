jQuery.sap.declare("sap.ui.custom.control.input.CInput");
sap.m.Input.extend("sap.ui.custom.control.input.CInput",{
	
	renderer:{},
	_getValueHelpIcon:function(){
		var that = this;

		if (!this._oValueHelpIcon) {
			var sURI = sap.ui.core.IconPool.getIconURI("discussion");
			this._oValueHelpIcon = sap.ui.core.IconPool.createControlByURI({
				id: this.getId() + "__vhi",
				src: sURI
			});

			this._oValueHelpIcon.addStyleClass("sapMInputValHelpInner");
			this._oValueHelpIcon.attachPress(function (evt) {
				// if the property valueHelpOnly is set to true, the event is triggered in the ontap function
				if (!that.getValueHelpOnly()) {
					that.fireValueHelpRequest({fromSuggestions: false});
				}
			});
		}

		return this._oValueHelpIcon;
	}
});