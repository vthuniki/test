jQuery.sap.declare("sap.ui.cms.util.formatters.CRFCustomFormatter");

sap.ui.cms.util.formatters.CRFCustomFormatter = {
	
	toUpperCase :  function (value) {
		return value.toUpperCase();
	}
	
};