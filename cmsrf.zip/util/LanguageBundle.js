jQuery.sap.declare("sap.ui.cms.util.LanguageBundle");
sap.ui.cms.util.LanguageBundle = {
		"language":new sap.ui.model.resource.ResourceModel({
            bundleUrl : [jQuery.sap.getModulePath("sap.ui.cms.i18n"), "messageBundle.properties"].join("/")
        })
};
