jQuery.sap.require("sap.ui.cms.util.DateTool");
jQuery.sap.require("sap.ui.cms.util.ServicesConstants");
jQuery.sap.require("sap.ui.cms.util.ErrorMessageBuilder");
jQuery.sap.require("sap.ui.cms.util.ServiceRequestFactory");
jQuery.sap.require("sap.ui.cms.util.LanguageBundle");

jQuery.sap.declare("sap.ui.cms.util.NotesProcessor");

sap.ui.cms.util.NotesProcessor = {};

sap.ui.cms.util.NotesProcessor.loadNotes = function(context) {

	var sc = sap.ui.cms.util.ServicesConstants;
	var srf = new sap.ui.cms.util.ServiceRequestFactory();
	
	var requestURL = sc.DOCUMENT_NOTES_SET_PART1
			+ sap.ui.cms.NotesGlobal.objectID
			+ sc.DOCUMENT_NOTES_SET_PART2;

	var oModel = new sap.ui.model.odata.ODataModel(
			srf.buildURLZCMSDAW(), true);
	sap.ui.core.BusyIndicator.show();
	oModel.read(requestURL, null, null, true,
			sap.ui.cms.util.NotesProcessor.loadNotesSuccess.bind(context),
			sap.ui.cms.util.NotesProcessor.loadNotesError.bind(context));
};

sap.ui.cms.util.NotesProcessor.loadNotesSuccess = function(oData, response) {
	sap.ui.core.BusyIndicator.hide();
	util.Service.checkForSessionTimeout(response);

	var notesModel = new sap.ui.model.json.JSONModel(oData.results);

	sap.ui.cms.NotesGlobal.notesModel = notesModel;

	var conversationInputField;
	if (this.getView().byId("headerInfoTabView")) {
		conversationInputField = this.getView().byId("headerInfoTabView").byId(
				"conversationControl_ID");
	} else {
		conversationInputField = this.getView().byId("conversationControl_ID");
	}

	var dateTool = new sap.ui.cms.util.DateTool();
	function compare(x, y) {
		return dateTool.createDateFromStrings(x.CrTime, x.CrDate)
				- dateTool.createDateFromStrings(y.CrTime, y.CrDate);
	}

	var lastNote = "";
	if (sap.ui.cms.NotesGlobal.notesModel.getData().length > 0) {
		// sort notes based on time
		var cdn = sap.ui.cms.NotesGlobal.notesModel.getData();
		cdn.sort(compare);
		
		for(var i = 0; i < cdn.length; i++){
			cdn[i].isLast = false;
		}
		cdn[cdn.length - 1].isLast = true;
		var lNote = cdn[cdn.length - 1];
		lastNote = lNote.firstName
				+ " "
				+ lNote.lastName
				+ " ("
				+ dateTool.createDateFromStrings(lNote.CrTime, lNote.CrDate)
						.toLocaleString() + "): " + lNote.Message;
	} else {
		lastNote = "";
	}

	sap.ui.cms.NotesGlobal.lastNote = lastNote;
	sap.ui.cms.NotesGlobal.conversationInputField = conversationInputField;
	
	conversationInputField.setValue(lastNote);
	
};

sap.ui.cms.util.NotesProcessor.loadNotesError = function(error) {
	sap.ui.core.BusyIndicator.hide();

	var computedErrorMessage = sap.ui.cms.util.ErrorMessageBuilder.build(error);
	sap.m.MessageBox.show(computedErrorMessage, sap.m.MessageBox.Icon.ERROR,
			sap.ui.cms.util.LanguageBundle.language.getResourceBundle()
					.getText("CMSCRF_ERROR_TITLE"),
			[ sap.m.MessageBox.Action.CLOSE ]);
};


sap.ui.cms.util.NotesProcessor.prepareNotesForSubmit = function() {

	var payload = {};
	payload.FK3 = sap.ui.cms.NotesGlobal.objectID;
	payload.MessageId = "002";
	var notes = [];

	var model = sap.ui.cms.NotesGlobal.notesModel.getData();

	for (var j = 0; j < model.length; j++) {
		if (model[j].flag_New === true) {
			model[j].FK3 = sap.ui.cms.NotesGlobal.objectID;
			model[j].Mode = 2;
			model[j].MessageId = "002";
			delete (model[j].timestamp);
			delete (model[j].flag_New);
			delete (model[j].Id);
			delete (model[j].isLast);
			notes.push(model[j]);
		}
	}

	payload.NavToNotes = notes;

	return payload;

};

sap.ui.cms.util.NotesProcessor.submitNotes = function(context, payload) {
	var sc = sap.ui.cms.util.ServicesConstants;
	var srf = new sap.ui.cms.util.ServiceRequestFactory();
	var requestURL = sc.INSERTNOTES_ENTITY_QUERY;

	var oModel = new sap.ui.model.odata.ODataModel(
			srf.buildURLZCMSDAW(), true);

	oModel.create(requestURL, payload, {
		success : sap.ui.cms.util.NotesProcessor.submitNotesSuccess
				.bind(context),
		error : sap.ui.cms.util.NotesProcessor.submitNotesError.bind(context),
		//async : true
		async : false
	});

};

sap.ui.cms.util.NotesProcessor.submitNotesSuccess = function(oData, response) {
	sap.ui.core.BusyIndicator.hide();
	util.Service.checkForSessionTimeout(response);

	if (sap.ui.cms.NotesGlobal.objectID) {
		sap.ui.cms.util.NotesProcessor.loadNotes.apply(this, [ this ]);
	}
};

sap.ui.cms.util.NotesProcessor.submitNotesError = function(error) {
	sap.ui.core.BusyIndicator.hide();

	var computedErrorMessage = sap.ui.cms.util.ErrorMessageBuilder.build(error);
	sap.m.MessageBox.show(computedErrorMessage, sap.m.MessageBox.Icon.ERROR,
			sap.ui.cms.util.LanguageBundle.language.getResourceBundle()
					.getText("CMSCRF_ERROR_TITLE"),
			[ sap.m.MessageBox.Action.CLOSE ]);
};


sap.ui.cms.util.NotesProcessor.displayLastNote = function(){
	if(sap.ui.cms.copycrf == false){ //C5204479
	if(sap.ui.cms.NotesGlobal.conversationInputField && sap.ui.cms.NotesGlobal.lastNote){
		sap.ui.cms.NotesGlobal.conversationInputField.setValue(sap.ui.cms.NotesGlobal.lastNote);		
	}
	}
};