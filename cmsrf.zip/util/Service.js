jQuery.sap.declare("util.Service");
jQuery.sap.require("sap.m.MessageToast");
util.Service = function() {

	var hostUrl = location.protocol + "//" + location.host + "/";
	var serviceUrl = "/sap/opu/odata/sap/";

	var bus;
	if (comp) {
		bus = comp.getEventBus();
	} else {
		bus = sap.ui.getCore().getEventBus();
	}

	return {

		request: function(method, url, data, successChannel, failureChannel,
			showLoadingIndicator) {
			if (!showLoadingIndicator) {
				showLoadingIndicator = true;
			}
			jQuery.sap.log.info(location.host);
			if (showLoadingIndicator) {
				sap.ui.core.BusyIndicator.show();
			}
			if (location.host.search("localhost") != -1) {
				url = url.replace("?", "/");

				if (url.lastIndexOf("export") != -1) {
					url = url + ".txt";
				} else {
					url = url + ".json";
				}
			}
			url = serviceUrl + url;
			var dType = "application/json";
			if (url.lastIndexOf("export") != -1) {
				dType = "application/ms-excel";

			}
			jQuery.sap.log.info("SERVICE [" + method + "] REQUEST :" + url);
			$
				.ajax({
					// pfad zur PHP Datei (ab HTML Datei)...
					url: url,
					cache: false,
					headers: {
						Accept: dType,
						"Content-Type": dType
					},
					// Daten, die an Server gesendet werden soll in JSON Notation
					data: data,

					datatype: dType,
					// Methode POST oder GET
					type: method,
					// Callback-Funktion, die nach der Antwort des Servers
					// ausgefuehrt wird
					success: function(data, textStatus, jqXHR) {
						if (jqXHR
							.getResponseHeader("com.sap.cloud.security.login")) {
							window.location.reload();
						}
						jQuery.sap.log
							.info("return value of succesfull request: to " + successChannel);
						jQuery.sap.log.info(data);
						sap.ui.core.BusyIndicator.hide();
						bus.publish("service", successChannel, {
							data: data,
							textStatus: textStatus,
							jqXHR: jqXHR
						});
						jQuery.sap.log.info("data published!");
					},

					error: function(jqXHR, textStatus, errorThrown) {
						if (jqXHR
							.getResponseHeader("com.sap.cloud.security.login")) {
							window.location.reload();
						}
						jQuery.sap.log.info("unsuccesfull request");
						sap.ui.core.BusyIndicator.hide();
						bus.publish("service", failureChannel, {
							jqXHR: jqXHR,
							textStatus: textStatus,
							errorThrown: errorThrown
						});
					}
				});
		},
		buildWebDynproLink: function(objectId, requestFormType) {
			return "https://isp.wdf.sap.corp/sap/bc/webdynpro/sap/zv_cms_rcm_wdr_gen_form?REQUESTFORM_TYPE=" + requestFormType + "&REQUESTNO=" +
				objectId + "&sap-language=EN";
		},
		parseDate: function(str) {
			if (!/^(\d){8}$/.test(str))
				return "invalid date";
			var y = str.substr(0, 4),
				m = str.substr(4, 2) - 1,
				d = str.substr(
					6, 2);
			return new Date(y, m, d);
		},

		stringToBoolean: function(booleanString) {
			if (booleanString == "X" || booleanString == "x") {
				return true;
			} else {
				return false;
			}
		},
		booleanToString: function(boolean) {
			if (boolean) {
				return "X";
			} else {
				return "";
			}

		},
		_numericChangeHandler: function(event) {
			var target = event.oSource;
			var value = target.getValue();
			//only allow numbers or a comma
			value = value.replace(/[^0-9,]/g, "");
			target.setValue(value);
		},

		buildControlWithStringObject: function(obj) {
			var control;
			var enabled = this.stringToBoolean(obj.Enabled);
			var mandatory = this.stringToBoolean(obj.Mandatory);
			var editable = !this.stringToBoolean(obj.DisplayOnly);
			var showSearchHelp = this.stringToBoolean(obj.ShowSearchHelp);
			var type = "Text";
			if (obj.Htmlsubtype && obj.Htmlsubtype.search("NUMBER") == -1) {
				type = obj.Htmlsubtype.toLowerCase();
				type = type.charAt(0).toUpperCase() + type.slice(1);
			}

			if (obj.Htmltype.search("DATE") != -1) {
				control = new sap.m.DateTimeInput({
					visible: enabled,
					enabled: "{= ${view>/editMode} || ${view>/creationMode} }",
					tooltip: obj.ToolTip
				});
				control.data("shName", obj.SearchHelp);
				control.data("mandatory", mandatory);
				control.data("itemId", obj.Fieldname);
			} else if (obj.Htmltype.search("SEPARATOR") != -1) {
				control = new sap.m.Text({
					visible: enabled,
					text: obj.FieldLabel

				});
				control.data("itemId", obj.Fieldname);
			} else if (obj.Htmltype.search("INPUT") != -1) {
				control = new sap.m.Input({
					visible: enabled,
					enabled: "{= ${view>/editMode} || ${view>/creationMode} }",
					type: type,
					valueHelpRequest: this.valueHelpRequestTriggered
						.bind(this),
					showValueHelp: showSearchHelp,
					tooltip: obj.ToolTip
				});

				if (obj.Htmlsubtype && obj.Htmlsubtype.search("NUMBER") != -1) {
					control.attachLiveChange(this._numericChangeHandler);
				}
				control.data("shName", obj.SearchHelp);
				control.data("mandatory", mandatory);
				control.data("itemId", obj.Fieldname);
			} else if (obj.Htmltype.search("SELECT") != -1) {

				control = new sap.m.Select({
					visible: enabled,
					enabled: "{= ${view>/editMode} || ${view>/creationMode} }",
					tooltip: obj.ToolTip
				});
				control.data("itemId", obj.Fieldname);
				control.data("mandatory", mandatory);

				if (obj.NavToDrop.results && obj.NavToDrop.results.length > 0) {
					var oItemTemplate = new sap.ui.core.Item({
						text: "{DomainDesc}",
						key: "{DropdownId}"

					});
					control.bindAggregation("items", "/", oItemTemplate);
					var model = new sap.ui.model.json.JSONModel();
					model.setData(obj.NavToDrop.results);
					control.setModel(model);
				}
			} else if (obj.Htmltype.search("AREA") != -1) {
				control = new sap.m.TextArea({
					rows: 2,
					visible: enabled,
					maxLength: 1024,
					editable: "{= ${view>/editMode} || ${view>/creationMode} }",
					showValueHelp: showSearchHelp,
					valueHelpRequest: this.valueHelpRequestTriggered
						.bind(this),
					tooltip: obj.ToolTip
				});

				if (obj.Htmltype.search("2") != -1) {
					//when the text area is the type number 2 -> use 10 rows
					control.setRows(10);
				} else if (obj.Htmltype.search("3") != -1) {
					//when the text area is the type number 3 -> use 20 rows
					control.setRows(20);
				}
				control.data("shName", obj.SearchHelp);
				control.data("mandatory", mandatory);
				control.data("itemId", obj.Fieldname);
			} else if (obj.Htmltype.search("CHECK") != -1) {
				control = new sap.m.CheckBox({

					visible: enabled,
					enabled: "{= ${view>/editMode} || ${view>/creationMode} }",

					tooltip: obj.ToolTip
				});
				control.data("itemId", obj.Fieldname);
				control.data("mandatory", mandatory);
			}
			// SAP.M.LINK IS BEEN IMPLEMENTED FOR LINK URL C5262631 SAPJIRA ITSDEO2C-15975
			else if (obj.Htmltype.search("LINK") != -1) {
				control = new sap.m.Link({
					text: obj.PopupContent,
					href: obj.PopupContent,
					target: "_blank",
					visible: true,
					enabled: true
					// enabled: "{= ${view>/editMode} || ${view>/creationMode} }",
				});
				control.data("itemId", obj.Fieldname);
				control.data("mandatory", mandatory);
			}

			return control;
		},
		openHelpPopover: function(oEvt) {
			var btn = oEvt.getSource();
			var longtext = btn.data("popContent");

			var _oPopover = sap.ui.xmlfragment("sap.ui.cms.view.HelpPopover", this);
			var model = new sap.ui.model.json.JSONModel();
			model.setProperty("/longtext", longtext);
			_oPopover.setModel(model);
			_oPopover.openBy(btn);
		},
		downloadFile: function(url) {
			url = jQuery.sap.getModulePath("sap.ui.cms") + serviceUrl + "ZCONTRACTRF_SRV/" + url;
			window.location.href = url;
		},
		dataURItoBlob: function(dataURI) {
			// convert base64 to raw binary data held in a string
			// doesn't handle URLEncoded DataURIs - see SO answer #6850276 for code that does this
			var byteString = atob(dataURI.split(',')[1]);

			// separate out the mime component
			var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];

			// write the bytes of the string to an ArrayBuffer
			var ab = new ArrayBuffer(byteString.length);
			var ia = new Uint8Array(ab);
			for (var i = 0; i < byteString.length; i++) {
				ia[i] = byteString.charCodeAt(i);
			}

			// write the ArrayBuffer to a blob, and you're done
			var bb = new BlobBuilder();
			bb.append(ab);
			return bb.getBlob(mimeString);
		},

		valueHelpRequestTriggered: function(oEvt, shName) {
			var searchHelpName;
			var control = oEvt.getSource();
			this.searchHelpInputControl = control;
			if (shName) {
				searchHelpName = shName;
			} else {
				//get search help name

				searchHelpName = control.data("shName");
			}

			if (searchHelpName && searchHelpName.length > 0) {
				//get metadata of search help
				//build new dialog with the metadata which shows all the inputs
				if (mainModel) {
					sap.ui.core.BusyIndicator.show();
					mainModel
						.read(
							"/SearchHlpMetadataCollectionSet/?$filter=Searchhelpname%20eq%20%27" + searchHelpName + "%27&$expand=ToMetadata", null,
							null, true,
							this.getSearchHelpMetaDataSuccess
							.bind(this),
							this.getSearchHelpMetaDataError.bind(this));
				}
			} else {
				sap.m.MessageToast.show("No Search Help assigned!");
			}

		},
		buildSearchHelpInputControl: function(obj) {
			var control;
			var enabled = this.stringToBoolean(obj.Editable);

			var showSearchHelp = false;
			if (obj.SearchHelp.length > 0) {
				showSearchHelp = true;
			}

			control = new sap.m.Input({

				enabled: enabled,
				valueHelpRequest: this.valueHelpRequestTriggered.bind(this),
				showValueHelp: showSearchHelp,
				tooltip: obj.ToolTip
			});
			control.data("searchHelp", obj.Searchhelpname);
			control.data("transField", obj.Transferredfieldname);
			control.data("shName", obj.SearchHelp);
			control.data("fieldname", obj.Fieldname);
			control.data("labelText", obj.Fieldlabel);
			control.data("isInput", obj.Isinput);
			control.data("isResult", obj.Isresult);
			return control;
		},
		buildLabelForInput: function(inputControl) {
			var labelForControl = new sap.m.Label({
				text: inputControl.data("labelText")
			});
			return labelForControl;
		},
		buildFormWithInputControls: function(inputControlArray, existingForm) {
			var simpleForm = new sap.ui.layout.form.SimpleForm();

			if (existingForm) {
				simpleForm = existingForm;
			}
			//get only the controls which are flagged as input controls
			inputControlArray = this.getInputControls(inputControlArray);

			for (var i in inputControlArray) {
				var control = inputControlArray[i];
				//add the event delegate for this control, to trigger a specific function when the control is rendered
				control.addEventDelegate({
					onAfterRendering: function(evt) {
						//get the source control
						var control = evt.srcControl;
						//bind the key down event to the control and pass over the source control as data
						$("#" + control.sId).on(
							'keydown', {
								src: control,
							},
							function(e) {
								e.stopPropagation();

								//only when the key down event has the keycode 13 = Enter -> proceed
								if (e.keyCode == 13) {
									//get the search button of the dialog which holds the input and fire it
									var control = e.data.src;
									var dialog = control.getParent()
										.getParent().getParent()
										.getParent().getParent()
										.getParent().getParent();
									var searchButton = dialog
										.getBeginButton();
									searchButton.firePress();
								}
							});
					}
				});

				var labelForControl = this.buildLabelForInput(control);

				simpleForm.addContent(labelForControl);
				simpleForm.addContent(control);
			}

			return simpleForm;
		},

		getSearchHelpControlArray: function(searchHelpControlResponse) {
			var inputControlArray = [];
			for (var i in searchHelpControlResponse) {
				var inputControl = this
					.buildSearchHelpInputControl(searchHelpControlResponse[i]);
				inputControlArray.push(inputControl);
			}
			return inputControlArray;
		},
		buildTabBarWithSearchHelpResponse: function(response, targetControl) {
			var tabbar = new sap.m.IconTabBar();

			for (var i in response) {
				var searchHelpEntry = response[i];

				if (searchHelpEntry.Tabname && searchHelpEntry.Tabname.length > 0) {
					var tab = new sap.m.IconTabFilter({
						key: searchHelpEntry.Tabname,
						text: "Tab " + i
					});
					var xmlView = new sap.ui.core.mvc.XMLView({
						viewName: "sap.ui.cms.view.EmptyTab"
					});
					var existingForm = xmlView.getContent()[0];
					var existingList = xmlView.getContent()[1];
					//add form and list onto the view
					var inputFieldsOfSearchHelpResponse = searchHelpEntry.ToMetadata.results;
					var simpleForm = this
						.buildFormWithInputControls(
							this
							.getSearchHelpControlArray(inputFieldsOfSearchHelpResponse),
							existingForm);
					var list = this
						.createSearchHelpResultList(
							this
							.getSearchHelpControlArray(inputFieldsOfSearchHelpResponse),
							existingList, targetControl);

					tab.addContent(xmlView);
					tabbar.addItem(tab);

				}
			}
			return tabbar;
		},
		changeDialogSelectItem: function(oEvt) {
			var item = oEvt.getParameters().selectedItem;

			var dialog;
			dialog = oEvt.getSource().getParent().getParent();
			dialog.removeAllContent();
			//clear dialog content
			//add the view of the item
			dialog.addContent(item.data("view"));
		},
		buildSelectWithResponse: function(response, targetControl) {
			var select = new sap.m.Select({
				change: this.changeDialogSelectItem
			});

			for (var i in response) {
				var searchHelpEntry = response[i];

				if (searchHelpEntry.Tabname && searchHelpEntry.Tabname.length > 0) {

					var item = new sap.ui.core.Item({
						key: searchHelpEntry.Tabname,
						text: searchHelpEntry.Tabname
					});

					var xmlView = new sap.ui.core.mvc.XMLView({
						viewName: "sap.ui.cms.view.EmptyTab"
					});
					var existingForm = xmlView.getContent()[0].getContent()[0];
					var existingList = xmlView.getContent()[1];
					//add form and list onto the view
					var inputFieldsOfSearchHelpResponse = searchHelpEntry.ToMetadata.results;
					var simpleForm = this
						.buildFormWithInputControls(
							this
							.getSearchHelpControlArray(inputFieldsOfSearchHelpResponse),
							existingForm);
					var list = this
						.createSearchHelpResultList(
							this
							.getSearchHelpControlArray(inputFieldsOfSearchHelpResponse),
							existingList, targetControl);

					item.data("view", xmlView);
					select.addItem(item);

				}
			}
			return select;
		},
		getSearchHelpMetaDataSuccess: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
			this.checkForSessionTimeout(response);
			//save the name of the attribute which has to be delivered to the input

			var result = oData.results;
			if (result.length > 0) {

				var searchHelp = result[0];
				var searchHelpName = searchHelp.Searchhelpname;

				var dynDialog = sap.ui.xmlfragment(
					"sap.ui.cms.view.DynSearchHelp", this);
				//make the dialog fullscreen when the device is a phone
				dynDialog.setStretch(jQuery.device.is.phone);

				var control = jQuery.extend(true, {},
					this.searchHelpInputControl);
				var select = this.buildSelectWithResponse(result, control);
				dynDialog.data("targetControl", control);

				dynDialog.getSubHeader().addContent(select);

				if (select.getItems().length > 0) {
					var item = select.getItemAt(0);
					var args = new Object();
					args['selectedItem'] = item;
					select.fireChange(args);
				}

				// open value help dialog
				dynDialog.open();
			}

		},

		getResultControls: function(searchHelpControlArray) {
			var resultControls = [];
			for (var i in searchHelpControlArray) {
				var control = searchHelpControlArray[i];
				if (control.data("isResult") && this.stringToBoolean(control.data("isResult"))) {
					resultControls.push(control);
				}
			}

			return resultControls;
		},
		getInputControls: function(searchHelpControlArray) {
			var resultControls = [];
			for (var i in searchHelpControlArray) {
				var control = searchHelpControlArray[i];
				if (control.data("isInput") && this.stringToBoolean(control.data("isInput"))) {
					resultControls.push(control);
				}
			}

			return resultControls;
		},

		buildTemplateAttrbibutesOutOfControlArray: function(controlArray) {
			var templateAttributes = [];

			for (var i in controlArray) {
				var control = controlArray[i];
				var attribute = new sap.m.ObjectAttribute({
					text: "{" + control.data("fieldname") + "}",
					title: control.data("labelText")

				});
				templateAttributes.push(attribute);
			}

			return templateAttributes;
		},
		getTransferredFieldControlFromControlArray: function(controlArray) {
			var control;

			for (var i in controlArray) {
				var entry = controlArray[i];
				if (entry.data("transField") == "X") {
					control = entry;
				}
			}

			return control;
		},
		createSearchHelpResultList: function(searchHelpControlArray,
			existingList, targetControl) {
			var list = new sap.m.List({
				headerText: "Result"

			});

			if (existingList) {
				list = existingList;
			}

			//get the controls only, which are flagged as result
			searchHelpControlArray = this
				.getResultControls(searchHelpControlArray);

			//get the transferredField control
			var transferredFieldControl = this
				.getTransferredFieldControlFromControlArray(searchHelpControlArray);
			var fieldResult = "";
			var fieldResultWithoutBrackets = "";

			if (transferredFieldControl) {
				fieldResult = "{" + transferredFieldControl.data("fieldname") + "}";

				fieldResultWithoutBrackets = transferredFieldControl.data("fieldname");
			}
			var templateAttributes = this
				.buildTemplateAttrbibutesOutOfControlArray(searchHelpControlArray);
			var template = new sap.m.ObjectListItem({

				attributes: templateAttributes,
				press: this.searchHelpItemSelected,
				title: fieldResult,
				type: "Active"
			});
			if (transferredFieldControl) {
				template.data("result", fieldResult);
			}
			var oSorter = new sap.ui.model.Sorter(
				fieldResultWithoutBrackets, false, false);
			list.bindItems({

				path: "/",
				sorter: oSorter,
				template: template

			});
			return list;
		},
		searchHelpItemSelected: function(oEvt) {
			var dialog;
			dialog = oEvt.getSource().getParent().getParent().getParent();

			var targetControl = dialog.data("targetControl");
			//pick the correct attribute
			targetControl.setValue(oEvt.getSource().data("result").trim());
			//call the change method of the control, to execute the change function, if there is some custom code
			targetControl.fireChange({
				value: oEvt.getSource().data("result")
			});

			dialog.close();
			dialog.destroy();
			dialog = null;
			this.activeDialog = null;
			this.activeSelectedTabView = null;

		},
		addEnterEventOnCustomDialog: function(form) {
			var inputArray = this.getAllInputControlsOutOfSimpleForm(form);
			for (var i in inputArray) {
				var input = inputArray[i];
				input.addEventDelegate({
					onAfterRendering: function(evt) {
						//get the source control
						var control = evt.srcControl;
						//bind the key down event to the control and pass over the source control as data
						$("#" + control.sId).on(
							'keydown', {
								src: control,
							},
							function(e) {
								e.stopPropagation();

								//only when the key down event has the keycode 13 = Enter -> proceed
								if (e.keyCode == 13) {
									//get the search button of the dialog which holds the input and fire it
									var control = e.data.src;
									var dialog = control.getParent()
										.getParent().getParent()
										.getParent().getParent();
									var searchButton = dialog
										.getBeginButton();
									searchButton.firePress();
								}
							});
					}
				});

			}
		},
		getAllInputControlsOutOfSimpleForm: function(simpleForm) {
			var inputControlArray = [];

			for (var i in simpleForm.getContent()) {
				var control = simpleForm.getContent()[i];
				//only return visible controls
				if (control instanceof sap.m.Input && control.getVisible()) {
					inputControlArray.push(control);
				}
			}

			return inputControlArray;
		},
		getAllUsableControlsOutOfSimpleForm: function(simpleForm) {
			var inputControlArray = [];

			for (var i in simpleForm.getContent()) {
				var control = simpleForm.getContent()[i];
				//only return visible controls
				if (!(control instanceof sap.m.Text) && !(control instanceof sap.m.Label) && !(control instanceof sap.m.Button) && control.getVisible()) {
					inputControlArray.push(control);
				}
			}

			return inputControlArray;
		},

		buildFilterStringForControlArray: function(controlArray) {
			var filterString = "";

			for (var i in controlArray) {
				var control = controlArray[i];
				var controlValue = control.getValue();
				var backendAttributeName = control.data("fieldname");
				if (controlValue && controlValue.length > 0) {
					if (filterString.length > 0) {
						filterString = filterString + "%20@$@AND@$@%20";
					}
					filterString = filterString + backendAttributeName + "%20EQ%20" + controlValue;
				}
			}

			return filterString;
		},
		getTabOfTabBarByKey: function(tabbar, key) {
			for (var i in tabbar.getItems()) {
				var tab = tabbar.getItems()[i];
				if (tab.getKey() == key) {
					return tab;
				}
			}
		},
		onDynSearch: function(oEvt) {
			//get the dialog
			var dialog;
			if (!jQuery.device.is.phone) {
				//dialog = oEvt.getSource().getParent().getParent();
				dialog = oEvt.getSource().getParent();
			} else {
				dialog = oEvt.getSource().getParent();
			}
			var xmlView = dialog.getContent()[0];
			this.activeDialog = dialog;
			this.activeSelectedTabView = xmlView;
			//get the active form in the dialog
			var simpleForm = xmlView.getContent()[0].getContent()[0];
			//close the input fields to show the list
			simpleForm.getParent().setExpanded(false);
			//get all inputs in the active form
			var inputArray = this
				.getAllInputControlsOutOfSimpleForm(simpleForm);
			//build filter string out of the input array
			var filterString = this
				.buildFilterStringForControlArray(inputArray);

			//fire the search help request to get the result
			if (inputArray && inputArray.length > 0) {
				var searchHelpName = inputArray[0].data("searchHelp");
				if (searchHelpName) {
					if (mainModel) {
						var sRead = "/SearchHlpDataCollectionSet/?$filter=Shlpname%20eq%20%27" + searchHelpName + "%27%20and%20Shlpselopt%20eq%20%27" +
							filterString + "%27%20&top=100";
						sap.ui.core.BusyIndicator.show();
						mainModel.read(sRead, null, null, true,
							this.getDynSearchHelpResultSuccess.bind(this),
							this.getDynSearchHelpResultError.bind(this));
					}
				}
			}

		},

		mergeDataResultEntries: function(entries) {
			var result = [];
			var previousRow = "";
			var mergedEntry = new Object();
			for (var i in entries) {
				var entry = entries[i];
				if (previousRow.length > 0) {
					if (previousRow != entry.Recordpos) {
						result.push(mergedEntry);
						mergedEntry = new Object();

					}
				}
				mergedEntry[entry.Fieldname] = entry.Fieldval;
				previousRow = entry.Recordpos;

			}
			//push the last object into the array
			if (previousRow && previousRow != "") {
				result.push(mergedEntry);
			}
			return result;
		},
		getDynSearchHelpResultSuccess: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
			util.Service.checkForSessionTimeout(response);
			var model = new sap.ui.model.json.JSONModel();

			var result = this.mergeDataResultEntries(oData.results);

			//show a toast to indicate when the result contains no data because it may happen that the list is not visible
			if (result.length <= 0) {
				sap.m.MessageToast.show("No data available!");

			}

			//scroll to the list in the view 7001718920 for Currency
			model.iSizeLimit = 400;
			model.setData(result);

			if (this.activeDialog && this.activeSelectedTabView) {
				this.activeSelectedTabView.setModel(model);
			}
		},
		getDynSearchHelpResultError: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
		},
		onCloseDynDialog: function(oEvt) {
			var dialog;
			if (!jQuery.device.is.phone) {
				//dialog = oEvt.getSource().getParent().getParent();
				dialog = oEvt.getSource().getParent();
			} else {
				dialog = oEvt.getSource().getParent();
			}
			if (dialog) {
				dialog.close();
				dialog.destroy();
				dialog = null;
				this.activeDialog = null;
				this.activeSelectedTabView = null;

			}
		},
		getSearchHelpMetaDataError: function(oData, response) {
			sap.ui.core.BusyIndicator.hide();
		},

		buildTableControlWithStringObject: function(obj, valueHelpCallback,
			changeCallback) {
			var control;

			if (!obj || (obj.ControlType.search("INPUT") != -1) || (obj.ControlType.search("AREA") != -1)) {

				control = new sap.m.Input({
					maxLength: 1024
				});
				if (changeCallback) {
					control.attachChange(changeCallback);
				}
				if (valueHelpCallback) {
					control.attachValueHelpRequest(valueHelpCallback);
				}
			} else if (obj.ControlType.search("SELECT") != -1) {

				control = new sap.m.Select();
				if (changeCallback) {
					control.attachChange(changeCallback);
				}

				if (obj.NavToLoad.results && obj.NavToLoad.results.length > 0) {
					var oItemTemplate = new sap.ui.core.Item({
						text: "{DomainDesc}",
						key: "{DropdownId}"

					});
					oItemTemplate.data("searchHelpName", "{SearchHelpName}");
					//					oItemTemplate.data("searchHelpName2", "{/SearchHelpName}");
					control.bindAggregation("items", "/", oItemTemplate);
					var model = new sap.ui.model.json.JSONModel();
					model.setData(obj.NavToLoad.results);
					control.setModel(model);
				}
			}

			return control;
		},
		checkForSessionTimeout: function(response) {
			if (response.headers["com.sap.cloud.security.login"]) {

				alert("Sorry but session has expired, page will be reloaded.");

				window.location.reload();

			}
		},

		getDateDDMMYYYY: function() {
			var today = new Date();
			var dd = today.getDate();
			var mm = today.getMonth() + 1; //January is 0!
			var yyyy = today.getFullYear();

			if (dd < 10) {
				dd = '0' + dd;
			}

			if (mm < 10) {
				mm = '0' + mm;
			}

			return dd + '.' + mm + '.' + yyyy;
		}

	};
}();