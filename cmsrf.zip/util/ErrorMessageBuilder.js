jQuery.sap.declare("sap.ui.cms.util.ErrorMessageBuilder");

sap.ui.cms.util.ErrorMessageBuilder = {};

sap.ui.cms.util.ErrorMessageBuilder.build = function(error) {

	var message = "";

	if (error) {
		if (error.message) {
			message = message + error.message + "  ";
		}

		if (error.response) {
			if (error.response.statusCode) {
				message = message + error.response.statusCode + " ";
			}
			if (error.response.statusText) {
				message = message + error.response.statusText + " ";
			}
		}

		if (error.response.body) {
			try {
				var er = jQuery.parseJSON(error.response.body);
				if (er && er.error && er.error.message
						&& er.error.message.value) {
					message = message + "\n\n" + er.error.message.value; 
				}
			} catch (e) {

			}
		}

	}
	return message;
};