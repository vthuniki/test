jQuery.sap.declare("sap.ui.cms.util.NCButtonsHandlers");

sap.ui.cms.util.NCButtonsHandlers = {};

sap.ui.cms.util.NCButtonsHandlers.activateCreate = function(context) {
	var creationMode = context.getView().getModel("view").getProperty(
			"/creationMode");
	if (creationMode) {
		context.advanceToNextTabButton.setEnabled(false);
		context.advanceToNextTabButton.setVisible(false);
		context.createButton.setEnabled(true);
		context.createButton.setVisible(true);
					// C5204963
		context.draftButton.setEnabled(true);
		context.draftButton.setVisible(true);
		// C5204963
	}
};

sap.ui.cms.util.NCButtonsHandlers.advanceToNextTab = function(context) {

	var currentlySelectedTab = context.iconTabBar.getSelectedKey();
	var items = context.iconTabBar.getItems();
	var length = items.length;
	var pos = 0;
	//var flagg = 0;   //C5299813
	tabloop: for (var i = 0; i < items.length - 2; i++) {
		var ctab = items[i];
		if (ctab.getKey && currentlySelectedTab === ctab.getKey()) {
			pos = i;
			break tabloop;
		}
	}
	
	//Begin of Included by C5299813 for ITSDEO2C-20497 - If contact tab is not visible, go to next tab
	if (flagg == 0){
	if(this.getView().byId("contactFilter").getVisible() == false){pos++;}
			flagg++;
	} //End Of include by C5299813
	context.iconTabBar.setSelectedKey(items[pos + 2].getKey());

	if (pos + 2 === length - 1) {
		context.advanceToNextTabButton.setEnabled(false);
		context.advanceToNextTabButton.setVisible(false);
		context.createButton.setEnabled(true);
		context.createButton.setVisible(true);
			// C5204963
		context.draftButton.setEnabled(true);
		context.draftButton.setVisible(true);
		// C5204963
	}
}

sap.ui.cms.util.NCButtonsHandlers.changeSalesOrg = function(context) {
	var creationMode = context.getView().getModel("view").getProperty(
			"/creationMode");
	if (creationMode) {
		sap.ui.cms.GlobalRegistry.advanceToNextTabButton.setEnabled(true);
		sap.ui.cms.GlobalRegistry.advanceToNextTabButton.setVisible(true);
		sap.ui.cms.GlobalRegistry.createButton.setEnabled(false);
		sap.ui.cms.GlobalRegistry.createButton.setVisible(false);
	}
};