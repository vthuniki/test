jQuery.sap.declare("util.Formatter");

util.Formatter = function() {

	var hostUrl = location.protocol + "//" + location.host + "/";
	var serviceUrl = "./../api/";

	return {

		getDateString: function(dateInput) {
			var dateStr = "";
			if (dateInput) {
				// SAPUI5 formatters  
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd.MM.yyyy"
				});
				dateStr = dateFormat.format(dateInput);
			}

			return dateStr;
		},
		checkComparedStrings: function(stringToBeSearchedIn) {
			var stringToBeChecked = this.data("id");
			var splittedEntries = stringToBeSearchedIn.split(",");

			for (var i in splittedEntries) {
				var entry = splittedEntries[i];
				if (entry == stringToBeChecked) {
					return true;
				}
			}

			return false;
		}

	};
}();