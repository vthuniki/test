jQuery.sap.declare("sap.ui.cms.util.ServiceEvents");

sap.ui.cms.util.ServiceEvents = {};

sap.ui.cms.util.ServiceEvents.define = function(name, value) {
	Object.defineProperty(sap.ui.cms.util.ServiceEvents, name
			.toUpperCase(), {
		"value" : value,
		"writable" : false,
		"configurable" : false
	});
};


sap.ui.cms.util.ServiceEvents.define("CHANEL",
		"sap.ui.cms.util.ServiceEvents.chanel");

sap.ui.cms.util.ServiceEvents.define("EVENT_DISPLAY_LAST_NOTE",
"displayLastNoteEvent");

