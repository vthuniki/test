jQuery.sap.declare("util.Controller");

sap.ui.core.mvc.Controller.extend("util.Controller", {
	getEventBus: function() {
	    //return components event bus if possible
	    if(comp){
	        return comp.getEventBus();
	    }
		return sap.ui.getCore().getEventBus();
	},
	onNavBackPressed: function(view) {
		this.getRouter().navBackTo(null, null, view);
	},
	onNavHome: function(view) {
		this.getEventBus().publish("nav", "back", null);
	},
	track: function(trackTerm) {
		jQuery.sap.log.info("Tracking: [" + trackTerm + "]");
		if (tracking)
			tracking.postEvent(trackTerm);

		
	},
	getRouter: function() {
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
	getI18n: function() {
		return this.getView().getModel("i18n");
	},
	_i18nBundle: function() {
		return this.getView().getModel("i18n").getResourceBundle();
	},
	geti18nText: function(key) {
		return this._i18nBundle().getText(key);
	},
	getRootPath: function() {
		return jQuery.sap.getModulePath("sap.ui.cms");
	}
});