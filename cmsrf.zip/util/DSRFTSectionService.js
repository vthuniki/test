jQuery.sap.require("sap.ui.cms.util.ErrorMessageBuilder");
jQuery.sap.require("sap.ui.cms.util.LanguageBundle");
jQuery.sap.require("sap.ui.cms.util.ServicesConstants");
jQuery.sap.require("sap.ui.cms.util.ServiceRequestFactory");
jQuery.sap.declare("sap.ui.cms.util.DSRFTSectionService");

sap.ui.cms.util.DSRFTSectionService = {};

sap.ui.cms.util.DSRFTSectionService.loadSections = function(context,
		requestSP) {
	var sc = sap.ui.cms.util.ServicesConstants;
	var srf = new sap.ui.cms.util.ServiceRequestFactory();

//	var requestURL = sc.REQUEST_TYPE_DETAILS_SET + "'" + searchValue + "'";
	var requestURL = sc.REQUEST_TYPE_DETAILS_SET + sc.PARENTID_EQ + "'"
	+ requestSP.R + sc.LTSEPARATOR +requestSP.C + "' " + sc.AND + " "+ sc.LIST_TYPE_EQ + "'" + sc.LIST_TYPE_S
	+ "'";

	var oModel = new sap.ui.model.odata.ODataModel(srf.buildURLZCONTRACT(),
			true);
	sap.ui.core.BusyIndicator.show();
	oModel
			.read(requestURL, null, null, true,
					sap.ui.cms.util.DSRFTSectionService.loadSectionsSuccess
							.bind(context),
					sap.ui.cms.util.DSRFTSectionService.loadSectionsError
							.bind(context));
};

sap.ui.cms.util.DSRFTSectionService.loadSectionsSuccess = function(oData,
		response) {

	sap.ui.core.BusyIndicator.hide();
	util.Service.checkForSessionTimeout(response);
	
	var sc = sap.ui.cms.util.ServicesConstants;

	var pso = {
		ListID : "SSEL01",
		ParentID : "NULL",
		ListType : sc.LIST_TYPE_S,
		ListDescription : sap.ui.cms.util.LanguageBundle.language
				.getResourceBundle().getText("CMSCRF_SERVICE_PLEASE_SELECT")
	};

	var localData = [];
	localData.push(pso);

	var newar = $.merge(localData, oData.results);

	var jsonModel = new sap.ui.model.json.JSONModel(newar);

	this.getView().setModel(jsonModel, "sections");

};

sap.ui.cms.util.DSRFTSectionService.loadSectionsError = function(error) {
	sap.ui.core.BusyIndicator.hide();

	var computedErrorMessage = sap.ui.cms.util.ErrorMessageBuilder.build(error);
	sap.m.MessageBox.show(computedErrorMessage, sap.m.MessageBox.Icon.ERROR,
			sap.ui.cms.util.LanguageBundle.language.getResourceBundle()
					.getText("CMSCRF_ERROR_TITLE"),
			[ sap.m.MessageBox.Action.CLOSE ]);
};
