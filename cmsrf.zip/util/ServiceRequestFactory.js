jQuery.sap.require("sap.ui.cms.util.ServicesConstants");

jQuery.sap.declare("sap.ui.cms.util.ServiceRequestFactory");
sap.ui.cms.util.ServiceRequestFactory = function() {

	var sc = sap.ui.cms.util.ServicesConstants;

	function isLocalhost() {
		if (location.host.search("localhost") !== -1) {
			return true;
		}
		return false;
	}

	function getHost() {
		return sc.HTTPS + "://" + sc.HOST_PGX_LOCAL + "/";
	}

	return {

		buildURLZCMSDAW : function() {
			var path = sc.PATH;
			var host = getHost();
			var service = sc.SERVICE_NAME_ZCMSDAW;

			var url = "";
			if (isLocalhost()) {
				url = host + path + "/" + service + "/";
				return url;

			} else {
				// var hostUrl = location.protocol + "//" + location.host + "/";
				// url = hostUrl + path + "/" + service + "/";
				url = "/" + path + "/" + service + "/";
				return url;
			}
		},

		buildURLZCONTRACT : function() {
			var path = sc.PATH;
			var host = getHost();
			var service = sc.SERVICE_NAME_ZCONTRACT;

			var url = "";
			if (isLocalhost()) {
				url = host + path + "/" + service + "/";
				return url;

			} else {
				url = "/" + path + "/" + service + "/";
				return url;
			}
		}
	}

};