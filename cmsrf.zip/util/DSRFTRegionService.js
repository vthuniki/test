jQuery.sap.require("sap.ui.cms.util.ErrorMessageBuilder");
jQuery.sap.require("sap.ui.cms.util.LanguageBundle");
jQuery.sap.require("sap.ui.cms.util.ServicesConstants");
jQuery.sap.require("sap.ui.cms.util.ServiceRequestFactory");
jQuery.sap.declare("sap.ui.cms.util.DSRFTRegionService");

sap.ui.cms.util.DSRFTRegionService = {};

sap.ui.cms.util.DSRFTRegionService.loadRegions = function(context) {
	var sc = sap.ui.cms.util.ServicesConstants;
	var srf = new sap.ui.cms.util.ServiceRequestFactory();

	var requestURL = sc.REQUEST_TYPE_DETAILS_SET + sc.PARENTID_EQ + "'"
			+ sc.NULL + "' " + sc.AND + " "+ sc.LIST_TYPE_EQ + "'" + sc.LIST_TYPE_R
			+ "'";
	
	var oModel = new sap.ui.model.odata.ODataModel(srf.buildURLZCONTRACT(),
			true);
	sap.ui.core.BusyIndicator.show();
	oModel.read(requestURL, null, null, true,
			sap.ui.cms.util.DSRFTRegionService.loadRegionSuccess.bind(context),
			sap.ui.cms.util.DSRFTRegionService.loadRegionError.bind(context));
};

sap.ui.cms.util.DSRFTRegionService.loadRegionSuccess = function(oData, response) {

	sap.ui.core.BusyIndicator.hide();
	util.Service.checkForSessionTimeout(response);
	var sc = sap.ui.cms.util.ServicesConstants;
	var pso = {
		ListID : "RSEL01",
		ParentID : "NULL",
		ListType : sc.LIST_TYPE_R,
		ListDescription : sap.ui.cms.util.LanguageBundle.language
				.getResourceBundle().getText("CMSCRF_SERVICE_PLEASE_SELECT")
	};

	var localData = [];
	localData.push(pso);

	var newar = $.merge(localData, oData.results);

	var jsonModel = new sap.ui.model.json.JSONModel(newar);

	this.getView().setModel(jsonModel, "regions");

};

sap.ui.cms.util.DSRFTRegionService.loadRegionError = function(error) {
	sap.ui.core.BusyIndicator.hide();

	var computedErrorMessage = sap.ui.cms.util.ErrorMessageBuilder.build(error);
	sap.m.MessageBox.show(computedErrorMessage, sap.m.MessageBox.Icon.ERROR,
			sap.ui.cms.util.LanguageBundle.language.getResourceBundle()
					.getText("CMSCRF_ERROR_TITLE"),
			[ sap.m.MessageBox.Action.CLOSE ]);
};
