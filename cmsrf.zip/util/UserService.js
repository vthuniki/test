jQuery.sap.require("sap.ui.cms.util.ErrorMessageBuilder");
jQuery.sap.require("sap.ui.cms.util.LanguageBundle");
jQuery.sap.require("sap.ui.cms.util.ServicesConstants");
jQuery.sap.require("sap.ui.cms.util.ServiceRequestFactory");
jQuery.sap.declare("sap.ui.cms.util.UserService");

sap.ui.cms.util.UserService = {};

sap.ui.cms.util.UserService.loadUser = function(context) {
	var sc = sap.ui.cms.util.ServicesConstants;
	var srf = new sap.ui.cms.util.ServiceRequestFactory();

	var requestURL = sc.USER_ENTITY_QUERY;

	var oModel = new sap.ui.model.odata.ODataModel(srf.buildURLZCMSDAW(), true);
	sap.ui.core.BusyIndicator.show();
	oModel.read(requestURL, null, null, true,
			sap.ui.cms.util.UserService.loadUSerSuccess.bind(context),
			sap.ui.cms.util.UserService.loadUserError.bind(context));
};

sap.ui.cms.util.UserService.loadUSerSuccess = function(oData, response) {
	sap.ui.core.BusyIndicator.hide();
	util.Service.checkForSessionTimeout(response);

	sap.ui.cms.NotesGlobal.currentUser = {};
	sap.ui.cms.NotesGlobal.currentUser.email = oData.Email;
	sap.ui.cms.NotesGlobal.currentUser.firstName = oData.Firstname;
	sap.ui.cms.NotesGlobal.currentUser.lastName = oData.Lastname;
	sap.ui.cms.NotesGlobal.currentUser.userId = oData.Userid;
	sap.ui.cms.NotesGlobal.currentUser.fullName = oData.Fullname;
};

sap.ui.cms.util.UserService.loadUserError = function(error) {
	sap.ui.core.BusyIndicator.hide();

	var computedErrorMessage = sap.ui.cms.util.ErrorMessageBuilder.build(error);
	sap.m.MessageBox.show(computedErrorMessage, sap.m.MessageBox.Icon.ERROR,
			sap.ui.cms.util.LanguageBundle.language.getResourceBundle()
					.getText("CMSCRF_ERROR_TITLE"),
			[ sap.m.MessageBox.Action.CLOSE ]);
};
