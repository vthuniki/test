jQuery.sap.declare("sap.ui.cms.util.ServicesConstants");


sap.ui.cms.util.ServicesConstants = {};

sap.ui.cms.util.ServicesConstants.define = function(name, value) {
	Object.defineProperty(sap.ui.cms.util.ServicesConstants, name
			.toUpperCase(), {
		"value" : value,
		"writable" : false,
		"configurable" : false
	});
};


sap.ui.cms.util.ServicesConstants.define("HTTPS", "https");
sap.ui.cms.util.ServicesConstants.define("HTTP", "http");

sap.ui.cms.util.ServicesConstants.define("HOST_PGX_LOCAL",
"pgxmain.wdf.sap.corp");

sap.ui.cms.util.ServicesConstants.define("HOST_PGD_LOCAL",
"pgdmain.wdf.sap.corp");

sap.ui.cms.util.ServicesConstants.define("HOST_PGT_LOCAL",
"pgtmain.wdf.sap.corp");

sap.ui.cms.util.ServicesConstants.define("HOST_PGV_LOCAL",
"pgvmain.wdf.sap.corp");

sap.ui.cms.util.ServicesConstants.define("PATH", "sap/opu/odata/sap");

sap.ui.cms.util.ServicesConstants.define("SERVICE_NAME_ZCMSDAW", "ZCMS_DAW_SRV");

sap.ui.cms.util.ServicesConstants.define("SERVICE_NAME_ZCONTRACT", "ZCONTRACTRF_SRV");

sap.ui.cms.util.ServicesConstants.define("USER_ENTITY_QUERY", "UserdataSet(Userid='')");

sap.ui.cms.util.ServicesConstants.define("INSERTNOTES_ENTITY_QUERY", "InsertNotesSet");

sap.ui.cms.util.ServicesConstants.define("DOCUMENT_NOTES_SET_PART1", "DocumentNotesSet?$filter= FK3 eq '");
sap.ui.cms.util.ServicesConstants.define("DOCUMENT_NOTES_SET_PART2", "' and MessageId eq '002' and Mode eq 1 ");

sap.ui.cms.util.ServicesConstants.define("REQUEST_TYPE_DETAILS_SET", "RequestTypeDetails_Set/?$filter=");
sap.ui.cms.util.ServicesConstants.define("PARENTID_EQ", "ParentID eq ");
sap.ui.cms.util.ServicesConstants.define("LIST_TYPE_EQ", "ListType eq ");
sap.ui.cms.util.ServicesConstants.define("LIST_TYPE_R", "R");
sap.ui.cms.util.ServicesConstants.define("LIST_TYPE_C", "C");
sap.ui.cms.util.ServicesConstants.define("LIST_TYPE_S", "S");
sap.ui.cms.util.ServicesConstants.define("LIST_TYPE_T", "T");
sap.ui.cms.util.ServicesConstants.define("LIST_TYPE_L", "L");
sap.ui.cms.util.ServicesConstants.define("LTSEPARATOR", "@");
sap.ui.cms.util.ServicesConstants.define("NULL", "NULL");
sap.ui.cms.util.ServicesConstants.define("AND", "and");