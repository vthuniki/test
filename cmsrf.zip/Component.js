jQuery.sap.declare("sap.ui.cms.Component");
jQuery.sap.require("sap.ui.cms.MyRouter");
var flagg = 0;   //C5299813
var test;
var type;
var language;
var sales_org;  //C5299813 /new params adding
var CPQIDValue; //C5325212 /new param
var CMSCASEIDValue; //C5325212 /new param
var requestFormType;
var salesOrgID;
var currentUser;
var mainModel;
var objectID;
var tracking;
var serviceUrl = "/sap/opu/odata/sap/";
var objectIDString = "OBJECT_ID";
//file size in MB
var maxAttachmentSize = 5;
var comp;
sap.ui.core.UIComponent
	.extend(
		"sap.ui.cms.Component", {
			metadata: {
				name: "Contract Management",
				version: "1.0",
				includes: ["css/style.css"], // css, javascript files that should be used in the component
				dependencies: {
					libs: ["sap.m", "sap.ui.layout", "sap.ui.commons", "sap.ui.unified", "sap.ui.ux3"],
					components: [],
					//			ui5version : "" // the version of SAP UI5 that your component requires
				},

			"sap.app": {
					"applicationVersion": {
						"version": "1.0"
					}
				},
				"sap.ui5": {
					"config": {
						"reportingId": "CMSCRF",
						"reportingHosts": ["cmsrf-sapitcloudt.dispatcher.hana.ondemand.com"]
					}
				},

				rootView: "sap.ui.cms.view.App",

				config: {
					sapFiori2Adaptation: true,
					resourceBundle: "i18n/messageBundle.properties",
					"titleResource": "CMSRF",
					"appName": "cmsrf",
					"ignoreComponent": true,
					"supportTeam": "jochen.winkler@sap.com;vijay.vikram@sap.com",
					serviceConfig: {
						name: "backend",
						serviceUrl: "/sap/opu/odata/sap/ZCONTRACTRF_SRV/"
					}
				},
				routing: {
					config: {
						routerClass: sap.ui.cms.MyRouter,
						viewType: "XML",
						viewPath: "sap.ui.cms.view",
						targetAggregation: "pages",
						clearTarget: false
					},
					routes: [{
							pattern: "",
							name: "home",
							viewPath: "sap.ui.cms.view",
							view: "Home",
							targetAggregation: "pages",
							targetControl: "idAppControl",
							subroutes: []
						}, {
							pattern: "LANGUAGE={language}",
							name: "homeLanguage",
							viewPath: "sap.ui.cms.view",
							view: "Home",
							targetAggregation: "pages",
							targetControl: "idAppControl",
							subroutes: []
						}, {
							pattern: "OBJECT_ID={id}",
							name: "homeObjectID",
							viewPath: "sap.ui.cms.view",
							view: "Home",
							targetAggregation: "pages",
							targetControl: "idAppControl",
							subroutes: []
						}, {
							pattern: "OBJECT_ID={id}/LANGUAGE={language}",
							name: "homeObjectIDLang",
							viewPath: "sap.ui.cms.view",
							view: "Home",
							targetAggregation: "pages",
							targetControl: "idAppControl",
							subroutes: []
						},
						/*Begin of C5288178*/
						/*{
							pattern: "REQUESTFORM_TYPE={type}/SALESORG_ID={salesorgid}", 
							name: "homeRequestTypeSO",
							viewPath: "sap.ui.cms.view",
							view: "Home",
							targetAggregation: "pages",
							targetControl: "idAppControl",
							subroutes: []
							},*/
						/*End of C5288178*/
						{
							pattern: "REQUESTFORM_TYPE={type}",
							name: "homeRequestType",
							viewPath: "sap.ui.cms.view",
							view: "Home",
							targetAggregation: "pages",
							targetControl: "idAppControl",
							subroutes: []
						}, {
							// LANGUAGE={language}" -C5204479-Language Param Remove-start
							/*pattern: "REQUESTFORM_TYPE={type}/LANGUAGE={language}", */
							// pattern: "REQUESTFORM_TYPE={type}/SALESORG_ID=:salesorgid:/LANGUAGE={language}", 
							pattern: "REQUESTFORM_TYPE={type}/LANGUAGE={language}",
							name: "homeRequestTypeLang",
							viewPath: "sap.ui.cms.view",
							view: "Home",
							targetAggregation: "pages",
							targetControl: "idAppControl",
							subroutes: []
						} 
						, {
							// Begin of Insert C5299813 - New parameter added
							pattern: "REQUESTFORM_TYPE={type}/LANGUAGE={language}/SALES_ORG={sales_org}/CPQ_ID={cpq_id}/CMS_CASE_ID={cms_case_id}",
							name: "homeRequestTypeLangSalesOrg",
							viewPath: "sap.ui.cms.view",
							view: "Home",
							targetAggregation: "pages",
							targetControl: "idAppControl",
							subroutes: []
						}
					]
				}

			},
			createContent: function () {
				comp = this;
				// create root view. has to be a JS-view for reasons...
				this.oView = sap.ui.view({
					id: this.createId("idAppControl"),
					viewName: "sap.ui.cms.view.App",
					type: "XML",
					viewData: {
						component: this
					}
				});

				return this.oView;
			},
			init: function () {

				sap.git = sap.git || {};
				sap.git.usage = sap.git.usage || {};
				sap.git.usage.Reporting = {
					_lp: null,
					_load: function (a) {
						this._lp = this._lp || sap.ui.getCore().loadLibrary("sap.git.usage", {
							url: "https://trackingshallwe.hana.ondemand.com/web-client/v3",
							async: !0
						}), this._lp.then(function () {
							a(sap.git.usage.MobileUsageReporting);
						}, this._loadFailed);
					},
					_loadFailed: function (a) {
						jQuery.sap.log.warning("[sap.git.usage.MobileUsageReporting]", "Loading failed: " + a);
					},
					setup: function (a) {
						this._load(function (b) {
							b.setup(a);
						});
					},
					addEvent: function (a, b) {
						this._load(function (c) {
							c.addEvent(a, b);
						});
					},
					setUser: function (a, b) {
						this._load(function (c) {
							c.setUser(a, b);
						});
					}
				};

				sap.git.usage.Reporting.setup(this);
				//start change
				sap.ui.getCore().getConfiguration().applySettings({
					language: "en"
				});
				//end change
				jQuery.sap.registerModulePath("sap.ui.custom", jQuery.sap.getModulePath("sap.ui.cms") + "/custom/");
				sap.ui.cms.GlobalRegistry = {};
				sap.ui.cms.NotesGlobal = {};
				sap.ui.cms.NotesGlobal.notesModel = new sap.ui.model.json.JSONModel();
				sap.ui.cms.NotesGlobal.notesModel.setData([]);
				// C5204479
				sap.ui.cms.copycrf = false;
				sap.ui.core.UIComponent.prototype.init.apply(this,
					arguments);

				var mConfig = this.getMetadata().getConfig();
				var sServiceUrl = mConfig.serviceConfig.serviceUrl;
				// always use absolute paths relative to our own component
				// (relative paths will fail if running in the Fiori Launchpad)
				var rootPath = jQuery.sap.getModulePath("sap.ui.cms");
				// Create and set domain model to the component
				var oModel = new sap.ui.model.odata.ODataModel(rootPath + sServiceUrl, true);
				mainModel = oModel;
				this.setModel(oModel);

				// set i18n model
				var i18nModel = new sap.ui.model.resource.ResourceModel({
					bundleUrl: [rootPath,
						mConfig.resourceBundle
					].join("/")
				});
				this.setModel(i18nModel, "i18n");

				// set config model
				var configModel = new sap.ui.model.json.JSONModel({
					lockMode: "D",
					type: "",
					language: "en",
					showCPTab: true

				});
				configModel.setDefaultBindingMode("OneWay");
				this.setModel(configModel, "config");
				// set device model
				var deviceModel = new sap.ui.model.json.JSONModel({
					isTouch: sap.ui.Device.support.touch,
					isNoTouch: !sap.ui.Device.support.touch,
					isPhone: sap.ui.Device.system.phone,
					isNoPhone: !sap.ui.Device.system.phone,
					listMode: sap.ui.Device.system.phone ? "None" : "SingleSelectMaster",
					listItemType: sap.ui.Device.system.phone ? "Active" : "Inactive"
				});
				deviceModel.setDefaultBindingMode("OneWay");
				this.setModel(deviceModel, "device");
				// C5204479-Start IT Mobile Usage-start
				// jQuery
				// 	.getScript(
				// 		"https://trackingshallwe.hana.ondemand.com/tracking/web-client/web-tracking.js",
				// 		function(data, status, jqxhr) {
				// 			jQuery
				// 				.getScript(
				// 					"https://trackingshallwe.hana.ondemand.com/tracking/web-client/crypto-sha1.js",
				// 					function(data,
				// 						status,
				// 						jqxhr) {
				// 						try {
				// 							tracking = new GlobalITTracking(
				// 								"CMSRF",
				// 								"1.0.0");
				// 						} catch (e) {
				// 							if (console)
				// 								console
				// 								.log("Error: " + e);
				// 						}
				// 					});
				// 		});
				// C5204479-Start IT Mobile Usage-end
				this.getRouter().initialize();

			}
		});