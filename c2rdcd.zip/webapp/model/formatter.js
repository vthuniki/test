sap.ui.define([], function () {
	"use strict";

	return {
	/**
	 * Rounds the number unit value to 2 digits
	 * @public
	 * @param {string} sValue the number string to be rounded
	 * @returns {string} sValue with 2 digits rounded
	 */
	numberUnit: function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		/**
		 * Retruns empty if the value is 0000000000
		 * @public
		 * @param {string} sValue the number string to be checked 
		 * @returns {string} sValue as empty if value is 0000000000
		 */
		contactPerson: function (sValue, sDesc) {
			if (sValue === "0000000000") {
				return "";
			}
			return sDesc + " (" + sValue + ")";
		},

		/**
		 * Retruns Green for Complete, Red for Cancel and nothing for opoen  
		 * @public
		 * @param {string} sValue is Invoice status kay 
		 */
		formatRowHighlight: function (sValue) {
			// Your logic for rowHighlight goes here
			if (sValue === "A") {
				return "Success";
			} else if (sValue === "B") {
				return "None";
			} else if (sValue === "C") {
				return "Error";
			}

			//return "Success";
		},
		/**
		 * Retruns '' if the value is 00000000
		 * @public
		 */
		prcPrEndDate: function (sValue) {
			if (sValue === "00000000") {
				return "";
			}
			return sValue;
		},
		/** to show icon for price protection/future discount right in product description
		 */
		productDescription: function (futureDisEndDate, priceProctEndDate, sRevenueType) {
			var that = this;
			// var sPath="/DCDCustomEntitySet(BUSINESSPARTNER='"+sBpNumber+"',"+"CASE_ID='"+sCaseId+"',"+"ERPNUMBER='"+sErpNumber+"')";
			// var rowData=this.getOwnerComponent().getModel().getData(sPath);
			var currDate = that.dateFormatter(new Date());
			var showMessage = false;

			if (sRevenueType === "Cl") {
				if (priceProctEndDate !== "" && priceProctEndDate !== null) {
					var priceProtectDate = that.dateFormatter(priceProctEndDate, "PRC_PROTECTION_END_DATE");
					if (priceProtectDate >= currDate) {
						showMessage = true;
					}
				}
			} else if (sRevenueType === "On") {
				if (futureDisEndDate !== "" && futureDisEndDate !== null) {
					var futureDiscDate = that.dateFormatter(futureDisEndDate);
					if (futureDiscDate >= currDate) {
						showMessage = true;
					}
				}
			}
			return showMessage;
		},

		//to show icon for swap exchange right in product description
		productDescriptionExchange: function (exchangeSwapRightEndDate, sRevenueType) {
			var that = this;
			// var sPath="/DCDCustomEntitySet(BUSINESSPARTNER='"+sBpNumber+"',"+"CASE_ID='"+sCaseId+"',"+"ERPNUMBER='"+sErpNumber+"')";
			// var rowData=this.getOwnerComponent().getModel().getData(sPath);
			var currDate = that.dateFormatter(new Date());
			var showMessage = false;

			if (sRevenueType === "Cl" || sRevenueType === "On") {
				if (exchangeSwapRightEndDate !== "" && exchangeSwapRightEndDate !== null) {
					var exchangeDate = that.dateFormatter(exchangeSwapRightEndDate);
					if (exchangeDate >= currDate) {
						showMessage = true;
					}
				}
			}
			return showMessage;
		},

		getServiceContractText: function (sServiceContract) {
			if (sServiceContract) {
				var aServiceContract = sServiceContract.split(",");
				if (aServiceContract.length > 1) {
					return "Multiple SC's";
				} else {
					return aServiceContract[0].split(":")[1];
				}
			}
			return "";
		},
		getServiceContractGuid: function (sServiceGuid) {
			if (sServiceGuid) {
				var aServiceContract = sServiceGuid.split(",");
				if (aServiceContract.length > 1) {
					return "Multiple Guid's";
				} else {
					return aServiceContract[0].split(":")[0];
				}
			}
			return "";
		},
		getSalesOrderText: function (sSalesOrder) {
			if (sSalesOrder) {
				var aSalesOrder = sSalesOrder.split(",");
				if (aSalesOrder.length > 1) {
					return "Multiple SO's";
				} else {
					return aSalesOrder[0].split(":")[1];
				}
			}
			return "";
		},
		getSalesOrderType: function (sSalesOrder) {
			if (sSalesOrder) {
				var aSalesOrder = sSalesOrder.split(",");
				if (aSalesOrder.length > 1) {
					return "Multiple Type's";
				} else {
					return aSalesOrder[0].split(":")[0];
				}
			}
			return "";
		}

};
});