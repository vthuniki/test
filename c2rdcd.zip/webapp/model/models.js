sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {
		//app Congiguration model
		createAppConfigModel: function () {
			var root = jQuery.sap.getModulePath("c2r.c2rdcd");
			var appData = {
				"NavigationEnabled": false,
				"protocol": "https://",
				"url": ".wdf.sap.corp/",
				"networkVBOrder":"sap/bc/bsp/sap/crm_ui_start/default.htm?crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-type=BT116_SRVO&crm-object-value=",
				"crmUrl": "sap(bD1lbiZjPTAwMSZkPW1pbiZpPTE=)/crm_logon/default.htm?crm-object-type=",
				"crmUrlAccount": "sap(bD1lbiZjPTAwMSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?crm-object-type=",
				"crmSalesUrlAccount": "sap(bD1lbiZjPTAwMSZ0PXNhcF9jb3JidSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?crm-object-type=",
				"crmUrlCase": "sap/bc/webdynpro/sap/zv_cms_rcm_wda_case?CASE_ID=",
				"crmUrlCaseMode": "&CASE_MODE=D&sap-wd-configid=ZV_CMS_RCM_WAC_CASE&sap-accessibility=&sap-theme=#",
				"crmUrlAction": "&crm-object-action=",
				"crmUrlValue": "&crm-object-value=",
				"crmUrlKeyName": "&crm-object-keyname=",
				"sapRole": "&saprole=ZSM_GENERAL",
				"sapRolep": "&saprole=ZK_GENERAL",
				"flpUrlDev": "flpsandbox-br339jmc4c.dispatcher.int.sap.eu2.hana.ondemand.com",
				"flpUrlTest": "fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com",
				"flpUrlProd": "fiorilaunchpad.sap.com",
				"flpHarmony": "/sites?sap-ushell-config=standalone#harmonyquote-Display&",
				"flpArm": "/sites#arm-Create&/createRequest",
				"flpOpp": "/Opportunity/",
				"flpQuote": "/Quotedetails/",
				"disclaimer": null,
				"dcdCockpitImg": root + "/images/DCD_Cockpit.PNG",
				"dcdCockpitVideo": root + "/images/DCD_Cockpit_Full_Demo_V3.mp4",
				"errorText":'',
				"glossaryUpload": null, 
				"adminKey": null,
				"nodes": [],
				"lines": [],
				"groups": [],
				"caseNodes": [],
				"caseLines": [],
				"caseGroups": [],
				"accountId": "",
				"erpNumber": "",
				"ngAccountId": "",
				"ngCaseId": "",
				"ngOrientation": "LeftRight",
				"AdminAccess": false,
				"ObjectPageFlag":false,
				"overviewPageFlag":false,
				"ServiceQuoteAnalyzer" : "sap-sac.eu10.sapanalytics.cloud/sap/fpa/ui/tenants/1fcd2/app.html#/analyticapp&/aa/7F92405128A8DE4D873B2183985C4D2/?resourceSubType=APPLICATION&resourceType=STORY&mode=view",
				"cloudReporting": "reporting.ondemand.com/sap/crp/cdo?type=crp_c&id=",
				"cloudReportingOrder": "#SP_Orders",
				"onPremReporting": "sap/bc/gui/sap/its/webgui/?&~transaction=*ZDCD_OP_PROD_REPORT%20S_KUNNR-LOW=",
				"SWContractToolboxReport": "sap/bc/gui/sap/its/webgui/?&~transaction=*ZDCD_OP_PROD_RPT_NEW%20S_KUNNR-LOW=",
				"oPopAriflow": "https://objectflowapp-sapitcloud.dispatcher.hana.ondemand.com/webapp/index.html#objectflowForObject/002,CASE,",
				"oPopAriflowtest":"https://objectflowapp-sapitcloudt.dispatcher.hana.ondemand.com/webapp/index.html#objectflowForObject/002,CASE,",
			    "oPopAriflowdev":"https://objectflowapp-sapitcloudt.dispatcher.hana.ondemand.com/webapp/index.html#objectflowForObject/002,CASE,",
			    "oPopAriflowServices":"https://ariflow.cfapps.eu10-004.hana.ondemand.com/index.html#objectflowForObject/001,CASE,",
				"maintenanceLandscape":"sap/bc/gui/sap/its/webgui/?&~transaction=*ZDCD_ML_PROD%20S_KUNNR-LOW=",
				"onPremSalesDoc": "sap/bc/gui/sap/its/webgui?~transaction=*VA03%20VBAK-VBELN=", 
				"hierarchyUrlDev": "harmonyinsight-eacpv.dispatcher.hana.ondemand.com/index.html#/general_sales_user/",
				"hierarchyUrlTest": "harmonyinsight-eacpt.dispatcher.hana.ondemand.com/index.html#/general_sales_user/",
				"hierarchyUrlProd": "harmony-insight.enter.sap/index.html#/general_sales_user/",
				"hierarchySell": "/sell",
				"globalGroup": "globalGroup/",
				"planningGroup": "globalGroup:",
				"planningEntity": "planningEntity/",
				"account": "account/",
				"showFilter": true,
				"invoiceDisclaimer": "DCD Cockpit displays unpaid invoices for last 5 years and all invoices for last year. If you are unable to see invoices, contact <a target='_blank' href='https://jam4.sapjam.com/groups/012IgHM45LoBVNlqmhne0R/overview_page/GZSQKlB36Q1AcVUOMYyyBk?edit_mode=true'>Cash collection team</a>",
				"invoiceError": "Invoices cannot be displayed due to technical limitations. Contact <a target='_blank' href='https://jam4.sapjam.com/groups/012IgHM45LoBVNlqmhne0R/overview_page/GZSQKlB36Q1AcVUOMYyyBk?edit_mode=true'>Cash collection team</a> for assistance.",
				"jamPageUrl":"wiki.wdf.sap.corp/wiki/pages/viewpage.action?spaceKey=DCD&title=Digital+Contract+Data+%28Contract+Digitalization%29+Home",
				"sharePoint":"sap.sharepoint.com/sites/124860/SitePages/Contract-Digitalization.aspx?csf=1&web=1&e=uxHDUK",
				"CRMWEBUI" : ".wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?crm-object-type=",
				"BT112_SC" : "BT112_SC",
				"CRMOBJ" : "&crm-object-action=B&crm-object-value=",
				"SalesOrder43" : "sap/bc/gui/sap/its/webgui?~transaction=*VA43%20VBAK-VBELN=",
				"SalesOrder03" : "sap/bc/gui/sap/its/webgui?~transaction=*VA03%20VBAK-VBELN=",
				"noSplash" : "&~NOSPLASH=1",
				"onBillingReport" : "sap/bc/gui/sap/its/webgui/?&~transaction=*ZT_DCD_BILL_PROJECT%20S_REFID-LOW="//ITSDEDLC-422
				
				
			};
			var oModel = new JSONModel(appData);
			oModel.setSizeLimit(2000);
			return oModel;
		},

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		createFLPModel: function () {
			var fnGetUser = jQuery.sap.getObject("sap.ushell.Container.getUser"),
				bIsShareInJamActive = fnGetUser ? fnGetUser().isJamActive() : false,
				oModel = new JSONModel({
					isShareInJamActive: bIsShareInJamActive
				});
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		}

	};

});