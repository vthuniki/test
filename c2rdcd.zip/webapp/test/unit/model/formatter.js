/*global QUnit*/

sap.ui.define([
		"c2r/c2rdcd/model/formatter"
	], function (formatter) {
		"use strict";

		QUnit.module("Number unit");

		function numberUnitValueTestCase(assert, sValue, fExpectedNumber) {
			// Act
			var fNumber = formatter.numberUnit(sValue);

			// Assert
			assert.strictEqual(fNumber, fExpectedNumber, "The rounding was correct");
		}

		QUnit.test("Should round down a 3 digit number", function (assert) {
			numberUnitValueTestCase.call(this, assert, "3.123", "3.12");
		});

		QUnit.test("Should round up a 3 digit number", function (assert) {
			numberUnitValueTestCase.call(this, assert, "3.128", "3.13");
		});

		QUnit.test("Should round a negative number", function (assert) {
			numberUnitValueTestCase.call(this, assert, "-3", "-3.00");
		});

		QUnit.test("Should round an empty string", function (assert) {
			numberUnitValueTestCase.call(this, assert, "", "");
		});

		QUnit.test("Should round a zero", function (assert) {
			numberUnitValueTestCase.call(this, assert, "0", "0.00");
		});
		
		
		// Row highlighting status test
		QUnit.module("Invoice Row Highlighting");
		
		function rowHighlightingTestCase(assert, sValue, fExpectedResult) {
			// Act
			var fValue = formatter.formatRowHighlight(sValue);

			// Assert
			assert.strictEqual(fValue, fExpectedResult, "The row highlighting was correct");
		}
		
		QUnit.test("Should return success when pdf status is A", function (assert) {
			rowHighlightingTestCase.call(this, assert, "A", "Success");
		});
		
		QUnit.test("Should return none when pdf status is B", function (assert) {
			rowHighlightingTestCase.call(this, assert, "B", "none");
		});
		
		QUnit.test("Should return error when pdf status is C", function (assert) {
			rowHighlightingTestCase.call(this, assert, "C", "Error");
		});
		
		
		// Contact person display test
		QUnit.module("Contact Person");
		
		function contactPersonTestCase(assert, sValue, sDesc, fExpectedResult) {
			// Act
			var fValue = formatter.contactPerson(sValue, sDesc);

			// Assert
			assert.strictEqual(fValue, fExpectedResult, "The contact person was correct");
		}
		
		QUnit.test("Should return Blank when contact person number is 0000000000", function (assert) {
			contactPersonTestCase.call(this, assert, "0000000000", "Description", "");
		});
		
		QUnit.test("Should return the contact person number with description", function (assert) {
			contactPersonTestCase.call(this, assert, "test", "Description", "Description (test)");
		});
	}
);
