/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit",
	"./pages/Worklist",
	"./pages/App"
], function (opaTest) {
	"use strict";

	QUnit.module("Worklist");

	opaTest("Should see the table with all entries", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		// Assertions
		Then.onTheWorklistPage.theTableShouldHaveAllEntries();
		// Cleanup
		Then.iTeardownMyAppFrame();
	});

	opaTest("The link contains the correct account Details", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();
		//Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iSeetheItemContainTheAccountId(1);
		// Assertions
		Then.onTheWorklistPage.iShouldSeeNewWindow();
		// Cleanup
		Then.iTeardownMyAppFrame();
	});
	opaTest("Should open the admin menu", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();
		//Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iPressTheAdminTab();
		// Assertions
		Then.onTheWorklistPage.iShouldSeeTheAdminMenu();
		// Cleanup
		Then.iTeardownMyAppFrame();
	});
	opaTest("Should open the information tab under the admin menu and edit the Text and saving it", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();

		//Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iPressTheAdminTab().
		and.iPressTheAdminInformationTab(2).
		and.iEditTheOverviewText(0).
		and.iPressTheFooterButton(3, 0);
		// Assertions
		Then.onTheWorklistPage.iShouldSeeTheSavedMessage();
	});
	opaTest("Should open the information tab under the admin menu and preview the edited text", function (Given, When, Then) {
		// //Actions
		When.onTheWorklistPage.iPressTheFooterButton(1, 0).
		and.iPressThePreviewSaveButton(0);
		// Assertions
		Then.onTheWorklistPage.iShouldSeeThePreviewMessage();
		// Cleanup
		Then.iTeardownMyAppFrame();
	});
	opaTest("Should open the information tab under the admin menu and edit the Text and saving it in authorization", function (Given, When,
		Then) {
		// Arrangements
		Given.iStartMyApp();
		//Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iPressTheAdminTab().
		and.iPressTheAdminInformationTab(2).
		and.iPressTheAuthButton(1).
		and.iEditTheOverviewText(1).
		and.iPressTheFooterButton(3, 1);
		// Assertions
		Then.onTheWorklistPage.iShouldSeeTheSavedMessage();
	});
	opaTest("Should open the information tab under the admin menu and preview the edited text in authorization", function (Given, When, Then) {
		// //Actions
		When.onTheWorklistPage.iPressTheFooterButton(1, 1).
		and.iPressThePreviewSaveButton(1);
		// Assertions
		Then.onTheWorklistPage.iShouldSeeThePreviewMessage();
		// Cleanup
		Then.iTeardownMyAppFrame();
	});
	opaTest("Should see the busy indicator on app view while worklist view metadata is loaded", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp({
			delay: 5000
		});
		// Assertions
		Then.onTheAppPage.iShouldSeeTheBusyIndicatorForTheWholeApp();
	});

	opaTest("Should see the busy indicator on worklist table after metadata is loaded", function (Given, When, Then) {
		//Actions
		When.onTheAppPage.iWaitUntilTheAppBusyIndicatorIsGone();

		// Assertions
		Then.onTheWorklistPage.iShouldSeeTheWorklistTableBusyIndicator();

		// Cleanup
		Then.iTeardownMyAppFrame();
	});

});