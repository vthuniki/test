/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit",
	"./pages/App",
	"./pages/Overview"
], function (opaTest) {
	"use strict";

	QUnit.module("Overview");

	opaTest("Should redirect to mail when Report Data Issue Icon is clicked", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();

		// Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iRememberTheItemAtPosition(2);
		When.onTheBrowser.iChangeTheHashToTheRememberedItem();
		When.onTheBrowser.iChangeTheHashToOverview(1);
		When.onTheOverview.iHighLightTheText();

		// Assertions
		Then.onTheOverview.iOpenTheEmail();
	});
	opaTest("Should open print screen", function (Given, When, Then) {
		//  Actions
		When.onTheOverview.iDownloadThePdf();

		// Assertions
		Then.onTheOverview.iSeeThePdfPopup();
	});
	opaTest("Should click on deal from overview", function (Given, When, Then) {
		// //  Actions
		When.onTheOverview.iDealStructSection("idDealStructSection");

		// Assertions
		Then.onTheOverview.iSeeSelectedTab("idDealStructSection");
	});
	opaTest("Should click on product tab", function (Given, When, Then) {
		// //  Actions
		When.onTheOverview.iDealStructSection("idProductsSection");

		// Assertions
		Then.onTheOverview.iSeeSelectedTab("idProductsSection");
	});
	opaTest("Should open the cloud reporting tab", function (Given, When, Then) {
		// // Actions
		When.onTheOverview.iClickTheCloudReportingButton();
		// Assertions
		Then.onTheOverview.iSeeSelectedTab("idProductsSection");
	});
	opaTest("Should open the onPrem reporting tab", function (Given, When, Then) {
		// Actions
		When.onTheOverview.iClickTheOnPremReportingButton();
		// Assertions
		Then.onTheOverview.iSeeSelectedTab("idProductsSection");
	});
	opaTest("Should click on clause tab", function (Given, When, Then) {
		//  Actions
		When.onTheOverview.iDealStructSection("idCClausesSection");

		// Assertions
		Then.onTheOverview.iSeeSelectedTab("idCClausesSection");
	});
	opaTest("Should click on contract tab", function (Given, When, Then) {
		//  Actions
		When.onTheOverview.iDealStructSection("idCContractsSection");

		// Assertions
		Then.onTheOverview.iSeeSelectedTab("idCContractsSection");
	});
	opaTest("Should click on date section tab", function (Given, When, Then) {
		//  Actions
		When.onTheOverview.iDealStructSection("idDatesSection");

		// Assertions
		Then.onTheOverview.iSeeSelectedTab("idDatesSection");
	});
	// opaTest("Should click on maintanance tab", function (Given, When, Then) {
	// 	//  Actions
	// 	When.onTheOverview.iDealStructSection("idMaintenanceSection");

	// 	// Assertions
	// 	Then.onTheOverview.iSeeSelectedTab("idMaintenanceSection");
	// });
	// opaTest("Should click on operation tab", function (Given, When, Then) {
	// 	// //  Actions
	// 	When.onTheOverview.iDealStructSection("idOperationsSection");

	// 	// Assertions
	// 	Then.onTheOverview.iSeeSelectedTab("idOperationsSection");
	// });
	opaTest("Should click on payment&invoicing tab", function (Given, When, Then) {
		//  Actions
		When.onTheOverview.iDealStructSection("idPNISection");

		// Assertions
		Then.onTheOverview.iSeeSelectedTab("idPNISection");
	});
	opaTest("Should click on overview tab", function (Given, When, Then) {
		// //  Actions
		When.onTheOverview.iDealStructSection("idOverviewSection");

		// Assertions
		Then.onTheOverview.iSeeSelectedTab("idOverviewSection");
		Then.iTeardownMyAppFrame();
	});

});