sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/actions/EnterText",
	"./Common",
	"./shareOptions",
	"sap/ui/test/matchers/AggregationFilled"
], function (Opa5, Press, EnterText, Common, shareOptions, AggregationFilled) {
	"use strict";

	var sViewName = "Overview";
	Opa5.createPageObjects({

		onTheOverview: {
			baseClass: Common,

			actions: jQuery.extend({

				iHighLightTheText: function () {
					return this.waitFor({
						id: "bpovp",
						viewName: sViewName,
						success: function (oLabel) {
							var node = oLabel.getDomRef();
							var iOpaFrame = document.getElementById("OpaFrame");
							var w = iOpaFrame.contentWindow;
							var iDoc = iOpaFrame.contentDocument;
							var selection = w.getSelection();
							var range = iDoc.createRange();
							range.selectNodeContents(node);
							selection.removeAllRanges();
							selection.addRange(range);
						}
					});
				},
				iDownloadThePdf: function () {
					return this.waitFor({
						id: "sPDFDownloadButton",
						viewName: sViewName,
						success: function (oButton) {
							oButton.$().trigger("tap");
						}
					});
				},
				iDealStructSection: function (toSelectSection) {
					return this.waitFor({
						id: "idDCDPageObjectLayoutOVP",
						viewName: sViewName,
						success: function (oObjectPage) {
							return this.waitFor({
								id: toSelectSection,
								viewName: sViewName,
								success: function (oSelectedSection) {
									oObjectPage.setSelectedSection(oSelectedSection);
								},
								errorMessage: "Cannot find Deal Struct Section"
							});
						}
					});
				},
				iClickTheCloudReportingButton: function () {
					return this.waitFor({
						id: "cloudReportingOverViewPage",
						viewName: sViewName,
						actions: new Press()
					});
				},
				iClickTheOnPremReportingButton: function () {
					return this.waitFor({
						id: "onPremReportingOverViewPage",
						viewName: sViewName,
						actions: new Press()
					});
				}
			}, shareOptions.createActions(sViewName)),
			assertions: {
				iShouldSeeOverviewPage: function () {
					return this.waitFor({
						viewName: "Overview",
						success: function (oPage) {
							Opa5.assert.ok(oPage, "Found the Overview Page");
						},
						errorMessage: "Can't see the  Overview Page"
					});
				},
				iOpenTheEmail: function () {
					return this.waitFor({
						id: "sDataIssueButton",
						viewName: sViewName,
						success: function (oButton) {
							oButton.$().trigger("tap");
							return this.waitFor({
								searchOpenDialogs: true,
								success: function (oDialog) {
									oDialog[7].firePress();
									Opa5.assert.ok(true, "Email window is shown");
								}
							});

						}
					});
				},
				iSeeThePdfPopup: function () {
					return this.waitFor({
						success: function () {
							Opa5.assert.ok(true, "Print screen is shown");
						}
					});
				},
				iSeeSelectedTab: function (selectedTab) {
					return this.waitFor({
						id: "idDCDPageObjectLayoutOVP",
						viewName: sViewName,
						matchers: function (oPage) {
							return oPage.getSelectedSection().indexOf(selectedTab) > 0;
						},
						success: function () {
							Opa5.assert.ok(true, selectedTab + "Selected Tab is shown");
						}
					});
				},
				// To check wheather payment & invoices table has entries
				theTableHasEntries: function () {
					return this.waitFor({
						viewName: sViewName,
						id: "CMS_InvoiceTable",
						matchers: new AggregationFilled({
							name: "items"
						}),
						success: function () {
							Opa5.assert.ok(true, "The table has entries");
						},
						errorMessage: "The table had no entries"
					});
				}
			}
		}
	});
});