sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./Common",
	"./shareOptions"
], function (Opa5, Press, EnterText, PropertyStrictEquals, Common, shareOptions) {
	"use strict";

	var sViewName = "Object",
		sHelpSmartIcon = "sHelpSmartIcon",
		sSearch = "searchBtn",
		sSearchGlossary = "searchGlossary";

	function clicksForLinks(oOptions) {
		return {
			id: oOptions.id,
			viewName: sViewName,
			matchers: function (oTable) {
				if (oOptions.tab === 'Case') {
					return oTable.getItems()[1].getItems()[0].getCells()[0].getItems()[0];
				} else if (oOptions.tab === 'Invoice') {
					return oTable.getItems()[1].getItems()[0].getCells()[1];
				} else {
					return oTable.getItems()[1].getItems()[0].getCells()[0].getItems()[1];
				}
			},
			actions: oOptions.actions,
			success: oOptions.success,
			errorMessage: "Table in view '" + sViewName + "' does not contain an Item"
		};
	}
	Opa5.createPageObjects({
		onTheObjectPage: {
			baseClass: Common,

			actions: jQuery.extend({
				iPressTheBackButton: function () {
					return this.waitFor({
						id: "objectPageLayout",
						viewName: sViewName,
						actions: new Press(),
						errorMessage: "Did not find the nav button on object page"
					});
				},
				iSeeImageOnClickOfHelp: function () {
					return this.waitFor({
						id: sHelpSmartIcon,
						viewName: sViewName,
						success: function (oButton) {
							oButton.$().trigger("tap");
						},
						errorMessage: "Did not find the help icon"
					});
				},
				iSeeSearchOnClickOfGlossary: function () {
					return this.waitFor({
						id: sSearch,
						viewName: sViewName,
						success: function (oButton) {
							oButton.$().trigger("tap");
						},
						errorMessage: "Did not find the search field"
					});
				},
				iSeetheItemContainTheCaseId: function (sOverviewTableId) {
					return this.waitFor({
						id: sOverviewTableId,
						viewName: sViewName,
						matchers: function (oTable) {
							var sLink =
								"isd.wdf.sap.corp/sap/bc/webdynpro/sap/zv_cms_rcm_wda_case?CASE_ID=000CASE_ID%201&CASE_MODE=D&sap-wd-configid=ZV_CMS_RCM_WAC_CASE&sap-accessibility=&sap-theme=#",
								sAccount = oTable.getItems()[1].getItems()[0].getBindingContext().getPath().split(',')[1].replace(/[()'\/\\]/g, "").split(
									'=')[1],
								sGeneratedLink = "isd.wdf.sap.corp/sap/bc/webdynpro/sap/zv_cms_rcm_wda_case?CASE_ID=000" + sAccount +
								"&CASE_MODE=D&sap-wd-configid=ZV_CMS_RCM_WAC_CASE&sap-accessibility=&sap-theme=#";

							return sLink === sGeneratedLink;
						},
						actions: new Press(),
						errorMessage: "Table in view '" + sViewName + "' does not contain an Item at position '"
					});
				},
				iSeetheItemNavigateToTheCaseId: function (oTab, sTableId) {
					return this.waitFor(clicksForLinks({
						id: sTableId,
						viewName: sViewName,
						tab: oTab,
						actions: new Press()
					}));
				},
				iSeetheItemNavigateToTheLink: function (param) {
					return this.waitFor({
						viewName: sViewName,
						controlType: "sap.m.ResponsivePopover",
						autoWait: false,
						success: function (oPopover) {
							var sId = (param === "Invoice" ? oPopover[0].getContent()[0].getId() : oPopover[0].getContent()[0].getItems()[0].getCells()[
								0].getId());
							return this.waitFor({
								id: sId,
								matchers: function (oTable) {
									var sLink = "",
										sPath = "";
									if (param === "Invoice") {
										sLink = "DCDInvoiceDataSet(guid'00A4C48C-0DFC-4507-ABC6-9B54A431B788')";
										sPath = oTable.getItems()[0].getCells()[1].getBindingContext().getPath().split("/")[1];
										if (sLink === sPath) {
											return oTable.getItems()[0].getCells()[1];
										}
									} else {
										sLink = "CustomerDataEntitySet('BUSINESSPARTNER%201')";
										sPath = oPopover[0].getContent()[0].getItems()[0].getCells()[0].getBindingContext().getPath().split("/")[1];
										if (sLink === sPath) {
											return oPopover[0].getContent()[0].getItems()[0].getCells()[0];
										}
									}
								},
								actions: new Press(),
								errorMessage: "Table in view  does not contain an Item at position '"
							});
						}
					});
				},
				iDealStructSection: function () {
					return this.waitFor({
						id: "objectPageLayout",
						viewName: sViewName,
						success: function (oObjectPage) {
							var invoiceId = oObjectPage.getSections()[7].getId();
							oObjectPage.setSelectedSection(invoiceId);
						}
					});
				},
				iClickTheCloudReportingButton: function () {
					return this.waitFor({
						id: "objectPageLayout",
						viewName: sViewName,
						success: function (oObjectPage) {
							var invoiceId = oObjectPage.getSections()[2].getId();
							oObjectPage.setSelectedSection(invoiceId);
							return this.waitFor({
								id: "cloudReportingObjectPage",
								viewName: sViewName,
								actions: new Press()
							});
						},
						errorMessage: "Cloud reporting button not found"
					});
				},
				iClickTheOnPremReportingButton: function () {
					return this.waitFor({
						id: "objectPageLayout",
						viewName: sViewName,
						success: function (oObjectPage) {
							var invoiceId = oObjectPage.getSections()[2].getId();
							oObjectPage.setSelectedSection(invoiceId);
							return this.waitFor({
								id: "onPremReportingObjectPage",
								viewName: sViewName,
								actions: new Press()
							});
						},
						errorMessage: "OnPem reporting button not found"
					});
				},
				iClickTheOnMaintananceButton: function () {
					return this.waitFor({
						id: "objectPageLayout",
						viewName: sViewName,
						success: function (oObjectPage) {
							var invoiceId = oObjectPage.getSections()[2].getId();
							oObjectPage.setSelectedSection(invoiceId);
							return this.waitFor({
								id: "onMaintenanceLandscapeObjectPage",
								viewName: sViewName,
								actions: new Press()
							});
						},
						errorMessage: "Maintanence reporting button not found"
					});
				},
				iPressOnHierarchy: function () {
					return this.waitFor({
						id: "hierarchyBtn",
						viewName: sViewName,
						actions: new Press(),
						errorMessage: "Cloud reporting button not found"
					});
				},
				iPressOnCancelInHierarchy: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (oDialog) {
							var cancelButton = oDialog[0].getButtons()[0].getId();
							return this.waitFor({
								id: cancelButton,
								actions: new Press()
							});
						}
					});
				}
			}, shareOptions.createActions(sViewName)),

			assertions: jQuery.extend({

				iShouldSeeTheRememberedObject: function () {
					return this.waitFor({
						success: function () {
							var sBindingPath = this.getContext().currentItem.bindingPath;
							this.waitFor({
								id: "objectPageLayout",
								viewName: sViewName,
								matchers: function (oPage) {
									return oPage.getBindingContext() && oPage.getBindingContext().getPath() === sBindingPath;
								},
								success: function (oPage) {
									Opa5.assert.strictEqual(oPage.getBindingContext().getPath(), sBindingPath, "was on the remembered detail page");
								},
								errorMessage: "Remembered object " + sBindingPath + " is not shown"
							});
						}
					});
				},
				iShouldSeeTheImageBox: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function () {
							Opa5.assert.ok(true, "The correct Image was shown");
						}
					});
				},
				iShouldSeeTheInvoicePopover: function () {
					return this.waitFor({
						controlType: "sap.m.ResponsivePopover",
						autoWait: false,
						success: function (oPopover) {
							Opa5.assert.ok(true, "The correct Popover was shown");
						}
					});
				},
				iShouldSeeTheSearchField: function () {
					return this.waitFor({
						id: sSearchGlossary,
						viewName: sViewName,
						actions: new EnterText({
							text: "field"
						}),
						success: function (oItem) {

							//oItem.setValue("field");
							return this.waitFor({
								success: function () {
									Opa5.assert.ok(true, "The correct searchField was shown");
								}
							});
						},
						errorMessage: "table does not show the no data text for search"
					});
				},
				iShouldSeeNewWindowObject: function (oTabs) {
					return this.waitFor({
						id: oTabs,
						viewName: sViewName,
						success: function (oTable) {
							Opa5.assert.ok(oTable, "Found the details");
						},
						errorMessage: "Can't see the details."
					});
				},
				iShouldSeeTheObjectViewsBusyIndicator: function () {
					return this.waitFor({
						id: "objectPageLayout",
						viewName: sViewName,
						matchers: function (oPage) {
							return oPage.getBusy();
						},
						autoWait: false,
						success: function (oPage) {
							Opa5.assert.ok(oPage.getBusy(), "The object view is busy");
						},
						errorMessage: "The object view is not busy"
					});
				},

				theViewIsNotBusyAnymore: function () {
					return this.waitFor({
						id: "objectPageLayout",
						viewName: sViewName,
						matchers: function (oPage) {
							return !oPage.getBusy();
						},
						autoWait: false,
						success: function (oPage) {
							Opa5.assert.ok(!oPage.getBusy(), "The object view is not busy");
						},
						errorMessage: "The object view is busy"
					});
				},

				theObjectViewsBusyIndicatorDelayIsZero: function () {
					return this.waitFor({
						id: "objectPageLayout",
						viewName: sViewName,
						success: function (oPage) {
							Opa5.assert.strictEqual(oPage.getBusyIndicatorDelay(), 0, "The object view's busy indicator delay is zero.");
						},
						errorMessage: "The object view's busy indicator delay is not zero."
					});
				},

				theObjectViewsBusyIndicatorDelayIsRestored: function () {
					return this.waitFor({
						id: "objectPageLayout",
						viewName: sViewName,
						matchers: new PropertyStrictEquals({
							name: "busyIndicatorDelay",
							value: 1000
						}),
						success: function () {
							Opa5.assert.ok(true, "The object view's busy indicator delay default is restored.");
						},
						errorMessage: "The object view's busy indicator delay is still zero."
					});
				},

				theShareTileButtonShouldContainTheRememberedObjectName: function () {
					return this.waitFor({
						id: "shareTile",
						viewName: sViewName,
						matchers: function (oButton) {
							var sObjectName = this.getContext().currentItem.name;
							var sTitle = oButton.getTitle();
							return sTitle && sTitle.indexOf(sObjectName) > -1;
						}.bind(this),
						success: function () {
							Opa5.assert.ok(true, "The Save as Tile button contains the object name");
						},
						errorMessage: "The Save as Tile did not contain the object name"
					});
				},
				iSeeSelectedTab: function (selectedTab) {
					return this.waitFor({
						id: "objectPageLayout",
						viewName: sViewName,
						matchers: function (oPage) {
							return oPage.getSelectedSection().indexOf(selectedTab) > 0;
						},
						success: function () {
							Opa5.assert.ok(true, selectedTab + "Selected Tab is shown");
						}
					});
				},
				iShouldSeeHierarchyTable: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function () {
							Opa5.assert.ok(true, "The correct Image was shown");
						}
					});
				}
			}, shareOptions.createAssertions(sViewName))
		}
	});
});