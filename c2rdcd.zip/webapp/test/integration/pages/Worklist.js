sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./Common",
	"./shareOptions"
], function (Opa5, Press, EnterText, AggregationLengthEquals, AggregationFilled, PropertyStrictEquals, Common, shareOptions) {
	"use strict";

	var sViewName = "Worklist",
		sTableId = "table",
		sSmartTableId = "ismartTableId",
		sSearchFieldId = "searchField",
		sAdminMenu = "adminMenu",
		sSomethingThatCannotBeFound = "*#-Q@@||";

	function allItemsInTheListContainTheSearchTerm(aControls) {
		var oTable = aControls[0],
			oSearchField = aControls[1],
			aItems = oTable.getItems();

		// table needs items
		if (aItems.length === 0) {
			return false;
		}

		return aItems.every(function (oItem) {
			return oItem.getCells()[0].getTitle().indexOf(oSearchField.getValue()) !== -1;
		});
	}

	function createWaitForItemAtPosition(oOptions) {
		var iPosition = oOptions.position;
		return {
			id: sTableId,
			viewName: sViewName,
			matchers: function (oTable) {
				return oTable.getItems()[iPosition];
			},
			actions: oOptions.actions,
			success: oOptions.success,
			errorMessage: "Table in view '" + sViewName + "' does not contain an Item at position '" + iPosition + "'"
		};
	}

	function createWaitForBPItemAtPosition(oOptions) {
		var iPosition = oOptions.position;
		return {
			id: sSmartTableId,
			viewName: sViewName,
			matchers: function (oTable) {
				return oTable.getItems()[1].getItems()[0].getCells()[0];
			},
			actions: oOptions.actions,
			success: oOptions.success,
			errorMessage: "Table in view '" + sViewName + "' does not contain an Item at position '" + iPosition + "'"
		};
	}
	Opa5.createPageObjects({

		onTheWorklistPage: {
			baseClass: Common,
			actions: jQuery.extend({
				iPressATableItemAtPosition: function (iPosition) {
					return this.waitFor(createWaitForItemAtPosition({
						position: iPosition,
						actions: new Press()
					}));
				},
				// To close the Desclaimer Dialog on start of App
				iPressTheDialogCloseButton: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (oDialog) {
							oDialog[0].getBeginButton().firePress();
						}
					});
				},
				iSeetheItemContainTheAccountId: function (iPosition) {
					return this.waitFor({
						id: sSmartTableId,
						viewName: sViewName,
						matchers: function (oTable) {
							var sLink =
								"icd.wdf.sap.corp/sap(bD1lbiZjPTAwMSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?crm-object-type=BP_ACCOUNT&crm-object-value=BUSINESSPARTNER%201&crm-object-keyname=PARTNER",
								sAccount = oTable.getItems()[1].getItems()[0].getBindingContext().getPath().replace(/[()'\/\\]/g, "").split(
									'CustomerDataEntitySet')[1],
								sGeneratedLink =
								"icd.wdf.sap.corp/sap(bD1lbiZjPTAwMSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?crm-object-type=BP_ACCOUNT&crm-object-value=" +
								sAccount + "&crm-object-keyname=PARTNER";

							return sLink === sGeneratedLink;
						},
						actions: new Press(),
						errorMessage: "Table in view '" + sViewName + "' does not contain an Item at position '" + iPosition + "'"
					});
				},
				iRememberTheItemAtPositioninTable: function (iPosition) {
					return this.waitFor(createWaitForBPItemAtPosition({
						position: iPosition,
						actions: new Press()
					}));
				},
				iRememberTheItemAtPosition: function (iPosition) {
					return this.waitFor(createWaitForItemAtPosition({
						position: iPosition,
						success: function (oTableItem) {
							var oBindingContext = oTableItem.getBindingContext();

							// Don't remember objects just strings since IE will not allow accessing objects of destroyed frames
							this.getContext().currentItem = {
								bindingPath: oBindingContext.getPath(),
								id: oBindingContext.getProperty("BUSINESSPARTNER"),
								name: oBindingContext.getProperty("BUSINESSPARTNER"),
								erpNumber:oBindingContext.getProperty("ERPNUMBER")
							};
						}
					}));
				},

				iPressOnMoreData: function () {
					return this.waitFor({
						id: sTableId,
						viewName: sViewName,
						matchers: function (oTable) {
							return !!oTable.$("trigger").length;
						},
						actions: new Press(),
						errorMessage: "The Table does not have a trigger"
					});
				},

				iWaitUntilTheTableIsLoaded: function () {
					return this.waitFor({
						id: sTableId,
						viewName: sViewName,
						matchers: [new AggregationFilled({
							name: "items"
						})],
						errorMessage: "The Table has not been loaded"
					});
				},

				iWaitUntilTheListIsNotVisible: function () {
					return this.waitFor({
						id: sTableId,
						viewName: sViewName,
						visible: false,
						matchers: function (oTable) {
							// visible false also returns visible controls so we need an extra check here
							return !oTable.$().is(":visible");
						},
						errorMessage: "The Table is still visible"
					});
				},

				iSearchForTheFirstObject: function () {
					var sFirstObjectTitle;

					return this.waitFor({
						id: sTableId,
						viewName: sViewName,
						matchers: new AggregationFilled({
							name: "items"
						}),
						success: function (oTable) {
							sFirstObjectTitle = oTable.getItems()[0].getCells()[0].getTitle();

							this.iSearchForValue(sFirstObjectTitle);

							this.waitFor({
								id: [sTableId, sSearchFieldId],
								viewName: sViewName,
								check: allItemsInTheListContainTheSearchTerm,
								errorMessage: "Did not find any table entries or too many while trying to search for the first object."
							});
						},
						errorMessage: "Did not find table entries while trying to search for the first object."
					});
				},

				iSearchForValueWithActions: function (aActions) {
					return this.waitFor({
						id: sSearchFieldId,
						viewName: sViewName,
						actions: aActions,
						errorMessage: "Failed to find search field in Worklist view.'"
					});
				},

				iSearchForValue: function (sSearchString) {
					return this.iSearchForValueWithActions([new EnterText({
						text: sSearchString
					}), new Press()]);
				},

				iTypeSomethingInTheSearchThatCannotBeFoundAndTriggerRefresh: function () {
					var fnEnterTextAndFireRefreshButtonPressedOnSearchField = function (oSearchField) {
						// set the search field value as EnterText action triggers a search event
						oSearchField.setValue(sSomethingThatCannotBeFound);

						// compose a simulated refresh button click event
						/*eslint-disable new-cap */
						var oEvent = jQuery.Event("touchend");
						/*eslint-enable new-cap */
						oEvent.originalEvent = {
							refreshButtonPressed: true,
							id: oSearchField.getId()
						};
						oEvent.target = oSearchField;
						oEvent.srcElement = oSearchField;
						jQuery.extend(oEvent, oEvent.originalEvent);

						// fire the search
						oSearchField.fireSearch(oEvent);
					};
					return this.iSearchForValueWithActions(fnEnterTextAndFireRefreshButtonPressedOnSearchField);
				},

				iClearTheSearch: function () {
					return this.iSearchForValueWithActions([new EnterText({
						text: ""
					}), new Press()]);
				},

				iSearchForSomethingWithNoResults: function () {
					return this.iSearchForValueWithActions([new EnterText({
						text: sSomethingThatCannotBeFound
					}), new Press()]);
				},

				iPressTheAdminTab: function () {
					return this.waitFor({
						viewName: sViewName,
						success: function (oEvent) {
							oEvent[0].getModel("AppConfig").setProperty("/AdminAccess", true);
							return this.waitFor({
								id: sAdminMenu,
								viewName: sViewName,
								actions: new Press()
							});
						},
						errorMessage: "Failed to find search field in Worklist view.'"
					});
				},
				iPressTheAdminInformationTab: function (key) {
					return this.waitFor({
						id: sAdminMenu,
						viewName: sViewName,
						actions: new Press(),
						success: function (oButton) {
							var menu = oButton.getMenu();
							var item = menu.getItems()[key];
							menu.fireItemSelected({
								"item": item
							});
						},
						errorMessage: "Failed to find search field in Worklist view.'"
					});
				},
				iEditTheOverviewText: function (header) {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (oDialog) {
							var overview_content = oDialog[0].getContent()[0].getItems()[header],
								infoEditId = overview_content.getContent()[0].getId();
							return this.waitFor({
								id: infoEditId,
								success: function (oItem) {
									var oeditor = oItem.getItems()[1].getItems()[0].getContent()[0];

									oeditor.setValue("Test OPA TEXTDATA 2");
								}
							});
						}
					});
				},
				iPressTheAuthButton: function (header) {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (oDialog) {
							var auth_content = oDialog[0].getContent()[0].getItems()[header].getId();
							return this.waitFor({
								id: auth_content,
								actions: new Press()
							});
						}
					});
				},
				iPressTheFooterButton: function (button, header) {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (oDialog) {
							var overview_content = oDialog[0].getContent()[0].getItems()[header],
								infoEditId = overview_content.getContent()[0].getId();
							return this.waitFor({
								id: infoEditId,
								success: function (oItem) {
									var saveButtonId = oItem.getItems()[2].getContent()[button].getId();
									return this.waitFor({
										id: saveButtonId,
										actions: new Press()
									});
								}
							});
						}
					});
				},
				iPressThePreviewSaveButton: function (header) {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (oDialog) {
							var confirm_button = oDialog[0].getContent()[0].getItems()[header],
								save_buttonId = confirm_button.getContent()[0].getItems()[2].getContent()[3].getId();
							return this.waitFor({
								id: save_buttonId,
								actions: new Press(),
								success: function (oItem) {
									Opa5.assert.ok(true, "Text saved successfully");
								}
							});
						}
					});
				}

			}, shareOptions.createActions(sViewName)),

			assertions: jQuery.extend({

				iShouldSeeTheTable: function () {
					return this.waitFor({
						id: sTableId,
						viewName: sViewName,
						success: function (oTable) {
							Opa5.assert.ok(oTable, "Found the object Table");
						},
						errorMessage: "Can't see the master Table."
					});
				},

				iShouldSeeTheAdminMenu: function () {
					return this.waitFor({
						id: sAdminMenu,
						viewName: sViewName,
						matchers: function (oMenu) {
							if (oMenu.getMenu().getItems().length > 1) {
								return true;
							} else {
								return false;
							}
						},
						success: function (oMenu) {
							Opa5.assert.ok(oMenu, "Found the admin Menu");
						},
						errorMessage: "Can't see the admin menu."
					});
				},

				iShouldSeeTheSavedMessage: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (oDialog) {
							var confirm_button = oDialog[1].getButtons()[0].getId();
							return this.waitFor({
								id: confirm_button,
								actions: new Press(),
								success: function (oItem) {
									Opa5.assert.ok(true, "Text saved successfully");
								}
							});
						}
					});
				},

				iShouldSeeThePreviewMessage: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (oDialog) {
							var confirm_button = oDialog[0].getContent()[0].getItems()[0],
								editedText = confirm_button.getContent()[0].getItems()[1].getItems()[0].getContent()[0].getValue();
							if (editedText === "Test OPA TEXTDATA 2") {
								Opa5.assert.ok(true, "Text saved successfully");
							}
						}
					});
				},

				theTableShowsOnlyObjectsWithTheSearchStringInTheirTitle: function () {
					this.waitFor({
						id: [sTableId, sSearchFieldId],
						viewName: sViewName,
						check: allItemsInTheListContainTheSearchTerm,
						success: function () {
							Opa5.assert.ok(true, "Every item did contain the title");
						},
						errorMessage: "The table did not have items"
					});
				},

				theTableHasEntries: function () {
					return this.waitFor({
						viewName: sViewName,
						id: sTableId,
						matchers: new AggregationFilled({
							name: "items"
						}),
						success: function () {
							Opa5.assert.ok(true, "The table has entries");
						},
						errorMessage: "The table had no entries"
					});
				},

				theTableShouldHaveAllEntries: function () {
					var aAllEntities,
						iExpectedNumberOfItems;

					// retrieve all CustomerDataEntitySet to be able to check for the total amount
					this.waitFor(this.createAWaitForAnEntitySet({
						entitySet: "CustomerDataEntitySet",
						success: function (aEntityData) {
							aAllEntities = aEntityData;
						}
					}));

					return this.waitFor({
						id: sTableId,
						viewName: sViewName,
						matchers: function (oTable) {
							// If there are less items in the list than the growingThreshold, only check for this number.
							iExpectedNumberOfItems = Math.min(oTable.getGrowingThreshold(), aAllEntities.length);
							return new AggregationLengthEquals({
								name: "items",
								length: iExpectedNumberOfItems
							}).isMatching(oTable);
						},
						success: function (oTable) {
							Opa5.assert.strictEqual(oTable.getItems().length, iExpectedNumberOfItems, "The growing Table has " +
								iExpectedNumberOfItems + " items");
						},
						errorMessage: "Table does not have all entries."
					});
				},

				theTitleShouldDisplayTheTotalAmountOfItems: function () {
					return this.waitFor({
						id: sTableId,
						viewName: sViewName,
						matchers: new AggregationFilled({
							name: "items"
						}),
						success: function (oTable) {
							var iObjectCount = oTable.getBinding("items").getLength();
							Opa5.assert.ok(true, "The Page has a title containing the number " + iObjectCount);
						},
						errorMessage: "The table has no items."
					});
				},

				theTableShouldHaveTheDoubleAmountOfInitialEntries: function () {
					var iExpectedNumberOfItems;

					return this.waitFor({
						id: sTableId,
						viewName: sViewName,
						matchers: function (oTable) {
							iExpectedNumberOfItems = oTable.getGrowingThreshold() * 2;
							return new AggregationLengthEquals({
								name: "items",
								length: iExpectedNumberOfItems
							}).isMatching(oTable);
						},
						success: function () {
							Opa5.assert.ok(true, "The growing Table had the double amount: " + iExpectedNumberOfItems + " of entries");
						},
						errorMessage: "Table does not have the double amount of entries."
					});
				},

				iShouldSeeTheWorklistViewsBusyIndicator: function () {
					return this.waitFor({
						id: "page",
						viewName: sViewName,
						success: function (oPage) {
							Opa5.assert.ok(oPage.getParent().getBusy(), "The worklist view is busy");
						},
						errorMessage: "The worklist view is not busy"
					});
				},

				iShouldSeeTheWorklistTableBusyIndicator: function () {
					return this.waitFor({
						id: "table",
						viewName: sViewName,
						matchers: new PropertyStrictEquals({
							name: "busy",
							value: true
						}),
						autoWait: false,
						success: function () {
							Opa5.assert.ok(true, "The worklist table is busy");
						},
						errorMessage: "The worklist table is not busy"
					});
				},

				iShouldSeeTheNoDataTextForNoSearchResults: function () {
					return this.waitFor({
						id: sTableId,
						viewName: sViewName,
						success: function (oTable) {
							Opa5.assert.strictEqual(
								oTable.getNoDataText(),
								oTable.getModel("i18n").getProperty("worklistNoDataWithSearchText"),
								"the table should show the no data text for search");
						},
						errorMessage: "table does not show the no data text for search"
					});
				},
				iShouldSeeNewWindow: function () {
					return this.waitFor({
						id: sSmartTableId,
						viewName: sViewName,
						success: function (oTable) {
							Opa5.assert.ok(oTable, "Found the account details");
						},
						errorMessage: "Can't see the account details."
					});
				}
			}, shareOptions.createAssertions(sViewName))

		}

	});

});