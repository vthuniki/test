sap.ui.define([
	"sap/ui/test/Opa5",
	"./Common"
], function(Opa5, Common) {
	"use strict";

	Opa5.createPageObjects({
		onTheBrowser : {
			baseClass : Common,

			actions : {

				iPressOnTheBackwardsButton : function () {
					return this.waitFor({
						success : function () {
							// manipulate history directly for testing purposes
							Opa5.getWindow().history.back();
						}
					});
				},

				iPressOnTheForwardsButton : function () {
					return this.waitFor({
						success : function () {
							// manipulate history directly for testing purposes
							Opa5.getWindow().history.forward();
						}
					});
				},

				iChangeTheHashToSomethingInvalid : function () {
					return this.waitFor({
						success : function () {
							Opa5.getHashChanger().setHash("/somethingInvalid");
						}
					});
				},

				iChangeTheHashToTheRememberedItem : function () {
					return this.waitFor({
						success : function () {
							var sObjectId = this.getContext().currentItem.id;
							var erpNumber= this.getContext().currentItem.erpNumber;

							Opa5.getHashChanger().setHash("/CustomerDataEntitySet/" + sObjectId + "/" +erpNumber);
						}
					});
				},
				iChangeTheHashToOverview: function () {
					return this.waitFor({
						success : function () {
							Opa5.getHashChanger().setHash("/CaseOverView/BUSINESSPARTNER%203/ERPNUMBER%203/CASE_ID%203/3de340d6-7800-412b-9f0c-22f5003d8c86");
						}
					});
				},
				// To go to the overview page of CASE ID 1 for checking payment & invoices data
				iChangeTheHashToOverview1: function () {
					return this.waitFor({
						success : function () {
							Opa5.getHashChanger().setHash("/CaseOverView/BUSINESSPARTNER%201/CASE_ID%201/1");
						}
					});
				}
			},

			assertions: {}
		}

	});
});