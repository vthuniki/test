/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit",
	"./pages/Worklist",
	"./pages/Browser",
	"./pages/Object",
	"./pages/App"
], function (opaTest) {
	"use strict";

	QUnit.module("Object");

	opaTest("Should remember the first item", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();

		//Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iRememberTheItemAtPosition(1);

		// Assertions
		Then.onTheWorklistPage.theTitleShouldDisplayTheTotalAmountOfItems();

		// Cleanup
		Then.iTeardownMyAppFrame();
	});
	opaTest("The link contains the correct caseid Details", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();
		// Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iRememberTheItemAtPosition(0);
		When.onTheBrowser.iChangeTheHashToTheRememberedItem();
		When.onTheObjectPage.iSeetheItemContainTheCaseId('dcdoverviewtabid');
		// Assertions
		Then.onTheObjectPage.iShouldSeeNewWindowObject("dcdoverviewtabid");
		// Cleanup
		Then.iTeardownMyAppFrame();
	});
	opaTest("Should open the cloud reporting tab", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();
		// Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iRememberTheItemAtPosition(0);
		When.onTheBrowser.iChangeTheHashToTheRememberedItem();
		When.onTheObjectPage.iClickTheCloudReportingButton();
		// Assertions
		Then.onTheObjectPage.iShouldSeeNewWindowObject("dcdproducttabid");
		// Cleanup
		Then.iTeardownMyAppFrame();
	});
	opaTest("Should open the onPrem reporting tab", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();
		// Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iRememberTheItemAtPosition(0);
		When.onTheBrowser.iChangeTheHashToTheRememberedItem();
		When.onTheObjectPage.iClickTheOnPremReportingButton();
		// Assertions
		Then.onTheObjectPage.iShouldSeeNewWindowObject("dcdproducttabid");
		// Cleanup
		Then.iTeardownMyAppFrame();
	});
	opaTest("Should open the on Maintanence reporting tab", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();
		// Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iRememberTheItemAtPosition(0);
		When.onTheBrowser.iChangeTheHashToTheRememberedItem();
		When.onTheObjectPage.iClickTheOnMaintananceButton();
		// Assertions
		Then.onTheObjectPage.iShouldSeeNewWindowObject("dcdproducttabid");
		// Cleanup
		Then.iTeardownMyAppFrame();
	});
	opaTest("The link will navigate to  caseid Details", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();
		// Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iRememberTheItemAtPosition(0);
		When.onTheBrowser.iChangeTheHashToTheRememberedItem();
		When.onTheObjectPage.iSeetheItemNavigateToTheCaseId('Case', 'dcdoverviewtabid');
		// Assertions
		Then.onTheObjectPage.iShouldSeeNewWindowObject("dcdoverviewtabid");
		// Cleanup
		// Then.iTeardownMyAppFrame();
	});
	opaTest("Should click on contract icon and check if the popup is opened", function (Given, When, Then) {
		// //  Actions
		When.onTheObjectPage.iSeetheItemNavigateToTheCaseId('Overview', 'dcdoverviewtabid');
		// Assertions
		Then.onTheObjectPage.iShouldSeeTheInvoicePopover();
		//	Cleanup
		// Then.iTeardownMyAppFrame();
	});
	opaTest("Should click on link Contract popover and check if links opens in new tab", function (Given, When, Then) {
		//  Actions
		When.onTheObjectPage.iSeetheItemNavigateToTheLink("Contract");

		// Assertions
		Then.onTheObjectPage.iShouldSeeTheInvoicePopover();
		//Cleanup
		Then.iTeardownMyAppFrame();
	});
	opaTest("Should click on payment and invoicing tab from overview", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();
		//  Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iRememberTheItemAtPosition(0);
		When.onTheBrowser.iChangeTheHashToTheRememberedItem();
		When.onTheObjectPage.iDealStructSection();

		// Assertions
		Then.onTheObjectPage.iSeeSelectedTab('dcdpayinvoicetabidSS1');

		//Cleanup
		// Then.iTeardownMyAppFrame();
	});
	opaTest("Should click on invoice icon and check if the popup is opened", function (Given, When, Then) {
		// //  Actions
		When.onTheObjectPage.iSeetheItemNavigateToTheCaseId('Invoice', 'dcdpayinvoicetabid');
		// Assertions
		Then.onTheObjectPage.iShouldSeeTheInvoicePopover();
	});
	opaTest("Should click on link invoice popover and check if links opens in new tab", function (Given, When, Then) {
		//  Actions
		When.onTheObjectPage.iSeetheItemNavigateToTheLink("Invoice");

		// Assertions
		Then.onTheObjectPage.iShouldSeeTheInvoicePopover();
		//Cleanup
		Then.iTeardownMyAppFrame();
	});
	opaTest("Should open image on click of help icon", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();
		// Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iRememberTheItemAtPosition(0);
		When.onTheBrowser.iChangeTheHashToTheRememberedItem();
		When.onTheObjectPage.iSeeImageOnClickOfHelp();
		// Assertions
		Then.onTheObjectPage.iShouldSeeTheImageBox();
		// Cleanup
		Then.iTeardownMyAppFrame();
	});
	// opaTest("Should open image on click of glossary icon", function (Given, When, Then) {
	// 	// Arrangements
	// 	Given.iStartMyApp();
	// 	// Actions
	// 	When.onTheWorklistPage.iPressTheDialogCloseButton();
	// 	When.onTheWorklistPage.iRememberTheItemAtPosition(0);
	// 	When.onTheBrowser.iChangeTheHashToTheRememberedItem();
	// 	When.onTheObjectPage.iSeeSearchOnClickOfGlossary();
	// 	// Assertions
	// 	Then.onTheObjectPage.iShouldSeeTheSearchField();
	// 	// Cleanup
	// 	Then.iTeardownMyAppFrame();
	// });
	opaTest("Should open hierarchyTable", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();
		// Actions
		When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheWorklistPage.iRememberTheItemAtPosition(0);
		When.onTheBrowser.iChangeTheHashToTheRememberedItem();
		When.onTheObjectPage.iPressOnHierarchy();
		// Assertions
		Then.onTheObjectPage.iShouldSeeHierarchyTable();
		// Cleanup
		// Then.iTeardownMyAppFrame();
	});
	opaTest("Should close hierarchy Table on Press of Cancel", function (Given, When, Then) {

		When.onTheObjectPage.iPressOnCancelInHierarchy();
		// Assertions
		Then.onTheObjectPage.iShouldSeeHierarchyTable();
		// Cleanup
		Then.iTeardownMyAppFrame();
	});
});