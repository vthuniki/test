/*global location history */
sap.ui.define([
	"c2r/c2rdcd/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"c2r/c2rdcd/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator", 
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/Text"

], function (BaseController, JSONModel, History, formatter, Filter, FilterOperator, MessageBox, MessageToast, Dialog, DialogType, Button,
	ButtonType, Text) {

	"use strict";

	return BaseController.extend("c2r.c2rdcd.controller.Worklist", {
		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			this._getSystemInfo();
			this.getAdminAccess();
		},
		/**
		 * Check for disclaimer in AppConfig if null, check for NOTIFCTN_RQSTD
		 * if NOTIFCTN_RQSTD = X, user has opted to do not show 
		 * else open the disclaimer
		 * set DISCLAIMER_KEY as datetime, to be used for updating NOTIFCTN_RQSTD
		 */
		onBeforeRendering: function () {
			var that = this;
			var oModelAppConfig = that.getOwnerComponent().getModel("AppConfig");
			var oModel = that.getOwnerComponent().getModel();
			if (oModelAppConfig.getProperty("/disclaimer") === null) {
				oModel.read("/DCDDisclaimerSet", {
					success: function (oData, response) {
						if (oData.results.length > 0) {
							oModelAppConfig.setProperty("/disclaimer", oData.results[0]);
							var sDiscalimerKey = oData.results[0].DISCLAIMER_KEY.toISOString();
							var sKey = "datetimeoffset'" + sDiscalimerKey.substring(0, sDiscalimerKey.indexOf(".")) + "'";
							oModelAppConfig.setProperty("/disclaimer/sKey", sKey);
							if (oModelAppConfig.getProperty("/disclaimer/NOTIFCTN_RQSTD") !== "X") {
								that.openDisclaimer();
							}
						}
					},
					error: function (error) {}
				});
			}
		},
		onBrandingCancelled: function () {
			var oPage = this.byId("cmsPage");
			oPage.setShowFooter(false);
		},

		//Navigation from worklist page to object page 
		onNavtoContractsOverview: function (oEvent) {
			var businessPartner = oEvent.getParameters().listItem.getBindingContext().getObject().BUSINESSPARTNER;
			var erpNumber = oEvent.getParameters().listItem.getBindingContext().getObject().ERPNUMBER;
			// Begin for ITSDEDLC-631
			var oResourceModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var caseid = oEvent.getParameters().listItem.getBindingContext().getObject().NUMBER_OF_ACTIVE_CASES;
			if (caseid !== "0") {
				this.getOwnerComponent().getRouter().navTo("object", {
					objectId: businessPartner,
					erpNumber: erpNumber
				});
			} else {
				MessageBox.information(oResourceModel.getText("noDataFound"));
			}
			// End for ITSDEDLC-631
		},

		//Event handler for opening cms link
		handleBPPress: function (oEvent) {
			var oBusinessPartner = oEvent.getSource().getBindingContext().getObject().BUSINESSPARTNER;
			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var sHTTPS = appConfigModel.getProperty("/protocol");
			var sSystemID = appConfigModel.getProperty("/SystemsInfo").CRMSYS;
			var url = appConfigModel.getProperty("/url");
			var crmUrlAccount = appConfigModel.getProperty("/crmUrlAccount");
			var crmUrlValue = appConfigModel.getProperty("/crmUrlValue");
			var crmUrlKeyName = appConfigModel.getProperty("/crmUrlKeyName");
			var sUrl = sHTTPS + sSystemID + url + crmUrlAccount + "BP_ACCOUNT" + crmUrlValue +
				oBusinessPartner + crmUrlKeyName + "PARTNER";
			sap.m.URLHelper.redirect(sUrl, true);
		},

		/**
		 * Changing the smart filter to pass OR
		 * inplace of AND
		 */
		onBeforeRebindTable: function (oEvent) {

			var oBindingParams = oEvent.getParameter("bindingParams");
			if (oBindingParams.filters.length > 0) {
				oBindingParams.filters[0].bAnd = false;
			}

		},

		//Open disclaimer pop-up
		openDisclaimer: function () {
			if (!this.oPrivacyDialog) {
				this.oPrivacyDialog = sap.ui.xmlfragment(this.getView().getId(), "c2r.c2rdcd.fragments.disclaimer", this);
				this.getView().addDependent(this.oPrivacyDialog);
			}
			this.oPrivacyDialog.open();
		},

		//event handler to open the latest news update
		goToLatestNewsUpdate: function () {
			this.oPrivacyDialog.close();
			var bShowNewsAndUpdate = true;
			this.onInfoPress(null, bShowNewsAndUpdate);
		},

		//event handler to open the menu dropdown
		onMenuAction: function (oEvent) {
			var key = oEvent.getParameter("item").getKey();
			switch (key) {
			case "0":
				this.getRouter().navTo("Admin", {
					key: 0
				});
				break;
			case "1":
				this.getRouter().navTo("Admin", {
					key: 1
				});
				break;
			case "2":
				this.onInfoEditPress();
				break;
			case "3":
				this.onCXRLoginPress();
				break;
					// <!--Start of code added by C5270230 on 26-sep-2023 as per JIRA ID: ITSDEDLC-1828-->
			case "4":
				this.Info_Products_Edit_Admin();
				break;
			case "5":
				this.Info_Home_Search_Edit_Admin();
				break;
			case "6":
				this.Info_Second_level_Edit_Admin();
				break;
			case "7":
				this.Info_ContractMap_Search_Edit_Admin();
				break;
			case "8":
				this.Info_XReference_Search_Edit_Admin();
				break;
				// <!--End of code added by C5270230 on 26-sep-2023 as per JIRA ID: ITSDEDLC-1828-->
			default:
				return;
			}
		},

		//Manage CXR Login
		onCXRLoginPress: function (evt) {
			if (!this.oCXRLoginDialog) {
				this.oCXRLoginDialog = sap.ui.xmlfragment("idlogindialog", "c2r.c2rdcd.fragments.managecxrlogin", this);
				this.getView().addDependent(this.oCXRLoginDialog);
			}
			this.oCXRLoginDialog.open();
			sap.ui.core.Fragment.byId("idlogindialog", "okButton").setEnabled(false);

		},
		onSelectRadio: function () {
			var oSelected = sap.ui.core.Fragment.byId("idlogindialog", "oEnable").getSelected();
			if (oSelected === true) {
				sap.ui.core.Fragment.byId("idlogindialog", "oEnable").setEditable(false);
				sap.ui.core.Fragment.byId("idlogindialog", "okButton").setEnabled(true);
			} else {
				sap.ui.core.Fragment.byId("idlogindialog", "oEnable").setEditable(true);
			}
			var oDSelected = sap.ui.core.Fragment.byId("idlogindialog", "oDisable").getSelected();
			if (oDSelected === true) {
				sap.ui.core.Fragment.byId("idlogindialog", "oDisable").setEditable(false);
				sap.ui.core.Fragment.byId("idlogindialog", "okButton").setEnabled(true);
			} else {
				sap.ui.core.Fragment.byId("idlogindialog", "oDisable").setEditable(true);
			}
		},
		//ok of Manage CXR Dialog
		onOkPress: function () {
			var that = this;
			var oSelected = sap.ui.core.Fragment.byId("idlogindialog", "oEnable").getSelected();
			var oModel = that.getOwnerComponent().getModel();
			oModel.callFunction("/CXRLoginHandler", {
				method: "POST",
				urlParameters: {
					Enabled: oSelected
				},
				success: function (oData, resposne) {
					if (oSelected === true) {
						MessageToast.show("Contract X-Ray Login Enabled Successfully ", {
							duration: 5000,
							width: "25em"
						});
					} else {
						MessageToast.show("Contract X-Ray Login Disabled Successfully", {
							duration: 5000,
							width: "25em"
						});
					}
					that.getOwnerComponent().getModel().refresh();
				},
				error: function (oError) {
					MessageToast.show(oError);
				}

			});
			this.oCXRLoginDialog.close();

		},
		//Cancel of Manage CXR Dialog
		onCancelPress: function () {
			this.oCXRLoginDialog.close();
		},

		//Info tab edit
		onInfoEditPress: function (evt) {
			if (!this.oInfoEditDialog) {
				this.oInfoEditDialog = sap.ui.xmlfragment("c2r.c2rdcd.fragments.informationEdit", this);
				this.getView().addDependent(this.oInfoEditDialog);
			}
			this.oInfoEditDialog.open();
		},
		//onclick searchinfotext
		onSearch: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			if (!this.oDefaultMessageDialog) {
				this.oDefaultMessageDialog = new Dialog({
					type: DialogType.Message,
					title: "Information:",
					content: new Text({
						text: i18nModel.getText("SearchText")
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "OK",
						press: function () {
							this.oDefaultMessageDialog.close();
						}.bind(this)
					})
				});
			}
			this.oDefaultMessageDialog.open();
		},


		// <!--Start of code added by C5270230 on 26-sep-2023 as per JIRA ID: ITSDEDLC-1828-->
		// Start of Products Information Edit 
		Info_Products_Edit_Admin: function (evt) {
			if (!this.pDialog_Info_Products) {
				this.pDialog_Info_Products = this.loadFragment({
					name: "c2r.c2rdcd.view.ReportProducts"
				});
			}
			this.pDialog_Info_Products.then(function (oDialog_Info_Products) {
				oDialog_Info_Products.open();
			});
		},
		Info_Products_Edit: function () {
			this.getView().byId("Info_Products_Preview_Button").setVisible(true);
			this.getView().byId("Info_Products_Edit_Button").setVisible(false);
			this.getView().byId("overviewTabInfoEdit_Main").setVisible(false);
			this.getView().byId("overviewTabInfoEdit").setVisible(true);
		},

		Info_Products_Preview: function () {
			this.getView().byId("Info_Products_Preview_Button").setVisible(false);
			this.getView().byId("Info_Products_Edit_Button").setVisible(true);
			this.getView().byId("overviewTabInfoEdit_Main").setVisible(true);
			this.getView().byId("overviewTabInfoEdit").setVisible(false);
		},

		Info_Products_Save: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("Save Information : Products Tab ?"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.submitChanges({
									success: function () {
										var errorText = oModelAppConfig.getProperty("/errorText");
										if (errorText === "") {
											MessageToast.show(i18nModel.getText("overviewSaveSuccess"));
										}
										oModelAppConfig.setProperty("/errorText", "");
									},
									error: function (error) {
										MessageToast.error(i18nModel.getText("overviewSaveError"));
									}
								});
							}
						}
					}
				);
			} else {
				MessageToast.show(i18nModel.getText("noPendingChangesMsg"));
			}
		},
		Info_Products_Close: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();

			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("pendingChangesMsg"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.resetChanges();
								this.byId("helloDialog").close();
							}
						}
					}
				);
			} else {
				this.byId("helloDialog").close();
			}
		},
		// End of Information Product Edits

		// Start of Home Page Search here
		Info_Home_Search_Edit_Admin: function (evt) {
			// alert('Deepak');
			if (!this.Dialog_Home_Search) {
				this.Dialog_Home_Search = this.loadFragment({
					name: "c2r.c2rdcd.view.ReportHomeSearch"
				});
			}
			this.Dialog_Home_Search.then(function (oDialog) {
				oDialog.open();
			});
		},
		Info_Home_Search_Edit: function () {
			this.getView().byId("Info_Home_Search_Preview_Button").setVisible(true);
			this.getView().byId("Info_Home_Search_Edit_Button").setVisible(false);
			this.getView().byId("overviewTabInfoEdit_Main_Home_Search").setVisible(false);
			this.getView().byId("overviewTabInfoEdit_Home_Search").setVisible(true);
		},

		Info_Home_Search_Preview: function () {
			this.getView().byId("Info_Home_Search_Preview_Button").setVisible(false);
			this.getView().byId("Info_Home_Search_Edit_Button").setVisible(true);
			this.getView().byId("overviewTabInfoEdit_Main_Home_Search").setVisible(true);
			this.getView().byId("overviewTabInfoEdit_Home_Search").setVisible(false);
		},

		Info_Home_Search_Save: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("Save Information : Home Page Standard Search ?"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.submitChanges({
									success: function () {
										var errorText = oModelAppConfig.getProperty("/errorText");
										if (errorText === "") {
											MessageToast.show(i18nModel.getText("overviewSaveSuccess"));
										}
										oModelAppConfig.setProperty("/errorText", "");
									},
									error: function (error) {
										MessageToast.error(i18nModel.getText("overviewSaveError"));
									}
								});
							}
						}
					}
				);
			} else {
				MessageToast.show(i18nModel.getText("noPendingChangesMsg"));
			}
		},
		Info_Home_Search_Close: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();

			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("pendingChangesMsg"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.resetChanges();
								this.byId("helloDialog_Home_Search").close();
							}
						}
					}
				);
			} else {
				this.byId("helloDialog_Home_Search").close();
			}
		},
		// End of Home Page Search here

		// Home Page Search Display Starts Here
		Home_Page_Search_Information: function () {
			if (!this.Disp_Info_Home_Search_Dialog) {
				this.Disp_Info_Home_Search_Dialog = this.loadFragment({
					name: "c2r.c2rdcd.view.DispInfoHomeSearch"
				});
			}
			this.Disp_Info_Home_Search_Dialog.then(function (oDialog) {
				oDialog.open();
			});
		},
		Disp_Info_Home_Search_Button: function () {
			this.byId("Disp_Info_Home_Search_Dialog").close();
		},
		// Home Page Search Display Ends Here

		// Start of Second Level Search here
		Info_Second_level_Edit_Admin: function (evt) {
			if (!this.pDialogSecondLevel) {
				this.pDialogSecondLevel = this.loadFragment({
					name: "c2r.c2rdcd.view.ReportSecondLevel"
				});
			}
			this.pDialogSecondLevel.then(function (oDialogSecondLevel) {
				oDialogSecondLevel.open();
			});
		},
		Info_Second_Level_Edit: function () {
			this.getView().byId("Info_Second_Level_Preview_Button").setVisible(true);
			this.getView().byId("Info_Second_Level_Edit_Button").setVisible(false);
			this.getView().byId("Info_Second_LevelInfoEdit_Main").setVisible(false);
			this.getView().byId("Info_Second_LevelInfoEdit").setVisible(true);
		},

		Info_Second_Level_Preview: function () {
			this.getView().byId("Info_Second_Level_Preview_Button").setVisible(false);
			this.getView().byId("Info_Second_Level_Edit_Button").setVisible(true);
			this.getView().byId("Info_Second_LevelInfoEdit_Main").setVisible(true);
			this.getView().byId("Info_Second_LevelInfoEdit").setVisible(false);
		},

		Info_Second_Level_Save: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("Save Information : Second Level Standard Search ?"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.submitChanges({
									success: function () {
										var errorText = oModelAppConfig.getProperty("/errorText");
										if (errorText === "") {
											MessageToast.show(i18nModel.getText("overviewSaveSuccess"));
										}
										oModelAppConfig.setProperty("/errorText", "");
									},
									error: function (error) {
										MessageToast.error(i18nModel.getText("overviewSaveError"));
									}
								});
							}
						}
					}
				);
			} else {
				MessageToast.show(i18nModel.getText("noPendingChangesMsg"));
			}
		},
		Info_Second_Level_Close: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();

			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("pendingChangesMsg"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.resetChanges();
								this.byId("helloDialog_Second_Level").close();
							}
						}
					}
				);
			} else {
				this.byId("helloDialog_Second_Level").close();
			}
		},
		// End of Second Level Search here

		// Start of Contract Level search
		Info_ContractMap_Search_Edit_Admin: function (evt) {
			if (!this.pDialog_Contract_Search) {
				this.pDialog_Contract_Search = this.loadFragment({
					name: "c2r.c2rdcd.view.ReportContractMap"
				});
			}
			this.pDialog_Contract_Search.then(function (oDialog_Contract_Search) {
				oDialog_Contract_Search.open();
			});
		},

		Info_ContractMap_Search_Search_Edit: function () {
			this.getView().byId("Info_ContractMap_Search_Preview_Button").setVisible(true);
			this.getView().byId("Info_ContractMap_Search_Edit_Button").setVisible(false);
			this.getView().byId("ContractMap_SearchInfoEdit_Main").setVisible(false);
			this.getView().byId("ContractMap_SearchInfoEdit").setVisible(true);
		},

		Info_ContractMap_Search_Preview: function () {
			this.getView().byId("Info_ContractMap_Search_Preview_Button").setVisible(false);
			this.getView().byId("Info_ContractMap_Search_Edit_Button").setVisible(true);
			this.getView().byId("ContractMap_SearchInfoEdit_Main").setVisible(true);
			this.getView().byId("ContractMap_SearchInfoEdit").setVisible(false);
		},

		Info_ContractMap_Search_Save: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("Save Information : Contract Map Standard Search ?"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.submitChanges({
									success: function () {
										var errorText = oModelAppConfig.getProperty("/errorText");
										if (errorText === "") {
											MessageToast.show(i18nModel.getText("overviewSaveSuccess"));
										}
										oModelAppConfig.setProperty("/errorText", "");
									},
									error: function (error) {
										MessageToast.error(i18nModel.getText("overviewSaveError"));
									}
								});
							}
						}
					}
				);
			} else {
				MessageToast.show(i18nModel.getText("noPendingChangesMsg"));
			}
		},
		Info_ContractMap_Search_Close: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();

			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("pendingChangesMsg"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.resetChanges();
								this.byId("ContractMap_Search").close();
							}
						}
					}
				);
			} else {
				this.byId("ContractMap_Search").close();
			}
		},
		// end of Contract Level Search
		
		// Start of XReference
		Info_XReference_Search_Edit_Admin: function (evt) {
			if (!this.pDialog_XReference) {
				this.pDialog_XReference = this.loadFragment({
					name: "c2r.c2rdcd.view.ReportXRef"
				});
			}
			this.pDialog_XReference.then(function (oDialog_XReference) {
				oDialog_XReference.open();
			});
		},

		Info_XReference_Search_Search_Edit: function () {
			this.getView().byId("Info_XReference_Search_Preview_Button").setVisible(true);
			this.getView().byId("Info_XReference_Search_Edit_Button").setVisible(false);
			this.getView().byId("XReference_SearchInfoEdit_Main").setVisible(false);
			this.getView().byId("XReference_SearchInfoEdit").setVisible(true);
		},

		Info_XReference_Search_Preview: function () {
			this.getView().byId("Info_XReference_Search_Preview_Button").setVisible(false);
			this.getView().byId("Info_XReference_Search_Edit_Button").setVisible(true);
			this.getView().byId("XReference_SearchInfoEdit_Main").setVisible(true);
			this.getView().byId("XReference_SearchInfoEdit").setVisible(false);
		},

		Info_XReference_Search_Save: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("Save Information : X-Reference ?"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.submitChanges({
									success: function () {
										var errorText = oModelAppConfig.getProperty("/errorText");
										if (errorText === "") {
											MessageToast.show(i18nModel.getText("overviewSaveSuccess"));
										}
										oModelAppConfig.setProperty("/errorText", "");
									},
									error: function (error) {
										MessageToast.error(i18nModel.getText("overviewSaveError"));
									}
								});
							}
						}
					}
				);
			} else {
				MessageToast.show(i18nModel.getText("noPendingChangesMsg"));
			}
		},
		Info_XReference_Search_Close: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();

			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("pendingChangesMsg"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.resetChanges();
								this.byId("XReference_Search").close();
							}
						}
					}
				);
			} else {
				this.byId("XReference_Search").close();
			}
		},
		// end of Xreference

		// <!--End of code added by C5270230 on 26-sep-2023 as per JIRA ID: ITSDEDLC-1828-->

		//Info tab cancel
		onInfoEditCancel: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();
			var that = this;
			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("pendingChangesMsg"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.resetChanges();
								that.oInfoEditDialog.close();
							}
						}
					}
				);
			} else {
				this.oInfoEditDialog.close();
			}
		},

		//Info tab ok selection
		onInfoEditTabSelect: function (oEvent) {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();
			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("pendingChangesMsg"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.resetChanges();
							}
						}
					}
				);
			} else {
				oModel.resetChanges();
			}
		},

		//overview tab  preview
		onOverviewPreview: function () {
			sap.ui.getCore().byId("previewOverviewButton").setVisible(false);
			sap.ui.getCore().byId("editOverviewButton").setVisible(true);

			sap.ui.getCore().byId("overviewTabInfo").setVisible(true);
			sap.ui.getCore().byId("overviewTabInfoEdit").setVisible(false);
		},

		//overview tab edit
		onOverviewEdit: function () {
			sap.ui.getCore().byId("previewOverviewButton").setVisible(true);
			sap.ui.getCore().byId("editOverviewButton").setVisible(false);

			sap.ui.getCore().byId("overviewTabInfo").setVisible(false);
			sap.ui.getCore().byId("overviewTabInfoEdit").setVisible(true);
		},

		//overview tab  save
		onOverviewSave: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("overviewSaveConfirmMsg"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.submitChanges({
									success: function () {
										var errorText = oModelAppConfig.getProperty("/errorText");
										if (errorText === "") {
											MessageToast.show(i18nModel.getText("overviewSaveSuccessMsg"));
										}
										oModelAppConfig.setProperty("/errorText", "");
									},
									error: function (error) {
										MessageToast.error(i18nModel.getText("overviewSaveErrorMsg"));
									}
								});
							}
						}
					}
				);
			} else {
				MessageToast.show(i18nModel.getText("noPendingChangesMsg"));
			}
		},

		//authorization preview 
		onAuthPreview: function () {
			sap.ui.getCore().byId("previewAuthButton").setVisible(false);
			sap.ui.getCore().byId("editAuthButton").setVisible(true);

			sap.ui.getCore().byId("authTabInfo").setVisible(true);
			sap.ui.getCore().byId("authTabInfoEdit").setVisible(false);
		},

		//authorization edit 
		onAuthEdit: function () {
			sap.ui.getCore().byId("previewAuthButton").setVisible(true);
			sap.ui.getCore().byId("editAuthButton").setVisible(false);

			sap.ui.getCore().byId("authTabInfo").setVisible(false);
			sap.ui.getCore().byId("authTabInfoEdit").setVisible(true);
		},

		//authorization save 
		onAuthSave: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("authSaveConfirmMsg"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.submitChanges({
									success: function () {
										var errorText = oModelAppConfig.getProperty("/errorText");
										if (errorText === "") {
											MessageToast.show(i18nModel.getText("authSaveSuccessMsg"));
										}
										oModelAppConfig.setProperty("/errorText", "");
									},
									error: function (error) {
										MessageToast.error(i18nModel.getText("authSaveErrorMsg"));
									}
								});
							}
						}
					}
				);
			} else {
				MessageToast.show(i18nModel.getText("noPendingChangesMsg"));
			}
		},

		//Begin code for ITSDEDLC-478
		//News preview 
		onNewsPreview: function () {
			sap.ui.getCore().byId("previewNewsButton").setVisible(false);
			sap.ui.getCore().byId("editNewsButton").setVisible(true);

			sap.ui.getCore().byId("newsTabInfo").setVisible(true);
			sap.ui.getCore().byId("newsTabInfoEdit").setVisible(false);
		},

		//News edit 
		onNewsEdit: function () {
			sap.ui.getCore().byId("previewNewsButton").setVisible(true);
			sap.ui.getCore().byId("editNewsButton").setVisible(false);

			sap.ui.getCore().byId("newsTabInfo").setVisible(false);
			sap.ui.getCore().byId("newsTabInfoEdit").setVisible(true);
		},
		//News save 
		onNewsSave: function () {
				var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				var oModel = this.getOwnerComponent().getModel();
				var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
				if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
					MessageBox.confirm(
						i18nModel.getText("newsSaveConfirmMsg"), {
							onClose: function (sAction) {
								if (sAction === "OK") {
									oModel.submitChanges({
										success: function () {
											var errorText = oModelAppConfig.getProperty("/errorText");
											if (errorText === "") {
												MessageToast.show(i18nModel.getText("authSaveSuccessMsg"));
											}
											oModelAppConfig.setProperty("/errorText", "");
										},
										error: function (error) {
											MessageToast.error(i18nModel.getText("authSaveErrorMsg"));
										}
									});
								}
							}
						}
					);
				} else {
					MessageToast.show(i18nModel.getText("noPendingChangesMsg"));
				}
			}
			//End code for ITSDEDLC-478
	});
});