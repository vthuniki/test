/*global window */
/*global Uint8Array */
sap.ui.define([
	"c2r/c2rdcd/controller/BaseController", 
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"c2r/c2rdcd/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/suite/ui/commons/networkgraph/ActionButton",
		"sap/m/ToolbarSpacer"
], function (BaseController, JSONModel, MessageBox, formatter, Filter, FilterOperator, ActionButton, ToolbarSpacer) {
	"use strict";
	var countryname;
	var caseid;
	var bpnumber;
	var erpdescription;
	var erpNumber;
	var oToolbar; //ITSDEDLC-422
	var oModelAppConfig; //ITSDEDLC-422
	var userSelectedObject; //ITSDEDLC-930
	var userSelectedObjectStatus; //ITSDEDLC-930
	var mapType;
	var caseguid;
	var revenueType;
	var quoteid;
	var reportid;

	return BaseController.extend("c2r.c2rdcd.controller.Overview", {
		formatter: formatter,
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf c2r.c2rdcd.view.Overview
		 */
		onInit: function () {
			this.getOwnerComponent().getRouter().getRoute("overView").attachPatternMatched(this._onOverViewMatched, this);

			//var oGraph = this.getView().byId("graph");
			oToolbar = this.getView().byId("graph").getToolbar(); //ITSDEDLC-422
			mapType = "Y";
			//graph toolbar extention 
			this.ngToolbarExtention();
			//report data issue icon added to the toolbar at last position 
			var aList = oToolbar.getContent();
			for (var i = 0; i < aList.length; i++) {
				if (aList[i].getMetadata().getName() === "sap.m.SearchField") {
					oToolbar.removeContent(aList[i]);
				}
			}
			this._graph = this.getView().byId("graph");
			this._graph.attachEvent("beforeLayouting", function (oEvent) {
				// this._graph.preventInvalidation(true);
				this._graph.getNodes().forEach(function (oNode) {
					oNode.removeAllActionButtons();
					// add detail link -> custom popover
					var oDetailButton = new ActionButton({
						title: this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("ngNodeDetails"),
						icon: "sap-icon://menu",
						press: function (oEvent) {
							this._openDetail(oNode, oEvent.getParameter("buttonElement"));
						}.bind(this)
					});
					oNode.addActionButton(oDetailButton);

					//ITSDEDLC-924 - Flow in the Contract Map
					var oPopButton = new ActionButton({
						title: this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("ngPopDetails"),
						icon: "sap-icon://popup-window",
						press: function (oEvent) {
							this._popoutDetail(oNode, oEvent.getParameter("buttonElement"));
						}.bind(this)
					});
					oNode.addActionButton(oPopButton);
					// start ITLT-1134
					var Revenue_Type = oNode.getBindingContext("AppConfig").getObject().REVENUETYPE;

					if (Revenue_Type === 'Cl') {
						var oPopAriflowButton = new ActionButton({
							title: this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("ngPopAriflowButton"),
							icon: "sap-icon://process",

							press: function (oEvent) {
								this._popoutDetails(oNode, oEvent.getParameter("buttonElement"));
							}.bind(this)
						});
						oNode.addActionButton(oPopAriflowButton);

					}
					if (Revenue_Type === 'Se') {
						var oPopAriflowButtonservices = new ActionButton({
							title: this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("ngPopAriflowButtonforservices"),
							icon: "sap-icon://process",
							press: function (oEvent) {
								this._popoutDetailsservices(oNode, oEvent.getParameter("buttonElement"));
							}.bind(this)
						});
						oNode.addActionButton(oPopAriflowButtonservices);
					}
					//end  ITLT-1134

				}, this);
			}.bind(this));
			this.getUserSelectedDataStatus();
		},
		_openDetail: function (oNode, oButton) {
			var nodeDetails = oNode.getBindingContext("AppConfig").getObject().ATTRIBUTES[0];
			this.getOwnerComponent().getModel("AppConfig").setProperty("/ContractID", nodeDetails.value);
			if (!this._oNGDetailsFragment) {
				this._oNGDetailsFragment = sap.ui.xmlfragment("c2r.c2rdcd.fragments.NGDetailsFragment", this);
				this.getView().addDependent(this._oNGDetailsFragment);
			}

			//this._oNGDetailsFragment.setModel(this.getOwnerComponent().getModel("AppConfig"));
			this._oNGDetailsFragment.setBindingContext(oNode.getBindingContext("AppConfig"));
			//Begin Code for ITSDEDLC-614
			var oNodeData = this._oNGDetailsFragment.getModel("AppConfig").getProperty(oNode.getBindingContext("AppConfig").sPath);
			var oNodeModel = new sap.ui.model.json.JSONModel();
			oNodeModel.setData(oNodeData);
			this._oNGDetailsFragment.setModel(oNodeModel, "NGNodeSet");
			//End code for ITSDEDLC-614
			jQuery.sap.delayedCall(0, this, function () {
				this._oNGDetailsFragment.openBy(oButton);
			});
		},

		onCloseNGCustomPopup: function (oEvt) {
			if (this._oNGDetailsFragment) {
				this._oNGDetailsFragment.close();
			}
		},
		//adding toolbar to network graph
		ngToolbarExtention: function (caseKeyval) {
			var oResourceModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oToolbar = this.getView().byId("graph").getToolbar();
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");

			//report data issue icon added to the toolbar at last position 
			var aList = oToolbar.getContent();
			for (var i = 0; i < aList.length; i++) {
				if (aList[i].getMetadata().getName() === "sap.m.SearchField") {
					oToolbar.removeContent(aList[i]);
				}
			}
			oToolbar.insertContent(new sap.m.Select({
				items: [
					new sap.ui.core.Item({
						key: "Y",
						text: oResourceModel.getText("contractMap")
					}), new sap.ui.core.Item({
						key: "X",
						text: oResourceModel.getText("xreferenceMap")
					})
				],
				layoutData: new sap.m.OverflowToolbarLayoutData({
					group: 1
				}),
				change: function (oControlEvent) {
					var oSection = this.byId("ngSection");
					mapType = oControlEvent.getSource().getSelectedItem().getKey();
					oModelAppConfig.setProperty("/Map", mapType);
					this.getNetworkGraphData(oSection);
				}.bind(this)
			}), 0);
		},
		//call for network garph 
		getNetworkGraphData: function (oSection) {
			//network graph data
			oSection.setBusy(true);
			var aFilters = [];
			oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			var revtype = oModelAppConfig.getProperty("/revenue");
			aFilters.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, bpnumber));
			aFilters.push(new sap.ui.model.Filter("CASE_ID", sap.ui.model.FilterOperator.EQ, caseid));
			aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
			aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, "STATUS"));
			aFilters.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));
			aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "AL"));
			aFilters.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, revtype));
			aFilters.push(new sap.ui.model.Filter("XREF", sap.ui.model.FilterOperator.EQ, mapType));

			//oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			var oResourceModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var aGroups = [];
			var aLinks = [];
			var aNodes = [];
			var providerContract = [];
			var that = this; //ITSDEDLC-422
			oModelAppConfig.setProperty("/caseNodes", aNodes);
			oModelAppConfig.setProperty("/caseLines", aLinks);
			oModelAppConfig.setProperty("/caseGroups", aGroups);
			this.getOwnerComponent().getModel().read("/NGOverviewSet", {
				filters: aFilters,
				urlParameters: {
					"$expand": "NGNodeSet/NGNodeAttrSet,NGLinksSet,NGGroupsSet"
				},
				success: function (oData, response) {
					var initCallCount = 0;
					if (oData.results.length > 0) {
						aGroups = oData.results[0].NGGroupsSet.results;
						aLinks = oData.results[0].NGLinksSet.results;
						aNodes = oData.results[0].NGNodeSet.results;
						revtype = oData.results[0].NGNodeSet.results[0].REVENUETYPE;
						for (var i = 0; i < aNodes.length; i++) {
							var aATTRIBUTES = JSON.parse(aNodes[i].ATTRIBUTES.replace(/'/g, '"'));
							aNodes[i].ATTRIBUTES = aATTRIBUTES;
							/* Begin code for ITSDEDLC-422*/
							for (var j = 0; j < aATTRIBUTES.length; j++) {
								if (aATTRIBUTES[j].key === "CONTRACT_ID") {
									var oCaseId = aATTRIBUTES[j].value;
								}
								if (oCaseId === caseid) {
									for (var k = 0; k < aATTRIBUTES.length; k++) {
										if (aATTRIBUTES[k].key === "PROVIDER_CONTRACT") {
											providerContract = aATTRIBUTES[k].value;
											// if (String(providerContract).charAt(0) === '6' && revtype === "Cl") {
											// 	oModelAppConfig.setProperty("/providerContract", providerContract);
											// 	if (reportid === "" || reportid === undefined) {
											// 		that.setVisibilityO2IReport();
											// 	}
											// }
											if (String(providerContract).charAt(0) === '6' && revtype === "Cl") {
												oModelAppConfig.setProperty("/providerContract", providerContract);
												initCallCount++;
												reportid = initCallCount;
												// if (reportid === " " || reportid === undefined) {
												if (reportid === 1) {
													that.setVisibilityO2IReport();
												} else {
													reportid = " ";
												}
											}
											break;
										}
									}
								}

							}
							/* End code for ITSDEDLC-422*/
							/* End code for ITSDEDLC-422*/
						}
						oModelAppConfig.setProperty("/caseNodes", aNodes);
						oModelAppConfig.setProperty("/caseLines", aLinks);
						oModelAppConfig.setProperty("/caseGroups", aGroups);
					}
					oSection.setBusy(false);
				},
				error: function (error) {
					oSection.setBusy(false);
					sap.m.MessageToast.show(oResourceModel.getText("dataErrorNG"), {
						duration: 5000,
						width: "25em"
					});
				}
			});
		},

		/* Begin code for ITSDEDLC-422*/
		//Creation of O2I Report Billing Projection Button to Network Graph toolbar
		setVisibilityO2IReport: function () {
			// if (reportid === "" || reportid === undefined) {
			if (reportid === 1) {
				reportid = 2;
				var oResourceModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				var oButtonText = oResourceModel.getText("o2ireportbillingprojection");
				var oGraph = this.getView().byId("graph");
				// var oButton = new sap.m.Button("o2ireportid", {
				// 		class: "sapUiLargeMargin",
				// 		text: oButtonText,
				// 		type: sap.m.ButtonType.Transparent,
				// 		icon: "sap-icon://line-chart",
				// 		visible: true,
				// 		press: this.billingProjection.bind(oGraph)
				// 	})
				// 	.addStyleClass("sapUiLargeMargin");
				// oButton.addStyleClass("sapUiLargeMargin");
				// reportid = "X";
				var oButton = new sap.m.Button("o2ireportid", {
					text: oButtonText,
					type: sap.m.ButtonType.Transparent,
					icon: "sap-icon://line-chart",
					visible: true,
					press: this.billingProjection.bind(oGraph)
				});
				oToolbar = this.getView().byId("graph").getToolbar();
				oToolbar.insertContent(new ToolbarSpacer(), 1);
				oToolbar.insertContent(new ToolbarSpacer(), 2);
				oToolbar.insertContent(new ToolbarSpacer(), 3);
				oToolbar.insertContent(new ToolbarSpacer(), 4);
				oToolbar.insertContent(new ToolbarSpacer(), 5);
				oToolbar.insertContent(new ToolbarSpacer(), 6);
				oToolbar.insertContent(new ToolbarSpacer(), 7);
				oToolbar.insertContent(new ToolbarSpacer(), 8);
				oToolbar.insertContent(new ToolbarSpacer(), 9);
				oToolbar.insertContent(new ToolbarSpacer(), 10);
				oToolbar.insertContent(new ToolbarSpacer(), 11);
				oToolbar.insertContent(new ToolbarSpacer(), 12);
				oToolbar.insertContent(new ToolbarSpacer(), 13);
				oToolbar.insertContent(new ToolbarSpacer(), 14);
				oToolbar.insertContent(new ToolbarSpacer(), 15);
				oToolbar.insertContent(new ToolbarSpacer(), 16);
				oToolbar.insertContent(new ToolbarSpacer(), 17);
				oToolbar.insertContent(new ToolbarSpacer(), 18);
				oToolbar.insertContent(new ToolbarSpacer(), 19);
				oToolbar.insertContent(new ToolbarSpacer(), 20);
				oToolbar.insertContent(oButton, 21);
			}
		},

		//Clicking of O2I Report Billing Projection to SAP Web GUI Call
		billingProjection: function (oEvent) {
			var oValue = oModelAppConfig.getProperty("/providerContract");
			var oUpdatedValue = '*' + oValue + '*';
			var appConfigModel = oModelAppConfig;
			var sysInfo = appConfigModel.getProperty("/SystemsInfo").SYSID.toLowerCase(),
				sHTTPS = appConfigModel.getProperty("/protocol"),
				url = appConfigModel.getProperty("/url");

			var onBillingReportUrl = appConfigModel.getProperty("/onBillingReport");
			var sUrl = sHTTPS + sysInfo + url + onBillingReportUrl + oUpdatedValue;
			sap.m.URLHelper.redirect(sUrl, true);
		},

		/* End code for ITSDEDLC-422*/

		//data to be downloaded as pdf
		onPDFDownload: function () {
			window.print();
		},
		//OnRow Press of Invoice table on Page3
		onRowShiftAction: function (oEvent) {
			//ITSDEDLC-796 Begin code
			var oSource = oEvent.getSource();
			var oView = this.getView();
			var path = oSource.getBindingContext().sPath;
			var oInvoice = path.substring(17, 27);
			var oResourceModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			// 	oRow = oSource.getParent();
			// if (oSource.getSrc() === "sap-icon://expand") {
			// 	oSource.setSrc("sap-icon://collapse");
			// 	oRow.getCells()[5].setVisible(true);
			// } else {
			// 	oSource.setSrc("sap-icon://expand");
			// 	oRow.getCells()[5].setVisible(false);
			// }
			var ojsonModel = new JSONModel();
			this.getOwnerComponent().getModel().callFunction("/GetAdditionalID", {
				method: "GET",
				urlParameters: {
					VBELN: oInvoice
				},
				success: function (oData, response) {
					if (oData.results.length > 0 && oData.results[0].AUBEL != '0') {
						var ojsonModel = new JSONModel(oData);
						oView.setModel(ojsonModel, "invoiceData");

					} else {
						MessageToast.show(oResourceModel.getText("No_Invoices_Found"));
					}
				}, // callback function for success
				error: function (oError) {
					MessageBox.error("Error while fetching the invoice details, please try later");
				}

			});
			if (!this.oinvoiceItemLoginDialog) {
				this.oinvoiceItemLoginDialog = sap.ui.xmlfragment("idInvoiceItemlogindialog", "c2r.c2rdcd.fragments.invoicesItem", this);
				oView.addDependent(this.oinvoiceItemLoginDialog);
			}
			this.oinvoiceItemLoginDialog.openBy(oSource);
		},
		onCloseFragment: function () {
			this.oinvoiceItemLoginDialog.close();
		},
		//ITSDEDLC-796 End Code
		//Navigate to Quote Id details
		onQuoteIDPress: function (oEvt) {
			var object;
			if (oEvt.getSource().getParent().getMetadata().getName() === "sap.m.Popover") {
				object = oEvt.getSource().getModel().getData();
			} else {
				object = oEvt.getSource().getParent()._getBindingContext().getObject();
			}
			this.openQuoteID(object);
		},
		//Quote id navigation 
		openQuoteID: function (object) {
			var oRevenueType = object.REVENUETYPE;
			var oProcessType = object.PROCESS_TYPE;

			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var sHTTPS = appConfigModel.getProperty("/protocol");

			var sSystemID = appConfigModel.getProperty("/SystemsInfo").CRMSYS;
			var eSystemID = appConfigModel.getProperty("/SystemsInfo").SYSID;
			var url = appConfigModel.getProperty("/url");
			var crmUrl = appConfigModel.getProperty("/crmUrl");
			var crmUrlAction = appConfigModel.getProperty("/crmUrlAction");
			var crmUrlValue = appConfigModel.getProperty("/crmUrlValue");
			var crmUrlKeyName = appConfigModel.getProperty("/crmUrlKeyName");
			var sapRole = appConfigModel.getProperty("/sapRole");
			var flpUrl;
			if (sSystemID === "ICD" || eSystemID === "ISD") {
				flpUrl = appConfigModel.getProperty("/flpUrlDev");
			} else if (sSystemID === "ICT" || eSystemID === "IST") {
				flpUrl = appConfigModel.getProperty("/flpUrlTest");
			} else if (sSystemID === "ICP" || eSystemID === "ISP") {
				flpUrl = appConfigModel.getProperty("/flpUrlProd");
			}
			var flpHarmony = appConfigModel.getProperty("/flpHarmony");
			var flpOpp = appConfigModel.getProperty("/flpOpp");
			var flpQuote = appConfigModel.getProperty("/flpQuote");
			var sUrl;

			if (oProcessType === "" || oProcessType === null) {
				var oMissingSourceMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("errorTextMissingSource");
				MessageBox.error(oMissingSourceMsg);
				return;
			}

			var oMissingLinkMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("errorTextMissingLink");
			var prefixSubstitute = "000000000000";
			var oQuoteId = object.QUOTE_ID;

			if (oRevenueType === "Cl") {
				if (oProcessType === "Historic") {
					sUrl = sHTTPS + sSystemID + url + crmUrl + "BT116_SRVQ" + crmUrlAction + "B" + crmUrlValue +
						object.QUOTE_ID + crmUrlKeyName + "OBJECT_ID" + sapRole;
				} else if (oProcessType === "Callidus/CPQ") {
					oQuoteId = prefixSubstitute.substr(oQuoteId.length) + oQuoteId;
					sUrl = sHTTPS + flpUrl + flpHarmony + flpOpp + object.OPPORTUNITY_ID + flpQuote + oQuoteId;
				}
				sap.m.URLHelper.redirect(sUrl, true);
			} else if (oRevenueType === "On") {
				if (oProcessType === "Historic") {
					sUrl = sHTTPS + sSystemID + url + crmUrl + "ERPQUOTATION" + crmUrlAction + "B" + crmUrlValue +
						object.QUOTE_ID + crmUrlKeyName + "VBELN" + sapRole;
				} else if (oProcessType === "Callidus/CPQ") {
					oQuoteId = prefixSubstitute.substr(oQuoteId.length) + oQuoteId;
					sUrl = sHTTPS + flpUrl + flpHarmony + flpOpp + object.OPPORTUNITY_ID + flpQuote + oQuoteId;
				}
				sap.m.URLHelper.redirect(sUrl, true);
			} else {
				MessageBox.error(oMissingLinkMsg);
				return;
			}
		},
		//Navigate to Oppurtunity Id details
		onOpportunityIDPress: function (oEvent) {
			var object = oEvent.getSource().getParent()._getBindingContext().getObject();
			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var sHTTPS = appConfigModel.getProperty("/protocol");
			var sSystemID = appConfigModel.getProperty("/SystemsInfo").CRMSYS;
			var url = appConfigModel.getProperty("/url");
			var crmUrl = appConfigModel.getProperty("/crmUrl");
			var crmUrlAction = appConfigModel.getProperty("/crmUrlAction");
			var crmUrlValue = appConfigModel.getProperty("/crmUrlValue");
			var crmUrlKeyName = appConfigModel.getProperty("/crmUrlKeyName");
			var sapRole = appConfigModel.getProperty("/sapRole");
			var sUrl = sHTTPS + sSystemID + url + crmUrl + "BT111_OPPT" + crmUrlAction + "B" + crmUrlValue +
				object.OPPORTUNITY_ID + crmUrlKeyName + "OBJECT_ID" + sapRole;
			sap.m.URLHelper.redirect(sUrl, true);
		},

		onServiceContractIdPress: function (oEvent) {
			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			if (isNaN(oEvent.getSource().getText())) {
				var sServiceContracts = oEvent.getSource().getBindingContext().getObject().ServiceContractGuid;
				var aServiceContracts = sServiceContracts.split(",");
				if (!this._SCLinks) {
					this._SCLinks = sap.ui.xmlfragment(this.getView().getId(),
						"c2r.c2rdcd.fragments.ServiceContractsList", this);
					this.getView().addDependent(this._SCLinks);
				}
				var aValues = [];
				for (var i = 0; i < aServiceContracts.length; i++) {
					var oValues = {
						sc: aServiceContracts[i].split(":")[1],
						guid: aServiceContracts[i].split(":")[0]
					};
					aValues.push(oValues);
				}
				appConfigModel.setProperty("/MultiServiceContracts", aValues);
				this._SCLinks.openBy(oEvent.getSource());
			} else {
				var sHTTPS = appConfigModel.getProperty("/protocol");
				var sSystemID = appConfigModel.getProperty("/SystemsInfo").CRMSYS;
				var sCRMWEBUI = appConfigModel.getProperty("/CRMWEBUI");
				var sBT112_SC = appConfigModel.getProperty("/BT112_SC");
				var sCRMOBJ = appConfigModel.getProperty("/CRMOBJ");
				var surl = sHTTPS + sSystemID + sCRMWEBUI + sBT112_SC + sCRMOBJ + oEvent.getSource().data("guid");
				sap.m.URLHelper.redirect(surl, true);
			}
		},

		onSalesOrderIdPress: function (oEvent) {
			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			if (isNaN(oEvent.getSource().getText())) {
				var sSalesOrders = oEvent.getSource().getBindingContext().getObject().SalesOrderObj;
				var aSalesOrders = sSalesOrders.split(",");
				if (!this._SOLinks) {
					this._SOLinks = sap.ui.xmlfragment(this.getView().getId(),
						"c2r.c2rdcd.fragments.SalesOrdersList", this);
					this.getView().addDependent(this._SOLinks);
				}
				var aValues = [];
				for (var i = 0; i < aSalesOrders.length; i++) {
					var oValues = {
						so: aSalesOrders[i].split(":")[1],
						type: aSalesOrders[i].split(":")[0]
					};
					aValues.push(oValues);
				}
				appConfigModel.setProperty("/MultiSalesOrders", aValues);
				this._SOLinks.openBy(oEvent.getSource());
			} else {
				var sHTTPS = appConfigModel.getProperty("/protocol");
				var sSystemID = appConfigModel.getProperty("/SystemsInfo").SYSID;
				var sSYSURL = appConfigModel.getProperty("/url");
				var sSALESURL = "";
				if (oEvent.getSource().data("guid") === "ZS27") {
					sSALESURL = appConfigModel.getProperty("/SalesOrder43");
				} else if (oEvent.getSource().data("guid") === "ZCTF") {
					sSALESURL = appConfigModel.getProperty("/SalesOrder03");
				}
				var sNOSPLASH = appConfigModel.getProperty("/noSplash");
				if (sSALESURL === "") {
					sap.m.MessageBox.error(this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("noSalesOrderLink"));
				} else {
					var surl = sHTTPS + sSystemID + sSYSURL + sSALESURL + oEvent.getSource().getText() + sNOSPLASH;
					sap.m.URLHelper.redirect(surl, true);
				}
			}
		},

		//framework agreement link
		onOppIdPress: function (oEvent) {
			var object = oEvent.getSource().getParent()._getBindingContext().getObject();
			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var sHTTPS = appConfigModel.getProperty("/protocol");
			var sSystemID = appConfigModel.getProperty("/SystemsInfo").CRMSYS;
			var url = appConfigModel.getProperty("/url");
			var crmUrl = appConfigModel.getProperty("/crmUrl");
			var crmUrlAction = appConfigModel.getProperty("/crmUrlAction");
			var crmUrlValue = appConfigModel.getProperty("/crmUrlValue");
			var crmUrlKeyName = appConfigModel.getProperty("/crmUrlKeyName");
			var sapRole = appConfigModel.getProperty("/sapRole");
			var sUrl = sHTTPS + sSystemID + url + crmUrl + "BT111_OPPT" + crmUrlAction + "B" + crmUrlValue +
				object.OPPORTUNITY_ID + crmUrlKeyName + "OBJECT_ID" + sapRole;
			sap.m.URLHelper.redirect(sUrl, true);
		},

		//report data issue
		onHelpPress: function () {
			var i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			if (window.getSelection().baseNode === null) {
				sap.m.MessageBox.information(i18n.getText("reportDataIssueInfo"));
			} else {
				var range = window.getSelection().getRangeAt(0);
				var getSelectedField = range.startContainer.data;
				var selectedData = range.endContainer.data;
				if (getSelectedField && !selectedData) {
					selectedData = ' ';
				}
				if (selectedData === null || getSelectedField === null || !selectedData || !getSelectedField) {
					sap.m.MessageBox.information(i18n.getText("reportDataIssueInfo"));
				} else {
					sap.m.URLHelper.triggerEmail("digital.contract@sap.com", "DCD: Data Issue for Customer " + erpdescription + " (" + bpnumber +
						"), Case " + caseid + " ", "Hello " + "Team" + ", \n\n" +
						"Kindly look into the Case ( " + caseid + ") with the following details: \n" +
						"Customer name: " + erpdescription + "\n" +
						"BP Number: " + bpnumber + "\n" +
						"Country: " + countryname + "\n" +
						"Case ID: " + caseid + "\n" +
						"Data Field: " + getSelectedField + "\n" +
						"Current Value of selected Data Field: " + selectedData + "\n" +
						"Reporter User ID: " + sap.ushell.Container.getService("UserInfo").getId() + "\n\n" +
						"Describe Issue:" + "\n\n" +
						"Thanks & Regards," + "\n" +
						sap.ushell.Container.getService("UserInfo").getUser().getFullName()
					);
					window.getSelection().removeAllRanges();
				}
			}
		},

		onAfterRendering: function () { // This function must be bound to the view's afterRendering event
			this._getSystemInfo();
		},
		getobjectViewData: function () {
			var that = this;
			var ojsonModel = new JSONModel();
			var oBusyDialog = new sap.m.BusyDialog();
			oBusyDialog.open();
			this.getOwnerComponent().getModel().callFunction("/GetCaseAttributes", {
				async: true,
				method: "GET",
				urlParameters: {
					"CASE_ID": caseid
				},
				success: function (oData, response) {
					if (oData.results.length > 0) {
						ojsonModel = new JSONModel(oData);
						erpNumber = ojsonModel.getData().results[0].ERPNUMBER;
						bpnumber = ojsonModel.getData().results[0].BPNUMBER;
						caseguid = ojsonModel.getData().results[0].CASE_GUID;
						revenueType = ojsonModel.getData().results[0].REVENUETYPE;
						quoteid = ojsonModel.getData().results[0].QUOTE;
						oBusyDialog.close();
						that.bindData();
					}
				}, // callback function for success
				error: function (oError) {
						MessageBox.error("Unable to fetch data");
						// oBusyDialog.close();
					}
					// return bpnumber;
			});
			// return bpnumber;
		},
		//matches the case Id after routing
		//ITSDEDLC-2251
		// _onOverViewMatched: function (oEvent) {
		// 	var sCaseId = oEvent.getParameter("arguments").caseId;
		// 	caseid = sCaseId;
		// 	this.getobjectViewData();
		// },
		_onOverViewMatched: function (oEvent) {
			var overviewSection = this.getView().byId("idOverviewSection");
			this.getView().byId("idDCDPageObjectLayoutOVP").setSelectedSection(overviewSection);
			var oViewModel = this.getModel("appView");
			oViewModel.setProperty("/viewBusy", true);
			var sBpNumber = this.getOwnerComponent().getModel("AppConfig").getProperty("/accountId");
			this.bpnumber = sBpNumber;
			bpnumber = sBpNumber;
			var erpnumber = this.getOwnerComponent().getModel("AppConfig").getProperty("/erpNumber");
			erpNumber = erpnumber;
			this.sErpNumber = erpnumber;
			var sCaseId = oEvent.getParameter("arguments").caseId;
			caseid = sCaseId;
			var sRevenueType = oEvent.getParameter("arguments").revenuetype;
			if (sRevenueType === "CL") {
				sRevenueType = "Cl";
			} else if (sRevenueType === "SR") {
				sRevenueType = "Se";
			} else if (sRevenueType === "OP") {
				sRevenueType = "On";
			} else {
				sRevenueType = sRevenueType;
			}
			this.getOwnerComponent().getModel("AppConfig").setProperty("/bpnumber", sBpNumber);
			this.getOwnerComponent().getModel("AppConfig").setProperty("/erpNumber", erpnumber);
			this.getOwnerComponent().getModel("AppConfig").setProperty("/caseid", sCaseId);
			this.getOwnerComponent().getModel("AppConfig").setProperty("/revenue", sRevenueType);

			//invoice data
			this.caseguid = sCaseId;
			if (this.caseguid) {
				// var ocaseguid = this.caseguid.toUpperCase();
				var ocaseguid = this.caseguid;
				var aFilters = [];
				aFilters.push(new Filter("VBELN", sap.ui.model.FilterOperator.EQ, ocaseguid));
				this.byId("InvoicesTable").getBinding("items").filter(aFilters);
			}

			//	QuoteBillPlan data
			this.quoteid = oEvent.getParameter("arguments").quoteId;
			if (this.quoteid) {
				var oquoteid = this.quoteid.toUpperCase();
				var aFilters = [];
				aFilters.push(new Filter("QuoteId", sap.ui.model.FilterOperator.EQ, oquoteid));
				this.byId("QuoteBP_Table").getBinding("items").filter(aFilters);
			}
			var oSection = this.byId("ngSection");
			this.getNetworkGraphData(oSection);
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDCD_SRV;v=0002/", true);
			var sObjectPath = "/CustomerDataEntitySet(BUSINESSPARTNER='" + sBpNumber + "',ERPNUMBER='" + erpnumber + "')";
			var that = this;
			oModel.read(sObjectPath, null, null, false,
				function (oData, oResponse) {
					erpNumber = oData.ERPNUMBER;
					that.getView().byId("ObjectHeaderTitleOVP").setText(
						oData.ERPNUMBERDESCRIPTION + " (" + oData.BUSINESSPARTNER + ")"
					);
					that.getView().byId("ObjectHeaderTitleSnappedOVP").setText(
						oData.ERPNUMBERDESCRIPTION + " (" + oData.BUSINESSPARTNER + ")"
					);
					erpdescription = oData.ERPNUMBERDESCRIPTION;
					that.getView().byId("bpovp").setText(
						oData.BUSINESSPARTNER
					);
					that.getView().byId("erpnumberovp").setText(
						oData.ERPNUMBER
					);
					that.getView().byId("accountOwner").setText(
						oData.ACCOWNER_NAME
					);
					//var imsDesc = formatter.imsDecs(oData.INTERNALMARKETSEGMENT);
					that.getView().byId("imsovp").setText(oData.INTERNALMARKETSEGMENT);

					that.getView().byId("issovp").setText(
						oData.INTERNALSALESSEGMENT
					);

					that.getView().byId("iacovp").setText(
						oData.INTERNALACCOUNTCLASSIFICATION
					);

					that.getView().byId("countryovp").setText(
						oData.COUNTRYNAME
					);
					countryname = oData.COUNTRYNAME;
					that.getView().byId("regionovp").setText(
						oData.REGION
					);
					that.getView().byId("cityovp").setText(
						oData.CITY
					);
					that.getView().byId("sapmasterCodeovp").setText(
						oData.SAP_MASTERCODE_DESC
					);

				});

			var prefixSubstitue = "0000000000";
			sBpNumber = prefixSubstitue.substr(sBpNumber.length) + sBpNumber;
			erpnumber = prefixSubstitue.substr(erpnumber.length) + erpnumber;
			var prefixCaseId = "000000000000";
			sCaseId = prefixCaseId.substr(sCaseId.length) + sCaseId;

			var sPathovp = "/DCDCustomEntitySet(BUSINESSPARTNER='" + sBpNumber + "',ERPNUMBER='" + erpnumber + "',CASE_ID='" + sCaseId + "')";
			this.getView().byId("idDCDPageObjectLayoutOVP").bindElement({
				path: sPathovp,
				events: {
					dataRequested: function () {
						oViewModel.setProperty("/viewBusy", true);
					},
					dataReceived: function () {
						oViewModel.setProperty("/viewBusy", false);
					}
				}
			});

			var sTablePathProd = sPathovp + "/toDCDCockpitProductsTabSet";
			var oProdTable = this.getView().byId("dcdproductstabidovp");

			oProdTable.setTableBindingPath(sTablePathProd);

			//ITSDEDLC-906 3rd level enhancements - Custom tab
			var oXRefTable = this.getView().byId("dcdxreferencetabidovp");
			var oCustTable = this.getView().byId("dcdcustomtabidovp");

			var overviewPageFlag = this.getOwnerComponent().getModel("AppConfig").getProperty("/overviewPageFlag");
			if (overviewPageFlag) {
				oProdTable.rebindTable();
				oCustTable.rebindTable();
				oXRefTable.rebindTable();

			}
			this.getOwnerComponent().getModel("AppConfig").setProperty("/overviewPageFlag", true);

			/* Begin code for ITSDEDLC-422*/
			if (oToolbar.getContent() !== undefined) {
				var aList = oToolbar.getContent();
				for (var i = 0; i < aList.length; i++) {
					if (aList[i].getMetadata().getName() === "sap.m.Button") {
						aList[i].destroy();
						oToolbar.removeContent(aList[i]);
					}
				}
			}

		},

		bindData: function (oEvent) {
			var overviewSection = this.getView().byId("idOverviewSection");
			this.getView().byId("idDCDPageObjectLayoutOVP").setSelectedSection(overviewSection);
			var oViewModel = this.getModel("appView");
			oViewModel.setProperty("/viewBusy", true);
			var sBpNumber;
			sBpNumber = bpnumber;
			var sRevenueType;
			if (revenueType === "CL") {
				sRevenueType = "Cl";
			} else if (revenueType === "SR") {
				sRevenueType = "Se";
			} else if (revenueType === "OP") {
				sRevenueType = "On";
			} else {
				sRevenueType = revenueType;
			}
			this.getOwnerComponent().getModel("AppConfig").setProperty("/bpnumber", bpnumber);
			this.getOwnerComponent().getModel("AppConfig").setProperty("/erpNumber", erpNumber);
			this.getOwnerComponent().getModel("AppConfig").setProperty("/caseid", caseid);
			this.getOwnerComponent().getModel("AppConfig").setProperty("/revenue", sRevenueType);
			//invoice data
			this.caseguid = caseguid;
			if (this.caseguid) {
				var ocaseguid = this.caseguid.toUpperCase();
				var aFilters = [];
				aFilters.push(new Filter("VBELN", sap.ui.model.FilterOperator.EQ, ocaseguid));
				this.byId("InvoicesTable").getBinding("items").filter(aFilters);
			}
			// QuoteBillPlan data
			this.quoteid = quoteid;
			if (this.quoteid) {
				var oquoteid = this.quoteid.toUpperCase();
				var aFilters = [];
				aFilters.push(new Filter("QuoteId", sap.ui.model.FilterOperator.EQ, oquoteid));
				this.byId("QuoteBP_Table").getBinding("items").filter(aFilters);
			}
			var oSection = this.byId("ngSection");
			this.getNetworkGraphData(oSection);
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDCD_SRV;v=0002/", true);

			var sObjectPath = "/CustomerDataEntitySet(BUSINESSPARTNER='" + sBpNumber + "',ERPNUMBER='" + erpNumber + "')";
			var that = this;
			oModel.read(sObjectPath, null, null, false,
				function (oData, oResponse) {
					erpNumber = oData.ERPNUMBER;
					that.getView().byId("ObjectHeaderTitleOVP").setText(
						oData.ERPNUMBERDESCRIPTION + " (" + oData.BUSINESSPARTNER + ")"
					);
					that.getView().byId("ObjectHeaderTitleSnappedOVP").setText(
						oData.ERPNUMBERDESCRIPTION + " (" + oData.BUSINESSPARTNER + ")"
					);
					erpdescription = oData.ERPNUMBERDESCRIPTION;
					that.getView().byId("bpovp").setText(
						oData.BUSINESSPARTNER
					);
					that.getView().byId("erpnumberovp").setText(
						oData.ERPNUMBER
					);
					that.getView().byId("accountOwner").setText(
						oData.ACCOWNER_NAME
					);
					//var imsDesc = formatter.imsDecs(oData.INTERNALMARKETSEGMENT);
					that.getView().byId("imsovp").setText(oData.INTERNALMARKETSEGMENT);

					that.getView().byId("issovp").setText(
						oData.INTERNALSALESSEGMENT
					);

					that.getView().byId("iacovp").setText(
						oData.INTERNALACCOUNTCLASSIFICATION
					);

					that.getView().byId("countryovp").setText(
						oData.COUNTRYNAME
					);
					countryname = oData.COUNTRYNAME;
					that.getView().byId("regionovp").setText(
						oData.REGION
					);
					that.getView().byId("cityovp").setText(
						oData.CITY
					);
					that.getView().byId("sapmasterCodeovp").setText(
						oData.SAP_MASTERCODE_DESC
					);
				});

			var prefixSubstitue = "0000000000";
			sBpNumber = prefixSubstitue.substr(sBpNumber.length) + sBpNumber;
			erpNumber = prefixSubstitue.substr(erpNumber.length) + erpNumber;
			var prefixCaseId = "000000000000";
			var sCaseId;
			sCaseId = caseid;
			sCaseId = prefixCaseId.substr(sCaseId.length) + sCaseId;
			var sPathovp = "/DCDCustomEntitySet(BUSINESSPARTNER='" + sBpNumber + "',ERPNUMBER='" + erpNumber + "',CASE_ID='" + sCaseId + "')";
			this.getView().byId("idDCDPageObjectLayoutOVP").bindElement({
				path: sPathovp,
				events: {
					dataRequested: function () {
						oViewModel.setProperty("/viewBusy", true);
					},
					dataReceived: function () {
						oViewModel.setProperty("/viewBusy", false);
					}
				}
			});

			var sTablePathProd = sPathovp + "/toDCDCockpitProductsTabSet";
			var oProdTable = this.getView().byId("dcdproductstabidovp");

			oProdTable.setTableBindingPath(sTablePathProd);

			// ITSDEDLC-906 3rd level enhancements - Custom tab
			var oXRefTable = this.getView().byId("dcdxreferencetabidovp");
			var oCustTable = this.getView().byId("dcdcustomtabidovp");

			var overviewPageFlag = this.getOwnerComponent().getModel("AppConfig").getProperty("/overviewPageFlag");
			if (overviewPageFlag) {
				oProdTable.rebindTable();
				oCustTable.rebindTable();
				oXRefTable.rebindTable();

			}
			this.getOwnerComponent().getModel("AppConfig").setProperty("/overviewPageFlag", true);

			// /* Begin code for ITSDEDLC-422*/
			if (oToolbar.getContent() !== undefined) {
				var aList = oToolbar.getContent();
				for (var i = 0; i < aList.length; i++) {
					if (aList[i].getMetadata().getName() === "sap.m.Button") {
						aList[i].destroy();
						oToolbar.removeContent(aList[i]);
					}
				}
			}

		},

		// Start of code added by C5270230 on 26-sep-2023 as per JIRA ID: ITSDEDLC-1828
		// XReference Information Data Sarts Here
		ReportInformation_XRef: function () {
			if (!this.Disp_Info_XReference_Search_Dialog) {
				this.Disp_Info_XReference_Search_Dialog = this.loadFragment({
					name: "c2r.c2rdcd.view.DispInfoXRef"
				});
			}
			this.Disp_Info_XReference_Search_Dialog.then(function (oDialog_Disp_Info_XReference) {
				oDialog_Disp_Info_XReference.open();
			});
		},
		Disp_Info_XReference_Search_Button: function () {
			this.byId("Disp_Info_XReference_Search_Dialog").close();
		},
		// XReference Information Ends Here
		// End of code added by C5270230 on 26-sep-2023 as per JIRA ID: ITSDEDLC-1828

		// Begin Code ITSDEDLC-930 for getting the user preferred data hide/expand
		getUserSelectedDataStatus: function () {
			var that = this;
			this.ojsonDataStatusModel = new JSONModel();
			this.getOwnerComponent().getModel().callFunction("/GetDataStatus", {
				method: "GET",
				urlParameters: {
					"DATA_SECTION": '',
					"STATUS": ''
				},
				success: function (oData, response) {
					if (oData.results.length > 0) {
						this.ojsonDataStatusModel = new JSONModel(oData);
						for (var i = 0; i < oData.results.length; i++) {
							var dataHeaderName = oData.results[i].DATA_SECTION;
							var dataHeaderNameStatus = oData.results[i].STATUS;
							if (dataHeaderName === "Overview" && dataHeaderNameStatus === "X") {
								that.getView().byId("overviewSubSection").setVisible(false);
								that.getView().byId("overviewShow").setIcon("sap-icon://add");
								// that.getView().byId("overviewShow").setText("Show More");
							} else if (dataHeaderName === "Products" && dataHeaderNameStatus === "X") {
								that.getView().byId("productsSubSection").setVisible(false);
								that.getView().byId("productShow").setIcon("sap-icon://add");
								// that.getView().byId("productShow").setText("Show More");
							} else if (dataHeaderName === "Contractual Clauses" && dataHeaderNameStatus === "X") {
								that.getView().byId("cclausesSubSection").setVisible(false);
								that.getView().byId("cclausesShow").setIcon("sap-icon://add");

							} else if (dataHeaderName === "Customer Contacts" && dataHeaderNameStatus === "X") {
								that.getView().byId("ccontractsSubSection").setVisible(false);
								that.getView().byId("ccontractsShow").setIcon("sap-icon://add");

							} else if (dataHeaderName === "Dates" && dataHeaderNameStatus === "X") {
								that.getView().byId("datesSubSection").setVisible(false);
								that.getView().byId("datesShow").setIcon("sap-icon://add");

							} else if (dataHeaderName === "Deal Structure" && dataHeaderNameStatus === "X") {
								that.getView().byId("dealStructureSubSection").setVisible(false);
								that.getView().byId("dealStructureShow").setIcon("sap-icon://add");

							} else if (dataHeaderName === "Payment and Invoicing" && dataHeaderNameStatus === "X") {
								that.getView().byId("payInvoiceSubSection").setVisible(false);
								that.getView().byId("payInvoiceShow").setIcon("sap-icon://add");

							} else if (dataHeaderName === "Security" && dataHeaderNameStatus === "X") {
								that.getView().byId("securitySubSection").setVisible(false);
								that.getView().byId("securityShow").setIcon("sap-icon://add");

							} else if (dataHeaderName === "Custom" && dataHeaderNameStatus === "X") {
								that.getView().byId("customSubSection").setVisible(false);
								that.getView().byId("customShow").setIcon("sap-icon://add");

							} else if (dataHeaderName === "Contract Map" && dataHeaderNameStatus === "X") {
								that.getView().byId("contractSubSection").setVisible(false);
								that.getView().byId("contractShow").setIcon("sap-icon://add");
							} else if (dataHeaderName === "X-Reference" && dataHeaderNameStatus === "X") {
								that.getView().byId("xreferenceSubSection").setVisible(false);
								that.getView().byId("xreferenceShow").setIcon("sap-icon://add");
							}
						}
					} else {
						// MessageToast.show(oResourceModel.getText("No_Invoices_Found"));
					}
				}, // callback function for success
				error: function (oError) {
					MessageBox.error("Error while fetching the User preferred data");
				}
			});
		},
		// send the user preferred selection for hide/expand
		sendUserSelectedDataStatus: function (oEvent) {
			var ojsonModel = new JSONModel();
			this.getOwnerComponent().getModel().callFunction("/GetDataStatusSave", {
				method: "GET",
				urlParameters: {
					"DATA_SECTION": userSelectedObject,
					"STATUS": userSelectedObjectStatus
				},
				success: function (oData, response) {
					if (oData.results.length > 0) {
						ojsonModel = new JSONModel(oData);
						// oView.setModel(ojsonModel, "invoiceData");

					} else {
						MessageToast.show("Unable to send the user selected preference");
					}
				}, // callback function for success
				error: function (oError) {
					MessageBox.error("Unable to send the user selected preference");
				}
			});

		},
		onProductsDetaiLessSelect: function (oEvent) {
			var productVisible = this.getView().byId("productsSubSection").getVisible();
			if (productVisible === true) {
				this.getView().byId("productsSubSection").setVisible(false);
				this.getView().byId("productShow").setIcon("sap-icon://add");
				// this.getView().byId("productShow").setText("Show More");
				userSelectedObject = 'Products';
				userSelectedObjectStatus = 'X';
				this.sendUserSelectedDataStatus();
			} else {
				this.getView().byId("productsSubSection").setVisible(true);
				this.getView().byId("productShow").setIcon("sap-icon://less");
				// this.getView().byId("productShow").setText("Show Less");
				userSelectedObject = 'Products';
				userSelectedObjectStatus = '';
				this.sendUserSelectedDataStatus();
			}
		},
		onCClausesDetaiLessSelect: function (oEvent) {
			var cclausesVisible = this.getView().byId("cclausesSubSection").getVisible();
			if (cclausesVisible === true) {
				this.getView().byId("cclausesSubSection").setVisible(false);
				this.getView().byId("cclausesShow").setIcon("sap-icon://add");
				// this.getView().byId("cclausesShow").setText("Show More");
				userSelectedObject = 'Contractual Clauses';
				userSelectedObjectStatus = 'X';
				this.sendUserSelectedDataStatus();
			} else {
				this.getView().byId("cclausesSubSection").setVisible(true);
				this.getView().byId("cclausesShow").setIcon("sap-icon://less");
				// this.getView().byId("cclausesShow").setText("Show Less");
				userSelectedObject = 'Contractual Clauses';
				userSelectedObjectStatus = '';
				this.sendUserSelectedDataStatus();
			}
		},
		onOverViewDetaiLessSelect: function (oEvent) {
			var overviewVisible = this.getView().byId("overviewSubSection").getVisible();
			if (overviewVisible === true) {
				this.getView().byId("overviewSubSection").setVisible(false);
				this.getView().byId("overviewShow").setIcon("sap-icon://add");
				// this.getView().byId("overviewShow").setText("Show More");
				userSelectedObject = 'Overview';
				userSelectedObjectStatus = 'X';
				this.sendUserSelectedDataStatus();
			} else {
				this.getView().byId("overviewSubSection").setVisible(true);
				this.getView().byId("overviewShow").setIcon("sap-icon://less");
				// this.getView().byId("overviewShow").setText("Show Less");
				userSelectedObject = 'Overview';
				userSelectedObjectStatus = '';
				this.sendUserSelectedDataStatus();
			}
		},
		onccontractsDetaiLessSelect: function (oEvent) {
			var ccontractsVisible = this.getView().byId("ccontractsSubSection").getVisible();
			if (ccontractsVisible === true) {
				this.getView().byId("ccontractsSubSection").setVisible(false);
				this.getView().byId("ccontractsShow").setIcon("sap-icon://add");
				// this.getView().byId("ccontractsShow").setText("Show More");
				userSelectedObject = 'Customer Contacts';
				userSelectedObjectStatus = 'X';
				this.sendUserSelectedDataStatus();
			} else {
				this.getView().byId("ccontractsSubSection").setVisible(true);
				this.getView().byId("ccontractsShow").setIcon("sap-icon://less");
				// this.getView().byId("ccontractsShow").setText("Show Less");
				userSelectedObject = 'Customer Contacts';
				userSelectedObjectStatus = '';
				this.sendUserSelectedDataStatus();
			}
		},
		onDatesDetaiLessSelect: function (oEvent) {
			var datesVisible = this.getView().byId("datesSubSection").getVisible();
			if (datesVisible === true) {
				this.getView().byId("datesSubSection").setVisible(false);
				this.getView().byId("datesShow").setIcon("sap-icon://add");
				// this.getView().byId("datesShow").setText("Show More");
				userSelectedObject = 'Dates';
				userSelectedObjectStatus = 'X';
				this.sendUserSelectedDataStatus();
			} else {
				this.getView().byId("datesSubSection").setVisible(true);
				this.getView().byId("datesShow").setIcon("sap-icon://less");
				// this.getView().byId("datesShow").setText("Show Less");
				userSelectedObject = 'Dates';
				userSelectedObjectStatus = '';
				this.sendUserSelectedDataStatus();
			}
		},
		onDealStructureDetaiLessSelect: function (oEvent) {
			var dealStructureVisible = this.getView().byId("dealStructureSubSection").getVisible();
			if (dealStructureVisible === true) {
				this.getView().byId("dealStructureSubSection").setVisible(false);
				this.getView().byId("dealStructureShow").setIcon("sap-icon://add");
				// this.getView().byId("dealStructureShow").setText("Show More");
				userSelectedObject = 'Deal Structure';
				userSelectedObjectStatus = 'X';
				this.sendUserSelectedDataStatus();
			} else {
				this.getView().byId("dealStructureSubSection").setVisible(true);
				this.getView().byId("dealStructureShow").setIcon("sap-icon://less");
				// this.getView().byId("dealStructureShow").setText("Show Less");
				userSelectedObject = 'Deal Structure';
				userSelectedObjectStatus = '';
				this.sendUserSelectedDataStatus();
			}
		},
		onPayInvoiceDetaiLessSelect: function (oEvent) {
			var payInvoiceVisible = this.getView().byId("payInvoiceSubSection").getVisible();
			if (payInvoiceVisible === true) {
				this.getView().byId("payInvoiceSubSection").setVisible(false);
				this.getView().byId("payInvoiceShow").setIcon("sap-icon://add");
				// this.getView().byId("payInvoiceShow").setText("Show More");
				userSelectedObject = 'Payment and Invoicing';
				userSelectedObjectStatus = 'X';
				this.sendUserSelectedDataStatus();
			} else {
				this.getView().byId("payInvoiceSubSection").setVisible(true);
				this.getView().byId("payInvoiceShow").setIcon("sap-icon://less");
				// this.getView().byId("payInvoiceShow").setText("Show Less");
				userSelectedObject = 'Payment and Invoicing';
				userSelectedObjectStatus = '';
				this.sendUserSelectedDataStatus();
			}
		},
		onSecurityDetaiLessSelect: function (oEvent) {
			var securityVisible = this.getView().byId("securitySubSection").getVisible();
			if (securityVisible === true) {
				this.getView().byId("securitySubSection").setVisible(false);
				this.getView().byId("securityShow").setIcon("sap-icon://add");
				// this.getView().byId("securityShow").setText("Show More");
				userSelectedObject = 'Security';
				userSelectedObjectStatus = 'X';
				this.sendUserSelectedDataStatus();
			} else {
				this.getView().byId("securitySubSection").setVisible(true);
				this.getView().byId("securityShow").setIcon("sap-icon://less");
				// this.getView().byId("securityShow").setText("Show Less");
				userSelectedObject = 'Security';
				userSelectedObjectStatus = '';
				this.sendUserSelectedDataStatus();
			}
		},
		onCustomDetaiLessSelect: function (oEvent) {
			var customVisible = this.getView().byId("customSubSection").getVisible();
			if (customVisible === true) {
				this.getView().byId("customSubSection").setVisible(false);
				this.getView().byId("customShow").setIcon("sap-icon://add");
				// this.getView().byId("customShow").setText("Show More");
				userSelectedObject = 'Custom';
				userSelectedObjectStatus = 'X';
				this.sendUserSelectedDataStatus();
			} else {
				this.getView().byId("customSubSection").setVisible(true);
				this.getView().byId("customShow").setIcon("sap-icon://less");
				// this.getView().byId("customShow").setText("Show Less");
				userSelectedObject = 'Custom';
				userSelectedObjectStatus = '';
				this.sendUserSelectedDataStatus();
			}
		},
		onxreferenceDetaiLessSelect: function (oEvent) {
			var xreferenceVisible = this.getView().byId("xreferenceSubSection").getVisible();
			if (xreferenceVisible === true) {
				this.getView().byId("xreferenceSubSection").setVisible(false);
				this.getView().byId("xreferenceShow").setIcon("sap-icon://add");
				// this.getView().byId("contractShow").setText("Show More");
				userSelectedObject = 'X-Reference';
				userSelectedObjectStatus = 'X';
				this.sendUserSelectedDataStatus();
			} else {
				this.getView().byId("xreferenceSubSection").setVisible(true);
				this.getView().byId("xreferenceShow").setIcon("sap-icon://less");
				// this.getView().byId("contractShow").setText("Show Less");
				userSelectedObject = 'X-Reference';
				userSelectedObjectStatus = '';
				this.sendUserSelectedDataStatus();
			}
		},
		onContractDetaiLessSelect: function (oEvent) {
			var contractVisible = this.getView().byId("contractSubSection").getVisible();
			if (contractVisible === true) {
				this.getView().byId("contractSubSection").setVisible(false);
				this.getView().byId("contractShow").setIcon("sap-icon://add");
				// this.getView().byId("contractShow").setText("Show More");
				userSelectedObject = 'Contract Map';
				userSelectedObjectStatus = 'X';
				this.sendUserSelectedDataStatus();
			} else {
				this.getView().byId("contractSubSection").setVisible(true);
				this.getView().byId("contractShow").setIcon("sap-icon://less");
				// this.getView().byId("contractShow").setText("Show Less");
				userSelectedObject = 'Contract Map';
				userSelectedObjectStatus = '';
				this.sendUserSelectedDataStatus();
			}
		},
		// End code  ITSDEDLC-930 
		onSecondLevel: function (oEvt) {
			var url = window.location.href;
			var surl = url.split("CaseOverView")[0] + "CustomerDataEntitySet/" + bpnumber + "/" + erpNumber;
			window.open(surl, "_self").location.reload();
		},
		//ITSDEDLC-906 3rd level enhancements - Custom tab
		onBeforeRebindTableDetails: function (oEvent) {

			var sBpNumber = this.getOwnerComponent().getModel("AppConfig").getProperty("/bpnumber");
			var erpnumber = this.getOwnerComponent().getModel("AppConfig").getProperty("/erpNumber");
			var sCaseId = this.getOwnerComponent().getModel("AppConfig").getProperty("/caseid");

			var prefixSubstitue = "0000000000";
			sBpNumber = prefixSubstitue.substr(sBpNumber.length) + sBpNumber;
			erpnumber = prefixSubstitue.substr(erpnumber.length) + erpnumber;
			var prefixCaseId = "000000000000";
			sCaseId = prefixCaseId.substr(sCaseId.length) + sCaseId;

			var oBindingParams = oEvent.getParameter("bindingParams");
			oBindingParams.filters.push(new sap.ui.model.Filter({
				path: "BUSINESSPARTNER",
				operator: FilterOperator.EQ,
				value1: sBpNumber
			}));
			oBindingParams.filters.push(new sap.ui.model.Filter({
				path: "ERPNUMBER",
				operator: FilterOperator.EQ,
				value1: erpNumber
			}));
			oBindingParams.filters.push(new sap.ui.model.Filter({
				path: "CASE_ID",
				operator: FilterOperator.EQ,
				value1: sCaseId
			}));

		}
	});
});