var Revenue_Type_Val = "";
/*global Uint8Array */
sap.ui.define([
	"sap/suite/ui/generic/template/extensionAPI/extensionAPI",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"c2r/c2rdcd/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"c2r/c2rdcd/model/formatter",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/ButtonType",
	"sap/m/Text",
	'sap/m/Tokenizer',
	"sap/m/Token",
	"sap/m/MultiInput",
	"sap/m/Label",
	"sap/ui/core/Icon",
	"sap/suite/ui/commons/networkgraph/ActionButton",
	"c2r/c2rdcd/controller/ErrorHandler"

], function (extensionAPI, Filter, FilterOperator, MessageBox,
	BaseController,
	JSONModel,
	History,
	formatter,
	Button,
	Dialog,
	DialogType,
	ButtonType,
	Text,
	Tokenizer,
	Token,
	MultiInput,
	Label,
	Icon,
	ActionButton,
	ErrorHandler
) {
	"use strict";
	var obp;
	var erpNumber;
	var bpnumber;
	var oExpandBtnClick;
	var oGrpByType;
	var oRevType;
	var oMapType_val;
	var oCaseID;
	var objectPath;
	return BaseController.extend("c2r.c2rdcdtroller.Object", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data

			var iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy: true,
					delay: 0
				});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function () {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			// SAP Web Analytics 
			var swa = {
				pubToken: 'b2c87a00-8a5d-8b92-b83b-3489b5e7b447',
				baseUrl: 'https://webanalytics.cfapps.eu10.hana.ondemand.com/tracker/'
			};
			window.swa = swa;
			(function () {
				var d = document,
					g = d.createElement('script'),
					s = d.getElementsByTagName('script')[0];
				g.type = 'text/javascript';
				g.defer = true;
				g.async = true;
				g.src = swa.baseUrl + 'js/privacy.js';
				s.parentNode.insertBefore(g, s);
			})();
			// SAP Web Analytics 
			oExpandBtnClick = 0;
			oGrpByType = "";
			oCaseID = "";
			oRevType = "";
			//Sales Org,Distribution Channel,Doc Category data load for contract map filters
			this.getSalesOrgfilterdata();
			this.getDisChannelfilterdata();
			this.getDocCategoryfilterdata();
			//graph toolbar extention 
			this.ngToolbarExtention();

			//graph extention

			this._graph = this.getView().byId("graph");
			this._graph.attachEvent("beforeLayouting", function (oEvent) {
				this._graph.preventInvalidation(true);
				this._graph.getNodes().forEach(function (oNode) {
					oNode.removeAllActionButtons();
					// add detail link -> custom popover
					var oDetailButton = new ActionButton({
						title: this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("ngNodeDetails"),
						icon: "sap-icon://menu",
						press: function (oEvent) {
							this._openDetail(oNode, oEvent.getParameter("buttonElement"));
						}.bind(this)
					});
					oNode.addActionButton(oDetailButton);

					// var oNodeButton = new ActionButton({
					// 	title: "Filter map to related deals",
					// 	icon: "sap-icon://filter",
					// 	press: function (oControlEvent) {
					// 		if (oExpandBtnClick == 1) {
					// 			oExpandBtnClick = 0;
					// 		} else {
					// 			oExpandBtnClick = 1;
					// 		}
					// 		var oSection = oControlEvent.getSource().getParent().getParent().getParent().getParent();
					// 		var aFilters = [];
					// 		if (oExpandBtnClick === 1) {
					// 			oCaseID = oNode.getKey();
					// 			aFilters.push(new sap.ui.model.Filter("CASE_ID", sap.ui.model.FilterOperator.EQ, oCaseID));
					// 			aFilters.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, null));
					// 			aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
					// 			aFilters.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));
					// 			aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "AL"));
					// 			this.getNetworkGraphData(aFilters, oSection, oControlEvent);
					// 		} else {
					// 			aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, "PERIOD"));
					// 			aFilters.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, "CL"));
					// 			aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "AL"));
					// 			this.getNetworkGraphData(aFilters, this.getView().byId("objectPageLayout").getSections()[0]);
					// 		}
					// 	}.bind(this)
					// });
					var oNodeButton = new ActionButton({
						title: "Filter map to related deals",
						icon: "sap-icon://filter",
						press: function (oControlEvent) {
							if (oExpandBtnClick == 1) {
								oExpandBtnClick = 0;
							} else {
								oExpandBtnClick = 1;
							}
							var oSection = oControlEvent.getSource().getParent().getParent().getParent().getParent();
							var aFilters = [];
							Revenue_Type_Val = oNode.getBindingContext("AppConfig").getObject().REVENUETYPE;
							if (oExpandBtnClick === 1) {
								oCaseID = oNode.getKey();
								aFilters.push(new sap.ui.model.Filter("CASE_ID", sap.ui.model.FilterOperator.EQ, oCaseID));
								// aFilters.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, null));
								aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
								// aFilters.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));
								aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "AL"));
								// aFilters.push(new sap.ui.model.Filter("XREF", sap.ui.model.FilterOperator.EQ, "Y"));
								this.getNetworkGraphData(aFilters, oSection, oControlEvent);
							} else {
								// aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, "PERIOD"));
								// aFilters.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, "CL"));
								aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "AL"));
								aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
								// aFilters.push(new sap.ui.model.Filter("XREF", sap.ui.model.FilterOperator.EQ, "Y"));
								this.getNetworkGraphData(aFilters, this.getView().byId("objectPageLayout").getSections()[0]);
							}
						}.bind(this)
					});
					oNode.addActionButton(oNodeButton);

					//ITSDEDLC-924 - Flow in the Contract Map
					var oPopButton = new ActionButton({
						title: this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("ngPopDetails"),
						icon: "sap-icon://popup-window",
						press: function (oEvent) {
							this._popoutDetail(oNode, oEvent.getParameter("buttonElement"));
						}.bind(this)
					});
					oNode.addActionButton(oPopButton);

					// ITSDEDLC-1658
					var Revenue_Type = oNode.getBindingContext("AppConfig").getObject().REVENUETYPE;

					if (Revenue_Type === 'Cl') {
						var oPopAriflowButton = new ActionButton({
							title: this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("ngPopAriflowButton"),
							icon: "sap-icon://process",

							press: function (oEvent) {
								this._popoutDetails(oNode, oEvent.getParameter("buttonElement"));
							}.bind(this)
						});
						oNode.addActionButton(oPopAriflowButton);

					}

					//ITSDEDLC-1671
					if (Revenue_Type === 'Se') {
						var oPopAriflowButtonservices = new ActionButton({
							title: this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("ngPopAriflowButtonforservices"),
							icon: "sap-icon://process",
							press: function (oEvent) {
								this._popoutDetailsservices(oNode, oEvent.getParameter("buttonElement"));
							}.bind(this)
						});
						oNode.addActionButton(oPopAriflowButtonservices);
					}

				}, this);
				this._graph.preventInvalidation(false);
			}.bind(this));
			// this._iEvent = 0;
			// Changes by C5341161 for ITLT-1075
			var oSmartFilter = this.getView().byId("smartFilterBar");
			//Ensure that there is no default Variant set by the user. 
			//In such a case, do not set default Variant.
			var sDefaultVariantKey = oSmartFilter.getVariantManagement().getDefaultVariantKey();
			//If No variant is set, default variant is "standard"
			if (sDefaultVariantKey !== "*Standard*") {
				return;
			}

			//Set the Global Variant as the current Variant
			oSmartFilter.getVariantManagement().setCurrentVariantKey("Security Non-Standard");
			// End of Changes by C5341161 for ITLT-1075
		},

		//open details menu for NG graph
		_openDetail: function (oNode, oButton) {
			var nodeDetails = oNode.getBindingContext("AppConfig").getObject().ATTRIBUTES[0];
			this.getOwnerComponent().getModel("AppConfig").setProperty("/ContractID", nodeDetails.value);
			if (!this._oNGDetailsFragment) {
				this._oNGDetailsFragment = sap.ui.xmlfragment("c2r.c2rdcd.fragments.NGDetailsFragment", this);
				this.getView().addDependent(this._oNGDetailsFragment);
			}

			//this._oNGDetailsFragment.setModel(this.getOwnerComponent().getModel("AppConfig"));
			this._oNGDetailsFragment.setBindingContext(oNode.getBindingContext("AppConfig"));
			//Begin Code for ITSDEDLC-614
			var oNodeData = this._oNGDetailsFragment.getModel("AppConfig").getProperty(oNode.getBindingContext("AppConfig").sPath);
			var oNodeModel = new sap.ui.model.json.JSONModel();
			oNodeModel.setData(oNodeData);
			this._oNGDetailsFragment.setModel(oNodeModel, "NGNodeSet");
			//End code for ITSDEDLC-614
			jQuery.sap.delayedCall(0, this, function () {
				this._oNGDetailsFragment.openBy(oButton);
			});
		},

		//event handler to open the NG menu dropdown
		onNGMenuAction: function (oEvent) {
			var key = oEvent.getParameter("item").getKey();
			// var sSalesOrg = oEvent.getSource().getBindingContext().getObject().SALESORG;
			var appConfigmodel = this.getOwnerComponent().getModel("AppConfig");
			var sHTTPS = appConfigmodel.getProperty("/protocol");
			switch (key) {
			case "0":
				// var sUrl = sHTTPS + "cmsrf-sapitcloud.dispatcher.hana.ondemand.com/#/REQUESTFORM_TYPE=FA/" + sSalesOrg;
				var sUrl = sHTTPS + "cmsrf-sapitcloud.dispatcher.hana.ondemand.com/#/REQUESTFORM_TYPE=FA/";
				sap.m.URLHelper.redirect(sUrl, true);
				break;
			case "1":
				//var sUrl = sHTTPS + "cmsrf-sapitcloud.dispatcher.hana.ondemand.com/#/REQUESTFORM_TYPE=NDAG/" + sSalesOrg;
				var sUrl = sHTTPS + "cmsrf-sapitcloud.dispatcher.hana.ondemand.com/#/REQUESTFORM_TYPE=NDAG/LANGUAGE=EN";
				sap.m.URLHelper.redirect(sUrl, true);
				break;
			case "2":
				//var sUrl = sHTTPS + "cmsrf-sapitcloud.dispatcher.hana.ondemand.com/#/REQUESTFORM_TYPE=CT/" + sSalesOrg;
				var sUrl = sHTTPS + "cmsrf-sapitcloud.dispatcher.hana.ondemand.com/#/REQUESTFORM_TYPE=CT/";
				sap.m.URLHelper.redirect(sUrl, true);
				break;
			default:
				return;
			}
		},

		onCloseNGCustomPopup: function (oEvt) {
			if (this._oNGDetailsFragment) {
				this._oNGDetailsFragment.close();
			}
		},

		//adding toolbar to network graph
		ngToolbarExtention: function (caseKeyval) {
			var oResourceModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oToolbar = this.getView().byId("graph").getToolbar();
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			//report data issue icon added to the toolbar at last position 
			var aList = oToolbar.getContent();
			for (var i = 0; i < aList.length; i++) {
				if (aList[i].getMetadata().getName() === "sap.m.SearchField") {
					oToolbar.removeContent(aList[i]);
				}
			}
			var oIcon = new Icon({
				src: "sap-icon://alert",
				tooltip: oResourceModel.getText("reportNetworkGraphIssue"),
				press: function () {
					sap.m.URLHelper.triggerEmail("digital.contract@sap.com", "DCD: Data Issue for Network graph",
						"Hi," + "\n\n" +
						"Thank you for reaching out to the DCD Team. In order to better assist you, please specify in detail the issue(s) you want to report using the below format. Regardless of your issue, please provide:" +
						"\n\n" +
						"1)	Customer Account number (BP or ERP): " + this.sAccountId + "\n" +
						"2)	Relevant contract number (CMS case ID)" + "\n\n" +
						"a)	Is your issue regarding a missing connection?  (If Yes, please provide more details)." + "\n\n\n" +
						"b)	Is your issue regarding wrong classification (eg amendment, upsell, initial order, etc? (If Yes, please provide more details)." +
						"\n\n\n" +
						"c)	Is your issue regarding a missing contract for your customer? (If Yes, please provide more details)." + "\n\n\n" +
						"d)	Based on the above information, please describe the issue in detail, so we can further investigate." + "\n\n\n" +
						"e)	Any additional information you can provide will help us accelerate finding a solution." + "\n\n\n" +
						"Thanks & Regards," + "\n" +
						sap.ushell.Container.getService("UserInfo").getUser().getFullName()
					);
				}.bind(this)
			});
			oToolbar.insertContent(oIcon, oToolbar.getContent().length);

			oToolbar.insertContent(new Label({
				text: oResourceModel.getText("groupBy"),
				layoutData: new sap.m.OverflowToolbarLayoutData({
					group: 1
				})
			}), 0);

			oToolbar.insertContent(new sap.m.Select({
				items: [
					new sap.ui.core.Item({
						key: "PERIOD",
						text: oResourceModel.getText("periodNG")
					}), new sap.ui.core.Item({
						key: "STATUS",
						text: oResourceModel.getText("statusNG")
					})
				],
				layoutData: new sap.m.OverflowToolbarLayoutData({
					group: 1
				}),

				change: function (oControlEvent) {
					oExpandBtnClick = 0;
					var oSection = oControlEvent.getSource().getParent().getParent().getParent().getParent();
					//	oSection.setBusy(true);
					var aFilters = [];
					// aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", "EQ", oControlEvent.getSource().getSelectedItem().getKey()));
					oGrpByType = oControlEvent.getSource().getSelectedItem().getKey();
					oModelAppConfig.setProperty("/groupBy", oGrpByType);
					// aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
					//}
					if (oExpandBtnClick === 1) {
						//	oSection.setBusy(true);
						// aFilters.push(new sap.ui.model.Filter("CASE_ID", sap.ui.model.FilterOperator.EQ, oCaseID));
						// aFilters.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, this.sAccountId));
						// aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
						// aFilters.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));
						// aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "AL"));
						this.getNetworkGraphData(aFilters, oSection, oControlEvent);
					} else {
						var aSolutionTypeKeys = oControlEvent.getSource().getParent().getContent()[3].getSelectedItems();
						if (aSolutionTypeKeys.length > 0) {
							for (var j = 0; j < aSolutionTypeKeys.length; j++) {
								aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", "EQ", aSolutionTypeKeys[j].getProperty("key")));
							}
						}
						this.getNetworkGraphData(aFilters, oSection);
					}
				}.bind(this)
			}), 1);

			// 	change: function (oControlEvent) {
			// 		oExpandBtnClick = 0;
			// 		var oSection = oControlEvent.getSource().getParent().getParent().getParent().getParent();
			// 		//	oSection.setBusy(true);
			// 		var aFilters = [];
			// 		//ITSDEDLC-812 aCaseToken has been commented as Contract ID search field is hidden
			// 		//var aCaseToken = oControlEvent.getSource().getParent().getContent()[7].getTokens();
			// 		aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", "EQ", oControlEvent.getSource().getSelectedItem().getKey()));
			// 		oGrpByType = oControlEvent.getSource().getSelectedItem().getKey();
			// 		//ITSDEDLC-812 selected group type has been set to Appconfig model
			// 		oModelAppConfig.setProperty("/groupBy", oGrpByType);

			// 		// aFilters.push(new sap.ui.model.Filter("REVENUETYPE", "EQ", oControlEvent.getSource().getParent().getContent()[3].getSelectedItem()
			// 		// 	.getKey()));
			// 		//ITSDEDLC-812 aCaseToken has been commented as Contract ID search field is hidden
			// 		// for (i = 0; i < aCaseToken.length; i++) {
			// 		// 	aFilters.push(new sap.ui.model.Filter("CASE_ID", "EQ", aCaseToken[i].getText()));
			// 		// }
			// 		//ITSDEDLC-812 aCaseToken has been commented as Contract ID search field is hidden
			// 		// if (aCaseToken.length > 0) {
			// 		// 	aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
			// 		// } else {

			// 		aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
			// 		//}
			// 		if (oExpandBtnClick === 1) {
			// 			//	oSection.setBusy(true);
			// 			aFilters.push(new sap.ui.model.Filter("CASE_ID", sap.ui.model.FilterOperator.EQ, oCaseID));
			// 			aFilters.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, this.sAccountId));
			// 			aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
			// 			aFilters.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));
			// 			aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "AL"));
			// 			// aFilters.push(new sap.ui.model.Filter("REVENUETYPE", "EQ", oControlEvent.getSource().getParent().getContent()[3].getSelectedItem()
			// 			// .getKey()));
			// 			this.getNetworkGraphData(aFilters, oSection, oControlEvent);
			// 		} else {
			// 			var aSolutionTypeKeys = oControlEvent.getSource().getParent().getContent()[3].getSelectedItems();
			// 			if (aSolutionTypeKeys.length > 0) {
			// 				for (var j = 0; j < aSolutionTypeKeys.length; j++) {
			// 					aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", "EQ", aSolutionTypeKeys[j].getProperty("key")));
			// 				}
			// 			}
			// 			this.getNetworkGraphData(aFilters, oSection);
			// 		}
			// 	}.bind(this)
			// }), 1);
			// ITSDCDLEC - 957 Moving revenue type filter towards other filter 
			//Revenue Type dropdown
			/*			oToolbar.insertContent(new Label({
							text: oResourceModel.getText("revenueTypeNG"),
							layoutData: new sap.m.OverflowToolbarLayoutData({
								group: 2
							})
						}), 2);*/

			/*			oToolbar.insertContent(new sap.m.Select({
							items: [
								//ITSDEDLC-812 - Added new new Revenue Type ALL
								new sap.ui.core.Item({
									key: "Al",
									text: oResourceModel.getText("alNG")
								}),
								new sap.ui.core.Item({
									key: "Cl",
									text: oResourceModel.getText("cloudNG")
								}),
								new sap.ui.core.Item({
									key: "On",
									text: oResourceModel.getText("onPremNG")
								}),
								new sap.ui.core.Item({
									key: "Se",
									text: oResourceModel.getText("serviceNG")
								}),
								//ITSDEDLC-779 - Added new Revenue Type ND 
								new sap.ui.core.Item({
									key: "ND",
									text: oResourceModel.getText("NDANG")
								})
							],*/
			/*				layoutData: new sap.m.OverflowToolbarLayoutData({
								group: 2
							}),*/
			// 	change: function (oControlEvent) {
			// 		oExpandBtnClick = 0;
			// 		var oSection = oControlEvent.getSource().getParent().getParent().getParent().getParent();
			// 		//ITSDEDLC-812 aCaseToken has been commented as Contract ID search field is hidden
			// 		//var aCaseToken = oControlEvent.getSource().getParent().getContent()[7].getTokens();
			// 		//	oSection.setBusy(true);
			// 		var aFilters = [];
			// 		aFilters.push(new sap.ui.model.Filter("REVENUETYPE", "EQ", oControlEvent.getSource().getSelectedItem().getKey()));
			// 		oRevType = oControlEvent.getSource().getSelectedItem().getKey();
			// 		//ITSDEDLC-812 selected revenue type has been set to Appconfig model
			// 		oModelAppConfig.setProperty("/revenueType", oRevType);

			// 		aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", "EQ", oControlEvent.getSource().getParent().getContent()[1].getSelectedItem()
			// 			.getKey()));
			// 		//ITSDEDLC-812 aCaseToken has been commented as Contract ID search field is hidden
			// 		// for (i = 0; i < aCaseToken.length; i++) {
			// 		// 	aFilters.push(new sap.ui.model.Filter("CASE_ID", "EQ", aCaseToken[i].getText()));
			// 		// }

			// 		// if (aCaseToken.length > 0) {
			// 		// 	aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
			// 		// } else {

			// 		aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
			// 		//}
			// 		if (oExpandBtnClick === 1) {
			// 			//	oSection.setBusy(true);
			// 			aFilters.push(new sap.ui.model.Filter("CASE_ID", sap.ui.model.FilterOperator.EQ, oCaseID));
			// 			aFilters.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, this.sAccountId));
			// 			aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
			// 			aFilters.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));
			// 			aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "AL"));
			// 			this.getNetworkGraphData(aFilters, oSection);
			// 		} else {
			// 			var aSolutionTypeKeys = oControlEvent.getSource().getParent().getContent()[5].getSelectedItems();
			// 			if (aSolutionTypeKeys.length > 0) {
			// 				for (var j = 0; j < aSolutionTypeKeys.length; j++) {
			// 					aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", "EQ", aSolutionTypeKeys[j].getProperty("key")));
			// 				}
			// 			}
			// 			this.getNetworkGraphData(aFilters, oSection);
			// 		}
			// 	}.bind(this)
			// }), 3);
			// End Code  ITSDCDLEC - 957
			oToolbar.insertContent(new Label({
				text: oResourceModel.getText("solutionTypeNG"),
				layoutData: new sap.m.OverflowToolbarLayoutData({
					group: 2
				})
			}), 2);
			oToolbar.insertContent(new sap.m.MultiComboBox({
				width: "auto",
				selectedKeys: ["AL"],
				items: {
					path: "/DCDODSolTypeSet",
					template: new sap.ui.core.Item({
						key: "{ZZK_OD_SOL_TYPE}",
						text: "{DESCRIPTION}"
					})
				},
				layoutData: new sap.m.OverflowToolbarLayoutData({
					group: 2
				}),
				// 	selectionFinish: function (oControlEvent) {
				// 		oExpandBtnClick = 0;
				// 		var oSection = oControlEvent.getSource().getParent().getParent().getParent().getParent();
				// 		//ITSDEDLC-812 aCaseToken has been commented as Contract ID search field is hidden
				// 		//var aCaseToken = oControlEvent.getSource().getParent().getContent()[7].getTokens();
				// 		//	oSection.setBusy(true);
				// 		var aFilters = [];
				// 		var selectedItems = oControlEvent.getParameter("selectedItems");
				// 		//ITSDEDLC-812 selected Item has been set to Appconfig model
				// 		oModelAppConfig.setProperty("/solutionType", selectedItems);

				// 		if (selectedItems.length > 0) {
				// 			if (oExpandBtnClick === 1) {
				// 				//	oSection.setBusy(true);
				// 				aFilters.push(new sap.ui.model.Filter("CASE_ID", sap.ui.model.FilterOperator.EQ, oCaseID));
				// 				aFilters.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, this.sAccountId));
				// 				aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
				// 				aFilters.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));
				// 				aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "AL"));
				// 				//	this.getNetworkGraphData(aFilters, oSection);
				// 			} else {
				// 				for (var j = 0; j < selectedItems.length; j++) {
				// 					aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", "EQ", selectedItems[j].getProperty("key")));
				// 				}
				// 			}
				// 			//ITSDEDLC-812 aCaseToken has been commented as Contract ID search field is hidden
				// 			// for (i = 0; i < aCaseToken.length; i++) {
				// 			// 	aFilters.push(new sap.ui.model.Filter("CASE_ID", "EQ", aCaseToken[i].getText()));
				// 			// }

				// 			// if (aCaseToken.length > 0) {
				// 			// 	aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
				// 			// } else {

				// 			aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
				// 			//}
				// 			aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", "EQ", oControlEvent.getSource().getParent().getContent()[1].getSelectedItem()
				// 				.getKey()));
				// 			aFilters.push(new sap.ui.model.Filter("REVENUETYPE", "EQ", oControlEvent.getSource().getParent().getContent()[3].getSelectedItem()
				// 				.getKey()));
				// 			this.getNetworkGraphData(aFilters, oSection);
				// 		}
				// 	}.bind(this)
				// }), 3);

				selectionFinish: function (oControlEvent) {
					oExpandBtnClick = 0;
					var oSection = oControlEvent.getSource().getParent().getParent().getParent().getParent();
					var aFilters = [];
					var selectedItems = oControlEvent.getParameter("selectedItems");
					//ITSDEDLC-812 selected Item has been set to Appconfig model
					oModelAppConfig.setProperty("/solutionType", selectedItems);

					if (selectedItems.length > 0) {
						if (oExpandBtnClick === 1) {
							//	oSection.setBusy(true);
							aFilters.push(new sap.ui.model.Filter("CASE_ID", sap.ui.model.FilterOperator.EQ, oCaseID));
							aFilters.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, this.sAccountId));
							aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
							aFilters.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));
							aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "AL"));
							this.getNetworkGraphData(aFilters, oSection);
						} else {
							for (var j = 0; j < selectedItems.length; j++) {
								aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", "EQ", selectedItems[j].getProperty("key")));
							}
						}
						aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
						//}
						aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", "EQ", oControlEvent.getSource().getParent().getContent()[1].getSelectedItem()
							.getKey()));
						// aFilters.push(new sap.ui.model.Filter("REVENUETYPE", "EQ", oControlEvent.getSource().getParent().getContent()[3].getSelectedItem()
						// 	.getKey()));
						this.getNetworkGraphData(aFilters, oSection);

					}
				}.bind(this)
			}), 3);

			// 1151
			oToolbar.insertContent(new Label({
				text: oResourceModel.getText("Map"),
				layoutData: new sap.m.OverflowToolbarLayoutData({
					group: 4
				})
			}), 4);
			oToolbar.insertContent(new sap.m.Select({
				items: [
					new sap.ui.core.Item({
						key: "Y",
						text: oResourceModel.getText("contractMap")
					}),
					new sap.ui.core.Item({
						key: "X",
						text: oResourceModel.getText("xreferenceMap")
					}),
					new sap.ui.core.Item({
						key: "Y",
						text: oResourceModel.getText("Reset - Map View") 
					})
				],
				layoutData: new sap.m.OverflowToolbarLayoutData({
					group: 5
				}),
				// 	change: function (oControlEvent) {
				// 		oExpandBtnClick = 0;
				// 		var oSection = oControlEvent.getSource().getParent().getParent().getParent().getParent();
				// 		var aFilters = [];
				// 		aFilters.push(new sap.ui.model.Filter("XREF", "EQ", oControlEvent.getSource().getSelectedItem().getKey()));
				// 		var oMapType = oControlEvent.getSource().getSelectedItem().getKey();
				// 		oModelAppConfig.setProperty("/Map", oMapType);
				// 		aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
				// 		if (oExpandBtnClick === 1) {
				// 			aFilters.push(new sap.ui.model.Filter("CASE_ID", sap.ui.model.FilterOperator.EQ, oCaseID));
				// 			aFilters.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, this.sAccountId));
				// 			aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
				// 			aFilters.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));
				// 			// 		aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "AL"));
				// 			this.getNetworkGraphData(aFilters, oSection, oControlEvent);
				// 		} else {
				// 			var aSolutionTypeKeys = oControlEvent.getSource().getParent().getContent()[3].getSelectedItems();
				// 			if (aSolutionTypeKeys.length > 0) {
				// 				for (var j = 0; j < aSolutionTypeKeys.length; j++) {
				// 					aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", "EQ", aSolutionTypeKeys[j].getProperty("key")));
				// 				}
				// 			}
				// 			this.getNetworkGraphData(aFilters, oSection);
				// 		}
				// 	}.bind(this)
				// }), 5);
				change: function (oControlEvent) {
					oExpandBtnClick = 0;
					var oSection = oControlEvent.getSource().getParent().getParent().getParent().getParent();
					var aFilters = [];
					// aFilters.push(new sap.ui.model.Filter("XREF", "EQ", oControlEvent.getSource().getSelectedItem().getKey()));
					var oMapType = oControlEvent.getSource().getSelectedItem().getKey();
					oModelAppConfig.setProperty("/Map", oMapType);

					oMapType_val = oControlEvent.getSource().getSelectedItem().getKey();
					oModelAppConfig.setProperty("/Map", oMapType_val);

					// aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
					if (oExpandBtnClick === 1) {
						// aFilters.push(new sap.ui.model.Filter("CASE_ID", sap.ui.model.FilterOperator.EQ, oCaseID));
						// aFilters.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, this.sAccountId));
						// aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
						// aFilters.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));
						// 		aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "AL"));
						this.getNetworkGraphData(aFilters, oSection, oControlEvent);
					} else {
						var aSolutionTypeKeys = oControlEvent.getSource().getParent().getContent()[3].getSelectedItems();
						if (aSolutionTypeKeys.length > 0) {
							for (var j = 0; j < aSolutionTypeKeys.length; j++) {
								aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", "EQ", aSolutionTypeKeys[j].getProperty("key")));
							}
						}
						this.getNetworkGraphData(aFilters, oSection);

					}
				}.bind(this)
			}), 5);

			//ITSDEDLC-812 Contract Id Filter has been hidden
			// oToolbar.insertContent(new Label({
			// 	text: oResourceModel.getText("CaseIDNG"),
			// 	layoutData: new sap.m.OverflowToolbarLayoutData({
			// 		group: 4
			// 	})
			// }), 6);
			// oToolbar.insertContent(new sap.m.MultiInput({
			// 	id: "Multicase",
			// 	width: "20%",
			// 	showValueHelp: false,
			// 	layoutData: new sap.m.OverflowToolbarLayoutData({
			// 		group: 4
			// 	}),
			// 	tokenUpdate: function (oControlEvent) {
			// 		if (oControlEvent.getParameter("type") === "removed") {
			// 			var oSection = oControlEvent.getSource().getParent().getParent().getParent().getParent();
			// 			var aFilters = [];
			// 			var oMultiToken = sap.ui.getCore().byId("Multicase");
			// 			var oremcaseid = oControlEvent.getParameter("removedTokens");
			// 			var aCaseToken = oMultiToken.getTokens();
			// 			for (var i = 0; i < aCaseToken.length; i++) {
			// 				if (aCaseToken[i].getText() !== oremcaseid[0].getText()) {
			// 					aFilters.push(new sap.ui.model.Filter("CASE_ID", "EQ", aCaseToken[i].getText()));
			// 				}
			// 			}
			// 			this.getfilters(aFilters, oSection, oControlEvent)
			// 		}
			// 	}.bind(this),
			// 	liveChange: function (oControlEvent) {
			// 		var oSection = oControlEvent.getSource().getParent().getParent().getParent().getParent();
			// 		var aFilters = [];
			// 		var caseIdValue = oControlEvent.getParameters().value.trim().split(" ");
			// 		var caseIdArr = caseIdValue.filter(function (el) {
			// 			return el;
			// 		}).map(n => parseInt(n.toString(8)).toString());
			// 		if (oControlEvent.getParameters().value.length > 9) {
			// 			var oCaseToken = caseIdArr.filter(function (item, pos) {
			// 				return caseIdArr.indexOf(item) === pos;
			// 			});
			// 			var oMultiToken = sap.ui.getCore().byId("Multicase");
			// 			// add validator
			// 			var fnValidator = function (args) {
			// 				var text = args.text;
			// 				return new Token({
			// 					key: text,
			// 					text: text
			// 				});
			// 			};
			// 			oMultiToken.addValidator(fnValidator);
			// 			var defToken = new sap.m.Token({
			// 				text: oControlEvent.getParameters().value
			// 			});
			// 			oMultiToken.addToken(defToken);
			// 			oMultiToken.setValue("");
			// 			var aCaseToken = oMultiToken.getTokens();
			// 			for (i = 0; i < aCaseToken.length; i++) {
			// 				aFilters.push(new sap.ui.model.Filter("CASE_ID", "EQ", aCaseToken[i].getText()));
			// 			}
			// 			for (i = 0; i < oCaseToken.length; i++) {
			// 				var ocaseid = oCaseToken[i];
			// 				aFilters.push(new sap.ui.model.Filter("CASE_ID", "EQ", ocaseid));
			// 			}
			// 			this.getfilters(aFilters, oSection, oControlEvent);
			// 		}
			// 	}.bind(this)
			// }), 7);
		},
		getfilters: function (aFilters, oSection, oControlEvent) {
			if (aFilters.length > 0) {
				aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CASE"));
			} else {

				aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
			}
			for (var j = 0; j < oControlEvent.getSource().getParent().getContent()[5].getSelectedKeys().length; j++) {
				aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", "EQ", oControlEvent.getSource().getParent().getContent()[5].getSelectedKeys()[
					j]));
			}
			aFilters.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, null));
			aFilters.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));
			aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", "EQ", oControlEvent.getSource().getParent().getContent()[1].getSelectedItem()
				.getKey()));
			aFilters.push(new sap.ui.model.Filter("REVENUETYPE", "EQ", oControlEvent.getSource().getParent().getContent()[3].getSelectedItem()
				.getKey()));
			this.getNetworkGraphData(aFilters, oSection, oControlEvent);
		},
		//Section navigation
		onSelectionNavigate: function (oEvent) {
			var oSection = oEvent.getParameter("section");
			var sTitle = oSection.getTitle();
			var sCaseNetworkTitle = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("caseNetworkTitle");

			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			if (sTitle === sCaseNetworkTitle) {
				oModelAppConfig.setProperty("/showFilter", false);
				oModelAppConfig.setProperty("/showStandardFilter", true);
			} else {
				oModelAppConfig.setProperty("/showFilter", true);
				oModelAppConfig.setProperty("/showStandardFilter", false);
			}
		},

		//call for network garph 
		// getNetworkGraphData: function (aFilters, oSection, oControlEvent) {
		// 	oSection.setBusy(true);
		// 	//network graph data
		// 	var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
		// 	var oResourceModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
		// 	var aGroups = [];
		// 	var aLinks = [];
		// 	var aNodes = [];
		// 	oModelAppConfig.setProperty("/nodes", aNodes);
		// 	oModelAppConfig.setProperty("/lines", aLinks);
		// 	oModelAppConfig.setProperty("/groups", aGroups);

		// 	//add common filters 
		// 	//if (oExpandBtnClick !== 1) {
		// 	aFilters.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, this.sAccountId));
		// 	aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
		// 	aFilters.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));

		// 	//ITSDEDLC-870 - Revenue Type is set to ALL
		// 	if (oRevType === "") {
		// 		aFilters.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, "Al"));
		// 	} else {
		// 		aFilters.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, oRevType));
		// 	}

		// 	//if (oExpandBtnClick === 1) {
		// 	if (oGrpByType === "") {
		// 		aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, "PERIOD"));
		// 	} else {
		// 		aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, oGrpByType));
		// 	}
		// 	//	}
		// 	oModelAppConfig.setProperty("/filters", aFilters);
		// 	this.getOwnerComponent().getModel().read("/NGOverviewSet", {
		// 		filters: aFilters,
		// 		urlParameters: {
		// 			"$expand": "NGNodeSet/NGNodeAttrSet,NGLinksSet,NGGroupsSet"
		// 		},
		// 		success: function (oData, response) {
		// 			//this.getView().byId("graph").setNoData(false);
		// 			if (oData.results.length > 0) {

		// 				aGroups = oData.results[0].NGGroupsSet.results;
		// 				aLinks = oData.results[0].NGLinksSet.results;
		// 				aNodes = oData.results[0].NGNodeSet.results;
		// 				for (var i = 0; i < aNodes.length; i++) {
		// 					var formattedAttribute = aNodes[i].ATTRIBUTES.replace(/"/g, '');
		// 					var aATTRIBUTES = JSON.parse(formattedAttribute.replace(/'/g, '"'));
		// 					aNodes[i].ATTRIBUTES = aATTRIBUTES;
		// 				}

		// 				oModelAppConfig.setProperty("/nodes", aNodes);
		// 				oModelAppConfig.setProperty("/lines", aLinks);
		// 				oModelAppConfig.setProperty("/groups", aGroups);
		// 			} else {
		// 				//	this.getView().byId("graph").setNoData(true);
		// 				sap.m.MessageToast.show(oResourceModel.getText("noDataFound"), {
		// 					duration: 5000,
		// 					width: "40em"
		// 				});
		// 			}
		// 			oSection.setBusy(false);
		// 		}.bind(this),
		// 		error: function (error) {
		// 			oSection.setBusy(false);
		// 			sap.m.MessageToast.show(oResourceModel.getText("dataErrorNG"), {
		// 				duration: 5000,
		// 				width: "25em"
		// 			});
		// 		}
		// 	});
		// },

		getNetworkGraphData: function (aFilters, oSection, oControlEvent) {
			oSection.setBusy(true);
			//network graph data
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			var oResourceModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var aGroups = [];
			var aLinks = [];
			var aNodes = [];
			oModelAppConfig.setProperty("/nodes", aNodes);
			oModelAppConfig.setProperty("/lines", aLinks);
			oModelAppConfig.setProperty("/groups", aGroups);

			//add common filters 
			//if (oExpandBtnClick !== 1) {
			aFilters.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, this.sAccountId));
			aFilters.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
			aFilters.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));

			//ITSDEDLC-870 - Revenue Type is set to ALL
			oRevType = Revenue_Type_Val;
			if (oRevType === "") {
				aFilters.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, "Al"));
			} else {
				aFilters.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, oRevType));
			}

			//if (oExpandBtnClick === 1) {
			if (oGrpByType === "" || oGrpByType === undefined) {
				aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, "PERIOD"));
			} else {
				aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, oGrpByType));
			}

			if (oMapType_val === "" || oMapType_val === undefined || oMapType_val === "Y") {
				aFilters.push(new sap.ui.model.Filter("XREF", sap.ui.model.FilterOperator.EQ, "Y"));
			} else {
				aFilters.push(new sap.ui.model.Filter("XREF", sap.ui.model.FilterOperator.EQ, oMapType_val));
			}

			oModelAppConfig.setProperty("/filters", aFilters);
			this.getOwnerComponent().getModel().read("/NGOverviewSet", {
				filters: aFilters,
				urlParameters: {
					"$expand": "NGNodeSet/NGNodeAttrSet,NGLinksSet,NGGroupsSet"
				},
				success: function (oData, response) {
					if (oData.results.length > 0) {

						aGroups = oData.results[0].NGGroupsSet.results;
						aLinks = oData.results[0].NGLinksSet.results;
						aNodes = oData.results[0].NGNodeSet.results;
						for (var i = 0; i < aNodes.length; i++) {
							var formattedAttribute = aNodes[i].ATTRIBUTES.replace(/"/g, '');
							var aATTRIBUTES = JSON.parse(formattedAttribute.replace(/'/g, '"'));
							aNodes[i].ATTRIBUTES = aATTRIBUTES;
						}

						oModelAppConfig.setProperty("/nodes", aNodes);
						oModelAppConfig.setProperty("/lines", aLinks);
						oModelAppConfig.setProperty("/groups", aGroups);
					} else {
						//	this.getView().byId("graph").setNoData(true);
						sap.m.MessageToast.show(oResourceModel.getText("noDataFound"), {
							duration: 5000,
							width: "40em"
						});
					}
					oSection.setBusy(false);
				}.bind(this),
				error: function (error) {
					oSection.setBusy(false);
					sap.m.MessageToast.show(oResourceModel.getText("dataErrorNG"), {
						duration: 5000,
						width: "25em"
					});
				}
			});
		},

		/**
		 * Check for disclaimer in AppConfig if null, check for NOTIFCTN_RQSTD
		 * if NOTIFCTN_RQSTD = X, user has opted to do not show 
		 * else open the disclaimer
		 * set DISCLAIMER_KEY as datetime, to be used for updating NOTIFCTN_RQSTD
		 */
		onPress: function (oEvent) {
			var a = 0;
		},

		// ***********Start of Changes By C5341161 for ITLT-1075***************
		onBeforeRendering: function () {
			var oSmartFilter = this.getView().byId("smartFilterBar");
			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var eSystemID = appConfigModel.getProperty("/SystemsInfo").SYSID;
			// var sSystemID = sMetadata.id.substring(11, 8);
			//Ensure that there is no default Variant set by the user. 
			//In such a case, do not set default Variant.
			var sDefaultVariantKey = oSmartFilter.getVariantManagement().getDefaultVariantKey();
			//If No variant is set, default variant is "standard"
			if (sDefaultVariantKey !== "*standard*") {
				return;
			}
			switch (eSystemID) {
			case "ISD":

				//Set the Global Variant as the current Variant
				oSmartFilter.getVariantManagement().setCurrentVariantId("id_1699812590076_319_table");
				// setCurrentVariantName*("Non Standard") ;
				// setCurrentVariantId("id_1535046664297_171_page");
			case "IST":
				//Set the Global Variant as the current Variant
				oSmartFilter.getVariantManagement().setCurrentVariantId("id_1689240803579_381_table");
			case "ISP":
				//Set the Global Variant as the current Variant
				oSmartFilter.getVariantManagement().setCurrentVariantId("id_1691663395434_302_table");
			}
		},
		// ***********End of Changes by C5341161 for ITLT-1075*****************

		onAfterRendering: function () {
			var that = this;
			var oModelAppConfig = that.getOwnerComponent().getModel("AppConfig");
			var oModel = that.getOwnerComponent().getModel();
			if (oModelAppConfig.getProperty("/disclaimer") === null) {
				oModel.read("/DCDDisclaimerSet", {
					success: function (oData, response) {
						if (oData.results.length > 0) {
							oModelAppConfig.setProperty("/disclaimer", oData.results[0]);
							var sDiscalimerKey = oData.results[0].DISCLAIMER_KEY.toISOString();
							var sKey = "datetimeoffset'" + sDiscalimerKey.substring(0, sDiscalimerKey.indexOf(".")) + "'";
							// var sKey = "datetime" + sDiscalimerKey.substring(0, sDiscalimerKey.indexOf("."));
							oModelAppConfig.setProperty("/disclaimer/sKey", sKey);
							if (oModelAppConfig.getProperty("/disclaimer/NOTIFCTN_RQSTD") !== "X") {
								that.openDisclaimer();
							}
						}
					},
					error: function (error) {}
				});
			}
			this._getSystemInfo();
			// Changes by C5341161 for ITLT-1075
			var oSmartFilter = this.getView().byId("smartFilterBar");
			//Ensure that there is no default Variant set by the user. 
			//In such a case, do not set default Variant.
			var sDefaultVariantKey = oSmartFilter.getVariantManagement().getDefaultVariantKey();
			//If No variant is set, default variant is "standard"
			if (sDefaultVariantKey !== "*Standard*") {
				return;
			}

			//Set the Global Variant as the current Variant
			oSmartFilter.getVariantManagement().setCurrentVariantKey("Security Non-Standard");
			// End of Changes by C5341161 for ITLT-1075
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function () {
			var oViewModel = this.getModel("objectView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		//How to Report data issue help handler
		onHelpPress: function () {
			var that = this;
			that.oDialog = that.getView().byId("requestguide");
			if (!that.oDialog) {
				that.oDialog = sap.ui.xmlfragment(that.getView().getId(), "c2r.c2rdcd.fragments.requestguide", this);
				that.getView().addDependent(that.oDialog);
			}
			var root = jQuery.sap.getModulePath("c2r.c2rdcd");
			that.getView().byId("idImage").setSrc(root + "/images/ProcessFlow.jpg");
			that.oDialog.open();
		},

		//Close help popup
		onCancel: function () {
			this.oDialog.close();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function (oEvent) {
			var ograph = this.getView().byId("graph");
			ograph.setBusy(true);
			//this.getOwnerComponent().getModel().setUseBatch(false);
			var sObjectId = oEvent.getParameter("arguments").objectId;
			var sErpNumber = oEvent.getParameter("arguments").erpNumber;
			this.sAccountId = sObjectId;
			this.bpnumber = sObjectId;
			this.sErpNumber = sErpNumber;
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			// Auto clear of filter bar values before navugation to worklist view
			var oFilterBar = this.getView().byId("filterBar");
			this.getView().byId("dcdBookingDate").setValue("");
			oFilterBar.clear();
			//ITSDEDLC-745 Auto Clear of SmartFilter values before navigating to Worklist View
			var oSmartFilter = this.getView().byId("smartFilterBar");
			oSmartFilter.clear();
			if (oModelAppConfig.getProperty("/erpNumber") !== this.sErpNumber) {
				// if (oModelAppConfig.getProperty("/accountId") !== this.sAccountId && oModelAppConfig.getProperty("/erpNumber") !== this.sErpNumber) {
				//fix network graph selection
				var overviewSection = this.getView().byId("overviewSection");
				this.getView().byId("objectPageLayout").setSelectedSection(overviewSection);
				//ITSDEDLC-812 Default display of Network Graph is adjusted.
				//var oToolbar = this.getView().byId("graph").getToolbar();
				//oToolbar.getContent()[1].setSelectedKey("0");
				//oToolbar.getContent()[3].setSelectedKey("2");
				oModelAppConfig.setProperty("/accountId", this.sAccountId);
				oModelAppConfig.setProperty("/erpNumber", this.sErpNumber);
				oModelAppConfig.setProperty("/showFilter", true);
				oModelAppConfig.setProperty("/showStandardFilter", false);
				this.getModel().metadataLoaded().then(function () {
					var sObjectPath = this.getModel().createKey("CustomerDataEntitySet", {
						BUSINESSPARTNER: sObjectId,
						ERPNUMBER: sErpNumber
					});
					objectPath = ("/" + sObjectPath);
					this._bindView("/" + sObjectPath);
				}.bind(this));
			}
			this.getView().byId("dcdoverviewtabid").rebindTable();
			this.getView().byId("dcdproductstabid").rebindTable();
			this.getView().byId("dcdsecuritytabid").rebindTable();
			this.getView().byId("dcdcontclaustabid").rebindTable();
			this.getView().byId("dcdcustconttabid").rebindTable();
			this.getView().byId("dcddatestabid").rebindTable();
			this.getView().byId("dcddealstructabid").rebindTable();
			this.getView().byId("dcdpayinvoicetabid").rebindTable();
			this.getView().byId("xreferencetabid").rebindTable();
			this.getView().byId("dcdcustomtabid").rebindTable();
			var aFilter = [];
			var aGroups = [];
			var aLinks = [];
			var aNodes = [];
			var oResourceModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oFilters = oModelAppConfig.getProperty("/filters");
			var ogroup_By = oModelAppConfig.getProperty("/groupBy");
			var orevenue_Type = oModelAppConfig.getProperty("/revenueType");
			var osolution_Type = oModelAppConfig.getProperty("/solutionType");
			var oFilterBar = this.oFilterBar = this.getView().byId("filterBar")

			aFilter.push(new sap.ui.model
				.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
			aFilter.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model
				.FilterOperator.EQ, this.sAccountId));
			aFilter.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ,
				erpNumber));

			aFilter.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, "PERIOD"));

			aFilter.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, "Al"));

			aFilter.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "Al"));

			this.getOwnerComponent().getModel().read("/NGOverviewSet", {
				filters: aFilter,
				urlParameters: {
					"$expand": "NGNodeSet/NGNodeAttrSet,NGLinksSet,NGGroupsSet"
				},
				success: function (oData, response) {
					if (oData.results.length > 0) {
						aGroups = oData.results[0].NGGroupsSet.results;
						aLinks = oData.results[0].NGLinksSet.results;
						aNodes = oData.results[0].NGNodeSet.results;
						for (var i = 0; i < aNodes.length; i++) {
							var formattedAttribute = aNodes[i].ATTRIBUTES.replace(/"/g, '');
							var aATTRIBUTES = JSON.parse(formattedAttribute.replace(/'/g, '"'));
							aNodes[i].ATTRIBUTES = aATTRIBUTES;
						}
						oModelAppConfig.setProperty("/nodes", aNodes);
						oModelAppConfig.setProperty("/lines", aLinks);
						oModelAppConfig.setProperty("/groups", aGroups);
					} else {
						sap.m.MessageToast.show(oResourceModel.getText("noDataFound"), {
							duration: 5000,
							width: "40em"
						});
					}
					ograph.setBusy(false);
				}.bind(this),
				error: function (error) {
					ograph.setBusy(false);
					sap.m.MessageToast.show(oResourceModel.getText("dataErrorNG"), {
						duration: 5000,
						width: "25em"
					});
				}

			});
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView: function (sObjectPath) {
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();
			var that = this;

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						oDataModel.metadataLoaded().then(function () {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
							// while metadata is loaded.
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function () {
						oViewModel.setProperty("/busy", false);
					}
				}
			});

			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDCD_SRV;v=0002/", true);
			oModel.read(sObjectPath, null, null, false,
				function (oData, oResponse) {
					obp = oData.BUSINESSPARTNER;
					erpNumber = oData.ERPNUMBER;
					that.getView().byId("ObjectHeaderTitle").setText(
						oData.ERPNUMBERDESCRIPTION + " (" + oData.BUSINESSPARTNER + ")"
					);
					that.getView().byId("ObjectHeaderTitleSnapped").setText(
						oData.ERPNUMBERDESCRIPTION + " (" + oData.BUSINESSPARTNER + ")"
					);
					that.getView().byId("bp").setText(
						oData.BUSINESSPARTNER
					);
					that.getView().byId("erpnumber").setText(
						oData.ERPNUMBER
					);
					that.getView().byId("accountOwner").setText(
						oData.ACCOWNER_NAME
					);
					that.getView().byId("ims").setText(oData.INTERNALMARKETSEGMENT);

					that.getView().byId("iac").setText(
						oData.INTERNALACCOUNTCLASSIFICATION
					);
					that.getView().byId("iss").setText(
						oData.INTERNALSALESSEGMENT
					);
					that.getView().byId("country").setText(
						oData.COUNTRYNAME
					);
					that.getView().byId("region").setText(
						oData.REGION
					);
					that.getView().byId("city").setText(
						oData.CITY
					);
					that.getView().byId("sapmasterCode").setText(
						oData.SAP_MASTERCODE_DESC
					);
					var msg;
					msg = "You are seeing the contracts for which you are authorized!!";
					sap.m.MessageToast.show(msg, {
						duration: 440,
						width: "25em"
					});
					var oModelAppConfig = that.getOwnerComponent().getModel("AppConfig");
					var oDataModelFI = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDCD_SRV;v=0002/", true);
					if (obp) {
						oDataModelFI.callFunction("/GetDCDCount", {
							method: "GET",
							urlParameters: {
								"BUSINESSPARTNER": obp,
								"ERPNUMBER": erpNumber
							},
							success: jQuery.proxy(function (oDataFI, response) {
								if (!oDataFI.GetDCDCount) {
									oModelAppConfig.setProperty("/noData", "You are not authorized!!");
								}
							}, this),
							error: function (oError) {}
						});
					}

				});

			var prdPath = sObjectPath + "/toProductTabEntities";
			var oProdTable = this.getView().byId("dcdproductstabid");

			oProdTable.applyVariant({
				group: {
					groupItems: [{
						columnKey: "CASE_ID",
						operation: "GroupDescending",
						showIfGrouped: true
					}, {
						columnKey: "QUOTE_ID",
						operation: "GroupDescending",
						showIfGrouped: true
					}]
				}
			});

			oProdTable._oCurrentVariant.group.groupItems.push();
			oProdTable.setTableBindingPath(prdPath);

			var ObjectPageFlag = this.getOwnerComponent().getModel("AppConfig").getProperty("/ObjectPageFlag");
			if (ObjectPageFlag) {
				oProdTable.rebindTable();

				this.getView().byId("dcdoverviewtabid").rebindTable();
				this.getView().byId("dcdsecuritytabid").rebindTable();
				this.getView().byId("dcdcontclaustabid").rebindTable();
				this.getView().byId("dcdcustconttabid").rebindTable();
				this.getView().byId("dcddatestabid").rebindTable();
				this.getView().byId("dcddealstructabid").rebindTable();
				this.getView().byId("dcdpayinvoicetabid").rebindTable();
				this.getView().byId("dcdcustomtabid").rebindTable();
			}

			this.getOwnerComponent().getModel("AppConfig").setProperty("/ObjectPageFlag", true);

			//call NG data once overview table is loaded 
			this.getView().byId("objectPageLayout").getSections()[0].setBusy(true);
			this.getView().byId("dcdoverviewtabid").attachEventOnce("dataReceived", function (oData) {
				var aFilters = [];
				aFilters.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, "PERIOD"));
				aFilters.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, "Al")); //ITSDEDLC-918 - Revenue Type is adjusted 'Al' instead of 'Cl'
				aFilters.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, "AL"));
				this.getNetworkGraphData(aFilters, this.getView().byId("objectPageLayout").getSections()[0]);
			}, this);
		},

		//binding of table
		onBeforeRebindTableDetails: function (oEvt) {
			var prefixSubstitue = "0000000000";
			if (obp) {
				obp = prefixSubstitue.substr(obp.length) + obp;
				erpNumber = prefixSubstitue.substr(erpNumber.length) + erpNumber;

				var oBindingParams = oEvt.getParameter("bindingParams");
				oBindingParams.filters.push(new sap.ui.model.Filter({
					path: "BUSINESSPARTNER",
					operator: FilterOperator.EQ,
					value1: obp,
				}));
				oBindingParams.filters.push(new sap.ui.model.Filter({
					path: "ERPNUMBER",
					operator: FilterOperator.EQ,
					value1: erpNumber,
				}));
				//Booking Year filter start 
				var oSmartFilter = this.getView().byId("smartFilterBar");
				var oFilterValue = oSmartFilter.getFilterData();
				var oBookingDate = oSmartFilter.getControlByKey("BOOKING_YEAR");
				if (oBookingDate !== null) {
					var fltMinBillingDate = oBookingDate.getDateValue();
					var fltMaxBillingDate = oBookingDate.getSecondDateValue();
					var array1 = [fltMinBillingDate, fltMaxBillingDate];
					var array2 = [];
					var val;
					if ((fltMinBillingDate !== null) && (fltMaxBillingDate !== null)) {
						array1.forEach(function (now) {
							val = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toGMTString();
							array2.push(val);
						});
						var filter = new sap.ui.model.Filter("BOOKING_YEAR", sap.ui.model.FilterOperator.BT, array2[0], array2[1]); //sfltMinBillingDate //sfltMaxBillingDate
						oBindingParams.filters.push(filter);
					}
				}
				//Booking Year filter end 
				oBindingParams.parameters = oBindingParams.parameters || {};
				oBindingParams.parameters.select = "*";
			}
		},
		//Navigateion from object page to overview page
		onLineitemClicked: function (oEvent) {
			var businessPartner = oEvent.getSource().getBindingContext().getObject().BUSINESSPARTNER;
			var erpNumber = oEvent.getSource().getBindingContext().getObject().ERPNUMBER;
			var caseId = oEvent.getSource().getBindingContext().getObject().CASE_ID;
			var caseGuid = oEvent.getSource().getBindingContext().getObject().CASEGUID;
			var quoteId = oEvent.getSource().getBindingContext().getObject().QUOTE_ID;
			var revenuetype = oEvent.getSource().getBindingContext().getObject().REVENUETYPE;
			//ITSDEDLC-952 Revenue Type's has been made first letter with Capital - Begin
			if (revenuetype === "CL") {
				revenuetype = "Cl";
			} else if (revenuetype === "SR") {
				revenuetype = "Se";
			} else if (revenuetype === "OP") {
				revenuetype = "On";
			} else {
				revenuetype;
			}
			//ITSDEDLC-952 - End
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			oModelAppConfig.setProperty("/revenue", revenuetype);
			this.getOwnerComponent().getRouter().navTo("overView", {
				// bpNumber: businessPartner,
				// erpNumber: erpNumber,
				caseId: caseId
					// caseGuid: caseGuid,
					// quoteId: quoteId,
					// revenuetype: revenuetype //ITSDEDLC-924
			});
		},

		//get casegui Id
		_getCaseGuid: function (caseid) {
			var oDataModel = this.getView().getModel();
			var that = this;
			oDataModel.callFunction("/GetCaseGUID", {
				method: "GET",
				urlParameters: {
					"CaseID": caseid
				},
				success: jQuery.proxy(function (oData, response) {
					if (oData.GetCaseGUID) {
						var oCaseGuid = new sap.ui.model.json.JSONModel(oData.GetCaseGUID);
						that.getView().setModel(oCaseGuid, "CaseGuid");
					}
				}, this),
				error: function (oError) {
					//Suitable Error Handling
				}
			});
		},

		//Product Description popover
		swapExchangeMsg: function (oEvent) {
			var that = this;
			// var caseID = oEvent.getSource().getParent().getBindingContext().getObject().CASE_ID;
			// var bpNumber = oEvent.getSource().getParent().getBindingContext().getObject().BUSINESSPARTNER;
			// var erpNumber = oEvent.getSource().getParent().getBindingContext().getObject().ERPNUMBER;
			//	var sPath="/DCDCustomEntitySet(BUSINESSPARTNER='"+bpNumber+"',"+"CASE_ID='"+caseID+"',"+"ERPNUMBER='"+erpNumber+"')";
			var rowData = oEvent.getSource().getParent().getBindingContext().getObject();
			var messageDate = "";

			messageDate = rowData.EXCHG_SWAP_RIGHTS_ENDDATE;

			var swapMessageDate = {};
			swapMessageDate["Date"] = messageDate.getDate() + "." + (messageDate.getMonth() + 1) + "." + messageDate.getFullYear();
			if (!this._swapPopover) {
				this._swapPopover = sap.ui.xmlfragment("c2r.c2rdcd.fragments.swapExchange", this);
				this.getView().addDependent(this._swapPopover);
			}
			var jModel = new sap.ui.model.json.JSONModel(swapMessageDate);
			that.setModel(jModel, "exchangeDateValue");
			this._swapPopover.openBy(oEvent.getSource());
		},

		//Future Discount or price protection Message Popover
		futureDisPrPtMsg: function (oEvent) {
			var that = this;
			// var caseID = oEvent.getSource().getParent().getBindingContext().getObject().CASE_ID;
			// var bpNumber = oEvent.getSource().getParent().getBindingContext().getObject().BUSINESSPARTNER;
			// var erpNumber = oEvent.getSource().getParent().getBindingContext().getObject().ERPNUMBER;
			//	var sPath="/DCDCustomEntitySet(BUSINESSPARTNER='"+bpNumber+"',"+"CASE_ID='"+caseID+"',"+"ERPNUMBER='"+erpNumber+"')";
			var rowData = oEvent.getSource().getParent().getBindingContext().getObject();
			var messageDate = "";
			var productMessageDate = {};

			if (rowData.REVENUETYPE === "On") {
				messageDate = rowData.FUTURE_DISC_END_DATE;
				productMessageDate["Date"] = messageDate.getDate() + "." + (messageDate.getMonth() + 1) + "." + messageDate.getFullYear();
			} else {
				messageDate = rowData.PRC_PROTECTION_END_DATE;
				productMessageDate["Date"] = messageDate;
			}
			productMessageDate["RevenueType"] = rowData.REVENUETYPE;
			if (!this._productPopover) {
				this._productPopover = sap.ui.xmlfragment("c2r.c2rdcd.fragments.productDescription", this);
				this.getView().addDependent(this._productPopover);
			}
			var jModel = new sap.ui.model.json.JSONModel(productMessageDate);
			that.setModel(jModel, "productDateValue");
			this._productPopover.openBy(oEvent.getSource());
		},

		//Swap message popover close
		swapExchangeMsgClose: function () {
			if (this._swapPopover) {
				this._swapPopover.close();
			}
		},

		//Product Description popover close
		productMsgClose: function () {
			if (this._productPopover) {
				this._productPopover.close();
			}
		},

		//date formatter in dd.mm.yyyy format
		dateFormatter: function (dateValue, oFieldValue) {
			var formattedDate = "";
			if (oFieldValue === 'PRC_PROTECTION_END_DATE') {
				var pricePtDate = dateValue.split(".");
				formattedDate = pricePtDate[1] + '.' + pricePtDate[0] + '.' + pricePtDate[2];
			} else {
				formattedDate = ((dateValue.getMonth() > 8) ? (dateValue.getMonth() + 1) : ('0' + (dateValue.getMonth() + 1))) + '.' +
					((dateValue.getDate() > 9) ? dateValue.getDate() : ('0' + dateValue.getDate())) + '.' +
					dateValue.getFullYear();
			}

			return new Date(formattedDate);
		},
		//open Invoice popup
		handleInvoicePress: function (oEvent) {
			if (!this._oPopoverInvoice) {
				this._oPopoverInvoice = sap.ui.xmlfragment("c2r.c2rdcd.fragments.invoices", this);
				this.getView().addDependent(this._oPopoverInvoice);
			}
			this._oPopoverInvoice.openBy(oEvent.getSource());
			var ocaseguid = oEvent.getSource().getParent().getBindingContext().getObject().CASEGUID;
			if (ocaseguid) {
				ocaseguid = ocaseguid.toUpperCase();
				var aFilters = [];
				aFilters.push(new Filter("CASE_GUID", sap.ui.model.FilterOperator.EQ, ocaseguid));
				sap.ui.getCore().byId("CMS_InvoicesTable").getBinding("items").filter(aFilters);
			}
		},

		//open BillingPlan Popup
		handleQuoteBPPress: function (oEvent) {
			var oRevenueType = oEvent.getSource().getBindingContext().getObject().REVENUETYPE;
			if (oRevenueType === 'Se') {
				if (!this._oPopoverBP) {
					this._oPopoverBP = sap.ui.xmlfragment("c2r.c2rdcd.fragments.QuoteBillingPlan", this);
					this.getView().addDependent(this._oPopoverBP);
				}
				this._oPopoverBP.openBy(oEvent.getSource());
				var oquoteid = oEvent.getSource().getParent().getBindingContext().getObject().QUOTE_ID;
				if (oquoteid) {
					oquoteid = oquoteid.toUpperCase();
					var aFilters = [];
					aFilters.push(new Filter("QuoteId", sap.ui.model.FilterOperator.EQ, oquoteid));
					sap.ui.getCore().byId("Quote_BP_Table").getBinding("items").filter(aFilters);
				}
			} else {
				sap.m.MessageToast.show("Quote billing plan details is only enabled for services revenue type");
			}
		},

		//binding of data
		_onBindingChange: function () {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

			var oResourceBundle = this.getResourceBundle(),
				oObject = oView.getBindingContext().getObject(),
				sObjectId = oObject.BUSINESSPARTNER,
				sObjectName = oObject.BUSINESSPARTNER;

			oViewModel.setProperty("/busy", false);
			// Add the object page to the flp routing history
			this.addHistoryEntry({
				title: this.getResourceBundle().getText("objectTitle") + " - " + sObjectName,
				icon: "sap-icon://enter-more",
				intent: "#DCDCockpit-display&/CustomerDataEntitySet/" + sObjectId
			});

			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("saveAsTileTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},

		//Navigate to Quote Id details
		onQuoteIDPress: function (oEvt) {
			var object;
			if (oEvt.getSource().getParent().getMetadata().getName() === "sap.m.Popover") {
				object = oEvt.getSource().getModel().getData();
			} else {
				object = oEvt.getSource().getParent()._getBindingContext().getObject();
			}
			this.openQuoteID(object);
		},

		//Quote id navigation 
		openQuoteID: function (object) {
			var oRevenueType = object.REVENUETYPE;
			var oProcessType = object.PROCESS_TYPE;

			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var sHTTPS = appConfigModel.getProperty("/protocol");

			var sSystemID = appConfigModel.getProperty("/SystemsInfo").CRMSYS;
			var eSystemID = appConfigModel.getProperty("/SystemsInfo").SYSID;
			var url = appConfigModel.getProperty("/url");
			var crmUrl = appConfigModel.getProperty("/crmUrl");
			var crmUrlAction = appConfigModel.getProperty("/crmUrlAction");
			var crmUrlValue = appConfigModel.getProperty("/crmUrlValue");
			var crmUrlKeyName = appConfigModel.getProperty("/crmUrlKeyName");
			var sapRole = appConfigModel.getProperty("/sapRole");
			var flpUrl;
			if (sSystemID === "ICD" || eSystemID === "ISD") {
				flpUrl = appConfigModel.getProperty("/flpUrlDev");
			} else if (sSystemID === "ICT" || eSystemID === "IST") {
				flpUrl = appConfigModel.getProperty("/flpUrlTest");
			} else if (sSystemID === "ICP" || eSystemID === "ISP") {
				flpUrl = appConfigModel.getProperty("/flpUrlProd");
			}
			var flpHarmony = appConfigModel.getProperty("/flpHarmony");
			var flpOpp = appConfigModel.getProperty("/flpOpp");
			var flpQuote = appConfigModel.getProperty("/flpQuote");
			var sUrl;

			if (oProcessType === "" || oProcessType === null) {
				var oMissingSourceMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("errorTextMissingSource");
				MessageBox.error(oMissingSourceMsg);
				return;
			}

			var oMissingLinkMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("errorTextMissingLink");
			var prefixSubstitute = "000000000000";
			var oQuoteId = object.QUOTE_ID;

			if (oRevenueType === "CL") {
				if (oProcessType === "Historic") {
					sUrl = sHTTPS + sSystemID + url + crmUrl + "BT116_SRVQ" + crmUrlAction + "B" + crmUrlValue +
						object.QUOTE_ID + crmUrlKeyName + "OBJECT_ID" + sapRole;
				} else if (oProcessType === "Callidus/CPQ") {
					oQuoteId = prefixSubstitute.substr(oQuoteId.length) + oQuoteId;
					sUrl = sHTTPS + flpUrl + flpHarmony + flpOpp + object.OPPORTUNITY_ID + flpQuote + oQuoteId;
				}
				sap.m.URLHelper.redirect(sUrl, true);
			} else if (oRevenueType === "OP" || oRevenueType === "SR") {
				if (oProcessType === "Historic") {
					sUrl = sHTTPS + sSystemID + url + crmUrl + "ERPQUOTATION" + crmUrlAction + "B" + crmUrlValue +
						object.QUOTE_ID + crmUrlKeyName + "VBELN" + sapRole;
				} else if (oProcessType === "Callidus/CPQ") {
					oQuoteId = prefixSubstitute.substr(oQuoteId.length) + oQuoteId;
					sUrl = sHTTPS + flpUrl + flpHarmony + flpOpp + object.OPPORTUNITY_ID + flpQuote + oQuoteId;
				}
				sap.m.URLHelper.redirect(sUrl, true);
			} else {
				MessageBox.error(oMissingLinkMsg);
				return;
			}
		},

		//Navigate to Sales Document Id details
		onSalesDocIDPress: function (oEvt) {
			var object;
			if (oEvt.getSource().getParent().getMetadata().getName() === "sap.m.Popover") {
				object = oEvt.getSource().getModel().getData();
			} else {
				object = oEvt.getSource().getParent()._getBindingContext().getObject();
			}
			this.openSalesDocID(object);
		},

		//Sales Document Id navigation 
		openSalesDocID: function (object) {
			var oRevenueType = object.REVENUETYPE;
			var oProcessType = object.PROCESS_TYPE;

			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var sHTTPS = appConfigModel.getProperty("/protocol");

			var sSystemID = appConfigModel.getProperty("/SystemsInfo").CRMSYS;
			var eSystemID = appConfigModel.getProperty("/SystemsInfo").SYSID;
			var url = appConfigModel.getProperty("/url");
			var crmUrl = appConfigModel.getProperty("/crmUrl");
			var crmUrlAction = appConfigModel.getProperty("/crmUrlAction");
			var crmUrlValue = appConfigModel.getProperty("/crmUrlValue");
			var crmUrlKeyName = appConfigModel.getProperty("/crmUrlKeyName");
			var crmUrlAccount = appConfigModel.getProperty("/crmUrlAccount");
			var crmSalesUrlAccount = appConfigModel.getProperty("/crmSalesUrlAccount");
			var sapRole = appConfigModel.getProperty("/sapRole");
			var sapRolep = appConfigModel.getProperty("/sapRolep");
			var onPremSalesDoc = appConfigModel.getProperty("/onPremSalesDoc");
			var flpUrl;
			if (sSystemID === "ICD" || eSystemID === "ISD") {
				flpUrl = appConfigModel.getProperty("/flpUrlDev");
			} else if (sSystemID === "ICT" || eSystemID === "IST") {
				flpUrl = appConfigModel.getProperty("/flpUrlTest");
			} else if (sSystemID === "ICP" || eSystemID === "ISP") {
				flpUrl = appConfigModel.getProperty("/flpUrlProd");
			}
			var flpHarmony = appConfigModel.getProperty("/flpHarmony");
			var flpOpp = appConfigModel.getProperty("/flpOpp");
			var flpQuote = appConfigModel.getProperty("/flpQuote");
			var sUrl;

			if (oProcessType === "" || oProcessType === null) {
				var oMissingSourceMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("errorTextMissingSource");
				MessageBox.error(oMissingSourceMsg);
				return;
			}

			var oMissingLinkMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("errorTextMissingLink");
			var prefixSubstitute = "000000000000";
			var oSalesDocId = object.SALES_DOC_ID;
			var oSalesDocGuid;

			if (oProcessType === "Callidus/CPQ") {
				if (oRevenueType === "CL" || oRevenueType === "OP") {
					var oSalesDocLink; // = object.SALES_DOC_LINK;
					// sUrl = oSalesDocLink;
					// sap.m.URLHelper.redirect(sUrl, true);
					var oDataModel = this.getView().getModel();
					var that = this;

					oDataModel.callFunction("/GetSalesDocLink", {
						method: "GET",
						urlParameters: {
							"SalesDocId": oSalesDocId
						},
						success: jQuery.proxy(function (oData, response) {
							if (oData.GetSalesDocLink) {
								oSalesDocLink = new sap.ui.model.json.JSONModel(oData.GetSalesDocLink);
								var salesDocLink = oSalesDocLink.oData.SalesDocumentLink;
								if (salesDocLink === "No link found" || salesDocLink === "") {
									MessageBox.error(oMissingLinkMsg);
									return;
								} else if (salesDocLink === "CRM link") {
									if (oRevenueType === "CL") {
										sUrl = sHTTPS + sSystemID + url + crmSalesUrlAccount + "BT116_SRVO" + crmUrlAction + "B" + crmUrlValue +
											object.SALES_DOC_ID + crmUrlKeyName + "OBJECT_ID" + sapRole;
										sap.m.URLHelper.redirect(sUrl, true);

									} else if (oRevenueType === "OP") {
										sUrl = sHTTPS + eSystemID + url + onPremSalesDoc + object.SALES_DOC_ID;
										sap.m.URLHelper.redirect(sUrl, true);
										//	crmUrl + "ERPQUOTATION" + crmUrlAction + "B" + crmUrlValue +object.QUOTE_ID + crmUrlKeyName + "VBELN" + sapRole;
									}
								} else {
									sUrl = sHTTPS + salesDocLink + sapRolep;
									sap.m.URLHelper.redirect(sUrl, true);
									//that.getView().setModel(oSalesDocGuid, "SalesDocGuid");
								}
							} else {
								if (oRevenueType === "CL") {
									sUrl = sHTTPS + sSystemID + url + crmSalesUrlAccount + "BT116_SRVO" + crmUrlAction + "B" + crmUrlValue +
										object.SALES_DOC_ID + crmUrlKeyName + "OBJECT_ID" + sapRole;
									sap.m.URLHelper.redirect(sUrl, true);

								} else if (oRevenueType === "OP") {
									sUrl = sHTTPS + eSystemID + url + onPremSalesDoc + object.SALES_DOC_ID;
									sap.m.URLHelper.redirect(sUrl, true);
									//	crmUrl + "ERPQUOTATION" + crmUrlAction + "B" + crmUrlValue +object.QUOTE_ID + crmUrlKeyName + "VBELN" + sapRole;
								} else if (oRevenueType === "SR") {
									sUrl = sHTTPS + eSystemID + url + onPremSalesDoc + object.SALES_DOC_ID;
									sap.m.URLHelper.redirect(sUrl, true);
								} else {
									MessageBox.error(oMissingLinkMsg);
									return;
								}
							}

						}, this),
						error: function (oError) {
							//Suitable Error Handling
						}
					});
				} else if (oRevenueType === "SR") {
					sUrl = sHTTPS + eSystemID + url + onPremSalesDoc + object.SALES_DOC_ID;
					sap.m.URLHelper.redirect(sUrl, true);
				}
			} else if (oProcessType === "Historic") {
				if (oRevenueType === "CL") {
					sUrl = sHTTPS + sSystemID + url + crmSalesUrlAccount + "BT116_SRVO" + crmUrlAction + "B" + crmUrlValue +
						object.SALES_DOC_ID + crmUrlKeyName + "OBJECT_ID" + sapRole;
					sap.m.URLHelper.redirect(sUrl, true);
				} else if (oRevenueType === "OP") {
					sUrl = sHTTPS + eSystemID + url + onPremSalesDoc + object.SALES_DOC_ID;
					sap.m.URLHelper.redirect(sUrl, true);
				} else if (oRevenueType === "SR") {
					sUrl = sHTTPS + eSystemID + url + onPremSalesDoc + object.SALES_DOC_ID;
					sap.m.URLHelper.redirect(sUrl, true);
				} else {
					MessageBox.error(oMissingLinkMsg);
					return;
				}
			} else {
				MessageBox.error(oMissingLinkMsg);
				return;
			}

			// 	if (oRevenueType === "Cl") {
			// 	if (oProcessType === "Historic") {
			// 		sUrl = sHTTPS + sSystemID + url + crmSalesUrlAccount + "BT116_SRVO" + crmUrlAction + "B" + crmUrlValue +
			// 			object.SALES_DOC_ID + crmUrlKeyName + "OBJECT_ID" + sapRole;
			// 			sap.m.URLHelper.redirect(sUrl, true);
			// 	} 
			// } else if (oRevenueType === "On") {
			// 	if (oProcessType === "Historic") {
			// 		sUrl = sHTTPS + eSystemID + url + onPremSalesDoc + object.SALES_DOC_ID;
			// 		sap.m.URLHelper.redirect(sUrl, true);
			// 		//	crmUrl + "ERPQUOTATION" + crmUrlAction + "B" + crmUrlValue +object.QUOTE_ID + crmUrlKeyName + "VBELN" + sapRole;
			// 	} 
			// } else if (oRevenueType === "Se") {
			// 	sUrl = sHTTPS + eSystemID + url + onPremSalesDoc + object.SALES_DOC_ID;
			// 	sap.m.URLHelper.redirect(sUrl, true);
			// } else {
			// 	MessageBox.error(oMissingLinkMsg);
			// 	return;
			// }

			/*if (oRevenueType === "Cl") {
				if (oProcessType === "Historic") {
					sUrl = sHTTPS + sSystemID + url + crmSalesUrlAccount + "BT116_SRVO" + crmUrlAction + "B" + crmUrlValue +
						object.SALES_DOC_ID + crmUrlKeyName + "OBJECT_ID" + sapRole;
				} else if (oProcessType === "Callidus/CPQ") {
					sUrl = sHTTPS + sSystemID + url + crmUrlAccount + "BT266_PRVC" + crmUrlValue + oSalesDocGuid + sapRole;
					// oQuoteId = prefixSubstitute.substr(oQuoteId.length) + oQuoteId;
					// sUrl = sHTTPS + flpUrl + flpHarmony + flpOpp + object.OPPORTUNITY_ID + flpQuote + oQuoteId;
				}
				sap.m.URLHelper.redirect(sUrl, true);
			} else if (oRevenueType === "On") {
				if (oProcessType === "Historic") {
					sUrl = sHTTPS + eSystemID + url + onPremSalesDoc + object.SALES_DOC_ID;
					//	crmUrl + "ERPQUOTATION" + crmUrlAction + "B" + crmUrlValue +object.QUOTE_ID + crmUrlKeyName + "VBELN" + sapRole;
				} else if (oProcessType === "Callidus/CPQ") {
					sUrl = sHTTPS + sSystemID + url + crmUrlAccount + "BT266_PRVC" + crmUrlValue + oSalesDocGuid + sapRole;
					// oQuoteId = prefixSubstitute.substr(oQuoteId.length) + oQuoteId;
					// sUrl = sHTTPS + flpUrl + flpHarmony + flpOpp + object.OPPORTUNITY_ID + flpQuote + oQuoteId;
				}
				sap.m.URLHelper.redirect(sUrl, true);
			} else if (oRevenueType === "Se") {
				sUrl = sHTTPS + eSystemID + url + onPremSalesDoc + object.SALES_DOC_ID;
				sap.m.URLHelper.redirect(sUrl, true);
			} else {
				MessageBox.error(oMissingLinkMsg);
				return;
			}*/
		},

		//Navigate to Oppurtunity Id details
		onOpportunityIDPress: function (oEvent) {
			var object = oEvent.getSource().getParent()._getBindingContext().getObject();
			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var sHTTPS = appConfigModel.getProperty("/protocol");
			var sSystemID = appConfigModel.getProperty("/SystemsInfo").CRMSYS;
			var url = appConfigModel.getProperty("/url");
			var crmUrl = appConfigModel.getProperty("/crmUrl");
			var crmUrlAction = appConfigModel.getProperty("/crmUrlAction");
			var crmUrlValue = appConfigModel.getProperty("/crmUrlValue");
			var crmUrlKeyName = appConfigModel.getProperty("/crmUrlKeyName");
			var sapRole = appConfigModel.getProperty("/sapRole");
			var sUrl = sHTTPS + sSystemID + url + crmUrl + "BT111_OPPT" + crmUrlAction + "B" + crmUrlValue +
				object.OPPORTUNITY_ID + crmUrlKeyName + "OBJECT_ID" + sapRole;
			sap.m.URLHelper.redirect(sUrl, true);
		},
		//onclick searchinfotext
		onSearchInfo: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			if (!this.oDefaultMessageDialog) {
				this.oDefaultMessageDialog = new Dialog({
					type: DialogType.Message,
					title: "Information:",
					content: new Text({
						text: i18nModel.getText("SearchTextInfo")
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "OK",
						press: function () {
							this.oDefaultMessageDialog.close();
						}.bind(this)
					})
				});
			}
			this.oDefaultMessageDialog.open();
		},

		// Start of code added by C5270230 on 26-sep-2023 as per JIRA ID: ITSDEDLC-1828
		// Second Level Search Information Data Sarts Here
		Second_level_Search_Info: function () {
			if (!this.Disp_Info_Second_Level_Search_Dialog) {
				this.Disp_Info_Second_Level_Search_Dialog = this.loadFragment({
					name: "c2r.c2rdcd.view.DispInfoSecondLevelSearch"
				});
			}
			this.Disp_Info_Second_Level_Search_Dialog.then(function (oDialog_Disp_Info_Second_Level_Search) {
				oDialog_Disp_Info_Second_Level_Search.open();
			});
		},
		Disp_Info_Second_Level_Search_Button: function () {
			this.byId("Disp_Info_Second_Level_Search_Dialog").close();
		},
		// Home Page Search Display Ends Here

		// Contract Map Search Information Data Sarts Here
		Info_ContractMap_Search: function () {
			if (!this.CDialog) {
				this.CDialog = this.loadFragment({
					name: "c2r.c2rdcd.view.DispInfoContractMap"
				});
			}
			this.CDialog.then(function (oDialog) {
				oDialog.open();
			});
		},
		Disp_Info_ContractMap_Search_Button: function () {
			this.byId("Disp_Info_ContractMap_Search_Dialog").close();
		},
		// Contract Map Search Display Ends Here
		// XReference Information Data Sarts Here
		ReportInformation_XRef: function () {
			// alert('Hello Xref');
			if (!this.pDialog) {
				this.pDialog = this.loadFragment({
					name: "c2r.c2rdcd.view.DispInfoXRef"
				});
			}
			this.pDialog.then(function (aDialog) {
				aDialog.open();
			});
		},
		Disp_Info_XReference_Search_Button: function () {
			this.byId("Disp_Info_XReference_Search_Dialog").close();
		},
		// XReference Information Ends Here

		// End of code added by C5270230 on 26-sep-2023 as per JIRA ID: ITSDEDLC-1828

		onbasicSearchInfo: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			if (!this.oDefaultMessageDialog) {
				this.oDefaultMessageDialog = new Dialog({
					type: DialogType.Message,
					title: "Information:",
					content: new Text({
						text: i18nModel.getText("BasicSearchTextInfo")
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "OK",
						press: function () {
							this.oDefaultMessageDialog.close();
						}.bind(this)
					})
				});
			}
			this.oDefaultMessageDialog.open();
		},

		//new Glossary
		onSearchPress: function (oEvent) {
			oEvent.getSource().setVisible(false);
			var oSrch = this.getView().byId("searchGlossary");
			oSrch.setVisible(true);
			oSrch.setWidth("35rem");
		},

		//new Glossary Search
		onSearch: function (oEvent) {
			this.getView().byId("searchBtn").setVisible(true);
			var oSrch = this.getView().byId("searchGlossary");
			oSrch.setValue("");
			oSrch.setVisible(false);
		},

		//open the details after search
		handleSuggest: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = [];
			if (sTerm) {
				aFilters.push(new Filter("FIELDNAME", sap.ui.model.FilterOperator.StartsWith, sTerm));
			}
			oEvent.getSource().getBinding("suggestionRows").filter(aFilters);
		},

		//on click of the suggestion item
		onSuggestionItemSelect: function (oEvent) {
			var obj = oEvent.getParameter("selectedRow").getBindingContext().getObject();
			var oI18n = this.getOwnerComponent().getModel("i18n");
			var msg = oI18n.getProperty("glossaryName") + " : " + obj.FIELDNAME + "\n" +
				oI18n.getProperty("glossaryDefinition") + " : " + obj.FIELDDEFINATION + "\n" +
				oI18n.getProperty("glossaryRevenueType") + " : " + obj.REVENUE_TYPE;

			var that = this;
			var dialog = new Dialog({
				title: oI18n.getProperty("glossaryText"),
				content: new Text({
					text: msg
				}).addStyleClass("sapUiSmallMargin"),
				beginButton: new Button({
					text: 'OK',
					press: function () {
						dialog.close();
						that.onSearch();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},

		//filter the search in glossary
		filterGlossary: function (oEvent) {
			var sValue = oEvent.getParameter("newValue");
			var aFilters = [];

			if (sValue) {
				var oFilter = new Filter("FIELDNAME", FilterOperator.Contains, sValue);
				aFilters.push(oFilter);
			}
			oEvent.getSource().getBinding("suggestionRows").filter(aFilters);
		},

		//Open disclaimer pop-up
		openDisclaimer: function () {
			if (!this.oPrivacyDialog) {
				this.oPrivacyDialog = sap.ui.xmlfragment(this.getView().getId(), "c2r.c2rdcd.fragments.disclaimer", this);
				this.getView().addDependent(this.oPrivacyDialog);
			}
			this.oPrivacyDialog.open();
		},

		//open the latest news amd updates
		goToLatestNewsUpdate: function () {
			this.oPrivacyDialog.close();
			var bShowNewsAndUpdate = true;
			this.onInfoPress(null, bShowNewsAndUpdate);
		},
		//graph search extention
		onGraphSearch: function (oEvent) {
			if (oEvent.getParameter("key")) {
				var sKey = oEvent.getParameter("key");
				if (sKey.startsWith("line")) {
					var aLines = oEvent.getSource().getLines();
					for (var i = 0; i < aLines.length; i++) {
						if (sKey === aLines[i].getKey()) {
							var oLineDomRef = aLines[i].getFocusDomRef();
							oLineDomRef.scrollIntoView({
								block: "center"
							});
						}
					}
				} else {
					var oNode = oEvent.getSource().getNodeByKey(sKey);
					var oNodeDomRef = oNode.getFocusDomRef();
					oNodeDomRef.scrollIntoView({
						block: "center"
					});
				}
			}
		},
		// search filter for contract tab
		onSearchContract: function (oEvent) {
			var ograph = this.getView().byId("graph");
			ograph.setBusy(true);
			var group_By;
			var revenue_Type;
			var solution_Type;
			var aFilter = [];
			var aGroups = [];
			var aLinks = [];
			var aNodes = [];
			var oSearchValue = this.getView().byId("searchField").getValue();
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			var oResourceModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oFilters = oModelAppConfig.getProperty("/filters");
			var ogroup_By = oModelAppConfig.getProperty("/groupBy");
			var orevenue_Type = oModelAppConfig.getProperty("/revenueType");
			var osolution_Type = oModelAppConfig.getProperty("/solutionType");
			var oFilterBar = this.oFilterBar = this.getView().byId("filterBar")
			for (var i = 0; i < oFilters.length; i++) {
				if (oFilters[i].sPath == "GROUP_TYPE") {
					group_By = oFilters[i].oValue1;
				}

				if (oFilters[i].sPath == "ODSOLTYPE") {
					solution_Type = oFilters[i].oValue1;
				}
			}
			aFilter.push(new sap.ui.model.Filter("CONTRACT_SEARCH", sap.ui.model.FilterOperator.EQ, oSearchValue));
			aFilter.push(new sap.ui.model
				.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
			aFilter.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model
				.FilterOperator.EQ, this.sAccountId));
			aFilter.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ,
				erpNumber));
			if (ogroup_By == undefined) {
				aFilter.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, group_By));
			} else {
				aFilter.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, ogroup_By));
			}
			aFilter.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, "Al"));
			if (osolution_Type == undefined) {
				aFilter.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, solution_Type));
			} else {
				for (var j = 0; j < osolution_Type.length; j++) {
					aFilter.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, osolution_Type[j].getProperty("key")));
				}
			}

			this.getOwnerComponent().getModel().read("/NGOverviewSet", {
				filters: aFilter,
				urlParameters: {
					"$expand": "NGNodeSet/NGNodeAttrSet,NGLinksSet,NGGroupsSet"
				},
				success: function (oData, response) {
					if (oData.results.length > 0) {
						aGroups = oData.results[0].NGGroupsSet.results;
						aLinks = oData.results[0].NGLinksSet.results;
						aNodes = oData.results[0].NGNodeSet.results;
						for (var i = 0; i < aNodes.length; i++) {
							var formattedAttribute = aNodes[i].ATTRIBUTES.replace(/"/g, '');
							var aATTRIBUTES = JSON.parse(formattedAttribute.replace(/'/g, '"'));
							aNodes[i].ATTRIBUTES = aATTRIBUTES;
						}
						oModelAppConfig.setProperty("/nodes", aNodes);
						oModelAppConfig.setProperty("/lines", aLinks);
						oModelAppConfig.setProperty("/groups", aGroups);
					} else {
						sap.m.MessageToast.show(oResourceModel.getText("noDataFound"), {
							duration: 5000,
							width: "40em"
						});
					}
					ograph.setBusy(false);
				}.bind(this),
				error: function (error) {
					ograph.setBusy(false);
					sap.m.MessageToast.show(oResourceModel.getText("dataErrorNG"), {
						duration: 5000,
						width: "25em"
					});
				}
			});
		},
		//ITSDEDLC-812 FilterBar search functionality 
		onSearch: function (oEvent) {
			var ograph = this.getView().byId("graph");
			ograph.setBusy(true);
			var group_By, map;
			var revenue_Type;
			var solution_Type;
			var aFilter = [];
			var aGroups = [];
			var aLinks = [];
			var aNodes = [];
			var oSearchValue = this.getView().byId("searchField").getValue();
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			var oResourceModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oFilters = oModelAppConfig.getProperty("/filters");
			var ogroup_By = oModelAppConfig.getProperty("/groupBy");
			var omap_Type = oModelAppConfig.getProperty("/Map");
			var orevenue_Type = oModelAppConfig.getProperty("/revenueType");
			var osolution_Type = oModelAppConfig.getProperty("/solutionType");
			var oFilterBar = this.oFilterBar = this.getView().byId("filterBar");
			//Begin code ITSDEDLC-857
			var aSalesOrgSelectedKeys = oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[0]).getSelectedKeys();
			if (aSalesOrgSelectedKeys != undefined || aSalesOrgSelectedKeys !== "") {
				for (var j = 0; j < aSalesOrgSelectedKeys.length; j++) {
					aFilter.push(new sap.ui.model.Filter("SALESORG", sap.ui.model.FilterOperator.EQ, aSalesOrgSelectedKeys[j]));
				}

			}
			var DisChannelSelectedKeys = oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[1]).getSelectedKeys()
			if (DisChannelSelectedKeys != undefined || DisChannelSelectedKeys !== "") {
				for (var j = 0; j < DisChannelSelectedKeys.length; j++) {
					aFilter.push(new sap.ui.model.Filter("DCHANNEL", sap.ui.model.FilterOperator.EQ, DisChannelSelectedKeys[j]));
				}
			}
			//Begin code ITSDEDLC-957
			var RevTypeSelectedKeys = oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[2]).getSelectedKeys()
				// if (RevTypeSelectedKeys == "") {
				// 	aFilter.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, "Al"));
				// } else {
				// 	aFilter.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, RevTypeSelectedKeys));
				// }
				//End code ITSDEDLC-957
			var aDocatSelectedKeys = oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[3]).getSelectedKeys()
				// aFilter.push(new sap.ui.model.Filter("DOCCAT", sap.ui.model.FilterOperator.EQ, aDocatSelectedKeys));

			if (aDocatSelectedKeys !== undefined || aDocatSelectedKeys !== "") {
				for (var j = 0; j < aDocatSelectedKeys.length; j++) {
					aFilter.push(new sap.ui.model.Filter("DOCCAT", sap.ui.model.FilterOperator.EQ, aDocatSelectedKeys[j]));
				}
			}

			var aBookingYearStart = oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[4]).getDateValue()
			var aBookingYearEnd = oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[4]).getSecondDateValue();
			if (aBookingYearStart !== null) {
				var filter = new sap.ui.model.Filter("BOOK_YEAR", sap.ui.model.FilterOperator.BT, aBookingYearStart, aBookingYearEnd); //sfltMinBillingDate //sfltMaxBillingDate
				aFilter.push(filter)
			}
			for (var i = 0; i < oFilters.length; i++) {
				if (oFilters[i].sPath == "GROUP_TYPE") {
					group_By = oFilters[i].oValue1;
				}
				if (oFilters[i].sPath == "XREF") {
					map = oFilters[i].oValue1;
				}
				if (oFilters[i].sPath == "ODSOLTYPE") {
					solution_Type = oFilters[i].oValue1;
				}
			}

			if (oSearchValue != undefined || oSearchValue !== "") {
				aFilter.push(new sap.ui.model.Filter("CONTRACT_SEARCH", sap.ui.model.FilterOperator.EQ, oSearchValue));
			}
			aFilter.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
			aFilter.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, this.sAccountId));
			aFilter.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));
			if (ogroup_By == undefined) {
				aFilter.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, group_By));
			} else {
				aFilter.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, ogroup_By));
			}
			if (omap_Type == undefined) {
				aFilter.push(new sap.ui.model.Filter("XREF", sap.ui.model.FilterOperator.EQ, "Y"));
			} else {
				aFilter.push(new sap.ui.model.Filter("XREF", sap.ui.model.FilterOperator.EQ, omap_Type));
			}

			if (osolution_Type == undefined) {
				aFilter.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, solution_Type));
			} else {
				for (var j = 0; j < osolution_Type.length; j++) {
					aFilter.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, osolution_Type[j].getProperty("key")));
				}
			}

			if (RevTypeSelectedKeys !== undefined || RevTypeSelectedKeys !== "") {
				for (var j = 0; j < RevTypeSelectedKeys.length; j++) {
					aFilter.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, RevTypeSelectedKeys[j]));
				}
			}

			this.getOwnerComponent().getModel().read("/NGOverviewSet", {
				filters: aFilter,
				urlParameters: {
					"$expand": "NGNodeSet/NGNodeAttrSet,NGLinksSet,NGGroupsSet"
				},
				success: function (oData, response) {

					//this.getView().byId("graph").setNoData(false);
					if (oData.results.length > 0) {

						aGroups = oData.results[0].NGGroupsSet.results;
						aLinks = oData.results[0].NGLinksSet.results;
						aNodes = oData.results[0].NGNodeSet.results;
						for (var i = 0; i < aNodes.length; i++) {
							var formattedAttribute = aNodes[i].ATTRIBUTES.replace(/"/g, '');
							var aATTRIBUTES = JSON.parse(formattedAttribute.replace(/'/g, '"'));
							aNodes[i].ATTRIBUTES = aATTRIBUTES;
						}

						oModelAppConfig.setProperty("/nodes", aNodes);
						oModelAppConfig.setProperty("/lines", aLinks);
						oModelAppConfig.setProperty("/groups", aGroups);
					} else {
						//	this.getView().byId("graph").setNoData(true);
						sap.m.MessageToast.show(oResourceModel.getText("noDataFound"), {
							duration: 5000,
							width: "40em"
						});
					}
					ograph.setBusy(false);
				}.bind(this),

				error: function (error) {
					ograph.setBusy(false);
					sap.m.MessageToast.show(oResourceModel.getText("dataErrorNG"), {
						duration: 5000,
						width: "25em"
					});
				}
			});
		},

		//ITSDEDLC-857 - Contract Map Enhancements filters
		onClear: function (oEvent) {
			var oFilterBar = this.oFilterBar = this.getView().byId("filterBar");

			if (oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[0]).getSelectedKeys() > 0) {
				oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[0]).setSelectedItems("");
			}
			if (oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[1]).getSelectedKeys() > 0) {
				oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[1]).setSelectedItems("");
			}
			if (oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[2]).getSelectedKeys().length > 0) {
				oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[2]).setSelectedItems("");
			}
			if (oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[3]).getSelectedKeys().length > 0) {
				oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[3]).setSelectedItems("");
			}
			if (oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[4]).getValue().length > 0) {
				oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[4]).setValue("");
			}
			if (this.getView().byId("searchField").getValue().length > 0)
				this.getView().byId("searchField").setValue("");
		}
	});
});
// 		onSearch: function (oEvent) {
// 			var ograph = this.getView().byId("graph");
// 			ograph.setBusy(true);
// 			var group_By, map;
// 			var revenue_Type;
// 			var solution_Type;
// 			var aFilter = [];
// 			var aGroups = [];
// 			var aLinks = [];
// 			var aNodes = [];
// 			var oSearchValue = this.getView().byId("searchField").getValue();
// 			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
// 			var oResourceModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
// 			var oFilters = oModelAppConfig.getProperty("/filters");
// 			var ogroup_By = oModelAppConfig.getProperty("/groupBy");
// 			var omap_Type = oModelAppConfig.getProperty("/Map");
// 			var orevenue_Type = oModelAppConfig.getProperty("/revenueType");
// 			var osolution_Type = oModelAppConfig.getProperty("/solutionType");
// 			var oFilterBar = this.oFilterBar = this.getView().byId("filterBar");
// 			//Begin code ITSDEDLC-857
// 			var aSalesOrgSelectedKeys = oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[0]).getSelectedKeys();
// 			aFilter.push(new sap.ui.model.Filter("SALESORG", sap.ui.model.FilterOperator.EQ, aSalesOrgSelectedKeys));
// 			var DisChannelSelectedKeys = oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[1]).getSelectedKeys()
// 			aFilter.push(new sap.ui.model.Filter("DCHANNEL", sap.ui.model.FilterOperator.EQ, DisChannelSelectedKeys));
// 			//Begin code ITSDEDLC-957
// 			var RevTypeSelectedKeys = oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[2]).getSelectedKeys()
// 			if (RevTypeSelectedKeys == "") {
// 				aFilter.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, "Al"));
// 			} else {
// 				aFilter.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, RevTypeSelectedKeys));
// 			}
// 			//End code ITSDEDLC-957
// 			var aDocatSelectedKeys = oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[3]).getSelectedKeys()
// 			aFilter.push(new sap.ui.model.Filter("DOCCAT", sap.ui.model.FilterOperator.EQ, aDocatSelectedKeys));
// 			var aBookingYearStart = oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[4]).getDateValue()
// 			var aBookingYearEnd = oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[4]).getSecondDateValue();
// 			if (aBookingYearStart !== null) {
// 				var filter = new sap.ui.model.Filter("BOOK_YEAR", sap.ui.model.FilterOperator.BT, aBookingYearStart, aBookingYearEnd); //sfltMinBillingDate //sfltMaxBillingDate
// 				aFilter.push(filter)
// 			}
// 			for (var i = 0; i < oFilters.length; i++) {
// 				if (oFilters[i].sPath == "GROUP_TYPE") {
// 					group_By = oFilters[i].oValue1;
// 				}
// 				if (oFilters[i].sPath == "XREF") {
// 					map = oFilters[i].oValue1;
// 				}
// 				// ITSDCDLEC - 957 Moving the revenue type filter
// 				// if (oFilters[i].sPath == "REVENUETYPE") {
// 				// 	revenue_Type = oFilters[i].oValue1;
// 				// }
// 				// End Code ITSDCDLEC - 957
// 				if (oFilters[i].sPath == "ODSOLTYPE") {
// 					solution_Type = oFilters[i].oValue1;
// 				}
// 			}

// 			aFilter.push(new sap.ui.model.Filter("CONTRACT_SEARCH", sap.ui.model.FilterOperator.EQ, oSearchValue));
// 			aFilter.push(new sap.ui.model.Filter("TYPE", sap.ui.model.FilterOperator.EQ, "CUSTOMER"));
// 			aFilter.push(new sap.ui.model.Filter("BUSINESSPARTNER", sap.ui.model.FilterOperator.EQ, this.sAccountId));
// 			aFilter.push(new sap.ui.model.Filter("ERPNUMBER", sap.ui.model.FilterOperator.EQ, erpNumber));
// 			if (ogroup_By == undefined) {
// 				aFilter.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, group_By));
// 			} else {
// 				aFilter.push(new sap.ui.model.Filter("GROUP_TYPE", sap.ui.model.FilterOperator.EQ, ogroup_By));
// 			}
// 			if (omap_Type == undefined) {
// 				aFilter.push(new sap.ui.model.Filter("XREF", sap.ui.model.FilterOperator.EQ, "Y"));
// 			} else {
// 				aFilter.push(new sap.ui.model.Filter("XREF", sap.ui.model.FilterOperator.EQ, omap_Type));
// 			}
// 			// if (orevenue_Type == undefined) {
// 			//Begin code ITSDEDLC-957
// 			// 	if (RevTypeSelectedKeys == "") {
// 			// 		aFilter.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, "Al"));
// 			// 	} else {
// 			// 		aFilter.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, RevTypeSelectedKeys));
// 			// 	}
// 			// } else {
// 			// 	aFilter.push(new sap.ui.model.Filter("REVENUETYPE", sap.ui.model.FilterOperator.EQ, orevenue_Type));
// 			// }
// 			//End code ITSDEDLC-957
// 			if (osolution_Type == undefined) {
// 				aFilter.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, solution_Type));
// 			} else {
// 				for (var j = 0; j < osolution_Type.length; j++) {
// 					aFilter.push(new sap.ui.model.Filter("ODSOLTYPE", sap.ui.model.FilterOperator.EQ, osolution_Type[j].getProperty("key")));
// 				}
// 			}

// 			this.getOwnerComponent().getModel().read("/NGOverviewSet", {
// 				filters: aFilter,
// 				urlParameters: {
// 					"$expand": "NGNodeSet/NGNodeAttrSet,NGLinksSet,NGGroupsSet"
// 				},
// 				success: function (oData, response) {

// 					//this.getView().byId("graph").setNoData(false);
// 					if (oData.results.length > 0) {

// 						aGroups = oData.results[0].NGGroupsSet.results;
// 						aLinks = oData.results[0].NGLinksSet.results;
// 						aNodes = oData.results[0].NGNodeSet.results;
// 						for (var i = 0; i < aNodes.length; i++) {
// 							var formattedAttribute = aNodes[i].ATTRIBUTES.replace(/"/g, '');
// 							var aATTRIBUTES = JSON.parse(formattedAttribute.replace(/'/g, '"'));
// 							aNodes[i].ATTRIBUTES = aATTRIBUTES;
// 						}

// 						oModelAppConfig.setProperty("/nodes", aNodes);
// 						oModelAppConfig.setProperty("/lines", aLinks);
// 						oModelAppConfig.setProperty("/groups", aGroups);
// 					} else {
// 						//	this.getView().byId("graph").setNoData(true);
// 						sap.m.MessageToast.show(oResourceModel.getText("noDataFound"), {
// 							duration: 5000,
// 							width: "40em"
// 						});
// 					}
// 					ograph.setBusy(false);
// 				}.bind(this),

// 				error: function (error) {
// 					ograph.setBusy(false);
// 					sap.m.MessageToast.show(oResourceModel.getText("dataErrorNG"), {
// 						duration: 5000,
// 						width: "25em"
// 					});
// 				}
// 			});
// 		},

// 		//ITSDEDLC-857 - Contract Map Enhancements filters
// 		onClear: function (oEvent) {
// 				var oFilterBar = this.oFilterBar = this.getView().byId("filterBar");

// 				if (oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[0]).getSelectedKeys() > 0) {
// 					oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[0]).setSelectedItems("");
// 				}
// 				if (oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[1]).getSelectedKeys() > 0) {
// 					oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[1]).setSelectedItems("");
// 				}
// 				if (oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[2]).getSelectedKeys().length > 0) {
// 					oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[2]).setSelectedItems("");
// 				}
// 				if (oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[3]).getSelectedKeys().length > 0) {
// 					oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[3]).setSelectedItems("");
// 				}
// 				if (oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[4]).getValue().length > 0) {
// 					oFilterBar.determineControlByFilterItem(oEvent.getSource().getFilterGroupItems()[4]).setValue("");
// 				}
// 				if (this.getView().byId("searchField").getValue().length > 0)
// 					this.getView().byId("searchField").setValue("");

// 			}
// 			// handleChange: function (oEvent) {
// 			// 	var sFrom = oEvent.getParameter("from");
// 			// 	var	sTo = oEvent.getParameter("to");
// 			// 	var	bValid = oEvent.getParameter("valid");
// 			// 	var	oEventSource = oEvent.getSource();
// 			// 		// oText = this.byId("TextEvent");

// 		// 		// this._iEvent++;

// 		// 	// oText.setText("Id: " + oEventSource.getId() + "\nFrom: " + sFrom + "\nTo: " + sTo);

// 		// 	if (bValid) {
// 		// 		oEventSource.setValueState(ValueState.None);
// 		// 	} else {
// 		// 		oEventSource.setValueState(ValueState.Error);
// 		// 	}
// 		// }

// 	});
// });