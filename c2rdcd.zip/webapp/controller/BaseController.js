sap.ui.define([
	"sap/ui/core/mvc/Controller"
	
], function (Controller) { 
	"use strict";
// Testing 
	return Controller.extend("c2r.c2rdcd.controller.BaseController", {
		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		//download Invoice 
		onCMSInvoiceDownload: function (oEvent) {
			var base64EncodedPDF = oEvent.getSource().getParent().getBindingContext().getObject().DOCUMENT;
			if (base64EncodedPDF) {
				var decodedPdfContent = atob(base64EncodedPDF);
				var byteArray = new Uint8Array(decodedPdfContent.length);
				for (var i = 0; i < decodedPdfContent.length; i++) {
					byteArray[i] = decodedPdfContent.charCodeAt(i);
				}
				var blob = new Blob([byteArray.buffer], {
					type: "application/pdf"
				});
				var pdfurl = URL.createObjectURL(blob);
				sap.m.URLHelper.redirect(pdfurl, true);
			} else {
				MessageBox.error(oEvent.getSource().getParent().getBindingContext().getObject().MESSAGE);
			}
		},
		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Getter for the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onShareEmailPress: function () {
			var oViewModel = (this.getModel("objectView") || this.getModel("worklistView"));
			sap.m.URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},

		//getSystem Info 
		_getSystemInfo: function () {
			var that = this;
			this.getOwnerComponent().getModel().callFunction("/GetServer", {
				method: "GET",
				urlParameters: {},
				success: jQuery.proxy(function (oData, response) {
					if (oData.GetServer) {
						that.getOwnerComponent().getModel("AppConfig").setProperty("/SystemsInfo", oData.GetServer);
						that.getOwnerComponent().getModel("AppConfig").setProperty("/NavigationEnabled", true);
					}
				}, this),
				error: function (oError) {
					sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},

		//getAdminAccess info
		getAdminAccess: function () {
			this.getOwnerComponent().getModel().callFunction("/GetAdminAccess", {
				method: "GET",
				urlParameters: {},
				success: jQuery.proxy(function (oData, response) {
					if (oData.GetAdminAccess) {
						this.getOwnerComponent().getModel("AppConfig").setProperty("/AdminAccess", oData.GetAdminAccess.ADMIN);
					}
				}, this),
				error: function (oError) {
					sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},

		getSalesOrgfilterdata: function () {

			this.getOwnerComponent().getModel().callFunction("/GetSalesOrg", {
				method: "GET",
				urlParameters: {
					SALES_ORG: ""
				},
				success: jQuery.proxy(function (oData, response) {
					if (oData.results.length > 0) {
						this.getOwnerComponent().getModel("AppConfig").setProperty("/Salesorg", oData.results);
					}
				}, this),
				error: function (oError) {
					sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},

		getDisChannelfilterdata: function () {
			this.getOwnerComponent().getModel().callFunction("/GetDchannel", {
				method: "GET",
				urlParameters: {
					DCHANNEL: ""
				},
				success: jQuery.proxy(function (oData, response) {
					if (oData.results.length > 0) {
						this.getOwnerComponent().getModel("AppConfig").setProperty("/Dischannel", oData.results);
					}
				}, this),
				error: function (oError) {
					sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		getDocCategoryfilterdata: function () {
			this.getOwnerComponent().getModel().callFunction("/GetDoccat", {
				method: "GET",
				urlParameters: {
					DOCCAT: ""
				},
				success: jQuery.proxy(function (oData, response) {
					if (oData.results.length > 0) {
						this.getOwnerComponent().getModel("AppConfig").setProperty("/Doccaterogy", oData.results);
					}
				}, this),
				error: function (oError) {
					sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		onReferenceCaseIDPress: function (oEvt) {
			var oCaseId = oEvt.getSource().getBindingContext("DCD").getObject().REFERENCE_CASE;
			this.openCaseID(oCaseId);
		},
		//Case Id Press
		onCaseIDPress: function (oEvt) {
			var oCaseId = oEvt.getSource().getProperty("title");
			this.openCaseID(oCaseId);
		},

		openCaseID: function (oCaseId) {
			var prefixSubstitute = "000000000000";
			oCaseId = prefixSubstitute.substr(oCaseId.length) + oCaseId;
			var appConfigmodel = this.getOwnerComponent().getModel("AppConfig");
			var sHTTPS = appConfigmodel.getProperty("/protocol");
			var sSystemID = appConfigmodel.getProperty("/SystemsInfo").SYSID;
			var url = appConfigmodel.getProperty("/url");
			var crmUrlCase = appConfigmodel.getProperty("/crmUrlCase");
			var crmUrlCaseMode = appConfigmodel.getProperty("/crmUrlCaseMode");

			var sUrl = sHTTPS + sSystemID + url + crmUrlCase + oCaseId + crmUrlCaseMode;
			sap.m.URLHelper.redirect(sUrl, true);
		},
		//Open Hierarchy Pop-up
		openHierarchy: function () {
			this.onHierarchyPress(null, this.bpnumber);
		},
		//open hierchy details in new tab 
		openHierarchyLink: function (oEvent) {
			this.onHierarchyLinkPress(oEvent, this.bpnumber);
		},

		onCancelHierarchy: function () {
			var that = this;
			that._oHierarchyDialog.close();
		},
		//Hierarchy Link Press
		onHierarchyLinkPress: function (oEvent, bpId) {
			var hierarchyElem = oEvent.getSource().getBindingContext("hierarchy").getObject(),
				appConfigmodel = this.getOwnerComponent().getModel("AppConfig"),
				sHTTPS = appConfigmodel.getProperty("/protocol"),
				sSystemID = appConfigmodel.getProperty("/SystemsInfo").CRMSYS,
				eSystemID = appConfigmodel.getProperty("/SystemsInfo").SYSID,
				hierarchySell = appConfigmodel.getProperty("/hierarchySell"),
				globalGroup = appConfigmodel.getProperty("/globalGroup"),
				planningGroup = appConfigmodel.getProperty("/planningGroup"),
				planningEntity = appConfigmodel.getProperty("/planningEntity"),
				account = appConfigmodel.getProperty("/account");

			var hierarchyUrl = "";
			if (sSystemID === "ICD" || eSystemID === "ISD") {
				hierarchyUrl = appConfigmodel.getProperty("/hierarchyUrlDev");
			} else if (sSystemID === "ICT" || eSystemID === "IST") {
				hierarchyUrl = appConfigmodel.getProperty("/hierarchyUrlTest");
			} else if (sSystemID === "ICP" || eSystemID === "ISP") {
				hierarchyUrl = appConfigmodel.getProperty("/hierarchyUrlProd");
			}

			var sUrl = "";

			if (hierarchyElem.type === "Global Group") {
				sUrl = sHTTPS + hierarchyUrl + globalGroup + bpId + hierarchySell;
			} else if (hierarchyElem.type === "Planning Group") {
				sUrl = sHTTPS + hierarchyUrl + planningGroup + hierarchyElem.name + "/" + bpId + hierarchySell;
			} else if (hierarchyElem.type === "Planning Entity") {
				sUrl = sHTTPS + hierarchyUrl + planningEntity + hierarchyElem.id + hierarchySell;
			} else {
				sUrl = sHTTPS + hierarchyUrl + account + hierarchyElem.id + hierarchySell;
			}
			sap.m.URLHelper.redirect(sUrl, true);
		},

		//Case Id Hover
		onHandleHover: function (oEvt) {
			var oBindingContextSource = oEvt.getSource().getBindingContext();
			var oObject = oBindingContextSource.getObject();
			var oModel = new sap.ui.model.json.JSONModel(oObject);
			if (!this._CaseInfoPopover) {
				this._CaseInfoPopover = sap.ui.xmlfragment("c2r.c2rdcd.fragments.overviewpopover", this);
				this.getView().addDependent(this._CaseInfoPopover);
			}
			this._CaseInfoPopover.setModel(oModel);
			this._CaseInfoPopover.openBy(oEvt.getSource());
		},
	
	
	//ITSDEDLC 1665
	LPROpen:  function (oEvent) {
		//ITSDEDLC-2305
		var revenuetype = oEvent.getSource().getBindingContext().getObject().REVENUETYPE;
		if ( revenuetype === "CL"){
			var that = this;
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDCD_SRV;v=0002/", true);
			//   if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("c2r.c2rdcd.fragments.LPRpopover", this);
				this.getView().addDependent(this._oPopover);
			// }
			var caseID = oEvent.getSource().getParent().getBindingContext().getObject().CASE_ID;
			var ocaseguid = oEvent.getSource().getParent().getBindingContext().getObject().LPR_ID;
			if (caseID) {
		
				caseID = caseID.toUpperCase();
				oModel.read("/LPRDocsURL001Set?$filter=Lprid eq '" + ocaseguid + "' and CaseId eq '" + caseID + "'", null, null, false,
					function (oDataCMS, oResponse) {
						var t = new sap.ui.model.json.JSONModel(oDataCMS);
						that.getView().setModel(t, "DCD");
					});
			}
			this._oPopover.openBy(oEvent.getSource());
		}
		else {
			
		sap.m.MessageBox.error("Data is not Available.");
		
		}
		},
		
		//OnCase hover out
		onHandleHoverOut: function (oEvt) {
			if (this._CaseInfoPopover) {
				this._CaseInfoPopover.close();
			}
		},

		//information pop up
		onInfoPress: function (evt, bShowNewsAndUpdate) {
			if (!this.oInfoDialog) {
				this.oInfoDialog = sap.ui.xmlfragment("c2r.c2rdcd.fragments.information", this);
				this.getView().addDependent(this.oInfoDialog);
			}
			this.oInfoDialog.open();
			if (bShowNewsAndUpdate) {
				this.oInfoDialog.getContent()[0].setSelectedKey("newsAndUpdate");
			} else {
				this.oInfoDialog.getContent()[0].setSelectedKey("Overview");
			}
		},

		//Info dialog close
		onInfoCancel: function () {
			this.oInfoDialog.close();
		},

		// Start of code added by C5270230 on 26-sep-2023 as per JIRA ID: ITSDEDLC-1828
		// Products Information Display Starts Here
		ReportInformation_Products: function () {
			if (!this.Disp_Info_Products_Dialog) {
				this.Disp_Info_Products_Dialog = this.loadFragment({
					name: "c2r.c2rdcd.view.DispInfoProducts"
				});
			}
			this.Disp_Info_Products_Dialog.then(function (oDialog_Disp_Info_Products) {
				oDialog_Disp_Info_Products.open();
			});
		},
		//ReportInformation dialogue close
		Disp_Info_Products_Button: function () {
			this.byId("Disp_Info_Products_Dialog").close();
		},
		// End of code added by C5270230 on 26-sep-2023 as per JIRA ID: ITSDEDLC-1828


		//ReportInformation dialogue
		ReportInformation: function () {

			// create dialog lazily
			if (!this.InfoReports) {
				this.InfoReports = this.loadFragment({
					name: "c2r.c2rdcd.fragments.ReportInformation"
				});
			}
			this.InfoReports.then(function (oDialog) {
				oDialog.open();
			});
		},
		//ReportInformation dialogue close
		onClose: function () {
			this.byId("InfoReports").close();
		},

		//Open DCD Cockpit video
		onPressOverviewImg: function () {
			sap.m.URLHelper.redirect(this.getOwnerComponent().getModel("AppConfig").getProperty("/dcdCockpitVideo"), true);
		},

		//Get Authorization for DCD Cockpit
		getAuthorization: function () {
			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var sHTTPS = appConfigModel.getProperty("/protocol");
			var flpUrl = appConfigModel.getProperty("/flpUrlProd");
			var flpArm = appConfigModel.getProperty("/flpArm");
			var sUrl = sHTTPS + flpUrl + flpArm;
			sap.m.URLHelper.redirect(sUrl, true);
		},

		//Commenting the below methods(onNewsAndUpdatePress, onNewsAndUpdateSharePoint) for the ITSDEDLC-478
		//Navigae to JAM Page news and Update
		// onNewsAndUpdatePress: function () {
		// 	var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
		// 	var sHTTPS = appConfigModel.getProperty("/protocol");
		// 	var jamPageUrl = appConfigModel.getProperty("/jamPageUrl");
		// 	var sUrl = sHTTPS + jamPageUrl;
		// 	sap.m.URLHelper.redirect(sUrl, true);
		// },

		// Navigate to Share point
		// onNewsAndUpdateSharePoint: function () {
		// 	var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
		// 	var sHTTPS = appConfigModel.getProperty("/protocol");
		// 	var sharePointUrl = appConfigModel.getProperty("/sharePoint");
		// 	var sUrl = sHTTPS + sharePointUrl;
		// 	sap.m.URLHelper.redirect(sUrl, true);
		// },

		//Hierarchy pop up
		onHierarchyPress: function (evt, bpId) {
			var that = this;
			$.ajax({
				type: "GET",
				url: "/gsu/hierarchy?account=" + bpId,
				success: function (data) {
					var accHierarchyData = {};
					accHierarchyData.highLevelAccount = [];
					accHierarchyData.highLevelAccount.push(data);
					var model = new sap.ui.model.json.JSONModel(accHierarchyData);
					that.setModel(model, "hierarchy");
				},
				error: function (error) {}
			});

			if (!this._oHierarchyDialog) {
				this._oHierarchyDialog = new sap.ui.xmlfragment("c2r.c2rdcd.fragments.hierarchy",
					this);
				this.getView().addDependent(this._oHierarchyDialog);
			}
			this._oHierarchyDialog.open();
		},
		//on close of disclaimer
		onDisclaimerClose: function (oEvent) {
			if (this.getView().byId("dndCheckBox").getSelected()) {
				var that = this;
				var oModelAppConfig = that.getOwnerComponent().getModel("AppConfig");
				var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDCD_SRV;v=0002/", true);
				var oObject = {};
				oObject.DISCLAIMER_KEY = oModelAppConfig.getProperty("/disclaimer/DISCLAIMER_KEY");
				oObject.NOTIFCTN_RQSTD = "X";
				oModel.setUseBatch(false);
				oModel.update("/DCDDisclaimerSet(" + oModelAppConfig.getProperty("/disclaimer/sKey") + ")", oObject, {
					success: function (oData, response) {
						sap.m.MessageToast.show("Response Acknowledged!, Disclaimer will not be shown until further updates.", {
							duration: 5000,
							width: "25em"
						});
					},
					error: function (error) {}
				});
			}
			this.oPrivacyDialog.close();
		},
			
		//LPR download ITSDEDLC 1665 
			
		onLPRattachmentDownloads: function (oEvent) {

				var url = oEvent.getSource().getBindingContext("DCD").getObject().Url;
				var  URL = "https:" + url;
		        // var LPRattachmentDownload;
		        // var system;
		       
		        // if (system === "https://flpsandbox-br339jmc4c.dispatcher.int.sap.eu2.hana.ondemand.com/sap/fiori/c2rdcd"){
		        // 	var LPRattachmentDownload = URL.replace("https://flpsandbox-br339jmc4c.dispatcher.int.sap.eu2.hana.ondemand.com/sap/fiori/c2rdcd", URL);
		        // 	window.open(LPRattachmentDownload, true);
		        	
		        // }  else if (system === "https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sap/fiori/c2rdcd" ){
		        // 		var LPRattachmentDownload = URL.replace("https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sap/fiori/c2rdcd", URL);
		        // 	window.open(LPRattachmentDownload, true);
		        	
		        // } else if (system === "https://fiorilaunchpad.sap.com/sap/fiori/c2rdcd" ){
		        // 	var LPRattachmentDownload = URL.replace("https://fiorilaunchpad.sap.com/sap/fiori/c2rdcd", URL);
		        // 	window.open(LPRattachmentDownload, true);
		        	
		        // } else 
		        	window.open(URL, true);
		 	
		},

		//download Attachment 
		onCMSAttachmentDownload: function (oEvent) {
			var url = oEvent.getSource().getBindingContext("DCD").getObject();
			url = url.__metadata.uri;
			url = url.replace("CmsDocumentsSet", "CmsAttachmentSet");
			url = url + "/$value";
			sap.m.URLHelper.redirect(url, true);
		},
		onXReferenceAttachmentDownload: function (oEvent) {
			var url = oEvent.getSource().getBindingContext("DCD").getObject();
			url = url.__metadata.uri;
			url = url.replace("XReferenceSet", "Xreference_AttachSet");
			url = url + "/$value";
			sap.m.URLHelper.redirect(url, true);
			// var selectedPath = oEvent.getSource().getBindingContext("DCD").sPath;
			// selectedPath = selectedPath.split("/");
			// selectedPath = selectedPath[2]
			// var oPdfModel = new sap.ui.model.json.JSONModel();
			// oPdfModel.setData({
			// 	filename: oEvent.getSource().getModel("DCD").getData().results[selectedPath].FILE_NAME,
			// 	content: oEvent.getSource().getModel("DCD").getData().results[selectedPath].FileContents
			// });
			// // // this.getView().setModel(oPdfModel);
			// var oPdfModel1 = oEvent.getSource().getModel();
			// if (oPdfModel) {
			// 	var data = oPdfModel.getData();
			// 	if (data.filename && data.content) {
			// 		var element = document.createElement("a");
			// 		element.setAttribute("href", "data:application/pdf;base64," + data.content);
			// 		element.setAttribute("download", data.filename);
			// 		document.body.appendChild(element);
			// 		element.click();
			// 		document.body.removeChild(element);
			// 	}
			// }
		},

		//to get Service Quote Analyzer
		getonServiceQuoteAnalyzer: function (oEvent) {
			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var sHTTPS = appConfigModel.getProperty("/protocol");
			var ServiceQuoteAnalyzerUrl = appConfigModel.getProperty("/ServiceQuoteAnalyzer");
			var sUrl = sHTTPS + ServiceQuoteAnalyzerUrl;
			sap.m.URLHelper.redirect(sUrl, true);
		},

		//to to cloud reporting 
		getReporting: function (oEvent) {
			var sObjectId = this.bpnumber;

			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var sHTTPS = appConfigModel.getProperty("/protocol");
			var cloudUrl = appConfigModel.getProperty("/cloudReporting");
			var cloudReportingOrder = appConfigModel.getProperty("/cloudReportingOrder");
			var sUrl = sHTTPS + cloudUrl + sObjectId + cloudReportingOrder;
			sap.m.URLHelper.redirect(sUrl, true);
		},

		//to Onprem reporting
		getOnPremReporting: function (oEvent) {
			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var sysInfo = appConfigModel.getProperty("/SystemsInfo").SYSID.toLowerCase(),
				sHTTPS = appConfigModel.getProperty("/protocol"),
				url = appConfigModel.getProperty("/url"),
				sObjectId = this.sErpNumber;

			var onPremReportingUrl = appConfigModel.getProperty("/onPremReporting");
			var sUrl = sHTTPS + sysInfo + url + onPremReportingUrl + sObjectId;
			sap.m.URLHelper.redirect(sUrl, true);
		},
		//to SW ontract Toolbox Report
		getSWContractToolboxReport: function (oEvent) {
			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var sysInfo = appConfigModel.getProperty("/SystemsInfo").SYSID.toLowerCase(),
				sHTTPS = appConfigModel.getProperty("/protocol"),
				url = appConfigModel.getProperty("/url"),
				sObjectId = this.sErpNumber;

			var SWContractToolboxReportUrl = appConfigModel.getProperty("/SWContractToolboxReport");
			var sUrl = sHTTPS + sysInfo + url + SWContractToolboxReportUrl + sObjectId;
			sap.m.URLHelper.redirect(sUrl, true);
		},

		//Maintance Landscape
		getMaintenanceLandscape: function () {
			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
			var sysInfo = appConfigModel.getProperty("/SystemsInfo").SYSID.toLowerCase(),
				sHTTPS = appConfigModel.getProperty("/protocol"),
				url = appConfigModel.getProperty("/url"),
				sObjectId = this.sErpNumber;

			var maintenanceLandscape = appConfigModel.getProperty("/maintenanceLandscape");
			var sUrl = sHTTPS + sysInfo + url + maintenanceLandscape + sObjectId;
			sap.m.URLHelper.redirect(sUrl, true);
		},

		//open Attachment popup
		handleAttachmentPress: function (oEvent) {
			var that = this;
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDCD_SRV;v=0002/", true);
			// if (!this._oPopover) {
			this._oPopover = sap.ui.xmlfragment("c2r.c2rdcd.fragments.attachment", this);
			this.getView().addDependent(this._oPopover);
			// }
			var caseID = oEvent.getSource().getParent().getBindingContext().getObject().CASE_ID;
			var ocaseguid = oEvent.getSource().getParent().getBindingContext().getObject().CASEGUID;
			if (ocaseguid) {
				ocaseguid = ocaseguid.replace(/-/g, "");
				ocaseguid = ocaseguid.toUpperCase();
				oModel.read("/CmsDocumentsSet?$filter=CaseGuid eq '" + ocaseguid + "' and CaseId eq '" + caseID + "'", null, null, false,
					function (oDataCMS, oResponse) {
						var t = new sap.ui.model.json.JSONModel(oDataCMS);
						that.getView().setModel(t, "DCD");
					});
			}
			this._oPopover.openBy(oEvent.getSource());
		},
		handleAttachmentPressT4C: function (oEvent) {
			var that = this;
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDCD_SRV;v=0002/", true);

			this._oPopover = sap.ui.xmlfragment("c2r.c2rdcd.fragments.attachmentT4C", this);
			this.getView().addDependent(this._oPopover);

			var caseID = oEvent.getSource().getParent().getBindingContext().getObject().CASE_ID;
			var ocaseguid = oEvent.getSource().getParent().getBindingContext().getObject().CASEGUID;
			if (ocaseguid) {
				ocaseguid = ocaseguid.replace(/-/g, "");
				ocaseguid = ocaseguid.toUpperCase();
				oModel.read("/XReferenceSet?$filter=CASE_ID eq '" + caseID + "' ", null, null, false,
					function (oDataCMS, oResponse) {
						var t = new sap.ui.model.json.JSONModel(oDataCMS);
						that.getView().setModel(t, "DCD");
					});
			}
			this._oPopover.openBy(oEvent.getSource());

		},
		//ITSDEDLC-992 - Begin Code for links for Contract ID, Quote ID, Provider Contract and Sales Order
		onNGDetailsItemPress: function (oEvent) {
			var that = this;
			var objectID;
			var oResourceModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var case_id = that.getOwnerComponent().getModel("AppConfig").getProperty("/ContractID");
			if (oEvent.getSource().getTitle() === "Contract ID") {
				that.openCaseID(case_id);
				objectID = " ";
			} else if (oEvent.getSource().getTitle() === "Quote ID") {
				objectID = oEvent.getSource().getInfo();
			} else if (oEvent.getSource().getTitle() === "Provider Contract") {
				objectID = oEvent.getSource().getInfo();
			} else {
				objectID = oEvent.getSource().getInfo();
			}
			if (oEvent.getSource().getTitle() !== "Contract ID") {
				var oDataModel = that.getView().getModel();
				oDataModel.callFunction("/GetObjectLink", {
					method: "GET",
					urlParameters: {
						"CASE_ID": case_id,
						"OBJECT": objectID,
						"LINK": ""
					},
					success: jQuery.proxy(function (oData, response) {
						if (oData.results[0].LINK.length > 0) {
							sap.m.URLHelper.redirect(oData.results[0].LINK, true);
						} else {
							sap.m.MessageToast.show(oResourceModel.getText("noLink"), {
								duration: 5000,
								width: "40em"
							});
						}
					}, this),
					error: function (oError) {
						sap.m.MessageToast.show(oResourceModel.getText("errorText"), {
							duration: 5000,
							width: "40em"
						});
					}
				});
			}

			// //node data 
			// var oNobject = oEvent.getSource().getParent().getBindingContext().getObject();
			// //item data 
			// var oIobject = oEvent.getSource().getBindingContext().getObject();

			// var appConfigmodel = this.getOwnerComponent().getModel("AppConfig");
			// var sHTTPS = appConfigmodel.getProperty("/protocol");
			// var sSystemID = appConfigmodel.getProperty("/SystemsInfo").SYSID;
			// var sCrmSysID = appConfigmodel.getProperty("/SystemsInfo").CRMSYS;
			// var url = appConfigmodel.getProperty("/url");
			// var networkVBOrder = appConfigmodel.getProperty("/networkVBOrder");
			// var sUrl;

			// if (oIobject.key === "CONTRACT_ID") {
			// 	this.openCaseID(oNobject.DOC_ID);
			// } else if (oIobject.key === "QUOTE_ID") {
			// 	oNobject.QUOTE_ID = oEvent.getSource().getBindingContext().getObject().value;
			// 	this.openQuoteID(oNobject);
			// } else if (oIobject.key === "PROVIDER_CONTRACT") {
			// 	sUrl = oIobject.link_val;
			// 	sap.m.URLHelper.redirect(sUrl, true);
			// } else if (oIobject.key === "SALES_ORDER") {
			// 	sUrl = sHTTPS + sCrmSysID + url + networkVBOrder + oIobject.value;
			// 	sap.m.URLHelper.redirect(sUrl, true);
			// }
		},

		//ITSDEDLC-924 - Flow in the Contract Map
		//Open contract details window for NG graph
		//ITSDEDLC-2303 DCD Cockpit BUGs: Contract Map Navigation
		_popoutDetail: function (oNode, oButton , oEvent) {
			var caseId = oNode.getBindingContext("AppConfig").getObject().ATTRIBUTES[0].value;
			var revenuetype =  oNode.getBindingContext("AppConfig").getObject().REVENUETYPE;
	       var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
				var oResourceBundle = this.getResourceBundle();
			var oDataModel = this.getView().getModel();
			oDataModel.callFunction("/DCDCaseDetails", {
				method: "GET",
				urlParameters: {
					"CASE_ID": caseId,
					"CASE_GUID": "",
					"ERPNUMBER": "",
					"BPNUMBER": "",
				"REVENUETYPE": ""
				},
				success: jQuery.proxy(function (oData, response) {
					if (oData.results.length > 0) {
							this.getOwnerComponent().getRouter().navTo("overView", {
			caseId: caseId
				
			});
					}
				}, this),
				error: function (oError) {
					sap.m.MessageToast.show(oResourceBundle.getText("errorText"), {
						duration: 5000,
						width: "40em"
					});
				}
			});
			// var BPNumber,
			// 	Caseguid,
			// 	ERPNumber,
			// 	RevenueType;
			// var case_id = oNode.getBindingContext("AppConfig").getObject().ATTRIBUTES[0].value;
			// var quote_id = oNode.getBindingContext("AppConfig").getObject().ATTRIBUTES[1].value;
			// var oResourceBundle = this.getResourceBundle();
			// var oDataModel = this.getView().getModel();
			// oDataModel.callFunction("/DCDCaseDetails", {
			// 	method: "GET",
			// 	urlParameters: {
			// 		"CASE_ID": case_id,
			// 		"CASE_GUID": "",
			// 		"ERPNUMBER": "",
			// 		"BPNUMBER": "",
			// 		"REVENUETYPE": ""
			// 	},
			// 	success: jQuery.proxy(function (oData, response) {
			// 		if (oData.results.length > 0) {
			// 			BPNumber = oData.results[0].BPNUMBER;
			// 			ERPNumber = oData.results[0].ERPNUMBER;
			// 			Caseguid = oData.results[0].CASE_GUID;
			// 			RevenueType = oData.results[0].REVENUETYPE;
			// 			this.openOverviewDetails(BPNumber, ERPNumber, Caseguid, case_id, quote_id, RevenueType);
			// 		}
			// 	}, this),
			// 	error: function (oError) {
			// 		sap.m.MessageToast.show(oResourceBundle.getText("errorText"), {
			// 			duration: 5000,
			// 			width: "40em"
			// 		});
			// 	}
			// });
		},
		//ITSDEDLC-1658

		// _popoutDetails: function (oNode) {

		// 	var caseId = oNode.getBindingContext("AppConfig").getObject().ATTRIBUTES[0].value;
		// 	var appConfigModel = this.getOwnerComponent().getModel("AppConfig");

		// 	var popoutDetailsdev = appConfigModel.getProperty("/oPopAriflowdev");
		// 	var popoutDetailstest = appConfigModel.getProperty("/oPopAriflowtest");
		// 	var popoutDetailsPro = appConfigModel.getProperty("/oPopAriflow");

		// 	// var sUrl =  popoutDetails + caseId;
		// 	var eSystemID = appConfigModel.getProperty("/SystemsInfo").SYSID;
		// 	var flpUrl;
		// 	var sUrl;
		// 	if (eSystemID === "ISD") {
		// 		flpUrl = appConfigModel.getProperty("/oPopAriflowdev");
		// 		sUrl = popoutDetailsdev + caseId;
		// 	} else if (eSystemID === "IST") {

		// 		flpUrl = appConfigModel.getProperty("/oPopAriflowtest");
		// 		sUrl = popoutDetailstest + caseId;
		// 	} else if (eSystemID === "ISP") {
		// 		flpUrl = appConfigModel.getProperty("/oPopAriflow");
		// 		sUrl = popoutDetailsPro + caseId;
		// 	}

		// 	sap.m.URLHelper.redirect(sUrl, true);
		// },
				//ITSDEDLC-1658 Ariflow for Cloud

		_popoutDetails: function (oNode) {

			var caseId = oNode.getBindingContext("AppConfig").getObject().ATTRIBUTES[0].value;
			var appConfigModel = this.getOwnerComponent().getModel("AppConfig");

			var popoutDetailsdev = appConfigModel.getProperty("/oPopAriflowdev");
			var popoutDetailstest = appConfigModel.getProperty("/oPopAriflowtest");
			var popoutDetailsPro = appConfigModel.getProperty("/oPopAriflow");

			// var sUrl =  popoutDetails + caseId;
			var eSystemID = appConfigModel.getProperty("/SystemsInfo").SYSID;
			var flpUrl;
			var sUrl;
			var Revenue_Type = oNode.getBindingContext("AppConfig").getObject().REVENUETYPE;
			if (Revenue_Type !== "Cl") {
				sap.m.MessageBox.error("Link is not Available.");
			}
				else if (eSystemID === "ISD") {
				flpUrl = appConfigModel.getProperty("/oPopAriflowdev");
				sUrl = popoutDetailsdev + caseId;
				sap.m.URLHelper.redirect(sUrl, true);
			} else if (eSystemID === "IST") {

				flpUrl = appConfigModel.getProperty("/oPopAriflowtest");
				sUrl = popoutDetailstest + caseId;
				sap.m.URLHelper.redirect(sUrl, true);
			} else if (eSystemID === "ISP") {
				flpUrl = appConfigModel.getProperty("/oPopAriflow");
				sUrl = popoutDetailsPro + caseId;
				sap.m.URLHelper.redirect(sUrl, true);
			}
		},
		
			//ITSDEDLC-1671 ( Cl, Mi, On , Se Revenue type)
		
		_popoutDetailsservices:function (oNode) {
var quote_id = oNode.getBindingContext("AppConfig").getObject().ATTRIBUTES[1].value;
	var caseId = oNode.getBindingContext("AppConfig").getObject().ATTRIBUTES[0].value;

	var appConfigModel = this.getOwnerComponent().getModel("AppConfig");
	var popoutDetailsservices = appConfigModel.getProperty("/oPopAriflowServices");
	var sUrl;
var Revenue_Type = oNode.getBindingContext("AppConfig").getObject().REVENUETYPE;

if (Revenue_Type !== 'Se'){
	
	sap.m.MessageBox.error("Link is not Available.");

} else if (quote_id !== "") {
	 //sUrl =  popoutDetailsservices + quote_id;
	 	 sUrl =  popoutDetailsservices + caseId;

			sap.m.URLHelper.redirect(sUrl, true);
}else{
		
		sap.m.MessageBox.error("There is no Quote Id.");
			}
		},

		openOverviewDetails: function (oVal1, oVal2, oVal3, oVal4, oVal5, oVal6) {
			var bpNumber = (oVal1 * 1).toString();
			var erpNumber = (oVal2 * 1).toString();
			var caseGuid = oVal3;
			var caseId = oVal4;
			var quoteId = oVal5;
			var revenuetype = oVal6;
			var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNav.isIntentSupported(["c2rdcd-Display"])
				.done(function (aResponses) {

				})
				.fail(function () {
					MessageToast(oResourceBundle.getText("navigationErrorMsg"));
				});
			var hash = (oCrossAppNav && oCrossAppNav.hrefForExternal({
				target: {
					// shellHash: "c2rdcd-Display"
					shellHash: "c2rdcd-Display&/CaseOverView/" + bpNumber + "/" + erpNumber + "/" + caseId + "/" + caseGuid + "/" +
						quoteId + "/" + revenuetype
				}
			})) || "";
			//Generate a  URL for the second application
			var url = window.location.href.split('#')[0] + hash;

			//Navigate to thrid page of same app
			sap.m.URLHelper.redirect(url, true);

		},

		/**
		 * Adds a history entry in the FLP page history
		 * @public
		 * @param {object} oEntry An entry object to add to the hierachy array as expected from the ShellUIService.setHierarchy method
		 * @param {boolean} bReset If true resets the history before the new entry is added
		 */
		addHistoryEntry: (function () {
			var aHistoryEntries = [];

			return function (oEntry, bReset) {
				if (bReset) {
					aHistoryEntries = [];
				}

				var bInHistory = aHistoryEntries.some(function (entry) {
					return entry.intent === oEntry.intent;
				});

				if (!bInHistory) {
					aHistoryEntries.push(oEntry);
					this.getOwnerComponent().getService("ShellUIService").then(function (oService) {
						oService.setHierarchy(aHistoryEntries);
					});
				}
			};
		})()
	});
});