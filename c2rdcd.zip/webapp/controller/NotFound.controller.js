sap.ui.define([
		"c2r/c2rdcd/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("c2r.c2rdcd.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);