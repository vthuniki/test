/*global XLSX */
sap.ui.define([
	"c2r/c2rdcd/controller/BaseController",
	"sap/m/MessageBox",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/Label",
	"sap/m/Text",
	"sap/m/TextArea",
	"sap/ui/model/json/JSONModel",
	"sap/ui/export/Spreadsheet",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"c2r/c2rdcd/js/xlsx"
], function (BaseController, MessageBox, Button, Dialog, Label, Text, TextArea, JSONModel, Spreadsheet, MessageToast, Filter,
	FilterOperator) {
	"use strict";
	return BaseController.extend("c2r.c2rdcd.controller.Admin", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf c2r.c2rdcd.view.Admin
		 */
		onInit: function () {
			this.getRouter().getRoute("Admin").attachPatternMatched(this._onObjectMatched, this);
		},
		
		//Match Admin key
		_onObjectMatched: function (oEvent) {
			var ikey = oEvent.getParameter("arguments").key;
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			oModelAppConfig.setProperty("/adminKey", ikey);
			this.onDelete();
		},

		//Check File type
		handleTypeMissmatch: function (oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			jQuery.each(aFileTypes, function (key, value) {
				aFileTypes[key] = "*." + value;
			});
			var sSupportedFileTypes = aFileTypes.join(", ");
			MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
				" is not supported. Choose the following types: " +
				sSupportedFileTypes);
		},

		//Glossary admin
		getCols: function () {
			return [{
				label: "FIELDNAME",
				property: "FIELDNAME",
				type: "string"
			}, {
				label: "FIELDDEFINITION",
				property: "FIELDDEFINITION",
				type: "string"
			}, {
				label: "REVENUE_TYPE",
				property: "REVENUE_TYPE",
				type: "string"
			}];
		},

		//Download glossary
		onDownloadGlossary: function () {
			var that = this;
			var aCols = that.getCols();

			var oSettings = {
				workbook: {
					columns: aCols
				},
				dataSource: []
			};

			var oSheet = new Spreadsheet(oSettings);
			oSheet.build()
				.then(function () {
					MessageToast.show("Export has finished");
				})
				.finally(function () {
					oSheet.destroy();
				});
		},

		//Table data to xlsx.
		onChange: function (oEvent) {
			if (oEvent.getSource().getItems()[0]) {
				oEvent.getSource().removeItem(oEvent.getSource().getItems()[0]);
			}
			var that = this;
			var file = oEvent.getParameter("files")[0];
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			if (file && window.FileReader) {
				var reader = new FileReader();
				reader.onload = function (evn) {
					var data = evn.target.result; //string in CSV

					var workbook = XLSX.read(data, {
						type: "binary"
					});

					//Read all rows from First Sheet into an JSON array.
					if (workbook.Sheets[workbook.SheetNames[0]]) {
						var excelRows = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]]);

						var oCols = {
							"FIELDNAME": "",
							"FIELDDEFINITION": "",
							"REVENUE_TYPE": ""
						};

						if (excelRows.length > 0) {
							var bIsEmpty = false;
							for (var i = 0; i < excelRows.length; i++) {
								if (JSON.stringify(Object.keys(excelRows[i])) === JSON.stringify(Object.keys(oCols))) {
									var sRevenueType = excelRows[i].REVENUE_TYPE;
									var aRevenueType = [];
									if (sRevenueType !== "") {
										aRevenueType = sRevenueType.split(",");
									}
									for (var j = 0; j < aRevenueType.length; j++) {
										aRevenueType[j] = aRevenueType[j].trim();
									}
									var aAllowedRevenueType = ["Cloud","On-Premise", "Services"];
									
									for (var k = 0; k < aRevenueType.length; k++) {
										if (aAllowedRevenueType.indexOf(aRevenueType[k]) === -1){
											MessageBox.error("REVENUE TYPE can only have Cloud/On-Premise/Services");
											that.onDelete();
											return;
										}
									}
									bIsEmpty = true;
								}
							}
							if (bIsEmpty) {
								if (!that.oDialogNewGlossary) {
									that.oDialogNewGlossary = sap.ui.xmlfragment(that.getView().getId(), "c2r.c2rdcd.fragments.addNewGlossary", that);
									that.getView().addDependent(that.oDialogNewGlossary);
								}
								that.oDialogNewGlossary.open();
								oModelAppConfig.setProperty("/glossaryUpload", excelRows);

							} else {
								MessageBox.error(i18nModel.getText("excelUploadCloError"));
								that.onDelete();
							}
						} else {
							MessageBox.error(i18nModel.getText("excelUploadBlankError"));
							that.onDelete();
						}
					} else {
						MessageBox.error(i18nModel.getText("excelUploadFilterError"));
						that.onDelete();
					}
				};
			}
			reader.readAsBinaryString(file);
		},

		//Glossary upload
		onAddNewGlossaryCancel: function () {
			this.onDelete();
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			oModelAppConfig.setProperty("/glossaryUpload", []);
			this.oDialogNewGlossary.close();
		},

		//Glossary Adddition confirmation
		onAddNewGlossaryConfirm: function () {
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var aData = oModelAppConfig.getProperty("/glossaryUpload");
			for (var i = 0; i < aData.length; i++) {
				this.getOwnerComponent().getModel().createEntry("/DCDGlossarySet", {
					properties: {
						FIELDDEFINATION: aData[i].FIELDDEFINITION,
						FIELDNAME: aData[i].FIELDNAME,
						REVENUE_TYPE: aData[i].REVENUE_TYPE
					}
				});
			}
			this.getOwnerComponent().getModel().submitChanges({
				success: function () {
					MessageToast.show(i18nModel.getText("glossaryUpdateSuccessMsg"));
				},
				error: function (error) {
					MessageToast.show(i18nModel.getText("glossaryUpdateErrorMsg"));
				}
			});
			oModelAppConfig.setProperty("/glossaryUpload", []);
			this.oDialogNewGlossary.close();
		},

		//On Delete of Glossary
		onDelete: function (oEvent) {
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			oModelAppConfig.setProperty("/glossaryUpload", []);
			this.getView().byId("UploadCollection").removeAllItems();
		},

		//Glossary updation completion
		glossaryUpdateFinished: function (evt) {
			var total = evt.getParameter("total");
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			oModelAppConfig.setProperty("/glossaryUploadCount", total);

		},

		//add single item
		getaddNewSingleGlossary: function () {
			if (!this.oDialogNewSingleGlossary) {
				this.oDialogNewSingleGlossary = sap.ui.xmlfragment(this.getView().getId(), "c2r.c2rdcd.fragments.addNewSingleGlossary", this);
				this.getView().addDependent(this.oDialogNewSingleGlossary);
			}
		},

		//Add new glossary
		addNewSingleGlossary: function () {
			this.getOwnerComponent().getModel("AppConfig").setProperty("/glossaryUpdateMode", "Add");
			this.getaddNewSingleGlossary();

			this.addNewSingleGlossaryContext = this.getOwnerComponent().getModel().createEntry("/DCDGlossarySet", {
				properties: {
					FIELDDEFINATION: "",
					FIELDNAME: "",
					REVENUE_TYPE: ""
				}
			});

			this.oDialogNewSingleGlossary.setBindingContext(this.addNewSingleGlossaryContext);
			this.oDialogNewSingleGlossary.open();
		},

		//confirmation of addition of glossary
		onAddNewSingleGlossaryConfirm: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			this.getOwnerComponent().getModel().submitChanges({
				success: function () {
					var errorText=oModelAppConfig.getProperty("/errorText");
					if(errorText === ""){					
						MessageToast.show(i18nModel.getText("glossaryUpdateSuccessMsg"));
					}
					oModelAppConfig.setProperty("/errorText","");
				},
				error: function (error) {
					MessageToast.show(i18nModel.getText("glossaryUpdateErrorMsg"));
				}
			});
			this.oDialogNewSingleGlossary.close();
		},

		//cancelation of addition of glossary
		onAddNewSingleGlossaryCancel: function () {
			var sMode = this.getOwnerComponent().getModel("AppConfig").getProperty("/glossaryUpdateMode");
			if (sMode === "Add") {
				this.getOwnerComponent().getModel().deleteCreatedEntry(this.addNewSingleGlossaryContext);
			} else {
				this.getOwnerComponent().getModel().resetChanges();
			}
			this.oDialogNewSingleGlossary.close();
		},

		//selecting Revenue type from revenue type dropdown
		selectRevenueType: function (evt) {
			var sText = evt.getSource().getProperty("text");
			var sRevenueType = evt.getSource().getBindingContext().getObject().REVENUE_TYPE;
			var aRevenueType = [];
			if (sRevenueType !== "") {
				aRevenueType = sRevenueType.split(",");
			}
			for (var i = 0; i < aRevenueType.length; i++) {
				aRevenueType[i] = aRevenueType[i].trim();
			}

			if (evt.getParameter("selected")) {
				aRevenueType.push(sText);
			} else {
				for (var j = 0; j < aRevenueType.length; j++) {
					if (aRevenueType[j] === sText) {
						aRevenueType.splice(j, 1);
					}
				}
			}
			aRevenueType.sort();
			this.getView().byId("addEditRevenueType").setValue(aRevenueType.join(", "));
		},

		//edit item
		onGlossaryItemEditPress: function (evt) {
			this.getOwnerComponent().getModel("AppConfig").setProperty("/glossaryUpdateMode", "Edit");
			this.getaddNewSingleGlossary();
			this.oDialogNewSingleGlossary.setBindingContext(evt.getSource().getBindingContext());
			this.oDialogNewSingleGlossary.open();
		},

		//delete item
		onGlossaryItemDeletePress: function (evt) {
			var that = this;
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var sPath = evt.getSource().getBindingContext().sPath;
			var dialog = new Dialog({
				id: that.createId("deleteGlossary"),
				title: "Confirm",
				type: "Message",
				content: [
					new Text({
						text: "Do you want to delete - {FIELDNAME}?"
					})
				],
				beginButton: new Button({
					text: "Yes",
					press: function () {
						that.getOwnerComponent().getModel().remove(sPath, {
							success: function () {
								MessageToast.show(i18nModel.getText("glossaryDeleteSuccessMsg"));
							},
							error: function (error) {
								MessageToast.show(i18nModel.getText("glossaryDeleteErrorMsg"));
							}
						});
						that.getOwnerComponent().getModel().submitChanges();
						dialog.close();
					}
				}),
				endButton: new Button({
					text: "No",
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.setModel(this.getOwnerComponent().getModel());
			dialog.bindElement(evt.getSource().getBindingContext().sPath);

			dialog.open();
		},

		//search on field name
		filterGlossaryName: function (oEvent) {
			var sQuery = oEvent.getParameter("query") ? oEvent.getParameter("query") : oEvent.getParameter("newValue");
			var aFilters = [];

			if (sQuery) {
				var oFilter = new Filter("FIELDNAME", FilterOperator.Contains, sQuery);
				aFilters.push(oFilter);
			}

			this.getView().byId("glossaryUpdateTable").getBinding("items").filter(aFilters);
		},

		//disclaimer admin
		disclaimerUpdateFinished: function (evt) {
			var total = evt.getParameter("total");
			var oModelAppConfig = this.getOwnerComponent().getModel("AppConfig");
			oModelAppConfig.setProperty("/allDisclaimersCount", total);

		},

		//adding new disclaimer
		onAddNewDisclaimer: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var that = this;
			var dialog = new Dialog({
				title: "Add New Disclaimer",
				type: "Message",
				contentWidth: "40rem",
				content: [

					new TextArea("addNewDisclaimerTextarea", {
						liveChange: function (oEvent) {
							var sText = oEvent.getParameter("value");
							var parent = oEvent.getSource().getParent();
							parent.getBeginButton().setEnabled(sText.length > 0);
						},
						rows: 6,
						width: "100%",
						placeholder: "Add Disclaimer (required)"
					})
				],
				beginButton: new Button({
					text: "Submit",
					enabled: false,
					press: function () {
						var oData = {};
						oData.DISCLAIMER_TEXT = sap.ui.getCore().byId("addNewDisclaimerTextarea").getValue();
						that.getOwnerComponent().getModel().create("/DCDAdminDisclaimerSet", oData, {
							success: function () {
								MessageToast.show(i18nModel.getText("disclaimerCreateSuccessMsg"));
							},
							error: function (error) {
								MessageToast.show(i18nModel.getText("disclaimerCreateErrorMsg"));
							}
						});
						that.getOwnerComponent().getModel().submitChanges();
						dialog.close();
					}
				}),
				endButton: new Button({
					text: "Cancel",
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});

			dialog.open();
		},

		//activation of disclaimer
		onActivate: function (oEvent) {
			var that = this;
			var oObject = oEvent.getSource().getBindingContext().getObject();
			var sPath = oEvent.getSource().getBindingContext().sPath;
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			MessageBox.confirm(
				oObject.DISCLAIMER_TEXT, {
					title: i18nModel.getText("disclaimerActivationMsg"),
					onClose: function (sAction) {
						if (sAction === "OK") {
							var oData = {};
							oData.ACTIVE_DSCLMR = "X";
							oData.DISCLAIMER_KEY = oObject.DISCLAIMER_KEY;
							that.getOwnerComponent().getModel().update(sPath, oData, {
								success: function () {
									MessageToast.show(i18nModel.getText("disclaimerActiveSuccessMsg"));
								},
								error: function (error) {
									MessageToast.show(i18nModel.getText("disclaimerActiveErrorMsg"));
								}
							});
							that.getOwnerComponent().getModel().submitChanges();
						}
					}
				}
			);
		}
	});
});