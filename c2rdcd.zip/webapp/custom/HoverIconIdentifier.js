sap.ui.define([
	"sap/ui/core/Icon"
], function (Icon) {
	return Icon.extend("c2rdcd.custom.HoverIconIdentifier", {
		metadata: {
			events: {
				"hover": {},
				"out":{}
			}
		},
		onmouseover: function (evt) {
			this.fireHover();
		},
		onmouseout: function (evt) {
			this.fireOut();
		},
		renderer: {}
	});
});