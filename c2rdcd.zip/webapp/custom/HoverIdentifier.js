sap.ui.define([
	"sap/m/ObjectIdentifier"
], function (ObjectIdentifier) {
	return ObjectIdentifier.extend("c2rdcd.custom.HoverIdentifier", {
		metadata: {
			events: {
				"hover": {},
				"out":{}
			}
		},
		onmouseover: function (evt) {
			this.fireHover();
		},
		onmouseout: function (evt) {
			this.fireOut();
		},
		renderer: {}
	});
});