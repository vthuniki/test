 #### WELCOME ####

This is your copy of the SAPUI5 Worklist Freestyle Application Template.
You can find the template version in the .project.json - file in your workspace.

For a detailed version change log, take a look at this page:

==  https://jam4.sapjam.com/search/universal_search2?query=&sort=score&tag=sapui5_freestyle_application_templates  ==

Please report bugs using BCP to component CA-UI5-FST

This template will not be updated automatically! But we will provide fixes for hands-on adaption.

Template Documentation can be found in the Demo Kit here:
http://veui5infra.dhcp.wdf.sap.corp:8080/demokit/#docs/guide/a460a7348a6c431a8bd967ab9fb8d918.html


 #### Happy Development! ####