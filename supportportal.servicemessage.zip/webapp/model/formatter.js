sap.ui.define(["sap/ui/core/format/DateFormat"], function (DateFormat) {
	"use strict";
	return {
		PriorityColor: function (Rating) {
			switch (Rating) {
			case "A":
				return "Positive";
			case "B":
				return "Critical";
			case "C":
				return "Negative";
			default:
				return "Neutral";
			}
		},

		removeLeadingZero: function (CRM_Order) {
			if (CRM_Order !== null) {
				var formattedOrder = CRM_Order.replace(/\b(0+)/gi, "");
				return formattedOrder;
			}
		},

		setSubscribeIcon: function (hasSubscription) {
			if (hasSubscription === "X") {
				return "sap-icon://email";
			} else {
				return "";
			}
		},

		setAvaliableForSubscribe: function (isHostingPartner) {
			if (isHostingPartner === "X") {
				return true;
			} else {
				return false;
			}
		},

		setTableMode: function (isHostingPartner) {
			if (isHostingPartner === "X") {
				return "MultiSelect";
			} else {
				return "None";
			}
		},

		/*getQuestionText: function(sQn, sQna, autoService) {
			if (autoService === "X") {
				return sQna;
			} else {
				return sQn;
			}
		},*/

		emailValueStateCheck: function (str) {
			if (str) {
				var rexMail = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
				if (!str.match(rexMail)) {
					return "Error";
				} else {
					return "None";
				}
			}
		},

		determSubscribeButtonName: function (createSubscription, updateSubscription, hasSubscription) {
			if (hasSubscription === "X") {
				return updateSubscription;
			} else {
				return createSubscription;
			}
		},

		determSubscribeButtonStatus: function (currentUser, substitute, canSubscribe) {
			if (canSubscribe === "X") {
				if (currentUser.charAt(0) !== "S" && substitute !== "X") {
					return false;
				}
			} else {
				return false;
			}
		},

		setCancelButton: function (isSingle) {
			if (isSingle) {
				return true;
			} else {
				return false;
			}
		},

		setDeleteButton: function (has_subscription, isSingle) {
			if (has_subscription === "X" && isSingle) {
				return true;
			} else {
				return false;
			}
		},

		determButtonStatus: function (substitute) {
			if (substitute === "X") {
				return false;
			} else {
				return true;
			}
		},
		formatDateTime: function (sInitDate, tformat) {
			if (tformat == 0) {
				if (!sInitDate) return;
				var oDateFormat = DateFormat.getDateTimeInstance({
					pattern: 'dd/MM/YYYY HH:mm:ss'
				});
				var oDate = oDateFormat.parse(sInitDate);
				return oDateFormat.format(oDate);
			} else {
				if (!sInitDate) return;
				var oDateFormat = DateFormat.getDateTimeInstance({
					pattern: 'dd/MM/YYYY hh:mm:ss a'
				});
				var oDate = oDateFormat.parse(sInitDate);
				return oDateFormat.format(oDate);
			}
		},
	};
});