jQuery.sap.declare("sap.support.servicemessage.extended.MyServiceMsgFilterBar");
jQuery.sap.require("sap.ui.comp.filterbar.FilterBar");
jQuery.sap.require("sap.support.servicemessage.extended.MyServiceMsgSmartVariantManagement");
jQuery.sap.require("sap.ui.layout.GridRenderer");

sap.ui.comp.filterbar.FilterBar.extend("sap.support.servicemessage.extended.MyServiceMsgFilterBar", {

		metadata : {
			library : "sap.support.servicemessage.extended",
			properties : {
				showNotificationFB: { type: "boolean", defaultValue: true },
				notificationLabelFB: { type: "string", defaultValue: "Notification" },
				enableManageSaveAsButtonFB:{ type: "boolean", defaultValue: true }
			}
		},
		
	renderer: sap.ui.layout.GridRenderer.render,
	

	_initializeVariantManagement: function() {
		var oPersInfo = new sap.ui.comp.smartvariants.PersonalizableInfo({
			type: "filterBar",
			keyName: "persistencyKey"
		});
		//oPersInfo.addControl(this); -> does not work with UI5 1.46
		oPersInfo.setControl(this);

		this._oSmartVM.addPersonalizableControl(oPersInfo);
		sap.ui.comp.filterbar.FilterBar.prototype._initializeVariantManagement.apply(this, arguments);
	},

	_applyVariant: function(oVariant, sContext) {

		if (oVariant && oVariant.version === "V2") {
			oVariant = this.mergeVariant(this._getStandardVariant(), oVariant, sContext);
		}

		sap.ui.comp.filterbar.FilterBar.prototype._applyVariant.apply(this, arguments);
	},

	_createVariantManagement: function() {
		//var oFilterBar = this; 
		this._oSmartVM = new sap.support.servicemessage.extended.MyServiceMsgSmartVariantManagement({
			showExecuteOnSelection: false,
			showNotification:  this.getShowNotificationFB(),
			notificationLabel: this.getNotificationLabelFB(),
			enableManageSaveAsButton: this.getEnableManageSaveAsButtonFB(),
			showShare: false,
			initialise: [function() {
				var sVariantID = this.getCurrentVariantId();
				if (!sVariantID || sVariantID.length === 0) {
					this.fireStandardVariant();
				}
			}, this]
		});
		return this._oSmartVM;
	},

	init: function() {
		sap.ui.comp.filterbar.FilterBar.prototype.init.apply(this, arguments);

		this.setPersistencyKey("sap.support.servicemessage");
		this._initializeVariantManagement();
	},

	getCurrentVariantId: function() {
		return this._oSmartVM.getCurrentVariantId();
	},

	setCurrentVariantId: function(sVariantKey, bDoNotApplyVariant) {
		return this._oSmartVM.setCurrentVariantId(sVariantKey, bDoNotApplyVariant);
	}

});