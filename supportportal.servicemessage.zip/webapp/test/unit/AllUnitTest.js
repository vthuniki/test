sap.ui.define([
	"sap/support/servicemessage/test/unit/model/formatter",
	"sap/support/servicemessage/test/unit/page/Homepage.controller",
	"sap/support/servicemessage/test/unit/page/BaseController",
	"sap/support/servicemessage/test/unit/page/splitPage.controller",
	"sap/support/servicemessage/test/unit/page/Subscribe.controller"
], function() {
	"use strict";
});