sap.ui.require([
	"sap/support/servicemessage/controller/SplitPage.controller",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Component",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
],function(splitpage, Controller, JSONModel, Component){
	"use strict";
	
	QUnit.module("BaseCotroller",{
		beforeEach: function(){
			this.splitPage = new splitpage();
			this.deviceModel = new JSONModel();
			this.oComponent = new Component();
			this.oComponent.setModel(this.deviceModel, "device");
			sinon.stub(Controller.prototype, "getOwnerComponent").returns(this.oComponent);
			this.oView = new sap.ui.core.mvc.View({
				masterPages: [new sap.ui.core.mvc.View({id: "master"})],
				detailPages: [new sap.ui.core.mvc.View({id: "detail"})]
			});
			sinon.stub(this.splitPage, "getView").returns(this.oView);   
			
		},
		afterEach: function(){
			this.splitPage.destroy();
			this.oView.destroy();
			Controller.prototype.getOwnerComponent.restore();
		}
	});
	
	// QUnit.test("Should display general page when use this application in desktop", function(assert){
	// 	//Arrangement
		
	// 	/*var oApp = this.stub(this.oView, "getContent").returns([
			
	// 	]);*/
	// 	var oData = {};
	// 	oData.system = {};
	// 	oData.system.phone = false;
	// 	this.splitPage.getModel("device").setData(oData);
	// //	this.stub(oApp, "getDetailPages").returns([ ]);
	// //	this.stub(oApp, "to");
	// 	//Action
	// 	this.splitPage.getGeneralPage();
	// 	//Assert
	// 	assert.strictEqual(this.oView.getContent()[0].getDetailPages()[0].called, true);
	// });
});