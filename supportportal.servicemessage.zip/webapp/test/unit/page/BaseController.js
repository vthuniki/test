sap.ui.require([
	"sap/support/servicemessage/controller/BaseController",
	"sap/m/MessageToast",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(BaseController, MessageToast, ODataModel){
	"use strict";
	QUnit.module("BaseCotroller",{
		beforeEach: function(){
			this.baseContrl = new BaseController();
			this.oView = new sap.ui.core.mvc.View({});
			sinon.stub(this.baseContrl, "getView").returns(this.oView);
			this.oStubById = sinon.stub(this.oView, "byId");
		},
		afterEach: function(){
			this.baseContrl.destroy();
			this.oView.destroy();
		}
	});
	
	QUnit.test("Shoud see success information when set message to read", function(assert){
		//Arrangement
		this.baseContrl._globalPointer = "";
		this.stub(this.baseContrl, "_getRemoteRoot").returns("/local");
		this.stub(ODataModel.prototype, "create").yieldsTo("success");
		this.oStubById.withArgs("unRead").returns(new sap.m.Text({text: "Has been read"}));
		this.oStubById.withArgs("read").returns(new sap.m.Text({text: "Has been read"}));
		this.stub(this.baseContrl, "getResourceBundle").returns(new sap.m.Text({text: "Has been read"}));
		this.stub(MessageToast, "show");
		this.baseContrl.setToRead();
		assert.strictEqual(MessageToast.show.getCall(0).args[0], "Has been read");
	});
});