sap.ui.require([
	"sap/support/servicemessage/controller/Homepage.controller",
	"sap/ui/core/mvc/Controller",
	"sap/ui/base/Event",
	"sap/ui/core/Component",
	"sap/ui/core/routing/Router",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Homepage, Controller, Event, Component, Router, JSONModel, ODataModel, MessageBox, MessageToast, ResourceModel) {
	"use strict";

	QUnit.module("Homepage", {
		beforeEach: function() {
			this.homepage = new Homepage();
		},
		afterEach: function() {
			this.homepage.destroy();
		}
	});

	QUnit.test("Should return false when string length < 8", function(assert) {
		var sAct = this.homepage._soCheck.call(this.oController, "1");
		assert.equal(sAct, false);
	});

	QUnit.test("Should return false when string length > 8", function(assert) {
		var sAct = this.homepage._soCheck.call(this.oController, "123456789");
		assert.equal(sAct, false);
	});

	QUnit.test("Should return false when string is '12345678' instead began with '73' or '75'", function(assert) {
		var sAct = this.homepage._soCheck.call(this.oController, "12345678");
		assert.equal(sAct, false);
	});

	QUnit.test("Should return false when string is '73abcdef' ", function(assert) {
		var sAct = this.homepage._soCheck.call(this.oController, "73abcdef");
		assert.equal(sAct, false);
	});

	QUnit.test("Should return true when string is '73123456' ", function(assert) {
		var sAct = this.homepage._soCheck.call(this.oController, "73123456");
		assert.equal(sAct, true);
	});

	QUnit.test("Should return true when string is '75123456' ", function(assert) {
		var sAct = this.homepage._soCheck.call(this.oController, "75123456");
		assert.equal(sAct, true);
	});

	QUnit.test("Should return true when string is '' ", function(assert) {
		var sAct = this.homepage._soCheck.call(this.oController, "");
		assert.equal(sAct, true);
	});

	QUnit.test("Should return 20160706 when date is 06.07.2016", function(assert) {
		var sAct = this.homepage._timeRefactor.call(this.oController, "06.07.2016");
		assert.equal(sAct, "20160706");
	});

	QUnit.test("Should return 20160617 when date is 17.06.2016", function(assert) {
		var sAct = this.homepage._timeRefactor.call(this.oController, "17.06.2016");
		assert.equal(sAct, "20160617");
	});

	QUnit.test("Should return 20161011 when string is '10/11/16' ", function(assert) {
		var sAct = this.homepage._timeRefactor.call(this.oController, "10/11/16");
		assert.equal(sAct, "20161011");
	});

	QUnit.test("Should return 20161001 when string is '10/1/16' ", function(assert) {
		var sAct = this.homepage._timeRefactor.call(this.oController, "10/1/16");
		assert.equal(sAct, "20161001");
	});

	QUnit.test("Should return S0001002864 when processorKey is 'S0001002864'", function(assert) {
		var sAct = this.homepage.getProcessorKey.call(this.oController, "S0001002864");
		assert.equal(sAct, "S0001002864");
	});

	QUnit.test("Should return S0001002864 when string is 'Ammer,Hans (S0001002864)' ", function(assert) {
		var sAct = this.homepage.getProcessorKey.call(this.oController, "Ammer,Hans (S0001002864)");
		assert.equal(sAct, "S0001002864");
	});
	QUnit.test("Should return false when string length < 3", function(assert) {
		var sAct = this.homepage._siCheck.call(this.oController, "a");
		assert.equal(sAct, false);
	});

	QUnit.test("Should return false when string length > 3", function(assert) {
		var sAct = this.homepage._siCheck.call(this.oController, "abcd");
		assert.equal(sAct, false);
	});

	QUnit.test("Should return false when string is '1aa'", function(assert) {
		var sAct = this.homepage._siCheck.call(this.oController, "1aa");
		assert.equal(sAct, false);
	});
	QUnit.test("Should return true when string is 'aaa'", function(assert) {
		var sAct = this.homepage._siCheck.call(this.oController, "aaa");
		assert.equal(sAct, true);
	});
	QUnit.test("Should return true when string is '' ", function(assert) {
		var sAct = this.homepage._siCheck.call(this.oController, "");
		assert.equal(sAct, true);
	});

	//   New
	QUnit.module("homePage - SMWEA URL for search", {
		beforeEach: function() {
			this.homepage = new Homepage();
			this.oComponent = new Component();
			this.oURLModel = new JSONModel();
			this.oComponent.setModel(this.oURLModel);
			sinon.stub(Controller.prototype, "getOwnerComponent").returns(this.oComponent);
			this.oView = new sap.ui.core.mvc.View({});
			sinon.stub(this.homepage, "getView").returns(this.oView);
			sinon.stub(this.oView, "setBusy");
			sinon.stub(this.homepage, "_getRemoteRoot").returns('/loacal');
		},
		afterEach: function() {
			this.homepage.destroy();
			Controller.prototype.getOwnerComponent.restore();
		}
	});

	QUnit.test("Should hidden search filter bar when use URL for search and display detail message toast", function(assert) {
		//Arrangement 
		var oEvent = new Event(null, null, {
			name: "EWAhomepagewithSysNo",
			arguments: {
				Customer: "202420",
				Installation: "20256312",
				SystemID: "EFP",
				SystemNo: "310128696",
				ServiceType: "SMEWA"
			}
		});
		/*var oData = {};
		oData.results = [{
			Action_User_Name: "S0002346931"
		}, {
			Action_User_Name: "S0002346931"
		}];*/
		//this.stub(ODataModel.prototype, "read").yieldsTo("success", oData);

		this.stub(this.homepage, "getResourceBundle").returns(new sap.m.Text({
			text: "Search EWA completed"
		}));
		this.stub(MessageToast, "show");
		this.homepage._onRoutePatternMatched(oEvent);
		//Assert
		assert.equal(this.homepage.getModel("URLModel").getData().Visible, false);
		//assert.equal(MessageToast.show.getCall(0).args[0], "Search EWA completed");

	});
	QUnit.test("Should return completed information without service message", function(assert) {
		//Arrangement 
		this.stub(this.homepage, "getResourceBundle").returns(new sap.m.Text({
			text: "Search completed"
		}));
		//Assert
		assert.equal(this.homepage.getMessageToastContent(), "Search completed");
		//assert.equal(this.homepage.getMessageToastContent("ss"), "Search completed");

	});
	QUnit.test("Should see search filter bar when URL withou search parameters", function(assert) {
		//Arrangement 
		var oEvent = new Event(null, null, {
			name: "homepage"
		});
		this.homepage._onRoutePatternMatched(oEvent);
		//Assert
		assert.equal(this.homepage.getModel("URLModel").getData().Visible, true);

	});

	QUnit.test("Should return false and see error message when customer number is empty", function(assert) {
		//Arrangement 
		this.stub(this.homepage, "getResourceBundle").returns(new sap.m.Text({
			text: "Please enter a customer number."
		}));
		this.stub(MessageBox, "error");
		//Assert
		assert.equal(this.homepage.checkCustomerNum(""), false);
		assert.strictEqual(MessageBox.error.getCall(0).args[0], "Please enter a customer number.");
	});

	QUnit.test("Should return true when customer number isn't empty under internal user", function(assert) {
		//Arrangement 
		this.stub(this.homepage, "getResourceBundle").returns(new sap.m.Text({
			text: "Please enter a customer number."
		}));
		this.stub(this.homepage, "getUserType").returns("I");
		//Assert
		assert.equal(this.homepage.checkCustomerNum("202418"), true);
	});

	QUnit.test("Should see error message when customer number is invalid under S-User", function(assert) {
		//Arrangement
		this.stub(this.homepage, "getResourceBundle").returns(new sap.m.Text({
			text: "Please enter a valid customer number."
		}));
		this.stub(this.homepage, "getUserType").returns("S");
		this.stub(JSONModel.prototype, "loadData");
		this.stub(this.homepage, "getCustomerList").returns(["202418", "202419"]);
		this.stub(MessageBox, "error");
		//Action
		this.homepage.checkCustomerNum("202411");
		//Assert
		assert.equal(MessageBox.error.getCall(0).args[0], "Please enter a valid customer number.");
	});
	QUnit.test("Should see error message when customer number is empty under S-User", function(assert) {
		//Arrangement 
		this.stub(this.homepage, "getResourceBundle").returns(new sap.m.Text({
			text: "Please enter a valid customer number."
		}));
		this.stub(this.homepage, "getUserType").returns("S");
		this.stub(JSONModel.prototype, "loadData");
		this.stub(this.homepage, "getCustomerList").returns([]);
		this.stub(MessageBox, "error");
		//Action
		this.homepage.checkCustomerNum("202418");
		//Assert
		assert.equal(MessageBox.error.getCall(0).args[0], "Please enter a valid customer number.");
	});

	QUnit.test("Should return true when customer number is valid under S-User", function(assert) {
		//Arrangement 
		this.stub(this.homepage, "getResourceBundle").returns(new sap.m.Text({
			text: "Please enter a valid customer number."
		}));
		this.stub(this.homepage, "getUserType").returns("S");
		this.stub(JSONModel.prototype, "loadData");
		this.stub(this.homepage, "getCustomerList").returns(["202418", "202419"]);
		//Assert
		assert.equal(this.homepage.checkCustomerNum("202418"), true);
	});

	QUnit.test("Should return array for customer model", function(assert) {
		//Arrangement 
		var oData = {};
		oData.d = {};
		oData.d.results = [{
			CustomerNo: "202418"
		}, {
			CustomerNo: "202419"
		}];
		var oCustomerModel = new JSONModel(oData);
		//Assert
		assert.deepEqual(this.homepage.getCustomerList(oCustomerModel), ["202418", "202419"]);
	});

	QUnit.test("Should return true when installation is empty", function(assert) {
		//Assert
		assert.equal(this.homepage.checkInstallation(), true);
	});

	QUnit.test("Should return true when current user is internal user", function(assert) {
		//Arrangement
		this.stub(this.homepage, "getUserType").returns("I");
		//Assert
		assert.equal(this.homepage.checkInstallation("0020256312"), true);
	});

	QUnit.test("Should see error message when installation is invalid under S-User", function(assert) {
		//Arrangement
		this.stub(this.homepage, "getResourceBundle").returns(new sap.m.Text({
			text: "Please enter a valid installation number."
		}));
		this.stub(this.homepage, "getUserType").returns("S");
		this.stub(JSONModel.prototype, "loadData");
		this.stub(this.homepage, "getInstallationList").returns(["0020256311", "0020256312"]);
		this.stub(MessageBox, "error");
		//Action
		this.homepage.checkInstallation("0020256310");
		//Assert
		assert.equal(MessageBox.error.getCall(0).args[0], "Please enter a valid installation number.");
	});

	QUnit.test("Should see error message when installation number is empty under S-User", function(assert) {
		//Arrangement 
		this.stub(this.homepage, "getResourceBundle").returns(new sap.m.Text({
			text: "Please enter a valid installation number."
		}));
		this.stub(this.homepage, "getUserType").returns("S");
		this.stub(JSONModel.prototype, "loadData");
		this.stub(this.homepage, "getInstallationList").returns([]);
		this.stub(MessageBox, "error");
		//Action
		this.homepage.checkInstallation("0020256310");
		//Assert
		assert.equal(MessageBox.error.getCall(0).args[0], "Please enter a valid installation number.");
	});

	QUnit.test("Should return true when installation number is valid under S-User", function(assert) {
		//Arrangement 
		this.stub(this.homepage, "getResourceBundle").returns(new sap.m.Text({
			text: "Please enter a valid customer number."
		}));
		this.stub(this.homepage, "getUserType").returns("S");
		this.stub(JSONModel.prototype, "loadData");
		this.stub(this.homepage, "getInstallationList").returns(["0020256311", "0020256312"]);

		//Assert
		assert.equal(this.homepage.checkInstallation("0020256311"), true);
	});
	QUnit.test("Should return array for installation model", function(assert) {
		//Arrangement 
		var oData = {};
		oData.d = {};
		oData.d.results = [{
			InstallationNo: "0020256311"
		}, {
			InstallationNo: "0020256312"
		}];
		var oIntallationModel = new JSONModel(oData);
		//Assert
		assert.deepEqual(this.homepage.getInstallationList(oIntallationModel), ["0020256311", "0020256312"]);
	});

	QUnit.module("homePage - Mandatery search criteria", {
		beforeEach: function() {
			this.homepage = new Homepage();
			this.oComponent = new Component();
			this.i18nModel = new JSONModel();
			this.oComponent.setModel(this.i18nModel, "i18n");
			sinon.stub(Controller.prototype, "getOwnerComponent").returns(this.oComponent);
		},
		afterEach: function() {
			this.homepage.destroy();
			Controller.prototype.getOwnerComponent.restore();
		}
	});

	QUnit.test("Should see messagebox when 'Customer' 'Installation' and 'Service Order ID' are empty in internal version", function(assert) {
		//Arrangement
		var userType = "I";
		var customer = [];
		var installation = [];
		var serviceOrder = [];
		this.stub(this.homepage, "getResourceBundle").returns(new sap.m.Text({
			text: "Please enter customer number or installation number."
		}));
		this.stub(MessageBox, "error");
		//Action
		this.homepage._checkMandatorySearchCriteria(userType, customer, installation, serviceOrder);
		//Assert
		assert.strictEqual(MessageBox.error.getCall(0).args[0], "Please enter customer number or installation number.");
	});

	QUnit.test("Should see messagebox when 'Customer'is empty in S-User version", function(assert) {
		//Arrangement
		var userType = "S";
		var customer = [];
		var installation = [];
		var serviceOrder = [];
		this.stub(this.homepage, "getResourceBundle").returns(new sap.m.Text({
			text: "Please enter customer number."
		}));
		this.stub(MessageBox, "error");
		//Action
		this.homepage._checkMandatorySearchCriteria(userType, customer, installation, serviceOrder);
		//Assert
		assert.strictEqual(MessageBox.error.getCall(0).args[0], "Please enter customer number.");
	});

	QUnit.module("homePage - Search results download", {
		beforeEach: function() {
			this.homepage = new Homepage();
			sinon.stub(this.homepage, "_getRemoteRoot").returns("/loacal");
		},
		afterEach: function() {
			this.homepage.destroy();
		}
	});

	function prepareFilterPara() {
		this.homepage.Filter = [];
		var val0 = new Array();
		val0.oValue1 = "202418";
		val0.sOperator = "EQ";
		val0.sPath = "Customer";
		this.homepage.Filter.push(val0);
		var val01 = new Array();
		val01.oValue1 = "202419";
		val01.sOperator = "EQ";
		val01.sPath = "Customer";
		this.homepage.Filter.push(val01);
		/*var val1 = new Array();
		val1.oValue1 = "20256434";
		val1.sOperator = "EQ";
		val1.sPath = "Installtion";
		this.homepage.Filter.push(val1);*/
		var val2 = new Array();
		val2.oValue1 = "S0000315119";
		val2.sOperator = "EQ";
		val2.sPath = "Aktion_User";
		this.homepage.Filter.push(val2);
		var val3 = new Array();
		val3.oValue1 = "20170103";
		val3.oValue2 = "20180104";
		val3.sOperator = "BT";
		val3.sPath = "Last_Sess_Dat";
		this.homepage.Filter.push(val3);
	}
	QUnit.test("Should download after press 'download' icon", function(assert) {
		var oOpenPageStub = sinon.stub(window, "open");
		prepareFilterPara.call(this);
		this.homepage.onDownload();
		assert.strictEqual(oOpenPageStub.called, true, "downloaded as expected");
		oOpenPageStub.restore();
	});

	QUnit.module("homePage - Go to Search", {
		beforeEach: function() {
			this.homepage = new Homepage();
			this.oView = new sap.ui.core.mvc.View({});
			sinon.stub(this.homepage, "getView").returns(this.oView);
		},
		afterEach: function() {
			this.homepage.destroy();
		}
	});

	function internalUserLogonWithPa() {
		var oStubById = this.stub(this.oView, "byId");
		oStubById.withArgs("A0").returns(new sap.ui.comp.filterbar.FilterItem({
			visible: false
		}));
		oStubById.withArgs("A1").returns(new sap.ui.comp.filterbar.FilterItem({
			visible: true
		}));
		oStubById.withArgs("B0").returns(new sap.ui.comp.filterbar.FilterItem({
			visible: false
		}));
		oStubById.withArgs("B1").returns(new sap.ui.comp.filterbar.FilterItem({
			visible: true
		}));
		oStubById.withArgs("customer_no_0").returns(new sap.m.Input({
			value: "202418"
		}));
		oStubById.withArgs("installation_0").returns(new sap.m.Input({
			value: "20256434"
		}));
		oStubById.withArgs("serviceOrder").returns(new sap.m.MultiInput({}));
		oStubById.withArgs("processor").returns(new sap.m.MultiInput({}));
		oStubById.withArgs("serviceType").returns(new sap.m.MultiComboBox({}));
		oStubById.withArgs("status").returns(new sap.m.MultiComboBox({}));
		oStubById.withArgs("DTI_from").returns(new sap.m.DatePicker({}));
		oStubById.withArgs("DTI_to").returns(new sap.m.DatePicker({}));
		oStubById.withArgs("systemId").returns(new sap.m.MultiInput({}));
	}
	/*QUnit.test("Should get search when internal user press 'Go' button ", function(assert) {
		this.stub(this.homepage, "getUserType");
		this.stub(this.homepage, "_checkMandatorySearchCriteria").returns(true);
		this.stub(this.homepage, "getSearchResult");
		internalUserLogonWithPa.call(this);
		this.homepage.onSearch();
		assert.equal(this.homepage.getSearchResult.calledOnce, true);
	});*/

	function internalUserLogonWithoutPa() {
		var oStubById = this.stub(this.oView, "byId");
		oStubById.withArgs("A0").returns(new sap.ui.comp.filterbar.FilterItem({
			visible: false
		}));
		oStubById.withArgs("A1").returns(new sap.ui.comp.filterbar.FilterItem({
			visible: true
		}));
		oStubById.withArgs("B0").returns(new sap.ui.comp.filterbar.FilterItem({
			visible: false
		}));
		oStubById.withArgs("B1").returns(new sap.ui.comp.filterbar.FilterItem({
			visible: true
		}));
		oStubById.withArgs("customer_no_0").returns(new sap.m.Input({}));
		oStubById.withArgs("installation_0").returns(new sap.m.Input({}));
		oStubById.withArgs("serviceOrder").returns(new sap.m.MultiInput({}));
		oStubById.withArgs("processor").returns(new sap.m.MultiInput({}));
		oStubById.withArgs("serviceType").returns(new sap.m.MultiComboBox({}));
		oStubById.withArgs("status").returns(new sap.m.MultiComboBox({}));
		oStubById.withArgs("DTI_from").returns(new sap.m.DatePicker({}));
		oStubById.withArgs("DTI_to").returns(new sap.m.DatePicker({}));
		oStubById.withArgs("systemId").returns(new sap.m.MultiInput({}));
	}
	/*QUnit.test("Should not get search when internal user press 'Go' button", function(assert) {
		this.stub(this.homepage, "getUserType");
		this.stub(this.homepage, "_checkMandatorySearchCriteria").returns(false);
		this.stub(this.homepage, "getSearchResult");
		internalUserLogonWithoutPa.call(this);
		this.homepage.onSearch();
		assert.equal(this.homepage.getSearchResult.calledOnce, false);
	});*/

	function sUserLogonWithoutPa() {
		var oStubById = this.stub(this.oView, "byId");
		oStubById.withArgs("A0").returns(new sap.ui.comp.filterbar.FilterItem({
			visible: true
		}));
		oStubById.withArgs("A1").returns(new sap.ui.comp.filterbar.FilterItem({
			visible: false
		}));
		oStubById.withArgs("B0").returns(new sap.ui.comp.filterbar.FilterItem({
			visible: true
		}));
		oStubById.withArgs("B1").returns(new sap.ui.comp.filterbar.FilterItem({
			visible: false
		}));
		oStubById.withArgs("customer_no").returns(new sap.m.MultiComboBox({
			selectedKeys: ["202418", "202419"]
		}));
		oStubById.withArgs("installation").returns(new sap.m.MultiComboBox({
			selectedKeys: ["20256434"]
		}));
		oStubById.withArgs("serviceOrder").returns(new sap.m.MultiInput({
			tokens: {
				key: "73373748",
				selected: true
			}
		}));
		oStubById.withArgs("processor").returns(new sap.m.MultiInput({
			tokens: {
				key: "S0000315119",
				selected: true
			}
		}));
		oStubById.withArgs("serviceType").returns(new sap.m.MultiComboBox({
			selectedKeys: ["SMEWA"]
		}));
		oStubById.withArgs("status").returns(new sap.m.MultiComboBox({
			selectedKeys: ["1"]
		}));
		oStubById.withArgs("DTI_from").returns(new sap.m.DatePicker({
			value: "2017.02.01"
		}));
		oStubById.withArgs("DTI_to").returns(new sap.m.DatePicker({
			value: "2018.01.01"
		}));
		oStubById.withArgs("systemId").returns(new sap.m.MultiInput({
			tokens: {
				key: "EFP",
				selected: true
			}
		}));
	}
	/*QUnit.test("Should get search when S-User press 'Go' button ", function(assert) {
		this.stub(this.homepage, "getUserType");
		this.stub(this.homepage, "_checkMandatorySearchCriteria").returns(true);
		this.stub(this.homepage, "getProcessorKey").returns("S0000315119");
		this.stub(this.homepage, "getSearchResult");
		sUserLogonWithoutPa.call(this);
		this.homepage.onSearch();
		assert.equal(this.homepage.getSearchResult.calledOnce, true);
	});*/

	// QUnit.module("Homepage - Set up auto-forwarding", {
	// 	beforeEach: function() {
	// 		this.homepage = new Homepage();
	// 		this.oComponent = new Component();
	// 		var oModelI18n = new ResourceModel({
	// 			bundleName: "sap.support.servicemessage.i18n.message_bundle",
	// 			bundleLocale: "EN"
	// 		});
	// 		this.oComponent.setModel(oModelI18n, "i18n");
	// 		sinon.stub(Controller.prototype, "getOwnerComponent").returns(this.oComponent);
	// 		/*this.oModel_userdata = new JSONModel();
	// 		this.oComponent.setModel(this.oModel_userdata, "Model_userdata");
			
	// 		this.viewStub = new sap.ui.core.mvc.View({});
	// 		sinon.stub(this.report, "getView").returns(this.viewStub);
	// 		this.controlStub = new sinon.stub(this.viewStub, "byId");*/
	// 		/*this.table = new ExTable({
	// 		    mode:"MultiSelect",          
	// 		    items:[new ExColumnListItem({accelerateFlag:true}),
	// 		            new ExColumnListItem({accelerateFlag:false})]
	// 		});*/
	// 		/*	var table=new sap.m.Table({mode:sap.m.ListMode.MultiSelect});
	// 			this.controlStub.withArgs("report").returns(new sap.m.Table());*/

	// 	},
	// 	afterEach: function() {
	// 		this.homepage.destroy();
	// 		Controller.prototype.getOwnerComponent.restore();
	// 	}
	// });

	// QUnit.test("Should display warning message when user doesn't select any message and click 'Set up auto-forwarding' button", function(
	// 	assert) {
	// 	this.homepage.sPointers = "";
	// 	this.stub(MessageBox, "warning");
	// 	//Action
	// 	this.homepage.onNavToSetUpAutoForwarding();
	// 	//Assert
	// 	assert.equal(MessageBox.warning.getCall(0).args[0], "To set up auto-forwarding, first select at least one SAP EarlyWatch Alert message from the list.");
	// });

	// QUnit.test("Should display warning message when user select Non-EWA message and click 'Set up auto-forwarding' button", function(assert) {
	// 	this.homepage.sPointers = "123";
	// 	this.homepage.NonEWA = true;
	// 	this.stub(MessageBox, "warning");
	// 	//Action
	// 	this.homepage.onNavToSetUpAutoForwarding();
	// 	//Assert
	// 	assert.equal(MessageBox.warning.getCall(0).args[0], "Currently, only SAP EarlyWatch Alert messages can be automatically forwarded.");
	// });

	// QUnit.test(
	// 	"Should display message when user select EWA message which already has auto-forwarding and click 'Set up auto-forwarding' button",
	// 	function(assert) {
	// 		this.homepage.sPointers = "123";
	// 		this.homepage.NonEWA = false;
	// 		this.homepage.hasSubscription = true;
	// 		this.stub(MessageBox, "show");
	// 		//Action
	// 		this.homepage.onNavToSetUpAutoForwarding();
	// 		//Assert
	// 		assert.equal(MessageBox.show.getCall(0).args[0],
	// 			"Auto-forwarding rules already exist for one of the selected SAP EarlyWatch Alert services. Do you want to replace them?");
	// 	});

	// QUnit.test(
	// 	"Should navigate to 'Auto-forwarding' page when user select EWA message which already has auto-forwarding and click 'Yes' button on MessageBox",
	// 	function(assert) {
	// 		this.homepage.sPointers = "123";
	// 		this.homepage.NonEWA = false;
	// 		this.homepage.hasSubscription = true;
	// 		this.stub(MessageBox, "show");
	// 		//Action
	// 		this.homepage.onNavToSetUpAutoForwarding();
	// 		//Assert
	// 		assert.equal(MessageBox.show.getCall(0).args[0],
	// 			"Auto-forwarding rules already exist for one of the selected SAP EarlyWatch Alert services. Do you want to replace them?");
	// 	});
	
});