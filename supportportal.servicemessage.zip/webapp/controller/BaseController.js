/*global history */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/comp/valuehelpdialog/ValueHelpDialog",
	"sap/ui/core/routing/History",
	'sap/m/MessageToast'
], function (Controller, JSONModel, ODataModel, ValueHelpDialog, History, MessageToast) {
	"use strict";

	return Controller.extend("sap.support.servicemessage.controller.BaseController", {
		_globalPointer: "",
		_NewProcessor: "",
		_NewProcessorName: "",

		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		getServiceMessageModel: function (oEvent) {
			var Pointer = oEvent.getParameter("arguments").Pointer;
			this.getOwnerComponent().getModel("ServiceMessageModel").loadData(this._getRemoteRoot() +
				"ServiceMessageSet('" + Pointer + "')", {}, false, "GET");
		},

		_initFavorite: function (Pointer, id_favorite, id_unfavorite, id_headerTitle) {
			var that = this;
			var _oUserProfilModel = new sap.ui.model.odata.v2.ODataModel({
				json: true,
				serviceUrl: "/services/odata/svt/user_profile_srv"
			});
			_oUserProfilModel.read("/Entries", {
				Pointer: Pointer,
				filters: [
					new sap.ui.model.Filter("Username", sap.ui.model.FilterOperator.EQ, this.getUser()), //this.getUser()
					new sap.ui.model.Filter("Attribute", sap.ui.model.FilterOperator.EQ, "FAVORITE_SERVICE_MESSAGES")
				],
				success: function (oData) {
					var oModel = oData.results;
					var favoritePointArray = [];
					var flag;
					for (var i = 0; i < oModel.length; i++) {
						favoritePointArray.push(oModel[i].Value);
						if (Pointer === oModel[i].Value) {
							that.getView().byId(id_favorite).setVisible(true);
							that.getView().byId(id_unfavorite).setVisible(false);
							that.getView().byId(id_headerTitle).setMarkFavorite(true);
							flag = "true";
						}
					}
					if (flag !== "true") {
						that.getView().byId(id_favorite).setVisible(false);
						that.getView().byId(id_unfavorite).setVisible(true);
						that.getView().byId(id_headerTitle).setMarkFavorite(false);
					}
				},
				error: function () {}
			});
			// set favorite Disable when substitute
			var substitute = this.getSubstitute();
			if (substitute === "X") {
				this.getView().byId("unfavorite").setEnabled(false);
				this.getView().byId("favorite").setEnabled(false);
			}
		},

		_addFavorite: function (id_favorite, id_unfavorite, id_headerTitle) {
			var that = this;
			var _oUserProfilModel = new sap.ui.model.odata.v2.ODataModel({
				json: true,
				serviceUrl: "/services/odata/svt/user_profile_srv"
			});

			var oData = {};
			oData.Attribute = "FAVORITE_SERVICE_MESSAGES";
			oData.Value = this._globalPointer;
			_oUserProfilModel.create("/Entries", oData, {
				success: function () {
					that.getView().byId(id_favorite).setVisible(true);
					that.getView().byId(id_unfavorite).setVisible(false);
					that.getView().byId(id_headerTitle).setMarkFavorite(true);
					var i18nModel = that.geti18nModel();
					var favorite_success = i18nModel.getResourceBundle().getText("favorite_success");
					MessageToast.show(favorite_success);
				},
				error: function () {

				}
			});

		},

		_removeFavorite: function (id_favorite, id_unfavorite, id_headerTitle) {
			var that = this;
			var _oUserProfilModel = new sap.ui.model.odata.v2.ODataModel({
				json: true,
				serviceUrl: "/services/odata/svt/user_profile_srv"
			});
			_oUserProfilModel.read("/Entries", {
				Pointer: that._globalPointer,
				filters: [
					new sap.ui.model.Filter("Username", sap.ui.model.FilterOperator.EQ, this.getUser()), //this.getUser()
					new sap.ui.model.Filter("Attribute", sap.ui.model.FilterOperator.EQ, "FAVORITE_SERVICE_MESSAGES")
				],
				success: function (oData) {
					var oModel = oData.results;
					var favoritePointArray = [];
					for (var i = 0; i < oModel.length; i++) {
						favoritePointArray.push(oModel[i].Value);
						if (that._globalPointer === oModel[i].Value) {
							_oUserProfilModel.remove("/Entries(Username='',Attribute='FAVORITE_SERVICE_MESSAGES',Field='" + oModel[i].Field + "')", {
								success: function () {
									that.getView().byId(id_favorite).setVisible(false);
									that.getView().byId(id_unfavorite).setVisible(true);
									that.getView().byId(id_headerTitle).setMarkFavorite(false);
									var i18nModel = that.geti18nModel();
									var unfavorite_success = i18nModel.getResourceBundle().getText("unfavorite_success");
									MessageToast.show(unfavorite_success);
								},
								error: function () {

								}
							});
						}
					}
				},
				error: function () {

				}
			});
		},
		_getRemoteRoot: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			var root = oComp.sConfig.requestRemote;
			return root;
		},

		_forward: function (contactId) {
			this.getView().setBusy(true);
			var that = this;
			var i18nModel = this.geti18nModel();
			var oValueHelpDialog = new ValueHelpDialog({
				id: "helpProcessor",
				title: "{i18n>Processor}",
				supportMultiselect: false,
				supportRanges: false,
				supportRangesOnly: false,
				//	key: this.aKeys[0],
				//	descriptionKey: this.aKeys[1],
				stretch: sap.ui.Device.system.phone,

				ok: function (oControlEvent) {
					that.aTokens = oControlEvent.getParameter("tokens");
					that._NewProcessor = that.aTokens[0].getAggregation("customData")[0].getValue().suser;
					that._NewProcessorName = that.aTokens[0].getAggregation("customData")[0].getValue().fullname;
					var oData = {};
					oData.Pointer = that._globalPointer;
					oData.Forward_suser = that._NewProcessor;
					var url = that._getRemoteRoot();
					var changemessageModel = new sap.ui.model.odata.v2.ODataModel(url);
					changemessageModel.setUseBatch(false);
					changemessageModel.create("/ChangeMessageSet", oData, {
						success: function () {
							var SessionContactText = i18nModel.getResourceBundle().getText("firstLineOfGeneralMessage");
							var sHtmlText01 = SessionContactText + " " + that._NewProcessorName + " " + oData.Forward_suser;
							that.getView().byId(contactId).setText(sHtmlText01);

							var newProcessor = i18nModel.getResourceBundle().getText("newProcessor", [oData.Forward_suser]);
							MessageToast.show(newProcessor);

						},
						error: function (oError) {
							MessageToast.show("Error!");
						}
					});
					that.getView().setBusy(false);
					oValueHelpDialog.close();
				},

				cancel: function (oControlEvent) {
					that.getView().setBusy(false);
					oValueHelpDialog.close();
				},

				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});
			/*---------------------------------- table content------------------------------*/
			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
					label: "SAP Support ID",
					template: "suser"
				}, {
					label: "First Name",
					template: "firstname"
				}, {
					label: "Last Name",
					template: "lastname",
					demandPopin: true
				}]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");
			//	oValueHelpDialog.setTokens(this.theTokenInput.getTokens());

			/* -----------------------------Filter bar-------------------------------------*/
			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				header: "Please enter your search criteria",
				advancedMode: false,
				filterBarExpanded: true,
				showFilterConfiguration: false,
				showGoOnFB: !sap.ui.Device.system.phone,
				filterItems: [new sap.ui.comp.filterbar.FilterItem({
						name: "A",
						label: "SAP Support ID",
						control: new sap.m.Input()
					}),
					new sap.ui.comp.filterbar.FilterItem({
						name: "B",
						label: "First name",
						control: new sap.m.Input()
					}),
					new sap.ui.comp.filterbar.FilterItem({
						name: "C",
						label: "Last name",
						control: new sap.m.Input()
					})
				],
				search: function (oEvent) {
					var sUser = oEvent.getParameters().selectionSet[0].getValue();
					var firstName = oEvent.getParameters().selectionSet[1].getValue();
					var lastName = oEvent.getParameters().selectionSet[2].getValue();

					var ProcessorModel = new ODataModel(that._getRemoteRoot(), {
						useBatch: false
					});
					var Filters = [];
					if (sUser !== "") {
						var _ofilter_suser = new sap.ui.model.Filter({
							path: "suser",
							operator: "EQ",
							value1: sUser.toLocaleUpperCase()
						});
						Filters.push(_ofilter_suser);
					}
					if (firstName !== "") {
						var _ofilter_firstname = new sap.ui.model.Filter({
							path: "firstname",
							operator: "EQ",
							value1: firstName
						});
						Filters.push(_ofilter_firstname);
					}
					if (lastName !== "") {
						var _ofilter_lastname = new sap.ui.model.Filter({
							path: "lastname",
							operator: "EQ",
							value1: lastName
						});
						Filters.push(_ofilter_lastname);
					}
					if (Filters.length === 0) {
						var noSearchCriteria = i18nModel.getResourceBundle().getText("noSearchCriteria");
						sap.m.MessageToast.show(noSearchCriteria);
						return;
					}
					ProcessorModel.read("/SUserSet", {
						filters: Filters,
						success: function (oData, oResponse) {
							var oRowsModel = new sap.ui.model.json.JSONModel({
								SUserSet: oResponse.data.results
							});
							oValueHelpDialog.getTable().setModel(oRowsModel);
							if (oValueHelpDialog.getTable().bindRows) {
								oValueHelpDialog.getTable().bindRows("/SUserSet");
							}
							var i18nModel1 = that.geti18nModel();
							var searchResult = oRowsModel.getData().SUserSet.length;
							if (searchResult === 0) {
								var notData = i18nModel.getResourceBundle().getText("noData");
								sap.m.MessageToast.show(notData);
							} else {
								var searchCompleted = i18nModel1.getResourceBundle().getText("searchCompleted");
								MessageToast.show(searchCompleted);
							}

						}
					});

				}
			});

			oValueHelpDialog.setModel(i18nModel, "i18n");
			oValueHelpDialog.setFilterBar(oFilterBar);
			oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			oValueHelpDialog.open();

		},
		setToRead: function () {
			var that = this;
			var oData = {};
			oData.Pointer = this._globalPointer;
			oData.Is_read = "X";
			var url = this._getRemoteRoot();
			var changemessageStatus = new sap.ui.model.odata.v2.ODataModel(url);
			changemessageStatus.setUseBatch(false);
			changemessageStatus.create("/ChangeMessageSet", oData, {
				success: function () {
					that._markAsRead();
					var markedToRead = that.getResourceBundle().getText("read");
					MessageToast.show(markedToRead);
				},
				error: function (oError) {
					MessageToast.show("Error!");
				}
			});

		},

		setTocomplete: function () {
			var that = this;
			var oData = {};
			oData.Pointer = this._globalPointer;
			oData.Is_complete = "X";
			var url = this._getRemoteRoot();
			var changemessageStatus = new sap.ui.model.odata.v2.ODataModel(url);
			changemessageStatus.setUseBatch(false);
			changemessageStatus.create("/ChangeMessageSet", oData, {
				success: function () {
					that._markAsCompleted();
					var i18nModel = that.geti18nModel();
					var markedToCompleted = i18nModel.getResourceBundle().getText("completed");
					MessageToast.show(markedToCompleted);
				},
				error: function (oError) {
					MessageToast.show("Error!");
				}
			});
		},
		_setVisibleStatusOfForwardAndStatusSetIcon: function (processor) {
			var usrType = this.getUserType();
			var userID = this.getUser();
			var substitute = this.getSubstitute();
			//No Icon: Internal user substitute S-User, Internal user, S-User isn't processor
			if (substitute === "X" || usrType !== "S" || userID !== processor) {
				this.getView().byId("forward").setEnabled(false);
				this.getView().byId("unRead").setEnabled(false);
				this.getView().byId("read").setEnabled(false);
				this.getView().byId("disComplete").setEnabled(false);
				this.getView().byId("complete").setEnabled(false);
			}
		},
		_markAsRead: function () {
			this.getView().byId("unRead").setVisible(false);
			this.getView().byId("read").setVisible(true);
		},

		_markAsCompleted: function () {
			// marks as read
			this.getView().byId("unRead").setVisible(false);
			this.getView().byId("read").setVisible(true);
			// marks as completed
			this.getView().byId("disComplete").setVisible(false);
			this.getView().byId("complete").setVisible(true);
		},

		getModel: function (sName) {
			return this.getOwnerComponent().getModel(sName);
		},
		setModel: function (oModel, sName) {
			return this.getOwnerComponent().setModel(oModel, sName);
		},

		getOData: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.oData;
		},
		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		getUser: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.User;
		},

		getUserType: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.UserType;
		},

		getSubstitute: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.Substitute;
		},

		onNavToSubscribe: function (oEvent) {
			var oApp = oEvent.getSource().getParent().getParent().getParent().getParent().getParent();
			oApp.to(oApp.getDetailPages()[2]);
			var Pointer = oEvent.getSource().getParent().getParent().getParent().getController()._globalPointer;
			var oData = {};
			oData.Pointer = Pointer;
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish("Detail", "ReloadSubscribeView", oData);
		},

		onNavBack: function () {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("master", {}, true);
			}
		},
		
		loadLog: function () {
			var that = this;
			var oModelRead = this.getModel("ModificationLog");
			oModelRead.read("/SubscribeMsgLogSet", {
				filters: [new sap.ui.model.Filter("Pointer", "EQ", this._globalPointer)],
				success: function (oData) {
					that.getModel("ModLog").setProperty("/results", oData.results);
				}.bind(this),
				error: function (error) {}.bind(this)
			});
		}

	});

});