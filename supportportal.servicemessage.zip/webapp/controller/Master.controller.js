/*global history */
sap.ui.define([
	"sap/support/servicemessage/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/support/servicemessage/model/formatter",
	"sap/m/Dialog",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, ODataModel, formatter, Dialog, MessageBox) {
	"use strict";
	return BaseController.extend("sap.support.servicemessage.controller.Master", {
		formatter: formatter,
		onInit: function() {
			this.getRouter().getRoute("SplitPage").attachPatternMatched(this.getSessionItems, this);
		},

		getSessionItems: function(oEvent) {
			// set icon color
			var template = this.getView().byId('list').getBindingInfo('items').template;
			template.addEventDelegate({
				onAfterRendering: function() {
					var Rating = this.getCustomData()[1].getValue();
					if (Rating === 'A') {
						this.$().addClass('greenColor');
					} else if (Rating === 'B') {
						this.$().addClass('yellowColor');
					} else if (Rating === 'C') {
						this.$().addClass('redColor');
					}
				}
			}, template);
			
			// Object Name
			var Pointer = oEvent.getParameter("arguments").Pointer;
			var ServiceMessageModel = new JSONModel();
			ServiceMessageModel.loadData(this._getRemoteRoot() +
				"ServiceMessageSet('" + Pointer + "')", {}, true, "GET");
			var that = this;
			ServiceMessageModel.attachRequestCompleted(
				function() {
					if (ServiceMessageModel.getData().d) {
						var ObjectName = ServiceMessageModel.getData().d.Description;
						that.getView().byId("page").setTitle(ObjectName);
					} 
				/*	else {
						var i18nModel = that.getModel("i18n");
						var userErrorDialog = new Dialog({
							title: "{i18n>userError}",
							type: "Message",
							state: "{i18n>userError}",
							content: new sap.m.Text({
								text: "{i18n>userErrorMessage}"
							})
						});

						userErrorDialog.setModel(i18nModel, "i18n");
						userErrorDialog.open();
						return;
					}*/

				}
			);
			// Session Items
			var Sessionmodel = new ODataModel(this._getRemoteRoot(), {
				useBatch: false
			});
			Sessionmodel.read("/ServiceMessageSet('" + Pointer + "')/SessionSet", {
				success: function(oData, oResponse) {
					var model = new sap.ui.model.json.JSONModel({
						SessionSet: oResponse.data.results
					});
					that.getView().setModel(model, "Session");
				},
				error: function (error) {
					MessageBox.error(JSON.parse(error.responseText).error.message.value);
				/*	var Code = JSON.parse(error.responseText).error.code;
					if(Code === "SY/002"){
						MessageBox.error(JSON.parse(error.responseText).error.message.value);
					}else if(){
						
					}*/
					
				}
			});
		},
	
		itemPress: function(e) {
			var oApp = this.getView().getParent().getParent();
			oApp.to(oApp.getDetailPages()[1]);
			var custom = e.getParameter("listItem").getCustomData();
			var Pointer = custom[0].getKey();
			var SessGuid = custom[0].getValue();
			var oData = {};
			oData.Pointer = Pointer;
			oData.SessGuid = SessGuid;
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish("Master", "ReloadDetailView", oData);
		},

		_getRemoteRoot: function() {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			var root = oComp.sConfig.requestRemote;
			return root;
		}

	});

});