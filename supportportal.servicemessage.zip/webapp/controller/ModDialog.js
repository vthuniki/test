sap.ui.define([
	"sap/ui/base/Object",
	"sap/support/servicemessage/model/formatter"
], function (Object, formatter) {
	"use strict";

	return Object.extend("sap.support.servicemessage.controller.ModDialog", {
         formatter: formatter,
		_getDialog : function () {
			// create dialog lazily
			if (!this._oDialog) {
				// create dialog via fragment factory
				this._oDialog = sap.ui.xmlfragment("sap.support.servicemessage.view.fragment.ModificationLog", this);
			}
			return this._oDialog;
		},

		open : function (oView) {
			var oDialog = this._getDialog();
			oView.addDependent(oDialog);
			oDialog.open();
			return;
		},

		closeDialog : function () {
			this._getDialog().close();
		},
		
	});

});
