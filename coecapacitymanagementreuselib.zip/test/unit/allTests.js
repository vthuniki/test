sap.ui.define([
    "test/unit/fragment/Organisation.fragment.controller",
    "test/unit/fragment/ProductSearch.fragment.controller",
    "test/unit/controls/ResourcePlanningCalendar/ResourcePlanningCalendarComponent",
    "test/unit/utils/helpers",
    "test/unit/utils/formatter",
    "test/unit/utils/datamanager",
    "test/unit/utils/i18n"
], function() { "use strict"; });
