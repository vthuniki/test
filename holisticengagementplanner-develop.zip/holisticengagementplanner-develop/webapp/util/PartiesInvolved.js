 sap.ui.define([
	"com/sap/ui/hep/reuse/Constants",
	"com/sap/ui/hep/model/formatter",
 	"sap/ui/model/json/JSONModel",
 	"com/sap/ui/hep/util/EmployeeDetails",
 	"sap/m/MessageBox",
	"sap/m/GroupHeaderListItem",
	"com/sap/ui/hep/reuse/BaseTools"
 ], function (Constants, formatter, JSONModel, EmployeeDetails, MessageBox, GroupHeaderListItem, BaseTools) {

 	"use strict";
 	return {
 		formatter: formatter,
 		employeeDetails: EmployeeDetails,

		  _loadFragment: function (oFragmentController, oView, sFragmentPath, fnInitialCallback) {
			  return BaseTools.loadFragment(oFragmentController, oView, sFragmentPath, fnInitialCallback);
		  },


 		init: function (oContext) {

 			this.oContext = oContext;
 			this.oLocalModel = oContext.getView().getModel("localModel");
 			this.oLocalModel.getData().newPartner = false;
 			this.oLocalModel.getData().showGoOnFB = true;
 			this.oLocalModel.getData().showDisclaimGU = false;
 			this.oLocalModel.refresh();

 			this.oModelPartnerSet = new JSONModel({});
 			this.oContext.getView().setModel(this.oModelPartnerSet, "PartnerSet");
 			this.oModelPartnerSet.refresh();

 			this.oModelPartnerFct = new JSONModel({});
 			this.oContext.getView().setModel(this.oModelPartnerFct, "PartnerFct");
 			this.oModelPartnerFct.refresh();

 			this.oModelEmployeeSearch = new JSONModel({});
 			this.oContext.getView().setModel(this.oModelEmployeeSearch, "EmployeeSearch");
 			this.oModelEmployeeSearch.refresh();

 			this.oModelContactSearch = new JSONModel({});
 			this.oContext.getView().setModel(this.oModelContactSearch, "ContactSearch");
 			this.oModelContactSearch.refresh();

 			this.oModelCustomerSearch = new JSONModel({});
 			this.oContext.getView().setModel(this.oModelCustomerSearch, "CustomerSearch");
 			this.oModelCustomerSearch.refresh();

 			this.oModelServiceTeamSearch = new JSONModel({});
 			this.oContext.getView().setModel(this.oModelServiceTeamSearch, "ServiceTeamSearch");
 			this.oModelServiceTeamSearch.refresh();

 			this.oModelPartnerSearch = new JSONModel({});
 			this.oContext.getView().setModel(this.oModelPartnerSearch, "PartnerSearch");
 			this.oModelPartnerSearch.refresh();

 			this.oModelPartnerResult = new JSONModel({});
 			this.oContext.getView().setModel(this.oModelPartnerResult, "PartnerResult");
 			this.oModelPartnerResult.setSizeLimit(1000);
 			this.oModelPartnerResult.refresh();

 			this.oModelPartnerSuggestion = new JSONModel({});
 			this.oContext.getView().setModel(this.oModelPartnerSuggestion, "PartnerSuggestion");
 			this.oModelPartnerSuggestion.refresh();

 			let sPath = sap.ui.require.toUrl("com/sap/ui/hep/model/countries.json");
 			this.oModelCountry = new JSONModel(sPath);
 			this.oModelCountry.attachRequestCompleted(function () {
 				this.oContext.getView().setModel(this.oModelCountry, "Country");
 				this.oModelCountry.refresh();
 			}.bind(this));

 			this._readPartnerFct();
 		},

 		/**
 		 *  Load section to add a new partner
 		 *  @param {object} oEvent - object that contains data for one reference object
 		 */
 		loadAddNewDialog: function (oEvent) {
 			this.oModelPartnerSet.getData().push({
 				newPartner: true,
 				PartnerFct: "",
 				PartnerID: "",
 				Name: "",
 				Group: "",
 				GrpSort: "00"
 			});
 			this.oModelPartnerSet.getData().sort((a, b) => (a.PartnerID > b.PartnerID) ? 1 : -1);
 			this.oModelPartnerSet.refresh();

 			this.oLocalModel.getData().newPartner = true;
 			this.oLocalModel.refresh();

 		},

 		getNewPartnerFct: function () {
 			return this.oModelPartnerSet.getData().find(elem => elem.newPartner === true).PartnerFct;
 		},

 		setNewPartnerFct: function (sPartnerFct) {
 			let oNewPartner = this.oModelPartnerSet.getData().find(elem => elem.newPartner === true);
 			if (this._getEntitTypeByPartnerFct(oNewPartner.PartnerFct) !== this._getEntitTypeByPartnerFct(sPartnerFct)) {
 				oNewPartner.PartnerID = "";
 				oNewPartner.Name = "";
 			}
 			oNewPartner.PartnerFct = sPartnerFct;
 			this.oModelPartnerSet.refresh();
 		},

 		getNewPartnerID: function () {
 			return this.oModelPartnerSet.getData().find(elem => elem.newPartner === true).PartnerID;
 		},

 		setNewPartner: function (sPartnerID, sName) {
 			let oNewPartner = this.oModelPartnerSet.getData().find(elem => elem.newPartner === true);
 			oNewPartner.PartnerID = sPartnerID;
 			oNewPartner.Name = sName;
 			this.oModelPartnerSet.refresh();
 		},

 		setCustomerSearchCountry: function (sCountryCode) {
 			this.oModelCustomerSearch.getData().Country = sCountryCode;
 			this.oModelCustomerSearch.refresh();
 		},

 		setServiceTeamSearchCountry: function (sCountryCode) {
 			this.oModelServiceTeamSearch.getData().Country = sCountryCode;
 			this.oModelServiceTeamSearch.refresh();
 		},

 		saveNewPartner: function (fnCallbackSuccess) {
 			this._createPartner(fnCallbackSuccess);
 			this.oLocalModel.getData().newPartner = false;
 			this.oLocalModel.refresh();
 		},

 		cancelNewPartner: function () {
 			this.oLocalModel.getData().newPartner = false;
 			this.oLocalModel.refresh();

 			let aPartnerSet = [];
 			this.oModelPartnerSet.getData().forEach(function (item) {
 				if (!item.newPartner || item.newPartner === false) {
 					aPartnerSet.push(item);
 				}
 			});
 			this.oModelPartnerSet.setData(aPartnerSet);
 			this.oModelPartnerSet.refresh();
 		},

 		deletePartner: function (sPartnerFct, sPartnerID, fnCallbackSuccess) {
 			this.oLocalModel.getData().busyPartnerSet = true;
 			this.oLocalModel.refresh();

 			if (sPartnerID === "" || sPartnerFct === "") {
 				return;
 			}
 			let entities = {};
				entities.servicePath = Constants.getServicePath();
 			entities.entitySet = "ProjectPartnerSet(ProjectID='" + this.oContext.getModel("projectDetails").getData().ProjectID +
 				"',PartnerID='" + sPartnerID + "',PartnerFct='" + sPartnerFct + "')";
 			entities.currentView = this.oContext.getView();
 			entities.oContext = this.oContext;
 			entities.callbackSuccess = (data) => {
 				this.oLocalModel.getData().busyPartnerSet = false;
 				this.oLocalModel.refresh();
 				this.readPartnerSet(fnCallbackSuccess);
 			};
 			entities.callbackError = (data) => {
 				this.oLocalModel.getData().busyPartnerSet = false;
 				this.oLocalModel.refresh();
 			};
 			this.oContext.deleteBaseRequest(entities);
 		},

 		fastSearchPartner: function (sInput, oInputSuggest) {
 			if (sInput === "") {
 				return;
 			}
 			let oNewPartner = this.oModelPartnerSet.getData().find(elem => elem.newPartner === true);
 			let sEntityType = this._getEntitTypeByPartnerFct(oNewPartner.PartnerFct);
 			let oParams = {
 				ValueFld: sInput
 			};
 			if (sEntityType === "PFContact") {
 				oParams.CustomerID = this.oContext.getModel("projectDetails").getData().CustomerID;
 			}
 			Promise.all([this.searchPartner(sEntityType + "Set", oParams)]).then(function (oData) {
 				let aResult = [];
 				this.oModelPartnerResult.getData().forEach(elem => aResult.push({
 					PartnerID: elem.PartnerID,
 					Name: elem.FullName
 				}));
 				this.oModelPartnerSuggestion.setData(aResult);
					this.oModelPartnerSuggestion.refresh();
 			}.bind(this));
 		},

 		_handlePartnerSuggestSuccess: function (oData) {
 			let aResult = [];
 			this.oModelPartnerResult.getData().forEach(elem => aResult.push({
 				PartnerID: elem.PartnerID,
 				Name: elem.Fullname
 			}));
 			this.oModelPartnerSuggestion.setData(aResult);
				this.oModelPartnerSuggestion.refresh();
 		},

 		/**
 		 *  trigger BE search for Employees
 		 *  @param {object} oParams - search parameter to be used for BE-read-request
 		 */
 		searchPartner: function (sEntitySet, oParams) {
 			if (this.oLocalModel.getData().bpSearchReturnType === "EngScopeSearchPopupCustomerValueHelp" &&
 				this.oLocalModel.getData().showDisclaimGU === true
 			) {
 				return undefined;
 			};

			return new Promise((resolve, reject) => {
				this.oLocalModel.getData().busyFastSearchPartner = true;
 				this.oLocalModel.getData().VHPartnerResultLength = "";
 				this.oLocalModel.refresh();

				let entities = {};
				entities.filter = this.oLocalModel.getData().bpSearchReturnType === "EngScopeSearchPopupCustomerValueHelp" ? "GuPartnerID ne '" + this.oLocalModel.getData().bpGlobalGUBp + "'" : "";
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = sEntitySet;
				this._fnHelperBuildFilterSearchPartner(oParams, entities);
				entities.sortItem = sEntitySet === "PFCustomerSet" || sEntitySet === "PFServiceTeamSet" ? "Name1" : "NameLast, NameFirst";
 				entities.currentView = this.oContext.getView();
 				entities.oContext = this.oContext;
 				entities.busyIndicator = "busyFastSearchPartner";
 				entities.callbackSuccess = function (data) {
 					this.oLocalModel.getData().busyFastSearchPartner = true;
 					this.oLocalModel.refresh();
 					this._handleSuccessSearchPartner(data);
						resolve();
 				}.bind(this);
 				this.oContext.readBaseRequest(entities);
 			});
 		},

		  _fnHelperBuildFilterSearchPartner(oParams, entities) {
			  Object.keys(oParams).forEach(key => {
				  let sAnd = entities.filter !== "" ? " and " : "";
				  if (key === "RelatedPartner" && this.oModelContactSearch.getData().relPartnerFlagSelectedKey === "Y")
					  entities.filter += sAnd + "RelatedPartner eq true";
				  else if (key === "CustomerID" && oParams[key] !== "")
					  entities.filter += sAnd + "CustomerID eq '" + oParams[key] + "'";
				  else if (key === "ValueFld" && oParams[key] !== "")
					  entities.filter += sAnd + "substringof('" + oParams[key] + "', " + key + ")";
				  else if (key === "UserId" && oParams[key] !== "")
					  entities.filter += sAnd + key + " eq '" + oParams[key].toUpperCase() + "'";
			  });
		  },

 		_handleSuccessSearchPartner: function (oData) {
 			this.oModelPartnerResult.setData(oData.results);
 			this.oModelPartnerResult.refresh();

 			this.oLocalModel.getData().VHPartnerResultLength = oData.results.length;
 			this.oLocalModel.refresh();
 		},

 		setMain: function (sPartnerFct, sPartnerID, fnCallbackSuccess) {
 			this._updatePartner({
 				ProjectID: this.oContext.getModel("projectDetails").getData().ProjectID,
 				PartnerID: sPartnerID,
 				PartnerFct: sPartnerFct,
 				MainPartner: "X"
 			}, fnCallbackSuccess);
 		},

 		_readPartnerFct: function () {
 			let entities = {};
				entities.servicePath = Constants.getServicePath();
 			entities.entitySet = "ProjectPFListSet";
 			entities.errorMessage = this.oContext.getResourceBundle().getText("ProjectDetails.ReadPartnerFctError");
 			entities.currentView = this.oContext.getView();
 			entities.oContext = this.oContext;
 			entities.callbackSuccess = function (data) {
 				this._handleSuccessReadPartnerFct(data);
 			}.bind(this);
 			this.oContext.readBaseRequest(entities);
 		},

 		_handleSuccessReadPartnerFct: function (oData) {
 			oData.results.forEach(function (elem) {
 				elem.Group = elem.GrpSort + " " + elem.GrpName;
 			});
 			this.oModelPartnerFct.setData(oData.results);
 			/*handle 3 cases which should always appear on top of the dropdown menu shown
 			by adding an new partner -> introducing a new sort property.
 			New property is required because items are numerated contineously with PartnerFctSort,
 			be we need to handle only 3 top cases and sort the rest alphabetically.
 			*/
 			oData.results.forEach(oItem => {
 				switch (oItem.PartnerFct) {
 				case "ZSTQML01":
 					oItem.MenConSort = 0;
 					break;
 				case "ZSENARCH":
 					oItem.MenConSort = 1;
 					break;
 				case "ZSTQM001":
 					oItem.MenConSort = 2;
 					break;
 				default:
 					oItem.MenConSort = null;
 				}
 			});

 			this.oModelPartnerFct.refresh();
 		},

 		getPartnerGroupTitle: function (oGroup) {
 			let sTitle = "";
 			if (oGroup.key === "00") {
 				sTitle = this.oContext.getResourceBundle().getText("Partner.NewPartner");
 			} else if (this.oModelPartnerFct.getData().length > 0) {
 				try {
 					sTitle = this.oModelPartnerFct.getData().find(elem => elem.GrpSort === oGroup.key).GrpName;

 				} catch (e) {
 					sTitle = oGroup.key;
 				}
 			}
 			return new GroupHeaderListItem({
 				title: sTitle
 			});
 		},

 		readPartnerSet: function (fnCallbackSuccess) {
 			this.oLocalModel.getData().busyPartnerSet = true;
 			this.oLocalModel.refresh();
 			let entities = {};
				entities.servicePath = Constants.getServicePath();
 			entities.entitySet = "ProjectSet('" + this.oContext.getModel("projectDetails").getData().ProjectID + "')";
 			entities.navigation = "toProjectPartners";
 			entities.currentView = this.oContext.getView();
 			entities.oContext = this.oContext;
 			entities.errorMessage = this.oContext.getResourceBundle().getText("ProjectDetails.ReadPartnerSetError", [this._idProject]);
 			entities.callbackSuccess = function (data) {
 				this._handleSuccessReadPartnerSet(data);
 				if (fnCallbackSuccess && typeof fnCallbackSuccess === 'function')
 					fnCallbackSuccess(data);
 				this.oLocalModel.getData().busyPartnerSet = false;
 				this.oLocalModel.refresh();
 			}.bind(this);
 			entities.callbackError = function (data) {
 				this.oLocalModel.getData().busyPartnerSet = false;
 				this.oLocalModel.refresh();
 			}.bind(this);
 			this.oContext.readBaseRequest(entities);
 		},

 		_handleSuccessReadPartnerSet: function (oData) {
 			oData.results.forEach(function (elem) {
 				elem.newPartner = false;
 				elem.Group = elem.GrpSort + " " + elem.GrpName;
 			});
 			//Add a pre-sorting for PF roles
 			oData.results.forEach(oItem => {
 				switch (oItem.PartnerFct) {
 				case "ZSTQML01":
 					oItem.MenConSort = 0;
 					break;
 				case "ZSENARCH":
 					oItem.MenConSort = 1;
 					break;
 				case "ZSTQM001":
 					oItem.MenConSort = 2;
 					break;
 				default:
 					oItem.MenConSort = null;
 				}
 			});

 			this.oModelPartnerSet.setData(oData.results);
 			this.oModelPartnerSet.refresh();

 			this.oLocalModel.getData().newPartner = false;
 			this.oLocalModel.refresh();
 		},

 		_createPartner: function (fnCallbackSuccess) {
 			this.oLocalModel.getData().busyPartnerSet = true;
 			this.oLocalModel.refresh();
 			let oNewPartner = this.oModelPartnerSet.getData().find(elem => elem.newPartner === true);
 			if (oNewPartner.PartnerID === "" || oNewPartner.PartnerFct === "") {
 				return;
 			}
 			let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "ProjectPartnerSet";
 			entities.currentView = this.oContext.getView();
 			entities.oContext = this.oContext;
 			entities.data = {
 				ProjectID: this.oContext.getModel("projectDetails").getData().ProjectID,
 				PartnerID: oNewPartner.PartnerID,
 				PartnerFct: oNewPartner.PartnerFct
				};
 			entities.callbackSuccess = (data) => {
 				if (entities.oContext.getMetadata()._sClassName.includes("ProjectDetails")) {
 					entities.oContext.getOwnerComponent().trackEvent("Add_BPToProject");
 				} else {
 					entities.oContext.getOwnerComponent().trackEvent("Add_BPToEngagement");
 				}
 				this._handleSuccessCreatePartner(data, fnCallbackSuccess);
 				this.oLocalModel.getData().busyPartnerSet = false;
 				this.oLocalModel.refresh();
 			};
 			entities.callbackError = (error) => {
 				this.oLocalModel.getData().busyPartnerSet = false;
 				this.oLocalModel.refresh();
 				this._handleErrorCreatePartner(error);
 			};
 			this.oContext.createBaseRequest(entities);
 		},

 		_handleSuccessCreatePartner: function (oData, fnCallbackSuccess) {
 			this.readPartnerSet(fnCallbackSuccess);
 		},

 		_handleErrorCreatePartner: function (oError) {
 			let oMessage = jQuery.parseJSON(oError.responseText);
 			MessageBox.error(oMessage.error.message.value, {
 				details: oMessage.error.code
 			});
 		},

 		_updatePartner: function (oPayload, fnCallbackSuccess) {
 			this.oLocalModel.getData().busyPartnerSet = true;
 			this.oLocalModel.refresh();
 			let entities = {};
				entities.servicePath = Constants.getServicePath();
 			entities.entitySet = "ProjectPartnerSet(ProjectID='" + this.oContext.getModel("projectDetails").getData().ProjectID +
 				"',PartnerID='" + oPayload.PartnerID + "',PartnerFct='" + oPayload.PartnerFct + "')";
 			entities.currentView = this.oContext.getView();
 			entities.oContext = this.oContext;
				entities.data = oPayload;
 			entities.callbackSuccess = (data) => {
 				this._handleSuccessUpdatePartner(data, fnCallbackSuccess);
 				this.oLocalModel.getData().busyPartnerSet = false;
 				this.oLocalModel.refresh();
 			};
 			entities.callbackError = (data) => {
 				this.oLocalModel.getData().busyPartnerSet = false;
 				this.oLocalModel.refresh();
 			};
 			this.oContext.updateBaseRequest(entities);
 		},

 		_handleSuccessUpdatePartner: function (data, fnCallbackSuccess) {
 			this.readPartnerSet(fnCallbackSuccess);
 		},

 		loadSearchHelpDialog: function (sPartnerFct, sEntityType = "") {
 			this.oLocalModel.getData().VHPartnerResultLength = "";
 			this.oLocalModel.refresh();
 			if (sEntityType === "") {
 				sEntityType = this._getEntitTypeByPartnerFct(sPartnerFct);
 			}
 			let sFragmentName = "";
 			switch (sEntityType) {
 			case "PFCustomer":
 				sFragmentName = "com.sap.ui.hep.view.fragment.ValueHelpCustomer";
 				if (this.oLocalModel.getData().bpSearchReturnType === "EngScopeSearchPopupCustomerValueHelp") {
 					this.setDisclaimerGU(true);
 				} else {
 					this.setDisclaimerGU(false);
 				}
 				break;
 			case "PFContact":
 				sFragmentName = "com.sap.ui.hep.view.fragment.ValueHelpContact";
				this.oModelContactSearch.getData().RelatedPartner = Constants.getFlagValues();
 				this.oModelContactSearch.getData().relPartnerFlagSelectedKey = "Y";
 				this.oModelContactSearch.getData().CustomerID = this.oContext.getModel("projectDetails").getData().CustomerID;
 				this.oModelContactSearch.refresh();
 				break;
 			case "PFEmployee":
 				sFragmentName = "com.sap.ui.hep.view.fragment.ValueHelpEmployee";
 				break;
 			case "PFServiceTeam":
 				sFragmentName = "com.sap.ui.hep.view.fragment.ValueHelpServiceTeam";
 				break;
 			default:
 				return;
 			}
 			this.oModelPartnerResult.setData();
 			this.oModelPartnerResult.refresh();
 			try {
					this.oContext._pDialogVHPartner?.then(oDialog => oDialog?.destroy());
					this.oContext._pDialogVHPartner = undefined;

					this.oContext._pDialogVHPartner = this._loadFragment(this.oContext, this.oContext.getView(), sFragmentName).then(oDialog => {
 					this.oContext._oDialogVHPartner = oDialog;
 					this.oContext._oDialogVHPartner.setModel(this.oContext.getModel("i18n"), "i18n");
 					this.oContext._oDialogVHPartner.addEventDelegate({
 						onsapenter: function () {
								let oModelSearch;
								switch (sEntityType) {
									case "PFCustomer":
										oModelSearch = this.oModelCustomerSearch;
										break;
									case "PFServiceTeam":
										oModelSearch = this.oModelServiceTeamSearch;
										break;
									case "PFContact":
										oModelSearch = this.oModelContactSearch;
										break;
									case "PFEmployee":
										oModelSearch = this.oModelEmployeeSearch;
										break;
									default:
										oModelSearch = undefined;
								}
 							this.searchPartner(sEntityType + "Set", oModelSearch.getData());
 						}.bind(this)
 					}, this);
 					this.oContext._oDialogVHPartner.open();
 				});
 			} catch (oError) {
 				if (oError.statusCode === 503) {
 					let oView = this.oContext.getView();
 					let params = {
 						currentView: oView
 					};
 					this.oContext.handleSessionTimeout(params, this.oContext);
 				}
 			}
 		},

 		setDisclaimerGU: function (bDisclaimerGU) {
 			if (bDisclaimerGU === true) {
 				this.oLocalModel.getData().showGoOnFB = false;
 				this.oLocalModel.getData().showDisclaimGU = true;
 			} else {
 				this.oLocalModel.getData().showGoOnFB = true;
 				this.oLocalModel.getData().showDisclaimGU = false;
 			}
 			this.oLocalModel.refresh();
 		},

 		closeSearchHelpDialog: function () {
 			this.oContext._oDialogVHPartner.close();
 			this.oContext._oDialogVHPartner.destroy();
 		},

 		_getEntitTypeByPartnerFct: function (sPartnerFct) {
 			if (sPartnerFct) {
 				return this.oModelPartnerFct.getData().find(elem => elem.PartnerFct === sPartnerFct).EntityType;
 			} else {
 				return null;
 			}
 		},
 	};

 });
