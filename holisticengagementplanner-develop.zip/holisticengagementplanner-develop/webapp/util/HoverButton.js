sap.ui.define([

], function () {
	"use strict";

	return sap.m.Button.extend("com.sap.ui.hep.util.HoverButton", {
		metadata: {
			events: {
				"hover": {}
			}
		},

		onmouseover: function (event) {
			this.fireHover(event);
		},

		renderer: function () {}

	});
});