sap.ui.define(
	[
		"com/sap/ui/hep/reuse/Constants",
		"com/sap/ui/hep/model/formatter",
		"com/sap/ui/hep/reuse/BaseRequest",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/Fragment",
		"com/sap/ui/hep/util/Pagination"
	],
	function (Constants, formatter, BaseRequest, JSONModel, Fragment, Pagination) {
		return {
			formatter: formatter,
			pagination: Pagination,




			/** This is a helper-module that can be used if a F4-Help for Selecting a Project  is required somewhere.
			   At the control where the F4-Help is required the following method has to be called in i.e. the following way:

			  	fnOnProjectSelectionVHTrigger: function (oEvent) {
						let oResourceBundle = this.getResourceBundle();
						let oView = this.getView();
						let oDestinationModel = this.getView().getModel("localModel");
						let oDestModelPathObject = this.getView().getModel("localModel").getData().oNewServicePlan;

						ProjectSelection.fnOnProjectSelectionDialogOpen(oView, oResourceBundle, oDestinationModel, oDestModelPathObject,
							"ProjectID", "ProjectGUID", "ProjectName");  //<-- name of the model properties, that are to be filled
					},

				That's it. Nothing more is required in the calling controller.
				Because the model and the model properties, that should be filled with the search result are handed over to this Module.
				Once  the user has selected a project from the result list, the given model properties of the calling controller are filled
				with the selected values and a refresh on that model is also performed
			*/

			fnOnProjectSelectionDialogOpen: function (oView, oResourceBundle, oDestModel, oDestModelPath, sProjectId, sProjectGuid, sProjectName) {
				this._oView = oView;
				this._oResourceBundle = oResourceBundle;
				this._oDestModel = oDestModel;
				this._oDestModelPath = oDestModelPath;
				this._sDestModelPropProjectId = sProjectId;
				this._sDestModelPropProjectGuid = sProjectGuid;
				this._sDestModelPropProjectName = sProjectName;

				// create and initialize the Model
				this._oProjectSelectionModel = new JSONModel({});
				this._oProjectSelectionModel.getData().filter = {};
				this._oProjectSelectionModel.getData().paginationClicks = 0;
				this._oProjectSelectionModel.getData().paginationSkip = 0;
				this._oProjectSelectionModel.getData().paginationIntervalStart = 0;
				this._oProjectSelectionModel.getData().paginationIntervalEnd = Constants.getPaginationTop();
				this._oProjectSelectionModel.getData().paginationNextBtnEnabled = true;
				this._oProjectSelectionModel.getData().paginationPrevBtnEnabled = true;
				this._oModel = this._oProjectSelectionModel; //needed for pagination Module
				this._oData = this._oProjectSelectionModel.getData(); //needed for pagination Module

				// load data from BE into model
				this._loadProjectReasonSelectionListFromBE();
				this._fnGetProjectsFromBE();

				// load Project Selection Fragment
				if (!this._oDialogProjectSelection) {
					try {
						Fragment.load({
							id: this._oView.getId(),
							name: "com.sap.ui.hep.util.projectSelection.DialogProjectSelection",
							controller: this
						}).then(oDialog => {
							this._oDialogProjectSelection = oDialog;
							this._oView.addDependent(this._oDialogProjectSelection);
							this._oDialogProjectSelection.setModel(this._oProjectSelectionModel, "projectSelectionModel");
							this._oDialogProjectSelection.open();
						});
					} catch (oError) {
						if (oError.statusCode === 503) {
							let params = {
								currentView: this._oView
							};
							this.handleSessionTimeout(params, this);
						}
					}
				} else {
					this._oDialogProjectSelection.open();
				}
			},

			//---------------------------------------------------- Reason Combo ----------------------------------------------------
			_loadProjectReasonSelectionListFromBE: function () {
				let entities = {
					servicePath: Constants.getServicePath(),
					entitySet: Constants.getEntities().ValueHelp,
					filter: "Entity eq 'CASE_REASON'",
					oContext: this._oView,
					currentView: this._oView,
					callbackSuccess: oData => {
						if (!oData.results.length) return;
						
						let aAllReasons = JSON.parse(oData.results[0].Results);
						aAllReasons.forEach(element => {
							element.CaseType = element["Case Type"];
							element.ReasonCode = element["Reason Code"];
							delete element["Case Type"];
							delete element["Reason Code"];
						});
						aAllReasons = aAllReasons.filter(oReason =>
							oReason.ReasonCode !== "ENG1" && oReason.ReasonCode !== "ENG2");
						this._oProjectSelectionModel.getData().Reasons =
							aAllReasons.filter(item => item.CaseType === Constants.getGenericCaseTypeForReasons());
						this._oProjectSelectionModel.refresh();				
					}
				};
				BaseRequest.handleRead(entities);
			},

			//-----------------------------------------------  Search Projects ------------------------------------------------------
			_fnGetProjectsFromBE: function () {
				this._oProjectSelectionModel.getData().busyProjectSearch = true;
				this._oProjectSelectionModel.refresh();
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = Constants.getEntities().ProjectEntity;
				entities.filter = this._buildProjectSearchFilterParams();
				entities.paginationTop = Constants.getPaginationTop();
				entities.paginationSkip = this._oProjectSelectionModel.getData().paginationSkip;
				entities.inlineCount = "allpages";
				entities.callbackSuccess = (oData) => {
					this._oProjectSelectionModel.getData().resultList = oData.results;
					this._oProjectSelectionModel.getData().NumberOfProjects = JSON.parse(oData.__count);
					this._oProjectSelectionModel.getData().busyProjectSearch = false;
					this._oProjectSelectionModel.refresh();
					this.pagination._paginationElements(this, this._oProjectSelectionModel.getData().NumberOfProjects,
						this._oView.byId("btnPaginationNext"),
						this._oView.byId("btnPaginationPrev"));
				};
				BaseRequest.handleRead(entities);
			},

			_buildProjectSearchFilterParams: function () {
				let sFilters = "( CaseType eq 'ZS02') and ( StatusID eq '71' or StatusID eq '80' or StatusID eq '81')";

				if (this._oProjectSelectionModel.getData().filter.ProjectId) {
					sFilters += " and substringof('" + this._oProjectSelectionModel.getData().filter.ProjectId + "', ProjectID)";
				}
				if (this._oProjectSelectionModel.getData().filter.ProjectName) {
					sFilters += " and substringof('" + this._oProjectSelectionModel.getData().filter.ProjectName + "', ProjectName)";
				}
				if (this._oProjectSelectionModel.getData().filter.CustomerBpId) {
					sFilters += " and substringof('" + this._oProjectSelectionModel.getData().filter.CustomerBpId + "', CustomerID)";
				}
				if (this._oProjectSelectionModel.getData().filter.CustomerName) {
					sFilters += " and substringof('" + this._oProjectSelectionModel.getData().filter.CustomerName + "', CustomerName)";
				}
				if (this._oProjectSelectionModel.getData().filter.ReasonCode) {
					sFilters += " and substringof('" + this._oProjectSelectionModel.getData().filter.ReasonCode + "', ReasonCode)";
				}

				if (sFilters.indexOf("ReasonCode") === -1) {
					sFilters += " and " +
						"( ReasonCode eq 'ENG3' or  ReasonCode eq 'ENG4' or  ReasonCode eq 'ENG5' or  ReasonCode eq 'ENG6' or  ReasonCode eq 'ENG7' or  ReasonCode eq 'ENGA'  or  ReasonCode eq '' )";
				}
				return sFilters;

			},

			fnOnResetSearchFiltersFilters: function () {
				this._oProjectSelectionModel.getData().filter = {};
				this._oProjectSelectionModel.refresh();
			},
			fnOnSearch: function () {
				this._oProjectSelectionModel.getData().paginationClicks = 0;
				this._oProjectSelectionModel.getData().paginationSkip = 0;
				this._oProjectSelectionModel.refresh();
				this._fnGetProjectsFromBE();
			},

			fnToPreviousRecords: function () {
				let pagination = this.pagination.goToNextPage(this, this._oProjectSelectionModel.getData().paginationClicks);
				this._oProjectSelectionModel.getData().paginationClicks = pagination.clicks;
				this._oProjectSelectionModel.getData().paginationSkip = pagination.skip;
				this._fnGetProjectsFromBE();
			},

			fnToNextRecords: function () {
				let pagination = this.pagination.goToNextPage(this, this._oProjectSelectionModel.getData().paginationClicks);
				this._oProjectSelectionModel.getData().paginationClicks = pagination.clicks;
				this._oProjectSelectionModel.getData().paginationSkip = pagination.skip;
				this._fnGetProjectsFromBE();
			},

			fnOnProjectSelected: function (oEvent) {
				let path = oEvent.getSource().getSelectedContextPaths()[0];
				let dataFromIndex = this._oProjectSelectionModel.getProperty(path);

				this._oDestModelPath[this._sDestModelPropProjectId] = dataFromIndex.ProjectID;
				this._oDestModelPath[this._sDestModelPropProjectGuid] = dataFromIndex.ProjectGUID;
				this._oDestModelPath[this._sDestModelPropProjectName] = dataFromIndex.ProjectName;
				this._oDestModel.refresh();

				this._oDialogProjectSelection.close();
			},

			fnOnCancelProjectSelection: function () {
				this._oDialogProjectSelection.close();
			}

		};
	}
);
