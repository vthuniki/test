sap.ui.define("com/sap/ui/hep/util/TablePersoBaseService",
    ["sap/ui/base/Object"], function (Object) {
        return Object.extend("com.sap.ui.hep.util.TablePersoBaseService", {
            constructor: function (personalizationFile) {
                this._persPromise = fetch(sap.ui.require.toUrl(`com/sap/ui/hep/util/perso/${personalizationFile}`))
                    .then(data => data.json());
            },

            getPersData: function () {
                let oDeferred = new jQuery.Deferred();
                let oBundle = this._oBundle;

                if (!oBundle) {
                    this._persPromise.then(perso => {
                        this._oBundle = perso;
                        oDeferred.resolve(this._oBundle);
                    });
                } else {
                    oDeferred.resolve(oBundle);
                }

                return oDeferred.promise();
            },

            setPersData: function (oBundle) {
                this._oBundle = oBundle;
                let oDeferred = new jQuery.Deferred();
                oDeferred.resolve();
                return oDeferred.promise();
            },

            delPersData: function () {
                let oDeferred = new jQuery.Deferred();
                oDeferred.resolve();
                return oDeferred.promise();
            },

            resetPersData: function () {
                let oDeferred = new jQuery.Deferred();

                this._persPromise.then(data => this._oBundle = data);
                oDeferred.resolve();
                return oDeferred.promise();
            },

            getCaption: function (oColumn) {
                return null;
            }
        });
    }, /* bExport= */ true);
