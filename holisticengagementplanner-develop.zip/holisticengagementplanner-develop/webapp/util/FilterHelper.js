sap.ui.define([
	"sap/ui/core/Fragment",
	"sap/ui/Device",
	"com/sap/ui/hep/reuse/Constants",
], function (Fragment, Device, Constants) {
	"use strict";
	return {

		getViewSettingsDialog: function (sDialogFragmentName, oContext, _mViewSettingsDialogs) {
			let pDialog = _mViewSettingsDialogs[sDialogFragmentName];
			if (!pDialog) {
				pDialog = Fragment.load({
					id: oContext.getView().getId(),
					name: sDialogFragmentName,
					controller: oContext
				}).then(oDialog => {
					oContext.getView().addDependent(oDialog);
					if (Device.system.desktop) {
						oDialog.addStyleClass("sapUiSizeCompact");
					}
					return oDialog;
				});
				    _mViewSettingsDialogs[sDialogFragmentName] = pDialog;
			}
			return pDialog;
		},

		_buildStartAndEndForDateFilters: function(start, end, value, type){
			if (type === "LASTMONTHS") {
				start.setMonth(start.getMonth() - value);
				start.setDate(1);
				end.setDate(0);
			} else if (type === "NEXTMONTHS") {
				start.setMonth(start.getMonth() + 1);
				start.setDate(1);
				end.setMonth(end.getMonth() + value + 1);
				end.setDate(0);
			} else if (type === "LASTYEARS") {
				start.setYear(start.getFullYear() - value);
				start.setMonth(0);
				start.setDate(1);
				end.setYear(end.getFullYear() - 1);
				end.setMonth(11);
				end.setDate(31);
			} else {
				start.setYear(start.getFullYear() + 1);
				start.setMonth(0);
				start.setDate(1);
				end.setYear(end.getFullYear() + value);
				end.setMonth(11);
				end.setDate(31);
			}

			return {start, end};
		},

		_setCheckedStandardFilters: function(item, entry, filterlist){
			if (filterlist[entry.getProperty("text")].includes(item.getProperty("key")) ||
					filterlist[entry.getProperty("text")].includes(item.getProperty("text"))) {
					item.setSelected(true);
			}
		},

		handleCreationOfFilterPopUpFromVariantServices: function(entry, filterlist, lastFilters){
			if (filterlist[entry.getProperty("text")] || filterlist[entry.getProperty("key")]) {
				if (entry.getProperty("text").includes("Date")) {
					let type = entry.getProperty("text");
					entry.setFilterCount(1);
					filterlist[type][0]["values"][0] = filterlist[type][1].length > 3 ? new Date(filterlist[type][1]) : filterlist[type][1];
					if (filterlist[type][2])
						filterlist[type][0]["values"][1] = new Date(filterlist[type][2]);
					entry.getCustomControl().setValue(filterlist[type][0]);
					lastFilters.pop();
					lastFilters.push(entry.getCustomControl().getValue());
				} else if (entry.getCustomControl !== undefined) {
					entry.setFilterCount(1);
					entry.getCustomControl().setValue(filterlist[entry.getProperty("key")][0]);
					lastFilters.pop();
					lastFilters.push(entry.getCustomControl().getValue());
				} else {
					entry.getItems().forEach(item => {
						this._setCheckedStandardFilters(item, entry, filterlist);
					});
				}
			}

			return lastFilters;
		},

		buildOptionsForDateFilters: function(oDateFilterName, oContext){
			oContext.byId(oDateFilterName).setStandardOptions(["DATE", "DATERANGE", "FROM", "TO", "NEXTMONTHS", "LASTMONTHS",
				"NEXTYEARS", "LASTYEARS"
			]);
		},

		cancelInputs: function(oEvent, oContext, lastFilters, positionCustomFiltersStart){
			let pos = 0,
				iFilterCount;

			oEvent.getSource().getFilterItems().forEach(oFilterItem => {
				if (oFilterItem.getText().includes("Date")) {

					iFilterCount = Number(!!lastFilters[pos]);

					if (oFilterItem.getText() === "Start Date") {
						oContext.byId("dynamic-range").setValue(lastFilters[pos]);
						oContext.byId("filterDialog").getFilterItems()[positionCustomFiltersStart].setFilterCount(iFilterCount);
					} else if (oFilterItem.getText() === "End Date") {
						oContext.byId("dynamic-range2").setValue(lastFilters[pos]);
						oContext.byId("filterDialog").getFilterItems()[positionCustomFiltersStart + 1].setFilterCount(iFilterCount);
					} else {
						oContext.byId("dynamic-range3").setValue(lastFilters[pos]);
						oContext.byId("filterDialog").getFilterItems()[positionCustomFiltersStart + 2].setFilterCount(iFilterCount);
					}
					pos++;
				}

				if (oFilterItem.getCustomControl?.().setValue && !oFilterItem.getText().includes("Date")) {

					oFilterItem.getCustomControl().setValue(lastFilters[pos]);

					iFilterCount = Number(!!lastFilters[pos]);

					oContext.byId("filterDialog").getFilterItems()[positionCustomFiltersStart + pos].setFilterCount(iFilterCount);
					pos++;
				}
			});
		},

		resetInputs: function(oEvent){
			oEvent.getSource().getFilterItems().forEach(oFilterItem => {
				if (oFilterItem.getCustomControl) {
					oFilterItem.setFilterCount(0);
					if (oFilterItem.getCustomControl().setValue)
						oFilterItem.getCustomControl().setValue();
				}
			});
		},

		_generateFilterString(date, start, end) {
			let startDateStart = new Date(start.setHours(0, 0, 0));
			let startDateEnd = new Date(end.setHours(23, 59, 59));

			return "(" + date + " ge datetime'" + startDateStart.toJSON().slice(0, -5) + "' and " + date + " le datetime'" + startDateEnd.toJSON()
				.slice(0, -5) + "') and ";
		},

		eventFired: function (oEvent, sId, oContext) {
			let iFilterCounter;
			if (sId.includes("Date")) {
				let valueState = oEvent.getParameter("valid") ? "None" : "Error";
				oEvent.getSource().setValueState(valueState);
				iFilterCounter = oEvent.getSource().getValue() === undefined ? 0 : 1;
			} else {
				iFilterCounter = oEvent.getParameters().value === "" ? 0 : 1;
			}
			oContext.getView().byId(sId).setFilterCount(iFilterCounter);
		},

		removeFilterFromBar: function (oEvent, oContext) {
			let sText = oEvent.getParameter("removedTokens")[0].getProperty("text").split("(")[0];
			let filterItem = sText.slice(-1) === " " ? sText.slice(0, -1) : sText;
			let oCtrlFilterDialog = oContext.getView().byId("filterDialog");
			oCtrlFilterDialog.getFilterItems().forEach(item => {
				if (item.getProperty("text") === filterItem) {
					if (item.getCustomControl) {
						item.setFilterCount(0);
						if (item.getCustomControl().setValue)
							item.getCustomControl().setValue();
					} else {
						item.getItems().forEach(itemS => itemS.setSelected(false));
					}
					oCtrlFilterDialog.fireConfirm();
				}
			});
		},

		resetFilters: function (oContext) {
			oContext.searchFilters = "";
			oContext.lastFilters = [];
			oContext.oStore = {};
			oContext.byId("multiInput").removeAllTokens();
			oContext.getView().getModel("localModel").getData().bVsdFilterBarVisible = false;
			oContext.getView().getModel("localModel").refresh();

			let oFD2 = oContext.getView().byId("filterDialog");
			oFD2?.clearFilters();

			if (oFD2) {
				oFD2.getFilterItems().forEach(item => {
					if (item.getCustomControl) {
						item.setFilterCount(0);
						if (item.getCustomControl().setValue)
							item.getCustomControl().setValue();
					}
				});
			}

			oContext.refreshSPDStatusFilter?.();

			oContext.getView().getModel("filterModel")?.refresh();
			oContext.getView().getModel("localModel")?.refresh();

		},

		_setFilterBarVisibilityForServices: function(oContext){
			if (oContext.byId("multiInput").getTokens().length) {
				oContext.getView().byId("vsdFilterBar").setVisible(true);
				oContext._oData.filtersSetted = true;
			} else {
				oContext.getView().byId("vsdFilterBar").setVisible(false);
				oContext._oData.filtersSetted = false;
			}
			oContext.getView().getModel("localModel").refresh();
		},

		_buildTextForMultiSelect: function(item, sTextBuilder, oContext){

			let addVal = true;

			if (item.getItems()) {
				item.getItems().forEach(itemS => {
					addVal = true;
					if (item.getText() === "Status" && oContext.oStore["Status"]) {
						addVal = oContext.oStore[item.getText()].includes(itemS.getProperty("key"))
					}
					if (itemS.getSelected() && addVal) {
						if (sTextBuilder !== "") {
							sTextBuilder += ", ";
						}
						sTextBuilder += itemS.getProperty("text");
					}
				});
			}

			return sTextBuilder;
		},

		refreshMultiInput: function (oContext) {

			if (!oContext.getView().byId("filterDialog")) {
				return;
			}

			let scopeView = oContext.getView().getModel("localModel").getData().scopeView

			if(scopeView && scopeView !== "services")
				return;
				

			let sTextBuilder = "";
			oContext.byId("multiInput").removeAllTokens();

			oContext.getView().byId("filterDialog").getFilterItems().forEach(item => {
				sTextBuilder = "";

				try {
					sTextBuilder = this._buildTextForMultiSelect(item, sTextBuilder, oContext);
				} catch (oError) { }
				try {
					if (item.getCustomControl?.().getValue()) {
						if (typeof item.getCustomControl().getValue() === "object") {
							sTextBuilder += "...";
						} else {
							sTextBuilder += "'" + item.getCustomControl().getValue() + "'";
						}
					}
				} catch (oError) { }

				if (sTextBuilder !== "") {
					sTextBuilder = item.getProperty("text") + " (" + sTextBuilder + ")";
					oContext.byId("multiInput").addToken(new sap.m.Token().setText(sTextBuilder));
				}

			});
			 
			this._setFilterBarVisibilityForServices(oContext);
		},

		generateFilterStringForDateFilters: function(oFilterItem, oContext, aParams){
			
			let oFilterItemVal = oFilterItem.getCustomControl().getProperty("value");
			oContext.lastFilters.push(oFilterItemVal);
			let date = oFilterItem.getKey();

			if (oFilterItemVal) {

				if (!oContext.oStore[oFilterItem.getText()])
					oContext.oStore[oFilterItem.getText()] = new Array();

				oContext.oStore[oFilterItem.getText()].push(oFilterItemVal);
				oContext.oStore[oFilterItem.getText()].push(oFilterItemVal["values"][0].toString());
				if (oFilterItemVal["values"][1])
					oContext.oStore[oFilterItem.getText()].push(oFilterItemVal["values"][1].toString());
			}

			if (oFilterItemVal && oFilterItemVal['operator'] === "DATE") {
				aParams = aParams + this._generateFilterString(date, oFilterItemVal["values"][0], oFilterItem.getCustomControl()
					.getProperty("value")["values"][0]);

			} else if (oFilterItemVal && (oFilterItemVal["operator"] ===
				"FROM" ||
				oFilterItemVal["operator"] === "TO")) {

				let startDateStart = new Date(new Date(oFilterItemVal["values"][0]).setHours(0, 0, 0));
				let operator = oFilterItemVal["operator"] === "TO" ? "le" : "ge";

				aParams = aParams + "(" + date + " " + operator + " datetime'" + startDateStart.toJSON().slice(0, -5) + "') and ";

			} else if (oFilterItemVal && oFilterItemVal['operator'] ===
				"DATERANGE") {

				aParams = aParams + this._generateFilterString(date, oFilterItemVal["values"][0], oFilterItem.getCustomControl()
					.getProperty("value")["values"][1]);

			} else if (oFilterItemVal) {

				let value = oFilterItemVal["values"][0],
					type = oFilterItemVal["operator"];

					let {start, end} = this._buildStartAndEndForDateFilters(new Date(),  new Date(), value, type);

				aParams = aParams + this._generateFilterString(date, start, end);
			}

			return aParams;

		},

		_generatePartialParameterForStandardFiltersHome: function(element, partialPar, partialVal){
			if (element.getParent().getProperty("text") === 'Phase')
				partialPar = `${element.getParent().getProperty("text")}ID eq '${partialVal}'`;
			else if (element.getParent().getProperty("text") === 'Type')
				partialPar = `ItemType eq '${partialVal}'`;
			else if (element.getParent().getProperty("text") === 'Rating')
				partialPar = `RatingID eq '${partialVal}'`;
			else if (element.getParent().getProperty("text") === 'Component Status')
				partialPar = `ComponentStatusID eq '${partialVal}'`;

			return partialPar;
		},

		_generatePartialParameterForStandardFiltersSPD: function(element, partialPar, partialVal){
			
			if (element.getParent().getProperty("text") === 'Phase')
				partialPar = element.getParent().getProperty("text") + "ID eq '";

			else if (element.getParent().getProperty("text") === 'Type')
				partialPar = "Item" + element.getParent().getProperty("text") + " eq '";

			else if (element.getParent().getProperty("text") === 'Status')
				partialPar = "ItemStatusID eq '";

			else if (element.getParent().getProperty("text") === 'Rating')
				partialPar = "RatingID eq '";

			else
				partialPar = "ComponentStatusID eq '";

			if (element.getProperty("key") !== "None" && element.getProperty(
					"key") !== "No Rating") {
				if (element.getProperty("key") === 'ZSK00001|E0018') {
					partialPar += 'DRAFT';
				} else {
					partialPar += partialVal;
				}
			}

			partialPar += "'";

			return partialPar
		},

		_generatePartialParameterForStandardFiltersProject: function(element, partialPar, partialVal){
			if (element.getParent().getProperty("text") === 'Deployment Type')
				partialPar = "DeploymentType eq '";

			else if (element.getParent().getProperty("text") === 'Status')
				partialPar = "StatusDescr eq '";

			else
				partialPar = "SapInvolvement eq '";

			return partialPar + partialVal +"'"
		},

		_handleElementOfMultiSelect: function(oContext, element, partialVal){
			if (!oContext.oStore[element.getParent().getProperty("text")])
					oContext.oStore[element.getParent().getProperty("text")] = new Array();

			oContext.oStore[element.getParent().getProperty("text")]
				.push(element.getProperty("key"));

			if (["No Rating", "None"].includes(element.getProperty("key"))) partialVal = "";

			return partialVal;
		},

		_triggerConstructionFunction: function(partialPar, calledFrom, partialVal, element){
			if(calledFrom === "HomeServices")
				partialPar = this._generatePartialParameterForStandardFiltersHome(element, partialPar, partialVal);
			else if(calledFrom === "SPD")
				partialPar = this._generatePartialParameterForStandardFiltersSPD(element, partialPar, partialVal);
			else 
				partialPar = this._generatePartialParameterForStandardFiltersProject(element, partialPar, partialVal);

			return partialPar;
		},

		_generateParametersForStandardFilters: function(aItemsSelected, oContext, calledFrom){

			let addPar = false;
			let groupPar = "";
			let aParamsFilter = "";
			
			for (const element of aItemsSelected) {
				let partialPar = "";
				let partialVal = element.getProperty("key");
				partialVal = this._handleElementOfMultiSelect(oContext, element, partialVal);

				partialPar = this._triggerConstructionFunction(partialPar, calledFrom, partialVal, element);

				if (partialPar !== "") {
					if (element.getParent().getProperty("text") !== groupPar) {
						if (addPar) {
							aParamsFilter += ")";
						}
						groupPar = element.getParent().getProperty("text")
						addPar = false
					} else if (addPar) {
						aParamsFilter += " or ";
					}
					if (!addPar) {
						addPar = true;
						aParamsFilter += " and (";
					}
					aParamsFilter += partialPar;
				}
			}

			return aParamsFilter;
		},

		generateFilterStringForStandardFiltersServices: function(aItemsSelected, oContext, aParams, calledFrom){
			if (aItemsSelected.length !== 0) {

				let aParamsFilter = this._generateParametersForStandardFilters(aItemsSelected, oContext, calledFrom);

				if (aParamsFilter !== "") {
					aParamsFilter += ")"
					aParams += aParamsFilter
				}
			}

			return aParams;
		},

		_handleFreeTextColumns: function(calledFor){
			let columns;
			if(calledFor === "services")
				columns = Constants.getFreeTextColumnsServices();
			else
				columns = Constants.getFreeTextColumnsProjects();

			return columns;

		},

		generateFilterStringForFreeText: function(oFilterItem, oContext, aParams, calledFor){
			if (!oContext.oStore[oFilterItem.getKey()])
				oContext.oStore[oFilterItem.getKey()] = new Array();

			oContext.oStore[oFilterItem.getKey()]
				.push(oFilterItem.getCustomControl().getValue());

			aParams = aParams + " substringof('" + oFilterItem.getCustomControl().getValue().toUpperCase() + "'," + oFilterItem.getKey();

			const freeTextColumns = this._handleFreeTextColumns(calledFor);

			if (freeTextColumns.includes(oFilterItem.getKey())) {
				aParams += "UC) and ";
			} else {
				aParams += ") and ";
			}

			return aParams;

		}
    }
})