sap.ui.define("com/sap/ui/hep/util/TablePersoServicePlans",
    [
        "com/sap/ui/hep/util/TablePersoBaseService"
    ],
    function (TablePersoBaseService) {
        "use strict";

        const PersoService = TablePersoBaseService.extend("com.sap.ui.hep.util.TablePersoServicePlans", {
            constructor: function () {
                TablePersoBaseService.call(this, "tablePerso-servicePlansList.json");
            },
        });

        return new PersoService();
    }, /* bExport= */ true);
