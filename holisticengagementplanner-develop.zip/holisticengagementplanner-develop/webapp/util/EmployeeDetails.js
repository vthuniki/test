sap.ui.define([
	"com/sap/ui/hep/model/formatter",
	"sap/base/Log",
	"com/sap/ui/hep/reuse/BaseTools"

], function (Formatter, Log, BaseTools) {
	"use strict";

	return {

		_loadFragment: function (oFragmentController, oView, sFragmentPath, fnInitialCallback) {
			return BaseTools.loadFragment(oFragmentController, oView, sFragmentPath, fnInitialCallback);
		},

		_loadEmployeePopover: function (sUserId, oView, oEvent, oSource) {
			if (sUserId) {
				this._pEmployeePopover ??= this._loadFragment(this, oView, "com.sap.ui.hep.view.fragment.EmployeePopover");
				this._pEmployeePopover.then(oPopover => {
					this._setModel(oPopover, sUserId);
					oPopover.openBy(oSource ?? oEvent.getSource());
				});
			}
		},

		_setModel(oPopover, sId) {
			let oUserModel = new sap.ui.model.json.JSONModel();
			this._loadUser(oPopover, sId);
			oPopover.setModel(oUserModel);
		},

		_loadUser: function (oPopover, sUserId) {
			this.popover = oPopover;
			$.ajax({
				url: Formatter.linkToSapIt(sUserId).employeeData,
				oPopover: oPopover
			})
				.done(this._loadUserDone.bind(this))
				.fail(this._loadUserFail.bind(this));
		},

		_loadUserDone: function (oData) {
			let oPopover = this.popover;
			oPopover.getModel().setData(oData);
			oPopover.getModel().refresh();
		},

		_loadUserFail: function (jqXHR, textStatus, errorThrown) {
			Log.warning("Failed to fetch UserInfo", `jqXHR=[${jqXHR}], textStatus=[${textStatus}], errorThrown=[${errorThrown}]`, "sapit");
		},

		onPhonePress: function (oEvent) {
			let phoneNumber = oEvent.getSource().getProperty("text");
			sap.m.URLHelper.triggerTel(phoneNumber);
		},
		onMailPress: function (oEvent) {
			let mailAdress = oEvent.getSource().getProperty("text");
			sap.m.URLHelper.triggerEmail(mailAdress);
		},

		displayEmployeePopover: function (oEvent, oView, sModelName, sUserIdPropertyName) {
			let oSource = oEvent.getSource(),
				sUserId;

			if (oSource.getBindingContext(sModelName) === undefined) {
				sUserId = oSource.getModel(sModelName).getData()[sUserIdPropertyName];
			} else {
				let sPath = oSource.getBindingContext(sModelName).sPath;
				let sItemsColletion = sPath.split("/")[1];
				let iIndex = parseInt(sPath.split("/")[2], 10);
				sUserId = oView.getModel(sModelName).getData()[sItemsColletion][iIndex][sUserIdPropertyName];
			}
			if (sUserId === undefined) {
				sUserId = oSource.getText().split("(")[1].split(")")[0];
			}
			this._loadEmployeePopover(sUserId, oView, oEvent, oSource);
		},

		displayEmployeePopoverGantt: function (oEvent, oView, sModelName, sUserIdPropertyName) {
			let oSource = oEvent.getSource();
			let pathGantt = oSource.getBindingContext("ganttModel").getPath();
			let sUserIdGantt;
			if (oSource.getBindingContext(sModelName) === undefined) {
				sUserIdGantt = oSource.getModel(sModelName).getData()[sUserIdPropertyName];
			} else {
				sUserIdGantt = oSource.getBindingContext("ganttModel").getProperty(pathGantt).ConsultantID;
			}
			this._loadEmployeePopover(sUserIdGantt, oView, oEvent, oSource);
		},

		displayEmployeePopoverGeneric: function (oEvent, oView, sUserID) {
			let oSource = oEvent.getSource();
			this._loadEmployeePopover(sUserID, oView, oEvent, oSource);
		}

	};
});
