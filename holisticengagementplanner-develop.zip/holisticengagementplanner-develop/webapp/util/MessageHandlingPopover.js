sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/m/MessagePopover",
	"sap/m/MessageItem"
], function (JSONModel, MessagePopover, MessageItem) {
	"use strict";

	return {
		initializeMsgHandlling: function (oContext) {
			let oView = oContext.getView();
			let oMessageTemplate = new MessageItem({
				type: "{type}",
				title: "{title}",
				activeTitle: "{active}",
				description: "{description}",
				subtitle: "{subtitle}",
				markupDescription: "{markupDescription}",
				longtextUrl: "{longtextUrl}"
			});

			let oMessagePopover = new MessagePopover({
				items: {
					path: "/messages",
					template: oMessageTemplate
				},
				activeTitlePress: function (evt) {
					let oMsgItemSelected = evt.getParameter("item").getBindingContext().getObject();
					if (oView.byId(oMsgItemSelected.id) !== undefined ||
						oView.byId(oMsgItemSelected.idForFocus) !== undefined) {
						let oControl = oView.byId(oMsgItemSelected.id) === undefined ?
							oView.byId(oMsgItemSelected.idForFocus) : oView.byId(oMsgItemSelected.id);
						oControl.focus();
					}
				}
			});
			let viewModel = new JSONModel({
				msgButtonEnabled: false
			});
			let viewModelMsgBE = new JSONModel();
			oContext.getView().setModel(viewModel, "messagesModel");
			oContext.getView().setModel(viewModelMsgBE, "messageModelBE");
			oMessagePopover.setModel(viewModel);
			oContext.oMessagePopover = oMessagePopover;
			this.oMessagePopover = oMessagePopover;
			this.oView = oView;
			this.oContext = oContext;
		},

		_setMessageDataEmpty: function(oMsgData){
			oMsgData.messages = [];
			oMsgData.messagesLength = [];
			oMsgData.msgButtonEnabled = false;

			return oMsgData;
		},

		_createMessageObject(id, type, title, isInDom, description, subtitle, longtextUrl){
			return {
				timestamp: new Date().getTime(),
				id: id,
				type: type,
				title: title,
				active: isInDom !== undefined,
				description: description,
				subtitle: subtitle,
				markupDescription: true,
				longtextUrl: longtextUrl
			};
		},

		_handleDisplayLogic(oMsgData, oContext, oButton, params){
			if (oMsgData.messages.length > 0) {
				oContext?.oMessagePopover.close();
				oMsgData.msgButtonEnabled = true;
				if (oButton.$()[0] && !oContext.bKeepMessagePopoverClosed) {
					if (!params?.trigger) {
						oContext.oMessagePopover.openBy(oButton);
					} else if (params?.trigger && params.trigger !== "deleteItem" && params.trigger !== "createItem" && params.trigger !==
							"saveItem") oContext.oMessagePopover.openBy(oButton);
				}
			} else {
				oMsgData.msgButtonEnabled = false;
				oMsgData.messagesLength = "";
				oContext.oMessagePopover.close();
			}

			oContext.getView().getModel("messagesModel").refresh();
		},

		addNewMessageseInsidePopover: function (...parameters) {

			let [id, type, title, description, subtitle, oContext, params, link, longtextUrl] = parameters

			oContext = oContext || this.oContext;

			let isInDom = oContext.getView().byId(id);
			let oButton = oContext.getView().byId("messagePopoverButton") ? oContext.getView().byId("messagePopoverButton") : sap.ui.getCore().byId(
				$("[id$=messagePopoverButton]").attr("id"));

			let oMsgData = oContext.getView().getModel("messagesModel").getData();
			if (oMsgData.messages === undefined) {
				oMsgData = this._setMessageDataEmpty(oMsgData);
			}
			let elm = {
				id: id
			};
			if (this._checkIfIsInsideModel(oMsgData, elm) === false) {
				oMsgData.messages.push(this._createMessageObject(id, type, title, isInDom, description, subtitle, longtextUrl));
			}
			if (link !== undefined) {
				let oLastItem = oMsgData.messages[oMsgData.messages.length - 1];
				oLastItem.link = link;
			}

			oMsgData.messagesLength = oMsgData.messages.length;
			oMsgData.messages.reduce((acc, cur) => acc.some(x => x.id === cur.id) ? acc : acc.concat(cur), []);
			oContext.getView().getModel("messagesModel").refresh();
			oMsgData.messages.sort(this.compare);

			this._handleDisplayLogic(oMsgData, oContext, oButton, params);
		},

		_checkIfIsInsideModel: function (oMsgData, elm) {
			let idOfelm = elm.id === undefined ? elm.getId() : elm.id;
			if (oMsgData.messages !== undefined) {
				let aMsgAlreadyIn = oMsgData.messages.filter(elmM => elmM.id === idOfelm);
				return aMsgAlreadyIn.length > 0;
			} 

			return false;
		},

		removeMsgFromPopover: function (id, oContext) {
			oContext = oContext || this.oContext;
			let oMsgData = oContext.getView().getModel("messagesModel").getData();
			if (oMsgData.messages !== undefined) {
				oMsgData.messages = oMsgData.messages.filter(elm => elm.id !== id);
				oMsgData.messagesLength = oMsgData.messages.length;

				oMsgData.messages.sort(this.compare);
				if (oMsgData.messages.length > 0) {
					oMsgData.msgButtonEnabled = true;
				} else {
					oMsgData.msgButtonEnabled = false;
					oMsgData.messagesLength = "";
					oContext.oMessagePopover.close();
				}
				oContext.getView().getModel("messagesModel").refresh();
			}
		},

		fnRemoveMessagesOlderThan: function(nOlderThanSeconds, sMessageId, oContext){
			oContext = oContext || this.oContext;
			let oMessageModel = oContext.getView().getModel("messagesModel");
			if (oMessageModel.getData().messages){
				let dNow = new Date();
				let aMsgFiltered = oMessageModel.getData().messages.filter(oMsg => {
					//in case sMessageId is given, only filter out messages with that Id
					return (sMessageId && !oMsg.id.includes(sMessageId)) ? true : new Date(oMsg.timestamp).getTime() + nOlderThanSeconds * 1000 > dNow;
				})
				oMessageModel.getData().messages = aMsgFiltered;
				if (aMsgFiltered.length === 0) {
					oMessageModel.msgButtonEnabled = false;
					oContext.oMessagePopover.close();
				}
				oMessageModel.messagesLength = aMsgFiltered.length.toString();
				oMessageModel.refresh();
			}
		},

		compare: function (a, b) {
			const msgA = a.timestamp;
			const msgB = b.timestamp;
			let comparison = 0;
			if (msgA < msgB) {
				comparison = 1;
			} else if (msgA > msgB) {
				comparison = -1;
			}
			return comparison;
		},
		//=================PROJECT DETAILS==================================================================

		_filterMessages: function (oMsgData, sKey, oContext) {
			oMsgData.messages = oMsgData.messages.filter(elmM => elmM.id !== sKey);
			oContext.getView().getModel("messagesModel").getData().messages = oMsgData.messages;
			oContext.getView().getModel("messagesModel").refresh();
		},

		_createModelDetails: function(oContext, bEngagementCase){
			return {
				"ProjectName": {
					"State": oContext._oData.projectNameValueState,
					"ValueStateText": bEngagementCase ? oContext.getResourceBundle().getText("ProjectDetails.EngagementName.Mandatory") : oContext.getResourceBundle()
						.getText("ProjectDetails.ProjectName.Mandatory")
				},
				"GoLiveDate": {
					"State": oContext._oData.projectGoLiveDateValueState,
					"ValueStateText": oContext._oData.projectGoLiveDateValueText
				},
				"ProjectDescription": {
					"State": oContext._oData.projectDescriptionValueState,
					"ValueStateText": bEngagementCase ? oContext.getResourceBundle().getText("ProjectDetails.EngagementDescription.Mandatory") : oContext
						.getResourceBundle().getText("ProjectDetails.ProjectDescription.Mandatory")
				},
				"EngagementCase": {
					"State": oContext._oData.projectCaseValueState,
					"ValueStateText": oContext.getResourceBundle().getText("ProjectDetails.EngagementCase.Mandatory")
				},
				"ProjectStartDate": {
					"State": oContext._oData.projectStartDateValueState,
					"ValueStateText": oContext._oData.projectStartDateValueText
				},
				"ProjectEndDate": {
					"State": oContext._oData.projectEndDateValueState,
					"ValueStateText": oContext._oData.projectEndDateValueText
				}
			};

		},

		addMessagesToPopoverProjectDetails: function (oContext) {
			let oButton = oContext.getView().byId("messagePopoverButton") ? oContext.getView().byId("messagePopoverButton") : sap.ui.getCore().byId(
				$("[id$=messagePopoverButton]").attr("id"));
			let oMsgData = oContext.getView().getModel("messagesModel").getData();
			let oMsgDataBE = oContext.getView().getModel("messageModelBE").getData();
			let bEngagementCase = oContext.getView().getModel("projectDetails").getData().ReasonCode === "ENG1" || oContext.getView().getModel(
				"projectDetails").getData().ReasonCode === "ENG2";

			if (!oMsgData.messages) {
				oMsgData.messages = [];
				oMsgData.messagesLength = 0;
				oMsgData.msgButtonEnabled = false;
			}

			this.addNotesMessageInPopover(oContext);

			let oModelDetails = this._createModelDetails(oContext, bEngagementCase);

			for (let key in oModelDetails) {
				if (oModelDetails.hasOwnProperty(key)) {
					let elm = oModelDetails[key];
					if (this._checkIfIsInsideModelPrjDetails(oMsgData, key) === false) {
						oMsgData.messages.push({
							timestamp: new Date().getTime(),
							id: key,
							active: true,
							type: elm.State,
							title: this._getTitleForMessage(key, bEngagementCase),
							description: elm.ValueStateText,
							subtitle: elm.ValueStateText
						});
					} else if (oModelDetails[key].State === "None") {
						this._filterMessages(oMsgData, key, oContext);
					}
				}
			}
			let oMsgDataUnique = oMsgData.messages.reduce((acc, cur) => acc.some(x => x.id === cur.id) ? acc : acc.concat(cur), []);
			oMsgData
				.messages = oMsgDataUnique.length === 0 ? oMsgData.messages : oMsgDataUnique;
			oMsgData.messages = oMsgData.messages.filter(
				iterator => iterator.type !== "None");
			Array.prototype.push.apply(oMsgData.messages, oMsgDataBE.messages);
			oMsgData.messages.sort(this.compare);
			oMsgData.messagesLength = oMsgData.messages.length;
			if (oMsgData.messages.length > 0) {
				oMsgData.msgButtonEnabled = true;
				oContext.oMessagePopover.close();
				oContext.oMessagePopover.openBy(oButton);
			}
			oContext.getView().getModel("messagesModel").refresh();
		},

		_getTitleForMessage: function (sKey, bEngagementCase) {
			switch (sKey) {
			case "ProjectDescription":
				return bEngagementCase ? "Engagement Description" : "Project Description";
			case "ProjectName":
				return bEngagementCase ? "Engagement Name" : "Project Name";
			default:
				return sKey;
			}
		},

		addNotesMessageInPopover: function (oContext) {
			let oButton = oContext.getView().byId("messagePopoverButton") ? oContext.getView().byId("messagePopoverButton") : sap.ui.getCore().byId(
				$("[id$=messagePopoverButton]").attr("id"));
			let oNotesModel = oContext.getView().getModel("oModelNotes").getData().newNoteValid;
			let oMsgData = oContext.getView().getModel("messagesModel").getData();
			if (!oMsgData.messages) {
				oMsgData.messages = [];
				oMsgData.messagesLength = 0;
				oMsgData.msgButtonEnabled = false;
			}
			let oModelNotesWithID = [];
			for (let key in oNotesModel) {
				if (key !== "save") {
					oModelNotesWithID.push({
						timestamp: new Date().getTime(),
						ID: key + "NoteID",
						idFocus: "notesSection",
						elm: key,
						state: oNotesModel[key]
					});
				}
			}
			oModelNotesWithID.forEach(elm => {
				if (this._checkIfIsInsideModelPrjDetails(oMsgData, elm.ID) === false) {
					oMsgData.messages.push({
						timestamp: new Date().getTime(),
						id: elm.ID,
						idForFocus: elm.idFocus,
						type: elm.state,
						active: true,
						title: oContext.getResourceBundle().getText("Notes." + elm.elm),
						description: oContext.getResourceBundle().getText("Note.Error." + elm.elm),
						subtitle: oContext.getResourceBundle().getText("Note.Error." + elm.elm)
					});
				} else if (elm.state === "None") {
					oMsgData.messages = oMsgData.messages.filter(elmM => elmM.id !== elm.ID);
				}
			});
			oMsgData.messages = oMsgData.messages.filter(iterator => iterator.type !== "None");
			oMsgData.messagesLength = oMsgData.messages.length;
			if (oMsgData.messages.length > 0) {
				oMsgData.msgButtonEnabled = true;
				oContext.oMessagePopover.openBy(oButton);
			}
			oMsgData.messages.sort(this.compare);
			oContext.getView().getModel("messagesModel").refresh();
		},

		addNewMessageseInsidePopoverPrjDetails: function (id, type, title, description, subtitle, oContext, active) {
			let isInDom = oContext.getView().byId(id);
			let oButton = oContext.getView().byId("messagePopoverButton") ? oContext.getView().byId("messagePopoverButton") : sap.ui.getCore().byId(
				$("[id$=messagePopoverButton]").attr("id"));
			let oMsgData = oContext.getView().getModel("messagesModel").getData();
			if (oMsgData.messages === undefined) {
				oMsgData.messages = [];
				oMsgData.messagesLength = 0;
				oMsgData.msgButtonEnabled = false;
			}

			if (this._checkIfIsInsideModelPrjDetails(oMsgData, id) === false || type === "Success") {
				oMsgData.messages.push({
					timestamp: new Date().getTime(),
					id: id,
					type: type,
					title: title,
					active: isInDom !== undefined,
					description: description,
					subtitle: subtitle
				});
			}
			oMsgData.messages.reduce((acc, cur) => acc.some(x => x.id === cur.ID) ? acc : acc.concat(cur), []);
			oMsgData.messagesLength = oMsgData.messages.length;

			oMsgData.messages.sort(this.compare);
			oContext.getView().getModel("messagesModel").refresh();
			if (oMsgData.messages.length > 0) {
				oMsgData.msgButtonEnabled = true;
				oContext.oMessagePopover.close();
				oContext.oMessagePopover.openBy(oButton);
			}
		},

		_checkIfIsInsideModelPrjDetails: function (oMsgData, elm) {
			let aMsgAlreadyIn = oMsgData.messages.filter(elmM => elmM.id === elm);
			return aMsgAlreadyIn.length > 0
		},

		_checkIfIsInsideModelPhase: function (oMsgData, elm) {
			let aMsgAlreadyIn = oMsgData.messages.filter(elmM => elmM.id === elm.ID);
			return aMsgAlreadyIn.length > 0
		},

		resetMessageDataModel: function (oView) {
			oView.getModel("messagesModel").setData({
				msgButtonEnabled: false
			});
			oView.getModel("messagesModel").refresh();
		},

		clearAllMessages: function (oView, oMessagePopover) {
			oView = oView || this.oView;
			this.resetMessageDataModel(oView);
			if (oMessagePopover) oMessagePopover.close();
			else this.oMessagePopover.close();
			oView.getModel("messageModelBE").setData({});
			oView.getModel("messageModelBE").refresh();
		},

		_handleButtonTypeFormatter: function(messageType, sHighestSeverityIcon){
			switch (messageType) {
				case "Error":
					return "Negative";
				case "Warning":
					 return sHighestSeverityIcon !== "Negative" ? "Critical" : sHighestSeverityIcon;
				case "Success":
					return sHighestSeverityIcon !== "Negative" && sHighestSeverityIcon !== "Critical" ? "Success" :
						sHighestSeverityIcon;
				default:
					 return !sHighestSeverityIcon ? "Neutral" : sHighestSeverityIcon;
				}
		},

		msgButtonTypeFormatter: function (oView) {
			let sHighestSeverityIcon = "Neutral";

			if (oView.getModel("messagesModel")) {
				let aMessages = oView.getModel("messagesModel").getData().messages;
				if (aMessages) {
					aMessages.forEach(function (sMessage) {
						sHighestSeverityIcon = this._handleButtonTypeFormatter(sMessage.type, sHighestSeverityIcon);
					}.bind(this));
				}
			}
			return sHighestSeverityIcon;
		},

		_handleSeverityMessage: function(severityIcon){
			switch (severityIcon) {
				case "Negative":
					return "Error";

				case "Critical":
					return "Warning";

				case "Success":
					return "Success";

				default:
					return "Information";
				}
		}, 

		highestSeverityMessages: function (oView) {
			let sHighestSeverityIconType = this.msgButtonTypeFormatter(oView);
			let sHighestSeverityMessageType;
			let sDisplayNumber = "";

			if (oView.getModel("messagesModel")) {
				let aMessages = oView.getModel("messagesModel").getData().messages;
				if (aMessages) {
					sHighestSeverityMessageType = this._handleSeverityMessage(sHighestSeverityIconType);
					sDisplayNumber = oView.getModel("messagesModel").getData().messages.reduce(function (iNumberOfMessages, oMessageItem) {
						return sHighestSeverityMessageType ? (iNumberOfMessages + 1) : iNumberOfMessages;
					}, 0);
				}
			}
			return sDisplayNumber;
		},

		_handleButtonIcon: function(messageType, sIcon){
			switch (messageType) {
				case "Error":
					return "sap-icon://message-error";
				case "Warning":
					return sIcon !== "sap-icon://message-error" ? "sap-icon://message-warning" : sIcon;
				case "Success":
					return sIcon !== "sap-icon://message-error" && sIcon !== "sap-icon://message-warning" ? "sap-icon://message-success" : sIcon;
				default:
					return !sIcon ? "sap-icon://message-information" : sIcon;
				}
		},

		msgButtonIconFormatter: function (oView) {
			let sIcon = "sap-icon://message-information";

			if (oView.getModel("messagesModel")) {
				let aMessages = oView.getModel("messagesModel").getData().messages;
				if (aMessages) {
					aMessages.forEach((sMessage) => {
						sIcon = this._handleButtonIcon(sMessage.type, sIcon)
					});
				}
			}
			return sIcon;
		}
	};
});