sap.ui.define("com/sap/ui/hep/util/TablePersoProActivities",
    [
        "com/sap/ui/hep/util/TablePersoBaseService"
    ],
    function (TablePersoBaseService) {
        "use strict";

        const PersoService = TablePersoBaseService.extend("com.sap.ui.hep.util.TablePersoProActivities", {
            constructor: function () {
                TablePersoBaseService.call(this, "tablePerso-ProActivitiesTable.json");
            },
        });

        return new PersoService();
    }, /* bExport= */ true);
