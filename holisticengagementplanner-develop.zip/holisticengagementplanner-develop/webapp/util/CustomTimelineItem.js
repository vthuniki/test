sap.ui.define([
	"sap/suite/ui/commons/TimelineItem",
	"com/sap/ui/hep/reuse/Constants",
	"sap/suite/ui/commons/TimelineItemRenderer",
	"sap/ui/core/Control"
], function (TimelineItem, Constants, TimelineItemRenderer, Control) {
	"use strict";

	let CustomTimelineItem = TimelineItem.extend("com.sap.ui.hep.util.CustomTimelineItem", {
		metadata: {
			properties: {
				NoteType: {
					type: "string",
					defaultValue: ""
				},
				Text: {
					type: "string",
					defaultValue: ""
				},
				defaultAggregation: "embeddedControl",
				aggregation: {
					embeddedControl: {
						type: "sap.ui.core.Control",
						multiple: false
					}
				}
			}
		},
		renderer: function (oRm, oControl) {
			TimelineItemRenderer.render(oRm, oControl);
		}
	});



	CustomTimelineItem.prototype._readConstants = function () {
		return Constants;
	};

	CustomTimelineItem.prototype.getText = function () {

	};
	CustomTimelineItem.prototype.getDateTime = function () {};
	return CustomTimelineItem;

});
