sap.ui.define([
	"com/sap/ui/hep/reuse/Constants",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"com/sap/ui/hep/util/NavigationToExternalApps",
	"sap/ui/model/json/JSONModel",
	"com/sap/ui/hep/reuse/BaseTools"

], function (Constants, MessageToast, MessageBox, NavigationToExternalApps, JSONModel, BaseTools) {
	return {

		_loadFragment: function (oFragmentController, oView, sFragmentPath, fnInitialCallback) {
			return BaseTools.loadFragment(oFragmentController, oView, sFragmentPath, fnInitialCallback);
		},

		// ********************************************************************************************************
		// ******************************************* CONTRACT SECTION *******************************************
		// ********************************************************************************************************

		//
		// ************************************* READ contract assignment  *******************************************

		/**
		 *  READ contract assignments for an engagement case from BE.
		 *  Model "engCaseContracts" is exptected to exist in the using component (oContext)
		 *  It is filled with the result
		 *  @param {oContext} object - the controller context
		 *  @param {string} sCaseId - The case for which contracts are read
		 */
		_fnEngCaseContractSectionRead: function (oContext, sCaseId) {
			oContext._oData.busyContractsList = true;
			oContext._oModel.refresh();
			let entities = {};

			entities.servicePath = Constants.getServicePath();
			entities.entitySet = `ProjectSet('${sCaseId}')`;
			entities.expand = "toProjectContracts";
			entities.errorMessage = oContext.getResourceBundle().getText("Engagement.Contracts.error.BECall");
			entities.oContext = oContext;
			entities.currentView = oContext.getView();
			entities.callbackSuccess = (oData) => {

				oContext.getView().getModel("engCaseContracts").getData().results = oData.toProjectContracts.results;
				oContext.getView().getModel("engCaseContracts").getData().iNumberOfContracts = oData.toProjectContracts.results.length;

				// determine if we got at least one valid contract in the list
				let oValidContract = oData.toProjectContracts.results.find(elm => {
					return elm.ContrValid === true;
				});
				oContext.getView().getModel("engCaseContracts").getData().validContractFound = !!oValidContract;
				// find the main contract and store its id
				let oMainContract = oData.toProjectContracts.results.find(elm => {
					return elm.CaseMainContract === true;
				});
				oContext.getView().getModel("engCaseContracts").getData().mainContractId = oMainContract ? oMainContract.ContrId : "";
				oContext.getView().getModel("engCaseContracts").refresh();

				oContext.getView().getModel("projectDetails").getData().MainContractEngText = oData.MainContractEngText;
				oContext.getView().getModel("projectDetails").refresh();

				oContext.getView().byId("headingContractExpanded").rerender();
				oContext.getView().byId("headingContractSnapped").rerender();

				oContext._oData.busyContractsList = false;
				oContext._oModel.refresh();
			};
			oContext.readBaseRequest(entities);
		},

		_updateMainContractEngText: function (oContext) {
			if (oContext.getView().getModel("engCaseContracts").getData().results.length === 0) {
				oContext.getView().getModel("projectDetails").getData().MainContractEngText = "";
			} else {
				oContext.getView().getModel("engCaseContracts").getData().results.forEach((oContract) => {
					if (oContract.CaseMainContract)
						oContext.getView().getModel("projectDetails").getData().MainContractEngText = oContract.ContrItemDescription;
				});
			}
			oContext.getView().getModel("projectDetails").refresh();
		},

		//
		// ************************************* DELETE contract assignment *******************************************

		/**
		 *  Event Handler for when user presses "Delete button" for a contract assignemnt
		 *  Double checks, if the user really wants to delete. Only then calls the oData-Delete function
		 *  @param {oContext} object - the controller context
		 *  @param {object} oEvent - contains information about the event that has happend
		 */
		fnEngCaseContractSectionHandleDelete: function (oContext, oEvent) {
			// get contract assignment to delete
			let sPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			let oContractAssignment = oContext.getView().getModel("engCaseContracts").getProperty(sPath);

			// user confirmation, really delete?
			MessageBox.confirm(oContext.getResourceBundle().getText("Engagement.Contracts.confirmDeletion", [oContractAssignment.ContrId]), {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				emphasizedAction: MessageBox.Action.YES,
				onClose: (sAction) => {
					if (sAction === "YES") {
						// trigger the oData call to delete
						this._fnDeleteEngContract(oContext, oContractAssignment.CaseId, oContractAssignment.ContrId);
					}
				}
			});
		},

		/**
		 *  DELETE contract assignment to engagement case in BE
		 *  After sucessfull delete, the list of contract assignemnts is read again from BE
		 *  @param {oContext} object - the controller context
		 *  @param {sCaseId} string - id of the case
		 *  @param {sContrId} string - id of the contract
		 */
		_fnDeleteEngContract: function (oContext, sCaseId, sContractId) {
			oContext._oData.busyContractsList = true;
			oContext._oModel.refresh();

			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = `ProjectContractSet(CaseId='${sCaseId}',ContrId='${sContractId}')`;
			entities.errorMessage = oContext.getResourceBundle().getText("Engagement.Contracts.error.BECall");
			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.busyIndicator = "busyContractsList";
			entities.callbackSuccess = () => {
				this._fnEngCaseContractSectionRead(oContext, sCaseId);
			};
			oContext.deleteBaseRequest(entities);
		},

		//
		// ************************************* Open Forecast App *******************************************

		/**
		 *  Event Handler for when user presses "Open Forecast App" for a contract assignemnt
		 *
		 *  @param {oContext} object - the controller context
		 *  @param {object} oEvent - contains information about the event that has happend
		 */
		fnEngCaseContractSectionHandleOpenForecastApp: function (oContext, oEvent) {
			// get contract for which to show the forecast app
			let sPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			let oContractAssignment = oContext.getView().getModel("engCaseContracts").getProperty(sPath);

			// open new Tab with forescast app for the selected contract
			if (!$.isEmptyObject(oContractAssignment) && oContractAssignment.ContrForecastUrl) {
				NavigationToExternalApps.fnHandleLinkNavigation(oContractAssignment.ContrForecastUrl);
			}
		},

		//
		// ************************************* Show Account Statement *******************************************

		/**
		 *  Event Handler for when user presses "Open Account Statement" for a contract assignemnt
		 *
		 *  @param {oContext} object - the controller context
		 *  @param {object} oEvent - contains information about the event that has happend
		 */
		fnEngCaseContractSectionHandleShowAccountStatement: function (oContext, oEvent) {
			// get contract for which to show the account statement
			let sPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			let oContractAssignment = oContext.getView().getModel("engCaseContracts").getProperty(sPath);

			// open new Tab with account statement for the selected contract
			if (!$.isEmptyObject(oContractAssignment) && oContractAssignment.ContrId) {
				const sContractId = oContractAssignment.ContrId.padStart(10, "0");
				const sEnvironment = Constants.getAccount()[oContext.getView().getModel("appData").getData().account].type;

				let sUrl =
					`https://${Constants.getAccountStatementUrl()[sEnvironment]}v01Par=IP_CONTRACT_NO&v01Model=sap.epm:SELF_SER_PREMIUM_ENGAGEMENT_FO&v01Val=${sContractId}&mode=view`;

				NavigationToExternalApps.fnHandleLinkNavigation(sUrl);
			}

		},

		//
		// ************************************* EDIT contract assignment *******************************************

		/**
		 *  Event Handler for when user changes the main-flag for an assignment
		 *  Only one of the assignments can have the main flag.
		 *  This is checked and if user tries to set a second main flag in the list, system does not allow
		 *  In case the uesr action was OK, function _fnUpdateEngContract is called in order to update in BE
		 *  @param {oContext} object - the controller context
		 *  @param {oEvent} object - information about the event
		 */
		fnEngCaseContractSectionHandleMainFlag: function (oContext, oEvent) {
			if (oEvent.getParameter("selected")) {
				let sPath = oEvent.getSource().getBindingInfo("selected").binding.getContext().sPath;
				let sCaseId = oContext.getView().getModel("engCaseContracts").getProperty(sPath).CaseId;
				let sContrIdNew = oContext.getView().getModel("engCaseContracts").getProperty(sPath).ContrId;

				oContext._oData.busyContractsList = true;
				oContext._oModel.refresh();

				//this._updateMainContractEngText(oContext);
				//  just send the currently focused contract as new Main Contract to BE
				this._fnUpdateEngContract(oContext, sCaseId, sContrIdNew, true).then(() => {
					// then read new situation from BE and remove busy flag
					this._fnEngCaseContractSectionRead(oContext, sCaseId);
				});
			}
		},

		/**
		 *  UPDATE contract assignment to engagement case in BE
		 *  Only the main-flag can be updated
		 *  After sucessfull update, the currently assigned contracts are read again
		 *  @param {oContext} object - the controller context
		 *  @param {sCaseId} string - id of the case
		 *  @param {sContrId} string - id of the contract
		 *  @param {bMain} boolean - value to set in BE for the main flag
		 */
		_fnUpdateEngContract: function (oContext, sCaseId, sContractId, bMain) {
			return new Promise((resolve, reject) => {
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.updateMethod = "PUT";
				entities.entitySet = `ProjectContractSet(CaseId='${sCaseId}',ContrId='${sContractId}')`;
				entities.data = {
					CaseMainContract: bMain,
					ContrId: sContractId
				};
				entities.errorMessage = oContext.getResourceBundle().getText("Engagement.Contracts.error.BECall");
				entities.currentView = oContext.getView();
				entities.oContext = oContext;
				entities.callbackSuccess = () => {
					resolve();
				};
				oContext.updateBaseRequest(entities);
			});
		},

		//
		// ************************************* CREATE contract assignment *******************************************

		/**
		 *  CREATE contract assignment to engagement case in BE
		 *  After sucessfull update, the currently assigned contracts are read again from BE
		 *  @param {oContext} object - the controller context
		 *  @param {sCaseId} string - id of the case
		 *  @param {sContrId} string - id of the contract
		 */
		_fnCreateEngContract: function (oContext, sContrId, sEngCaseId) {
			oContext._oData.busyContractsList = true;
			oContext._oModel.refresh();
			let entities = {};

			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ProjectContractSet";
			entities.errorMessage = oContext.getResourceBundle().getText("Engagement.Contracts.error.BECall");
			entities.data = {
				"CaseId": sEngCaseId,
				"ContrId": sContrId
			};
			entities.oContext = oContext;
			entities.currentView = oContext.getView();
			entities.callbackSuccess = (oData) => {
				entities.oContext.getOwnerComponent().trackEvent("Add_ContractToEngagement");
				this._fnEngCaseContractSectionRead(oContext, sEngCaseId);
			};
			oContext.createBaseRequest(entities);
		},

		// ********************************************************************************************************
		// ************************************* POPUP Search Contracts *******************************************
		// ********************************************************************************************************

		// initialize data for popup
		fnInitialize: function (oContext, oCustomizing) {
			this.fnCallbackAfterChange = oCustomizing?.fnCallBackAfterValueChange;

			if (!oContext.getView().getModel("engCaseContractsSearchHelp")) {
				oContext.getView().setModel(new JSONModel({}), "engCaseContractsSearchHelp");
				oContext.getView().getModel("engCaseContractsSearchHelp").refresh();
			}
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().fieldCustomerIDVisible = oCustomizing?.bFieldCustomerIDVisible ?? true;
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().fieldSoldToVisible = oCustomizing?.bFieldSoldToVisible ?? false;
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().fieldServiceProductVisible = oCustomizing?.bFieldServiceProductVisible ?? false;
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().columnAssignedVisible = oCustomizing?.bColumnAssignedVisible ?? true;
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().ContrRelPartner = oCustomizing?.sContrRelPartner ?? "Yes";
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().showClearButton = oCustomizing?.bShowClearButton ?? false;
			oContext.getView().getModel("engCaseContractsSearchHelp").refresh();

			oContext.getView().getModel("localModel").getData().dropDownRelPart = [{
				key: "X",
				text: "Yes"
			}, {
				key: "",
				text: "No"
			}];

			this._bInitializedSearchPopup = true;
		},

		/**
		 *  Event Handler opens a dialog popup and directly triggers the search
		 *  @param {oContext} object - the controller context
		 *  @param {oEvent} object - information about the event
		 */
		fnEngCaseContractSearchPopupOpen: function (oContext, oEvent) {
			//set the search criteria, which are used when the search is triggered
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().CustomerID ||= oContext.getView().getModel('projectDetails').getData().CustomerID || "";
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().CustomerName = "";
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().ContrRelPartner ||= oContext.getView().getModel("engCaseContractsSearchHelp").getData().CustomerID ? "Yes" : "No";
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().ContrId = "";
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().ContrDescription = "";
			oContext.getView().getModel('engCaseContractsSearchHelp').getData().ServiceProduct = "";
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().iNumberOfContracts = 0;
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().results = {};
			oContext.getView().getModel("engCaseContractsSearchHelp").refresh();

			//open the popup
			this._pEngagementContractSearchDialog ??= this._loadFragment(oContext, oContext.getView(), "com.sap.ui.hep.view.Details.Engagement.fragment.EngCaseContractSearchPopup");
			this._pEngagementContractSearchDialog.then(oDialog => oDialog.open());

			this.fnEngCaseContractSearchPopupSearch(oContext);  //trigger the search directly
		},

		fnEngCaseContractSearchPopupSearch: function (oContext, oEvent) {
			let sCustomerId = oContext.getView().getModel('engCaseContractsSearchHelp').getData().CustomerID || oContext.getView().getModel('engCaseContractsSearchHelp').getData().SoldToId || "";
			let sCustomerName = oContext.getView().getModel('engCaseContractsSearchHelp').getData().CustomerName || oContext.getView().getModel('engCaseContractsSearchHelp').getData().SoldTo || "";
			let sContractRelPartner = oContext.getView().getModel('engCaseContractsSearchHelp').getData().ContrRelPartner === "Yes" ? "X" : "";
			let sContractId = oContext.getView().getModel('engCaseContractsSearchHelp').getData().ContrId;
			let sContractDesc = oContext.getView().getModel('engCaseContractsSearchHelp').getData().ContrDescription;
			let sServiceProduct = oContext.getView().getModel('engCaseContractsSearchHelp').getData().ServiceProduct ||= "";

			oContext._oData.busyEngCaseContractsSearchPopup = true;
			oContext._oModel.refresh();
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ContractSet";
			entities.filter = `substringof('${sCustomerId}',CustomerID) and substringof('${sCustomerName}',CustomerName) and substringof('${sContractId}',ContractID) and ` +
				`substringof('${sContractDesc}',ContractName) and substringof('${sServiceProduct}',ContractitemName) and ` +
				`( ProcessType eq 'ZS27' or ProcessType eq 'ZCTF' ) and IncludeRelPartners eq '${sContractRelPartner}'`;
			entities.mCustomUrlParameters = new Map().set("Source", "Case"); //the URL-Parameter ensures in BE, that the right coding in the QUERY_PROJECTCONTRACTS-method is called
			entities.errorMessage = oContext.getResourceBundle().getText("Engagement.Contracts.error.BECall");
			entities.oContext = oContext;
			entities.paginationTop = 100;
			entities.currentView = oContext.getView();
			entities.callbackSuccess = (oData) => {
				oContext._oData.busyEngCaseContractsSearchPopup = false;
				oContext._oModel.refresh();
				this._handleSuccesContractSearch(oData, oContext);
			};
			oContext.readBaseRequest(entities);
		},

		_handleSuccesContractSearch: function (oData, oContext) {
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().iNumberOfContracts = oData.results.length;
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().results = oData.results;
			if (oContext.getView().getModel("engCaseContracts")) {
				oContext.getView().getModel("engCaseContractsSearchHelp").getData().results.forEach((oFoundContr) => {
					oFoundContr.isAssigned = !oContext.getView().getModel("engCaseContracts").getData().results.every((oAssignedContr) => {
						return oAssignedContr.ContrId !== oFoundContr.ContractID;
					});
				});
			}
			oContext.getView().getModel("engCaseContractsSearchHelp").refresh();
		},

		/**
		 *  Event handler, that is triggered when the user manually closes the contract search popop
		 *  either via Cancel-button or by selecting an entry from the result list.
		 *  If the user selects an entry from the result list that exists already as assignemt, a
		 *  Message Toast is displayed in order to inform the user - and the popup is not closed
		 *  otherwise the popup is closed and method "this._fnCreateEngContract" is called to
		 *  assign the selected contract in BE.
		 *  @param {oContext} object - the controller context
		 *  @param {oEvent} object - information about the event
		 */
		fnEngCaseContractSearchPopupClose: function (oContext, oEvent) {
			let bClosePopup = true;
			if (oEvent.getParameters().listItem) {
				let sPath = oEvent.getParameters().listItem.getBindingContextPath();
				let sSelContractId = oContext.getView().getModel("engCaseContractsSearchHelp").getProperty(sPath).ContractID;
				let sEngCaseId = oContext.getView().getModel("projectDetails").getData().ProjectID;

				if (sEngCaseId) {
					//popup was used on Engagement-Tab "Assigned Contracts" to assign a new contract to the engagement
					if (oContext.getView().getModel("engCaseContractsSearchHelp").getProperty(sPath).isAssigned) {
						MessageToast.show(oContext.getResourceBundle().getText("Engagement.Contracts.SearchPopup.Result.toast.alreadyAssigned"));
						bClosePopup = false;
					} else this._fnCreateEngContract(oContext, sSelContractId, sEngCaseId);
				} else {
					//popup was used in another place - currently CreateEngagmentDialog to select a contractId
					let oSelectedContractData = oContext.getView().getModel("engCaseContractsSearchHelp").getProperty(sPath);
					this?.fnCallbackAfterChange(oSelectedContractData, 'None');
				}
			}
			if (bClosePopup) {
				this._pEngagementContractSearchDialog.then(oDialog => oDialog.close().destroy());
				this._pEngagementContractSearchDialog = undefined;
			}
			this.fnCallbackAfterChange = undefined;
			this._fnClearSearchFields(oContext);
		},

		fnEngCaseContractSearchPopupFilterBarClear: function (oContext, oEvent) {
			this._fnClearSearchFields(oContext);
			this.fnEngCaseContractSearchPopupSearch(oContext);
		},

		_fnClearSearchFields: function (oContext) {
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().CustomerID = "";
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().CustomerName = "";
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().SoldToId = "";
			oContext.getView().getModel("engCaseContractsSearchHelp").getData().SoldTo = "";
			oContext.getView().getModel('engCaseContractsSearchHelp').getData().ContrId = "";
			oContext.getView().getModel('engCaseContractsSearchHelp').getData().ContrDescription = "";
			oContext.getView().getModel('engCaseContractsSearchHelp').getData().ServiceProduct = "";
			oContext.getView().getModel('engCaseContractsSearchHelp').refresh();
		}
	};

});
