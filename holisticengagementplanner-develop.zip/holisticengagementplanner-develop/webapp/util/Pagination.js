/*eslint-env es6*/
sap.ui.define([
	"com/sap/ui/hep/reuse/Constants"

], function (Constants) {
	"use strict";
	return {

		goToNextPage: function (oContext, iNumberOfClicks, servicesSelected) {
			let clicks = 0,
				skip = 0,
				constant = servicesSelected ? Constants.getPaginationTopServices() : Constants.getPaginationTop();

			if (iNumberOfClicks < 0) {
				clicks += 1;
			} else {
				clicks = iNumberOfClicks + 1;
			}
			skip = clicks * constant;

			return {
				"clicks": clicks,
				"skip": skip
			};
		},

		goToPreviousPage: function (oContext, iNumberOfClicks, servicesSelected) {
			let skip,
				constant = servicesSelected ? Constants.getPaginationTopServices() : Constants.getPaginationTop(),
				clicks = iNumberOfClicks;

			if (iNumberOfClicks <= 1) {
				skip = 0;
				clicks -= 1;
			} else {
				clicks = iNumberOfClicks - 1;
				skip = clicks * constant;
			}

			return {
				"clicks": clicks,
				"skip": skip
			};
		},

		_paginationElements: function (oContext, iNumberOfItems, oNextPageButton, oPreviousPageButton, servicesSelected) {
			let iSkip = oContext._oData.paginationSkip,
				iTop = servicesSelected ? Constants.getPaginationTopServices() : Constants.getPaginationTop(),
				iClicks = oContext._oData.paginationClicks;


			oContext._oData.paginationIntervalStart = iTop * iClicks + 1;
			if (iNumberOfItems === "0" || iNumberOfItems === 0) {
				oContext._oData.paginationIntervalStart = 0;
			}
			oContext._oData.paginationIntervalEnd = iSkip + iTop;

			if (iSkip < iNumberOfItems) {
				oContext._oData.paginationNextBtnEnabled = true;
			}
			if (iSkip >= iTop) {
				oContext._oData.paginationPrevBtnEnabled = true;
			}
			if (iSkip >= (iNumberOfItems - iTop)) {
				oContext._oData.paginationNextBtnEnabled = false;
				oContext._oData.paginationIntervalEnd = iNumberOfItems;
			}
			if (iSkip === 0) {
				oContext._oData.paginationPrevBtnEnabled = false;
			}
			oContext._oModel.refresh();

			if (oNextPageButton) {
				oNextPageButton.setEnabled(oContext._oData.paginationNextBtnEnabled);
			}
			if (oPreviousPageButton) {
				oPreviousPageButton.setEnabled(oContext._oData.paginationPrevBtnEnabled);
			}
		}
	};
});
