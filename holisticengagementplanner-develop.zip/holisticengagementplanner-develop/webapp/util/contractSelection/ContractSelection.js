/*eslint no-unused-expressions: [0, { "allowTernary": true }]*/
sap.ui.define(
	[
		"com/sap/ui/hep/reuse/Constants",
		"com/sap/ui/hep/model/formatter",
		"com/sap/ui/hep/reuse/BaseRequest",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/Fragment",
		"com/sap/ui/hep/util/Pagination",
		"com/sap/ui/hep/util/customerSelection/CustomerSelection"
	],
	function (Constants, Formtter, BaseRequest, JSONModel, Fragment, Pagination, CustomerSelection) {
		return {

			formatter: Formtter,
			pagination: Pagination,

			

			fnGetDetailsForContract: function (sContractId, bExactMatch, fnCallback) {
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = Constants.getEntities().ContractEntity;
				entities.paginationTop = 10;
				entities.paginationSkip = 0;
				entities.filter =
					"substringof('" + sContractId + "',ContractID) and substringof('',ContractName) and ( ProcessType eq 'ZS27' or ProcessType eq 'ZCTF' )";
			    entities.mCustomUrlParameters = new Map().set("Source", "Case");
				entities.callbackSuccess = (oData) => {
					fnCallback(oData);
				};
				BaseRequest.handleRead(entities);
			}
		};
	}
);
