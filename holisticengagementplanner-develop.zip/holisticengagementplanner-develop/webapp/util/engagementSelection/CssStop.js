sap.ui.define([
    "sap/gantt/def/gradient/Stop"
], function (Stop) {
    "use strict";

    const CssStop = Stop.extend("com.sap.ui.hep.util.engagementSelection.CssStop", {
        metadata: {
            properties: {
                cssClass: {type: "string", defaultValue: ""}
            },
            renderer: {
                apiVersion: 2
            }
        }
    });

    CssStop.prototype.getDefString = function () {
        const properties = [
            {name: "offSet", output: "offset"},
            {name: "stopColor", output: "stop-color"},
            {name: "cssClass", output: "class"}
        ];
        const output = properties.filter(prop => !this.isPropertyInitial(prop.name))
            .map(prop => `${prop.output}="${this.getProperty(prop.name)}"`)
            .join(" ");

        return `<stop id="${this.getId()}" ${output}/>`;
    };

    return CssStop;
}, true);
