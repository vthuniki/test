sap.ui.define(
	[
		"com/sap/ui/hep/reuse/Constants",
		"com/sap/ui/hep/model/formatter",
		"com/sap/ui/hep/reuse/BaseRequest",
		"sap/ui/model/json/JSONModel",
		"com/sap/ui/hep/util/Pagination",
		"com/sap/ui/hep/util/customerSelection/CustomerSelection",
		"com/sap/ui/hep/reuse/BaseTools"
	],
	function (Constants, Formtter, BaseRequest, JSONModel, Pagination, CustomerSelection, BaseTools) {
		return {

			formatter: Formtter,
			pagination: Pagination,

			_loadFragment: function (oFragmentController, oView, sFragmentPath, fnInitialCallback) {
				return BaseTools.loadFragment(oFragmentController, oView, sFragmentPath, fnInitialCallback);
			},

			fnGetDetailsForEngagement: function (sEngCaseId, bExactMatch, fnCallback) {
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = Constants.getEntities().ProjectEntity;
				entities.paginationTop = 10;
				entities.paginationSkip = 0;
				if (bExactMatch) {
					entities.filter =
						"( CaseType eq 'ZS02') and ( ProjectID eq '" + sEngCaseId + "' )";
				} else {
					entities.filter =
						"( CaseType eq 'ZS02') and substringof('" + sEngCaseId + "', ProjectID)";
				}
				entities.callbackSuccess = (oData) => {
					fnCallback(oData);
				};
				BaseRequest.handleRead(entities);
			},

			fnEngagementSelectionDialogOpen: function (oView, oResourceBundle, oInitialFilterValues, fnCallback) {
				this._oView = oView;
				this._oResourceBundle = oResourceBundle;
				this._fnDestControllerCallback = fnCallback;
				this._oInitialFilterValues = oInitialFilterValues;

				// create and initialize the Model
				this._oEngagementSelectionModel = new JSONModel({});
				this._oEngagementSelectionModel.getData().paginationClicks = 0;
				this._oEngagementSelectionModel.getData().paginationSkip = 0;
				this._oEngagementSelectionModel.getData().paginationIntervalStart = 0;
				this._oEngagementSelectionModel.getData().paginationIntervalEnd = Constants.getPaginationTop();
				this._oEngagementSelectionModel.getData().paginationNextBtnEnabled = true;
				this._oEngagementSelectionModel.getData().paginationPrevBtnEnabled = true;

				this._oEngagementSelectionModel.refresh();
				this._oModel = this._oEngagementSelectionModel; //needed for pagination Module
				this._oData = this._oEngagementSelectionModel.getData(); //needed for pagination Module

				// create and initialize helper Models
				this._oCustomerIdVhModel = new JSONModel({});
				this._oCustomerIdVhModel.setSizeLimit(1000);

				// load data from BE into model
				this._loadReasonSelectionListFromBE();

				// load Engagement Selection Fragment
				this._pDialogEngagementSelection ??= this._loadFragment(this, this._oView, "com.sap.ui.hep.util.engagementSelection.DialogEngagementSelection");
				this._pDialogEngagementSelection.then(oDialog => {
					oDialog.setModel(this._oEngagementSelectionModel, "engagementSelectionModel");
					oDialog.setModel(this._oCustomerIdVhModel, "customerSearchHelpModel");
					this._setInitialDialogValuesAndOpen();
				});

			},

			_setInitialDialogValuesAndOpen: function () {
				this._oEngagementSelectionModel.getData().sDialogWidth = this._oInitialFilterValues.sDialogWidth;
				this._oEngagementSelectionModel.getData().sDialogHeight = this._oInitialFilterValues.sDialogHeight;
				this._oEngagementSelectionModel.refresh();
				//for the following setup the dialog has to be open, so that the field.byId() is working
				this._pDialogEngagementSelection.then(oDialog => oDialog.open());
				this._fnHandleClearSearch();

				this._oEngagementSelectionModel.getData().disableCustomerFields = this._oInitialFilterValues.DisableCustomerFields;
				if (!this._oEngagementSelectionModel.getData().disableCustomerFields)
					this._setUpCustomerSelectionModule1(this._oInitialFilterValues.CustomerBpId);
				else {
					this._oEngagementSelectionModel.getData().disableCustomerFieldsValueCustomerId = this._oInitialFilterValues.CustomerBpId;
					this._oView.byId("idFilterCustomerName").setValue(this._oInitialFilterValues.CustomerName);
				}

				this._oView.byId("idFilterReasonCode").setSelectedKey('ALL');

				if (this._oInitialFilterValues.CaseId) this._oView.byId("idFilterCaseId").setValue(this._oInitialFilterValues.CaseId);
				if (this._oInitialFilterValues.CaseTitle) this._oView.byId("idFilterCaseTitle").setValue(this._oInitialFilterValues.CaseTitle);

				this._oEngagementSelectionModel.getData().bDisableReasonCombo = this._oInitialFilterValues.DisableReasonCombo;
				if (this._oInitialFilterValues.ReasonCode) this._oView.byId("idFilterReasonCode").setSelectedKey(this._oInitialFilterValues.ReasonCode);
				this._oEngagementSelectionModel.refresh();

				this._fnGetEngagementsFromBE();
			},

			//----------------------------------------------------------------------------------------------------------------------------------
			//---------------------------------------------------- Customer Selection Field ----------------------------------------------------
			//----------------------------------------------------------------------------------------------------------------------------------

			_setUpCustomerSelectionModule1: function (sInitialCustomerId) {
				let oCustomerSelectionCustomizing = {
					sInputFragmentId: "idFragmentCustomerIdDialogEngagementSelection",
					bInputFragmentHasTextField: false,
					sValueHelpFragmentId: "CustomerSelection1",
					sDialogWidth: this._oInitialFilterValues.sDialogWidth, //same size as the engagement-selection dialog itself, to reduce the popup over popup impression
					sDialogHeight: this._oInitialFilterValues.sDialogHeight,
					sCustomerIdFieldGridSpan: null,
					sCustomerNameFieldGridSpan: null,
					bCustomerIdRequired: false,
					bCustomerTextFieldVisible: false,
					fnCallBackAfterValueChange: (oNewCustomer, sValueState, bInputFieldSubmit) => {
						//define what needs to happen in your view controller, when the Customer has changed....
						//trigger engagement-search in case user has pressed <Enter> in search field customerID - which only can be the case if the search is open!!
						if (bInputFieldSubmit && this._pDialogEngagementSelection) this.fnHandleSearchTriggered();
					}
				};

				//get the single instance and then initialize
				if (!this.CustomerSelection1) this.CustomerSelection1 = new CustomerSelection(); //get the instance and then initialize
				this.CustomerSelection1.fnInitialize(this._oView, oCustomerSelectionCustomizing, sInitialCustomerId);
			},

			//----------------------------------------------------------------------------------------------------------------------------------
			//--------------------------------------------------------- Reason Combo -----------------------------------------------------------
			//----------------------------------------------------------------------------------------------------------------------------------

			_loadReasonSelectionListFromBE: function () {
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = Constants.getEntities().ValueHelp;
				entities.filter = "Entity eq 'CASE_REASON'";
				entities.oContext = this._oView;
				entities.currentView = this._oView;
				entities.callbackSuccess = (oData) => {
					if (oData.results.length) {
						let aAllReasons = JSON.parse(oData.results[0].Results);
						aAllReasons.forEach(elm => {
							elm.CaseType = elm["Case Type"];
							elm.ReasonCode = elm["Reason Code"];
							delete elm["Case Type"];
							delete elm["Reason Code"];
						});
						aAllReasons = aAllReasons.filter(oReason => oReason.ReasonCode === "ENG1" || oReason.ReasonCode === "ENG2");
						this._oEngagementSelectionModel.getData().Reasons = aAllReasons.filter(item => item.CaseType === 'ZS02');
						this._oEngagementSelectionModel.getData().Reasons.unshift({
							Description: '(All)',
							CaseType: 'ZS02',
							ReasonCode: 'ALL'
						});
						this._oEngagementSelectionModel.refresh();
					}
				};
				BaseRequest.handleRead(entities);
			},

			//----------------------------------------------------------------------------------------------------------------------------------
			//---------------------------------------------------------------  Event Handler ---------------------------------------------------
			//----------------------------------------------------------------------------------------------------------------------------------

			fnHandleSearchTriggered: function () {
				this._oEngagementSelectionModel.getData().paginationClicks = 0;
				this._oEngagementSelectionModel.getData().paginationSkip = 0;
				this._oEngagementSelectionModel.refresh();
				this._fnGetEngagementsFromBE();
			},

			_fnHandleClearSearch: function () {
				this._oView.byId("idFilterCaseId").setValue();
				this._oView.byId("idFilterCaseTitle").setValue();
				if (!this._oEngagementSelectionModel.getData().disableCustomerFields) {
					if (this.CustomerSelection1) this.CustomerSelection1.fnSetCustomerId("");
					this._oView.byId("idFilterCustomerName").setValue();
				}
				if (!this._oEngagementSelectionModel.getData().bDisableReasonCombo) {
					this._oView.byId("idFilterReasonCode").setSelectedKey('ALL');
				}
				this._oCustomerIdVhModel.getData().busyCustomerValueHelpTable = false;
				this._oCustomerIdVhModel.getData().results = [];
				this._oCustomerIdVhModel.getData().NumberOfEngagements = "0";
			},

			fnHandleToPreviousRecords: function () {
				let pagination = this.pagination.goToPreviousPage(this, this._oEngagementSelectionModel.getData().paginationClicks);
				this._oEngagementSelectionModel.getData().paginationClicks = pagination.clicks;
				this._oEngagementSelectionModel.getData().paginationSkip = pagination.skip;
				this._fnGetEngagementsFromBE();
			},

			fnHandleToNextRecords: function () {
				let pagination = this.pagination.goToNextPage(this, this._oEngagementSelectionModel.getData().paginationClicks);
				this._oEngagementSelectionModel.getData().paginationClicks = pagination.clicks;
				this._oEngagementSelectionModel.getData().paginationSkip = pagination.skip;
				this._fnGetEngagementsFromBE();
			},

			fnHandleEngagementSelected: function (oEvent) {
				let path = oEvent.getSource().getSelectedContextPaths()[0];
				let dataFromIndex = this._oEngagementSelectionModel.getProperty(path);

				this.fnHandleCloseEngagementSelection();
				this._fnDestControllerCallback(dataFromIndex);
			},

			fnHandleCloseEngagementSelection: function () {
				this._pDialogEngagementSelection.then(oDialog => oDialog.close().destroy());
				this._pDialogEngagementSelection = undefined;
			},

			fnHandleCancelEngagementSelection: function () {
				this._pDialogEngagementSelection.then(oDialog => oDialog.close().destroy());
				this._pDialogEngagementSelection = undefined;
				this._fnDestControllerCallback(null);
			},

			fnHandleNavBack: function (oContext) {
				this._oView.byId("navContainerEngCaseSearch").back();
			},

			//--------------------------------------------------------------------------------------------------------------------------
			//-----------------------------------------------  Search Engagements ------------------------------------------------------
			//--------------------------------------------------------------------------------------------------------------------------

			_fnGetEngagementsFromBE: function () {
				this._oEngagementSelectionModel.getData().busyEngagementSearch = true;
				this._oEngagementSelectionModel.refresh();
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = Constants.getEntities().ProjectEntity;
				entities.filter = this._buildEngagementSearchFilterParams();
				entities.paginationTop = 10;
				entities.paginationSkip = this._oEngagementSelectionModel.getData().paginationSkip;
				entities.inlineCount = "allpages";
				entities.callbackSuccess = (oData) => {
					this._oEngagementSelectionModel.getData().resultList = oData.results;
					this._oEngagementSelectionModel.getData().NumberOfEngagements = JSON.parse(oData.__count);
					this._oEngagementSelectionModel.getData().busyEngagementSearch = false;
					this._oEngagementSelectionModel.refresh();
					this.pagination._paginationElements(this, this._oEngagementSelectionModel.getData().NumberOfEngagements,
						this._oView.byId("btnPaginationNextEngagementSelection"),
						this._oView.byId("btnPaginationPrevEngagementSelection"));
				};
				BaseRequest.handleRead(entities);
			},

			_buildEngagementSearchFilterParams: function () {
				let sCustomerId = this._oEngagementSelectionModel.getData().disableCustomerFields ? this._oEngagementSelectionModel.getData().disableCustomerFieldsValueCustomerId :
					this.CustomerSelection1.fnGetCustomerId();
				let sFilters = "( CaseType eq 'ZS02')";

				if (this._oView.byId("idFilterCaseId").getValue()) {
					sFilters += " and substringof('" + this._oView.byId("idFilterCaseId").getValue() + "', ProjectID)";
				}
				if (this._oView.byId("idFilterCaseTitle").getValue()) {
					sFilters += " and substringof('" + this._oView.byId("idFilterCaseTitle").getValue() + "', ProjectName)";
				}

				if (sCustomerId) {
					if (this._oInitialFilterValues.ExactCustomerId) {
						sFilters += " and CustomerID eq '" + sCustomerId.padStart(10, "0") + "'";
					} else {
						sFilters += " and substringof('" + sCustomerId + "', CustomerID)";
					}
				}

				if (this._oView.byId("idFilterCustomerName").getValue()) {
					sFilters += " and substringof('" + this._oView.byId("idFilterCustomerName").getValue().toUpperCase() + "', CustomerNameUC)";
				}
				if (this._oView.byId("idFilterReasonCode").getSelectedKey() && this._oView.byId("idFilterReasonCode").getSelectedKey() !== 'ALL') {
					sFilters += " and substringof('" + this._oView.byId("idFilterReasonCode").getSelectedKey() + "', ReasonCode)";
				}

				if (sFilters.indexOf("ReasonCode") === -1) {
					sFilters += " and " +
						"( ReasonCode eq 'ENG2' or  ReasonCode eq 'ENG1' )";
				}
				return sFilters;

			}

		};
	}
);
