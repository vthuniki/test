sap.ui.define([
    "sap/gantt/simple/BaseGroup"
], function (BaseGroup) {
    "use strict";

    const BoundBaseGroup = BaseGroup.extend("com.sap.ui.hep.util.engagementSelection.BoundBaseGroup", {
        metadata: {
            properties: {
                boundClass: {type: "string", defaultValue: ""},
                cssVariable: {type: "object", defaultValue: ""},
                gradientId: {type: "string", defaultValue: ""}
            },
            aggregations: {
                /**
                 * The shapes of the group
                 */
                shapes: {type: "sap.gantt.simple.BaseShape", multiple: true, singularName: "shape"}
            },
            renderer: {
                apiVersion: 2    // enable in-place DOM patching
            }

        }
    });

    BoundBaseGroup.prototype.renderElement = function (oRm, oGroup) {
        oRm.openStart("g", oGroup);
        if (this.getBoundClass()) {
            this.getBoundClass()
                .split(' ')
                .forEach((c) => oRm.class(c));
        }
        if (this.getGradientId()) {
            oRm.style("fill", `url(#${this.getGradientId()})`);
        }
        oRm.openEnd();

        BaseGroup.prototype.renderElement.call(this, oRm, oGroup);

        oRm.close("g");
    };

    return BoundBaseGroup;
}, true);
