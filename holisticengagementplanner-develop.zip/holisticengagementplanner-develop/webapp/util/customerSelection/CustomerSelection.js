sap.ui.define(
	[
		"com/sap/ui/hep/reuse/Constants",
		"com/sap/ui/hep/reuse/BaseRequest",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/Fragment"

	],
	function (Constants, BaseRequest, JSONModel, Fragment) {

		let CustomerSelection = function () {
			//empty as basis for prototyp
		};


		//_______________________________________________________________________________________________________________
		//									I N F O R M A T I O N   H O W   T O   U S E
		//
		// In order to use the generic search module for Customers you have to
		// 1. insert the fragment into your view, where you normally would put the INPUT-field for the field Customer-ID
		//    i.e.			    <core:Fragment id="idFragmentCustomerIdDialogCreateProject" fragmentName="com.sap.ui.hep.util.customerSelection.InputFieldCustomerForForms"	type="XML"/>
		//           or     	<core:Fragment id="idFragmentCustomerIdDialogEngagementSelection" fragmentName="com.sap.ui.hep.util.customerSelection.InputFieldCustomer" type="XML"/>
		//    REMAKR: it is very important to give the fragment an ID, that later has to be specified in the setup-customizing as well (see below)
		// 2. in the controller of your view, you have to add the dependency
		//    i.e. 			"com/sap/ui/hep/util/customerSelection/CustomerSelection"   as "..., CustomerSelection, ...
		// 3. Somewhere in the initilization part of our controller, you then have to setup the CustomerSelection-module, by defining it's SETTNGS, creating the INSTANCE of it and finally calling its initilization method
		//
		//    i.e. the following method you could copy to your controller and adjust it to your needs, in order to set up the customer selection field.
		//         This method you would then have to call somewhere in initialization process for your controller:
		//
		//
		//
		//
		//			_setUpCustomerSelectionModule1: function (sInitialCustomerId) {
		// 				let oCustomerSelectionCustomizing = {
		// 					sInputFragmentId: "idFragmentCustomerIdDialogCreateProject",  //the name you have given to the fragment that you put into your view
		// 					bInputFragmentHasTextField: true,  //you are either using the fragment for forms or the simple one ... the later does not have the "CustomerName"-field and no grid-layout setup
		// 					sValueHelpFragmentId: "CustomerSelection2",  //a string that the module uses to prefix the ids of the value help fragment fields
		// 					sDialogWidth: "70%",  //dimensions of the value help dialog
		// 					sDialogHeight: "790px",  //dimensions of the value help dialog
		// 					sCustomerIdFieldGridSpan: "XL3 L3 M3 S3",  //only in case of using the form-fragment
		// 					sCustomerNameFieldGridSpan: "XL6 L6 M6 S6",  //only in case of using the form-fragment
		// 					bCustomerIdRequired: true,  //puts a red asterisk to the input field and takes care the the value state is set to error
		// 					bCustomerTextFieldVisible: true,  //it is also possible to use the form-fragment, but to hide the CustomerName field from the user
		// 					fnCallBackAfterValueChange: (oNewCustomer, sValueState, bInputFieldSubmit) => {
		// 						//define what needs to happen in your view controller, when the Customer has changed....
		//						//oNewCustomer - contains the data of the new customer
		//						//sValueState - is either "None" or "Error", depending on if the oNewCustomer is valid or not ("Error" can only occur in case "bCustomerIdRequired" was set to true) // maybe this topic is more complex and "Error" should also happen in case it is not required...
		// 						//bInputFieldSubmit - give the information if the new values was set via typing something and pressing <Enter> in the customer field, or i.e. via selecting a line in the iput help
		// 						}
		// 					}
		// 				};
		// 				//get your instance and then initialize it
		// 				if (!this.CustomerSelection2) this.CustomerSelection2 = new CustomerSelection();
		// 				this.CustomerSelection2.fnInitialize(this._oView, oCustomerSelectionCustomizing, sInitialCustomerId);
		//			},
		//
		//
		//
		//
		//    Remark: Inside your view controller you can then use the setter- and getter- method of your new CustomerSelection-Module
		//		  i.e. this.CustomerSelection2.fnGetCustomerId()   and this.CustomerSelection2.fnSetCustomerId("159922")
		//
		//_______________________________________________________________________________________________________________

		CustomerSelection.prototype.fnInitialize = function (oEmbeddingView, oCustomizing, sInitialCustomerId) {
			this._oView = oEmbeddingView;
			this._oResourceBundle = this._oView.getController().getResourceBundle();
			this.fnCallbackAfterChange = oCustomizing.fnCallBackAfterValueChange; //DEFINED IN EMBEDDING CONTROLLER
			this._sValueHelpFragmentId = oCustomizing.sValueHelpFragmentId; //DEFINED IN EMBEDDING CONTROLLER

			let sInputFragmentId = oCustomizing.sInputFragmentId; //DEFINED IN EMBEDDING CONTROLLER
			let bInputFragmentHasTextField = oCustomizing.bInputFragmentHasTextField; //DEFINED IN EMBEDDING CONTROLLER
			//calculate Ids for the input-fragment fields
			let sIdFieldInputCustomerId = sap.ui.core.Fragment.createId(sInputFragmentId, "idFieldInputCustomerId");
			let sIdFieldInputCustomerName = "";
			if (bInputFragmentHasTextField) sIdFieldInputCustomerName = sap.ui.core.Fragment.createId(sInputFragmentId, "idFieldTextCustomerName");

			//set the model directly to the Input fields iside the fragment and not just to the embedding view
			// (because the embedding view might finally contain serveral CustomerSelection fields)
			this._modelCustomerInputField = new JSONModel({});
			oEmbeddingView.getController().byId(sIdFieldInputCustomerId).setModel(this._modelCustomerInputField, "modelCustomerInputField");

			//the event handlers for the input field have to be added here programatically and can not be defined in the XML of the Input field
			//otherwise it would not be clear, which instance of the CustomerSelection handles them in the end (in case of we have more instances...)
			//the model is set for one or two fields, depending on the given customizing  - and ensure every event is only attached once!
			oEmbeddingView.getController().byId(sIdFieldInputCustomerId).detachSubmit(this.fnHandleSubmitCustomerId, this);
			oEmbeddingView.getController().byId(sIdFieldInputCustomerId).attachSubmit(this.fnHandleSubmitCustomerId, this);
			oEmbeddingView.getController().byId(sIdFieldInputCustomerId).detachValueHelpRequest(this.fnCustomerSelectionDialogOpen, this);
			oEmbeddingView.getController().byId(sIdFieldInputCustomerId).attachValueHelpRequest(this.fnCustomerSelectionDialogOpen, this);
			oEmbeddingView.getController().byId(sIdFieldInputCustomerId).detachChange(this.fnHandleCustomerIdChanged, this);
			oEmbeddingView.getController().byId(sIdFieldInputCustomerId).attachChange(this.fnHandleCustomerIdChanged, this);
			if (bInputFragmentHasTextField) { //the input field for filter bars does not have the text field
				oEmbeddingView.getController().byId(sIdFieldInputCustomerName).setModel(this._modelCustomerInputField, "modelCustomerInputField");
			}

			//In case the fragment for the form view is used, we have to specify the SPAN-Values for the Grid-layout
			this._modelCustomerInputField.getData().sCustomerIdFieldGridSpan = oCustomizing.sCustomerIdFieldGridSpan; //DEFINED IN EMBEDDING CONTROLLER
			this._modelCustomerInputField.getData().sCustomerNameFieldGridSpan = oCustomizing.sCustomerNameFieldGridSpan; //DEFINED IN EMBEDDING CONTROLLER

			//set some further properties of the input field from given customizing
			this._modelCustomerInputField.getData().bCustomerIdRequired = oCustomizing.bCustomerIdRequired; //DEFINED IN EMBEDDING CONTROLLER
			this._modelCustomerInputField.getData().bCustomerTextFieldVisible = oCustomizing.bCustomerTextFieldVisible; //DEFINED IN EMBEDDING CONTROLLER

			this._modelCustomerInputField.getData().busyCustomerIdInputField = false;
			this._modelCustomerInputField.getData().valueStateCustomerIdInputField = "None";
			this._modelCustomerInputField.getData().valueStateTextCustomerIdInputField = "";

			this._modelCustomerInputField.getData().oCustomer = {};
			this._modelCustomerInputField.getData().oCustomer.PartnerID = sInitialCustomerId; //INITIAL VALUE FROM EMBEDDING CONTROLLER
			this._modelCustomerInputField.refresh();

			//get the complete customer info - however the BE call may need some time, during which fnGetCustomerFullName and fnGetCustomerName1 do not return anything!
			this._fnGetOneCustomerFromBE(null, sInitialCustomerId, (aODataResults => {
				this._modelCustomerInputField.getData().oCustomer = aODataResults[0];
				this._modelCustomerInputField.refresh();
			}));

			//define and initialize model for the value help dialog
			this._modelCustomerDialog = new JSONModel({});
			this._modelCustomerDialog.getData().sDialogWidth = oCustomizing.sDialogWidth; //DEFINED IN EMBEDDING CONTROLLER
			this._modelCustomerDialog.getData().sDialogHeight = oCustomizing.sDialogHeight; //DEFINED IN EMBEDDING CONTROLLER
			this._modelCustomerDialog.getData().busyDialogCustomerValueHelp = false;
			this._modelCustomerDialog.getData().searchFilter = {};
			this._modelCustomerDialog.getData().results = [];
			this._modelCustomerDialog.getData().numberOfResults = "0";
			this._modelCustomerDialog.refresh();

			this._fnLoadCountryList();
		};

		CustomerSelection.prototype.fnGetCustomerId = function () {
			return this._modelCustomerInputField.getData().oCustomer ? this._modelCustomerInputField.getData().oCustomer.PartnerID : "";
		};

		CustomerSelection.prototype.fnSetCustomerId = function (sCustomerId) {
			this._modelCustomerInputField.getData().oCustomer = {};
			this._modelCustomerInputField.getData().oCustomer.PartnerID = sCustomerId;
			this._modelCustomerInputField.refresh();
			this.fnHandleCustomerIdChanged();
		};

		CustomerSelection.prototype.fnSetCustomerIdNoHandle = function (sCustomerId, sCustomerFullName = "") {
			this._modelCustomerInputField.getData().oCustomer = {};
			this._modelCustomerInputField.getData().oCustomer.PartnerID = sCustomerId;
			this._modelCustomerInputField.getData().oCustomer.FullName = sCustomerFullName;
			this._modelCustomerInputField.refresh();
		};

		CustomerSelection.prototype.fnGetCustomerFullName = function () {
			return this._modelCustomerInputField.getData().oCustomer.FullName;
		};
		CustomerSelection.prototype.fnGetCustomerName1 = function () {
			return this._modelCustomerInputField.getData().oCustomer.Name1;
		};

		//______________________________________________________________________________________________________________________
		//
		//                                                    HELPER
		//
		//______________________________________________________________________________________________________________________



		CustomerSelection.prototype._fnGetOneCustomerFromBE = function (sCustomerHint, sPartnerId, fnCallBack) {
			if (!sCustomerHint && !sPartnerId) fnCallBack([{}]); //nothing in, so empty array back
			else {
				this.bWorkingOnChange = true;
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "PFCustomerSet";
				entities.filter = sPartnerId ? "(PartnerID eq '" + sPartnerId + "')" : "(ValueFld eq '" + sCustomerHint + "')";
				entities.callbackSuccess = (oData) => {
					this.bWorkingOnChange = false;
					fnCallBack(oData.results);
				};
				BaseRequest.handleRead(entities);
			}
		};

		CustomerSelection.prototype._fnLoadCountryList = function () {
			let oCountryListModel = new JSONModel(sap.ui.require.toUrl("com/sap/ui/hep/model/countries.json"));
			oCountryListModel.attachRequestCompleted(function (oEvent) {
				this._modelCustomerDialog.getData().countryList = oEvent.getSource().getData().countries;
				this._modelCustomerDialog.refresh();
			}.bind(this));
		};

		//______________________________________________________________________________________________________________________
		//
		//                                                    CUSTOMER INPUT FIELD
		//
		//______________________________________________________________________________________________________________________

		CustomerSelection.prototype._fnSetCustomerIdFieldValueState = function (sValueState) {
			if (sValueState === "None") {
				this._modelCustomerInputField.getData().valueStateCustomerIdInputField = "None";
				this._modelCustomerInputField.getData().valueStateTextCustomerIdInputField = "";
			} else {
				this._modelCustomerInputField.getData().valueStateCustomerIdInputField = "Error";
				this._modelCustomerInputField.getData().valueStateTextCustomerIdInputField = "No valid Customer";
			}
			this._modelCustomerInputField.refresh();
		};

		CustomerSelection.prototype._fnGetCustomerIdFieldValueState = function () {
			return this._modelCustomerInputField.getData().valueStateCustomerIdInputField;
		};

		// ****************************** START *** fnHandleCustomerIdChanged **************************************************
		CustomerSelection.prototype.fnHandleCustomerIdChanged = function (oEvent) {
			//REMARK: if value is not valid (Error-case) or not unique we also have to clean-up the oCustomer-object
			//when the value is valid, we do not have to change the oCustomer-object, because it was already set in the calling method!
			let sEnteredValue = this._modelCustomerInputField.getData().oCustomer.PartnerID;
			let bCustomerRequired = this._modelCustomerInputField.getData().bCustomerIdRequired;
			if (!sEnteredValue) {
				this._fnHelperAddCustomerToModel(sEnteredValue, bCustomerRequired);
				this.fnCallbackAfterChange(this._modelCustomerInputField.getData().oCustomer, this._modelCustomerInputField.getData().valueStateCustomerIdInputField,
					this._handleCustomerIdFieldSubmit);
			} else
				//something is entered, but is it a valid Customer number?
				//in case user has pressed <Submit> inside the field, do a generic search for the entered value
				//all other cases do strict search for the PartnerId
				if (this._handleCustomerIdFieldSubmit) {
					this._fnHelperHandleCustomerIdChangedHandleSubmit(sEnteredValue, bCustomerRequired);
				} else {
					this._fnHelperHandleCustomerIdChangedHandleStrictSearchForPartnerID(sEnteredValue, bCustomerRequired);
				}
			this._handleCustomerIdFieldSubmit = false;
		};

		CustomerSelection.prototype._fnHelperHandleCustomerIdChangedHandleSubmit = function (sEnteredValue, bCustomerRequired) {
			this._fnGetOneCustomerFromBE(sEnteredValue, null, (aODataResults) => {
				if (aODataResults.length !== 1) {
					this._fnHelperAddCustomerToModel(sEnteredValue, bCustomerRequired);
				} else if (bCustomerRequired) this._fnSetCustomerIdFieldValueState("None");
				this.fnCallbackAfterChange(this._modelCustomerInputField.getData().oCustomer, this._modelCustomerInputField.getData().valueStateCustomerIdInputField,
					this._handleCustomerIdFieldSubmit);
			});
		};

		CustomerSelection.prototype._fnHelperHandleCustomerIdChangedHandleStrictSearchForPartnerID = function (sEnteredValue, bCustomerRequired) {
			this._fnGetOneCustomerFromBE(null, sEnteredValue, (aODataResults) => {
				if (aODataResults.length !== 1) {
					this._fnHelperAddCustomerToModel(sEnteredValue, bCustomerRequired);
				} else {
					if (bCustomerRequired) this._fnSetCustomerIdFieldValueState("None");
					try {
						this._modelCustomerInputField.getData().oCustomer.FullName = aODataResults[0].FullName;
					} catch (oError) {
					}
				}
				this.fnCallbackAfterChange(this._modelCustomerInputField.getData().oCustomer, this._modelCustomerInputField.getData().valueStateCustomerIdInputField,
					this._handleCustomerIdFieldSubmit);
			});
		};

		CustomerSelection.prototype._fnHelperAddCustomerToModel = function (sEnteredValue, bCustomerRequired) {
			if (bCustomerRequired) this._fnSetCustomerIdFieldValueState("Error");
			else this._fnSetCustomerIdFieldValueState("None");
			this._modelCustomerInputField.getData().oCustomer = {};
			this._modelCustomerInputField.getData().oCustomer.PartnerID = sEnteredValue;
			this._modelCustomerInputField.refresh();
		};
		// ********************************* END *** fnHandleCustomerIdChanged *****************************


		CustomerSelection.prototype.fnHandleSubmitCustomerId = function (oEvent) {
			this._handleCustomerIdFieldSubmit = true;
			this._modelCustomerInputField.getData().oCustomer.FullName = "";
			this._modelCustomerInputField.getData().busyCustomerIdInputField = true;
			this._modelCustomerInputField.refresh();

			this._fnHandleClearSearch();
			this._modelCustomerDialog.getData().searchFilter.ValueFld = oEvent.getParameter("value");
			this._modelCustomerDialog.refresh();
			this.fnHandleCustomerValueHelpSearchTriggered(null, true);

		};

		//______________________________________________________________________________________________________________________
		//
		//                                                    SEARCH DIALOG
		//
		//______________________________________________________________________________________________________________________

		CustomerSelection.prototype.fnCustomerSelectionDialogOpen = function (oEvent) {
			if (oEvent) this._fnHandleClearSearch(); //triggered directly by user by clicking on the icon - then popup should be empty
			if (!this._oDialogCustomerValueHelp) {
				try {
					Fragment.load({
						id: this._oView.createId(this._sValueHelpFragmentId),
						name: "com.sap.ui.hep.util.customerSelection.DialogValueHelpCustomer",
						controller: this
					}).then(oDialog => {
						this._oDialogCustomerValueHelp = oDialog;
						this._oView.addDependent(this._oDialogCustomerValueHelp);
						this._oDialogCustomerValueHelp.setModel(this._modelCustomerDialog, "modelCustomerDialog");
						this._oDialogCustomerValueHelp.addStyleClass("sapUiSizeCompact");
						this._oDialogCustomerValueHelp.open();

					});
				} catch (oError) {
					if (oError.statusCode === 503) {
						let params = {
							currentView: this._oView
						};
						this.handleSessionTimeout(params, this);
					}
				}
			} else this._oDialogCustomerValueHelp.open();

		};

		// ****************************** START *** fnHandleCustomerValueHelpSearchTriggered **************************************************
		CustomerSelection.prototype.fnHandleCustomerValueHelpSearchTriggered = function (oEvent) {
			this._modelCustomerDialog.getData().busyDialogCustomerValueHelp = true;
			this._modelCustomerDialog.refresh();

			let sFilter = "";
			let sCustFilterGeneric = this._modelCustomerDialog.getData().searchFilter.ValueFld;
			let sCustFilterCity = this._modelCustomerDialog.getData().searchFilter.City;
			let sCustFilterCountry = this._modelCustomerDialog.getData().searchFilter.Country;

			if (sCustFilterGeneric) sFilter = "substringof('" + sCustFilterGeneric + "', ValueFld)";
			if (sCustFilterCity) sFilter = sFilter ? sFilter + " and substringof('" + sCustFilterCity + "', City)" : "substringof('" +
				sCustFilterCity + "', City)";
			if (sCustFilterCountry) sFilter = sFilter ? sFilter + " and Country eq '" + sCustFilterCountry + "'" : "Country eq '" +
				sCustFilterCountry + "'";

			//build the request
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "PFCustomerSet";
			entities.filter = sFilter;
			entities.paginationTop = "100"; //limit to 100 results
			entities.paginationSkip = "0";
			entities.currentView = this._oView;
			entities.errorMessage = this._oResourceBundle.getText("NewProject.CustomerSearchError");
			entities.callbackSuccess = this._fnHandleSuccessCustomerValueHelpSearchTriggered.bind(this);
			BaseRequest.handleRead(entities);
		};

		CustomerSelection.prototype._fnHandleSuccessCustomerValueHelpSearchTriggered = function (oData) {
			this._modelCustomerInputField.getData().busyCustomerIdInputField = false; //might have been set, when coming from fnHandleSubmitCustomerId, just in case reset it
			this._modelCustomerInputField.refresh();
			this._modelCustomerDialog.getData().busyDialogCustomerValueHelp = false;
			this._modelCustomerDialog.refresh();
			if (!this._ignoreCustomerSearchDialog) {
				this._modelCustomerDialog.getData().results = oData.results;
				this._modelCustomerDialog.getData().numberOfResults = oData.results.length;

				if (this._handleCustomerIdFieldSubmit) { //Customer search was not triggered inside the Dialog, but by pressing <Enter> in the "Emplyee"-InputField...
					if (this._modelCustomerDialog.getData().numberOfResults === 1) {
						this._modelCustomerInputField.getData().oCustomer = oData.results[0];
						this._fnSetCustomerIdFieldValueState("None");
						this.fnCallbackAfterChange(oData.results[0], "None", this._handleCustomerIdFieldSubmit);
					} else {
						this.fnCustomerSelectionDialogOpen(); //open the dialog with the found results, so the user can select
						this._modelCustomerInputField.getData().oCustomer.FullName = "";
					}
				}
				this._modelCustomerInputField.refresh();
				this._modelCustomerDialog.refresh();

			} else this._ignoreCustomerSearchDialog = false;
		};
		// ****************************** END *** fnHandleCustomerValueHelpSearchTriggered **************************************************

		CustomerSelection.prototype._fnHandleClearSearch = function () {
			this._modelCustomerDialog.getData().searchFilter.ValueFld = "";
			this._modelCustomerDialog.getData().searchFilter.City = "";
			this._modelCustomerDialog.getData().searchFilter.Country = "";
			this._modelCustomerDialog.getData().results = null;
			this._modelCustomerDialog.getData().numberOfResults = "0";
			this._modelCustomerDialog.refresh();

		};

		CustomerSelection.prototype.fnHandleCustomerDialogItemPressed = function (oEvent) {
			this._modelCustomerInputField.getData().busyCustomerIdInputField = false; //might have been set
			this._modelCustomerInputField.refresh();
			let iSelectedItemIndex = parseInt(oEvent.getSource().getSelectedContextPaths()[0].split("/")[2], 10);
			let oSelectedItem = this._modelCustomerDialog.getData().results[iSelectedItemIndex];
			this._modelCustomerInputField.getData().oCustomer = oSelectedItem;
			this.fnCloseCustomerValueHelpDialog();
			this._modelCustomerInputField.refresh();
			this._handleCustomerIdFieldSubmit = false; //_fnHandleCustomerIdChanged is not triggered, because of a Submit in field CustomerId
			this.fnHandleCustomerIdChanged();
		};

		CustomerSelection.prototype.fnHandleCustomerDialogCancel = function () {
			this._modelCustomerInputField.getData().busyCustomerIdInputField = false; //might have been set
			this._modelCustomerInputField.refresh();
			this._modelCustomerDialog.getData().results = [];
			this.fnCloseCustomerValueHelpDialog();
			this.fnHandleCustomerIdChanged(); //might be or might not be, but better call it
		};

		CustomerSelection.prototype.fnCloseCustomerValueHelpDialog = function () {
			this._oDialogCustomerValueHelp.close();
			this._oDialogCustomerValueHelp.destroy();
			this._oDialogCustomerValueHelp = undefined;
			if (this._callbackAfterCustomerValueHelpDialogClose) this._callbackAfterCustomerValueHelpDialogClose();
		};
		return CustomerSelection;
	}

);
