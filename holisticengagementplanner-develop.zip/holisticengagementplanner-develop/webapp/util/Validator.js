sap.ui.define([
	"com/sap/ui/hep/util/MessageHandlingPopover"

], function (MessageHandlingPopover) {
	"use strict";

	let Validator = function () {
		this._isValid = true;
		this._isFormValid = false;
		this._isValidationPerformed = false;
		this.messageHandler = MessageHandlingPopover;
	};

	/**
	 * Returns true only when the form validation has been performed, and no validation errors were found
	 * @returns {boolean} validation
	 */
	Validator.prototype.isValid = function () {
		return this._isValidationPerformed && this._isValid;
	};

	/**
	 * Returns true only when the form validation has been performed, and no validation errors were found
	 * @returns {boolean} validation
	 */
	Validator.prototype.isFormValid = function () {
		return this._isFormValid && this._isValid;
	};

	/**
	 * Recursively validates the given oControl and any aggregations (i.e. child controls) it may have
	 * and highlights any mandatory fields that are not filled
	 *
	 * @param {(sap.ui.core.Control|sap.ui.layout.form.FormContainer|sap.ui.layout.form.FormElement)} oControl - The control or element to be validated.
	 * @param {object} oModel the model
	 * @param {object} oContext the controller
	 * @param {boolean} bQuestionnaire wether or not the form is the one from the Questionnaire section
	 * @return {boolean} whether the oControl is valid or not.
	 */
	Validator.prototype.validateAndHighlightMissingMandatoryFields = function (oControl, oModel, oContext, bQuestionnaire) {
		this._isValid = true;
		sap.ui.getCore().getMessageManager().removeAllMessages();
		this._validateAndHighlightMissingMandatoryFields(oControl, oModel, oContext, bQuestionnaire);
		return this.isValid();
	};

	/**
	 * Recursively validates the given oControl and any aggregations (i.e. child controls) it may have
	 *
	 * @param {(sap.ui.core.Control|sap.ui.layout.form.FormContainer|sap.ui.layout.form.FormElement)} oControl - The control or element to be validated.
	 * @param {boolean} bQuestionnaire wether or not the form is the one from the Questionnaire section
	 * @return {boolean} whether the oControl is valid or not.
	 */
	Validator.prototype.validateEntireForm = function (oControl, bQuestionnaire) {
		this._isFormValid = true;
		this._validateEntireForm(oControl, bQuestionnaire);
		return this.isFormValid();
	};

	Validator.prototype.getFieldValue = function (oField) {
		let oValue;
		switch (true) {
		case oField instanceof sap.m.ComboBox:
			oValue = oField.getSelectedKey();
			if (!oValue) {
				oValue = oField.getValue();
			}
			if (oField.getValueState() === "Error" && oValue.length === 0) {
				oValue = ""; // a field that already is in Error-State should recognized as errorous by the validator as well
				// this is achieved by pretending it is an empty mandatory field
			}
			break;
		case oField instanceof sap.m.Input:
			oValue = oField.getValue();
			break;
		case oField instanceof sap.m.CheckBox:
			oValue = oField.getSelected();
			break;
			// to do: check the items inside the vbox, check the radio button itself
		case oField instanceof sap.m.RadioButtonGroup:
			oValue = oField.getSelectedIndex();
			break;
		case oField instanceof sap.m.Link:
			// 
			break;
		case oField instanceof sap.m.Text:
			oValue = oField.getText();
			break;
		case oField instanceof sap.m.TextArea:
			oValue = oField.getValue();
			break;
		case oField instanceof sap.m.DatePicker:
			oValue = oField.getValue();
			if (!oField.isValidValue()) {
				oValue = "";
			}
			break;
		default:
			oValue = oField.getValue();
		}
		return oValue;
	};

	/**
	 * Recursively validates the given oControl and any aggregations (i.e. child controls) it may have
	 *
	 * @param {(sap.ui.core.Control|sap.ui.layout.form.FormContainer|sap.ui.layout.form.FormElement)} oControl - The control or element to be validated.
	 * @param {boolean} bQuestionnaire wether or not the form is the one from the Questionnaire section
	*/	
	Validator.prototype._validateEntireForm = function (oControl, bQuestionnaire) {
		this._isValid = true;
		this._isValidationPerformed = false;		
		$.each(oControl.getFormContainers(), function (iformContainer, oFormContainer) {
			$.each(oFormContainer.getFormElements(), function (iFormElement, oFormElement) {
				const bMandatory = oFormElement.getLabelControl().isRequired();
				const oCurrentUIElement = bQuestionnaire ? oFormElement.getFields()[0].getItems()[0] : oFormElement.getFields()[0];
				if (bMandatory && oFormElement.getVisible()) {
					let oValue = this.getFieldValue(oCurrentUIElement);
					this._isValid = !(typeof oValue === 'undefined' || oValue === null || (typeof (oValue) === "string" && oValue.trim() === "") ||
                					(oCurrentUIElement.getMetadata().getElementName() === "sap.m.RadioButtonGroup" && oValue === -1));
					return this._isValid
				}
			}.bind(this));
			return this._isValid
		}.bind(this));
		this._isValidationPerformed = true;
	};

	/**
	 * Function used to get Info of UIElement, used internally in the iteration of form fields
	 *
	 * @param {(object)} oContext - The View controller (oView.getController()) .
	 * @param {object|sap.ui.layout.form.FormElement} oUIElement UI Element
	*/
	Validator.prototype._getItemFromUIElement = function (oContext, oUIElement) {
		let oItem, aPath, bValueStateExists = false;
		if (oUIElement.getBindingInfo("valueState") !== undefined) {
			bValueStateExists = true;
			let sModel = oUIElement.getBindingInfo("valueState").parts[0].model;
			let sPath = oUIElement.getBindingInfo("valueState").parts[0].path;
			aPath = sPath.slice(1).split("/");
			oItem = oContext.getView().getModel(sModel).getData();
			if ( aPath.length > 1 ) {
				oItem = oItem[aPath[aPath.length - 2]];
			}
		}
		return [ bValueStateExists , aPath , oItem ];
	};		

	/**
	 * Function used to assign value state to item, used internally in the iteration of form fields
	 *
	 * @param {bValueStateExists} boolean - flag used to appy the value .
	 * @param {bQuestionnaire} boolean - flag to know if is a questionnaire
	 * @param {oItem} object - can be an array or a UIElement
	 * @param {sPathname} string - name of key in path (if oItem is an array)
	 * @return: boolean - true if change applied
	*/
	Validator.prototype._assignValueStateToItem = function (bValueStateExists, bQuestionnaire, oItem, sPathName, bValue, sValue ) {
		if (!bValueStateExists) {
			return false
		}	
		if (bQuestionnaire) {
			oItem.bValueStateError = bValue;
		} else {
			oItem[sPathName] = sValue;
		}
		return true
	};		
	/**
	 * Function used to assign value state to item, used internally in the iteration of form fields
	 *
 	 * @param {oCurrentUIElement} object - UI Element
	 * @param {oFormElement} object - Form Element .
	 * @param {bQuestionnaire} boolean - flag to know if is a questionnaire
	 * @param {oContext} object - instance of form context
	 * @param {bIsSavePress} boolean - flag to know if save is pressed
	 * @param {oModel} object - instance of model of form (for refresh)
	*/
	Validator.prototype._checkValueAndSetStateToItem = function (oCurrentUIElement, oFormElement, bQuestionnaire, oContext, bIsSavePress, oModel ) {
		let aPath;	
		let bValueStateExists = false;
		let oItem;		
		let oMsgData = oContext.getModel("messagesModel").getData();		
		let msgInfos = oMsgData.messages;
		let oValue = this.getFieldValue(oCurrentUIElement);	
		if (oValue === "" || oValue === null || oValue === undefined)  {
			this._isValid = false;
			if (typeof oCurrentUIElement.getValueState === "function") {
				let title = oFormElement.getLabelControl().getText();
				let description = oCurrentUIElement.getAggregation("tooltip");
				let subtitle = oCurrentUIElement.getProperty("valueStateText");
				if (bQuestionnaire || (!bQuestionnaire && bIsSavePress)) {
					this.messageHandler.addNewMessageseInsidePopover(id, "Error", title, description, subtitle, oContext);
				}
				[ bValueStateExists , aPath , oItem ] = this._getItemFromUIElement(oContext, oCurrentUIElement)
				this._assignValueStateToItem(bValueStateExists, bQuestionnaire, oItem, aPath[aPath.length - 1], true, "Error")
				oModel.refresh();
			}
		} else if (typeof oCurrentUIElement.getValueState === "function") {
			if (msgInfos) {
				if (this.messageHandler._checkIfIsInsideModel(oMsgData, oCurrentUIElement) === true) {
					this.messageHandler.removeMsgFromPopover(oCurrentUIElement.getId(), oContext);
				}
				[ bValueStateExists , aPath , oItem ] = this._getItemFromUIElement(oContext, oCurrentUIElement)
				this._assignValueStateToItem(bValueStateExists, bQuestionnaire, oItem, aPath[aPath.length - 1], false, "None")
				oModel.refresh();
			}
		}
	}	

	Validator.prototype._validateAndHighlightMissingMandatoryFields = function (oControl, oModel, oContext, bQuestionnaire) {
		this._isValid = true;
		let localModel;
		let bEnabled = true;
		let bIsSavePress = false;
		if (!bQuestionnaire) {
			localModel = oContext.getView().getModel("localModel") ? oContext.getView().getModel("localModel").getData() : undefined;
		}
		bIsSavePress = localModel ? localModel.isSavePress : false;

		// loop UI Elements of each container in the form and assign status value depending on some conditions
		// 1: if value is empy 
		// 2: if value state is a function and msgInfos is a valid message instance
		$.each(oControl.getFormContainers(), function (iformContainer, oFormContainer) {
			$.each(oFormContainer.getFormElements(), function (iFormElement, oFormElement) {
				const bMandatory = oFormElement.getLabelControl().isRequired();
				bEnabled = true;
				const oCurrentUIElement = bQuestionnaire ? oFormElement.getFields()[0].getItems()[0] : oFormElement.getFields()[0];
				bEnabled = typeof oCurrentUIElement.getEnabled === "function" ? oCurrentUIElement.getEnabled() : true;
				if (bMandatory && bEnabled && oFormElement.getVisible()) {
					// get the associated element from the model and set the value state with error
					this._checkValueAndSetStateToItem( oCurrentUIElement, oFormElement, bQuestionnaire, oContext, bIsSavePress, oModel);
				}
			}.bind(this));
		}.bind(this));
		this._isValidationPerformed = true;
	};

	return Validator;
});