sap.ui.define("com/sap/ui/hep/util/TablePersoActivities",
    [
        "com/sap/ui/hep/util/TablePersoBaseService",
    ],
    function (TablePersoBaseService) {
        "use strict";

        const PersoService = TablePersoBaseService.extend("com.sap.ui.hep.util.TablePersoActivities", {
            constructor: function () {
                TablePersoBaseService.call(this, "tablePerso-ActivitiesTable.json");
            },
        });

        return new PersoService();
    }, /* bExport= */ true);
