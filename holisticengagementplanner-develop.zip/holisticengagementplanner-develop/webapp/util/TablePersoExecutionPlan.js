sap.ui.define("com/sap/ui/hep/util/TablePersoExecutionPlan",
    [
        "com/sap/ui/hep/util/SessionTablePersoBaseService"
    ],
    function (SessionTablePersoBaseService) {
        "use strict";

        const PersoService = SessionTablePersoBaseService.extend("com.sap.ui.hep.util.TablePersoExecutionPlan", {
            constructor: function () {
                SessionTablePersoBaseService.call(this, "tablePerso-idExecutionPlanTable.json", "projectDetailsExecutionConfig")
            },
        });

        return new PersoService();
    }, /* bExport= */ true);
