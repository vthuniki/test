sap.ui.define(
	[
		"com/sap/ui/hep/reuse/Constants",
		"com/sap/ui/hep/model/formatter",
		"com/sap/ui/hep/reuse/BaseRequest",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/Fragment",
		"com/sap/ui/hep/util/NavigationToExternalApps"
	],
	function (Constants, formatter, BaseRequest, JSONModel, Fragment, NavigationToExternalApps) {
		return {
			formatter: formatter,



			/**
			 * first method that is called in this module.
			 * It takes care of loading the available services from BE and detailed information about each.
			 * It also takes care of loading the Fragment with the Dialog-control and inject it into the view
			 * that is handed over.
			 * All events that are triggered by controls inside the Dialog are handeled by directly by the
			 * event handler methods, defined in this module, as this module is set as the controller for
			 * the fragment.
			 *
			 * @param {object} oView  - View-control in that the Frament has to be injected
			 * @param {object} oResourceBundle  - Access to i18n-file
			 * @param {string} sServicePathSPD  - Path to oData-Service in BE
			 * @param {string} sProjectId  - Project to which the service is to be added
			 */
			fnOnServProdSelectionDialogOpen: function (oView, oResourceBundle, sServicePathSPD, sProjectId) {
				this._oView = oView;
				this._oResourceBundle = oResourceBundle;
				let sCustomerId = oView.getModel("spdDetails").getData().CaseDetails.CustomerID;

				// create and initialize the Model
				if (!this._oAddServiceModel) {
					this._oAddServiceModel = new JSONModel({});
				}
				this._setInitialModelValues(sProjectId);

				// load Services and their Hierarchy from Backend into the Model, but do not wait, just set busy
				this._oAddServiceModel.getData().bBusySelectionTree = true;
				this._oAddServiceModel.refresh();
				Promise.all([this._pLoadAllServicesFromCRM(sServicePathSPD), this._pLoadServiceHierarchyFromCRM(sCustomerId)]).then(() => {
					this._oAddServiceModel.getData().bBusySelectionTree = false;
					this._oAddServiceModel.refresh();
				}).catch((err) => {
					// BE call fail
				});

				// load/open the fragment with the Dialog and attach the Model to it
				if (!this._oDialogServiceProductSelection) {
					let oFragmentData = {
						id: this._oView.getId(),
						name: "com.sap.ui.hep.util.serviceProductSelection.DialogServiceProductSelection",
						controller: this
					};
					try {
						Fragment.load(oFragmentData).then((oDialog) => {
							this._oView.addDependent(oDialog);
							this._oView.byId("idInputServiceSession").addEventDelegate({
								onAfterRendering: function () {
									setTimeout(function () {
										this._oView.byId("idInputServiceSession").focus();
									}.bind(this), 500);
								}.bind(this)
							});
							oDialog.setModel(this._oAddServiceModel, "addServiceModel");
							oDialog.open();

							this._oDialogServiceProductSelection = oDialog;
						});
					} catch (oError) {
						if (oError.statusCode === 503) {
						  //do nothing
						}
					}
				} else {
					this.fnOnServProdSelectionNavToPageMaster();
					this._oDialogServiceProductSelection.open();
				}
			},

			/**
			 * if not already done, creates a dedicated Model for the ServiceProductSelection Dialog
			 * and loads all service products and information about them from CRM-BE.
			 * This contains also the information if a service should be scoped in SRS first....
			 *
			 * @param {string} sServicePathSPD  - oData-Service path to access BE
			 */
			_pLoadAllServicesFromCRM: function (sServicePathSPD) {
				return new Promise((res) => {
					if (this._oAddServiceModel.getData().aAllServicesFromCrm) {
						res();
					} else {
						let entities = {};
						entities.servicePath = sServicePathSPD;
						entities.entitySet = "ServiceF4Set";
						entities.callbackSuccess = (oData) => {
							this._oAddServiceModel.getData().aAllServicesFromCrm = oData.results;
							this._oAddServiceModel.refresh();
							res();
						};
						BaseRequest.handleRead(entities);
					}
				});
			},

			/**
			 * This methhods sets all model properties to their initial values.
			 * It also gives the developer an overview about what properties the model has
			 */
			_setInitialModelValues: function (sProjectId) {
				//this._oAddServiceModel.getData().aAllServicesFromCrm   --> this is filled form BE in _pLoadModelWithAllServicesFromCRM
				this._oAddServiceModel.getData().dialogServProdSelectionWidth = "34rem";
				this._oAddServiceModel.getData().dialogServProdSelectionHeight = "13rem";
				this._oAddServiceModel.getData().projectId = sProjectId;
				this._oAddServiceModel.getData().selectedObject = {};
				this._oAddServiceModel.getData().skipScopingEnabled = false;
				this._oAddServiceModel.getData().skipScopingSelected = false;
				this._oAddServiceModel.getData().bBtnContinueEnabled = true;
				this._oAddServiceModel.getData().bDialogServProdSelectionConfirmationMode = false;
				this._oAddServiceModel.refresh();
			},

			_pLoadServiceHierarchyFromCRM: function (sCustomerId) {
				return new Promise((res) => {
					if (this._oAddServiceModel.getData().aSrvHierarchyFromCRM && sCustomerId === this._oAddServiceModel.getData().sCustomerId) {
						res();
					} else {
						let entities = {};
						entities.servicePath = Constants.getServicePath();
						entities.entitySet = "ProductValueHelpSet";
						entities.filter =  `( CustomerId eq '${sCustomerId}' )`;
						entities.callbackSuccess = (oData) => {
							this._oAddServiceModel.getData().sCustomerId = sCustomerId;
							this._oAddServiceModel.getData().aSrvHierarchyFromCRM = oData.results;
							this._oAddServiceModel.getData().aSrvHierarchyFromCRM.forEach(oSrv => {
								oSrv.FreeTextSearch = (oSrv.ServiceProductId + " " + oSrv.SessionProductId + " " + oSrv.SessionDescription + " " + oSrv.CatalogTitle +
									" " + oSrv.ServiceDescription).toUpperCase();
							});
							this._oAddServiceModel.refresh();
							this._buildSrvHierarchyTree(oData.results);
							res();
						};
						BaseRequest.handleRead(entities);
					}
				});
			},

			/**
			 * The method gets a f.
			 * eloper an overview about what properties the model has
			 */
			_buildSrvHierarchyTree: function (aSrvHierarchyFlat) {
				aSrvHierarchyFlat.forEach(elm => {
					//correct values, where BE sends strange characters - probably only happens in Test and Dev landscape
					elm.RefObjRequirement = isNaN(parseInt(elm.RefObjRequirement, 10)) ? 0 : parseInt(elm.RefObjRequirement, 10);
				});
				let aItems = [];
				let aCatalog = aSrvHierarchyFlat;
				let aService = aSrvHierarchyFlat;
				let aComponent = aSrvHierarchyFlat;
				for (let i = 0; i < aCatalog.length; i++) {
					if (i > 0 && aCatalog[i - 1].CatalogId === aCatalog[i].CatalogId) {
						continue;
					}
					let oCatalog = {
						CatalogId: aCatalog[i].CatalogId,
						DisplayText: aCatalog[i].CatalogTitle,
						Children: [],
						Type: "catalog"
					};
					aService.forEach(serviceElem => {
						if (oCatalog.Children.find(service => service.ServiceProductId === serviceElem.ServiceProductId)) {
							return; //if service is already in catalog-tree, do nothing and go to next one
						}

						if (serviceElem.CatalogId === aCatalog[i].CatalogId) {
							//create the service for the catalog-tree
							let oService = {
								CatalogId: serviceElem.CatalogId,
								ServiceProductId: serviceElem.ServiceProductId,
								DisplayText: serviceElem.ServiceProductId + " " + serviceElem.ServiceDescription,
								ServiceSearch: serviceElem.ServiceProductId + " " + serviceElem.ServiceDescription.toUpperCase(),
								RefObjRequirement: serviceElem.RefObjRequirement,
								Type: "service",
								ServiceType: serviceElem.ServiceType, //"A=onSide B=Remote"
								Children: []
							};

							// add Sessions as Children to the Service (but in case the Service is of type "B" (remote) create just
							// one child and concatenate all sessions into that one child
							this.__fnAddSessionsUnderService(oService, serviceElem, aComponent);

							//push the service into the Catalog
							oCatalog.Children.push(oService);
						}
					});
					aItems.push(oCatalog);
				}

				// go through the whole catalog now and compact all sessions under a service into one single line
				aItems.forEach((oCatalog) => {
					oCatalog.Children.forEach((oService) => {
						this.__fnCompactSessionsInOneLine(oService);
					});
				});

				this._oAddServiceModel.getData().aSrvHierarchyItemsFiltered = aItems;
				this._oAddServiceModel.refresh();
			},

			__fnAddSessionsUnderService: function(oService, serviceElem, aComponent){
				// add Sessions as Children to the Service (but in case the Service is of type "B" (remote) create just
				// one child and concatenate all sessions into that one child
				aComponent.forEach(sessionElem => {
					if ((sessionElem.CatalogId === serviceElem.CatalogId) &&
						(sessionElem.ServiceProductId === serviceElem.ServiceProductId) &&
						(sessionElem.StaffingProductId === "") && (serviceElem.SessionDescription.length !== 0)) {

						oService.Children.push({
							CatalogId: serviceElem.CatalogId,
							ServiceProductId: sessionElem.ServiceProductId,
							SessionId: sessionElem.SessionProductId,
							DisplayText: sessionElem.SessionProductId + " " + sessionElem.SessionDescription,
							ServiceSearch: sessionElem.ServiceProductId + " " + sessionElem.ServiceDescription.toUpperCase(),
							SessionSearch: sessionElem.SessionProductId + " " + sessionElem.SessionDescription.toUpperCase(),
							RefObjRequirement: sessionElem.RefObjRequirement,
							Type: "session",
							ServiceType: serviceElem.ServiceType //"A=onSide B=Remote"
						});
					}
				});
			},

			__fnCompactSessionsInOneLine: function (oService){
				// go through everything and compact all sessions under one service into one single line
				if (oService.ServiceType === "B") {
					let oMultiSession = {};
					oService.Children.forEach((oSession) => {
						oMultiSession.SessionId = oSession.SessionId;
						oMultiSession.DisplayText = oMultiSession.DisplayText ? oMultiSession.DisplayText + " / " + oSession.DisplayText :
							oSession.DisplayText;
					});

					if (oMultiSession.DisplayText) {
						oMultiSession.CatalogId = oService.CatalogId;
						oMultiSession.ServiceProductId = oService.ServiceProductId;
						oMultiSession.Type = oMultiSession.DisplayText.includes(" / ") ? "multiSession" : "session";
						oMultiSession.SessionId = oMultiSession.Type === "multiSession" ? "" : oMultiSession.SessionId;
						oMultiSession.ServiceType = oService.ServiceType;
						oMultiSession.ServiceSearch = oService.DisplayText.toUpperCase();
						oMultiSession.SessionSearch = oMultiSession.DisplayText.toUpperCase();
						oMultiSession.RefObjRequirement = oService.RefObjRequirement;

						oService.Children = [];
						oService.Children.push(oMultiSession);
					}
				}
			},

			_fnNavToSrsAppCreation: function () {
				this._oDialogServiceProductSelection.close();

				const sProjectId = this._oAddServiceModel.getData().projectId;
				const oSelectedObject = this._oAddServiceModel.getData().selectedObject;
				let sServiceProductId = "";
				let sSessionId = "";

				if (!$.isEmptyObject(oSelectedObject)) {
					sServiceProductId = oSelectedObject.ServiceProductId;
					sSessionId = oSelectedObject.SessionId;
				}
				this._oView.getController().getOwnerComponent().trackEvent("Trigger_CreateServiceRequest_InSRS");
				NavigationToExternalApps.fnNavigateToSrsApp("Create", "", sProjectId, sServiceProductId, sSessionId);

			},

			_fnNavToSoCreation: function () {
				this._oDialogServiceProductSelection.close();
				const sProjectId = this._oAddServiceModel.getData().projectId;
				const oSelectedObject = this._oAddServiceModel.getData().selectedObject;
				this._oView.getController().getRouter().navTo("ServiceOrderCreate", {
					projectID: sProjectId,
					['?details']: {
						catalogId: oSelectedObject.CatalogId,
						serviceProductId: oSelectedObject.ServiceProductId,
						sessionId: oSelectedObject.SessionId === undefined ? "" : oSelectedObject.SessionId
					}
				});
			},

			_fnShowUserConfirmNavDialog: function () {
				this._oAddServiceModel.getData().bDialogServProdSelectionConfirmationMode = true;
				this._oAddServiceModel.getData().dialogServProdSelectionWidth = "32rem";
				this._oAddServiceModel.getData().dialogServProdSelectionHeight = "8rem";
				this._oAddServiceModel.refresh();
				this._oView.byId("btnConfirmGotoSRS").addEventDelegate({
					onAfterRendering: function () {
						this._oView.byId("btnConfirmGotoSRS").focus();
					}.bind(this)
				});
			},

			//*******************************************************************************************************
			//***********************************      Event Handler     ********************************************
			//*******************************************************************************************************

			/**
			 * user has pressed button "Continue". Depending on the selectec service product we have to
			 * continue either in SRS-app or in HEP-SO-creation
			 * If the user has not choosen anything, we go to SR-creation
			 * If the user has selected a service, with ResulType "SR" and NOT selected to skip the scoping, we also go to SR-creation,
			 * but handing over already the selected service and session
			 * In all other cases we go to SO creation
			 *
			 * @param {string} sServicePathSPD  - oData-Service path to access BE
			 */
			fnOnServProdSelectionBtnContinue: function () {
				let bSkipScoping = this._oAddServiceModel.getData().skipScopingSelected;
				let oSelectedObject = this._oAddServiceModel.getData().selectedObject;
				if ($.isEmptyObject(oSelectedObject)) {
					this._fnNavToSrsAppCreation(); //simply create a new SR
				} else if (oSelectedObject.ResultType === "SR") {
						if (bSkipScoping) {
							this._fnShowUserConfirmNavDialog();
						} else {
							this._fnNavToSrsAppCreation();
						}
					} else if (bSkipScoping) {
							this._fnNavToSoCreation();
						} else {
							this._fnNavToSrsAppCreation();
						}
			},

			/**
			 * user has pressed button "Goto Service Request Scoping" in confirmation-dialog..
			 */
			fnOnServProdSelectionBtnGotoSrs: function () {
				this._fnNavToSrsAppCreation();
			},

			/**
			 * user has pressed button "Continue without Scoping" in confirmation-dialog.
			 */
			fnOnServProdSelectionBtnGotoSo: function () {
				this._fnNavToSoCreation();
			},

			/**
			 * user has pressed button "Cancel".
			 * Just the Dialog is closed
			 */
			fnOnServProdSelectionBtnCancel: function () {
				this._oDialogServiceProductSelection.close();
			},

			/**
			 * user has triggered navigation from master-page of the dialog to the selection-page.
			 * The screen size needs be be ajustd to the bigger size and the continue-button disabled
			 */
			fnOnServProdSelectionNavToPageSelection: function () {
				let sCustomerId = this._oView.getModel("spdDetails").getData().CaseDetails.CustomerID;
				this._pLoadServiceHierarchyFromCRM(sCustomerId).then(() => {
					this._oAddServiceModel.getData().dialogServProdSelectionWidth = "60rem";
					this._oAddServiceModel.getData().dialogServProdSelectionHeight = "80%";
					this._oAddServiceModel.getData().bBtnContinueEnabled = false;
					this._oAddServiceModel.refresh();
					this._oView.byId("navContainerServProdSelectionDialog").to(this._oView.byId("pageServProdSelectionDialogSelection"));
				});
			},

			/**
			 * user has triggered navigation from selection-page back to the master-page of the dialog.
			 * The screen size needs be be ajustd to the smaller size and the continue-button enabled
			 */
			fnOnServProdSelectionNavToPageMaster: function () {
				this._oAddServiceModel.getData().dialogServProdSelectionWidth = "34rem";
				this._oAddServiceModel.getData().dialogServProdSelectionHeight = "13rem";
				this._oAddServiceModel.getData().bBtnContinueEnabled = true;
				this._oAddServiceModel.refresh();
				this._oView.byId("navContainerServProdSelectionDialog").to(this._oView.byId("pageServProdSelectionDialogMaster"));
			},

			/**
			 * user has clicked on the i-Information-Icon next to "Skip Scoping". A small Popover-control is created and an
			 * information text displayed
			 */
			fnOnServProdSelectionShowSkipInformation: function () {
				let oInfoIcon = this._oView.byId("idFormServiceProdSelectionSkipScopingInfoIcon");
				new sap.m.Popover({
					showHeader: false,
					content: [
						new sap.m.Text({
							text: this._oResourceBundle.getText("ServiceProductSelection.AddServiceDialog.SkipScopingInfo")
						}).addStyleClass("sapUiSmallMargin")
					]
				}).openBy(oInfoIcon);
			},

			/**
			 * user has entered search critera and result tree needs to be filtered
			 * (works with live search and normal search)
			 *
			 * @param {object} oEvent - Event Data coming in
			 */
			fnOnServProdSelectionFilterResult: function (oEvent) {
				let sFilterString = oEvent.getParameter("query") ? oEvent.getParameter("query") : oEvent.getParameter("newValue");
				let aServicesFiltered = this._oAddServiceModel.getData().aSrvHierarchyFromCRM.slice(); // fastest way to create a copy
				if (sFilterString) {
					sFilterString = sFilterString.toUpperCase();
					aServicesFiltered = this._oAddServiceModel.getData().aSrvHierarchyFromCRM.filter((oSrv) => {
						return oSrv.FreeTextSearch.includes(sFilterString);
					});
				}
				this._buildSrvHierarchyTree(aServicesFiltered);
			},

			/**
			 * user wants to expand the service hierarchy tree
			 */
			fnOnServProdSelectionResultListExpand: function () {
				this._oView.byId("treeTableServiceHierachy").expandToLevel(2);
			},

			/**
			 * user wants to collapse the service hierarchy tree
			 */
			fnOnServProdSelectionResultListCollapse: function () {
				this._oView.byId("treeTableServiceHierachy").collapseAll();
			},

			/**
			 * user has selected a session/service from the result list.
			 * Identify the selected item, enrich it with some data and fill it as "selectedObject" into the model
			 * and enabled/disable the "skip scoping" checkbox, depending on the resultType of the selected item (SR or SO)
			 *
			 * @param {object} oEvent - Event Data coming in
			 */
			fnOnServProdSelectionResultListSessionSelected: function (oEvent) {
				this._oAddServiceModel.getData().selectedObject = this._oAddServiceModel.getProperty(oEvent.getSource().getParent().getParent().getBindingContext(
					"addServiceModel").sPath);
				if (this._oAddServiceModel.getData().selectedObject.Type === "multiSession") {
					let sPathParentService = oEvent.getSource().getParent().getParent().getBindingContext("addServiceModel").sPath;
					sPathParentService = sPathParentService.slice(0, sPathParentService.lastIndexOf("Children") - 1);
					this._oAddServiceModel.getData().selectedObject = this._oAddServiceModel.getProperty(sPathParentService);
				}
				let oDataForServiceFromCRM = this._oAddServiceModel.getData().aAllServicesFromCrm.find(elm => elm.ServiceID === this._oAddServiceModel
					.getData().selectedObject.ServiceProductId);
				if (oDataForServiceFromCRM) {
					this._oAddServiceModel.getData().selectedObject.ResultType = oDataForServiceFromCRM.ResultType; //SO or SR
					this._oAddServiceModel.getData().skipScopingEnabled = oDataForServiceFromCRM.ResultType === "SR";
					this._oAddServiceModel.getData().skipScopingSelected = oDataForServiceFromCRM.ResultType !== "SR";
					let oFurtherSessionData = this._oAddServiceModel.getData().aSrvHierarchyFromCRM.find(elm => elm.SessionProductId ===
						oDataForServiceFromCRM.ComponentID);
					if (oFurtherSessionData?.ScopingMandatory) {
						//overrules everything
						this._oAddServiceModel.getData().skipScopingEnabled = false;
						this._oAddServiceModel.getData().skipScopingSelected = false;
					}
				}
				this._oAddServiceModel.refresh();
				this.fnOnServProdSelectionNavToPageMaster();
			},

			/**
			 * user has clicked on one of the (i)-information-icons in the result list
			 * In case a session was selected (3rd level), open the SSC-page for that session. In case a service was selected (2nd level)
			 * open that service in SSC.
			 *
			 * @param {object} oEvent - Event Data coming in
			 */
			fnOnServProdSelectionResultListInfoIconClicked: function (oEvent) {
				const sSelectedSessionId = this._oAddServiceModel.getProperty(oEvent.getSource().getParent().getParent().getBindingContext(
					"addServiceModel").sPath).SessionId;
				const sSelectedServiceId = this._oAddServiceModel.getProperty(oEvent.getSource().getParent().getParent().getBindingContext(
					"addServiceModel").sPath).ServiceProductId;
				const sSelectedId = sSelectedSessionId || sSelectedServiceId;
				const sUrlToSsc = Constants.getSscUrl(sSelectedId);
				NavigationToExternalApps.fnHandleLinkNavigation(sUrlToSsc);
			}

		};
	}
);
