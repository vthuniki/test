sap.ui.define([
	"com/sap/ui/hep/reuse/Constants",
	"com/sap/ui/hep/model/formatter",
	"sap/ui/model/odata/v2/ODataModel",
	"com/sap/ui/hep/util/MessageHandlingPopover",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/base/Log"
], function (Constants, Formatters, ODataModel, MessageHandlingPopover, MessageToast, MessageBox, Log) {
	"use strict";

	return {
		formatter: Formatters,
		messageHandler: MessageHandlingPopover,

		initializeDetails: function (oContext) {
			oContext._oData.busyAttachments = false;
			oContext._oData.attachments = {};
			oContext._oData.attachments.items = [];		
			oContext._oData.numberOfAttachments = 0;
			oContext._oData.newAttachmentDescription = "";	
			oContext._nbUploadingFiles = null;
			oContext._nbFileUploaded = 0;
			this._initializeNoData(oContext);	
			this.btnText = oContext.getView().getModel("i18n").getResourceBundle().getText("Attachments.Add");
			
			this._oUploadSet = oContext.getView().byId('idAttachmentsUploadSet');
			this._oUploadSet.getDefaultFileUploader().setButtonText(this.btnText);
		},

		_initializeNoData: function (oContext) {
			let isProjectPage = oContext.getView().getViewName().indexOf("ProjectDetails") > 0,
				sProjectDetailsText = oContext.getResourceBundle().getText("ProjectDetails.Attachments.NoDataDescription"),
				sSOText = oContext.formatter.formatAttachmentsNoDataDescription(oContext.getView(), true),
				noDataText = isProjectPage ? sProjectDetailsText : sSOText;
			oContext._oData.attachments.noDataDescription = noDataText;
			oContext._oData.isProjectPage = isProjectPage;
			oContext._oModel.refresh();
		},

		_fnSetAttachmentText: function (oContext, sText) {
		    oContext._oData.newAttachmentDescription = sText;
	    	oContext.getView().getModel("localModel").refresh();
		},

		//=============================================== General Setup ==============================================

		fnBuildAttachmentsCollection: function (oContext, isProjectPage) {
			const bEditAllowed = oContext.getModel("localModel").getData().formEditMode === true || isProjectPage === true;
			this._oUploadSet.destroyItems();
			this._oUploadSet.setUploadEnabled(bEditAllowed);
			oContext.byId("idInputNewAttachmentDescription").setEnabled(bEditAllowed);
			this._oUploadSet.bindAggregation("items", "localModel>/attachments/items", () => {
				const item = new sap.m.upload.UploadSetItem({
					fileName: {
						parts: [{
							path: "localModel>FileName"
						}, {
							path: "localModel>FileType"
						}],
						formatter: (FileName, FileType) => this.formatter.formatFileName(FileName, FileType)
					},
					tooltip: "{localModel>FileGuid}",
					visibleEdit: false,
					visibleRemove: true,
					url: "{localModel>FileUrl}",
					enabledRemove: bEditAllowed,
					uploadState: "Complete",
					mediaType: "{localModel>FileType}",
					openPressed: [function (oEvent) {
						// Overwrites default press method due to APIM header restriction
						this._fnDownloadAttachment(oEvent);
					},this] ,
					removePressed: [function (oEvent) {
						let oEventRemove = oEvent;
						oEvent.preventDefault();
						oContext.oUploadObjectId = oEvent.getSource().mAggregations.headerFields[0].mProperties.key;
						let oThis = this;
						MessageBox.confirm(oContext.getView().getModel("i18n").getResourceBundle().getText("Attachments.DeleteConfirm",[oEvent.getSource().getFileName()]), {
							actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
							emphasizedAction: MessageBox.Action.OK,
							onClose: function (sAction) {
								if ( sAction === 'OK') {
									// Overwrites default press method due to APIM header restriction
									oThis._fnDeleteAttachment(oEventRemove, oContext, oContext._oData.isProjectPage );
								}
							}
						});
					}, this]
				});
				item.addAttribute( new sap.m.ObjectAttribute({
					active: false,
					text: "{localModel>FileDescription}"
				}));
				item.addAttribute( new sap.m.ObjectAttribute({
					active: false,
					title: "Created at",
					text: "{localModel>FileCreatedAt}"
				}));
				item.addHeaderField(new sap.ui.core.Item({
					key: "{localModel>FileGuid}"
				}));
				return item;
			});
			
		},

		_fnDownloadAttachment: function (oEvent) {
			oEvent.preventDefault();
			const bindingContext = oEvent.getSource().getBindingContext("localModel");
			let sUrl = bindingContext.getObject("FileUrl");
			let sFilename = bindingContext.getObject("FileName");
			let oHeaders = Constants.getAPIHeaders();
			MessageToast.show(oEvent.getSource().getModel("i18n").getResourceBundle().getText("Attachments.Download.Toast"));
			let messageDownloadedFailed = oEvent.getSource().getModel("i18n").getResourceBundle().getText("Attachments.DownloadError.Toast");
			fetch(sUrl, {
				headers: oHeaders
			}).then(oResponse => oResponse.blob()).then(blob => {
				let sBlobUrl = window.URL.createObjectURL(blob);
				let oAnchor = document.createElement("a");
				oAnchor.href = sBlobUrl;
				oAnchor.download = sFilename;
				document.body.appendChild(oAnchor);
				oAnchor.click();
				document.body.removeChild(oAnchor);
				window.URL.revokeObjectURL(sUrl);
			}).catch(error => {
				MessageToast.show(messageDownloadedFailed);
				if (error.message === "Download failed") {
					Log.error(`Couldn't download file at ${error.cause.url}\nThe status is ${error.cause.statusCode} / ${error.cause.statusText}.\n\nThe response is\n${error.cause.response}`, error);
				} else {
					Log.error(`Couldn't download file at ${sUrl}`, error);
				}
			});
		},
	

		_fnDeleteAttachment: function (oEvent, oContext) {
			this.messageHandler.fnRemoveMessagesOlderThan(0.01, "AttachmentUpload"); 
			let sItemToDeleteId =	oContext.oUploadObjectId,
				oData = this._oUploadSet.getModel("localModel").getData().attachments,
				aItems = oData.items;
			aItems.forEach((item, index) => {
				if (item && item.FileGuid === sItemToDeleteId) {
					oContext.getView().getModel("localModel").getData().busyAttachments = true;
					oContext.getView().getModel("localModel").refresh();
					this._fnHandleFileDeleted([item.FileGuid], oContext).then(() => {
						aItems.splice(index, 1);
						this._oUploadSet.getModel("localModel").getData().attachments.items = aItems;
						this._oUploadSet.getModel("localModel").refresh();
						let sSuccessTitle = oContext.getResourceBundle().getText("Attachments.DeleteFile.Success.Title"),
							sSuccessSubtitle = oContext.getResourceBundle().getText("Attachments.DeleteFile.Success.Subtitle", [item.FileName]),
							sSuccessMessage = oContext.getResourceBundle().getText("Attachments.DeleteFile.Success.Content", [item.FileName]);
						this.messageHandler.addNewMessageseInsidePopover("AttachmentUploadFileDeletedSuccess" + item.FileGuid, "Success",	sSuccessTitle, sSuccessMessage, sSuccessSubtitle, oContext);
						oContext._oData.numberOfAttachments = aItems.length;
						oContext.getView().getModel("localModel").getData().busyAttachments = false;
						oContext.getView().getModel("localModel").refresh();
					}).catch(() => {
						let sErrorTitle = oContext.getResourceBundle().getText("Attachments.DeleteFile.Error.Title"),
							sErrorSubtitle = oContext.getResourceBundle().getText("Attachments.DeleteFile.Error.Subtitle", [item.FileName]),
							sErrorMessage = oContext.getResourceBundle().getText("Attachments.DeleteFile.Error.Content", [item.FileName]);
						this.messageHandler.addNewMessageseInsidePopover("AttachmentUploadFileDeletedError" + item.FileGuid, "Error",	sErrorTitle, sErrorMessage, sErrorSubtitle, oContext);
						oContext.getView().getModel("localModel").getData().busyAttachments = false;
						oContext.getView().getModel("localModel").refresh();
					});
				}
			});
			
		},

		_fnHandleFileDeleted: function (documentIds, oContext) {
			return new Promise((resolve, reject) => {
				let sBatchProjectDetails = "/" + "AttachmentSet(" +
					"ProjectID='" + oContext._idProject + "',";

				let sBatchSO = "/" + "AttachmentSet(" +
					"ObjectGuid=guid'" + oContext._idServiceOrderGuid + "',";
				let sBatchIndividualUrl = '';
				if (oContext._idProject !== '' && !oContext._idServiceOrderGuid ) {
					sBatchIndividualUrl = sBatchProjectDetails;
				} else {
					sBatchIndividualUrl = sBatchSO;
				}

				let myServiceUrl = Constants.getServicePath();
				let oBModel = new ODataModel(myServiceUrl);
				oBModel.setHeaders(Constants.getAPIHeaders());
				documentIds.forEach((docID) => {
					let entirePath = "";
					oBModel.setDeferredGroups(["groupSetId"]);
					entirePath = sBatchIndividualUrl + "FileGuid='" + docID + "')";
					oBModel.remove(entirePath, {
						groupId: "groupSetId"
					});
				});
				oBModel.submitChanges({
					groupId: "groupSetId",
					headers: {
						"accept": " text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8"
					},
					success: () => {
						resolve();
					},
					error: (oError) => {
						reject(new Error('Error ...', {cause: oError}));
					}
				});
			});
		},

		//=============================================== Event Handler  =============================================

		fnHandleBeforeUploadStarts: function (oEvent, oContext) {
			this.messageHandler.fnRemoveMessagesOlderThan(4, "AttachmentUpload");
			MessageToast.show(oEvent.getSource().getModel("i18n").getResourceBundle().getText("Attachments.Upload.Toast"));
			oContext._oData.busyAttachments = true;
			oContext._oModel.refresh();   
		    this._oUploadSet.setBusy(true);
		    oContext._oModel.refresh();
		    let isProjectPage = oContext.getMetadata()._sClassName.includes("ServiceOrder") ? false : true;
			let slugValue = isProjectPage === true ? oContext._idProject : oContext._idServiceOrderGuid;
			let oApiHeaders = Constants.getAPIHeaders();
			let oCustomerHeaderSlug;
			let oApiKey;
			let oApiSecret;
			let oCustomerHeaderTokenToken;
		
			let attachmentDesc = oContext._oData.newAttachmentDescription;
			if ( !attachmentDesc || attachmentDesc === "" ) {
				attachmentDesc = "description";
			}
			oCustomerHeaderSlug = new sap.ui.core.Item({
				key: "SLUG",
				text: encodeURIComponent(slugValue + "/" + oEvent.getParameters().item.getFileName() + "/" + attachmentDesc)
			});
			oApiKey = new sap.ui.core.Item({
				key: "APIKey",
				text: oApiHeaders.APIKey
			});
			oApiSecret = new sap.ui.core.Item({
				key: "APISecret",
				text: oApiHeaders.APISecret
			});
			oCustomerHeaderTokenToken = new sap.ui.core.Item({
				key: "x-csrf-token",
				text: oContext._token
			});
		
			oEvent.getParameters().item.addHeaderField(oCustomerHeaderSlug);
			oEvent.getParameters().item.addHeaderField(oApiKey);
			oEvent.getParameters().item.addHeaderField(oApiSecret);
			oEvent.getParameters().item.addHeaderField(oCustomerHeaderTokenToken);	    
		},

		fnHandleUploadCompleted: function (oEvent, oContext) {		
			oContext._oData.busyAttachments = true;
			oContext._oModel.refresh();
			oContext._nbFileUploaded++;
			oContext._oData.newAttachmentDescription = "";
			this._fnSetAttachmentText(oContext,"");
			let isProjectPage = oContext.getMetadata()._sClassName.includes("ServiceOrder") ? false : true,
			 	oFile = oEvent.getParameters(),
			 	sFileName = oFile.item.getFileName(),	    
				bUploadError = oFile?.status !== 200 && oFile?.status !== 201,
				sMessageType = bUploadError ? "Error" : "Success",
				sMessageID = "AttachmentUpload" + sFileName + (new Date()).getTime(),
				sMessageTitle = bUploadError ? oContext.getResourceBundle().getText("Attachments.Upload.Title") : oContext.getResourceBundle().getText("Attachments.FileAdded.Success.Title"),
				sMessageSubTitle = bUploadError ? oContext.getResourceBundle().getText("Attachments.UploadCompleted.Error.SubTitle", [sFileName]) : oContext.getResourceBundle().getText("Attachments.FileAdded.Success.Subtitle", [sFileName]),
				sMessageDescription = bUploadError ? oContext.getResourceBundle().getText("Attachments.UploadCompleted.Error", [sFileName]) : oContext.getResourceBundle().getText("Attachments.FileAdded.Success.Content", [sFileName]);

			if (oFile?.item._fFileSize === 0) {	//special error case
				sMessageDescription = oContext.getResourceBundle().getText("Attachments.UploadCompleted.Error.Empty", [sFileName]);
				sMessageSubTitle = oContext.getResourceBundle().getText("Attachments.UploadCompleted.Error.Empty.SubTitle");
			}	
			
			this.messageHandler.addNewMessageseInsidePopover(sMessageID, sMessageType, sMessageTitle, sMessageDescription,	sMessageSubTitle, oContext);			
				
			if (isProjectPage) this.fnReadAttachmentsProjectDetails(oContext);
			else this.fnReadAttachmentsSO(oContext);
			
			oContext?.inactiveBusyIndicators(oContext);
		},

		fnHandleFileSizeExceed: function (oEvent, oContext) {
			let bFileUploaderUsed = !oEvent.getParameters().item.sParentAggregationName,
				sFileName = oEvent.getParameters()?.item.getFileName(),
				sMessageID,
				sErrorTitle, 
				sErrorSubtitle, 
				sErrorMessage;
			if (bFileUploaderUsed){
				this.messageHandler.fnRemoveMessagesOlderThan(0.01, "AttachmentUpload"); 
				sMessageID = "AttachmentUploadExceedSizeError";
				sErrorTitle = oContext.getResourceBundle().getText("Attachments.SizeExceededUploadError.AllFailed.Title");
				sErrorSubtitle = oContext.getResourceBundle().getText("Attachments.SizeExceededUploadError.AllFailed.Subtitle");
				sErrorMessage = oContext.getResourceBundle().getText("Attachments.SizeExceededUploadError.AllFailed.Description", [sFileName, oContext._oData.attachments.fileSizeLimit]);
			} else {
				sMessageID = "AttachmentUploadExceedSizeError" + sFileName + (new Date()).getTime();
				sErrorTitle = oContext.getResourceBundle().getText("Attachments.SizeExceededUploadError.Title");
				sErrorSubtitle = oContext.getResourceBundle().getText("Attachments.SizeExceededUploadError.Subtitle", [sFileName]);
				sErrorMessage = oContext.getResourceBundle().getText("Attachments.SizeExceededUploadError.Description", [sFileName, oContext._oData.attachments.fileSizeLimit]);
			}
			this.messageHandler.addNewMessageseInsidePopover(sMessageID, "Error", sErrorTitle,	sErrorMessage, sErrorSubtitle, oContext);
			this._oUploadSet.removeIncompleteItem(oEvent.getParameters().item);
		},

		//====================================== Projects / Engagements ===============================================================

		fnReadAttachmentsProjectDetails: function (oContext) {
			this._oUploadSet.setBusy(true);
			oContext._oModel.refresh(); 
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ProjectSet";
			entities.getEntity = oContext._idProject;
			entities.navigation = "toAttachment";
			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.errorMessage = oContext.getResourceBundle().getText("ProjectDetails.ReadAttachmentError", [this._idProject]);
			entities.busyIndicator = "busyAttachments";
			entities.callbackSuccess = (data) => {
				this._handleSuccessAttachmentsProjectDetails(data, oContext);
			};
			oContext.readBaseRequest(entities);
			oContext._oData.numberOfAttachments = 0;
			oContext._oModel.refresh();
		},

		_handleSuccessAttachmentsProjectDetails: function (data, oContext) {
			oContext._oData.attachments.items = data.results;
			oContext._oData.numberOfAttachments = data.results.length;
			$.each(oContext._oData.attachments.items, (iAttachment, oAttachment) => {
				oAttachment.FileUrl = Constants.getServicePathWithoutLangParam() +
					"AttachmentSet(ProjectID='" + oContext._idProject + "',FileGuid='" + oAttachment.FileGuid + "')/$value" +
					Constants.getServicePathLangParam();
			});
			oContext._oData.busyAttachments = false;
			oContext._oData.attachments.fileSizeLimit = Constants.getAttachmentsFileSizeLimit();
			this.fnBuildAttachmentsCollection(oContext, true);
			oContext._oModel.refresh();
		},

 		//==========================================  Service Orders  ============================================================

		fnReadAttachmentsSO: function (oContext) {
			return new Promise((resolve, reject) => {
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "ServiceOrderSet(guid'" + oContext._idServiceOrderGuid + "')";
				entities.navigation = "toAttachment";
				entities.currentView = oContext.getView();
				entities.oContext = oContext;
				entities.errorMessage = oContext.getResourceBundle().getText("ProjectDetails.ReadAttachmentError", [this._idProject]);
				entities.busyIndicator = "busyAttachments";
				entities.callbackSuccess = (data) => {
					oContext._oData.attachments.items = data.results;
					oContext._oData.numberOfAttachments = data.results.length;
					$.each(oContext._oData.attachments.items, (iAttachment, oAttachment) => {
						oAttachment.FileUrl = Constants.getServicePathWithoutLangParam() +
							"AttachmentSet(ObjectGuid=guid'" + oContext._idServiceOrderGuid + "',FileGuid='" + oAttachment.FileGuid + "')/$value" +
							Constants.getServicePathLangParam();
					});
					oContext._oData.busyAttachments = false;
					oContext._oData.attachments.fileSizeLimit = Constants.getAttachmentsFileSizeLimit();
					oContext._oModel.refresh();
					this.fnBuildAttachmentsCollection(oContext, false);
					resolve();
				};
				oContext.readBaseRequest(entities);
			});
		}
	
	};
});
