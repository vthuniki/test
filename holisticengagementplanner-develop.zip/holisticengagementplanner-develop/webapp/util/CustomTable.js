sap.ui.define([
	"com/sap/ui/hep/util/TableSortHelper"
], function (SortHelper) {
	"use strict";

	return sap.m.Table.extend("com.sap.ui.hep.util.CustomTable", {
		metadata: {
			properties: {
				"sorting": {
					type: "boolean",
					defaultValue: false
				},
				"triggerBESorting": {
					type: "boolean",
					defaultValue: false
				},
				"showFilter": {
					type: "boolean",
					defaultValue: false
				},
				"context": {
					type: "object",
					defaultValue: null
				},
				"showSelectAll": {
					type: "boolean",
					defaultValue: true
				}
			}
		},

		renderer: function (oRm, oControl) {
			sap.m.TableRenderer.render(oRm, oControl); //use superclass renderer routine
		},

		onAfterRendering: function () {
			if (sap.m.Table.prototype.onAfterRendering) {
				sap.m.Table.prototype.onAfterRendering.apply(this, arguments);
			}
			if (this.getSorting() === false) {
				let columns = this.getColumns();
				columns.forEach(function (oCol) {
					oCol.setSortField();
				});
			}
		},

		_bindAggregation: function (sName, oBindingInfo) {
			if (sap.m.Table.prototype._bindAggregation) {
				sap.m.Table.prototype._bindAggregation.call(this, sName, oBindingInfo);
			}
			if (sName === "items") {
				this._updateSorting();
			}
		},

		resetSorting: function () {
			let columns = this.getColumns();
			columns.forEach(function (oCol) {
				oCol.setSortIndicator(sap.ui.core.SortOrder.None);
			});
			let binding = this.getBinding("items");
			binding.sort(null);
		},

		onColumnPress: function (oColumn) {
			if (sap.m.Table.prototype.onColumnPress) {
				sap.m.Table.prototype.onColumnPress(oColumn);
			}
			if (oColumn.getSortIndicator() === "None" && oColumn.getSortField() !== "") {
				oColumn.setSortIndicator(sap.ui.core.SortOrder.Ascending);
				this._updateSorting(oColumn);
			} else if (oColumn.getSortField() === "") {
				oColumn.setSortIndicator(sap.ui.core.SortOrder.None);
			} else {
				this._updateSorting(oColumn);
			}
		},

		_updateSorting: function (oColumn) {
			if (oColumn) {
				this._sortConfig = {
					field: oColumn.getSortField(),
					type: oColumn.getSortType === undefined ? null : parseInt(oColumn.getSortType(), 10)
				};
			} else {
				this._sortConfig = null;
			}
			if (oColumn) {
				SortHelper.updateSorting(this, this._sortConfig, oColumn);
				let oSort = {
					field: this._sortConfig.field,
					order: oColumn.getSortIndicator(),
					column: oColumn.getId().split("--")[3] ? oColumn.getId().split("--")[3] : oColumn.getId().split("--")[1]
				};
					if (this.getContext()) { // && this.getTriggerBESorting() === true
						this.getContext().fnHandleSearchForItems(oSort);
					} else 
						this.getSortFieldDraft(oSort);
					} 
				else {
				SortHelper.updateSorting(this, this._sortConfig);
			}
		},

		setShowSelectAll: function (bValue) {
			this.bPreventMassSelection = !bValue;
			this.setProperty("showSelectAll", bValue);
			return this;
		},
		  
		getSortFieldDraft: function(myData) {
		    sap.ui.getCore().getEventBus().publish("channelSortDraft", "sortEvent2", { myData }); // broadcast the event
		 }
		
	});
});