sap.ui.define("com/sap/ui/hep/util/TablePersoEngagementCases",
    [
        "com/sap/ui/hep/util/SessionTablePersoBaseService"
    ],
    function (SessionTablePersoBaseService) {
        "use strict";

        const PersoService = SessionTablePersoBaseService.extend("com.sap.ui.hep.util.TablePersoEngagementCases", {
            constructor: function () {
                SessionTablePersoBaseService.call(this, "tablePerso-idEngagementsTable.json", "homeEngTableConfig");
            },
        });

        return new PersoService();
    }, /* bExport= */ true);
