sap.ui.define([
	"sap/m/MessageBox",
	"com/sap/ui/hep/reuse/Constants",
	"sap/m/MessageToast",
	"com/sap/ui/hep/model/formatter",
	"com/sap/ui/hep/util/Dates",
	"com/sap/ui/hep/util/ServiceOrderValidation",
	"com/sap/ui/hep/util/Validator",
	"com/sap/ui/hep/util/MessageHandlingPopover",
	"sap/ui/model/odata/v2/ODataModel",
	"com/sap/ui/hep/util/Attachments"

], function (MessageBox, Constants, MessageToast, Formatters, Dates, ServiceOrderValidation, GenericFormValidator,
	MessageHandlingPopover, ODataModel, Attachments) {
	"use strict";

	return {

		formatter: Formatters,
		dates: Dates,
		SOValidation: ServiceOrderValidation,
		messageHandler: MessageHandlingPopover,
		attachments: Attachments,




		additionalInfoValidation: function (oContext) {
			let oGenericFormValidator = new GenericFormValidator(),
				oSOModel = oContext.getView().getModel("oModelSO"),
				bServiceDataSectionValid = oGenericFormValidator.validateAndHighlightMissingMandatoryFields(
					oContext.getView().byId("formServiceData"), oSOModel, oContext, false);
			if (bServiceDataSectionValid) {
				oSOModel.getData().wizardDataStepValid = true;
			} else {
				oSOModel.getData().wizardDataStepValid = false;
			}
			oSOModel.refresh();
		},

		/**
		 * Proceed after the service is selected (either by URL-Parameter in case of creation, or by displaying an existing SO)
		 * @param {object} oContext the context from which the method is triggered
		 */
		proceedAfterServiceProductIsSet: function (sServiceProductId, oContext) {
			oContext.getView().getModel("oModelSO").getData().busySO = true;
			oContext.getView().getModel("oModelSO").getData().showDescription = true;
			oContext.getView().getModel("oModelSO").refresh();
			if (!oContext._idServiceOrder) {
				oContext.getView().getModel("oModelSO").getData().Description = oContext.getView().getModel("oModelSO").getData().MainProductText;
				oContext.getView().getModel("oModelSO").refresh();
				oContext.getView().byId("soDescription").fireLiveChange();
			}
			this._resetContractFields(oContext);
			this._raiseDeliveryMessage(oContext);
			this._pReadServiceProductAllComponents(sServiceProductId, oContext).then((res, rej) => {
				oContext.collectSoRelevantServiceProductComponents();
				oContext.checkBilling(); // As this is a billing relevant parameter, we need to refresh billing options from BE
				this.SOValidation.validateSoDataStepField(oContext.getView().getModel("oModelSO"), oContext);
			});
		},

		/**
		 * Raise warning message in case one is customizied for chosen product
		 * @param {object} oContext the context from which the method is triggered
		 * @param {string} sproductIdSelected selected product id
		 */
		_raiseDeliveryMessage: function (oContext) {
			let sProductID = oContext.getView().getModel("oModelSO").getData().MainProduct;
			let oServiceProduct = oContext.serviceHierarchyBaseData.find(elem => elem.ServiceProductId === sProductID);
			oContext.getView().getModel("oModelSO").getData().DelMsgVisible = false;
			if (oServiceProduct.DelMsgMessage !== "") {
				oContext.getView().getModel("oModelSO").getData().DelMsgVisible = true;
				oContext.getView().getModel("oModelSO").getData().DelMsgText = oServiceProduct.DelMsgMessage + " " + oServiceProduct.DelMsgLongtext;
				switch (oServiceProduct.DelMsgType) {
					case "W":
						oContext.getView().getModel("oModelSO").getData().DelMsgType = "Warning";
						break;
					case "E":
						oContext.getView().getModel("oModelSO").getData().DelMsgType = "Error";
						break;
					default:
						oContext.getView().getModel("oModelSO").getData().DelMsgType = "Information";
						break;
				}
			}
			oContext.getView().getModel("oModelSO").refresh();
		},

		_readSOContracts: function (sSOProductID, oContext) {
			let entities = {},
				sDatePropertyId,
				sDate,
				iCustomerID = oContext.getView().getModel("projectDetails").getData().CustomerID === undefined ?
					// In Edit mode, project details is not filled (yet). But the customer ID is given by the SO details
					oContext.getView().getModel("oModelSO").getData().CustomerID :
					// In Create mode, CustomerID is only given by the project details - weird :(
					oContext.getView().getModel("projectDetails").getData().CustomerID;
			oContext.getView().getModel("oModelSO").getData().contractItemsAllWithoutContingent = false;
			oContext.getView().getModel("oModelSO").getData().busyContract = true;
			oContext.getView().getModel("oModelSO").refresh();

			if (oContext.getView().getModel("oModelSO").getData().goLiveRequired) {
				sDatePropertyId = "soGoLliveDate";
			}
			if (oContext.getView().getModel("oModelSO").getData().reqDelRequired) {
				sDatePropertyId = "soRecDelDate";
			}
			if (oContext.getView().byId(sDatePropertyId).isValidValue()) {
				sDate = new Date(oContext.getView().byId(sDatePropertyId).getDateValue());
				sDate = "datetime'" + this.dates._convertDateToBEZuluFormat(sDate) + "'";
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "ContractSet()";
				entities.filter = "CustomerID eq '" + iCustomerID + "'";
				entities.filter += " and ";
				entities.filter += "ProductID eq '" + sSOProductID + "' ";
				entities.filter += " and ";
				entities.filter += "RecDelDate eq " + sDate + "";
				entities.currentView = oContext.getView();
				entities.busyIndicator = "busyContract";
				entities.oContext = oContext;
				entities.model = "oModelSO";
				entities.errorMessage = oContext.getResourceBundle().getText("SO.ReadContractsError");
				entities.callbackSuccess = (data) => {
					this._handleSuccessReadSOContracts(data, oContext);
				};
				oContext.readBaseRequest(entities);
			} else {
				oContext.getView().getModel("oModelSO").getData().busyContract = false;
				oContext.getView().getModel("oModelSO").getData().contractVisible = false;
				oContext.getView().getModel("oModelSO").refresh();
			}
		},

		_handleSuccessReadSOContracts: function (data, oContext) {
			oContext.getView().getModel("oModelSO").getData().contractVisible = (data.results.length !== 0);
			oContext.getView().getModel("oModelSO").getData().contractSelected = false;
			oContext.getView().getModel("oModelSO").getData().contractsExist = (data.results.length !== 0);
			oContext.getView().getModel("oModelSO").getData().contracts = data.results;
			oContext.getView().getModel("oModelSO").refresh();
			this._setValidContract(oContext);

			if (data.results.length !== 0 ||
				(oContext._idServiceOrder && oContext.getView().getModel("oModelSO").getData().ContractID)) {
				oContext.getView().getModel("oModelSO").getData().newSOValid.contractID = "None";
				oContext.getView().getModel("oModelSO").getData().newSOValid.contractItems = "None";
				if (data.results.length === 1 && !oContext.getView().getModel("localModel").getData().loadingDataForEditMode) {
					oContext.getView().getModel("oModelSO").getData().contractSelectedKey = data.results[0].ContractID;
					oContext.getView().getModel("oModelSO").refresh();
					oContext.getView().byId("soContract").fireChange();
				} else {
					oContext.getView().getModel("oModelSO").getData().busyContract = false;
					oContext.getView().getModel("oModelSO").refresh();
				}
			} else {
				this._setNoContractAvailable(oContext);
				this._setNoContractItemAvailable(oContext);
				oContext.getView().getModel("oModelSO").getData().busyContract = false;
				oContext.getView().getModel("oModelSO").refresh();
				oContext.getView().getModel("localModel").getData().loadingDataForEditMode = false;
				oContext.getView().getModel("localModel").refresh();
			}
			oContext.getView().getModel("oModelSO").refresh();
			if (!oContext.getView().getModel("oModelSO").getData().contractRemovedAfterDateChange &&
				oContext._idServiceOrder && oContext.getView().getModel("oModelSO").getData().ContractID) {
				this._selectCurrentContract(oContext);
			} else {
				oContext.getView().getModel("localModel").getData().loadingDataForEditMode = false;
				oContext.getView().getModel("localModel").refresh();
			}
			oContext.getView().getModel("oModelSO").getData().contractRemovedAfterDateChange = false;
			oContext.getView().getModel("oModelSO").refresh();
		},

		_selectCurrentContract: function (oContext) {
			let sContractId = oContext.getView().getModel("oModelSO").getData().ContractID,
				sContractText = oContext.getView().getModel("oModelSO").getData().ContractText,
				sContractIdKey = this._findContractIdInSelectionList(sContractId, oContext);
			oContext.getView().byId("soContract").setSelectedKey(sContractIdKey);
			if (!sContractIdKey) {
				if (sContractText) {
					oContext.getView().byId("soContract").setValue(sContractText);
				}
				oContext.getView().byId("soContract").fireChange();
			} else {
				oContext.getView().byId("soContract").fireChange();
			}
		},

		_findContractIdInSelectionList: function (sContractId, oContext) {
			let sContractIdKey = "";
			$.each(oContext.getView().getModel("oModelSO").getData().contracts, function (iItem, oItem) {
				if (oItem.ContractID === sContractId) {
					sContractIdKey = oItem.ContractID;
				}
			});
			return sContractIdKey;
		},

		setContractItemFromBE: function (oContext) {
			let sContractItem = oContext.getView().getModel("oModelSO").getData().ContractItem;
			let sContractItemText = oContext.getView().getModel("oModelSO").getData().ContractItemText;

			let sContractItemKey = this._findContractItemInSelectionList(sContractItem, oContext);

			if (!sContractItemKey) {
				oContext.getView().byId("soContractItem").setValue(sContractItemText);
			} else {
				oContext.getView().byId("soContractItem").setSelectedKey(sContractItemKey);
			}

			oContext.getView().byId("soContractItem").fireChange();

		},

		_findContractItemInSelectionList: function (sContractItem, oContext) {
			let sContractItemKey = "";
			$.each(oContext.getView().getModel("oModelSO").getData().contractItems, function (iItem, oItem) {
				if (oItem.ContractItemID === sContractItem) {
					sContractItemKey = oItem.ContractItemID;
				}
			});
			return sContractItemKey;
		},

		_resetContractFields: function (oContext) {
			oContext.getView().getModel("oModelSO").getData().contracts = [];
			oContext.getView().getModel("oModelSO").getData().contractSelectedKey = null;
			oContext.getView().getModel("oModelSO").getData().contractItems = [];
			oContext.getView().getModel("oModelSO").getData().contractItemSelectedKey = null;
			oContext.getView().getModel("oModelSO").refresh();
		},

		validateSOCreationFields: function (oContext) {
			this.validateProdIDCreationFields(oContext);
			this.validateContractCreationFields(oContext);
			this.validateReqDateCreationsFields(oContext);
			this.validateGoLiveCreationFields(oContext);
			if (oContext._idServiceOrder) {
				this.validateAllFieldsWhenSOExist(oContext);
			}
			if (oContext.getView().getModel("oModelSO").getData().newSOValid.productID === "Error" ||
				oContext.getView().getModel("oModelSO").getData().newSOValid.contractID === "Error" ||
				oContext.getView().getModel("oModelSO").getData().newSOValid.contractItems === "Error" ||
				oContext.getView().getModel("oModelSO").getData().newSOValid.reqDelDate === "Error" ||
				oContext.getView().getModel("oModelSO").getData().newSOValid.goLiveDate === "Error") {
				oContext.getView().getModel("oModelSO").getData().newSOValid.save = false;
			} else if (oContext._idServiceOrder) {
				if (oContext.getView().getModel("oModelSO").getData().newSOValid.projectPhase === "Error" ||
					// oContext.getView().getModel("oModelSO").getData().newSOValid.refObj === "Error" ||
					oContext.getView().getModel("oModelSO").getData().newSOValid.accountContactPerson === "Error") {
					oContext.getView().getModel("oModelSO").getData().newSOValid.save = false;
				} else {
					oContext.getView().getModel("oModelSO").getData().newSOValid.save = true;
				}
			} else {
				oContext.getView().getModel("oModelSO").getData().newSOValid.save = true;
			}
			oContext.getView().getModel("oModelSO").refresh();
		},

		validateProdIDCreationFields: function (oContext) {
			if (oContext.getView().byId("soProdID").getValue() === "") {
				oContext.getView().getModel("oModelSO").getData().newSOValid.productID = "Error";
			} else {
				oContext.getView().getModel("oModelSO").getData().newSOValid.productID = "None";
			}
		},

		validateContractCreationFields: function (oContext) {
			if (oContext.getView().getModel("oModelSO").getData().contractRequired) {
				let bContractEnabled = this.formatter.formatContractAvailableForSelection(
					oContext.getView().getModel("oModelSO").getData().productIdSelected, 
					oContext.getView().getModel("oModelSO").getData().contractsExist,
					oContext.getView().getModel("oModelSO").getData().reqDelRequired, 
					oContext.getView().getModel("oModelSO").getData().reqDelDateExists,
					oContext.getView().getModel("oModelSO").getData().goLiveRequired, 
					oContext.getView().getModel("oModelSO").getData().goLiveExists
				);
				if (bContractEnabled && (oContext.getView().byId("soContract").getValue() === "" ||
					oContext.getView().byId("soContract").getSelectedItem().getKey() === "noData")) {
					oContext.getView().getModel("oModelSO").getData().newSOValid.contractID = "Error";
				}
				if (oContext.getView().getModel("oModelSO").getData().contractSelected &&
					(oContext.getView().byId("soContractItem").getValue() === "" ||
						oContext.getView().byId("soContractItem").getSelectedItem().getKey() === "noData")) {
					oContext.getView().getModel("oModelSO").getData().newSOValid.contractItems = "Error";
				}
			} else {
				oContext.getView().getModel("oModelSO").getData().newSOValid.contractID = "None";
				oContext.getView().getModel("oModelSO").getData().newSOValid.contractItems = "None";
			}
			oContext.getView().getModel("oModelSO").refresh();
		},

		validateReqDateCreationsFields: function (oContext) {
			if (oContext.getView().getModel("oModelSO").getData().reqDelRequired) {
				if (oContext.getView().byId("soRecDelDate").getValue() === "") {
					oContext.getView().getModel("oModelSO").getData().newSOValid.reqDelDate = "Error";
				}
			} else {
				oContext.getView().getModel("oModelSO").getData().newSOValid.reqDelDate = "None";
			}
		},

		validateGoLiveCreationFields: function (oContext) {
			if (oContext.getView().getModel("oModelSO").getData().goLiveRequired && oContext.getView().byId("soGoLliveDate").getVisible()) {
				if (oContext.getView().byId("soGoLliveDate").getValue() === "") {
					oContext.getView().getModel("oModelSO").getData().newSOValid.goLiveDate = "Error";
				}
			} else {
				oContext.getView().getModel("oModelSO").getData().newSOValid.goLiveDate = "None";
			}
			oContext.getView().getModel("oModelSO").refresh();
		},

		validateAllFieldsWhenSOExist: function (oContext) {
			if (oContext.getView().getModel("oModelSO").getData().refObjRequired) {
				if (oContext.getView().byId("ReferenceObject").getValue() === "") {
					oContext.getView().getModel("oModelSO").getData().newSOValid.refObjRequiredForRelease = "Information";
				} else {
					oContext.getView().getModel("oModelSO").getData().newSOValid.refObjRequiredForRelease = "None";
				}
			} else {
				oContext.getView().getModel("oModelSO").getData().newSOValid.refObjRequiredForRelease = "None";
			}

			if (oContext.getView().byId("AccountContactPerson").getValue() === "") {
				oContext.getView().getModel("oModelSO").getData().newSOValid.accountContactPerson = "Error";
			} else {
				oContext.getView().getModel("oModelSO").getData().newSOValid.accountContactPerson = "None";
			}

			if (oContext.getView().getModel("oModelSO").getData().FeedbackEnabled && oContext.getView().byId("SurveyRecipient")
				.getVisible()) {
				if (oContext.getView().byId("SurveyRecipient").getValue() === "") {
					oContext.getView().getModel("oModelSO").getData().newSOValid.surveyRecipient = "Error";
				}
			} else {
				oContext.getView().getModel("oModelSO").getData().newSOValid.surveyRecipient = "None";
			}
			oContext.getView().getModel("oModelSO").refresh();
		},

		/**
		 * (1) In a scenario where we only have mandatory components,
		 * there will be one call going to the backend, for the SO creation.
		 *
		 * (2) In a scenario where we have both mandatory and user selected components,
		 * the first calls goes with the so creation, without any componentns.
		 *
		 * After this, a second call with the user-selected components.
		 *
		 * The Mandatory components should be displayed as read-only
		 * and the user may only select the other ones.
		 *
		 * The Payload created for sending SO data to the back-end for either a ne wor an existing SO
		 *
		 * @param {object} oContext the context from which the method is triggered
		 * @param {boolean} bUseGsdo if GSDO creation is used or not
		 * @param {string} sStatus the SO status: draft or existing
		 * @return {object} oPayload the SO payload constructed
		 */
		_createPaylodSODraftAndUpdate: function (oContext, bUseGsdo, sStatus) {
			let oModelSO = oContext.getView().getModel("oModelSO").getData(),
				oPayload = {},
				sSystemIbComp = oModelSO.selectedRefObj.IbComponent,
				sSolmanIbComp = oModelSO.selectedRefObj.SolmanComponent;
			if (oContext.getView().getModel("oModelCbxCombo").getData().cbxSelectedKey === Constants.getCbxCustKey().Yes) {
				sSystemIbComp = oModelSO.SystemIBComp;
				sSolmanIbComp = oModelSO.SolmanIBComp;
			}
			oPayload = {
				"SoID": oModelSO.SoID ? oModelSO.SoID : "",
				"SoGUID": oModelSO.SoGUID,
				"ProjectID": oContext._idProject,
				"Description": oModelSO.Description,
				"CustomerID": oContext.getView().getModel("projectDetails").getData().CustomerID,
				"ContractID": (oModelSO.contractsExist && oModelSO.contractItems.length > 0 && oModelSO.contractVisible) ? oModelSO.contractSelectedKey : "",
				"ContractItem": (oModelSO.contractItemsExist && oModelSO.contractItems.length > 0 && oModelSO.contractVisible) ? oModelSO.contractItemSelectedKey : "",
				"GoLiveDate": this.dates._convertDateToBEFormat(oModelSO.GoLiveDate, "start"),
				"RecDelDate": this.dates._convertDateToBEFormat(oModelSO.RecDelDate, "start"),
				"ContactID": oModelSO.ContactID,
				"SurveyRecId": oModelSO.SurveyRecId,
				"FeedbackEnabled": oModelSO.FeedbackEnabled,
				"SystemIBComp": sSystemIbComp,
				"SolmanIBComp": sSolmanIbComp,
				"MainProduct": oModelSO.MainProduct,
				"UseGsdoCreation": bUseGsdo,
				"Questionnaire": sStatus === "Draft" ? "" : this.createSOQuestionnairePayloadForUpdate(oContext),
				"CbxEnabled": oContext.getView().getModel("oModelCbxCombo").getData().cbxSelectedKey,
				"BillingOption": oModelSO.BillingOption,
				"ServiceOrderGroup": oModelSO.ServiceOrderGroup,
				"DraftMode": sStatus === "Draft",
				"StatusCode": oContext._oData.isReleasePress ? Constants.getServiceOrderStatusCode().release : ""
			};

			return oPayload;
		},

		_createPayloadSOCreateDeep: function (oContext) {
			let oModelSO = oContext.getView().getModel("oModelSO").getData(),
				oPayload = {},
				sSystemIbComp = oModelSO.selectedRefObj.IbComponent,
				sSolmanIbComp = oModelSO.selectedRefObj.SolmanComponent;
			if (oContext.getView().getModel("oModelCbxCombo").getData().cbxSelectedKey === Constants.getCbxCustKey().Yes) {
				sSystemIbComp = oModelSO.SystemIBComp;
				sSolmanIbComp = oModelSO.SolmanIBComp;
			}
			oPayload = {
				"SoID": oModelSO.SoID ? oModelSO.SoID : "",
				"SoGUID": oModelSO.SoGUID,
				"ProjectID": oContext._idProject,
				"Description": oModelSO.Description,
				"CustomerID": oContext.getView().getModel("projectDetails").getData().CustomerID,
				"ContractID": (oModelSO.contractsExist && oModelSO.contractItems.length > 0 && oModelSO.contractVisible) ? oModelSO.contractSelectedKey : "",
				"ContractItem": (oModelSO.contractItemsExist && oModelSO.contractItems.length > 0 && oModelSO.contractVisible) ? oModelSO.contractItemSelectedKey : "",
				"GoLiveDate": this.dates._convertDateToBEFormat(oModelSO.GoLiveDate, "start"),
				"RecDelDate": this.dates._convertDateToBEFormat(oModelSO.RecDelDate, "start"),
				"ContactID": oModelSO.ContactID,
				"SurveyRecId": oModelSO.SurveyRecId,
				"FeedbackEnabled": oModelSO.FeedbackEnabled,
				"SystemIBComp": sSystemIbComp,
				"SolmanIBComp": sSolmanIbComp,
				"MainProduct": oModelSO.MainProduct,
				"UseGsdoCreation": true,
				"Questionnaire": this.createSOQuestionnairePayloadForUpdate(oContext),
				"CbxEnabled": oContext.getView().getModel("oModelCbxCombo").getData().cbxSelectedKey,
				"BillingOption": oModelSO.BillingOption,
				"ServiceOrderGroup": oModelSO.ServiceOrderGroup,
				"toServiceOrderItems": this._createPayloadSOItems(oContext),
				"toCloudRefObjects": this._createPayloadCloudRefObjects(oContext)
			};

			return oPayload;
		},

		_createPayloadSOItems: function (oContext) {
			let aItem = [];
			for (const element of oContext.getView().getModel("localModel").getData().SOItems) {
				let oItem = element;
				aItem.push({
					Handle: oItem.Handle,
					ProductID: oItem.ProductID,
					ParentHandle: oItem.ParentHandle,
					CallOfDays: oItem.CallOfDays.toString(),
					QualificationId: oItem.QualificationId,
					StartDate: oItem.StartDate,
					EndDate: oItem.EndDate
				});
			}
			return aItem;
		},

		_createPayloadCloudRefObjects: function (oContext) {

			let aRefObjects = [];
			let aData = oContext.getView().getModel("cloudRefObj").getData();
			for (const element of aData) {
				aRefObjects.push({
					"GuidObject": element.GuidObject,
					"IbComponent": element.IbComponent,
					"ParentComponent": element.ParentComponent,
					"ProductID": element.ProductID,
					"MainObject": element.MainObject
				});
			}
			return aRefObjects;
		},

		addSOCreateMessageInsidePopover: function (oContext) {
			let sSOID = oContext.getView().getModel("oModelSO").getData().SoID,
				sId = "SOCreate",
				sType = "Success",
				sTitle = oContext.getResourceBundle().getText("SO.Success.Create.Title"),
				sDescription = oContext.getResourceBundle().getText("SO.Success.Create.Description", [sSOID]),
				sDetails = null;
			oContext.messageHandler.addNewMessageseInsidePopover(sId, sType, sTitle, sDetails, sDescription, oContext);
		},

		handleSOCreation: function (oContext) {
			let oPayload = this._createPayloadSOCreateDeep(oContext, true);

			new Promise((resolve, reject) => {
				this._createSO(oContext, oPayload, resolve, reject);
			}).then((oData, oResponse) => {
				this._fnSuccessCreateSO(oContext, oData, oResponse);

				//after succesfully creating a SO, navigate to the SO Edit View
				oContext.getOwnerComponent().getModel("appData").getData().noReporting = true; //this navigation should not change the statistic
				oContext.getRouter().navTo("ServiceOrderMaintain", {
					serviceOrderID: oData.SoID
				});
			});
		},

		_createSO: function (oContext, oPayload, resolve, reject) {
			let entities = {};
			oContext.getView().getModel("localModel").getData().busyServiceOrderPage = true;
			oContext.getView().getModel("localModel").refresh();

			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ServiceOrderSet()";
			entities.data = oPayload;
			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.aUrlParameters = [
				["CurrentStep=" + (oContext.getView().getModel("localModel").getData().currentStep ? oContext.getView().getModel("localModel").getData()
					.currentStep.toString() : "").toString()]
			];
			entities.errorMessage = oContext.getResourceBundle().getText("SO.CreateSOError");
			entities.callbackSuccess = (oData, oResponse) => {
				oResponse.oContext.getOwnerComponent().trackEvent("Create_ServiceOrder_InHEP");
				oResponse.oContext.getOwnerComponent().trackEvent("Create_ServiceOrder");
				resolve(oData, oResponse);
			};
			entities.callbackError = (oError) => {
				if (oError.statusCode === 504) {
					// this error is just a communication timeout which occurs if BE needs more than 30s
					// for creating the SO and sending the response. So it could be that actually the SO was
					// created in the meanwhile.
					// We can give it a try and read the last SO from BE that the user has created today
					// maybe its the one.....
					let _fnCloseMessageBox = null;
					let _pMessageBoxClosed = new Promise(res => {
						_fnCloseMessageBox = res;
					});
					/* eslint-disable sap-timeout-usage */
					setTimeout(() => {
						this._getOrderLastCreated(oError, oContext, _pMessageBoxClosed);
					}, 20 * 1000);
					/* eslint-enable sap-timeout-usage */
					MessageBox.warning("Service Order creation takes longer than usual. \n" +
						"A timeout has occured while waiting for CRM backend to confirm order creation success! \n\n" +
						"This could be due to high load on CRM backend side, but also because of errors in CRM backend.\n\n" +
						"We will wait some seconds and then check if a service order has been created by your user.\n" +
						"Please wait....", {
						id: 'idSOConnectionTimeoutWarningMessageBox',
						onClose: _fnCloseMessageBox
					});
				} else {
					this._fnRaiseErrorCreatingSO(oContext);
					oContext.getView().getModel("localModel").getData().busyServiceOrderPage = true;
					oContext.getView().getModel("localModel").refresh();
				}
			};
			oContext.createBaseRequest(entities);
		},

		_getOrderLastCreated: function (oError, oContext, pTimeoutWarningMessageBoxClosed) {
			let sUserID = oContext.getOwnerComponent().getModel("appData").getData().oCrmUserData.UserId;
			let dToday = new Date();
			let sTodayFormatted =
				dToday.getFullYear() + "-" + String(dToday.getMonth() + 1).padStart(2, "0") + "-" +
				String(dToday.getDate()).padStart(2, "0") + "T00:00:00";
			let oParams = {
				servicePath: Constants.getServicePath(),
				entitySet: Constants.getEntities().ServiceItem,
				filter: " UserID eq '" + sUserID + "' and  ( StatusID eq 'ZSK00001|E0001' ) " +
					" and CreatedAt gt datetime'" + sTodayFormatted + "'",
				oContext: oContext,
				currentView: oContext.getView(),
				callbackSuccess: oData => {
					pTimeoutWarningMessageBoxClosed.then(() => {
						// Try to find an order created by the current user within the last 60 seconds
						oData.results.sort((a, b) => {
							return a.CreatedAt.getTime() <= b.CreatedAt.getTime() ? 1 : -1;
						});
						if (new Date().getTime() - oData.results[0].CreatedAt.getTime() < 120 * 1000) {
							MessageBox.warning("We have found service order " + oData.results[0].ObjectID +
								" just created by you. " + "Please double check if it corresponds to the data you entered.");
							oContext.getOwnerComponent().getModel("appData").getData().noReporting = true; //this navigation should not change the statistic
							oContext.getRouter().navTo("ServiceOrderMaintain", {
								serviceOrderID: oData.results[0].ObjectID
							});
						} else {
							this._fnRaiseErrorCreatingSO(oContext);
							oContext.getView().getModel("localModel").getData().busyServiceOrderPage = false;
							oContext.getView().getModel("localModel").refresh();

						}
					});
				},
				callbackError: oErr => {
					//again a timeout - so something is really wrong
					pTimeoutWarningMessageBoxClosed.then(() => {
						this._fnRaiseErrorCreatingSO(oContext);
						oContext.getView().getModel("localModel").getData().busyServiceOrderPage = false;
						oContext.getView().getModel("localModel").refresh();
					});
				}
			};
			oContext.readBaseRequest(oParams);
		},

		_fnRaiseErrorCreatingSO: function (oContext) {
			let sId = "SOCreation";
			let sType = "Error";
			let sTitle = "Error creating new service order";
			let sDescription = "Error: The service order could not be created in CRM backend. Please try again.";
			let sDetails = null;
			oContext.messageHandler.addNewMessageseInsidePopover(sId, sType, sTitle, sDetails, sDescription, oContext);

		},

		_fnSuccessCreateSO: function (oContext, oData, oResponse) {
			let oMergedData = { ...oContext.getView().getModel("oModelSO").getData(), ...oData };
			oMergedData.SurveyRecValue = oData.SurveyRecFirst + " " + oData.SurveyRecLast;
			oContext.getView().getModel("oModelSO").setData(oMergedData);

			oContext.getView().getModel("oModelSO").refresh();

			oContext._idServiceOrderGuid = oData.SoGUID;
			oContext._idServiceOrder = oData.SoID;
		},

		createSOQuestionnairePayloadForUpdate: function (oContext) {
			if (!oContext.getView().getModel("questionnaire")) {
				return;
			}
			let oModel = oContext.getView().getModel("questionnaire"),
				oModelQuestionnaire = oModel.getData().results,
				oPayload = {},
				oQuestionnairePayload = [];
			oModelQuestionnaire.forEach(function (oRow, iRow, aArray) {
				oRow.forEach(function (oField, iField, aArrayFields) {
					oPayload = {
						"FieldName": oField.FieldName,
						"FieldContent": oField.FieldContent
					};
					if (oField.oMetadata && Object.entries(oField.oMetadata).length !== 0) {
						if (oField.FieldType === "R") {
							$.each(oField.oMetadata, function (iIndex, oItem) {
								if (oItem.value === true) {
									oPayload.FieldContent = oItem.key;
								}
							});
						}
					}
					oQuestionnairePayload.push(oPayload);
				});
			});
			return JSON.stringify(oQuestionnairePayload);
		},

		updateSO: function (oContext) {
			let entities = {};
			oContext.getView().getModel("localModel").getData().busyServiceOrderPage = true;
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ServiceOrderSet(guid'" + oContext.getView().getModel("oModelSO").getData().SoGUID + "')";
			entities.data = this._createPaylodSODraftAndUpdate(oContext, false, "Update");
			if (oContext.getView().getViewName().indexOf("ProjectDetails") > 0) {
				entities.busyIndicator = "busyProjectPlanning";
			} else {
				entities.busyIndicator = "busyServiceOrderPage";
			}
			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.errorMessage = oContext.getView().getModel("localModel").getData().isReleasePress ? oContext.getResourceBundle().getText(
				"SO.ReleaseSOError") : oContext.getResourceBundle().getText("SO.UpdateSOError");
			entities.updateMethod = "Put";
			entities.aUrlParameters = [
				["CurrentStep=" + (oContext.getView().getModel("localModel").getData().currentStep ? oContext.getView().getModel("localModel").getData()
					.currentStep.toString() : "").toString()]
			];
			this.handleClearAllMessages(oContext);
			entities.callbackSuccess = (data, response) => {
				response.oContext.getOwnerComponent().trackEvent("Edit_ServiceOrder");
				this._handleSuccessUpdateSO(oContext, response, data);
			};
			let aItems = oContext.getView().getModel("localModel").getData().SOItems;
			for (const element of aItems) {
				if (parseInt(element.Handle, 10) > 0) {
					this.createItemBE(element, entities.data.SoGUID, oContext);
				}
			}
			oContext.updateBaseRequestBatch(entities);
			oContext.submitBaseRequestBatch();
		},

		_isStatusReleased: function (sStatusCode) {
			let bReleased = false;
			if (sStatusCode === Constants.getServiceOrderStatusCode().release || sStatusCode === Constants
				.getServiceOrderStatusCode().planning) {
				bReleased = true;
			}
			return bReleased;
		},

		_handleSuccessUpdateSO: function (oContext, response, data) {
			oContext.getView().getModel("localModel").getData().isSavePress = false;
			oContext.getView().getModel("localModel").getData().isReleasePress = false;
			oContext.getView().getModel("localModel").refresh();

			if (oContext.getView().getModel("oModelSO").getData().soAdditionalComponents.length &&
				oContext._oData.bAdditionalComponents) {
				this._addAdditionalComponents(oData, oContext);
			}
			if (this._isStatusReleased(response.data.StatusCode)) {

				let oBusSO = oContext.getOwnerComponent().getEventBus(),
					SoSendToDelivery = {
						SOId: response.data.SoID,
						Status: "Sent to Delivery"
					};
				let sReason = oContext.getView().getModel("projectDetails").getData().ReasonCode;
				let aSpecialReasons = Constants.getSpecialReasonCase();
				if (!aSpecialReasons.includes(sReason)) {
					oBusSO.publish("SOSendDelivery", "soSendToDelivery", SoSendToDelivery);
					oContext.navToProjectDetails();
				} else {
					oBusSO.publish("SOSendDeliveryENG", "soSendToDeliveryENG", SoSendToDelivery);
					oContext.navToEngagement();
				}

			} else {
				let oDataModel = new ODataModel({
					serviceUrl: Constants.getServicePath(),
					serviceUrlParams: {
						CurrentStep: oContext.getModel("localModel").getData().currentStep
					},
					useBatch: false,
					disableHeadRequestForToken: true,
					defaultCountMode: "None",
					headers: Constants.getAPIHeaders()
				});
				oDataModel.read(`/ServiceOrderSet(guid'${oContext.getView().getModel("oModelSO").getData().SoGUID}')`, {
					success: (oData, oResponse) => {
						new Promise((resolve, reject) => {
							this.readSOItems(oContext.getView().getModel("oModelSO").getData().SoGUID, oContext, resolve, reject);
						}).then(() => {
							oContext._refObjHandlingAfterCBXChangesFromBE(oData);
							let oMergedData = { ...oContext.getView().getModel("oModelSO").getData(), ...oData };
							oContext.getView().getModel("oModelSO").setData(oMergedData);
							oContext.getView().getModel("oModelSO").refresh();
							let sSOID = oContext.getView().getModel("oModelSO").getData().SoID;
							let sId = "SOupdate";
							let sType = "Success";
							let sTitle = oContext.getResourceBundle().getText("SO.Success.Update.Title");
							let sDescription = oContext.getResourceBundle().getText("SO.Success.Update.Description", [sSOID]);
							let sDetails = null;
							oContext.messageHandler.addNewMessageseInsidePopover(sId, sType, sTitle, sDetails, sDescription, oContext);
						});
					}
				});
			}
		},

		checkSeverity: function (message) {
			let typeMainMsg;
			if (message.severity === "info") {
				typeMainMsg = "Information";
			} else if (message.severity === "warning") {
				typeMainMsg = "Warning";
			} else {
				typeMainMsg = "Error";
			}
			return typeMainMsg;
		},

		_fnSuccessMessages: function (messages, oContext) {
			let aListMsg = JSON.parse(messages);
			let typeMainMsg = this.checkSeverity(aListMsg);
			let msgMainMsg = aListMsg.message;
			let idMainMsg = aListMsg.code + msgMainMsg;
			let aDetailsMsg = aListMsg.details;

			function addMessageToPopover(code, type, message, context) {
				if (message !== "") {
					context.messageHandler.addNewMessageseInsidePopover(code + message, type, message, message, message, context);
				}
			}

			aDetailsMsg.forEach(msg => {
				let msgType = this.checkSeverity(msg);
				addMessageToPopover(msg.code, msgType, msg.message, oContext);
			});

			let buttonMsg = oContext.getView().byId("messagePopoverButton");
			addMessageToPopover(idMainMsg, typeMainMsg, msgMainMsg, oContext);

			oContext.oMessagePopover.close();
			oContext.oMessagePopover.openBy(buttonMsg);
		},

		_addAdditionalComponents: function (data, oContext) {
			let oComponent = {
				HeaderGuid: data.SoGUID,
				HeaderId: data.SoID
			};
			oContext._countAdditionalComponents = 0;
			$.each(oContext._oData.aAdditionalComponentsSelected, (iIndex, oItem) => {
				oComponent.ProductId = oItem.getKey();
				oContext._countAdditionalComponents++;
				this._addComponent(oComponent, data, oContext);
			});
		},

		_addComponent: function (oComponent, oSOData, oContext) {
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ServiceOrderItemSet()";
			entities.data = oComponent;
			entities.busyIndicator = "busyProjectPlanning";
			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.errorMessage = oContext.getResourceBundle().getText("SO.AddComponentSOError");
			entities.callbackSuccess = (data) => {
				if (oContext._countAdditionalComponents === oContext._oData.aAdditionalComponentsSelected.length) {
					let sSOCreated = oContext.getResourceBundle().getText("SO.Success.Create", oSOData.SoID);
					MessageToast.show(sSOCreated, {
						duration: 4000,
						width: "20em"
					});
				}
			};
			oContext.createBaseRequestSync(entities);
		},

		pReadAllServiceProductsFromCRM: function (oContext) {
			return new Promise((resolve, reject) => {
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "DropDownListSet";
				entities.filter = "Type eq '" + "Product" + "'";
				entities.currentView = oContext.getView();
				entities.oContext = oContext;
				entities.errorMessage = oContext.getResourceBundle().getText("SO.ReadAllServiceProductsFromCRMError");
				entities.callbackSuccess = (data) => {
					oContext.getView().getModel("oModelSO").getData().products = data.results;
					oContext.getView().getModel("oModelSO").refresh();
					resolve();
				};
				oContext.readBaseRequest(entities);
			});
		},

		readSOContractItems: function (sContractID, oContext) {
			let entities = {},
				sDatePropertyId,
				sDate,
				iCustomerID = oContext.getView().byId("CustomerID") === undefined ?
					oContext.getView().getModel("projectDetails").getData().CustomerID :
					oContext.getView().byId("CustomerID").getText();

			oContext.getView().getModel("oModelSO").getData().busyContractItem = true;
			oContext.getView().getModel("oModelSO").refresh();

			if (oContext.getView().getModel("oModelSO").getData().goLiveRequired) {
				sDatePropertyId = "soGoLliveDate";
			}
			if (oContext.getView().getModel("oModelSO").getData().reqDelRequired) {
				sDatePropertyId = "soRecDelDate";
			}

			sDate = new Date(oContext.getView().byId(sDatePropertyId).getDateValue().setHours(23, 59, 59));
			sDate = "datetime'" + this.dates._convertDateToBEZuluFormat(sDate) + "'";

			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ContractSet";
			entities.filter = "(CustomerID eq '" + iCustomerID + "'";
			entities.filter += " and ";
			entities.filter += "ContractID eq '" + sContractID + "' ";
			entities.filter += " and ";
			entities.filter += "RecDelDate eq " + sDate + "";
			entities.filter += " and ";
			entities.filter += "ProductID eq '" + oContext.getView().getModel("oModelSO").getData().MainProduct + "')";

			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.model = "oModelSO";
			entities.busyIndicator = "busyContractItem";
			entities.errorMessage = oContext.getResourceBundle().getText("SO.ReadSOContractItemsError");
			entities.callbackSuccess = (data) => {
				this._handleSuccessReadSOContractItems(data, oContext);
			};
			oContext.readBaseRequest(entities);
		},

		_handleSuccessReadSOContractItems: function (data, oContext) {
			let iLengthOriginal = data.results.length;
			data.results = data.results.filter(oItem => parseFloat(oItem.ItemAvailableDays) !== 0);
			oContext.getView().getModel("oModelSO").getData().contractItemsAllWithoutContingent = false;
			if (iLengthOriginal !== 0 && data.results.length === 0) {
				oContext.getView().getModel("oModelSO").getData().contractItemsAllWithoutContingent = true;
			}
			oContext._workAtRiskVisible = false;
			oContext.getView().getModel("oModelSO").getData().contractSelected = (data.results.length !== 0);
			oContext.getView().getModel("oModelSO").getData().contractItems = data.results;
			oContext.getView().getModel("oModelSO").getData().contractItemsExist = (data.results.length !== 0);
			oContext.getView().getModel("oModelSO").getData().busyContractItem = false;
			oContext.getView().getModel("oModelSO").getData().busyContract = false;
			oContext.getView().getModel("oModelSO").refresh();
			if (data.results.length !== 0 || (oContext._idServiceOrder && oContext.getModel("oModelSO").getData().ContractItem)) {
				oContext.getView().getModel("oModelSO").getData().newSOValid.contractItems = "None";
				oContext.getView().byId("noItemContractLabel").setVisible(false);
				if (data.results.length === 1 && !oContext.getView().getModel("localModel").getData().loadingDataForEditMode) {
					oContext.getView().byId("soContractItem").fireChange();
				}
			} else {
				this._setNoContractItemAvailable(oContext);
			}
			oContext.getView().getModel("oModelSO").refresh();

			if (!oContext.getView().getModel("oModelSO").getData().contractRemovedAfterDateChange &&
				oContext._idServiceOrder && oContext.getView().getModel("localModel").getData().loadingDataForEditMode &&
				(oContext.getModel("oModelSO").getData().ContractItem !== "")) {

				this.setContractItemFromBE(oContext);
			}
			oContext.getView().getModel("oModelSO").getData().contractRemovedAfterDateChange = false;
			oContext.getView().getModel("oModelSO").refresh();
			oContext.getView().getModel("localModel").getData().loadingDataForEditMode = false;
			oContext.getView().getModel("localModel").refresh();
		},

		_setNoContractItemAvailable: function (oContext) {
			oContext.getView().byId("noItemContractLabel").setVisible(true);
		},

		_setNoContractAvailable: function (oContext) {
			oContext.getView().byId("noContractLabel").setVisible(true);

		},

		createItemBE: function (oComponent, SoGUID, oContext) {
			let entities = {};
			oContext.getModel("localModel").refresh();
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ServiceOrderItemSet()";
			entities.data = {
				CallOfDays: oComponent.CallOfDays,
				EndDate: oComponent.EndDate,
				Handle: oComponent.Handle,
				HeaderGuid: oComponent.HeaderGuid,
				ParentGUID: oComponent.ParentGUID,
				ParentHandle: oComponent.ParentHandle,
				ProductID: oComponent.ProductID,
				QualificationId: oComponent.QualificationId,
				StartDate: oComponent.StartDate
			};
			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.aUrlParameters = [
				["CurrentStep=" + (oContext.getView().getModel("localModel").getData().currentStep ? oContext.getView().getModel("localModel").getData()
					.currentStep.toString() : "").toString()]
			];
			entities.errorMessage = oContext.getResourceBundle().getText("SO.CreateNewItemsError");

			oContext.createBaseRequestBatch(entities);
		},

		createItemUI: function (oComponent, SoGUID, oContext) {
			oContext.getView().getModel("localModel").getData().SOItems.push(oComponent);
		},

		deleteItemBE: function (oComponent, oSOData, oContext) {
			let entities = {};
			oContext.getView().getModel("localModel").refresh();
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ServiceOrderItemSet";
			entities.getEntity = oComponent.ItemGUID;
			entities.isGuid = true;
			entities.trigger = "deleteItem";
			entities.data = oSOData;
			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.errorMessage = oContext.getResourceBundle().getText("SO.DeleteItemsError");
			entities.aUrlParameters = [
				["CurrentStep=" + (oContext.getView().getModel("localModel").getData().currentStep ? oContext.getView().getModel("localModel").getData()
					.currentStep.toString() : "").toString()]
			];
			oContext.deleteBaseRequestBatch(entities);
		},

		deleteItemUI: function (oComponent, oSOData, oContext) {
			let aItems = oContext.getView().getModel("localModel").getData().SOItems;
			oContext.getView().getModel("localModel").getData().SOItems = [];
			for (const element of aItems) {
				if ((element.Handle !== oComponent.Handle || element.ItemGUID !== oComponent.ItemGUID) && (element.ParentHandle !==
					oComponent
						.Handle || element.ParentGUID !== oComponent.ItemGUID)) {
					oContext.getView().getModel("localModel").getData().SOItems.push(element);
				}
			}
			this.buildSOItemsTree(oContext);
			if (parseInt(oComponent.Handle, 10) === 0) {
				this.deleteItemBE(oComponent, oSOData, oContext);
			}
		},

		getParentItem: function (oContext, oItemIn) {
			for (const element of oContext.getView().getModel("localModel").getData().SOItems) {
				let oItem = element;
				if (oItem.Handle === oItemIn.ParentHandle && oItem.ItemGUID === oItemIn.ParentGUID) {
					return oItem;
				}
			}
		},

		isMainItem: function (oContext, oItem) {
			return !!(((!oItem.ParentHandle || parseInt(oItem.ParentHandle, 10) === 0) && (oItem.ParentGUID ===
				"00000000-0000-0000-0000-000000000000" || !oItem.ParentGUID || oItem.ParentGUID ===
				"")));
		},

		readSOItems: function (sSoGUID, oContext, resolveSOItems, rejectSOItems) {
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ServiceOrderSet(guid'" + sSoGUID + "')/toServiceOrderItems";
			entities.busyIndicator = "busyServiceComponentStep";
			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.errorMessage = oContext.getResourceBundle().getText("SO.ReadingItemsError");
			entities.callbackSuccess = (data) => {
				this._handleSuccessReadSOItems(data, sSoGUID, oContext);
				oContext.getView().getModel("localModel").getData().busyServiceComponentStep = false;
				oContext.getView().getModel("localModel").refresh();
				if (resolveSOItems) {
					resolveSOItems();
				}
			};
			oContext.readBaseRequest(entities);
		},

		/**
		 * to simplify the UI users are not allowed to add further sessions for a service, although
		 * it might be allowed from BE side....
		 * Also deleting the existing session (should be one) is not allowed on the UI
		 * Due to this, we need to manipulate the corresponding properties, we received from BE, before
		 * we build the SO Items Tree.
		 *
		 * @param {object} data - returned from BE
		 * @param {string} sSoGUID - the SO GUID
		 * @param {object} oContext - the context from which the method is called
		 */
		_handleSuccessReadSOItems: function (data, sSoGUID, oContext) {
			data.results.forEach(item1 => {
				if (this.isMainItem(oContext, item1)) {
					item1.CreateSubAllowed = false;
					data.results.forEach(item2 => {
						if (item2.ParentProductID === item1.ProductID) {
							item2.DeleteAllowed = false;
						}
					});
				}
			});
			oContext.getView().getModel("localModel").getData().SOItems = data.results;
			if (data.results.length) {
				this.buildSOItemsTree(oContext, true);
			}
		},

		/**
		 * starting point to build the SO items tree for the UI.
		 * The main item (highest level) is found and used as a starting point for the recursive
		 * method "_addItemUI", which then adds the lower level tree....
		 *
		 * @param {object} oContext - the context from which the method is called
		 * @param {boolean} bInitialCall - initial call
		 */
		buildSOItemsTree: function (oContext, bInitCall) {
			oContext.getView().getModel("treeSO").setData({
				"itemsSO": []
			});
			this.CallOffDays = 0;
			oContext.getView().getModel("localModel").getData().SOItems.forEach((item, index) => {
				if (this.isMainItem(oContext, item)) {
					oContext.getView().getModel("treeSO").getData().itemsSO.push(this._addItemUI(item, oContext));
				}
			});
			if (!bInitCall) {
				oContext.getView().getModel("localModel").getData().SOItems.find(elem => !this.getParentItem(oContext, elem)).CallOfDays =
					this.CallOffDays;
			}
			oContext.getView().getModel("treeSO").refresh();
			if (!oContext._displayMode) {
				oContext.checkRefObjValueIsValid();
			}
			oContext.getView().getModel("localModel").getData().busyServiceOrderPage = false;
			oContext.getView().getModel("localModel").getData().busySO = false;
			oContext.getView().getModel("localModel").refresh();
		},

		_addItemUI: function (oItem, oContext) {
			let oNewItem = oItem;
			if (!this.isMainItem(oContext, oItem)) {
				this.CallOffDays = this.CallOffDays + parseFloat(oItem.CallOfDays);
			}
			if (oNewItem.ItemNo > 0) {
				oNewItem.ItemNo = oNewItem.ItemNo.replace(/^0+/, "");
			} else {
				oNewItem.ItemNo = "NEW";
			}
			oNewItem.itemsSO = [];
			oContext.getView().getModel("localModel").getData().SOItems.forEach((item, index) => {
				if ((item.ParentGUID && item.ParentGUID === oItem.ItemGUID) || (item.ParentHandle && parseInt(item.ParentHandle, 10) > 0 &&
					item
						.ParentHandle ===
					oItem.Handle)) {
					oNewItem.itemsSO.push(this._addItemUI(item, oContext));
				}
			});
			return oNewItem;
		},

		/*	addItem: function (oItem, data, oContext) {
			let oNewItem = {
				"ItemGUID": oItem.ItemGUID,
				"ItemNo": oItem.ItemNo.replace(/^0+/, ""),
				"ParentNo": oItem.ParentNo,
				"ProductID": oItem.ProductID,
				"ComponentText": oItem.ProductText,
				"CallOfDays": oItem.CallOfDays,
				"ConsultantName": oItem.ConsultantText,
				"Status": oItem.StatusText,
				"StatusKey": oItem.Status,
				"Qualification": oItem.QualificationId,
				"QualificationName": oItem.QualificationName,
				"editVisible": oItem.EditAllowed,
				"addButtonVisible": oItem.CreateSubAllowed,
				"StartDate": oItem.StartDate,
				"EndDate": oItem.EndDate,
				"minDate": null,
				"maxDate": null,
				"Description": oItem.Description,
				"ServiceType": oItem.ServiceType,
				"deleteVisible": oItem.DeleteAllowed,
				"SystemRequired": oItem.SystemRequired,
				"SolmanRequired": oItem.SolmanRequired,
				"itemsSO": this.addChildren(oItem.ItemNo, data, oContext)
			};
			return oNewItem;
		},

		addChildren: function (sParent, data, oContext) {
			let aChildren = [];
			data.results.forEach((item, index) => {
				if (sParent === item.ParentNo) {
					aChildren.push(this.addItem(item, data, oContext));
				}
			});
			aChildren.forEach((child) => {
				child.ItemNo = parseInt(child.ItemNo, 10);
			});
			aChildren.sort((initial, next) => {
				let sStatement;
				if (initial.ItemNo > next.ItemNo) {
					sStatement = 1;
				} else {
					sStatement = ((next.ItemNo > initial.ItemNo) ? -1 : 0);
				}
				return sStatement;
			});
			return aChildren;
		},
*/

		/**
		 * Read Service Order Items + build item tree
		 * @param {object} oContext the context from which the method is triggered
		 * @param {object} fResolve - resolve
		 * @param {string} sSOProductID the SO Product Id
		 *
		 * @returns {Promise} resolved - to inform higher level functions when data is available
		 */
		_pReadServiceProductAllComponents: function (sServiceProductId, oContext) {
			return new Promise((res, rej) => {

				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "ProductSet('" + sServiceProductId + "')";
				entities.expand = "toProductComponents";

				entities.currentView = oContext.getView();
				entities.oContext = oContext;
				entities.model = "oModelSO";
				entities.errorMessage = oContext.getResourceBundle().getText("SO.ReadingComponentsError", [sServiceProductId]);
				entities.callbackSuccess = (data) => {
					this._handleSuccessReadServiceProductAllComponents(data, sServiceProductId, oContext);

					res();
				};
				oContext.readBaseRequest(entities);
			});
		},

		_handleSuccessReadServiceProductAllComponents: function (data, sServiceProductId, oContext) {
			let oModelSO = oContext.getView().getModel("oModelSO").getData();
			oModelSO.aServiceProductAllComponents = data.toProductComponents.results;
			oModelSO.goLiveRequired = data.GoLiveDateMandatory;
			oModelSO.reqDelRequired = data.ReqDelDateMandatory;
			if (oModelSO.CbxEnabled !== Constants.getCbxCustKey().Yes) {
				oModelSO.refObjComboEnabled = true;
			}
			oModelSO.newSOValid = {
				contractID: "None",
				contractItems: "None",
				reqDelDate: "None",
				goLiveDate: "None",
				refObjRequiredForRelease: "None"
			};
			oModelSO.refObjComboValueStateText = oContext.getResourceBundle().getText("SO.Error.Subtitle.RefObj");
			oModelSO.SelectedComponentIDs = [];
			oModelSO.MandatoryComponentsIDs = [];
			oModelSO.soMandatoryComponents = [];
			oModelSO.soAdditionalComponents = [];

			this.iterateServiceProductComponents(oModelSO);

			oModelSO.soMandatoryComponentsExist = !!oModelSO.soMandatoryComponents.length;
			oModelSO.additionalComponentsExist = !!oModelSO.soAdditionalComponents.length;
			oContext.getView().getModel("oModelSO").refresh();

			if (!oContext._displayMode) {
				if (oModelSO.reqDelRequired && oContext.getView().byId("soRecDelDate").getValue() !== "") {
					this._readSOContracts(sServiceProductId, oContext);
				}
				if (oModelSO.goLiveRequired && oContext.getView().byId("soGoLliveDate").getValue() !== "") {
					this._readSOContracts(sServiceProductId, oContext);
				}
			}
			if (oContext._idServiceOrder) {
				this.readSOItems(oContext._idServiceOrderGuid, oContext);
				if (!oContext._displayMode) {
					oContext.readQuestionnaire();
				}
			}
		},

		iterateServiceProductComponents: function (oModelSO) {
			$.each(oModelSO.aServiceProductAllComponents, function (oComponent) {
				if (oComponent.Mandatory || oComponent.Selected) {
					oModelSO.MandatoryComponentsIDs.push(oComponent.ComponentID);
					oModelSO.soMandatoryComponents.push(oComponent);
					oModelSO.SelectedComponentIDs.push(oComponent.ComponentID);
				} else {
					oModelSO.soAdditionalComponents.push(oComponent);
					if (oComponent.Selected) {
						oModelSO.SelectedComponentIDs.push(oComponent.ComponentID);
					}
				}
			});
		}
		,

		checkIfOneItemIsSelected: function (oEvent, oContext) {
			let soMandatoryDD = oEvent.getSource();
			if (oEvent.getSource().getSelectedItems().length === 0) {
				soMandatoryDD.setValueState("Error");
				soMandatoryDD.setValueStateText(oContext.getResourceBundle().getText("ServiceOrder.MandatoryComponentsSelection"));
			} else {
				soMandatoryDD.setValueState("None");
			}
		},

		/* =================================== Status Change ==============================================*/

		changeServiceOrderStatus: function (oServiceOrder, oContext, sStatus) {
			this.handleClearAllMessages(oContext);

			if (this._isStatusReleased(sStatus)) {
				this.releaseSO(oContext, oServiceOrder.guid.replaceAll("-", "").toUpperCase()).then((dataSO) => {
					oContext.messageHandler.addNewMessageseInsidePopover("SOStatusChange", "Success",
						oContext.getResourceBundle().getText("SO.Released.Success.Title"),
						oContext.getResourceBundle().getText("SO.Released.Success.DescriptionLong", [oServiceOrder.idOfSO ? oServiceOrder.idOfSO :
							oServiceOrder.SOID
						]),
						oContext.getResourceBundle().getText("SO.Released.Success.DescriptionShort", [oServiceOrder.idOfSO ? oServiceOrder.idOfSO :
							oServiceOrder.SOID
						]), oContext);
				});
			} else {
				this.updateServiceOrderStatus(oServiceOrder, oContext, sStatus);
			}
		},

		updateServiceOrderStatus: function (oServiceOrder, oContext, sStatus) {
			let modelLocal = oContext.getView().getModel("localModel"),
				bIsProjectDetailsPage = oContext.getView().getViewName().split("ProjectDetails").length > 1,
				bIsEngsPage = oContext.getView().getViewName().split("Engagement").length > 1,
				entities = {};

			if (bIsProjectDetailsPage || bIsEngsPage) {
				modelLocal.getData().busyProjectPlanning = true;
			} else {
				modelLocal.getData().busyServiceOrderPage = true;
			}
			modelLocal.refresh();

			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ServiceOrderSet";
			entities.getEntity = oServiceOrder.guid;
			entities.isGuid = true;
			let sSOID = oServiceOrder.idOfSO ? oServiceOrder.idOfSO : oServiceOrder.SOID;
			entities.data = {
				SoID: sSOID,
				StatusCode: sStatus
			};
			entities.updateMethod = "Put";
			entities.busyIndicator = bIsProjectDetailsPage || bIsEngsPage ? "busyProjectPlanning" : "busyServiceOrderPage";
			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.errorMessage = oContext.getResourceBundle().getText("SO.UpdateStatusError", [sSOID]);
			entities.callbackSuccess = () => {
				oContext.getOwnerComponent().trackEvent("Edit_ServiceOrder");
				this._handleSuccessChangeStatusSO(oServiceOrder, oContext, sStatus);
			};
			oContext.updateBaseRequest(entities);
		}
		,

		_handleSuccessChangeStatusSO: function (oServiceOrder, oContext, sStatus) {
			let bIsProjectDetailsPage = oContext.getView().getViewName().split("ProjectDetails").length > 1,
				bIsEngsPage = oContext.getView().getViewName().split("Engagement").length > 1,
				sStatusText = "",
				sSOID = oServiceOrder.idOfSO ? oServiceOrder.idOfSO : oServiceOrder.SOID;
			if (bIsProjectDetailsPage) {
				oContext.getView().getModel("localModel").getData().busyProjectPlanning = false;
			} else {
				oContext.getView().getModel("localModel").getData().busyServiceOrderPage = false;
			}
			oContext.getView().getModel("localModel").refresh();

			if (this._isStatusReleased(sStatus)) {
				sStatusText = "Released";
				if (bIsProjectDetailsPage || bIsEngsPage) {
					oContext.messageHandler.addNewMessageseInsidePopover("SOStatusChange", "Success",
						oContext.getResourceBundle().getText("SO." + sStatusText + ".Success.Title"),
						oContext.getResourceBundle().getText("SO." + sStatusText + ".Success.DescriptionLong", [sSOID]),
						oContext.getResourceBundle().getText("SO." + sStatusText + ".Success.DescriptionShort", [sSOID]), oContext);
				} else {
					let oBusSO = oContext.getOwnerComponent().getEventBus(),
						SoSendToDelivery = {
							SOId: sSOID,
							Status: "Sent to Delivery"
						};
					let sReason = oContext.getView().getModel("projectDetails").getData().ReasonCode;
					let aSpecialReasons = Constants.getSpecialReasonCase();
					if (!aSpecialReasons.includes(sReason)) {
						oBusSO.publish("SOSendDelivery", "soSendToDelivery", SoSendToDelivery);
						oContext.navToProjectDetails();
					} else {
						oBusSO.publish("SOSendDeliveryENG", "soSendToDeliveryENG", SoSendToDelivery);
						oContext.navToEngagement();
					}
				}
			} else {
				sStatusText = "Cancelled";
				oContext.messageHandler.addNewMessageseInsidePopover("SOStatusChange", "Success",
					oContext.getResourceBundle().getText("SO." + sStatusText + ".Success.Title"),
					oContext.getResourceBundle().getText("SO." + sStatusText + ".Success.DescriptionLong", [sSOID]),
					oContext.getResourceBundle().getText("SO." + sStatusText + ".Success.DescriptionShort", [sSOID]), oContext);
			}
		},

		releaseSO: function (oContext, sSoGuid) {
			return new Promise((resolve, reject) => {
				if (sSoGuid) {
					let oParams = {};
					oParams.oContext = oContext;
					oParams.servicePath = Constants.getServicePath();
					oParams.function = "SORelease";
					oParams.method = "GET";
					oParams.currentView = oContext.getView();
					oParams.errorMessage = oContext.getResourceBundle().getText("SO.ReleaseSOError");
					oParams.busyIndicator = "busyProjectPlanning";
					oParams.urlParameters = {
						"SoGUID": sSoGuid
					};
					oParams.callbackSuccess = (data) => {
						if (this._isStatusReleased(data.StatusCode)) {
							oContext.getOwnerComponent().trackEvent("Edit_ServiceOrder");
							resolve(data);
						} else {
							reject(new Error(''));
						}
					};
					oContext.getView().getModel("localModel").getData().busyProjectPlanning = true;
					oContext.getView().getModel("localModel").refresh();
					oContext.callFunction(oParams);
				} else {
					reject(new Error(''));
				}
			});
		},

		handleClearAllMessages: function (oContext) {
			this.messageHandler.resetMessageDataModel(oContext.getView());
			oContext.oMessagePopover.close();
		},

		_setValidContract: function (oContext) {
			let aContracts = oContext.getView().getModel("oModelSO").getData().contracts;
			if (!aContracts || aContracts.length === 0) {
				oContext.getView().getModel("oModelSO").getData().validContract = false;
				oContext.getView().getModel("oModelSO").refresh();
				if (oContext.getView().byId("btnFormElement1")) oContext.getView().byId("btnFormElement1").addStyleClass("criticalIcon");
				if (oContext.getView().byId("btnFormElement2")) oContext.getView().byId("btnFormElement2").addStyleClass("criticalIcon");
				return false;
			} else {
				oContext.getView().getModel("oModelSO").getData().validContract = true;
				oContext.getView().getModel("oModelSO").refresh();
				if (oContext.getView().byId("btnFormElement1")) oContext.getView().byId("btnFormElement1").removeStyleClass("criticalIcon");
				if (oContext.getView().byId("btnFormElement2")) oContext.getView().byId("btnFormElement2").removeStyleClass("criticalIcon");
				return true;
			}
		},
		_getHTMLcontractList: function (oData, oContext) {
			if (!oData?.value) {
				return null;
			} else {
				let sContractList = "<ul>";
				for (const element of oData.results) {
					sContractList = sContractList + "<li>" + element.ContractName + "</li>";
				}
				sContractList = sContractList + "</ul>";
				return sContractList;
			}
		}
	};
});
