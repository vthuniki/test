sap.ui.define([
	"com/sap/ui/hep/util/TableSortHelper",
	"sap/m/Column"
], function (SortHelper, Column) {
	"use strict";

	return Column.extend("com.sap.ui.hep.util.CustomColumn", {
		metadata: {
			properties: {
				"sortField": {
					type: "string",
					defaultValue: ""
				},
				"sortType": {
					type: "string",
					defaultValue: ""
				}
			}
		},

		onAfterRendering: function () {
			if (sap.m.Column.prototype.onAfterRendering) {
				sap.m.ColumnRendering.apply(this, arguments);
			}
		}
	});
});
