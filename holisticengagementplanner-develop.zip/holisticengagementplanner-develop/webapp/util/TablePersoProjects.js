sap.ui.define("com/sap/ui/hep/util/TablePersoProjects",
    [
        "com/sap/ui/hep/util/SessionTablePersoBaseService"
    ],
    function (SessionTablePersoBaseService) {
        "use strict";

        const PersoService = SessionTablePersoBaseService.extend("com.sap.ui.hep.util.TablePersoProjects", {
            constructor: function () {
                SessionTablePersoBaseService.call(this, "tablePerso-projectsTable.json", "homeProjectsTableConfig");
            },
        });

        return new PersoService();
    }, /* bExport= */ true);
