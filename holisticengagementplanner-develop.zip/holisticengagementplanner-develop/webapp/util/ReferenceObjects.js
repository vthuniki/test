sap.ui.define([
	"com/sap/ui/hep/reuse/Constants",
	"sap/ui/core/syncStyleClass",
	"com/sap/ui/hep/model/formatter",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageBox",
	"com/sap/ui/hep/util/TablePersoAddRefObj",
	"sap/m/TablePersoController",
	"sap/ui/model/json/JSONModel"
], function (Constants, syncStyleClass, formatter, Fragment, Filter, ODataModel, MessageBox, TablePersoAddRefObj, TablePersoController,
	JSONModel) {
	"use strict";
	return {
		formatter: formatter,
		_setContext: function (oContext) {
			this.oContext = oContext;
		},

		// ========================================= Read already assigned reference objects ================

 		/**
 		 *  Read reference objects assigned to project from BE.
 		 *  @param {object} oContext - The context in which the method is called
 		 *  @returns {object} promise
 		 */
 		readReferenceObjectsOfProject: function (oContext) {
 			return new Promise((resolve, reject) => {
 				let entities = {};
 				oContext._oData.busyReferenceObjects = true;
 				oContext._oModel.refresh();
				entities.servicePath = Constants.getServicePath();
 				entities.entitySet = "ProjectSet";
 				entities.getEntity = oContext._idProject;
 				entities.navigation = "toReferenceObject";
 				entities.currentView = oContext.getView();
 				entities.oContext = oContext;
 				entities.busyIndicator = "busyReferenceObjects";
 				entities.errorMessage = oContext.getResourceBundle().getText("ProjectDetails.ReadReferenceObjects", [oContext._idProject]);
 				entities.callbackSuccess = (data) => {
 					this._handleSuccessReferenceObjects(data, oContext);
 					resolve();
 				};
 				oContext.readBaseRequest(entities);
 			});
 		},

		/**
		 *  Callback function, called after successfully reading the reference objects, which are assigned to the project, from BE. 
		 *  The reference objects as stored in model "ReferenceObjects" and each is enriched with the additional attributes:
		 *  "new", "deleted", "comboValue", "InstNo" and "SolmanInstNo"
		 *  @param {object} data - the data that has read from BE
		 *  @param {object} oContext - The context in which the method is called
		 */
		_handleSuccessReferenceObjects: function (data, oContext) {
			let aRefObjects = data.results;
			aRefObjects.forEach((oElem, iIndex, aArray) => {
				oElem.new = false;
				oElem.deleted = false;
				oElem.save = false;
			});
			aRefObjects.forEach((oRefObject) => {
				if (oRefObject.SysStatus.toUpperCase() == 'ACTIVE') {
					oRefObject.comboValue = this.formatter.refObjDisplay(oRefObject);
					this._createGroupingRO(oRefObject, oContext);
					oRefObject.InstNo = this.formatter._removeZeroesFromField(oRefObject.InstNo);
					oRefObject.SolmanInstNo = this.formatter._removeZeroesFromField(oRefObject.SolmanInstNo);
				}
			});
			oContext.getView().getModel("ReferenceObjects").getData().results = aRefObjects;
			oContext.getView().getModel("ReferenceObjects").getData().numberOfItems = aRefObjects.length;
			oContext.getView().getModel("ReferenceObjects").refresh();

			oContext._oData.busyReferenceObjects = false;
			oContext._oModel.refresh();
		},

		/**
		 *  Helper function, called while enriching the reference objects from BE with additional attributes
		 *  The additinal attribute  "SolmanAssigned" is added, which is used for Grouping in the combo
		 *  @param {object} oRefEntry - object that contains data for one reference object
		 *  @param {object} oContext - The context in which the method is called
		 */
		_createGroupingRO: function (oRefEntry, oContext) {
			let oDeployModelCloud = Constants.getDeploymentModelValues()[1].name;
			if (oRefEntry.DeployModel === oDeployModelCloud) {
				oRefEntry.SolmanAssigned = oDeployModelCloud;
			} else {
				let sSolManAssignmentText = !oRefEntry.SolmanSID ?
					oContext.getResourceBundle().getText("RO.GroupCaptionWithoutSolman") : oContext.getResourceBundle().getText(
						"RO.GroupCaptionWithSolman");
				oRefEntry.SolmanAssigned = oRefEntry.DeployModel + " " + sSolManAssignmentText;
			}
		},

		// ========================================= Startup Reference Object popup ====================================

		/**
		 *  Event handler, that is called when the user presses the button to open the popup for adding reference objects 
		 *  The popup is realized in form of a fragment with a dialog control on it. 
		 *  The fragment is loaded and then stored as a property of the calling context.
		 *  In case this property already exists, the fragment is not loaded newly, but reused.
		 *  After the Fragment has been loaded, use of method "addDependent" takes care models of the context are set and lifecyle is taken care of
		 *  @param {object} oEvent - object that contains data for one reference object
		 *  @param {object} oContext - The context in which the method is called
		 */
		loadReferenceObjectsDialog: function (oEvent, oContext) {
			this._setContext(oContext);
			if (!oContext._oDialogAddNewRO) {
				try {
					Fragment.load({
						id: oContext.getView().createId("roSelectPopup"), ///oContext.getView().getId(),
						name: "com.sap.ui.hep.view.fragment.AddReferenceObject",
						controller: oContext
					}).then(oDialogRF => {
						oContext._oDialogAddNewRO = oDialogRF;
						oContext._oDialogAddNewRO.setModel(oContext.getModel("i18n"), "i18n");
						oContext.getView().addDependent(oContext._oDialogAddNewRO);
						syncStyleClass(oContext.getView().getController().getOwnerComponent().getContentDensityClass(), oContext.getView(), oContext._oDialogAddNewRO);
						this._loadFilterOptions();
						this._openAndPopulateRODialog();
					});
				} catch (oError) {
					if (oError.statusCode === 503) {
						let oView = oContext.getView();
						let params = {
							currentView: oView
						};
						oContext.handleSessionTimeout(params, oContext);
					}
				}
			} else {
				this._loadFilterOptions();
				this._openAndPopulateRODialog();
			}
		},

		_initializeAddRefObjTablePerso: function (oContext) {
			if (oContext._oTPCAddRefObj === undefined) {
				oContext._oTPCAddRefObj = new TablePersoController({
					table: Fragment.byId(oContext.getView().createId("roSelectPopup"), "tableRO"),
					persoService: TablePersoAddRefObj
				}).activate();
			}
		},

		onAddRefObjPersoButtonPressed: function (oEvent, oContext) {
			oContext._oTPCAddRefObj.openDialog();
		},

		onAddRefObjSortReset: function (oContext) {
			let oTable = Fragment.byId(oContext.getView().createId("roSelectPopup"), "tableRO");
			oTable.resetSorting();
			this.searchROonGOBtn(null, oContext);
		},

		onAddRefObjTablePersoRefresh: function (oContext) {
			TablePersoAddRefObj.resetPersData();
			oContext._oTPCAddRefObj.refresh();
		},

 		/**
 		 *  Helper function to load fixed values for all combo lists on the selection screen
 		 */
 		_loadFilterOptions: function () {
			this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().alreadyAdded = Constants.getAlreadyAddedOptions();
			this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().relPartnerFlag = Constants.getFlagValues();
			this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().deletionFlag = Constants.getFlagValues();
			this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().systemUsage = Constants.getSystemUsageValues();
			this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().deploymentModel = Constants.getDeploymentModelValues();
			this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().systemSolMan = Constants.getSystemSolManOptions();
 			this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().installations = {};
 			this.oContext._oDialogAddNewRO.getModel("oModelRO").refresh();
 		},

 		/**
 		 *  Helper function to set initial values for filter criteria, populate the installations-Combo initially (for the initially
 		 *  selected customer), execute the search initially and finally display the fragment (popup)
 		 */
 		_openAndPopulateRODialog: function () {
 			Object.assign(this.oContext._oDialogAddNewRO.getModel("oModelRO").getData(), {
 				customerID: this.oContext.getView().getModel("projectDetails").getData().CustomerID,
 				helperCustomerIDchangedOnModel: false,
				relPartnerFlagSelectedKey: Constants.referenceObjectPopupInitialComboValues().relPartnerFlagSelectedKey,
				deletionFlagSelectedKey: Constants.referenceObjectPopupInitialComboValues().deletionFlagSelectedKey,
 				sInstallationNumberInput: "",
				installationsSelectedKey: Constants.referenceObjectPopupInitialComboValues().installationsSelectedKey,
 				sID: "",
 				sNBTentantID: "",
				systemUsageSelectedKey: Constants.referenceObjectPopupInitialComboValues().systemUsageSelectedKey,
				solmanUsageSelectedKey: Constants.referenceObjectPopupInitialComboValues().solmanUsageSelectedKey,
				deploymentModelSelectedKey: Constants.referenceObjectPopupInitialComboValues().deploymentModelSelectedKey,
				systemRoleSelectedKey: Constants.referenceObjectPopupInitialComboValues().systemRoleSelectedKey,
				systemSolManSelectedValue: Constants.referenceObjectPopupInitialComboValues().systemSolManSelectedValue,
				alreadyAddedSelectedKey: Constants.referenceObjectPopupInitialComboValues().alreadyAddedSelectedKey,

				IbComponent: "",
				solutionDescription: "",
				solutionID: "",
				systemDescription: "",
				installationNumberSolMan: "",
				SolManVersion: "",
				systemIDSolMan: "",

				inputMissing: false,
				search: "",
				items: []
			});
			this.oContext._oDialogAddNewRO.getModel("oModelRO").refresh();

			this.oContext.getView().getModel("oModelRO").bindProperty("/customerID").attachChange(this.fnHandleModelPropertyChangeCustomerID,
				this);
			this._searchInstallationsOfCustomer(this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().customerID);
			this._readSystemRoles();
			this.searchROonGOBtn(null, this.oContext);
			this.oContext._oDialogAddNewRO.open();
		},

 		/**
 		 *  Read installations for a specific customer from BE
 		 *  @param {string} sCustomerId - customer id as string
 		 */
 		_searchInstallationsOfCustomer: function (sCustomerId) {
 			let entities = {};
			entities.servicePath = Constants.getServicePath();
 			entities.entitySet = "InstallationSet";
 			entities.errorMessage = this.oContext.getResourceBundle().getText("ProjectDetails.SearchIntalations");
 			entities.filter = `CustomerId eq '${sCustomerId}'`;
 			entities.currentView = this.oContext.getView();
 			entities.oContext = this.oContext;
 			entities.busyIndicator = "busyAddRefObjList";
 			entities.callbackSuccess = (oData) => {
 				this._handleSuccessSearchInstallationsOfCustomer(oData, this.oContext);
 			};
 			this.oContext.readBaseRequest(entities);
 		},

		/**
		 *  calculate a further property "InstnoDipslay" for each installation that has been read from BE
		 *  and add the found installations to the oModelRO model
		 *  @param {object} oData - data recieved via BE call
		 *  @param {object} oContext - context in which the method is called
		 */
		_handleSuccessSearchInstallationsOfCustomer: function (oData, oContext) {
			oData.results.forEach(item => {
				item.InstnoDisplay = this.formatter._removeZeroesFromField(item.Instno);
			});
			this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().installations = oData.results;
			this.oContext._oDialogAddNewRO.getModel("oModelRO").refresh();
		},

		/**
		 *  Read domain values for System Role
		 */
		_readSystemRoles: function () {
			this._readDropDownValues("CarSystemRole", "SO.ReadSystemRolesError", "/systemRoles", this._handleSuccessReadDropDown.bind(this));
		},

		/**
		 * Read domain values for Data Center
		 * @return {promise} Returns a promise with the fetched data
		 */
		_readDataCenters: function () {
			return new Promise(function (resolve, reject) {
				this._readDropDownValues("CarDataCenter", "SO.ReadDataCenterError", "/dataCenters", function (sPropertyPath, oData) {
					resolve(oData);
				});
			}.bind(this));
		},

 		_readDropDownValues: function (sFilterValue, sErrorMessageId, sPropertyPath, fCallback) {
 			let entities = {};
			entities.servicePath = Constants.getServicePath();
 			entities.entitySet = "DropDownListSet";
 			entities.filter = "Type eq '" + sFilterValue + "'";
 			entities.currentView = this.oContext.getView();
 			entities.oContext = this.oContext;
 			entities.busyIndicator = "busyAddRefObjList";
 			entities.errorMessage = this.oContext.getResourceBundle().getText(sErrorMessageId);
 			entities.callbackSuccess = (data) => {
 				fCallback(sPropertyPath, data);
 			};
 			this.oContext.readBaseRequest(entities);
 		},

		/**
		 *  Set ComboBox Content based on result
		 *  @param {String} sPropertyPath - property path of the model
		 *  @param {object} oData - data recieved via BE call
		 *  @param {object} oContext - context in which the method is called
		 */
		_handleSuccessReadDropDown: function (sPropertyPath, oData) {
			oData.results.forEach(function (elem) {
				if (!elem.Value || elem.Value === "") {
					elem.Value = elem.Key;
				}
				elem.Value = elem.Value.trim();
			});

			this.oContext._oDialogAddNewRO.getModel("oModelRO").setProperty(sPropertyPath, oData.results);

			this.oContext._oDialogAddNewRO.getModel("oModelRO").refresh();
		},

		// ===================================== Search for Reference Objects in BE =================================

		/**
		 *  prepare triggering BE search to read reference objects fitting to search criteria set, by collecting
		 *  the entered search criteria. After that calling the helper method to execute the BE-read-request
		 *  @param {object} oEvent - event data received from triggering event (i.e. button click)
		 *  @param {object} oContext - context in which the method is called
		 *  @param {object} oSort - sorting
		 */
		searchROonGOBtn: function (oEvent, oContext, oSort) {
			Fragment.byId(oContext.getView().createId("roSelectPopup"), "tableRO").removeSelections();
			this._setContext(oContext);

			let oROModelData = this.oContext._oDialogAddNewRO.getModel("oModelRO").getData(),
				sSystemSolManKeyFromElement = this.oContext.getView().getModel("oModelRO").getData().refObjRequirements,
				sSystemSolManKey = sSystemSolManKeyFromElement === "" ? oROModelData.refObjRequirements : sSystemSolManKeyFromElement,
				sSystemSolman = typeof sSystemSolManKey === "string" ? JSON.parse(sSystemSolManKeyFromElement.trim()) :
					sSystemSolManKeyFromElement,

				oSearchParams = {
					Customer: oROModelData.customerID.trim(),
					PartnerRelFlag: oROModelData.relPartnerFlagSelectedKey,
					DeletionFlag: oROModelData.deletionFlagSelectedKey,
					InstNo: this._determineInstallationNumber(),
					SID: oROModelData.sID.trim(),
					SystemRefNum: oROModelData.sNBTentantID.trim(),
					SystemUsage: oROModelData.systemUsageSelectedKey,
					SolmanUsage: oROModelData.solmanUsageSelectedKey,
					DeployModel: oROModelData.deploymentModelSelectedKey,
					CarSysRole: oROModelData.systemRoleSelectedKey,
					SystemSolman: sSystemSolman,
					alreadyAdded: oROModelData.alreadyAddedSelectedKey,
					IbComponent: oROModelData.IbComponent.trim(),
					SolutionDescr: oROModelData.solutionDescription.trim(),
					SolutionID: oROModelData.solutionID.trim(),
					SysDescription: oROModelData.systemDescription.trim(),
					SolmanInstNo: oROModelData.installationNumberSolMan.trim(),
					SolmanRelease: oROModelData.SolManVersion.trim(),
					SolmanSID: oROModelData.systemIDSolMan.trim(),
					CarDataCenter: oROModelData.dataCenterSelectedKey				
				};
			if (oSearchParams.sGivenCustomerID === "" && oSearchParams.sInstallationNumber === "") {
				oROModelData.customerIDExists = false;
				oROModelData.instNoExists = false;
				this.oContext._oDialogAddNewRO.getModel("oModelRO").refresh();
			} else {
				this._searchForReferenceObjects(oSearchParams, oSort);
			}
		},

		/**
		 *  helper method to determine current value of installation number. 
		 *  Consider both - the combobox (which is only available when customer is given) and the simple input as fallback.
		 *  @return {string} - installation number
		 */
		_determineInstallationNumber: function () {
			let oInstallationCombo = Fragment.byId(this.oContext.getView().createId("roSelectPopup"), "installationNumberCombo");
			let sInstallationComboValue = oInstallationCombo.getValue().trim();
			if (sInstallationComboValue === "" && this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().sInstallationNumberInput) {
				return this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().sInstallationNumberInput.trim();
			}
			let sInstNo = "";
			if (oInstallationCombo.getSelectedKey() === "" && sInstallationComboValue !== "") {
				let aInstallations = this.oContext.getView().getModel("oModelRO").getData().installations;
				let sInstWithZeroes = aInstallations.filter(inst => inst.Instno.includes(sInstallationComboValue));
				sInstNo = sInstWithZeroes.length > 0 ? sInstWithZeroes[0].Instno : "";
			} else {
				sInstNo = oInstallationCombo.getSelectedKey();
			}
			return sInstNo;
		},

		_determineSortingCriterias: function () {
			let oSortProperties = null,
				oTable = this.oContext.getView().byId("tableRO");
			if (oTable) {
				let aColumns = oTable.getColumns(),
					oSortingColumn = aColumns.find(oColumn => oColumn.getSortIndicator() !== "None");
				if (oSortingColumn) {
					oSortProperties = {};
					oSortProperties.field = oSortingColumn.getSortField();
					oSortProperties.order = oSortingColumn.getSortIndicator();
				}
			}
			return oSortProperties;
		},

 		/**
 		 *  trigger the BE search to read reference objects fitting to search criteria, that come in via parameter
 		 *  @param {object} oParams - search parameter to be used for BE-read-request
 		 *  @param {object} oSort - sorting
 		 */
 		_searchForReferenceObjects: function (oParams, oSort) {
 			let entities = {},
 				oSortProperties = oSort || this._determineSortingCriterias(oSort);

			this.oContext.getView().getModel("localModel").getData().busyAddRefObjList = true;
			this.oContext.getView().getModel("localModel").refresh();
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = Constants.getEntities().IBaseComponentSet;
			if (oSortProperties) {
				entities.sortItem = oSortProperties.field;
				entities.sortOrder = Constants.getSortOrder()[oSortProperties.order];
			}
			entities.errorMessage = this.oContext.getResourceBundle().getText("ProjectDetails.ROSearchingError");
		
			let aFilterMap = [
				{ field : "Customer", subString : false },
				{ field : "InstNo", subString : true },
				{ field : "DeployModel", subString : false },
				{ field : "SystemUsage", subString : false },
				{ field : "SolmanUsage", subString : false },
				{ field : "CarSysRole", subString : false },
				{ field : "CarDataCenter", subString : false },
				{ field : "SystemRefNum", subString : true },
				{ field : "SID", subString : true },
				{ field : "SysDescription", subString : true },
				{ field : "SolmanSID", subString : true },
				{ field : "SolmanInstNo", subString : true },
				{ field : "SolmanRelease", subString : true },
				{ field : "SolutionID", subString : true },
				{ field : "SolutionDescr", subString : true },
				{ field : "IbComponent", subString : true },
				{ field : "SystemSolman", subString : false },
				{ field : "PartnerRelFlag", subString : false },
				{ field : "DeletionFlag", subString : false }
			];
			entities.filter = "";
			for(let oFilter of aFilterMap) {
				entities.filter = this._addSearchFilter(entities.filter, oFilter, oParams);	
			}

			entities.currentView = this.oContext.getView();
			entities.oContext = this.oContext;
			entities.busyIndicator = "busyAddRefObjList";
			entities.callbackSuccess = (data) => {
				this.oContext.getView().getModel("localModel").getData().busyAddRefObjList = false;
				this.oContext.getView().getModel("localModel").refresh();
				this._handleSuccessFindRO(data, oParams);
			};
			this.oContext.readBaseRequest(entities);
		},

		_addSearchFilter: function (sFilter, oFilter, oParams) {
			if (oParams[oFilter.field]) {
				sFilter = sFilter !== "" ? sFilter + " and" : "";
				if (oFilter.subString) {
					sFilter = `${sFilter} substringof('${oParams[oFilter.field]}', ${oFilter.field})`;
				} else {
					sFilter = `${sFilter} ${oFilter.field} eq '${oParams[oFilter.field]}'`;
				}
			}
			return sFilter;
		},

		/**
		 * Helper method to handle the reference object data, that was received from BE
		 * 
		 * Note: Show leading '0' for installation numbers, as otherwise, 
		 * contains filter like '002' would lead ton confusing results.
		 * 
		 * @param {object} oData - reference object data received from BE
		 * @param {object} oParams - search parameter that have been used by the BE-read-request
		 */
		_handleSuccessFindRO: function (oData, oParams) {
			oData.results = this._removeDuplicateSystems(oData.results);

			oData.results.map(oItem => {
				oItem.AlreadyExists = this.checkIfROAlreadyExists(oItem);
				oItem.SystemRefNum = this.formatter._removeZeroesFromField(oItem.SystemRefNum);
				oItem.PartnerRelFlag = this.oContext.getResourceBundle().getText("ReferenceObjects.Flag." + oItem.PartnerRelFlag);
				oItem.DeletionFlag = this.oContext.getResourceBundle().getText("ReferenceObjects.Flag." + oItem.DeletionFlag);
			});
			let initialVisibleRowsRO = Constants.getVisibleRowsRO();
			this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().items = this._applyUIFilters(oData.results, oParams);
			let intROLength = this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().items.length;
			this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().count = intROLength;
			this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().visibleRows = intROLength > initialVisibleRowsRO ?
				initialVisibleRowsRO :
				intROLength;
			this.oContext._oDialogAddNewRO.getModel("oModelRO").refresh();

			this.oContext.getView().getModel("localModel").getData().busyAddRefObjList = false;
			this.oContext.getView().getModel("localModel").refresh();

			this._initializeAddRefObjTablePerso(this.oContext);

			let oAddRefObj = Fragment.byId(this.oContext.getView().createId("roSelectPopup"), "tableRO");
			oAddRefObj.setContext(this.oContext);
		},

		/**
		 *  helper method to remove unnessary entries from the result list. An entry is considered unnesseary,
		 *  if there is already another entry with the same SystemRefNum, SolmanSID, SystemUsage AND InstNo.
		 *  In this case the entry is removed, only the ProductVersion of this entry is added to the ProductVersion-field
		 *  of the same entry which is displayed.
		 *  @param {array} aBeResults - array of reference objects, received from the BE
		 *  @returns {array} results
		 */
		_removeDuplicateSystems: function (aBeResults) {
			let aSmaller = [];
			for (let oResult of aBeResults) {
				let oSmaller = aSmaller.find(function (elem) {
					if (elem.SystemRefNum === oResult.SystemRefNum && elem.SolmanSID === oResult.SolmanSID
						&& elem.SystemUsage === oResult.SystemUsage && elem.InstNo === oResult.InstNo)
						return elem;
				});
				if (oSmaller) {
					if (!String(oSmaller.ProductVersionName).includes(oResult.ProductVersionName)) {
						oSmaller.ProductVersionName = oSmaller.ProductVersionName + ",\n " + oResult.ProductVersionName;
					}
				} else {
					aSmaller.push(oResult);
				}

			}
			return aSmaller;
		},
		/**
		 *  helper method to check if a reference object in the search result list is already linked to the project. 
		 *  @param {object} oSelectedRO - one reference object, that was received from BE via reference object search
		 *  @return {boolean} - true if this one reference object is already linked to the project, otherwise false
		 */
		checkIfROAlreadyExists: function (oSelectedRO) {
			let bROAlreadyExists = false;
			let aRefObjects = this.oContext.getView().getModel("ReferenceObjects").getData().results;
			if (aRefObjects.length === 0) {
				bROAlreadyExists = false;
			} else {
				$.each(aRefObjects, function (iIndex, oItem) {
					if (oSelectedRO.IbComponent === oItem.IbComponent &&
						oSelectedRO.SolmanComponent === oItem.SolmanComponent) {
						bROAlreadyExists = true;
					}
				});
			}
			return bROAlreadyExists;
		},

		/**
		 *  helper method to apply calculated properties for each entry of the result list 
		 *  of reference object search: 
		 *  - alreadyAdded (Flag)
		 *  @param {object} oItems - items
		 *  @param {object} oParams - search parameter that have been used by the BE-read-request
		 *  @return {object} - the item object that has come into as param oItems, enriched with new property "alreadyAdded"
		 */
		_applyUIFilters: function (oItems, oParams) {
			let alreadyAdded = oParams.alreadyAdded,
				oFilteredItems = oItems;
			oFilteredItems = oFilteredItems.filter(function (oItem) {
				return (alreadyAdded === "YES" && oItem.AlreadyExists) ||
					(alreadyAdded === "NO" && !oItem.AlreadyExists) ||
					(alreadyAdded === "ALL");
			});
			return oFilteredItems;
		},

		// ===================================== Handle user actions on reference object popup =================================

		/**
		 *  event handler, when user clicks on "reset sorting" button on UI
		 *  @param {object} oEvent - event that has been triggered
		 *  @param {object} oContext - context in which the method is called
		 */
		resetSorting: function (oEvent, oContext) {
			let oTable = Fragment.byId(oContext.getView().createId("roSelectPopup"), "tableRO"),
				aColumns = oTable.getColumns();
			oTable.getBinding("rows").sort(null);
			for (let oColumn of aColumns) {
				oColumn.setSorted(false);
			}
		},

 		/**
 		 *  event handler, when user selects an entry. It sets true/false to the model property "roSelectionPage", which controls
 		 *  then the visability of "Add" button.
 		 *  @param {object} oEvent - event that has been triggered
 		 *  @param {object} oContext - context in which the method is called
 		 */
 		fnHandleSelectionChange: function (oEvent, oContext) {
 			oContext._oDialogAddNewRO.getModel("oModelRO").getData().roSelectionPage =
 				!!oEvent.getSource().getSelectedItems().length;
 			oContext._oDialogAddNewRO.getModel("oModelRO").refresh();
 		},

		/**
		 *  event handler, when user navigates back from customer search help page to reference object popup main page
		 *  @param {object} oContext - context in which the method is called
		 */
		onRONavBack: function (oContext) {
			let oNavCon = Fragment.byId(oContext.getView().createId("roSelectPopup"), "navContainer");
			oNavCon.back();
			oContext.getView().getModel("customerSearchHelp").getData().selectedCustomerName = "";
			oContext._oDialogAddNewRO.getModel("customerSearchHelp").refresh();
			oContext.getView().getModel("customerSearchHelp").getData().results = [];
			oContext.getView().getModel("customerSearchHelp").refresh();
			Fragment.byId(oContext.getView().createId("roSelectPopup"), "tableRO").removeSelections();
		},

		/**
		 * helper function, which is called, if oModelRO property customerID is changed. (registered for binding)
		 * this is only needed, in case user selectes a customer in the the customer search help popup in the result list.
		 * Then the customer is taken over in the oModelRO/customerID field but the "normal" change-event handler, defined on the 
		 * XML is is not triggered in this case. Thats why we need to listen to the change of the model property as well.
		 * But we need to prevent, that the "real" event handler for customerID change ("onCustomerIDorInstNoChange") is called twice,
		 * if the user changes customerID on the XML-view. Thats why a further helper property "helperCustomerIDchangedOnModel"
		 * is introduced. It is set, when the user clicks on a customer in the result list of the customer search help popup
		 * and the customerID is written into the oModelRO field customerID.
		 * Only in this case the "real" method "onCustomerIDorInstNoChange" is actually called
		 * @param {object} oEvent - event that was triggered
		 * @param {object} oContext - The context in which the method is called
		 */
		fnHandleModelPropertyChangeCustomerID: function (oEvent) {
			if (this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().helperCustomerIDchangedOnModel) {
				this.oContext._oDialogAddNewRO.getModel("oModelRO").getData().helperCustomerIDchangedOnModel = false;
				this.onCustomerIDOrInstNoChange(oEvent, this.oContext);
			}
		},

		/**
		 * event handler triggered when value of customer or installation field is changed.  
		 * Sets flags for "Customer exists" and "Installation exists"
		 * When customer has been entered, 
		 *  - load all installations for the customer into the installation-combo
		 *  - initialize installation-Input-field
		 * When customer is cleared,
		 *  - take the currently selected key from the installation-combo into the installation-Input-field
		 *  - clear the selected key from the installation-combo
		 *  - clear the installations of the previous customer from the installation-combo
		 * Introduce generic property "inputMissing" to simplify property binding (e.g. value states...)
		 * @param {object} oEvent - event that was triggered
		 * @param {object} oContext - The context in which the method is called
		 */
		onCustomerIDOrInstNoChange: function (oEvent, oContext) {
			let sSource = oEvent.getSource().sPath ? oEvent.getSource().sPath : oEvent.getSource().getId();
			let oModel = oContext._oDialogAddNewRO.getModel("oModelRO");

 			let sCustomerId = oModel.getData().customerID;
 			let sInstNo = this._determineInstallationNumber();
 			oModel.getData().customerIDExists = sCustomerId !== "";
 			oModel.getData().instNoExists = sInstNo !== "";

			oModel.getData().inputMissing = false;
			if (!oModel.getData().customerIDExists && !oModel.getData().instNoExists) {
				oModel.getData().inputMissing = true;
			}

			if (sSource.includes("customerID")) {
				if (oModel.getData().customerIDExists) {
					oModel.getData().sInstallationNumberInput = "";
					this._searchInstallationsOfCustomer(sCustomerId);
				} else {
					oModel.getData().sInstallationNumberInput = oModel.getData().installationsSelectedKey;
					oModel.getData().installationsSelectedKey = "";
					oModel.getData().installations = {};
				}
			}

			oModel.refresh();
		},

		// ===================================== data center value help on reference object popup =================================
		/**
		 *  event handler, navigates to the "dataCenterValueHelp"-page within the NavContainer of the reference object popup
		 *  (the "dataCenterValueHelp"-page contains the data-center-value-help-Fragment)
		 *  Will load the data center values from the backend
		 *  @param {object} oEvent - event that has been triggered
		 *  @param {object} oContext - context in which the method is called
		 */
		dataCenterValueHelpTrigger: function (oEvent, oContext) {
			let oNavCon = Fragment.byId(oContext.getView().createId("roSelectPopup"), "navContainer"),
				oDetailPage = Fragment.byId(oContext.getView().createId("roSelectPopup"), "dataCenterValueHelp");

			let aDataCenters = [];
			this.oContext._oDialogAddNewRO.setModel(new JSONModel({
				dataCenters: aDataCenters,
				numberOfDataCenters: aDataCenters.length
			}), "dataCenterSearchHelp");

			this.oContext._oDialogAddNewRO.getModel("dataCenterSearchHelp").setProperty("/busyDataCenterHelpTable", true);
			this._readDataCenters().then(function (oData) {
				oData.results.forEach(function (elem) {
					if (!elem.Value || elem.Value === "") {
						elem.Value = elem.Key;
					}
					elem.Value = elem.Value.trim();
				});

				this.oContext._oDialogAddNewRO.getModel("dataCenterSearchHelp").setProperty("/filteredDataCenters", oData.results);
				this.oContext._oDialogAddNewRO.getModel("dataCenterSearchHelp").setProperty("/numberOfDataCenters", oData.results.length);
				this.oContext._oDialogAddNewRO.getModel("dataCenterSearchHelp").setProperty("/dataCenters", oData.results);

				this.oContext._oDialogAddNewRO.getModel("dataCenterSearchHelp").setProperty("/busyDataCenterHelpTable", false);

			}.bind(this));

			oNavCon.to(oDetailPage);
		},

		/**
		 *  event handler when user clicks on an entry in the result list of data center Fragment
		 *  - selected data center id is written into oModelRO.dataCenterSelectedKey,
		 *  @param {object} oEvent - event that has been triggered
		 *  @param {object} oContext - context in which the method is called
		 */
		handleDataCenterItemPressed: function (oEvent, oContext) {
			let oSource = oEvent.getSource();
			let sSelectedPath = oSource.getBindingContextPath();
			let oSelectedDataCenter = oContext._oDialogAddNewRO.getModel("dataCenterSearchHelp").getProperty(sSelectedPath);

			oContext._oDialogAddNewRO.getModel("oModelRO").setProperty("/dataCenterSelectedKey", oSelectedDataCenter.Key);
			oContext._oDialogAddNewRO.getModel("oModelRO").refresh();
			this.onRONavBack(oContext);
		},

		/**
		 *  Event function to search and filter the current data centers 
		 */
		searchDataCenters: function () {
			let aDataCenters = this.oContext._oDialogAddNewRO.getModel("dataCenterSearchHelp").getProperty("/dataCenters");

			let sDataCenterId = this.oContext._oDialogAddNewRO.getModel("dataCenterSearchHelp").getProperty("/searchDataCenterId");
			if (sDataCenterId && sDataCenterId !== "") {
				aDataCenters = this._filterDataCenters(aDataCenters, "Key", sDataCenterId);
			}

			let sDataCenter = this.oContext._oDialogAddNewRO.getModel("dataCenterSearchHelp").getProperty("/searchDataCenter");
			if (sDataCenter && sDataCenter !== "") {
				aDataCenters = this._filterDataCenters(aDataCenters, "Value", sDataCenter);
			}

			this.oContext._oDialogAddNewRO.getModel("dataCenterSearchHelp").setProperty("/filteredDataCenters", aDataCenters);
			this.oContext._oDialogAddNewRO.getModel("dataCenterSearchHelp").setProperty("/numberOfDataCenters", aDataCenters.length);
		},

		/**
		 * helper function to filter a specific property of a data center
		 * @param {array} aDataCenters - all available data centers
		 * @param {string} sProperty - property id to filter
		 * @param {string} sFilterValue - filter value to search for
		 * @return {array} filtered data centers 
		 */
		_filterDataCenters: function (aDataCenters, sProperty, sFilterValue) {
			return aDataCenters.filter(function (oDataCenter) {
				return oDataCenter[sProperty].includes(sFilterValue);
			});
		},

		// ===================================== customer search help on reference object popup =================================
		/**
		 *  event handler, navigates to the "detail"-page within the NavContainer of the reference object popup
		 *  (the "detail"-page contains the customer-search-help-Fragment)
		 *  it also sets the roSelectionPage-property to false, which disables the "Add" button 
		 *  (which is required, as the same "Add" button is also used by the customer-search-help-Fragment)
		 *  @param {object} oEvent - event that has been triggered
		 *  @param {object} oContext - context in which the method is called
		 */
		customerIdValueHelpTrigger: function (oEvent, oContext) {
			let oNavCon = Fragment.byId(oContext.getView().createId("roSelectPopup"), "navContainer"),
				oDetailPage = Fragment.byId(oContext.getView().createId("roSelectPopup"), "detail");
			oContext._oDialogAddNewRO.getModel("oModelRO").getData().roSelectionPage = false;
			oContext._oDialogAddNewRO.getModel("oModelRO").refresh();
			oNavCon.to(oDetailPage);
		},

		/**
		 *  event handler, called when the users starts the search inside the customer-search-help-Fragment.
		 *  triggers the BE search for customer.
		 *  @param {object} oEvent - event that has been triggered
		 *  @param {object} oContext - context in which the method is called
		 */
		searchCustomerSpecific: function (oEvent, oContext) {
			let entities = {},
				customerNameToSearch = oContext.getView().getModel("customerSearchHelp").getData().selectedCustomerName.trim();
			oContext.getView().getModel("localModel").getData().busyCustomerHelpTable = true;
			oContext.getView().getModel("localModel").refresh();

			entities.servicePath = Constants.getServicePath();
			entities.entitySet = Constants.getEntities().CustomerEntity;
			entities.filter = "(CustomerName  eq '*" + customerNameToSearch + "*')";
			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.busyIndicator = "busyCustomerHelpTable";
			entities.errorMessage = oContext.getResourceBundle().getText("NewProject.CustomerSearchError");
			entities.callbackSuccess = (oData) => {
				this._handleSuccesSearchCustomerValueHelp(oData, oContext);
			};
			oContext.readBaseRequest(entities);
		},

		/**
		 *  handle the data that is received be the customer-BE-search.
		 *  (received data is put into model "customerSearchHelp"))
		 *  @param {object} oData - data set
		 *  @param {object} oContext - context in which the method is called
		 */
		_handleSuccesSearchCustomerValueHelp: function (oData, oContext) {
			let helpCustomerModel = oContext.getView().getModel("customerSearchHelp");
			helpCustomerModel.getData().results = oData.results;
			helpCustomerModel.refresh();
			oContext.getView().getModel("localModel").getData().busyCustomerHelpTable = false;
			oContext.getView().getModel("localModel").refresh();
		},

		/**
		 *  event handler when user clicks on an entry in the result list of customer search Fragment
		 *  - selected customer's ID is written into oModelRO.CustomerID,
		 *  @param {object} oEvent - event that has been triggered
		 *  @param {object} oContext - context in which the method is called
		 */
		handleCustomerItemPressed: function (oEvent, oContext) {
			let oSource = oEvent.getSource(),
				sPath = oSource.getSelectedContextPaths(),
				iSelectedItemIndex = parseInt(sPath[0].split("/")[2], 10),
				oSelectedItemFromModel = oContext.getView().getModel("customerSearchHelp").getData().results[iSelectedItemIndex];

			oContext._oDialogAddNewRO.getModel("oModelRO").getData().customerID = oSelectedItemFromModel.CustomerID;
			oContext._oDialogAddNewRO.getModel("oModelRO").getData().helperCustomerIDchangedOnModel = true;
			oContext._oDialogAddNewRO.getModel("oModelRO").refresh();
			this.onRONavBack(oContext);
		},
		// New Version of popup - KNGMHM02-23694
		handleCustomerItemPressedGenCustomerPopup: function (sPartnerID, oContext) {
			oContext._oDialogAddNewRO.getModel("oModelRO").getData().customerID = sPartnerID;
			oContext._oDialogAddNewRO.getModel("oModelRO").getData().helperCustomerIDchangedOnModel = true;
			oContext._oDialogAddNewRO.getModel("oModelRO").refresh();
		},
		/**
		 *  event handler, called when the user closes the reference object popup either by using buttons "add" or "cancel"
		 *  @param {object} oEvent - event that has been triggered
		 *  @param {object} oContext - context in which the method is called
		 */
		discardReferenceObjectsDialog: function (oEvent, oContext) {
			oContext.getView().getModel("oModelRO").getData().customerIDExists = true;
			oContext.getView().getModel("oModelRO").getData().instNoExists = true;
			oContext.getView().getModel("oModelRO").refresh();
			Fragment.byId(this.oContext.getView().createId("roSelectPopup"), "tableRO").removeSelections();
			oContext._oDialogAddNewRO.close();
		},

		/**
		 *  event handler, called when the user closes the reference object popup either by using buttons "add" or "cancel"
		 *  REMARK: only called from ServiceOrder-Context, because it is exactly designed to open the ComboBox "ReferenceObject"
		 *          that is on the ServiceOrder screen, right after the user has closed the popup
		 *  @param {object} oContext - context in which the method is called
		 */
		expandListOfRO: function (oContext) {
			if (oContext.getView().byId("ReferenceObject")) {
				oContext.getView().byId("ReferenceObject").open();
			}
			oContext._oDialogAddNewRO.destroy();
			oContext._oDialogAddNewRO = undefined;
		},

		/**
		 *  event handler, when the user clicks on "add"-button to take the selected reference objets from the result list over
		 *  in the calling view
		 *
		 * 
		 *  @param {object} oEvent - event that has been triggered
		 *  @param {object} oContext - context in which the method is called
		 */
		fnHandleAddRefObj: function (oEvent, oContext) {
			this._addRefObj(oEvent, oContext);
			if (oContext.getModel("localModel").getData().bDetailPage) {
				oContext.onPressSaveRefObj();
			}
		},

		_addRefObj: function (oEvent, oContext) {
			let oTable = Fragment.byId(oContext.getView().createId("roSelectPopup"), "tableRO"),
				aReferenceObjects = oContext.getView().getModel("ReferenceObjects").getData().results,
				oModelBinding = oContext.getView().getModel("oModelRO"),
				oSelectedPaths = oTable.getSelectedContextPaths(),
				myLength = oSelectedPaths.length,
				iCounter = 0,
				oSelectedRO,
				sROs = "",
				sROAlreadyExist = "",
				newROs = [];
			oSelectedPaths.forEach(sPath => {
				oSelectedRO = oModelBinding.getProperty(sPath);
				if (this.checkIfROAlreadyExists(oSelectedRO) === false) {
					if (aReferenceObjects === undefined) {
						oContext.getView().getModel("ReferenceObjects").getData().results = [];
					}
					oSelectedRO.new = true;
					oSelectedRO.deleted = false;
					oSelectedRO.save = true;
					oSelectedRO.ProjectID = oContext.getView().getModel("projectDetails").getData().ProjectID;
					oSelectedRO.comboValue = this.formatter.refObjDisplay(oSelectedRO);
					this._createGroupingRO(oSelectedRO, oContext);

					newROs.push(oSelectedRO);
					iCounter++;
				} else {
					sROs += "SID: " + oSelectedRO.SID + " / " +
						" InstNo: " + oSelectedRO.InstNo + " / " +
						" Ibase Component: " + oSelectedRO.IbComponent + " / " +
						" Customer ID: " + oSelectedRO.Customer + "\n";
				}
			});
			if (iCounter === myLength) {
				$.each(newROs, (index, item) => {
					oContext.getView().getModel("ReferenceObjects").getData().results.push(item);
				});
				oContext.getView().getModel("ReferenceObjects").refresh();
				this.discardReferenceObjectsDialog(oEvent, oContext);
			} else if (sROs === "") {
				MessageBox.error(oContext.getResourceBundle().getText("RO.New.NoItemSelected.Content"), {
					title: oContext.getResourceBundle().getText("RO.New.NoItemSelected.Title"),
					actions: [MessageBox.Action.OK]
				});
			} else {
				sROAlreadyExist = oContext.getResourceBundle().getText("RO.New.AlreadyExist.Content") + sROs;
				MessageBox.error(sROAlreadyExist, {
					title: oContext.getResourceBundle().getText("RO.New.AlreadyExist.Title"),
					actions: [MessageBox.Action.OK]
				});
			}
		},

		/**
		 *  Event handler when user clicks on <Clear>-button
		 * 
		 *  Remark: <Clear>-button is currently not used and not displayed - so function is not needed
		 * 
		 *  @param {object} oEvent - event that has been triggered
		 *  @param {oObject} oContext - context in which the method is called
		 */
		/*onRefObjFiltersClear: function (oEvent, oContext) {
			let oItems = Fragment.byId(oContext.getView().createId("roSelectPopup"), "filterBarRO").getAllFilterItems(true);
			for (let i = 0; i < oItems.length; i++) {
				let oControl = oContext.getView().byId("filterBarRO").determineControlByFilterItem(oItems[i]);
				if (oControl) {
					oControl.setValue("");
				}
			}
		},*/

		// ==================================================================================================
		// ===================================== Project Details View ONLY  =================================
		// ==================================================================================================	

		/**
		 *  Helper function for project details. 
		 *  Prepare reference objects for saving scenarios: 
		 *  - user can add one or several reference objects at once
		 *  - user can delete exactly one reference object (thats why array.splice can be used)
		 *  @param {function} resolveRO - callback function when promise is resolved
		 *  @param {function} rejectRO - callback function when promise is rejected
		 *  @param {oObject} oContext - context in which the method is called
		 */
		_manipulateReferenceObjects: function (resolveRO, rejectRO, oContext) {
			let oModel = oContext.getView().getModel("ReferenceObjects"),
				oModelReferenceObjects = oModel.getData().results,
				oPayload = {},
				sBatchIndividualUrl;

			let myServiceUrl = Constants.getServicePath();
			let oBModel = new ODataModel(myServiceUrl);
			let iCounter = 0;
			oBModel.setHeaders(Constants.getAPIHeaders());
			oBModel.setDeferredGroups(["groupSetId"]);
			oModelReferenceObjects.forEach((oElem, iIndex, aArray) => {
				if (oElem.save === true && oElem.deleted === false) {
					oPayload = {
						"ProjectID": oElem.ProjectID,
						"IbComponent": oElem.IbComponent,
						"SolmanComponent": oElem.SolmanComponent
					};
					sBatchIndividualUrl = `/${Constants.getEntities().ReferenceObjectSet}`;
					oBModel.create(sBatchIndividualUrl, oPayload, {
						groupId: "groupSetId"
					});
					oElem.save = false;
				} else if (oElem.save === false && oElem.deleted === true) {
					sBatchIndividualUrl = `/${Constants.getEntities().ReferenceObjectSet}(Guid=guid'${oElem.Guid}',ProjectID='${oElem.ProjectID}')`;
					oBModel.remove(sBatchIndividualUrl, {
						groupId: "groupSetId"
					});
					oModelReferenceObjects.splice(iIndex, 1);
				} else {
					iCounter++;
				}
			});
			oModel.refresh();

			if (oModelReferenceObjects.length === iCounter) {
				resolveRO();
			}
			oBModel.submitChanges({
				groupId: "groupSetId",
				success: (oData) => {
					this._onSuccessUpdateRefObjects(oData, oContext);
					resolveRO();
				},
				error: (oError) => {
					rejectRO();
				}
			});
		},

		_onSuccessUpdateRefObjects: function (oData, oContext) {
			let oModel = oContext.getView().getModel("ReferenceObjects"),
						 oModelReferenceObjects = oModel.getData().results;
			try {
				for (let oResponse of oData.__batchResponses[0].__changeResponses) {
					if (oResponse.statusCode !== "201") {
						continue;
					}
					oModelReferenceObjects.find(function (elem) {
						if (elem.IbComponent === oResponse.data.IbComponent && elem.SolmanComponent === oResponse.data.SolmanComponent) {
							elem.Guid = oResponse.data.Guid;
						}
					});
				}
				oModel.refresh();
			} catch (e) {

			}
			oContext.getView().getModel("ReferenceObjects").getData().numberOfItems = oContext.getView().getModel("ReferenceObjects").getData()
				.results.length;
			oContext.getView().getModel("ReferenceObjects").refresh();
		},

 		deleteRefObjConfirmation: function (oEvent, oContext) {
 			let sPath = oEvent.getSource().getBindingContext("ReferenceObjects").getPath(),
 				oSelectedItem = oContext.getView().getModel("ReferenceObjects").getProperty(sPath),
 				oSelectedUIItem = oEvent.getSource().getParent();

			MessageBox.confirm(oContext.getResourceBundle().getText("RO.Delete.Confirm.Content"), {
				details: "<p class='indication6TextColor'>" + oSelectedItem.SolmanAssigned + "</p>" +
					"<ul>" +
					"<li>BP ID: " + oSelectedItem.Customer + "</li>" +
					"<li>Installation Number: " + oSelectedItem.InstNo + " </li>" +
					"<li>System ID: " + oSelectedItem.SID + " </li>" +
					"<li>Description: " + oSelectedItem.SysDescription + "</li>" +
					"<li>Ibase Component: " + oSelectedItem.IbComponent + "</li>" +
					"<li>SolMan ID: " + oSelectedItem.SolmanSID + "</li>" +
					"</ul>",
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				emphasizedAction: MessageBox.Action.YES,
				onClose: (sAction) => {
					if (sAction === "YES") {
						this._deleteRefObj(sPath, oSelectedUIItem, oContext);
						oContext.onPressSaveRefObj();
					}
				}
			});
		},

		_deleteRefObj: function (sPath, oSelectedUIItem, oContext) {
			let iSelectedElementId = sPath.split("/")[2],
				oModel = oContext.getView().getModel("ReferenceObjects"),
				oTable = oSelectedUIItem.getParent(),
				oBinding = oTable.getBinding("items"),
				oFilter;

			oModel.getData().results[iSelectedElementId].deleted = true;
			oModel.refresh();
			oFilter = new Filter("deleted", sap.ui.model.FilterOperator.EQ, false);
			oBinding.filter(oFilter);
		},

		// ================================================================================================
		// ===================================== Service Order View ONLY  =================================
		// ================================================================================================

		/**  Event handler when user changes the Reference Object of the service order
		 *  clear the Service Contact Person, as it depends on the selected Reference Object
		 *  
		 *  In case the user has emptied the Reference Object Field, initialize the related Model fields
		 *  In case the user has selected a (new) value, fill the model-sub-path "oModelSO.selectedRefObj" with
		 *  the selected values. (These values can be taken from the "ReferenceObjects"-Model, which is filled
		 *  with the list Reference Objects, that are assigned to the project.)
		 *  Also check that the selected RefObj is valid (i.e. contains Solman and Sytem in case both is required)
		 *
		 *  also always perform a billing-check
		 * 
		 *  @param {object} oEvent - event that has been triggered
		 *  @param {oObject} oContext - context in which the method is called
		 */
		fnHandleRefObjChangeSO: function (oEvent, oContext) {
			oContext.getView().getModel("oModelSO").getData().refObjComboValueStateText =
				oContext.getResourceBundle().getText("SO.Error.Subtitle.RefObj");
			oContext.getView().getModel("oModelSO").getData().refObjExist = false;
			oContext.getView().getModel("oModelSO").refresh();

			if (oEvent.getParameter("value") === "") {
				oContext.getView().getModel("oModelSO").getData().selectedRefObj = {};
				oContext.getView().getModel("oModelSO").getData().DeliveryModel = "";
				oContext.getView().getModel("oModelSO").getData().DeliveryModelText = "#";
				oContext.getView().getModel("oModelSO").getData().contractRequired = false;
				oContext.getView().getModel("oModelSO").getData().refObjExists = false;
				oContext.getView().getModel("oModelSO").getData().contractItemRequired = false;
				oContext.getView().getModel("oModelSO").refresh();
				oContext.checkBilling();
			} else {
				let oSelectedRefObj = oContext.getView().getModel("ReferenceObjects").getData().results.find(
					elm => elm.comboValue === oEvent.getParameter("value")
				);
				if (typeof oSelectedRefObj !== "undefined") {
					oContext.getView().getModel("oModelSO").getData().selectedRefObj = {
						"InstNo": oSelectedRefObj.InstNo,
						"SystemID": oSelectedRefObj.SID,
						"SolmanComponent": oSelectedRefObj.SolmanComponent,
						"SolmanSID": oSelectedRefObj.SolmanSID,
						"SolmanInstNo": oSelectedRefObj.SolmanInstNo,
						"SolmanRelease": oSelectedRefObj.SolmanRelease,
						"IbComponent": oSelectedRefObj.IbComponent,
						"SystemNumber": oSelectedRefObj.SystemRefNum,
						"SystemDescription": oSelectedRefObj.SysDescription,
						"DeployMod": oSelectedRefObj.DeployMod,
						"SystemRoleText": oSelectedRefObj.CarSysRoleText
					};
					oContext.getView().getModel("oModelSO").getData().DeliveryModel = oSelectedRefObj.DeliveryModel;
					oContext.getView().getModel("oModelSO").getData().DeliveryModelText = oSelectedRefObj.DeliveryModelText;
					oContext.getView().getModel("oModelSO").getData().DeployMod = oSelectedRefObj.DeployMod;
					oContext.getView().getModel("oModelSO").getData().DeployModT = oSelectedRefObj.DeployModel;

					oContext.getView().getModel("oModelSO").getData().newSOValid.refObj = "None";
					oContext.getView().getModel("oModelSO").getData().newSOValid.refObjRequiredForRelease = "None";
					oContext.getView().getModel("oModelSO").getData().refObjExist = true;
					oContext.getView().getModel("oModelSO").refresh();

					oContext.checkRefObjValueIsValid();
					oContext.checkBilling();
				} else {
					oContext.getView().getModel("oModelSO").getData().RefObjText = "";
					oContext.getView().getModel("oModelSO").refresh();
				}
			}
		},

 		/**
 		 *  Validate refObject
 		 *  Search on session level as well: System/SolMan required when true on at least one session
 		 *  @param {object} oContext - The context in which the method is called
 		 */
 		fnValidatedRefObjectsSO: function (oContext) {
 			let oSOModel = oContext.getView().getModel("oModelSO");
 			let solManCheck = !(oSOModel.getData().solmanRequired && oSOModel.getData().selectedRefObj.SolmanComponent === "0");
 			oSOModel.getData().newSOValid.refObjRequiredForRelease = solManCheck ? "None" : "Information";
 			oSOModel.getData().refObjComboValueStateText = solManCheck ?
 				oContext.getResourceBundle().getText("SO.Error.Subtitle.RefObj") :
 				oContext.getResourceBundle().getText("SO.Error.OnlySolman.RefObj");

			let iSolmanRequired = 0;
			let iSystemRequired = 0;
			oSOModel.getData().refObjRequired = false;
			oSOModel.getData().systemRequired = false;
			oSOModel.getData().solmanRequired = false;
			if (oContext.getModel("treeSO").getData().itemsSO) {
				oContext.getModel("treeSO").getData().itemsSO.forEach(mainItem => {
					iSystemRequired = this._checkSystemRequired(mainItem, iSystemRequired, oSOModel);
					iSolmanRequired = this._checkSolmanRequired(mainItem, iSolmanRequired, oSOModel);
					mainItem.itemsSO.forEach(session => {
						iSystemRequired = this._checkSystemRequired(session, iSystemRequired, oSOModel);
						iSolmanRequired = this._checkSolmanRequired(session, iSolmanRequired, oSOModel);
					});
				});
			}
			oSOModel.refresh();
			oContext.getView().getModel("oModelRO").getData().refObjRequirements = iSystemRequired + iSolmanRequired;
			oContext.getView().getModel("oModelRO").refresh();
		},

		_checkSystemRequired(oItem, iSystemRequired, oSOModel) {
			if (iSystemRequired === 0 && oItem.SystemRequired) {
				oSOModel.getData().refObjRequired = true;
				oSOModel.getData().systemRequired = true;
				iSystemRequired = 1;
			}
			return iSystemRequired;
		},

		_checkSolmanRequired(oItem, iSolmanRequired, oSOModel) {
			if ( iSolmanRequired === 0 && oItem.SolmanRequired) {
				oSOModel.getData().refObjRequired = true;
				oSOModel.getData().solmanRequired = true;
				iSolmanRequired = 2;
			}
			return iSolmanRequired;
		}


 	};
 });
