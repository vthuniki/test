sap.ui.define("com/sap/ui/hep/util/TablePersoLinkedObjects",
    [
        "com/sap/ui/hep/util/TablePersoBaseService"
    ],
    function (TablePersoBaseService) {
        "use strict";

        const PersoService = TablePersoBaseService.extend("com.sap.ui.hep.util.TablePersoLinkedObjects", {
            constructor: function () {
                TablePersoBaseService.call(this, "tablePerso-LinkedObjectsTable.json");
            },
        });

        return new PersoService();
    }, /* bExport= */ true);
