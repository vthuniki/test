/* eslint-disable sap-no-ui5base-prop */
/* eslint-disable sap-ui5-no-private-prop */
/* eslint-disable sap-no-ui5-prop-warning */
/*eslint-env es6*/
sap.ui.define(["jquery.sap.global"], function (jQuery) {
	"use strict";

	let PersonalizationService = {

		oData: {
			_persoSchemaVersion: "1.0",
			aColumns: [{
				id: "tablePersoSOC-SOComponents-colSOCProduct",
				order: 1,
				text: "colSOCProduct",
				visible: true
			}, {
				id: "tablePersoSOC-SOComponents-colSOCDescription",
				order: 2,
				text: "colSOCDescription",
				visible: true
			}]
		},

		setContext: function (oContext) {
			this.oContext = oContext;
			this._getCurrentConfigSession();
		},

		_getCurrentConfigSession: function () {
			if (this.oContext.getOwnerComponent().getModel("appData").getData().oMyStorage.get("homeProjectsTableConfig") !== null) {
				this._oBundle = this.oContext.getOwnerComponent().getModel("appData").getData().oMyStorage.get("homeProjectsTableConfig");
			}
		},

		getPersData: function () {
			let oDeferred = new jQuery.Deferred();
			if (!this._oBundle) {
				this._oBundle = this.oData;
			}
			const oBundle = this._oBundle;
			oDeferred.resolve(oBundle);
			return oDeferred.promise();
		},

		setPersData: function (oBundle) {
			let oDeferred = new jQuery.Deferred();
			this._oBundle = oBundle;
			oDeferred.resolve();
			return oDeferred.promise();
		},

		delPersData: function () {
			let oDeferred = new jQuery.Deferred();
			oDeferred.resolve();
			return oDeferred.promise();
		},

		resetPersData: function () {
			let oDeferred = new jQuery.Deferred();
			let oInitialData = {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "tablePersoSOC-SOComponents-colItem",
					order: 0,
					text: "colSOCItem",
					visible: true
				}, {
					id: "tablePersoSOC-SOComponents-colSOCId",
					order: 1,
					text: "colSOCId",
					visible: true
				}, {
					id: "tablePersoSOC-SOComponents-colSOCProduct",
					order: 2,
					text: "colSOCProduct",
					visible: true
				}, {
					id: "tablePersoSOC-SOComponents-colSOCDescription",
					order: 3,
					text: "colSOCDescription",
					visible: true
				}, {
					id: "tablePersoSOC-SOComponents-colSOCDays",
					order: 4,
					text: "colSOCDays",
					visible: true
				}, {
					id: "tablePersoSOC-SOComponents-colSOCConsultant",
					order: 5,
					text: "colSOCConsultant",
					visible: true
				}, {
					id: "tablePersoSOC-SOComponents-colSOCStatus",
					order: 6,
					text: "colSOCStatus",
					visible: true
				}, {
					id: "tablePersoSOC-SOComponents-colSOCStartDate",
					order: 7,
					text: "colSOCStartDate",
					visible: false
				}, {
					id: "tablePersoSOC-SOComponents-colSOCEndDate",
					order: 8,
					text: "colSOCEndDate",
					visible: false
				}, {
					id: "tablePersoSOC-SOComponents-colSOCQualification",
					order: 9,
					text: "colSOCQualification",
					visible: false
				}, {
					id: "tablePersoSOC-SOComponents-colSOCServiceType",
					order: 10,
					text: "colSOCServiceType",
					visible: false
				}]
			};
			this._oBundle = oInitialData;
			oDeferred.resolve();
			return oDeferred.promise();
		},

		getCaption: function (oColumn) {
			return null;
		}
	};

	return PersonalizationService;

}, /* bExport= */ true);