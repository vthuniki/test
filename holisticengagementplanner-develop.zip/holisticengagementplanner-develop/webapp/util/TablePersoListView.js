sap.ui.define("com/sap/ui/hep/util/TablePersoListView",
    [
        "com/sap/ui/hep/util/TablePersoBaseService"
    ],
    function (TablePersoBaseService) {
        "use strict";

        const PersoService = TablePersoBaseService.extend("com.sap.ui.hep.util.TablePersoListView", {
            constructor: function () {
                TablePersoBaseService.call(this, "tableSPDListViewTree.json");
            },
        });

        return new PersoService();
    }, /* bExport= */ true);
