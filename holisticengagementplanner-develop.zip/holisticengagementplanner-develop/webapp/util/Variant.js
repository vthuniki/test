sap.ui.define([
	"com/sap/ui/hep/reuse/Constants",
	"com/sap/ui/hep/reuse/BaseRequest",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/message/Message",
	"sap/ui/core/MessageType",
	"com/sap/ui/hep/util/MessageHandlingPopover"
], function (Constants, BaseRequest, JSONModel, Message, MessageType, MessageHandlingPopover) {
	"use strict";

	return {
		/*============================== Variant Management =========================*/
		pageVariantID: "",
		context: {},
		currentVariant: {
			filter: new JSONModel(),
			tablePerso: new JSONModel()
		},
		standardVariant: {
			filter: new JSONModel(),
			tablePerso: new JSONModel()
		},

		variantSetName: "",
		standardKey: '*standard*',
		variantLoaded: "",
		variantModel: new JSONModel({
			results: []
		}),

		setDefaultVariant: function (variantID) {
			this.selectedVariantKey = variantID;
			this.context.getView().byId(this.pageVariantID).setInitialSelectionKey(variantID);
			this.context.getView().byId(this.pageVariantID).setDefaultVariantKey(variantID);
			this.context.getView().byId(this.pageVariantID).setSelectionKey(variantID);
		},

		readVariants: function (selectedVariant) {
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = Constants.getEntities().VariantDataSet;
			entities.filter = `VariantSetName eq '${this.variantSetName}'`;
			entities.oContext = this.context;
			entities.currentView = this.context.getView();
			entities.callbackSuccess = (oData) => {
				this.context.getView().byId(this.pageVariantID).destroyVariantItems();
				this.variantModel.setData(oData);
				this.variantModel.refresh();

				if (oData) {
					let results = oData.results;
					let isDefaultVariantSelected = false;

					if (selectedVariant) {
						this.selectVariant(selectedVariant);
					} else {
						results.forEach(variant => {
							if (variant.IsDefault === "X") {
								this.setDefaultVariant(variant.VariantID);
								this.setCurrentVariant(variant.VariantContent);
								isDefaultVariantSelected = true;
							}
						});

						if (!isDefaultVariantSelected) {
							this.setDefaultVariant(this.standardKey);
							this.setCurrentVariant(null);
						}
					}
					sap.ui.core.BusyIndicator.hide();
				}
			};
			BaseRequest.handleRead(entities);

		},

		onSave: function (oEvent) {
			let existingVariantData = this.variantModel.getData();

			let variantDetails = oEvent.getParameters();
			let existingSelectedVariant = null;

			let defaultVariant = "";
			if (variantDetails.def) {
				defaultVariant = "X";
			}

			existingVariantData.results.forEach(existingVariant => {
				if (variantDetails.key === existingVariant.VariantID) {
					existingVariant.IsDefault = defaultVariant;
					existingSelectedVariant = existingVariant;
				}
			});

			let variantData = {
				filter: this.currentVariant.filter.getData(),
				tablePerso: this.currentVariant.tablePerso.getData()
			};
			this._newVariant(existingSelectedVariant, variantDetails, variantData, defaultVariant);

		},

		_newVariant: function (existingSelectedVariant, variantDetails, variantData, defaultVariant, tablePersoData) {
			sap.ui.core.BusyIndicator.show();

			if (existingSelectedVariant) {
				existingSelectedVariant.VariantContent = JSON.stringify(variantData);
				this.updateVariant(null, existingSelectedVariant, this);
			} else {
				let newVariant = {
					"VariantSetName": this.variantSetName,
					"VariantDisplayName": variantDetails.name,
					"VariantContent": JSON.stringify(variantData),
					"IsDefault": defaultVariant,
					"Scope": "LOCAL"
				};
				this.createVariant(newVariant);
			}
		},

		onSelect: function (oEvent) {
			const selectedVariantKey = oEvent.getParameters().key;
			if (selectedVariantKey !== this.standardKey) {
				this.selectVariant(selectedVariantKey);
			} else {
				this.setCurrentVariant(null);
			}
		},

		selectVariant: function (variantID) {
			if (this.selectedVariantKey === variantID) {
				return;
			}
			this.selectedVariantKey = variantID;
			this.context.getView().byId(this.pageVariantID).setSelectionKey(variantID);
			this.context.getView().byId(this.pageVariantID).setInitialSelectionKey(variantID);
			let oVariantData = this.variantModel.getData().results.find(elem => elem.VariantID === variantID).VariantContent;
			this.setCurrentVariant(oVariantData);
		},

		setCurrentVariant: function (variantData) {
			if (!variantData) {
				this.selectedVariantKey = this.standardKey;
				this.currentVariant.filter.setData(this.standardVariant.filter.getData());
				this.currentVariant.tablePerso.setData(this.standardVariant.tablePerso.getData());
			} else {
				this.currentVariant.filter.setData(JSON.parse(variantData).filter);
				this.currentVariant.tablePerso.setData(JSON.parse(variantData).tablePerso);
			}
			this.variantLoaded();
		},

		createVariant: function (payload) {
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = Constants.getEntities().VariantDataSet;
			entities.oContext = this.context;
			entities.currentView = this.context.getView();
			entities.callbackSuccess = (oData) => {
				this.readVariants(oData.VariantID);
			};
			entities.callbackError = (oError) => {};
			entities.data = payload;

			BaseRequest.handleCreate(entities);
		},

		_handleDefaultVariant: function(existingFiltersDataParam, defaultVariantParam, deletedVariants, renamedVariants){
			this.context.getView().byId(this.pageVariantID).setInitialSelectionKey(this.defaultSelectedKey);
			this.context.getView().byId(this.pageVariantID).setDefaultVariantKey(this.defaultSelectedKey);
			this.context.getView().byId(this.pageVariantID).setSelectionKey(this.defaultSelectedKey);

			existingFiltersDataParam = existingFiltersDataParam.map(existingFilter => {
				if (existingFilter.IsDefault === "X") {
					defaultVariantParam = existingFilter;
					existingFilter.IsDefault = "";
				}
				return existingFilter
			});

			if (defaultVariantParam && deletedVariants.length && deletedVariants.includes(defaultVariantParam.VariantID)) {
				defaultVariantParam = null;
			}
			if (defaultVariantParam && deletedVariants.length && renamedVariants.includes(defaultVariantParam.VariantID)) {
				defaultVariantParam = null;
			}

			return {existingFiltersDataParam, defaultVariantParam};

		},

		_handleNotDefaultVariants: function(oEvent, existingFiltersDataParam, defaultVariantParam, deletedVariants, renamedVariants){
			let explicitCallNeededToSetDefaultVariant = true;
				if (deletedVariants.length) {
					explicitCallNeededToSetDefaultVariant = deletedVariants.includes(oEvent.getParameters().def);
				}
				if (explicitCallNeededToSetDefaultVariant && renamedVariants.length) {
					explicitCallNeededToSetDefaultVariant = renamedVariants.includes(oEvent.getParameters().def);
				}
				if (oEvent.getParameters().def && oEvent.getParameters().def !== this.defaultSelectedKey) {
					existingFiltersDataParam = existingFiltersDataParam.map(existingFilter => {
						if (oEvent.getParameters().def === existingFilter.VariantID) {
							existingFilter.IsDefault = "X";
							if (explicitCallNeededToSetDefaultVariant) {
								defaultVariantParam = existingFilter;
							}
						} else {
							existingFilter.IsDefault = "";
						}
						return existingFilter;
					});
				}

				return {existingFiltersDataParam, defaultVariantParam};
		},

		onManage: function (oEvent) {
			let existingFiltersData = this.variantModel.getData().results;
			let deletedVariants = oEvent.getParameters().deleted;
			let renamedVariants = oEvent.getParameters().renamed;
			let defaultVariant = null;

			if (oEvent.getParameters().def === this.defaultSelectedKey) {

				let {existingFiltersDataParam, defaultVariantParam} = this._handleDefaultVariant(existingFiltersData, defaultVariant, deletedVariants, renamedVariants);
				existingFiltersData = existingFiltersDataParam;
				defaultVariant = defaultVariantParam;

			} else {
				let {existingFiltersDataParam, defaultVariantParam} = this._handleNotDefaultVariants(oEvent, existingFiltersData, defaultVariant, deletedVariants, renamedVariants);
				existingFiltersData = existingFiltersDataParam;
				defaultVariant = defaultVariantParam;
			}

			let setDefaultStandard = false;

			//if the sap variant is selected as default, all others are deselected from the default
			if(oEvent.getParameters().def === "*standard*"){
				 setDefaultStandard = true;
				existingFiltersData = existingFiltersData.map(item => item.IsDefault="")
			}

			if (deletedVariants.length || renamedVariants.length || defaultVariant || setDefaultStandard) {
				this.updateVariantCollection(deletedVariants, renamedVariants, existingFiltersData, defaultVariant, setDefaultStandard);
			}
		},

		updateVariantCollection: function (deletedVariants, renamedVariants, variantCollection, defaultVariant, setDefaultStandard) {
			let variantsToUpdate = [];

			variantCollection = variantCollection.map(variant => {
				renamedVariants.forEach(renamedVariant => {
					if (variant.VariantID === renamedVariant.key) {
						variant.VariantDisplayName = renamedVariant.name;
						variantsToUpdate.push(variant);
					}
				});
					return variant;
			});

			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = Constants.getEntities().VariantDataSet;
			entities.oContext = this.context;
			entities.currentView = this.context.getView();
			entities.callbackSuccess = (oData) => {};
			entities.callbackError = (oError) => {};

			deletedVariants.forEach(variant => {
				entities.entitySet = Constants.getVariantsEntityName(variant);
				BaseRequest.handleDelete(entities);
			});

			//if sap variant is selected as default, update the other ones
			if(setDefaultStandard)
				variantsToUpdate = variantCollection;

			variantsToUpdate = variantsToUpdate.map(variant => {
				if (variant["__metadata"]) {
					delete variant["__metadata"];
				}
				entities.updateMethod = "PUT";
				entities.data = variant;
				entities.entitySet = Constants.getVariantsEntityName(variant.VariantID);
				BaseRequest.handleUpdate(entities);

				return variant;
			});

			if (defaultVariant) {
				if (defaultVariant["__metadata"]) {
					delete defaultVariant["__metadata"];
				}
				entities.updateMethod = "PUT";
				entities.data = defaultVariant;
				entities.entitySet = Constants.getVariantsEntityName(defaultVariant.VariantID);
				BaseRequest.handleUpdate(entities);
			}
		},

		updateVariant: function (payload) {
			if (!payload) return;

			if (payload["__metadata"]) {
				delete payload["__metadata"];
			}
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = Constants.getEntities().VariantDataSet;
			entities.oContext = this.context;
			entities.currentView = this.context.getView();
			entities.callbackSuccess = (oData) => {};
			entities.callbackError = (oError) => {};
			entities.updateMethod = "PUT";
			entities.data = payload;
			entities.entitySet = Constants.getVariantsEntityName(payload.VariantID);
			BaseRequest.handleUpdate(entities);
		}

	};
});
