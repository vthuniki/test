sap.ui.define("com/sap/ui/hep/util/SessionTablePersoBaseService",
    [
        "com/sap/ui/hep/util/TablePersoBaseService"
    ],
    function (TablePersoBaseService) {
        "use strict";

        return TablePersoBaseService.extend("com.sap.ui.hep.util.SessionTablePersoBaseService.js", {
            constructor: function (personalizationFile, configName) {
                TablePersoBaseService.call(this, personalizationFile);
                this._configName = configName;
            },

            setContext: function (oContext) {
                this.oContext = oContext;
                this._getCurrentConfigSession();
            },

            _saveCurrentConfigSession: function (oBundle) {
                const appDataModel = this.oContext.getOwnerComponent().getModel("appData");
                appDataModel.getData().oMyStorage.put(this._configName, oBundle);
                appDataModel.refresh();
            },

            _getCurrentConfigSession: function () {
                const appDataModel = this.oContext.getOwnerComponent().getModel("appData");
                if (appDataModel.getData().oMyStorage.get(this._configName) !== null) {
                    this._oBundle = appDataModel.getData().oMyStorage.get(this._configName);
                }
            },

            setPersData: function (oBundle) {
                this._saveCurrentConfigSession(oBundle);
                return TablePersoBaseService.prototype.setPersData.call(this, oBundle);
            },
        });
    }, /* bExport= */ true);
