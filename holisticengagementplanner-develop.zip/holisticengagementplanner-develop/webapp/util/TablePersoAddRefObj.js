sap.ui.define("com/sap/ui/hep/util/TablePersoAddRefObj",
    [
        "com/sap/ui/hep/util/TablePersoBaseService"
    ],
    function (TablePersoBaseService) {
        "use strict";

        const PersoService = TablePersoBaseService.extend("com.sap.ui.hep.util.TablePersoAddRefObj", {
            constructor: function () {
                TablePersoBaseService.call(this, "tablePerso-roSelectPopup.json");
            },
        });

        return new PersoService();
    }, /* bExport= */ true);
