/*eslint no-unused-expressions: [0, { "allowTernary": true }]*/
/*eslint max-params: ["error", 20]*/
/*eslint new-cap: ["error", { "newIsCap": false }]*/
sap.ui.define([
	"sap/gantt/simple/GanttPrinting",
	"sap/m/FlexBox",
	"sap/m/Label",
	"sap/m/library",
	"sap/m/RadioButton",
	"sap/m/RadioButtonGroup"
], function (GanttPrinting, FlexBox, Label, MobileLibrary, RadioButton, RadioButtonGroup) {
	"use strict";

	return GanttPrinting.extend("com.sap.ui.hep.util.CustomGanttPrinting", {
		metadata: {
			associations: {
				ganttChart: {
					type: "sap.gantt.simple.GanttChartWithTable",
					multiple: false
				}

			}
		},

		init: function () {
			GanttPrinting.prototype.init.call(this);
			this._oModel.getData().portrait = false;
			this._oModel.getData().paperWidth = GanttPrinting._oPaperSizes.A4.height;
			this._oModel.getData().paperHeight = GanttPrinting._oPaperSizes.A4.width;
			this._oModel.refresh();
		},

		_savePdf: function () {

			if (!this._validateFields()) {
				return;
			}

			let sOrientation = this._oModel.getProperty("/portrait") ? "p" : "l",
				fPaperWidth = this._oModel.getProperty("/paperWidth"),
				fPaperHeight = this._oModel.getProperty("/paperHeight"),
				bExportAsJPEG = this._oModel.getProperty("/exportAsJPEG"),
				fCompressionQuality = this._oModel.getProperty("/compressionQuality") / 100,
				sPaperSize = this._oModel.getProperty("/paperSize");

			let oPdf = new window.jsPDF({
				orientation: sOrientation,
				unit: "px",
				format: sPaperSize === "Custom" ? [fPaperWidth * 0.75, fPaperHeight * 0.75] : sPaperSize.toLowerCase()
			});

			let aPages = this._pageToBeExported();
			for (let i = 0; i < aPages.length; i++) {
				let oCanvas = this._getCanvasOfPageN(aPages[i], true);

				if (!oCanvas) {
					continue;
				}

				if (i !== 0) {
					oPdf.addPage();
				}

				if (bExportAsJPEG) {
					oPdf.addImage(oCanvas.toDataURL("image/jpeg", fCompressionQuality), "JPEG", 0, 0);
				} else {
					oPdf.addImage(oCanvas.toDataURL("image/png"), "PNG", 0, 0);
				}

			}

			let oDate = new Date();
			let sPdfTitle = this._oBundle.getText("Gantt.Download.Internal") + " - " + this._oBundle.getText("Gantt.Download.SectionName");
			oPdf.save(`${sPdfTitle}` + oDate.toISOString() + ".pdf");
		},

		_createOptionsForm: function () {
			if (this.getGanttChart() !== null) {
				this._oBundle = sap.ui.getCore().byId(this.getGanttChart()).getModel("i18n").getResourceBundle();
				let oColumns = this._ganttChartClone.getAggregation("table").getColumns();
				let oActionCol = oColumns.find(elm => elm.getLabel().getProperty("text").includes("Actions"));
				oActionCol?.setVisible(false);
				this._oModel.getData().headerText = this._oBundle.getText("Gantt.Download.Internal");
				this._oModel.getData().showHeaderText = true;
				this._oModel.refresh();
			}

			let oOptionsForm = new FlexBox({
				renderType: "Bare",
				direction: MobileLibrary.FlexDirection.Column,
				items: [
					new Label({
						text: this._oRb.getText("GNT_PRNTG_EXPORT_TYPES")
					}),
					new RadioButtonGroup({
						columns: 2,
						selectedIndex: this._oModel.getProperty("/multiplePage") ? 0 : 1,
						select: this._onChangeExportTypes.bind(this),
						buttons: [
							new RadioButton({
								id: "Multiple",
								text: this._oRb.getText("GNT_PRNTG_MULTIPLE_PAGE"),
								selected: "{setting>/multiplePage}"
							}),
							new RadioButton({
								id: "Single",
								text: this._oRb.getText("GNT_PRNTG_SINGLE_PAGE")
							})
						]
					}).addStyleClass("sapGanttPrintingBottomMargin"),
					new Label({
						text: this._oRb.getText("GNT_PRNTG_ORIENTATION")
					}),
					new RadioButtonGroup({
						columns: 2,
						selectedIndex: this._oModel.getProperty("/portrait") ? 0 : 1,
						select: this._onChangeOrientation.bind(this),
						buttons: [
							new RadioButton({
								id: "Portrait",
								text: this._oRb.getText("GNT_PRNTG_PORTRAIT"),
								selected: "{setting>/portrait}"
							}),
							new RadioButton({
								id: "Landscape",
								text: this._oRb.getText("GNT_PRNTG_LANDSCAPE")
							})
						]
					}).addStyleClass("sapGanttPrintingBottomMargin"),
					new Label({
						text: this._oRb.getText("GNT_PRNTG_PAPER_SIZE")
					}),
					this._createPaperComboBox(),
					this._createPaperSizeFields().addStyleClass("sapGanttPrintingBottomMargin"),

					new Label({
						text: this._oBundle.getText("Gantt.Download.DurationLabel"),
						wrapping: true
					}),
					this._createDurationComboBox(),
					this._createDatePicker().addStyleClass("sapGanttPrintingBottomMargin"),

					new Label({
						text: this._oRb.getText("GNT_PRNTG_SCALE"),
						visible: "{setting>/multiplePage}"
					}),
					this._createScale().addStyleClass("sapGanttPrintingBottomMargin"),

					new Label({
						text: this._oRb.getText("GNT_PRNTG_PAGE_RANGE"),
						visible: "{setting>/multiplePage}"
					}),
					this._createPageRange().addStyleClass("sapGanttPrintingBottomMargin"),

					new Label({
						text: this._oRb.getText("GNT_PRNTG_HEADER_AND_FOOTER")
					}),
					// this._createCheckBoxWithInput(this._oRb.getText("GNT_PRNTG_HEADER"), "{setting>/showHeaderText}", "{setting>/headerText}"),
					this._createCheckBoxWithInput(this._oRb.getText("GNT_PRNTG_FOOTER"), "{setting>/showFooterText}", "{setting>/footerText}").addStyleClass(
						"sapGanttPrintingBottomMargin"),

					this._createLabelWithSwitch(this._oRb.getText("GNT_PRNTG_SHOW_PAGE_NUMBER"), "{setting>/showPageNumber}").addStyleClass(
						"sapGanttPrintingBottomMargin"),

					this._createPanel(this._oRb.getText("GNT_PRNTG_MARGIN"), this._createMargin()),

					this._createPanel(this._oRb.getText("GNT_PRNTG_COMPRESSION"), this._createCompression())
				]
			});
			return oOptionsForm;
		}

	});
});