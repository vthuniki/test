sap.ui.define([
	"sap/base/security/URLListValidator",
	"com/sap/ui/hep/reuse/Constants"

], function (URLListValidator, Constants) {
	"use strict";

	return {
		/*
		Adds the url to list of valid URL patterns. The reason is the flppluginoperations-web which introduced a pattern for URL validation.
		If at least one such pattern is available, all pure-HTML ulrs will be checked, which happens in FLP test environemt and prod. 
		Since additional contracts (>1) in Engagement Scope are created as HTML they are affected by this change. 
		*/
		initValidUrl: function (oContext) {
			const sEnv = Constants.getEnvironment();

			switch (sEnv) {
				case "dev":
					URLListValidator.add("https", "icd.wdf.sap.corp");
					break;
				case "test":
					URLListValidator.add("https", "ict.wdf.sap.corp");
					break;
				case "prod":
					URLListValidator.add("https", "icp.wdf.sap.corp");
					break;
				default:
					return;
			}
		}
	};
});