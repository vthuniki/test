sap.ui.define([

], function () {
	"use strict";

	return sap.m.ColumnListItem.extend("com.sap.ui.hep.util.CustomColumnListItem", {
		metadata: {
			properties: {
				"useable": {
					type: "boolean",
					defaultValue: true
				}

			}
		},

		renderer: function (oRm, oControl) {
			sap.m.ColumnListItemRenderer.render(oRm, oControl); //use superclass renderer routine
		},

		isSelectable: function (bValue) {
			return this.getUseable();
		}

	});
});