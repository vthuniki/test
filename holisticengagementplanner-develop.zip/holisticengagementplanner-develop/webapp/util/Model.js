/*eslint-env es6*/
sap.ui.define([
	"com/sap/ui/hep/reuse/Constants",
	"sap/ui/model/Sorter"
], function (Constants, ModelSorter) {
	"use strict";

	return {
		_readConstants: function () {
			return Constants;
		},

		/**
		 * SAPUI5 interprets that when there is a null value, null is greater than all other values
		 * This is adjusted below so that null is the smallest value when sorting
		 *
		 * @param {object} oContext the context from which the method is called
		 * @param {string} sSortItem the name of the property to sort on
		 * @param {string} sSortOrder the sort order: "asc" for ascendin or "desc" for descending
		 * @return {object} oSort the sorter
		 */
		createrSorter: function (oContext, sSortItem, sSortOrder) {
			let oSorter = new ModelSorter({
				path: sSortItem,
				descending: sSortOrder === "desc" ? true : false
			});
			oSorter.fnCompare = function (a, b) {
				if (a === b) {
					return 0;
				}
				if (b === null) {
					return 1;
				}
				if (a === null) {
					return -1;
				}
				if (typeof a === "string" && typeof b === "string") {
					return a.localeCompare(b, "nb");
				}
				if (a < b) {
					return -1;
				}
				if (a > b) {
					return 1;
				}
				return 0;
			};
			return oSorter;
		}
	};
});
