sap.ui.define([
	"com/sap/ui/hep/util/Validator",
	"com/sap/ui/hep/reuse/Constants",
	"com/sap/ui/hep/model/formatter",
	"sap/ui/core/syncStyleClass",
	"com/sap/ui/hep/util/MessageHandlingPopover",
	"sap/ui/model/odata/v2/ODataModel"
], function (Validator, Constants, Formatters, syncStyleClass, MessageHandlingPopover, ODataModel) {
	"use strict";

	return {
		formatter: Formatters,
		messages: MessageHandlingPopover,

		_configGridLayout1: {
				labelSpanXL: 4,
				labelSpanL: 4,
				labelSpanM: 12,
				labelSpanS: 12,
				adjustLabelSpan: false,
				emptySpanXL: 0,
				emptySpanL: 0,
				emptySpanM: 0,
				emptySpanS: 0,
				columnsXL: 2,
				columnsL: 2,
				columnsM: 1,
				singleContainerFullSize: false
		},

		_configGridLayout2: {
				labelSpanXL: 12,
				labelSpanL: 12,
				labelSpanM: 12,
				labelSpanS: 12,
				adjustLabelSpan: false,
				emptySpanXL: 0,
				emptySpanL: 0,
				emptySpanM: 0,
				emptySpanS: 0,
				columnsXL: 1,
				columnsL: 1,
				columnsM: 1,
				singleContainerFullSize: true
		},

		_createForm: function(aFormElementsRight, aFormElementsLeft, oView){
			return new sap.ui.layout.form.Form(oView.getController().createId("questionnaireForm"), {
				editable: true,
				layout: new sap.ui.layout.form.ResponsiveGridLayout(this._configGridLayout),
				formContainers: [
					new sap.ui.layout.form.FormContainer({
						formElements: aFormElementsRight
					}),
					new sap.ui.layout.form.FormContainer({
						formElements: aFormElementsLeft
					})
				]
			});

		},

		_createFormBottom: function(aFormElementsBottom, oView){
			return new sap.ui.layout.form.Form(oView.getController().createId("questionnaireFormBottom"), {
				editable: true,
				layout: new sap.ui.layout.form.ResponsiveGridLayout(this._configGridLayout2),
				formContainers: [
					new sap.ui.layout.form.FormContainer({
						formElements: aFormElementsBottom
					})
				]
			});
		},

		_createTestButton(oView){
			return new sap.m.Button({
				text: "Test Save Questionnaire - remove this button when the entire SO may be saved - this is just for test purposes",
				press: (oEvent) => {
					this._validateQuestionnaire(oEvent, oView);
				},
				// visible: bDevEnv
				visible: false
			});
		},

		_renderElements: function(oView, oTitle, oForm, oFormBottom){
			let oTestButton = this._createTestButton(oView);
			const validator = new Validator();

			oView.byId("questionnaire").addItem(oTitle);
			oView.byId("questionnaire").addItem(oForm);
			if (oFormBottom) {
				oView.byId("questionnaire").addItem(oFormBottom);
			}
			oView.byId("questionnaire").addItem(oTestButton);
			oView.byId("questionnaire").rerender();

			oView.getModel("oModelSO").getData().wizardQuestionnaireStepValid = validator.validateEntireForm(oView.byId("questionnaireForm"),
				true);
			oView.getModel("oModelSO").refresh();
		},

		_addFormElements: function(oView, oLayout){
			let formElementsRight = [],
				formElementsLeft = [];

			const iLength = Math.floor(oLayout.length / 2);
			$.each(oLayout, (iRow, oRow) => {
				if (iRow > 0) {
					let oFormElement = this._createQuestionnaireFormElement(oView, oRow, iRow);

					if (iRow <= iLength) {
						formElementsRight.push(oFormElement);
					} else {
						formElementsLeft.push(oFormElement);
					}
				}
			});

			return {formElementsLeft, formElementsRight};
		},

		createQuestionnaireLayout: function (oView, oLayout) {
			let oTitle,
				oTitleField = oLayout[0][0],
				oForm,
				oFormBottom,
				aFormElementsRight = [],
				aFormElementsLeft = [],
				aFormElementsBottom = [],
				aFormElementsBottomRaw = [],
				oFormElement;

			$.each(oLayout, (iRow, oRow) => {
				let elementsInRow = [];
				for (let i = 0; i < oRow.length; i++) {
					if (oRow[i] && oRow[i].FieldType === "E") {
						elementsInRow.push(oRow[i]);
						oRow.splice(i, 1);
						if (oRow.length === 0) {
							oLayout.splice(iRow, 1);
						}
					}
				}
				if (elementsInRow.length > 0) {
					aFormElementsBottomRaw.push(elementsInRow);
				}
			});

			$.each(aFormElementsBottomRaw, (iRow, oRow) => {
				oFormElement = this._createQuestionnaireFormElement(oView, oRow, iRow);
				aFormElementsBottom.push(oFormElement);
			});


			oTitle = new sap.m.Title({
				text: oTitleField.FieldContent
			});

			const {formElementsLeft, formElementsRight} = this._addFormElements(oView, oLayout);

			aFormElementsLeft.push(...formElementsLeft);
			aFormElementsRight.push(...formElementsRight);

			oLayout.push(...aFormElementsBottomRaw);

			oForm = this._createForm(aFormElementsRight, aFormElementsLeft, oView);

			if (aFormElementsBottom.length > 0) {
				oFormBottom = this._createFormBottom(aFormElementsBottom, oView);
			}

			this._renderElements(oView, oTitle, oForm, oFormBottom);


		},

		_createFormElement: function(oRow, oView, oField, bWithDetermination, oFieldsInARow){
			return new sap.ui.layout.form.FormElement({
				label: new sap.m.Label({
					text: oRow[0].FieldLabel,
					required: oView.getController()._displayMode ? false : {
						parts: [{
							path: "questionnaire>/results/" + oField.DeterminedBy.FieldRow + "/" + oField.DeterminedBy.FieldColumn +
								"/oMetadata/" + oField.DeterminedBy.FieldSelectionIndex + "/value"
						}],
						formatter: function (oSelectedValue) {
							return ((oRow[0].Mandatory && !bWithDetermination) || (bWithDetermination && oSelectedValue && oRow[0].Mandatory));
						}
					}
				}),
				fields: [
					new sap.m.HBox({
						justifyContent: sap.m.FlexJustifyContent.SpaceBetween,
						fitContainer: true,
						wrap: sap.m.FlexWrap.Wrap,
						items: [
							oFieldsInARow
						]
					})
				]
			});
		},

		_createFieldsInARow(oRow, oView, iRow){
			let fieldsInARow = [];

			$.each(oRow, (iField, oField) => {
				let oQuestionnaireField = oView.getController()._displayMode ?
					this._createQuestionnaireFieldDisplayMode(oView, oField, iRow, iField) :
					this._createQuestionnaireFieldEditMode(oView, oField, iRow, iField);
				if (oQuestionnaireField) {
					fieldsInARow.push(oQuestionnaireField);
				}
			});

			return fieldsInARow;
		},

		_createQuestionnaireFormElement: function (oView, oRow, iRow) {
			let oFormElement,
				oFieldsInARow = [];

			if (oRow !== undefined) {

				oFieldsInARow = this._createFieldsInARow(oRow, oView, iRow);

				let oField = oRow[0];
				let bValidDetermination = true;
				for (let property in oField.DeterminedBy) {
					if (oField.DeterminedBy[property] === "") {
						bValidDetermination = false;
					}
				}
				let bWithDetermination = (oField.DeterminedBy !== undefined && bValidDetermination);
				if (!bWithDetermination) {
					oField.DeterminedBy = {
						"FieldRow": "",
						"FieldColumn": "",
						"FieldSelectionIndex": ""
					};
				}

				oFormElement = this._createFormElement(oRow, oView, oField, bWithDetermination, oFieldsInARow);
			}
			return oFormElement;
		},

		fnHandleDiscardVHInput: function (oEvent, oContext) {
			oContext._oVHInput.destroyContent();
			oContext._oVHInput.close();
			oContext._oVHInput = undefined;
		},

		_generateFilterParams: function (aFilters) {
			return "(" + aFilters.join(" and ") + ")";
		},

		_handleCasePDisplayMode(oModel, oField){
			let sSelectedKey = oModel.getData().results[oField.layoutRow][oField.layoutColumn].FieldContent,
				oSelectedItemValue = sSelectedKey.length ? oField.oMetadata.find(elem => elem.key === sSelectedKey).value : "";
			return new sap.m.Text({
				text: oSelectedItemValue
			});
		},

		_handleCaseRDisplayMode(oModel, oField){
			let oMetadata = oField.oMetadata !== undefined ? oField.oMetadata : JSON.parse(oField.MetaData);
			let oFieldData = oMetadata.find(function (oRadioButtonItem, iRadioButton) {
				return JSON.parse(oModel.getData().results[oField.layoutRow][oField.layoutColumn]
					.oMetadata[
						iRadioButton].value);
			});
			let sSelectedRadioButtonLabel = !oFieldData ? "" : oFieldData.label;
			return new sap.m.Text({
				text: sSelectedRadioButtonLabel
			});
		},

		_handleCaseLDisplayMode: function(oField){

			let oMetadata,
				bWithDetermination = false;

			oMetadata = JSON.parse(oField.MetaData);
			bWithDetermination = oField.DeterminedBy !== undefined ? true : false;
			if (!bWithDetermination) {
				oField.DeterminedBy = {
					"FieldRow": "",
					"FieldColumn": "",
					"FieldSelectionIndex": ""
				};
			}

			return new sap.m.Link({
				target: "_blank",
				rel: "noopener noreferrer",
				enabled: $.isEmptyObject(oMetadata) ? false : true,
				href: this.__helperLinkBuildHref(oField, oMetadata),
				text: this.__helperLinkBuildText(oField)
			}).addStyleClass("customMarginTop");
		},

		__helperLinkBuildHref: function(oField, oMetadata){
			return {
				parts: [{
					path: "questionnaire>/results/" + oField.DeterminedBy.FieldRow + "/" + oField.DeterminedBy.FieldColumn +
						"/FieldContent"
				}],
				formatter: function (sSelectedItem) {
					let sUrl = $.isEmptyObject(oMetadata) ? "" : oMetadata[0].value,
						sUpdatedUrl = sUrl;
					if (sUrl.length && typeof sSelectedItem !== "object") {
						sUpdatedUrl = sUrl.split("crm-object-value")[0] + "crm-object-value=" + sSelectedItem;
					}
					return sUpdatedUrl;
				}
			};
		},

		__helperLinkBuildText: function(oField){
			return {
				parts: [{
					path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/FieldContent"
				}, {
					path: "questionnaire>/results/" + oField.DeterminedBy.FieldRow + "/" + oField.DeterminedBy.FieldColumn +
						"/Selection"
				}],
				mode: sap.ui.model.BindingMode.TwoWay,
				formatter: function (sCurrentValue, sSelectedValue) {
					return (sSelectedValue && typeof sSelectedValue !== "object") ? sSelectedValue : sCurrentValue;
				}
			}
		},


		_createQuestionnaireField: function(oModel, oField, sText){

			let oQuestionnaireField;

			/* Field type */
			switch (oField.FieldType) {
				// Picklist - key-value pairs
			case "P":
				oQuestionnaireField = this._handleCasePDisplayMode(oModel, oField);
				break;
				// Radio button	- key-value pairs
			case "R":
				oQuestionnaireField = this._handleCaseRDisplayMode(oModel, oField);
				break;
				// Link	- key-value pairs - this is display-only
			case "L":
				oQuestionnaireField = this._handleCaseLDisplayMode(oField);
				break;
			default:
				oQuestionnaireField = new sap.m.Text({
					text: sText
				});
			}

			return oQuestionnaireField;
		},

		_createQuestionnaireFieldDisplayMode: function (oView, oField, iRow, iField) {
			let oModel = oView.getModel("questionnaire"),
				oQuestionnaireField,
				sText = oField.FieldType === "E" ? oField.FieldContent : oModel.getData().results[oField.layoutRow][oField.layoutColumn].FieldContent;

			oQuestionnaireField = this._createQuestionnaireField(oModel, oField, sText);

			oQuestionnaireField.addStyleClass("sapUiSmallMarginEnd customPaddingTop"); //sapUiMediumNegativeMarginBeginEnd
			return sText.length ? oQuestionnaireField : null;
		},

		_handleCasePEditMode: function(oField, oModel, oView){
			return new sap.m.ComboBox({
				tooltip: oField.Tooltip,
				change: (oEvent) => {
					this._handleTextFieldLiveChange(oEvent, oField, oModel, oView);
				},
				selectedKey: {
					path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/FieldContent",
					mode: sap.ui.model.BindingMode.TwoWay
				},
				valueStateText: oView.getController().getResourceBundle().getText("Questionnaire.MandatoryFieldError.ComboBox"),
				valueState: {
					parts: [{
						path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/bValueStateError"
					}],
					formatter: function (bValueStateError) {
						return bValueStateError ? sap.ui.core.ValueState.Error : sap.ui.core.ValueState.None;
					}
				}
			});
		},

		_handleCaseIEditMode(oField, oModel, oView, iFieldLength){
			let bValueHelp = false,
				bWithDetermination = oField.DeterminedBy !== undefined ? true : false;

			if (!bWithDetermination) {
				oField.DeterminedBy = {
					"FieldRow": "",
					"FieldColumn": "",
					"FieldSelectionIndex": ""
				};
			}
			let oMetadata = {};
			if (oField.MetaData) {
				oMetadata = $.isEmptyObject(oField.oMetadata) ? JSON.parse(oField.MetaData)[0] : oField.oMetadata;
				if (oMetadata) {
					bValueHelp = true;
				}
			}
			oField.oMetadata = oMetadata;

			return new sap.m.Input({
				tooltip: oField.Tooltip,
				maxLength: iFieldLength,
				value: {
					path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/FieldContent",
					mode: sap.ui.model.BindingMode.TwoWay
				},
				liveChange: (oEvent) => {
					this._handleTextFieldLiveChange(oEvent, oField, oModel, oView);
				},
				showValueHelp: bValueHelp,
				valueHelpRequest: (oEvent) => {
					this._handleInputFieldLoadVH(oEvent, oView.getController(), oMetadata, oField);
				},
				valueStateText: oView.getController().getResourceBundle().getText("Questionnaire.MandatoryFieldError.Input"),
				valueState: {
					parts: [{
						path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/bValueStateError"
					}],
					formatter: function (bValueStateError) {
						return bValueStateError ? sap.ui.core.ValueState.Error : sap.ui.core.ValueState.None;
					}
				},
				enabled: {
					parts: [{
						path: "questionnaire>/results/" + oField.DeterminedBy.FieldRow + "/" + oField.DeterminedBy.FieldColumn +
							"/oMetadata/" + oField.DeterminedBy.FieldSelectionIndex + "/value"
					}],
					formatter: function (oSelectedValue) {
						return ((bWithDetermination && oSelectedValue) || !bWithDetermination) === true;
					}
				}
			});

		},

		_handleCaseCEditMode: function(oField){
			return new sap.m.CheckBox({
				tooltip: oField.Tooltip,
				selected: {
					path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/FieldContent",
					mode: sap.ui.model.BindingMode.TwoWay
				},
				valueState: oField.bValueStateError ? sap.ui.core.ValueState.Error : sap.ui.core.ValueState.None
			});
		},

		_handleCaseREditMode: function(oField, oModel, oView){
			let oRadioButton,
				bIsSelected = false,
				oMetadata = oField.oMetadata !== undefined ? oField.oMetadata : JSON.parse(oField.MetaData),
				oQuestionnaireField = new sap.m.RadioButtonGroup({}),
				bWithDetermination = oField.DeterminedBy !== undefined;

			if (!bWithDetermination) {
				oField.DeterminedBy = {
					"FieldRow": "",
					"FieldColumn": "",
					"FieldSelectionIndex": ""
				};
			}

			$.each(oMetadata, (iRadioButton, oRadioButtonFromJSON) => {
				oRadioButton = new sap.m.RadioButton({
					text: {
						path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/" +
							"oMetadata/" + iRadioButton + "/label"
					},
					groupName: oField.sFieldName,
					selected: {
						path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/" +
							"oMetadata/" + iRadioButton + "/value"
					},
					select: (oEvent) => {
						this._handleRadioSelection(oEvent, oField, oModel, oView);
					},
					enabled: {
						parts: [{
							path: "questionnaire>/results/" + oField.DeterminedBy.FieldRow + "/" + oField.DeterminedBy.FieldColumn +
								"/oMetadata/" + oField.DeterminedBy.FieldSelectionIndex + "/value"
						}],
						formatter: function (oSelectedValue) {
							return ((bWithDetermination && oSelectedValue) || !bWithDetermination) === true;
						}
					}
				});
				oQuestionnaireField.insertButton(oRadioButton, iRadioButton);
				if (!bIsSelected) {
					bIsSelected = JSON.parse(oModel.getData().results[oField.layoutRow][oField.layoutColumn].oMetadata[iRadioButton].value);
				}
			});
			if (!bIsSelected) {
				oQuestionnaireField.setSelectedIndex(-1);
			}

			oQuestionnaireField.setProperty("columns", oMetadata.length);

			return oQuestionnaireField;
		},

		_handleCaseLEditMode: function(oField){
			let oMetadata = JSON.parse(oField.MetaData),
				bWithDetermination = oField.DeterminedBy !== undefined ? true : false;

			if (!bWithDetermination) {
				oField.DeterminedBy = {
					"FieldRow": "",
					"FieldColumn": "",
					"FieldSelectionIndex": ""
				};
			}

			return new sap.m.Link({
				tooltip: oField.Tooltip === "" ? oField.FieldContent : oField.Tooltip,
				target: "_blank",
				rel: "noopener noreferrer",
				enabled: !$.isEmptyObject(oMetadata),
				href: this.__helperLinkBuildHref(oField, oMetadata),
				text: this.__helperLinkBuildText(oField)
			});
		},

		_handleCaseAEditMode: function(oField, oModel, oView, iFieldLength){
			let bWithDetermination = oField.DeterminedBy !== undefined;

			if (!bWithDetermination) {
				oField.DeterminedBy = {
					"FieldRow": "",
					"FieldColumn": "",
					"FieldSelectionIndex": ""
				};
			}

			return new sap.m.TextArea({
				tooltip: oField.Tooltip,
				maxLength: iFieldLength,
				showExceededText: true,
				rows: 6,
				growing: true,
				growingMaxLines: 6,
				cols: 30,
				width: "25rem",
				
				value: {
					path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/FieldContent",
					mode: sap.ui.model.BindingMode.TwoWay
				},
				
				valueState: {
					parts: [{
						path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/bValueStateError"
					}],
					formatter: function (bValueState) {
						return bValueState ? sap.ui.core.ValueState.Error : sap.ui.core.ValueState.None;
					}
				},

				valueStateText: oView.getController().getResourceBundle().getText("Questionnaire.MandatoryFieldError.TextArea"),
				
				liveChange: (oEvent) => {
					this._handleTextFieldLiveChange(oEvent, oField, oModel, oView);
				},

				enabled: {
					parts: [{
						path: "questionnaire>/results/" + oField.DeterminedBy.FieldRow + "/" + oField.DeterminedBy.FieldColumn +
							"/oMetadata/" + oField.DeterminedBy.FieldSelectionIndex + "/value"
					}],
					formatter: function (oSelectedValue) {
						return ((bWithDetermination && oSelectedValue) || !bWithDetermination) === true;
					}
				}
			});
		},

		_handleCaseDEditMode: function(oField, oModel, oView){
			let bWithDetermination = oField.DeterminedBy !== undefined;
			if (!bWithDetermination) {
				oField.DeterminedBy = {
					"FieldRow": "",
					"FieldColumn": "",
					"FieldSelectionIndex": ""
				};
			}

			return new sap.m.DatePicker({
				tooltip: oField.Tooltip,
				width: oField.sFieldWidth,
				valueFormat: "medium",
				change: (oEvent) => {
					this._handleTextFieldLiveChange(oEvent, oField, oModel, oView);
				},
				value: {
					path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/FieldContent",
					mode: sap.ui.model.BindingMode.TwoWay
				},
				enabled: {
					parts: [{
						path: "questionnaire>/results/" + oField.DeterminedBy.FieldRow + "/" + oField.DeterminedBy.FieldColumn +
							"/oMetadata/" + oField.DeterminedBy.FieldSelectionIndex + "/value"
					}],
					formatter: function (oSelectedValue) {
						return ((bWithDetermination && oSelectedValue) || !bWithDetermination) === true;
					}
				},
				valueStateText: oView.getController().getResourceBundle().getText("Questionnaire.MandatoryFieldError.DatePicker"),
				valueState: {
					parts: [{
						path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/bValueStateError"
					}, {
						path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/FieldContent"
					}],
					formatter: function (bValueStateError, sFieldContent) {
						return bValueStateError ? sap.ui.core.ValueState.Error : sap.ui.core.ValueState.None;
					}
				}
			});
		},

		_createQuestionnaireFieldEditMode: function (oView, oField, iRow, iField) {
			let oModel = oView.getModel("questionnaire"),
				oQuestionnaireField,
				iFieldLengthFromBE = parseInt(oField.Length, 10),
				iFieldLength = iFieldLengthFromBE;

			/* Field type */
			switch (oField.FieldType) {
				// Picklist - key-value pairs
			case "P":
				let oItemTemplate = new sap.ui.core.ListItem({
					key: {
						path: "questionnaire>key",
						mode: sap.ui.model.BindingMode.TwoWay
					},
					text: {
						path: "questionnaire>value",
						mode: sap.ui.model.BindingMode.TwoWay
					}
				});

				oQuestionnaireField = this._handleCasePEditMode(oField, oModel, oView);

				oQuestionnaireField.bindItems("questionnaire>/results/" + oField.layoutRow +
					"/" + oField.layoutColumn + "/oMetadata", oItemTemplate);

				break;
				// Input field
			case "I":
				oQuestionnaireField = this._handleCaseIEditMode(oField, oModel, oView, iFieldLength);
				oQuestionnaireField.setEnabled();
				break;
				// Checkbox	- key-value pairs
			case "C":
				oQuestionnaireField = this._handleCaseCEditMode(oField);
				break;
				// Radio button	- key-value pairs
			case "R":
				oQuestionnaireField = this._handleCaseREditMode(oField, oModel, oView);
				break;
				// Link	- key-value pairs - this is display-only
			case "L":
				oQuestionnaireField = this._handleCaseLEditMode(oField);
				break;
				// Text	- this is display-only
			case "T":
				oQuestionnaireField = new sap.m.Text({
					tooltip: oField.Tooltip,
					width: oField.sFieldWidth,
					text: {
						path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/FieldContent",
						mode: sap.ui.model.BindingMode.TwoWay
					}
				});
				break;
				// Text area -
			case "A":
				oQuestionnaireField = this._handleCaseAEditMode(oField, oModel, oView, iFieldLength);
				break;
				// Date picker
			case "D":
				oQuestionnaireField = this._handleCaseDEditMode(oField, oModel, oView)
				break;
				// Text area full width
			case "E":
				oQuestionnaireField = this._createTextArea(oField, iFieldLength, oModel, oView, this._getMaxElementWidth(oView), 90);
				oView.getModel("device").getData().resize.attachHandler(function () {
					oQuestionnaireField.setWidth(this._getMaxElementWidth(oView));
				}.bind(this));
				break;
			default:
				oQuestionnaireField = null;
			}

			if (oQuestionnaireField) {
				oQuestionnaireField.addStyleClass("sapUiSmallMarginEnd");
			}
			return oQuestionnaireField;
		},

		_getMaxElementWidth: function (oView) {
			let _iWidth = oView.getModel("device").getData().resize.width;
			if (_iWidth > 1550) {
				return "92rem";
			} else if (_iWidth > 1130) {
				return "65rem";
			} else {
				return "46rem";
			}
		},

		_createTextArea: function (oField, iFieldLength, oModel, oView, sWidth, iGrowingMaxLines) {
			let bWithDetermination = oField.DeterminedBy !== undefined;
			if (!bWithDetermination) {
				oField.DeterminedBy = {
					"FieldRow": "",
					"FieldColumn": "",
					"FieldSelectionIndex": ""
				};
			}
			let oQuestionnaireField = new sap.m.TextArea({
				tooltip: oField.Tooltip,
				maxLength: iFieldLength,
				showExceededText: true,
				rows: 6,
				growing: true,
				growingMaxLines: iGrowingMaxLines ? iGrowingMaxLines : 6,
				cols: 30,
				width: sWidth,
				
				enabled: {
					parts: [{
						path: "questionnaire>/results/" + oField.DeterminedBy.FieldRow + "/" + oField.DeterminedBy.FieldColumn +
							"/oMetadata/" + oField.DeterminedBy.FieldSelectionIndex + "/value"
					}],
					formatter: function (oSelectedValue) {
						return ((bWithDetermination && oSelectedValue) || !bWithDetermination) === true;
					}
				},
				
				value: {
					path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/FieldContent",
					mode: sap.ui.model.BindingMode.TwoWay
				},
				
				valueStateText: oView.getController().getResourceBundle().getText("Questionnaire.MandatoryFieldError.TextArea"),
				
				liveChange: (oEvent) => {
					this._handleTextFieldLiveChange(oEvent, oField, oModel, oView);
				},

				valueState: {
					parts: [{
						path: "questionnaire>/results/" + oField.layoutRow + "/" + oField.layoutColumn + "/bValueStateError"
					}],
					formatter: function (bValueStateError) {
						return bValueStateError ? sap.ui.core.ValueState.Error : sap.ui.core.ValueState.None;
					}
				}
			});

			return oQuestionnaireField;
		},

		// ============================================ Validations ============================================================

		_filterItemsForRadioButtons: function(oModel, oField){
			return oModel.getData().results.filter(function (row) {
				let filteredRow = row.filter(function (elem) {
					let aReferences = oField.oMetadata[0].reference ? oField.oMetadata[0].reference : oField.oMetadata[1].reference;
					let oItemMatch = null;
					$.each(aReferences.split(","), function (iSplittedItem, oSplittedItem) {
						if (oSplittedItem === elem.FieldName) {
							oItemMatch = oSplittedItem;
						}
					});
					return oItemMatch;
				});
				return filteredRow.length ? filteredRow : null;
			}).filter(itemReturned => itemReturned !== null);
		},

		_handleRadioSelection: function (oEvent, oField, oModel, oView) {
			oEvent.getSource().getParent().setSelectedButton(oEvent.getSource());
			let bYesSelected = oEvent.getSource().getText() === "Yes";

			// set value State of dependend Text-Fields
			let items = this._filterItemsForRadioButtons(oModel, oField);
			let aReferencedFields = items;
			aReferencedFields.forEach(function (oReference) {
				let oReferencedField = oReference[0];
				oReferencedField.bValueStateError = bYesSelected && oReferencedField.Mandatory && !oReferencedField.FieldContent;
			});
			oModel.refresh();
			
			// validate everything again
			let validator = new Validator();
			oView.getModel("oModelSO").getData().wizardQuestionnaireStepValid = validator.validateEntireForm(oView.byId("questionnaireForm"),
				true);
			oView.getModel("oModelSO").refresh();
		},

		_handleTextFieldLiveChange: function (oEvent, oField, oModel, oView) {
			oField.bValueStateError = !oEvent.getParameter("newValue") && oField.Mandatory;
			oModel.refresh();

			let validator = new Validator();
			oView.getModel("oModelSO").getData().wizardQuestionnaireStepValid = validator.validateEntireForm(oView.byId("questionnaireForm"), true);
			oView.getModel("oModelSO").refresh();
		},

		_validateQuestionnaire: function (oEvent, oView) {
			let validator = new Validator();
			validator.validateAndHighlightMissingMandatoryFields(oView.byId("questionnaireForm"), oView.getController().getModel("questionnaire"),
				oView.getController(), true);

			if (validator.isValid()) {
				this._saveQuestionnaire(oEvent, oView);
			}
		},

		// ============================================== Save =================================================================

		_updateQuestionnaire: function(oModelQuestionnaire, oView0, oBModel){

			let oPayload = {},
				sBatchIndividualUrl;

			oModelQuestionnaire.forEach(function (oRow) {
				let oView1 = oView0;
				oRow.forEach(function (oField) {
					let oView2 = oView1;
					oPayload = {
						"FieldName": oField.FieldName,
						"FieldContent": oField.FieldContent
					};
					if (oField.oMetadata && Object.entries(oField.oMetadata).length !== 0) {
						if (oField.FieldType === "R") {
							$.each(oField.oMetadata, function (iIndex, oItem) {
								if (oItem.value === true) {
									oPayload.FieldContent = oItem.key;
								}
							});
						}
					}
					sBatchIndividualUrl = "/" + "QuestionnaireSet(guid'" + oView2.getModel("oModelSO").getData().SoGUID + "')";
					oBModel.update(sBatchIndividualUrl, oPayload, {
						groupId: "groupSetId"
					});
				});
			});
		},

		_saveQuestionnaire: function (oEvent, oView) {
			let oModel = oView.getModel("questionnaire"),
				oModelQuestionnaire = oModel.getData().results;

			let myServiceUrl = Constants.getServicePath();
			let oBModel = new ODataModel(myServiceUrl, {
				defaultUpdateMethod: sap.ui.model.odata.UpdateMethod.Put
			});
			this._updateQuestionnaire(oModelQuestionnaire, oView, oBModel);

			oBModel.setDeferredGroups(["groupSetId"]);
			oBModel.submitChanges({
				groupId: "groupSetId",
				success: function (oData) {
					if (oData.__batchResponses[0].response.statusCode === "500") {
						oView.getController().messages.addNewMessageseInsidePopover("prodID",
							"Error",
							"The questionnaire could not be saved",
							JSON.parse(oData.__batchResponses[0].response.body).error.message.value,
							"Questionnaire",
							oView.getController());
					}
				}
			});
		},

		// ============================================== VH Create ============================================================

		_handleInputFieldLoadVH: function (oEvent, oContext, oMetadata, oField) {
			if (!oContext._oVHInput) {
				try {
					oContext._oVHInput = this._createVHInput(oEvent, oContext, oMetadata, oField);
					oContext._oVHInput.setModel(oContext.getModel("i18n"), "i18n");
					oContext._oVHInput.setModel(oContext.getView().getModel("localModel"));
					oContext.getView().addDependent(oContext._oVHInput);
					syncStyleClass(oContext.getView().getController().getOwnerComponent().getContentDensityClass(),
						oContext.getView(), oContext._oVHInput);
					oContext._oVHInput.open();
					this._searchVHInput(oEvent, oMetadata, oField, oContext);
				} catch (oError) {
					if (oError.statusCode === 503) {
						let oView = oContext.getView();
						let params = {
							currentView: oView
						};
						oContext.handleSessionTimeout(params, oContext);
					}
				}
			} else {
				oContext._oVHInput.open();
			}
		},

		_createVHInput: function (oEvent, oContext, oNewMetadata, oField, bValueHelpWithTreeResponse) {
			let oFilterGroupItem,
				oFilterGroupItems = [],
				oCell,
				oCells = [],
				oColumn,
				oColumns = [],
				oColumnTree,
				oColumnsTree = [],
				bIsTree = false;

			let oMetadata = oNewMetadata[0];
			if (oMetadata.fields.filter(item => item.name === "Parent Component").length) {
				bIsTree = true;
			}

			oContext.getModel("localModel").getData().questionnaireVHInput = oMetadata;
			oContext.getModel("localModel").refresh();

			$.each(oMetadata.fields, (iItem, oItem) => {
				if (oItem.name !== "Parent Component") {
					oFilterGroupItem = this._createFilterGroupItem(iItem, oItem.name, oContext);
					oFilterGroupItems.push(oFilterGroupItem);

					oCell = this._createCell(oItem.name);
					oCells.push(oCell);

					oColumn = this._createColumn(oItem.name);
					oColumns.push(oColumn);

					oColumnTree = this._createColumnTree(oItem.name);
					oColumnsTree.push(oColumnTree);
				}
			});

			let oFilterBar = this._createFilterBar(oFilterGroupItems, oMetadata, oField, oContext);
			let oTable = this._createTable(oContext, oField, oCells, oColumns);
			let oTreeTable = this._createTreeTable(oContext, oField, oColumnsTree);

			let oDialog = new sap.m.Dialog({
				title: oMetadata.title,
				draggable: true,
				resizable: true,
				contentWidth: (oMetadata.fields.length * 20) + "rem",
				content: [
					new sap.m.VBox({})
				],
				endButton: new sap.m.Button({
					text: "{i18n>Cancel}",
					press: (oEventPress) => {
						this.fnHandleDiscardVHInput(oEventPress, oContext);
					}
				})
			});

			let oTableType = bIsTree ? oTreeTable : oTable;
			oDialog.getContent()[0].addItem(oFilterBar);
			oDialog.getContent()[0].addItem(oTableType);
			oDialog.setModel(oContext.getView().getModel("localModel"));
			oContext.setModel(oContext.getView().getModel("localModel"));
			oDialog.setModel(oContext.getView().getModel("localModel"), "localModel");
			oDialog.setModel(oContext.getView().getModel("questionnaire"), "questionnaire");
			oContext.getView().addDependent(oDialog);
			return oDialog;
		},

		_createCell: function (sName) {
			let oCell = new sap.m.Text({
				text: {
					path: "localModel>" + sName,
					mode: sap.ui.model.BindingMode.TwoWay
				}
			});
			return oCell;
		},

		_createColumn: function (sName) {
			let oColumn = new sap.m.Column({
				header: [
					new sap.m.Label({
						text: sName
					})
				]
			});
			return oColumn;
		},

		_createColumnTree: function (sName) {
			let oColumnTree = new sap.ui.table.Column({
				label: sName,
				template: [
					new sap.m.Text({
						text: {
							path: "localModel>" + sName
						}
					})
				]
			});
			return oColumnTree;
		},

		_createFilterBar: function (oFilterGroupItems, oMetadata, oField, oContext) {
			let oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				showFilterConfiguration: false,
				useToolbar: false,
				filterGroupItems: oFilterGroupItems,
				search: (oEventSearch) => {
					this._searchVHInput(oEventSearch, oMetadata, oField, oContext);
				}
			});
			return oFilterBar;
		},

		_createFilterGroupItem: function (iItem, sName, oContext) {
			let oFilterGroupItem = new sap.ui.comp.filterbar.FilterGroupItem({
				groupName: "VHInput",
				groupTitle: "VHInput",
				name: sName,
				label: sName,
				labelTooltip: sName,
				visibleInFilterBar: true,
				control: new sap.m.Input({
					value: {
						path: "localModel>/questionnaireVHInput/fields/" + iItem + "/value",
						mode: sap.ui.model.BindingMode.TwoWay
					},
					enabled: true
				})
			});
			return oFilterGroupItem;
		},

		_createTable: function (oContext, oField, oCells, oColumns) {
			let oTemplate = new sap.m.ColumnListItem({
				cells: oCells
			});
			let oTable = new sap.m.Table({
				mode: sap.m.ListMode.SingleSelectMaster,
				selectionChange: (oEventSelectionChange) => {
					this._handleVHInputItemPress(oEventSelectionChange, oContext, oField);
				},
				columns: oColumns,
				items: {
					path: "{localModel>/questionnaireVHInput/results}",
					template: oTemplate
				}
			});
			let sPath = "localModel>/questionnaireVHInput/results";
			oTable.bindItems(sPath, oTemplate);

			return oTable;
		},

		_createTreeTable: function (oContext, oField, oColumnsTree) {
			let oTreeTable = new sap.ui.table.TreeTable({
				busy: {
					path: "{localModel>/busyVHInput}"
				},
				busyIndicatorDelay: 0,
				rowSelectionChange: (oTreeTableSelectionEvent) => {
					this._handleVHInputItemFromTreePress(oTreeTableSelectionEvent, oContext, oField);
				},
				selectionMode: sap.ui.table.SelectionMode.Single,
				selectionBehavior: sap.ui.table.SelectionBehavior.RowOnly,
				enableColumnReordering: false,
				columns: oColumnsTree,
				rows: {
					path: "localModel>/questionnaireVHInput/results",
					parameters: {
						arrayNames: ["Tree"]
					}
				}
			});
			return oTreeTable;
		},

		// ============================================== VH Search ============================================================

		_searchVHInput: function (oEventSearch, oMetadata, oField, oContext) {
			let entities = {},
				sFilters = "",
				oDataLocalModel = oContext.getModel("localModel").getData();
			$.each(oMetadata.fields, function (iItem, oItem) {
				if (oItem.value) {
					let sFilterValue = oDataLocalModel.questionnaireVHInput.fields[iItem].value;
					if (sFilters !== "") {
						sFilters += ", ";
					}
					sFilters += "{\"name\": \"" + oItem.name + "\", \"value\": \"" + sFilterValue + "\"}";
				}
			});
			oContext.getView().getModel("localModel").getData().busyVHInput = true;
			oContext.getView().getModel("localModel").refresh();
			entities.servicePath = Constants.getServicePath();

			entities.entitySet = "ValueHelpSet";
			entities.filter = "(";
			entities.filter += "Entity eq '" + oField.FieldName + "'";
			if (sFilters !== "") {
				entities.filter += " and Fields eq '[" + sFilters + "]'";
			}
			entities.filter += ")";

			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.busyIndicator = "busyVHInput";
			entities.callbackSuccess = (oData) => {
				this._handleSuccessVHInputSearch(oData, oField, oContext);
			};
			oContext.readBaseRequest(entities);
		},

		_handleSuccessVHInputSearch: function (oData, oField, oContext) {
			if (oData.results.length) {
				if (oField.oMetadata[0].fields.filter(item => item.name === "Parent Component").length) {
					let oJSONResponse = JSON.parse(oData.results[0].Results),
						oSortedFlatStructure = oJSONResponse.sort((a, b) =>
							a["Component Description"] === b["Component Description"] ? 0 :
							+(a["Component Description"] > b["Component Description"]) || -1),
						aTree = this._convertFlatDataIntoTreeStructure(oSortedFlatStructure);
					oContext.getView().getModel("localModel").getData().questionnaireVHInput.results = aTree;
					oContext.getView().getModel("localModel").refresh();
				} else {
					oContext.getView().getModel("localModel").getData().questionnaireVHInput.results = JSON.parse(oData.results[0].Results);
				}
			}
			oContext.getView().getModel("localModel").getData().busyVHInput = false;
			oContext.getView().getModel("localModel").refresh();
		},

		_convertFlatDataIntoTreeStructure: function (oFlatStructure) {
			let nodes = [],
				nodeMap = {},
				oCurrentNode,
				sParentId;

			oFlatStructure.forEach(function (oItem) {
				oCurrentNode = oItem;
				oCurrentNode.Tree = [];

				sParentId = oCurrentNode["Parent Component"];
				if (sParentId !== "XX") {
					let parent = nodeMap[oCurrentNode["Parent Component"]];
					if (parent) {
						parent.Tree.push(oCurrentNode);
					}
				} else {
					nodes.push(oCurrentNode);
				}
				let nodeNew = oCurrentNode["Component Name"];
				nodeMap[nodeNew] = oCurrentNode;
			});
			return nodes;
		},

		// ======================================== VH Result selection ========================================================

		_handleVHInputItemPress: function (oEvent, oContext, oField) {
			let oSource = oEvent.getSource(),
				sPath = oSource.getSelectedContextPaths(),
				iSelectedItemIndex = parseInt(sPath[0].split("/")[3], 10),
				oSelectedItemFromModel = oContext.getModel("localModel").getData().questionnaireVHInput.results[iSelectedItemIndex],
				sKey = oContext.getModel("localModel").getData().questionnaireVHInput.fields[0].name,
				oSelectedKey = oSelectedItemFromModel[sKey];

			// The VH selection is used for another field that depends on this VH-enriched field
			if (oField.oMetadata[0].hasOwnProperty("reference")) {
				if (oField.oMetadata[0].reference.length) {
					let oReferencedField = null;
					$.each(oContext.getView().getModel("questionnaire").getData().results, function (iRow, oRow) {
						$.each(oRow, function (iElem, oElem) {
							if (oElem.FieldName === oField.oMetadata[0].reference) {
								oReferencedField = oElem;
							}
						});
					});

					let sFirstField = oContext.getModel("localModel").getData().questionnaireVHInput.fields[1].name;
					let sSecondField = oContext.getModel("localModel").getData().questionnaireVHInput.fields[2].name;
					if (oSelectedItemFromModel.hasOwnProperty("Salutation")) {
						oField.Selection = oSelectedItemFromModel.Salutation + " ";
					}
					oField.Selection += oSelectedItemFromModel[sFirstField] + " " + oSelectedItemFromModel[sSecondField];
					oReferencedField.FieldContent = oField.Selection;
				}
			}
			oContext.getModel("questionnaire").getData().results[oField.layoutRow][oField.layoutColumn].FieldContent = oSelectedKey;
			oContext.getModel("questionnaire").refresh();
			this.fnHandleDiscardVHInput(oEvent, oContext);
		},

		_handleVHInputItemFromTreePress: function (oEvent, oContext, oField) {
			let oRowContext = oEvent.getParameter("rowContext"),
				sPath = oRowContext.getPath(),
				sSplit = sPath.split("/"),
				aSelectedChildren = [],
				oSelectedItemFromModel,
				sKey = oContext.getModel("localModel").getData().questionnaireVHInput.fields[1].name;

			for (let i = 0; i < sSplit.length / 2 - 1; i++) {
				let iSelectedItemChild = parseInt(sPath.split("/")[4 + i * 2 - 1], 10);
				aSelectedChildren.push(iSelectedItemChild);
			}

			oSelectedItemFromModel = oContext.getModel("localModel").getData().questionnaireVHInput.results;
			$.each(aSelectedChildren, function (iIndex, oChild) {
				oSelectedItemFromModel = (iIndex === aSelectedChildren.length - 1) ?
					oSelectedItemFromModel[oChild] : oSelectedItemFromModel[oChild].Tree;
			});
			let oSelectedKey = oSelectedItemFromModel[sKey];

			oContext.getModel("questionnaire").getData().results[oField.layoutRow][oField.layoutColumn].FieldContent = oSelectedKey;
			oContext.getModel("questionnaire").refresh();
			this.fnHandleDiscardVHInput(oEvent, oContext);
		},

		destroyQuestionnaire: function (oContext) {
			let oQuestionnaire = oContext.getView().byId("questionnaire");
			if (oQuestionnaire !== undefined) {
				oQuestionnaire.destroyItems();
			}
		}
	};
});
