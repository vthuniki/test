/*eslint complexity: [2, 50]*/
/*eslint max-params: [2, 12]*/
/*eslint-env es6*/
/*eslint no-unused-expressions: ["error", { "allowTernary": true }]*/
sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"com/sap/ui/hep/reuse/Constants"

], function (JSONModel, Constants) {
	"use strict";
	return {
		_readConstants: function () {
			return Constants;
		},

		dateForUIBasedOnUserOffset: function (sInitialDate) {
			let sDate = null,
				iUserOffset;
			if (sInitialDate) {
				iUserOffset = sInitialDate.getTimezoneOffset() * 60000;
				sDate = new Date(sInitialDate.getTime() + iUserOffset);
			}
			return sDate;
		},

		dateForBEBasedOnUserOffset: function (sInitialDate) {
			let sDate = null;
			if (sInitialDate) {
				let iUserOffset = sInitialDate.getTimezoneOffset() * 60000;
				sDate = new Date(sInitialDate.getTime() - iUserOffset);
			}
			return sDate;
		},
		/**
		 * All start dates should have 00:00:00 hours
		 * All end / qgate / go-live dates should have 23:59:59 hours
		 * Expected format: "2018-10-01T00:00:00", derived from Zulu format: "2018-08-30T22:00:00.000Z"
		 * @param {string} sDate The full text string date format to be converted in a suitable back-end format.
		 * @returns {string} The date in UTC (Zulu) format, but without the "Z" and the miliseconds at the end
		 */
		_convertDateToBEZuluFormat: function (sDate) {
			let sDateForBE = "";
			if (sDate === null) {
				sDateForBE = null;
			} else {
				let sDateWithUserOffset = this.dateForBEBasedOnUserOffset(sDate);
				sDateForBE = sDateWithUserOffset.toJSON().substring(0, 19);
			}
			return sDateForBE;
		},

		_convertDateToBEZuluFormatTemp: function (sDate) {
			let sDateForBE = "";
			if (sDate === null) {
				sDateForBE = null;
			} else {

				sDateForBE = sDate.toJSON().substring(0, 19);
			}
			return sDateForBE;
		},

		/**
		 * Expected format: "2018-10-01T00:00:00"
		 * e.g.: "2018-08-30T22:00:00.000Z"
		 *
		 * @param {object} sDate the date to be converted
		 * @param {string} typeOfdate the type of the date: start date / end date
		 * @return {string} sDateForBE the date converted in the format expected by the back-end
		 */
		_convertDateToBEFormat: function (sDate, typeOfdate) {

			if (sDate) {
				if (typeOfdate === "start") {
					sDate.setHours(0, 0, 0);
				}
				if (typeOfdate === "end") {
					sDate.setHours(23, 59, 59);
				}

			}
			// return sDateForBE;
			return sDate;
		},

		checkGreaterDate: function (sGreaterDate, sDate) {
			return sGreaterDate.toJSON().substring(0, 10) > sDate.toJSON().substring(0, 10);
		},

		compareTwoDates: function (dDateFirst, dDateSecond) {
			return dDateFirst - dDateSecond === 0;
		},

		convertDateIntoGivenFormat: function (dDate) {
			if (dDate) {
				let sDate = dDate.toDateString().substr(4, 20);
				return sDate.substr(4, 2) + "-" + sDate.substr(0, 3) + "-" + sDate.substr(7, 4);
			} else {
				return "";
			}
		},

		_createStringDate: function (date) {
			let sYMD = new Date(date).toISOString().slice(0, 10);
			let sYMDString = sYMD.split("-").join("");
			let sHMS = new Date(date).toLocaleTimeString("de-DE");
			let sHMSString = sHMS.split(":").join("");
			return sYMDString + sHMSString;
		},

		_formatDateFromString: function (sDate) {
			if (sDate && typeof sDate === "string") {
				if (sDate.trim() !== "0" && sDate.trim().length > 10) {
					let sDateSplit = sDate.match(/.{1,8}/g);
					let aYDM = sDateSplit[0];
					let aHMS = sDateSplit[1];

					let aYear = aYDM.match(/.{1,4}/g)[0];
					let aMonthDay = aYDM.match(/.{1,4}/g)[1].match(/.{2}/g);

					let aHourMinutesSeconds = aHMS.match(/.{2}/g);
					return new Date(aYear, aMonthDay[0] - 1, aMonthDay[1], aHourMinutesSeconds[0], aHourMinutesSeconds[1], aHourMinutesSeconds[2]);
				} else {
					return null;
				}
			} else {
				return null;
			}
		}

	};
});
