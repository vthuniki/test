sap.ui.define([
	"com/sap/ui/hep/model/formatter",
	"com/sap/ui/hep/util/Validator"
], function (Formatters, GenericValidator) {
	"use strict";
	return {
		formatter: Formatters,

		validateSoDataStepField: function (oSOModel, oContext) {
			let validator = new GenericValidator();
			validator.validateEntireForm(oContext.getView().byId("formServiceData"), false);
			oSOModel.getData().wizardDataStepValid = validator.isFormValid();
			oSOModel.refresh();
		}
	};
});
