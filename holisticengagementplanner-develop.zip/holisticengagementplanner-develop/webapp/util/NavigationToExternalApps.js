sap.ui.define([
	"com/sap/ui/hep/reuse/Constants",
	"sap/m/MessageBox"

], function (Constants, MessageBox) {

	return {

		_resourceBundle: new sap.ui.model.resource.ResourceModel({ bundleName: "com.sap.ui.hep.i18n.i18n" }).getResourceBundle(),
					
		_fnCFlpCrossAppNavigation: function(sShellHash){
			if (window.parent) {
				window.parent.postMessage(
					JSON.stringify({
						type: "request",
						service: "sap.ushell.services.CrossApplicationNavigation.toExternal",
						body: {
					  		oArgs: {
								target: {
									shellHash : sShellHash //"sap-ushell-navmode" "explace",  add this param if the navigation target should be opened in a new tab
								},						   				
					  		},
						},
				  	}), 
					location?.ancestorOrigins[0]
				);
			}
		},
		
		//Generic function for link navigation
		fnHandleLinkNavigation: function (sUrl) {
			window.open(sUrl, "_blank", "noopener,noreferrer");
		},

		//Navigation to the PEA App (ActivityEdit, ActivityDisplay, ActivitySearch, ActivityCreate)
		fnNavigateToPeActivityApp: function (oContext, sId, sActivityAction) {
			oContext._oData.busyIndicatorProjects = true;
			oContext._oModel.refresh();

			if (location.href.includes("applicationstudio.cloud.sap")){
				//during BAS there is no PEA. So we use navigation then dev-launchpad-app 
				let sUrl = Constants.getPeActivityDevWorkzoneUrl() + sActivityAction;
				sUrl = sId ? sUrl + "/" + sId : sUrl;
				this.fnHandleLinkNavigation(sUrl);
			} else {
				let sShellHash = Constants.getPeActivtyCrossAppHash() + sActivityAction; 
				sShellHash = sId ? sShellHash + "/" + sId : sShellHash;
				this._fnCFlpCrossAppNavigation(sShellHash);
			}

			oContext._oData.busyIndicatorProjects = false;
			oContext._oModel.refresh();
		},

		//Navigation to the SRS App
		fnNavigateToSrsApp: function (sAction, sSrId, sProjectId, sServiceId, sComponentId) {	
			if (!location.href.includes("applicationstudio.cloud.sap") && !(location.href.includes("-dev-duck"))){
				//during BAS and in Dev-Workzone-Launchpad there is no SRS available! 
				let sShellHash = Constants.getSrsCrossAppHash();
				if (sAction === "Display" && sSrId) sShellHash += "&/DetailView/" + sSrId + "," + sProjectId;  //display
				if (sAction === "Create" && sServiceId) sShellHash += "&paramsProduct=" + sServiceId + "-" + sComponentId + "&/DetailView/NEW_SR," + sProjectId; //create with data
				if (sAction === "Create" && !sSrId && !sServiceId) sShellHash += "&/DetailView/NEW_SR," + sProjectId; //create empty
				this._fnCFlpCrossAppNavigation(sShellHash);
			} else {
				MessageBox.information(this._resourceBundle.getText("Navigation.Srs.NA"));
			}
		}

	};
});
