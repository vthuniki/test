sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"com/sap/ui/hep/reuse/Constants",
	"sap/ui/model/odata/v2/ODataModel",
	"com/sap/ui/hep/util/MessageHandlingPopover",
	"com/sap/ui/hep/reuse/BaseTools"

], function (JSONModel, Constants, ODataModel, MessageHandlingPopover, BaseTools) {
	"use strict";

	return {
		messageHandler: MessageHandlingPopover,

		_loadFragment: function (oFragmentController, oView, sFragmentPath, fnInitialCallback) {
			return BaseTools.loadFragment(oFragmentController, oView, sFragmentPath, fnInitialCallback);
		},

		/**
		 * Field validation
		 *
		 * @param {object} oContext the context from which the method is called
		 */
		setNoteTypes: function (oContext) {
			let oModelNotes = new JSONModel({});
			oModelNotes.setDefaultBindingMode("OneWay");
			oModelNotes.setData(Constants.getNoteTypeItems());
			oContext.getView().setModel(oModelNotes, "oModelNotes");
			let aNotes = oModelNotes.getData().noteTypes;
			oModelNotes.getData().noteTypesNewNotes = aNotes.slice(1);
			oModelNotes.getData().newNoteValid = {};
			oModelNotes.getData().newNoteValid.newNoteType = "None";
			oModelNotes.getData().newNoteValid.newNoteSubject = "None";
			oModelNotes.getData().newNoteValid.newNoteText = "None";
			oModelNotes.getData().newNoteValid.save = false;
			oModelNotes.refresh();
		},

		handleReadNotes: function (noteType, oContext) {
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = Constants.getEntities().NoteSet;
			entities.filter = `ProjectID eq '${oContext._idProject}' and Langu eq 'EN'`;
			entities.errorMessage = oContext.getResourceBundle().getText("ProjectDetails.ReadNotesError", [oContext._idProject]);
			if (noteType !== null && noteType !== Constants.getNoteTypeNone().key) {
				entities.filter += `and NoteType eq '${noteType}'`;
			}
			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.busyIndicator = "busyNotes";
			entities.callbackSuccess = (data) => {
				this._handleSuccessNotes(data, oContext, true);
			};
			oContext.readBaseRequest(entities);
		},

		_handleSuccessNotes: function (data, oContext, sInitCall) {
			data.results.map(elm => {
				elm.showDeleteNote = false;
			});
			let oNotes = data.results;

			oContext.getView().getModel("oModelNotes").getData().items = oNotes;
			oContext.getView().getModel("oModelNotes").refresh();

			jQuery("section").css("overflow", "auto");
			oContext._oData.formEditMode = false;
			oContext._oData.busyNotes = false;
			oContext._oData.busyNotesBox = false;
			oContext._oModel.refresh();
		},

		handleFieldSelectionChangeNotes: function (oEvent, oView) {
			let sViewId = oView.getId();
			let sCurrentFieldId = oEvent.getSource().getId().substr(sViewId.length + 2, oEvent.getSource().getId().length);
			if (oEvent.getSource().getValue() !== "") {
				oView.getModel("oModelNotes").getData().newNoteValid[sCurrentFieldId] = "None";
			} else {
				oView.getModel("oModelNotes").getData().newNoteValid[sCurrentFieldId] = "Error";
			}
			oView.getModel("oModelNotes").refresh();
		},

		handleNoteTypeSelectionChange: function (oEvent, oView) {
			let sViewId = oView.getId();
			let sCurrentFieldId = oEvent.getSource().getId().substr(sViewId.length + 2, oEvent.getSource().getId().length);
			if (oEvent.getSource().getSelectedItem().getText() !== "") {
				oView.getModel("oModelNotes").getData().newNoteValid[sCurrentFieldId] = "None";
			} else {
				oView.getModel("oModelNotes").getData().newNoteValid[sCurrentFieldId] = "Error";
			}
			oView.getModel("oModelNotes").refresh();

		},

		/**
		 * @param {object} oEvent triggered when the add new note button is pressed
		 * @param {object} oContext the context from which the method is called
		 *
		 * The language is optional
		 * oNote.Langu = "EN";
		 * this._addNewNoteBE(oNote, oContext);
		 */
		handleAddNote: function (oEvent, oContext) {
			let userLogonDetails = oContext.getOwnerComponent().getModel("appData").getData().oCrmUserData;
			this._validateNoteCreationFields(oContext.getView(), oContext);
			if (oContext.getView().getModel("oModelNotes").getData().newNoteValid.save) {
				let oNote = {};
				oContext._oData.busyNewNote = true;
				oContext._oModel.refresh();
				oNote.CreatedOn = new Date();
				oNote.Title = oContext.getView().byId("newNoteSubject").getValue();
				oNote.Text = oContext.getView().byId("newNoteText").getValue();
				oNote.NoteType = oContext.getView().byId("newNoteType").getSelectedKey();
				oNote.ProjectID = oContext._idProject;
				oNote.CreatedBy = userLogonDetails.UserId;
				oNote.CreatedFirstname = userLogonDetails.FirstName;
				oNote.CreatedLastname = userLogonDetails.LastName;
				oNote.NewAdded = true;
				oNote.id = new Date().getTime();
				oNote.showDeleteNote = true;

				oContext._oData.busyNewNote = false;
				oContext._oModel.refresh();
				oContext.getView().getModel("oModelNotes").getData().items.push(oNote);
				oContext.getView().getModel("oModelNotes").refresh();
				this.handleDiscardNote(oContext);

				this._saveNotes(oContext);
			}
		},

		_saveNotes: function (oContext) {
			let oPromiseNotes = new Promise((resolveNotes, rejectNotes) => {
				return this._preparePayloadAndSaveNotes(resolveNotes, rejectNotes, oContext);
			});
			oPromiseNotes.then(() => {
				this.handleReadNotes(null, oContext);
			},
				(error) => {
					let titleErrorNote = oContext.getResourceBundle().getText("Notes.AddNew");
					oContext.messageHandler.addNewMessageseInsidePopover("Notes", "Error", titleErrorNote, error.message, error.message, oContext);
					oContext.inactiveBusyIndicators(oContext);
				});
		},

		removeNote: function (oEvent, oContext) {
			let oModelNotes = oEvent.getSource().getBindingContext("oModelNotes"),
				sPath = oModelNotes.sPath,
				oDataNotes = oModelNotes.getModel().getData().items,
				sSelectedNote = oModelNotes.getProperty(sPath),
				sNoteKey = sSelectedNote.NoteExtKey,
				filteredData = oDataNotes.filter(note => note.NoteExtKey !== sNoteKey);

			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = `${Constants.getEntities().NoteSet}(ProjectID='${sSelectedNote.ProjectID}',NoteExtKey='${sSelectedNote.NoteExtKey}',NoteType='${sSelectedNote.NoteType}',Langu='EN')`

			entities.errorMessage = oContext.getResourceBundle().getText("ProjectDetails.DeleteNotesError", [sSelectedNote.CreatedFirstname + " " +
				sSelectedNote.CreatedLastname, sSelectedNote.CreatedBy, sSelectedNote.Title, sSelectedNote.NoteExtKey
			]);
			entities.currentView = oContext.getView();
			entities.oContext = oContext;
			entities.busyIndicator = "busyNotes";
			entities.callbackSuccess = (data) => {

				oContext.getView().getModel("oModelNotes").getData().items = filteredData;
				oContext.getView().getModel("oModelNotes").refresh();
			};
			oContext.deleteBaseRequest(entities);
		},

		_validateNoteCreationFields: function (oView, oContext) {
			if (oView.byId("newNoteType").getValue() === "") {
				oView.getModel("oModelNotes").getData().newNoteValid.newNoteType = "Error";
			}
			if (oView.byId("newNoteSubject").getValue() === "") {
				oView.getModel("oModelNotes").getData().newNoteValid.newNoteSubject = "Error";
			}
			if (oView.byId("newNoteText").getValue() === "") {
				oView.getModel("oModelNotes").getData().newNoteValid.newNoteText = "Error";
			}
			if (oView.getModel("oModelNotes").getData().newNoteValid.newNoteType === "Error" ||
				oView.getModel("oModelNotes").getData().newNoteValid.newNoteSubject === "Error" ||
				oView.getModel("oModelNotes").getData().newNoteValid.newNoteText === "Error") {

				oView.getModel("oModelNotes").getData().newNoteValid.save = false;
			} else {
				oView.getModel("oModelNotes").getData().newNoteValid.save = true;
			}
			this.messageHandler.addNotesMessageInPopover(oContext);
			oView.getModel("oModelNotes").refresh();
		},

		_preparePayloadAndSaveNotes: function (resolveNotes, rejectNotes, oCtxt) {
			let sBatchIndividualUrl;
			let oNote = {};
			let myServiceUrl = Constants.getServicePath();
			let oBModel = new ODataModel(myServiceUrl);
			oBModel.setHeaders(Constants.getAPIHeaders());
			let dataNotesLocal = oCtxt.getView().getModel("oModelNotes").getData().items;
			let cnt = 0;
			let aNewAdded = [];
			oBModel.setDeferredGroups(["groupSetId"]);
			dataNotesLocal.forEach((elm, index) => {
				if (elm.NewAdded === true) {
					oNote = {
						"CreatedOn": new Date(),
						"Title": elm.Title,
						"Text": elm.Text,
						"NoteType": elm.NoteType,
						"ProjectID": oCtxt._idProject
					};
					sBatchIndividualUrl = `/${Constants.getEntities().NoteSet}`;
					oBModel.create(sBatchIndividualUrl, oNote, {
						groupId: "groupSetId"
					});
					aNewAdded.push(index);
				}
				cnt++;
			});
			if (dataNotesLocal.length === cnt) {
				oBModel.submitChanges({
					groupId: "groupSetId",
					success:  (oData) => {
						if (oData.__batchResponses !== undefined) {
							if (oData.__batchResponses[0].__changeResponses === undefined) {
								let msgFromBE = JSON.parse(oData.__batchResponses[0].response.body).error.message.value;
								this.messageHandler.addNewMessageseInsidePopover("notesErrorCreation", "Error", "Create Notes", msgFromBE, msgFromBE,
									oCtxt);
								oCtxt.inactiveBusyIndicators(oCtxt);
							} else {
								aNewAdded.forEach(function (elm) {
									oCtxt.getOwnerComponent().trackEvent("Create_Note");
									dataNotesLocal[elm].NewAdded = false;
								});

								resolveNotes(oData);
							}
						} else {
							resolveNotes(oData);
						}
					},
					error: function (oError) {
						rejectNotes(oError);
					}
				});
			}
			if (this.isEmpty(oNote)) {
				resolveNotes();
			}
		},

		isEmpty: function (obj) {
			for (let key in obj) {
				if (obj.hasOwnProperty(key)) {
					return false;
				}
			}
			return true;
		},

		handleDiscardNote: function (oContext) {
			oContext._pDialogNotes?.then(oDialog => oDialog.close().destroy());
			oContext._pDialogNotes = undefined;

			oContext.getView().getModel("oModelNotes").getData().newNoteValid.save = false;
			oContext.getView().getModel("oModelNotes").getData().newNoteValid.newNoteType = "None";
			oContext.getView().getModel("oModelNotes").getData().newNoteValid.newNoteSubject = "None";
			oContext.getView().getModel("oModelNotes").getData().newNoteValid.newNoteText = "None";
			oContext.getView().getModel("oModelNotes").refresh();
		},

		_openDialogAddNewNote: function (oEvent, oContext) {
			oContext._pDialogNotes ??= this._loadFragment(oContext, oContext.getView(), "com.sap.ui.hep.view.Details.fragment.AddNote");
			oContext._pDialogNotes.then(oDialog => oDialog.open());
		}
	};
});
