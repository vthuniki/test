sap.ui.define([], function () {
	"use strict";

	return {

		updateSorting: function (oTable, oSortConfig, oSortColumn) {
			oTable.getItems().forEach(oItem => {
				if (oItem.getMetadata().getName() === "com.sap.ui.hep.util.CustomColumnListItem") {
					oItem.setUseable(true);
				}
			});

			let conf = oSortConfig;
			if ((!oTable) || (!conf)) return;

			let binding = oTable.getBinding("items");
			if (!binding) return;

			let col = this._fnHelperSetColumnSortIndicator(oTable, oSortColumn)
			if (!col) return; // no sorting
		
			let name = this._fnHelperGetName(col);
			if (!name) return;

			let fn = this._fnHelperGetSorterComparator(conf);

			let sorter = [];
			if (binding.isGrouped()) {
				sorter.push(binding.aSorters[0]);
			}
			sorter.push(new sap.ui.model.Sorter(conf.field, col.getSortIndicator() === sap.ui.core.SortOrder.Descending, false, fn));
			if (!oTable.getContext()) {
				if(sorter[0].sPath === "EffortTotal")
					sorter[0].fnCompare = function(a, b){
						return a-b;
					};
				binding.sort(sorter);
			}
		},


		_fnHelperSetColumnSortIndicator: function(oTable, oSortColumn){
			let col = null;
			let columns = oTable.getColumns();
			columns.forEach(function (oCol) {
				if (oSortColumn) {
					if (oCol === oSortColumn) {
						let ind = oCol.getSortIndicator();
						oCol.setSortIndicator(ind === sap.ui.core.SortOrder.Ascending ? sap.ui.core.SortOrder.Descending : sap.ui.core.SortOrder.Ascending);
					} else {
						oCol.setSortIndicator(sap.ui.core.SortOrder.None);
					}
				}
				if (oCol.getSortIndicator() !== sap.ui.core.SortOrder.None) {
					col = oCol;
				}
			});
			return col;
		},

		_fnHelperGetName: function (col){
			/* 
			Hack: in Engagement Scope table the column headers consist of Text + clickable core Items.
			header below tries to get Column Text and exits if === null, but the parent item for the 
			column is now the Flex/HBox which has no name property => sorting does not work. The code 
			below checks for the aggeregation and looks for the text field if therer are any. It should not
			cause problems in other usages. 
			*/ 
			let header = col.getHeader();
			let name;
			if (header.getAggregation("items")) {
				// composite of text + icon
				const aItems = header.getAggregation("items");
				aItems.forEach(oItem => {
					if (oItem.getMetadata().getName() === "sap.m.Text") {
						name = oItem.getProperty("text");
					}
				}); 
			} else {
				// text only
				name = header?.getText() || null;
			}
			return name;
		},	

		_fnHelperGetSorterComparator: function (conf){
			let _sortText = function (a, b) {
				if ((!a) && (!b)) {
					return 0;
				} else if (!a) {
					return -1;
				} else if (!b) {
					return 1;
				} else {
					let typeA = typeof (a);
					let typeB = typeof (b);
					if (typeA !== typeB) {
						return 0;
					}
					if (typeA === "object") {
						return a.getTime() - b.getTime();
					} else if (typeA === "number") {
						return a - b;
					} else {
						return a.localeCompare(b);
					}
				}
			};

			let _sortBoolean = function (a, b) {
				return (a < b) * 2 - 1;
			};

			let fn;
			switch (conf.type === 1) {
			case 1:		
				fn = _sortText;
				break;
			case 2:
				fn = _sortText;
				break;
			case 3:
				fn = _sortBoolean;
				break;
			}

			return fn;		
		}
	};
});