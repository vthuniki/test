sap.ui.define("com/sap/ui/hep/util/TablePersoCustomerProjects",
    [
        "com/sap/ui/hep/util/TablePersoBaseService"
    ],
    function (TablePersoBaseService) {
        "use strict";

        const PersoService = TablePersoBaseService.extend("com.sap.ui.hep.util.TablePersoAddRefObj", {
            constructor: function () {
                TablePersoBaseService.call(this, "tablePerso-customerProjectTable.json");
            },
        });

        return new PersoService();
    }, /* bExport= */ true);
