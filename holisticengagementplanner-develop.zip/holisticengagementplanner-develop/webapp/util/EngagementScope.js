sap.ui.define([
	"com/sap/ui/hep/reuse/Constants"
], function (Constants) {
	return {


		// ********************************************************************************************************
		// ******************************************* SCOPE SECTION **********************************************
		// ********************************************************************************************************

		pEngScopeSectionRead: function (oContext, sProjId, bResetFilter = true) {
			return new Promise((resolve, reject) => {
				oContext.getView().getModel("localModel").getData().busyEngScopeTable = true;
				oContext.getView().getModel("localModel").refresh();
				let entities = {};

				entities.servicePath = Constants.getServicePath();
				entities.entitySet = `ProjectSet('${sProjId}')/toEngagementScope`;
				entities.paginationTop = 9999;
				entities.pagintationSkip = 0;
				entities.errorMessage = oContext.getResourceBundle().getText("Engagement.Scope.error.BECall");
				entities.oContext = oContext;
				entities.currentView = oContext.getView();
				entities.callbackSuccess = (oData) => {
					oContext.getView().getModel("engScope").getData().results = oContext._parseContractsToLinks(oData.results);
					oContext.getView().getModel("engScope").getData().customerCount = oData.results.length;
					oContext.getView().getModel("engScope").getData().inScopeCount = oContext.engagementScope._fnEngScopeUpdateInScopeCount(
						oData.results);
					oContext.getView().getModel("engScope").refresh();
					oContext.getView().getModel("localModel").getData().busyEngScopeTable = false;
					oContext.getView().getModel("localModel").refresh();
					// handle variants
					if (bResetFilter) {
						oContext._initEngScopeFilters("prod");
					}
					resolve();
				};
				entities.callbackError = (oError) => {
					// release busy indicator in case of an error
					oContext.getView().getModel("localModel").getData().busyEngScopeTable = false;
					oContext.getView().getModel("localModel").refresh();
					reject();
				};

				oContext.readBaseRequest(entities);
			});
		},

		_fnEngScopeUpdateInScopeFlag: function (oContext, sCaseId, sPartnerNo, bInScope) {
			oContext.getView().getModel("localModel").getData().busyEngScopeTable = true;
			oContext.getView().getModel("localModel").refresh();
			let entities = {};

			entities.servicePath = Constants.getServicePath();
			entities.entitySet = `EngagementScopeSet(CaseId='${sCaseId}',PartnerNo='${sPartnerNo}')`;
			entities.data = {
				"CaseId": sCaseId,
				"PartnerNo": sPartnerNo,
				"InScope": bInScope
			};
			entities.merge = false;
			entities.updateMethod = "PUT";
			entities.context = oContext;
			entities.currentView = oContext.getView();
			entities.callbackSuccess = (one, two, three) => {
				// change the flag toggle in the local model - important for calculations of the flag count
				const sPath = oContext.getView().getModel("engScope").getData().sPathToggled;
				oContext.getView().getModel("engScope").getProperty(sPath).InScope = oContext.getView().getModel("engScope").getProperty(sPath).InScope ?
					false : true;
				oContext.getView().getModel("engScope").getData().inScopeCount = oContext.engagementScope._fnEngScopeUpdateInScopeCount(
					oContext.getModel("engScope").getData().results);
				oContext.getView().getModel("engScope").refresh();
				oContext.getView().getModel("localModel").getData().busyEngScopeTable = false;
				oContext.getView().getModel("localModel").refresh();
				oContext.getOwnerComponent().trackEvent("EngScope_Change_ScopeOfEngagement");
			};
			entities.callbackError = (oError) => {
				const parsedError = JSON.parse(oError.responseText);
				const sCheckBoxId = oContext.getView().getModel("engScope").getData().oCheckBoxControlId;
				const oCheckboxControl = sap.ui.getCore().byId(sCheckBoxId);
				// set the checkbox back to previous state
				oCheckboxControl.setSelected(!oCheckboxControl.getSelected());
				// Inform user about an error via MessageBus
				oContext.messageHandler.clearAllMessages();
				oContext.messageHandler.addNewMessageseInsidePopover(
					null,
					"Error",
					"Backend Error: " + parsedError.error.innererror.errordetails[0].message,
					"Checkbox selection restored");
				oContext.getView().getModel("localModel").getData().busyEngScopeTable = false;
				oContext.getView().getModel("localModel").refresh();

			};
			oContext.updateBaseRequest(entities);
		},

		_fnEngScopeUpdateInScopeCount: function (oResults) {
			return oResults.filter(oItem => oItem.InScope === true || oItem.MainFlag ===
				true).length;
		}
	};
});
