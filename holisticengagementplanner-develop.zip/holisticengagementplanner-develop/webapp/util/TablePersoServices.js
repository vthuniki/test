sap.ui.define("com/sap/ui/hep/util/TablePersoServices",
    [
        "com/sap/ui/hep/util/SessionTablePersoBaseService"
    ],
    function (SessionTablePersoBaseService) {
        "use strict";

        const PersoService = SessionTablePersoBaseService.extend("com.sap.ui.hep.util.TablePersoServices", {
            constructor: function () {
                SessionTablePersoBaseService.call(this, "tablePerso-servicesTable.json", "homeServTableConfig");
            },
        });

        return new PersoService();
    }, /* bExport= */ true);
