sap.ui.define("com/sap/ui/hep/util/TablePersoEngagementScope",
    [
        "com/sap/ui/hep/util/TablePersoBaseService"
    ],
    function (TablePersoBaseService) {
        "use strict";

        const PersoService = TablePersoBaseService.extend("com.sap.ui.hep.util.TablePersoEngagementScope", {
            constructor: function () {
                TablePersoBaseService.call(this, "tablePerso-engScopeTable.json");
            },

            setContext: function (oContext) {
                this.oContext = oContext;
            },

            setPersData: function (oBundle) {
                let oDeferred = new jQuery.Deferred(),
                    oEngModel = this.oContext.getModel("engScope");
                this._oBundle = oBundle;
                oDeferred.resolve();
                // only trigger save variant if a personalisation flag is set to true
                if (oEngModel.getData().bIsPersoCalled) {
                    this.oContext._onEngScopeVariantChanged(oDeferred);
                }
                return oDeferred.promise();
            },

            getCaption: function (oColumn) {
                let sCaption = null;
                const oColHeader = oColumn.getHeader();
                // Check if header control has either text or 'title' property
                if (oColHeader.getText && oColHeader.getText()) {
                    sCaption = oColHeader.getText();
                } else if (oColHeader.getTitle && oColHeader.getTitle()) {
                    sCaption = oColHeader.getTitle();
                }

                // handles cases where text is nested in other controls (FlexBox/HBox/VBox)
                if (!sCaption) {
                    oColumn.getAggregation("header").getAggregation("items").forEach(oItem => {
                        if (oItem.getText !== undefined) {
                            sCaption = oItem.getText();
                        }
                    });
                }
                return sCaption;
            }
        });

        return new PersoService();
    }, /* bExport= */ true);
