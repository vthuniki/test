sap.ui.define([
	"sap/gantt/simple/BaseRectangle",
	"sap/gantt/simple/RenderUtils",
	"sap/m/Label"
], function (BaseRectangle, RenderUtils, Label) {
	"use strict";

	return BaseRectangle.extend("com.sap.ui.hep.util.LegendRectangle", {
		metadata: {
			properties: {
				title: {
					type: "string"
				},
				fill: {
					type: "string"
				},
				width: {
					type: "float"
				},
				height: {
					type: "float"
				}
			}
			/*,
						aggregations: {
							_label: {
								type: "sap.m.Label",
								multiple: false,
								visibility: "public"
							},
							_baseRectangle: {
								type: "sap.gantt.simple.BaseRectangle",
								multiple: false,
								visibility: "public"
							}
						}*/
		},

		init: function () {
			
		},
		/*
				renderContent: function () {
					// return "M " + 100 + " " + 100 + " L " + (100 + 5) + " " + 100 + " L " + (100 - 5) + " " +
					// 	100 + " Z";
				},*/

		getD: function () {
			
		},

		renderElement: function (oRm, oElement) {
			if (!this._isValid()) {
				return;
			}

			oRm.write("<rect");
			this.writeElementData(oRm);
			oRm.writeClasses(this);

			oRm.write(">");
			oRm.write("</rect>");

			if (this.getShowTitle()) {
				this.setShowTitle(false);
				
			}

			BaseRectangle.prototype.renderElement.apply(this, arguments);
		}
	});
});