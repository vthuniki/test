sap.ui.define(
	[
		"com/sap/ui/hep/reuse/Constants",
		"com/sap/ui/hep/reuse/BaseRequest",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/Fragment"

	],
	function (Constants, BaseRequest, JSONModel, Fragment) {

		let EmployeeSelection = function () {
			//empty as basis for prototyping
		};

		//_______________________________________________________________________________________________________________
		//									I N F O R M A T I O N   H O W   T O   U S E
		//
		// In order to use the generic search module for Employees you have to
		// 1. insert the fragment into your view, where you normally would put the INPUT-field for the field Employee-ID
		//    i.e.			    <core:Fragment id="idFragmentEmployeeIdDialogCreateProject" fragmentName="com.sap.ui.hep.util.employeeSelection.InputFieldEmployeeForForms"	type="XML"/>
		//           or     	<core:Fragment id="idFragmentEmployeeIdDialogEngagementSelection" fragmentName="com.sap.ui.hep.util.employeeSelection.InputFieldEmployee" type="XML"/>
		//    REMAKR: it is very important to give the fragment an ID, that later has to be specified in the setup-customizing as well (see below)
		// 2. in the controller of your view, you have to add the dependency
		//    i.e. 			"com/sap/ui/hep/util/EmployeeSelection/EmployeeSelection"   as "..., EmployeeSelection, ...
		// 3. Somewhere in the initilization part of our controller, you then have to setup the EmployeeSelection-module, by defining it's SETTNGS, creating the INSTANCE of it and finally calling its initilization method
		//
		//    i.e. the following method you could copy to your controller and adjust it to your needs, in order to set up the Employee selection field.
		//         This method you would then have to call somewhere in initialization process for your controller:
		//
		//
		//
		//
		//			_setUpEmployeeSelectionModule1: function (sInitialEmployeeId) {
		// 				let oEmployeeSelectionCustomizing = {
		// 					sInputFragmentId: "idFragmentEmployeeIdDialogCreateProject",  //the name you have given to the fragment that you put into your view
		// 					bInputFragmentHasTextField: true,  //you are either using the fragment for forms or the simple one ... the later does not have the "EmployeeName"-field and no grid-layout setup
		// 					sValueHelpFragmentId: "EmployeeSelection2",  //a string that the module uses to prefix the ids of the value help fragment fields
		// 					sDialogWidth: "70%",  //dimensions of the value help dialog
		// 					sDialogHeight: "790px",  //dimensions of the value help dialog
		// 					sEmployeeIdFieldGridSpan: "XL3 L3 M3 S3",  //only in case of using the form-fragment
		// 					sEmployeeNameFieldGridSpan: "XL6 L6 M6 S6",  //only in case of using the form-fragment
		// 					bEmployeeIdRequired: true,  //puts a red asterisk to the input field and takes care the the value state is set to error
		// 					bEmployeeTextFieldVisible: true,  //it is also possible to use the form-fragment, but to hide the EmployeeName field from the user
		// 					fnCallBackAfterValueChange: (oNewEmployee, sValueState, bInputFieldSubmit) => {
		// 						//define what needs to happen in your view controller, when the Employee has changed....
		//						//oNewEmployee - contains the data of the new Employee
		//						//sValueState - is either "None" or "Error", depending on if the oNewEmployee is valid or not ("Error" can only occur in case "bEmployeeIdRequired" was set to true) // maybe this topic is more complex and "Error" should also happen in case it is not required...
		// 						//bInputFieldSubmit - give the information if the new values was set via typing something and pressing <Enter> in the Employee field, or i.e. via selecting a line in the iput help
		// 						}
		// 					}
		// 				};
		// 				//get your instance and then initialize it
		// 				if (!this.EmployeeSelection2) this.EmployeeSelection2 = new EmployeeSelection();
		// 				this.EmployeeSelection2.fnInitialize(this._oView, oEmployeeSelectionCustomizing, sInitialEmployeeId);
		//			},
		//
		//
		//
		//
		//    Remark: Inside your view controller you can then use the setter- and getter- method of your new EmployeeSelection-Module
		//		  i.e. this.EmployeeSelection2.fnGetEmployeeId()   and this.EmployeeSelection2.fnSetEmployeeId("159922")
		//
		//_______________________________________________________________________________________________________________

		EmployeeSelection.prototype.fnInitialize = function (oEmbeddingView, oCustomizing, sInitialEmployeeId) {
			this._oView = oEmbeddingView;
			this._oResourceBundle = this._oView.getController().getResourceBundle();
			this.fnCallbackAfterChange = oCustomizing.fnCallBackAfterValueChange; //DEFINED IN EMBEDDING CONTROLLER
			this._sValueHelpFragmentId = oCustomizing.sValueHelpFragmentId; //DEFINED IN EMBEDDING CONTROLLER

			let sInputFragmentId = oCustomizing.sInputFragmentId; //DEFINED IN EMBEDDING CONTROLLER
			let bInputFragmentHasTextField = oCustomizing.bInputFragmentHasTextField; //DEFINED IN EMBEDDING CONTROLLER
			//calculate Ids for the input-fragment fields
			let sIdFieldInputEmployeeId = sap.ui.core.Fragment.createId(sInputFragmentId, "idFieldInputEmployeeId");
			let sIdFieldInputEmployeeName = "";
			if (bInputFragmentHasTextField) sIdFieldInputEmployeeName = sap.ui.core.Fragment.createId(sInputFragmentId, "idFieldTextEmployeeName");

			//set the model directly to the Input fields iside the fragment and not just to the embedding view
			// (because the embedding view might finally contain serveral EmployeeSelection fields)
			this._modelEmployeeInputField = new JSONModel({});
			oEmbeddingView.getController().byId(sIdFieldInputEmployeeId).setModel(this._modelEmployeeInputField, "modelEmployeeInputField");

			//the event handlers for the input field have to be added here programatically and can not be defined in the XML of the Input field
			//otherwise it would not be clear, which instance of the EmployeeSelection handles them in the end (in case of we have more instances...)
			//the model is set for one or two fields, depending on the given customizing  - and ensure every event is only attached once!
			oEmbeddingView.getController().byId(sIdFieldInputEmployeeId).detachSubmit(this.fnHandleSubmitEmployeeId, this);
			oEmbeddingView.getController().byId(sIdFieldInputEmployeeId).attachSubmit(this.fnHandleSubmitEmployeeId, this);
			oEmbeddingView.getController().byId(sIdFieldInputEmployeeId).detachValueHelpRequest(this.fnEmployeeSelectionDialogOpen, this);
			oEmbeddingView.getController().byId(sIdFieldInputEmployeeId).attachValueHelpRequest(this.fnEmployeeSelectionDialogOpen, this);
			oEmbeddingView.getController().byId(sIdFieldInputEmployeeId).detachChange(this.fnHandleEmployeeIdChanged, this);
			oEmbeddingView.getController().byId(sIdFieldInputEmployeeId).attachChange(this.fnHandleEmployeeIdChanged, this);
			if (bInputFragmentHasTextField) { //the input field for filter bars does not have the text field
				oEmbeddingView.getController().byId(sIdFieldInputEmployeeName).setModel(this._modelEmployeeInputField, "modelEmployeeInputField");
			}

			//In case the fragment for the form view is used, we have to specify the SPAN-Values for the Grid-layout
			this._modelEmployeeInputField.getData().sEmployeeIdFieldGridSpan = oCustomizing.sEmployeeIdFieldGridSpan; //DEFINED IN EMBEDDING CONTROLLER
			this._modelEmployeeInputField.getData().sEmployeeNameFieldGridSpan = oCustomizing.sEmployeeNameFieldGridSpan; //DEFINED IN EMBEDDING CONTROLLER

			//set some further properties of the input field from given customizing
			this._modelEmployeeInputField.getData().bEmployeeIdRequired = oCustomizing.bEmployeeIdRequired; //DEFINED IN EMBEDDING CONTROLLER
			this._modelEmployeeInputField.getData().bEmployeeTextFieldVisible = oCustomizing.bEmployeeTextFieldVisible; //DEFINED IN EMBEDDING CONTROLLER

			this._modelEmployeeInputField.getData().busyEmployeeIdInputField = false;
			this._modelEmployeeInputField.getData().valueStateEmployeeIdInputField = "None";
			this._modelEmployeeInputField.getData().valueStateTextEmployeeIdInputField = "";

			this._modelEmployeeInputField.getData().oEmployee = {};
			this._modelEmployeeInputField.getData().oEmployee.PartnerID = sInitialEmployeeId; //INITIAL VALUE FROM EMBEDDING CONTROLLER
			this._modelEmployeeInputField.refresh();

			//get the complete Employee info - however the BE call may need some time, during which fnGetEmployeeFullName and fnGetEmployeeName1 do not return anything! maybe redesin via promise? currently not needed, as the get*name*-fns are nto used
			if (isNaN(sInitialEmployeeId)) { //in case the UserID has been passed in
				this._fnGetOneEmployeeFromBE(sInitialEmployeeId, null, (aODataResults => {
					this._modelEmployeeInputField.getData().oEmployee = aODataResults[0];
					this._modelEmployeeInputField.refresh();
				}));
			} else {
				this._fnGetOneEmployeeFromBE(null, sInitialEmployeeId, (aODataResults => {
					this._modelEmployeeInputField.getData().oEmployee = aODataResults[0];
					this._modelEmployeeInputField.refresh();
				}));
			}

			//define and initialize model for the value help dialog
			this._modelEmployeeDialog = new JSONModel({});
			this._modelEmployeeDialog.getData().sDialogWidth = oCustomizing.sDialogWidth; //DEFINED IN EMBEDDING CONTROLLER
			this._modelEmployeeDialog.getData().sDialogHeight = oCustomizing.sDialogHeight; //DEFINED IN EMBEDDING CONTROLLER
			this._modelEmployeeDialog.getData().busyDialogEmployeeValueHelp = false;
			this._modelEmployeeDialog.getData().searchFilter = {};
			this._modelEmployeeDialog.getData().results = [];
			this._modelEmployeeDialog.getData().numberOfResults = "0";
			this._modelEmployeeDialog.refresh();

		};

		EmployeeSelection.prototype.fnGetEmployeeId = function () {
			return this._modelEmployeeInputField.getData().oEmployee ? this._modelEmployeeInputField.getData().oEmployee.PartnerID : "";
		};

		EmployeeSelection.prototype.fnSetEmployeeId = function (sEmployeeId) {
			this._modelEmployeeInputField.getData().oEmployee = {};
			this._modelEmployeeInputField.getData().oEmployee.PartnerID = sEmployeeId;
			this._modelEmployeeInputField.refresh();
			this.fnHandleEmployeeIdChanged();
		};

		EmployeeSelection.prototype.fnGetEmployeeFullName = function () {
			return this._modelEmployeeInputField.getData().oEmployee ? this._modelEmployeeInputField.getData().oEmployee.FullName : "";
		};
		EmployeeSelection.prototype.fnGetEmployeeName1 = function () {
			return this._modelEmployeeInputField.getData().oEmployee ? this._modelEmployeeInputField.getData().oEmployee.Name1 : "";
		};

		//______________________________________________________________________________________________________________________
		//
		//                                                    HELPER
		//
		//______________________________________________________________________________________________________________________



		EmployeeSelection.prototype._fnGetOneEmployeeFromBE = function (sEmployeeHint, sPartnerId, fnCallBack) {
			if (!sEmployeeHint && !sPartnerId) fnCallBack([{}]); //nothing in, so empty array back
			else {
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "PFEmployeeSet";
				entities.filter = sPartnerId ? "(PartnerID eq '" + sPartnerId + "')" : "(ValueFld eq '" + sEmployeeHint + "')";
				entities.callbackSuccess = (oData) => {
					fnCallBack(oData.results);
				};
				BaseRequest.handleRead(entities);
			}
		};

		//______________________________________________________________________________________________________________________
		//
		//                                                    Employee INPUT FIELD
		//
		//______________________________________________________________________________________________________________________

		EmployeeSelection.prototype._fnSetEmployeeIdFieldValueState = function (sValueState) {
			if (sValueState === "None") {
				this._modelEmployeeInputField.getData().valueStateEmployeeIdInputField = "None";
				this._modelEmployeeInputField.getData().valueStateTextEmployeeIdInputField = "";
			} else {
				this._modelEmployeeInputField.getData().valueStateEmployeeIdInputField = "Error";
				this._modelEmployeeInputField.getData().valueStateTextEmployeeIdInputField = "No valid Employee";
			}
			this._modelEmployeeInputField.refresh();
		};

		EmployeeSelection.prototype._fnGetEmployeeIdFieldValueState = function () {
			return this._modelEmployeeInputField.getData().valueStateEmployeeIdInputField;
		};

		// ****************************** START *** fnHandleEmployeeIdChanged **************************************************
		EmployeeSelection.prototype.fnHandleEmployeeIdChanged = function (oEvent) {
			//REMARK: if value is not valid (Error-case) or not unique we also have to clean-up the oEmployee-object
			//when the value is valid, we do not have to change the oEmployee-object, because it was already set in the calling method!
			let sEnteredValue = this._modelEmployeeInputField.getData().oEmployee.PartnerID;
			let bEmployeeRequired = this._modelEmployeeInputField.getData().bEmployeeIdRequired;
			if (!sEnteredValue) {
				this._fnHelperAddEmployeeToModel(bEmployeeRequired, sEnteredValue);
				this.fnCallbackAfterChange(this._modelEmployeeInputField.getData().oEmployee, this._modelEmployeeInputField.getData().valueStateEmployeeIdInputField,
					this._handleEmployeeIdFieldSubmit);
			} else
				//something is entered, but is it a valid Employee number?
				//in case user has pressed <Submit> inside the field, do a generic search for the entered value
				//all other cases do strict search for the PartnerId
				if (this._handleEmployeeIdFieldSubmit) {
					this._fnHelperHandleEmployeeIdChangedHandleSubmit(sEnteredValue, bEmployeeRequired);
				} else {
					this._fnHelperHandleEmployeeIdChangedHandleStrictSearchForPartnerID(sEnteredValue, bEmployeeRequired);
				}
			this._handleEmployeeIdFieldSubmit = false;
		};

		EmployeeSelection.prototype._fnHelperHandleEmployeeIdChangedHandleSubmit = function (sEnteredValue, bEmployeeRequired) {
			this._fnGetOneEmployeeFromBE(sEnteredValue, null, (aODataResults) => {
				if (aODataResults.length !== 1) {
					this._fnHelperAddEmployeeToModel(bEmployeeRequired, sEnteredValue);
				} else if (bEmployeeRequired) this._fnSetEmployeeIdFieldValueState("None");
				this.fnCallbackAfterChange(this._modelEmployeeInputField.getData().oEmployee, this._modelEmployeeInputField.getData().valueStateEmployeeIdInputField,
					this._handleEmployeeIdFieldSubmit);
			});
		};

		EmployeeSelection.prototype._fnHelperHandleEmployeeIdChangedHandleStrictSearchForPartnerID = function (sEnteredValue, bEmployeeRequired) {
			this._fnGetOneEmployeeFromBE(null, sEnteredValue, (aODataResults) => {
				if (aODataResults.length !== 1) {
					this._fnHelperAddEmployeeToModel(bEmployeeRequired, sEnteredValue);
				} else {
					if (bEmployeeRequired) this._fnSetEmployeeIdFieldValueState("None");
					this._modelEmployeeInputField.getData().oEmployee.FullName = aODataResults[0].FullName;
					this._modelEmployeeInputField.refresh();
				}
				this.fnCallbackAfterChange(this._modelEmployeeInputField.getData().oEmployee, this._modelEmployeeInputField.getData().valueStateEmployeeIdInputField,
					this._handleEmployeeIdFieldSubmit);
			});
		};

		EmployeeSelection.prototype._fnHelperAddEmployeeToModel = function (bEmployeeRequired, sEnteredValue) {
			if (bEmployeeRequired) this._fnSetEmployeeIdFieldValueState("Error");
			else this._fnSetEmployeeIdFieldValueState("None");
			this._modelEmployeeInputField.getData().oEmployee = {};
			this._modelEmployeeInputField.getData().oEmployee.PartnerID = sEnteredValue;
			this._modelEmployeeInputField.getData().oEmployee.FullName = "";
			this._modelEmployeeInputField.refresh();
		};
		// ****************************** START *** fnHandleEmployeeIdChanged **************************************************


		EmployeeSelection.prototype.fnHandleSubmitEmployeeId = function (oEvent) {
			this._handleEmployeeIdFieldSubmit = true;
			this._modelEmployeeInputField.getData().oEmployee.FullName = "";
			this._modelEmployeeInputField.getData().busyEmployeeIdInputField = true;
			this._modelEmployeeInputField.refresh();

			this._fnHandleClearSearch();
			this._modelEmployeeDialog.getData().searchFilter.ValueFld = oEvent.getParameter("value");
			this._modelEmployeeDialog.refresh();
			this.fnHandleEmployeeValueHelpSearchTriggered(null, true);

		};

		//______________________________________________________________________________________________________________________
		//
		//                                                    SEARCH DIALOG
		//
		//______________________________________________________________________________________________________________________

		EmployeeSelection.prototype.fnEmployeeSelectionDialogOpen = function (oEvent) {
			if (oEvent) this._fnHandleClearSearch(); //triggered directly by user by clicking on the icon - then popup should be empty
			if (!this._oDialogEmployeeValueHelp) {
				try {
					Fragment.load({
						id: this._oView.createId(this._sValueHelpFragmentId),
						name: "com.sap.ui.hep.util.employeeSelection.DialogValueHelpEmployee",
						controller: this
					}).then(oDialog => {
						this._oDialogEmployeeValueHelp = oDialog;
						this._oView.addDependent(this._oDialogEmployeeValueHelp);
						this._oDialogEmployeeValueHelp.setModel(this._modelEmployeeDialog, "modelEmployeeDialog");
						this._oDialogEmployeeValueHelp.addStyleClass("sapUiSizeCompact");
						this._oDialogEmployeeValueHelp.open();

					});
				} catch (oError) {
					if (oError.statusCode === 503) {
						let params = {
							currentView: this._oView
						};
						this.handleSessionTimeout(params, this);
					}
				}
			} else this._oDialogEmployeeValueHelp.open();

		};


		// ****************************** START *** fnHandleEmployeeValueHelpSearchTriggered **************************************************
		EmployeeSelection.prototype.fnHandleEmployeeValueHelpSearchTriggered = function (oEvent) {
			this._modelEmployeeDialog.getData().busyDialogEmployeeValueHelp = false;
			this._modelEmployeeDialog.refresh();
			//build the filter  i.e. substringof('dasf', ValueFld) and City eq 'afds' and Country eq 'DE'
			let sFilterGeneric = this._modelEmployeeDialog.getData().searchFilter.ValueFld;
			let sFilterNameFirst = this._modelEmployeeDialog.getData().searchFilter.NameFirst;
			let sFilterNameLast = this._modelEmployeeDialog.getData().searchFilter.NameLast;
			let sFilterUserId = this._modelEmployeeDialog.getData().searchFilter.UserId;
			let sFilterEmail = this._modelEmployeeDialog.getData().searchFilter.EmailAddr;

			let sFilter = "";
			if (sFilterGeneric) sFilter = "substringof('" + sFilterGeneric + "', ValueFld)";
			if (sFilterNameFirst) sFilter = sFilter ? sFilter + " and substringof('" + sFilterNameFirst + "', NameFirst)" : "substringof('" +
				sFilterNameFirst + "', NameFirst)";
			if (sFilterNameLast) sFilter = sFilter ? sFilter + " and substringof('" + sFilterNameLast + "', NameLast)" : "substringof('" +
				sFilterNameLast + "', NameLast)";
			if (sFilterUserId) sFilter = sFilter ? sFilter + " and substringof('" + sFilterUserId + "', UserId)" : "substringof('" +
				sFilterUserId + "', UserId)";
			if (sFilterEmail) sFilter = sFilter ? sFilter + " and substringof('" + sFilterEmail + "', EmailAddr)" : "substringof('" +
				sFilterEmail + "', EmailAddr)";

			//build the request
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "PFEmployeeSet";
			entities.filter = sFilter;
			entities.paginationTop = "100"; //limit to 100 results
			entities.paginationSkip = "0";
			entities.currentView = this._oView;
			entities.errorMessage = this._oResourceBundle.getText("NewProject.CustomerSearchError");
			entities.callbackSuccess = this._fnHandleSuccessEmployeeValueHelpSearchTriggered.bind(this);
			BaseRequest.handleRead(entities);
		};

		EmployeeSelection.prototype._fnHandleSuccessEmployeeValueHelpSearchTriggered = function (oData) {
			this._modelEmployeeInputField.getData().busyEmployeeIdInputField = false; //might have been set, when coming from fnHandleSubmitCustomerId, just in case reset it
			this._modelEmployeeInputField.refresh();
			this._modelEmployeeDialog.getData().busyDialogEmployeeValueHelp = false;
			this._modelEmployeeDialog.refresh();
			if (!this._ignoreEmployeeSearchDialog) {
				this._modelEmployeeDialog.getData().results = oData.results;
				this._modelEmployeeDialog.getData().numberOfResults = oData.results.length;

				if (this._handleEmployeeIdFieldSubmit) { //employee search was not triggered inside the Dialog, but by pressing <Enter> in the "Emplyee"-InputField...
					if (this._modelEmployeeDialog.getData().numberOfResults === 1) {
						this._modelEmployeeInputField.getData().oEmployee = oData.results[0];
						this._fnSetEmployeeIdFieldValueState("None");
						this.fnCallbackAfterChange(oData.results[0], "None");
					} else {
						this.fnEmployeeSelectionDialogOpen(); //open the dialog with the found results, so the user can select
						this._modelEmployeeInputField.getData().oEmployee.FullName = "";
					}
				}
				this._modelEmployeeInputField.refresh();
				this._modelEmployeeDialog.refresh();

			} else this._ignoreEmployeeSearchDialog = false;
		};
		// ****************************** END *** fnHandleEmployeeValueHelpSearchTriggered **************************************************


		EmployeeSelection.prototype._fnHandleClearSearch = function () {
			this._modelEmployeeDialog.getData().searchFilter.ValueFld = "";
			this._modelEmployeeDialog.getData().searchFilter.NameFirst = "";
			this._modelEmployeeDialog.getData().searchFilter.NameLast = "";
			this._modelEmployeeDialog.getData().searchFilter.UserId = "";
			this._modelEmployeeDialog.getData().searchFilter.EmailAddr = "";
			this._modelEmployeeDialog.getData().results = null;
			this._modelEmployeeDialog.getData().numberOfResults = "0";
			this._modelEmployeeDialog.refresh();
			//this could be used to trigger en empty search then directly: this.fnHandleEmployeeValueHelpSearchTriggered();

		};

		EmployeeSelection.prototype.fnHandleEmployeeDialogItemPressed = function (oEvent) {
			this._modelEmployeeInputField.getData().busyEmployeeIdInputField = false; //might have been set
			this._modelEmployeeInputField.refresh();
			let iSelectedItemIndex = parseInt(oEvent.getSource().getSelectedContextPaths()[0].split("/")[2], 10);
			let oSelectedItem = this._modelEmployeeDialog.getData().results[iSelectedItemIndex];
			this._modelEmployeeInputField.getData().oEmployee = oSelectedItem;
			this.fnCloseEmployeeValueHelpDialog();
			this._modelEmployeeInputField.refresh();
			this._handleEmployeeIdFieldSubmit = false; //_fnHandleEmployeeIdChanged is not triggered, because of a Submit in field EmployeeId
			this.fnHandleEmployeeIdChanged();
		};

		EmployeeSelection.prototype.fnHandleEmployeeDialogCancel = function () {
			this._modelEmployeeInputField.getData().busyEmployeeIdInputField = false; //might have been set
			this._modelEmployeeInputField.refresh();
			this._modelEmployeeDialog.getData().results = [];
			this.fnCloseEmployeeValueHelpDialog();
			this.fnHandleEmployeeIdChanged(); //might be or might not be, but better call it
		};

		EmployeeSelection.prototype.fnCloseEmployeeValueHelpDialog = function () {
			this._oDialogEmployeeValueHelp.close();
			this._oDialogEmployeeValueHelp.destroy();
			this._oDialogEmployeeValueHelp = undefined;
			if (this._callbackAfterEmployeeValueHelpDialogClose) this._callbackAfterEmployeeValueHelpDialogClose();
		};
		return EmployeeSelection;
	}

);
