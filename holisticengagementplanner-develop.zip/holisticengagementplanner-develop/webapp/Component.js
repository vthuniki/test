sap.ui.getCore().loadLibrary("sapit", {
	url: sap.ui.require.toUrl("com/sap/ui/hep") + "/resources/sapit", async: false
});

/*eslint-env es6*/
sap.ui.define([
	"sap/ui/core/UIComponent",
	"com/sap/ui/hep/model/models",
	"com/sap/ui/hep/reuse/BaseRequest",
	"com/sap/ui/hep/reuse/Constants",
	"sap/ui/util/Storage",
	"sap/base/Log",
	"sapit/util/cFLPAdapter"
], function (UIComponent, models, BaseRequest, Constants, Storage, Log, cFLPAdapter) {
	"use strict";

	let _tracking = null;
	return UIComponent.extend("com.sap.ui.hep.Component", {

		metadata: {
			manifest: "json",
			properties: {
				customerId: {
					name: "customerId",
					type: "string"
				}
			}
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			cFLPAdapter.init();
			UIComponent.prototype.init.apply(this, arguments);
			this.setModel(models.createDeviceModel(), "device");
			this.getRouter().initialize();
			this._generalAppModel();
			this.oHelperData = {};
			this._determineAccount();
			this._adjustReportingParametersForAccount();
			this._determineCurrentBrowser();
			this._determineUnauthorizedAccessAndCRMUserData();
			this._fnPreloadAllPackagesFromSSC();
			this._fnPreloadAllComponentsFromSSC();
			this._fnPreloadAllCrmServiceComponents();

			this.getModel("appData").getData()._langInfoExists = false;
			this.getModel("appData").refresh();

			/* Mobile Usage Reporting */
			/* Version v3 */
			/* eslint-disable */
			sap.git = sap.git || {};
			sap.git.usage = sap.git.usage || {};
			sap.git.usage.Reporting = {
				_lp: null,
				_load: function (a) {
					if (!this._lp) this._lp = sap.ui.getCore().loadLibrary("sap.git.usage", {
						url: Constants.getUsageReportingTrackingUrl(),
						async: true
					});
					this._lp.then(function () {
						a(sap.git.usage.MobileUsageReporting);
					}, this._loadFailed);
				},
				_loadFailed: function (a) {
					Log.warning("[sap.git.usage.MobileUsageReporting]", "Loading failed: " + a);
				},
				setup: function (a) {
					this._load(function (b) {
						b.setup(a);
					});
				},
				addEvent: function (a, b) {
					this._load(function (c) {
						c.addEvent(a, b);
					});
				},
				setUser: function (a, b) {
					this._load(function (c) {
						c.setUser(a, b);
					});
				}
			};
			/* eslint-enable */
			sap.git.usage.Reporting.setup(this);
			_tracking = sap.git;

			// calculate five minutes from milliseconds and set rounds counter to 0
			const fiveMinutes = 1000 * 5 * 60;
			this.roundCounter = 0;

			sap.ui.require(["sap/ui/core/IntervalTrigger"], (IntervalTrigger) => {
				// initialize interval trigger with 5 minutes
				this.heartbeatTrigger = new IntervalTrigger(fiveMinutes);
				this.heartbeatTrigger.addListener(() => {
					// check if 4 hours passed(48 rounds)
					if (this.roundCounter <= 48) {
						try {
							// tries to keep session alive in environment
							window.parent.postMessage(
								JSON.stringify({
									type: "request",
									service: "sap.ushell.sessionHandler.notifyUserActive"
								}), location?.ancestorOrigins[0]);
						} catch (e) {
							Log.error("Couldn't extend the session", e);
						}

						const oParams = {
							servicePath: Constants.getServicePathWithoutLangParam(),
							method: "GET",
							callbackSuccess: (data) => this.roundCounter++
						}
						oParams.function = "Ping";

						BaseRequest.handleFunctionCall(oParams);
					}
				});
			});

			sap.ui.require(["sap/ui/core/IconPool"], function(IconPool) {
				IconPool.addIcon("myIcon-calendar-check", "myCalendarCheckIconCollection", {
					fontFamily: "custom-icon-font",
					content: "e800"
				});
			});
		},

		trackEvent: function (oEvent) {
			if ((!oEvent) || (!_tracking)) {
				return;
			}
			if (Constants.getArrayOfValidEventNames().includes(oEvent)) {
				_tracking.usage.Reporting.addEvent(this, oEvent);
			} else {
				Log.error("Can't track event '" + oEvent + ".' Not a valid event name. Please check Constants.js-file for valid event names.");
			}
		},

		getContentDensityClass: function () {
			if (!this._sContentDensityClass) {
				if (!sap.ui.Device.support.touch || sap.ui.Device.system.desktop === true) {
					this._sContentDensityClass = "sapUiSizeCompact";
				} else {
					this._sContentDensityClass = "sapUiSizeCozy";
				}
			}
			return this._sContentDensityClass;
		},

		_generalAppModel: function () {
			const JSONModel = sap.ui.require("sap/ui/model/json/JSONModel");

			let oModel = new JSONModel({});
			this.setModel(oModel, "appData");

			this.getModel("appData").getData().oMyStorage = new Storage(Storage.Type.session, "hep");
			this.getModel("appData").refresh();
		},

		_determineAccount: function () {
			let sCurrentUrl = window.location.href;
			let sAccount = "dev";
			if (sCurrentUrl.includes("home-prod") || sCurrentUrl.includes("prod-elephant")) {
				sAccount = "prod";
			} else if (sCurrentUrl.includes("home-test") || sCurrentUrl.includes("test-echidna")) {
				sAccount = "test";
			}
			this.getModel("appData").getData().account = sAccount;
			this.getModel("appData").refresh();
		},

		_adjustReportingParametersForAccount: function () {
			const oNewValues = Constants.getMobileReportingParameterNewValues(Constants.getEnvironment());
			if (oNewValues !== undefined) {
				if (this.getMetadata()._oMetadata) {
					this.getMetadata()._oMetadata._oManifest._oManifest['sap.ui5'].config.reportingId = oNewValues.reportingId;
					this.getMetadata()._oMetadata._oManifest._oManifest['sap.ui5'].config.reportingHosts.push(oNewValues.reportingHost);
				}
				this.getMetadata()._oManifest._oManifest['sap.ui5'].config.reportingId = oNewValues.reportingId;
				this.getMetadata()._oManifest._oManifest['sap.ui5'].config.reportingHosts.push(oNewValues.reportingHost);
			}
		},

		_determineCurrentBrowser: function () {
			// Check is done in index.html already. IE is crashing earlier already and would never reach this point.
			// Incorrect, as index.html is never used if hep is accessed via flp, however index.html should never be used for access
			if (!sap.ui.Device.browser.webkit && !sap.ui.Device.browser.firefox) {
				this.getRouter().navTo("UnsupportedBrowser");
			}

		},

		_determineUnauthorizedAccessAndCRMUserData: function () {
			this.pCrmUserDataLoaded = new Promise((resolve, reject) => {
				// Checks if the user is either a TQM, BO, or CoE or CSP. If not then we'll show an Unauthorized page.
				let entities = {};
				entities.servicePath = Constants.getServicePathWithoutLangParam();
				entities.entitySet = "UserSet('')";
				entities.oContext = this;
				entities.errorMessage = "Error reading User authorizations";
				entities.callbackSuccess = (oData) => {
					if (oData.IsBo === false && oData.IsCoe === false && oData.IsTqm === false && oData.IsCsp === false) {
						this.getRouter().navTo("Unauthorized");
					}
					this.getModel("appData").getData().oCrmUserData = oData;
					resolve();
				};
				BaseRequest.handleRead(entities);
			});
		},

		_fnPreloadAllPackagesFromSSC: function () {
			let pLoadAllFocusPackagesFromSSC = new Promise(resFPLoaded => {
				let entities = {};
				entities.url = Constants.getRequestSscAllFocusPackages();
				entities.callbackSuccess = (oData) => {
					resFPLoaded(oData.products);
				};
				BaseRequest.handleReadRest(entities);
			});
			let pLoadAllBusinessScenarioModulesFromSSC = new Promise(resBSMLoaded => {
				let entities = {};
				entities.url = Constants.getRequestSscAllBusinessScenarioModules();
				entities.callbackSuccess = (oData) => {
					resBSMLoaded(oData.products);
				};
				BaseRequest.handleReadRest(entities);
			});
			this.oHelperData.pReadAllPackagesFromSSC = Promise.all([pLoadAllFocusPackagesFromSSC, pLoadAllBusinessScenarioModulesFromSSC]).then(aPackages =>{
				let aPackagesAll = [...aPackages[0], ...aPackages[1]];  //merge array of "Focus Packages" and array of "Business Scenario Modules" tegether
				aPackagesAll.forEach(oPackage => {
					this.__fnFormattingSscPackage(oPackage);
				});
				//sort the list of SSC Packages
				aPackagesAll.sort((a, b) => (a.serviceNumber > b.serviceNumber) ? 1 : -1);
				let iCounter = 0;
				aPackagesAll.forEach(oPackage => {
					iCounter++;
					oPackage.LinkText = `${iCounter}. [${oPackage.code}] - ${oPackage.name}`;
					oPackage.PackageUrl = oPackage.url;
				});
				return aPackagesAll;
			});
		},

		__fnFormattingSscPackage(oPackage) {
			if (oPackage.code.startsWith("FP")) {
				oPackage.usedIn = "Focus Package";
				oPackage.nameFormatted = oPackage.name;
			} else {
				//Formatting oPackage.usedIn
				oPackage.usedIn = oPackage.name?.substr(0, oPackage.name.indexOf('//'))?.trim();
				if (oPackage.usedIn?.includes(":")) {
					oPackage.usedIn = oPackage?.usedIn?.substr(21, oPackage.name.length).trim();
				}
				if (oPackage.usedIn?.startsWith(":")) {
					oPackage.usedIn = oPackage?.usedIn?.substr(1, oPackage.name.length).trim();
				}
				//Formatting oPackage.name
				oPackage.nameFormatted = oPackage.name?.substr(oPackage.name.indexOf('//') + 2, oPackage.name.length).trim();
				if (oPackage.nameFormatted?.includes("Module")) {
					oPackage.nameFormatted = oPackage.nameFormatted.substr(oPackage.nameFormatted.indexOf('Module') + 6, oPackage.nameFormatted
						.length).trim();
				}
				if (oPackage.nameFormatted?.startsWith(":")) {
					oPackage.nameFormatted = oPackage.nameFormatted.substr(1, oPackage.nameFormatted.length).trim();
				}
			}
		},

		_fnPreloadAllComponentsFromSSC: function () {
			// Usually, although it should not be the case, there are slight differences, between the service components in SSC and CRM.
			// Relevant in the end is, what we have in CRM, because only those can be used inside SOs or SRs.
			// However, we also need the list of components from SSC, because it contains information that CRM does not have. I.e. Phase and Effort...
			// To maximize performance for this topic, we load a list of all components from SSC once at startup of HEP.
			//  (this list can then be be used, to populate the missing information in the list of components we load from CRM in the next step)

			let pReadFPComponents = new Promise(resFPsLoaded => {
				let entities = {};
				entities.url = Constants.getRequestSscAllFocusPackageComponents();
				entities.callbackSuccess = (oData) => {
					resFPsLoaded(oData.d.results);
				};
				BaseRequest.handleReadRest(entities);
			});
			let pReadBSMComponents = new Promise(resBSMsLoaded => {
				let entities = {};
				entities.url = Constants.getRequestSscAllBusinessScenarioModuleComponents();
				entities.callbackSuccess = (oData) => {
					resBSMsLoaded(oData.d.results);
				};
				BaseRequest.handleReadRest(entities);
			});
			this.oHelperData.pReadAllComponentsFromSSC = Promise.all([pReadFPComponents, pReadBSMComponents]).then(aData => {
				return [...aData[0], ...aData[1]];
			});
		},

		_fnPreloadAllCrmServiceComponents: function () {
			// We load all service components from CRM and enhance them with some further information from the respective SSC-component (like "effort" and "phase")
			this.oHelperData.pReadAllCrmServiceComponents = new Promise((resolve, reject) => {
				let entities = {};
				entities.servicePath = Constants.getServicePathSPD();
				entities.entitySet = "ComponentF4Set";
				entities.expand = "toServiceF4";
				entities.callbackSuccess = (oData) => {
					this.oHelperData.pReadAllComponentsFromSSC.then(aSSCComponents => {
						//after the call to SSC is finished, use its data to enrich the CRM components data
						oData.results.forEach(oCrmComponent => {
							this.__fnEnrichCrmServiceComponentWithSscData(aSSCComponents, oCrmComponent);
						});
						resolve(oData);
					});
				};
				BaseRequest.handleRead(entities);
			});
		},

		__fnEnrichCrmServiceComponentWithSscData(aSSCComponents, oCrmComponent) {
			oCrmComponent.EffortFixed = oCrmComponent.toServiceF4.results[0].EffortFixed;
			//enrich CRM component with data from SSC (Description, Effort, Phase)
			let oSSCComponent = aSSCComponents.find(elm => elm.serviceNumber === oCrmComponent.ComponentID);
			if (oSSCComponent) {
				oCrmComponent.ComponentDescription = oSSCComponent.name.length > 40 ? oSSCComponent.name.substr(0, 38) + ".." :
					oSSCComponent.name;
				oCrmComponent.ComponentDescriptionUc = oCrmComponent.ComponentDescription.toUpperCase();
				oCrmComponent.ComponentEffort = oSSCComponent.scEffortEstimate ? parseFloat(oSSCComponent.scEffortEstimate).toFixed(3) :
					"0.000";
				oCrmComponent.ComponentFirstPhase = (oSSCComponent.scProjectPhase?.results[0]) ?
					Constants.getCrmPhaseForSSCPhase()[(oSSCComponent.scProjectPhase.results[0].value)] : null;
				let oPhaseCust = Constants.getProjectPhasesCustomizing().results.find(elm => elm.DdlbKey === oCrmComponent.ComponentFirstPhase);
				oCrmComponent.ComponentFirstPhaseText = oPhaseCust ? oPhaseCust.Value : "None";
			}
		}
	});
});
