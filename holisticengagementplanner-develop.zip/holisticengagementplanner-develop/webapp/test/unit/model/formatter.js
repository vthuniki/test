/*global QUnit*/

sap.ui.define([
	"com/sap/ui/hep/model/formatter",
	"sap/ui/core/mvc/View",
	"sap/ui/model/resource/ResourceModel"
], function (Formatter, XMLView, ResourceModel) {
	"use strict";

	QUnit.module("Formatter", {
		beforeEach: function () {

			this.oModelI18n = new ResourceModel({
				bundleName: "com.sap.ui.hep.i18n.i18n",
				bundleLocale: "EN"
			});

			this.oEmptyView = new XMLView({});
			Formatter.getView = function () {};

			var oModel = {
				getResourceBundle: function () {}
			};

			sinon.stub(Formatter, "getView").returns(this.oEmptyView);
			sinon.stub(this.oEmptyView, "getModel").withArgs("i18n").returns(oModel);
			sinon.stub(oModel, "getResourceBundle").returns(this.oModelI18n.getResourceBundle());
		},
		afterEach: function () {
			this.oModelI18n.destroy();
		}
	});

	QUnit.test("showRestrictedConfirmBtn - Should return true to make the confirm button enabled", function (assert) {
		const shouldBeEnabled = true;
		const sReason = "05";

		let isEnabled = Formatter.showRestrictedConfirmBtn(sReason);
		assert.strictEqual(isEnabled, shouldBeEnabled);
	});

	QUnit.test("showRestrictedConfirmBtn - Should return true to make the confirm button enabled with free text and reason Other", function (
		assert) {
		const shouldBeEnabled = true;
		const sReason = "90";
		const sOtherReason = "I need access";

		let isEnabled = Formatter.showRestrictedConfirmBtn(sReason, sOtherReason);
		assert.strictEqual(isEnabled, shouldBeEnabled);
	});

	QUnit.test("showRestrictedConfirmBtn - Should return false because reason is undefined", function (assert) {
		const shouldBeEnabled = false;

		let isEnabled = Formatter.showRestrictedConfirmBtn();
		assert.strictEqual(isEnabled, shouldBeEnabled);
	});

	QUnit.test("showRestrictedConfirmBtn - Should return false because reason is empty", function (assert) {
		const shouldBeEnabled = false;
		const sReason = "";

		let isEnabled = Formatter.showRestrictedConfirmBtn(sReason);
		assert.strictEqual(isEnabled, shouldBeEnabled);
	});

	QUnit.test("showRestrictedConfirmBtn - Should return false because reason is null", function (assert) {
		const shouldBeEnabled = false;
		const sReason = null;

		let isEnabled = Formatter.showRestrictedConfirmBtn(sReason);
		assert.strictEqual(isEnabled, shouldBeEnabled);
	});

	QUnit.test("showRestrictedConfirmBtn - Should return false because reason is Other and text is empty", function (assert) {
		const shouldBeEnabled = false;
		const sReason = "90";
		const sOtherReason = "";

		let isEnabled = Formatter.showRestrictedConfirmBtn(sReason, sOtherReason);
		assert.strictEqual(isEnabled, shouldBeEnabled);
	});

	QUnit.test("formatSPDServicePlanDraftTitle - Should return the SPD Title with number of items and days", function (assert) {

		const expectedTitle = "Service Plan Draft (10 items / 25 days)";
		const iNumberOfItems = 10;
		const iNumberOfDays = 25;

		let isText = Formatter.formatSPDServicePlanDraftTitle(iNumberOfItems, iNumberOfDays);
		assert.strictEqual(isText, expectedTitle, "Service Plan Draft text is correctly formatted");
	});

	QUnit.test("formatSPDServicePlanDraftTitle - Should display 0 items and 0 days if no value is provided ", function (assert) {

		const expectedTitle = "Service Plan Draft (0 items / 0 days)";

		let isText = Formatter.formatSPDServicePlanDraftTitle();
		assert.strictEqual(isText, expectedTitle, "Service Plan Draft text is correctly formatted");
	});

});