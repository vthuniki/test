sap.ui.define([
	"com/sap/ui/hep/controller/NewEngagement/NewEngagement.controller",
	], function(Controller) {
	"use strict";

	QUnit.module("New Engagement", {

		beforeEach: function() {

		},

		afterEach: function() {

		}
	});

	QUnit.test("Should Initialize all fileds so that they have no errors", function(assert) {
				// arrange
		const oAppController = new Controller();
		oAppController._oData = {};
		
		oAppController._setInitialValueStateForAllFields();
		
		assert.ok(oAppController._oData.valueStatecustomerNumber === "None", "Value State of field Customer Number is set as 'None'");
		assert.ok(oAppController._oData.valueStatecustomerName === "None", "Value State of field Customer Name is set as 'None'");
		assert.ok(oAppController._oData.valueStateengagementName === "None", "Value State of field Engagement Name is set as 'None'");
		assert.ok(oAppController._oData.valueStateengagementDescription === "None", "Value State of field Engagement Description is set as 'None'");
		assert.ok(oAppController._oData.valueStatereason === "None", "Value State of field Reason is set as 'None'");
		assert.ok(oAppController._oData.valueStatestartDateNE === "None", "Value State of field Start Date NE is set as 'None'");
		assert.ok(oAppController._oData.valueStateendDateNE === "None", "Value State of field End Date NE is set as 'None'");
		assert.ok(oAppController._oData.valueStateparentEngagementCase === "None", "Value State of field Parent Engagement Case is set as 'None'");
		
		assert.ok(oAppController._oData.customerNumberValid, "Customer number is initially set to valid");
		assert.ok(oAppController._oData.customerNameValid, "Customer name is initially set to valid");
		assert.ok(oAppController._oData.engagementNameValid, "Engagement name is initially set to valid");
		assert.ok(oAppController._oData.engagementDescriptionValid, "Engagement description is initially set to valid");
		assert.ok(oAppController._oData.reasonValid, "Reason is initially set to valid");
		assert.ok(oAppController._oData.engagementTypeValid, "Engagement type is initially set to valid");
		assert.ok(oAppController._oData.startDateNEValid, "Start Date NE is initially set to valid");
		assert.ok(oAppController._oData.endDateNEValid, "End Date NE is initially set to valid");
		assert.ok(oAppController._oData.parentEngagementCaseValid, "Parent engagement case is initially set to valid");
	});
});