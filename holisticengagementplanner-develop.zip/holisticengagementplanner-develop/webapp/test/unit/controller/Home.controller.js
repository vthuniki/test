/*global QUnit*/

sap.ui.define([
	"com/sap/ui/hep/controller/Home/Home.controller",
	"sap/ui/core/routing/Router",
	"sap/ui/core/routing/Route",
	"sap/ui/core/mvc/XMLView"
], function (Controller, Router, Route, XMLView) {
	"use strict";
	
	var temp;

	QUnit.module("Home Controller", {
		beforeEach: function () {
		// code 
	},
		afterEach: function() {
		// code	
		}
	} );

	QUnit.test("onInit - should initialize the HomeController", async function (assert) {
		// arrange
		const oAppController = new Controller();
		const testValue = "testValue"
		
		// arrange pattern matched
		const router = new Router();
		const route = new Route(router, {name: "testRoute"}, null);
		
		const routerStub = new sinon.stub(oAppController, "getRouter").returns(router);
		const routeStub = new sinon.stub(router, "getRoute").returns(route) ;
		const patternMatchedStub = new sinon.stub(route, "attachPatternMatched");
		
		// arrange addStyle 
		const view = await XMLView.create({definition: "<sap.ui.core.mvc.View> </sap.ui.core.mvc.View>"});
		const ownerComponent = await new sap.ui.core.Component();
		ownerComponent.getContentDensityClass = function () {return "1234"};
		
		const viewStub = new sinon.stub(oAppController, "getView").returns(view);
		const styleClassStub = new sinon.stub(view, "addStyleClass");
		const ownerCompStub = new sinon.stub(oAppController, "getOwnerComponent").returns(ownerComponent);
		const densClassStub = new sinon.stub(ownerComponent, "getContentDensityClass").returns(testValue);
		
		// arrange setInitialCustomerValue
		const initCustValStub = new sinon.stub(oAppController, "_setInitialCustomerValue");
		
		// act
		oAppController.onInit();
		
		// assert
		assert.ok(patternMatchedStub.called, "Pattern matched assigned to route");
		assert.ok(styleClassStub.called, "Style Class added");
		assert.ok(styleClassStub.alwaysCalledWith(testValue), "DensityClass of Owner Component added as Style Class");
		assert.ok(initCustValStub.called, "Function '_setInitialCustomerValue()' called.")
		
	});

});