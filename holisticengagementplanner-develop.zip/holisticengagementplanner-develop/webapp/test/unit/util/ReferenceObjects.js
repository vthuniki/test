/*global QUnit*/

var aDataCenters = [{
	"Type": "CarDataCenter",
	"Key": "",
	"Value": ""
}, {
	"Type": "CarDataCenter",
	"Key": "AAA",
	"Value": "Netherlands: Amsterdam"
}, {
	"Type": "CarDataCenter",
	"Key": "AB2",
	"Value": "USA: Ashburn, VA"
}, {
	"Type": "CarDataCenter",
	"Key": "AB3",
	"Value": "USA: Ashburn, VA"
}];

sap.ui.define([
	"com/sap/ui/hep/util/ReferenceObjects",
	"sap/ui/core/mvc/View",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/model/json/JSONModel"
], function (ReferenceObject, View, ResourceModel, JSONModel) {
	"use strict";

	QUnit.module("ReferenceObjects", {
		beforeEach: function () {

			this._oDialogAddNewRO = {
				getModel: function () {}
			};

			ReferenceObject.oContext = {
				_oDialogAddNewRO: this._oDialogAddNewRO
			};

			this.oDataCenterModel = new JSONModel({
				dataCenters: aDataCenters
			});
			sinon.stub(this._oDialogAddNewRO, "getModel").withArgs("dataCenterSearchHelp").returns(this.oDataCenterModel);

		},
		afterEach: function () {
			this.oDataCenterModel.destroy();
		}
	});

	QUnit.test("searchDataCenters - Should set the filteredDataCenter model value without filtering", function (assert) {
		ReferenceObject.searchDataCenters();

		const aSearchedDataCenters = this._oDialogAddNewRO.getModel("dataCenterSearchHelp").getProperty("/filteredDataCenters");
		const iNumberOfDataCenters = this._oDialogAddNewRO.getModel("dataCenterSearchHelp").getProperty("/numberOfDataCenters");

		assert.strictEqual(iNumberOfDataCenters, 4);
		assert.strictEqual(aSearchedDataCenters, aDataCenters);

	});

	QUnit.test("searchDataCenters - Should set the filteredDataCenter model value with filtering the Value fields", function (assert) {
		const aTargetFilteredDataCenters = [{
			"Type": "CarDataCenter",
			"Key": "AB2",
			"Value": "USA: Ashburn, VA"
		}, {
			"Type": "CarDataCenter",
			"Key": "AB3",
			"Value": "USA: Ashburn, VA"
		}];

		this._oDialogAddNewRO.getModel("dataCenterSearchHelp").setProperty("/searchDataCenter", "USA");

		ReferenceObject.searchDataCenters();

		const aSearchedDataCenters = this._oDialogAddNewRO.getModel("dataCenterSearchHelp").getProperty("/filteredDataCenters");
		const iNumberOfDataCenters = this._oDialogAddNewRO.getModel("dataCenterSearchHelp").getProperty("/numberOfDataCenters");

		assert.strictEqual(iNumberOfDataCenters, 2);
		assert.propEqual(aSearchedDataCenters, aTargetFilteredDataCenters);

	});

	QUnit.test("searchDataCenters - Should set the filteredDataCenter model value with filtering the Key fields", function (assert) {
		const aTargetFilteredDataCenters = [{
			"Type": "CarDataCenter",
			"Key": "AB2",
			"Value": "USA: Ashburn, VA"
		}];

		this._oDialogAddNewRO.getModel("dataCenterSearchHelp").setProperty("/searchDataCenterId", "AB2");

		ReferenceObject.searchDataCenters();

		const aSearchedDataCenters = this._oDialogAddNewRO.getModel("dataCenterSearchHelp").getProperty("/filteredDataCenters");
		const iNumberOfDataCenters = this._oDialogAddNewRO.getModel("dataCenterSearchHelp").getProperty("/numberOfDataCenters");

		assert.strictEqual(iNumberOfDataCenters, 1);
		assert.propEqual(aSearchedDataCenters, aTargetFilteredDataCenters);

	});

	QUnit.test("searchDataCenters - Should set the filteredDataCenter model value with filtering both the Value and Key fields", function (
		assert) {
		const aTargetFilteredDataCenters = [{
			"Type": "CarDataCenter",
			"Key": "AB2",
			"Value": "USA: Ashburn, VA"
		}];

		this._oDialogAddNewRO.getModel("dataCenterSearchHelp").setProperty("/searchDataCenterId", "AB2");
		this._oDialogAddNewRO.getModel("dataCenterSearchHelp").setProperty("/searchDataCenter", "USA");

		ReferenceObject.searchDataCenters();

		const aSearchedDataCenters = this._oDialogAddNewRO.getModel("dataCenterSearchHelp").getProperty("/filteredDataCenters");
		const iNumberOfDataCenters = this._oDialogAddNewRO.getModel("dataCenterSearchHelp").getProperty("/numberOfDataCenters");

		assert.strictEqual(iNumberOfDataCenters, 1);
		assert.propEqual(aSearchedDataCenters, aTargetFilteredDataCenters);

	});

	QUnit.test("_filterDataCenters - Should filter and return only one data center based on the Key", function (assert) {
		const aTargetFilteredDataCenters = [{
			"Type": "CarDataCenter",
			"Key": "AB2",
			"Value": "USA: Ashburn, VA"
		}];

		const sProperty = "Key";
		const sFilterValue = "AB2";

		const aFilteredDataCenters = ReferenceObject._filterDataCenters(aDataCenters, sProperty, sFilterValue);
		assert.propEqual(aFilteredDataCenters, aTargetFilteredDataCenters);
		assert.strictEqual(aFilteredDataCenters.length, 1);
	});

	QUnit.test("_filterDataCenters - Should filter and return only one data center based on the Value", function (assert) {
		const aTargetFilteredDataCenters = [{
			"Type": "CarDataCenter",
			"Key": "AAA",
			"Value": "Netherlands: Amsterdam"
		}];

		const sProperty = "Value";
		const sFilterValue = "Netherlands";

		const aFilteredDataCenters = ReferenceObject._filterDataCenters(aDataCenters, sProperty, sFilterValue);
		assert.propEqual(aFilteredDataCenters, aTargetFilteredDataCenters);
		assert.strictEqual(aFilteredDataCenters.length, 1);
	});

	QUnit.test("_filterDataCenters - Should filter and return multiple data center based on the Value", function (assert) {
		const aTargetFilteredDataCenters = [{
			"Type": "CarDataCenter",
			"Key": "AB2",
			"Value": "USA: Ashburn, VA"
		}, {
			"Type": "CarDataCenter",
			"Key": "AB3",
			"Value": "USA: Ashburn, VA"
		}];

		const sProperty = "Value";
		const sFilterValue = "USA";

		const aFilteredDataCenters = ReferenceObject._filterDataCenters(aDataCenters, sProperty, sFilterValue);
		assert.propEqual(aFilteredDataCenters, aTargetFilteredDataCenters);
		assert.strictEqual(aFilteredDataCenters.length, 2);
	});

});