sap.ui.define([
		"com/sap/ui/hep/test/unit/controller/Home.controller",
		"com/sap/ui/hep/test/unit/controller/NewEngagement.controller",
		"com/sap/ui/hep/test/unit/model/formatter",
		"com/sap/ui/hep/test/unit/util/ReferenceObjects"
	],
	QUnit.config.autostart = false,
	function () {
		"use strict";
	});