	/*global QUnit*/

	sap.ui.define([
		"sap/ui/test/opaQunit",
		"./pages/Home",
		"./pages/ProjectDetails",
		"./pages/SPDDetails"
	], function (opaTest) {
		"use strict";

		var sProjectNameID = "Project for Integration Tests (20002897)";
		var sProjectName = "Project for Integration Tests";
		var sCustomer = "Hilti AG (159922)";
		var sServicePlanName = "Mock - Service Plan 1";
		var sServicePlanDescription = "Mock - First service plan to be used in OPA5 tests.";
		var sServicePlanItem = "Mock - GoingLive Analysis Session";
		var sServicePlanItemStartDate = "March 29, 2021";
		var sServicePlanItemEndDate = "March 30, 2021";
		var sComponentID = "9500017";
		var sComponentDescription = "Mock - GoingLive Analysis Session";
		var sComponentType = "Proposal";
		var sItemNumber = "0000000000";
		var sCreatedAt = "March 24, 2021";
		var sCreatedBy = "Dina Younes (I516286)";

		QUnit.module("New Service Plan Delivery Journey");

		opaTest("I open a project, I should see tab: Service Plan BETA.", function (Given, When, Then) {

			// Arrangements
			Given.iStartMyApp();

			When.onTheAppPage.iSwitchToProjectsEnagagements("Projects");
			When.onTheAppPage.iOpenProjectsEngagementsDropDown();
			When.onTheAppPage.iSelectAllMyProjectsEngagements("All Projects");
			When.onTheAppPage.iClickOnProjectInList(sProjectName);

			Then.onTheProjectDetailsPage.iShouldSeeCorrectProjectNameID(sProjectNameID);
			Then.onTheProjectDetailsPage.iShouldSeeCorrectTab("Service Plan Drafts BETA");
		});

		opaTest("I switch to tab Service Plan Drafts BETA, I should see 1 service plan.", function (Given, When, Then) {
			When.onTheProjectDetailsPage.iClickOnTab("Service Plan Drafts BETA");
			Then.onTheProjectDetailsPage.iShouldSeeServicePlans(1);
		});

		opaTest("Check Table Columns of tab 'Service Plan Drafts'", function (Given, When, Then) {
			var columns = [{
				id: "Name",
				width: "25%",
				visible: true,
				index: 1
			}, {
				id: "Description",
				width: "25%",
				visible: true,
				index: 2
			}, {
				id: "CreatedAt",
				visible: true,
				index: 3
			}, {
				id: "CreatedBy",
				visible: true,
				index: 4
			}, {
				id: "ChangedAt",
				visible: true,
				index: 5,
				sortIndicator: "Descending"
			}, {
				id: "ChangedBy",
				visible: true,
				index: 6
			}, {
				id: "Actions",
				visible: true,
				width: "6rem",
				index: 7
			}];

			//Assertions
			columns.forEach(function (column, index) {
				if (column.width) Then.onTheProjectDetailsPage.iShouldSeeColumnWithCorrectWidth(column.id, column.width);
				if (column.visible !== undefined) Then.onTheProjectDetailsPage.iSeeTheCorrectColumn(column.id, column.visible);
				if (column.index !== undefined) Then.onTheProjectDetailsPage.iShouldSeeColumnInCorrectOrder(column.id, column.index);
				if (column.sortIndicator !== undefined) Then.onTheProjectDetailsPage.iShouldSeeColumnCorrectlySorted(column.id, column.sortIndicator);
			});
		});

		opaTest("I should see correct name, description and created by of the first service plan.", function (Given, When, Then) {
			Then.onTheProjectDetailsPage.iShouldSeeCorrectServicePlanName(0, sServicePlanName);
			Then.onTheProjectDetailsPage.iShouldSeeCorrectServicePlanDescription(0, sServicePlanDescription);
			Then.onTheProjectDetailsPage.iShouldSeeCorrectCreatedBy(0, "Dina Younes (I516286)");
		});

		opaTest("I click on Add Service Plan. I should see Create Service Plan dialog.", function (Given, When, Then) {
			When.onTheProjectDetailsPage.iClickOnAddServicePlan();
			Then.onTheProjectDetailsPage.iShouldSeeCreateServicePlanDialog();
		});

		opaTest("I enter Service Plan name, description. I should see correct project name in the dialog.", function (Given, When, Then) {
			When.onTheProjectDetailsPage.iEnterServicePlanName("Test Service Plan");
			When.onTheProjectDetailsPage.iEnterServicePlanDescription("Test Service Plan:\nService plan created during OPA5.");
			Then.onTheProjectDetailsPage.iShouldSeeCorrectCaseNameID(sProjectNameID);
		});

		opaTest("I navigate to SPD page. I should see correct page title: Service Plan Details.", function (Given, When, Then) {
			When.onTheProjectDetailsPage.iCancelCreatingServicePlan();
			When.onTheProjectDetailsPage.iNavigateToServicePlanItems();
			Then.onTheSPDDetailsPage.iShouldSeeCorrectPageTitle("Service Plan Details");
			Then.onTheSPDDetailsPage.iShouldSeeCorrectCustomer(sCustomer);
		});

		opaTest("On the SPD page. I should see correct customer name and ID: " + sCustomer, function (Given, When, Then) {
			Then.onTheSPDDetailsPage.iShouldSeeCorrectCustomer(sCustomer);
		});

		/*opaTest("On the SPD page. I should see correct service plan name: "+sServicePlanName, function (Given, When, Then) {
			Then.onTheSPDDetailsPage.iShouldSeeCorrectServicePlanName(sServicePlanName);
		});*/

		opaTest("Iswitch to tab Phase View. I should see 1 service plan item.", function (Given, When, Then) {
			When.onTheSPDDetailsPage.iClickOnTab("Phase View");
			Then.onTheSPDDetailsPage.iShouldSeeCorrectNumberOfServicePlanItems(1);
		});

		opaTest("I should see service plan item with correct title: " + sServicePlanItem, function (Given, When, Then) {
			Then.onTheSPDDetailsPage.iShouldSeeCorrectServicePlanItem(sServicePlanItem);
		});

		opaTest("I should see service plan item with correct effort: 2.000", function (Given, When, Then) {
			Then.onTheSPDDetailsPage.iShouldSeeCorrectEffortOfServicePlanItem(2);
		});

		opaTest("I should see service plan item with correct start date: " + sServicePlanItemStartDate, function (Given, When, Then) {
			Then.onTheSPDDetailsPage.iShouldSeeCorrectStartDateOfServicePlanItem(sServicePlanItemStartDate);
		});

		opaTest("I should see service plan item with correct end date: " + sServicePlanItemEndDate, function (Given, When, Then) {
			Then.onTheSPDDetailsPage.iShouldSeeCorrectEndDateOfServicePlanItem(sServicePlanItemEndDate);
		});

		opaTest("I click on Edit. I should see the field start date editable.", function (Given, When, Then) {
			When.onTheSPDDetailsPage.iClickOnEdit();
			Then.onTheSPDDetailsPage.iShouldSeeStartDateOfServicePlanItemEditable(true);
		});

		opaTest("In the Edit mode I should see the field end date editable.", function (Given, When, Then) {
			Then.onTheSPDDetailsPage.iShouldSeeEndDateOfServicePlanItemEditable(true);
		});

		opaTest("In the Edit mode I should see the field effort editable.", function (Given, When, Then) {
			Then.onTheSPDDetailsPage.iShouldSeeEffortOfServicePlanItemEditable(true);
		});

		opaTest("In the Edit mode I should see the delete icon.", function (Given, When, Then) {
			Then.onTheSPDDetailsPage.iShouldSeeDeleteIcon();
		});

		opaTest("I click on Cancel. I should see discard changes dialog.", function (Given, When, Then) {
			When.onTheSPDDetailsPage.iClickOnCancel();
			Then.onTheSPDDetailsPage.iShouldSeeDialogDiscardChanges();
		});

		opaTest("I cancel the dialog and switch to List view. I should see 1 service plan item.", function (Given, When, Then) {
			When.onTheSPDDetailsPage.inDialogIClickOnCanel();
			When.onTheSPDDetailsPage.iClickOnTab("List View");
			When.onTheSPDDetailsPage.inListViewIClickOnExpand();
			Then.onTheSPDDetailsPage.iShouldSeeCorrectNumberOfServicePlanItems(1);
		});

		opaTest("In List view. I should see correct component ID of service plan item.", function (Given, When, Then) {
			Then.onTheSPDDetailsPage.inListViewIShouldSeeCorrectComponentId(sComponentID);
		});

		opaTest("In List view. I should see correct component description of service plan item.", function (Given, When, Then) {
			Then.onTheSPDDetailsPage.inListViewIShouldSeeCorrectComponentDescription(sComponentDescription);
		});

		opaTest("In List view. I should see correct component effort of service plan item.", function (Given, When, Then) {
			Then.onTheSPDDetailsPage.inListViewIShouldSeeCorrectEffort(2);
		});

		/*opaTest("In List view. I should see correct citem number of service plan item.", function (Given, When, Then) {
			//Then.onTheSPDDetailsPage.inListViewIShouldSeeCorrectComponentType(sComponentType);
			Then.onTheSPDDetailsPage.inListViewIShouldSeeCorrectComponentNumber(sItemNumber);
		});*/

		opaTest("In List view. I should see correct start and end date of service plan item.", function (Given, When, Then) {
			Then.onTheSPDDetailsPage.inListViewIShouldSeeCorrectStartDate(sServicePlanItemStartDate);
			Then.onTheSPDDetailsPage.inListViewIShouldSeeCorrectEndDate(sServicePlanItemEndDate);
		});

		opaTest("I switch to General Information tab. I should see the fields created at, created by and description with correct data.",
			function (Given, When, Then) {
				When.onTheSPDDetailsPage.iClickOnTab("General Information");
				Then.onTheSPDDetailsPage.inGeneralInformationTabIShouldSeeCorrectCreatedAt(sCreatedAt);
				Then.onTheSPDDetailsPage.inGeneralInformationTabIShouldSeeCorrectCreatedBy(sCreatedBy);
				Then.onTheSPDDetailsPage.inGeneralInformationTabIShouldSeeCorrectDescription(sServicePlanDescription);
				Then.iTeardownMyApp();
			});

	});