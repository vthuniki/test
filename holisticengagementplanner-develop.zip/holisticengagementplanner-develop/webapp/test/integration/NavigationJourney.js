	/*global QUnit*/

	sap.ui.define([
		"sap/ui/test/opaQunit",
		"./pages/Home",
		"./pages/ProjectDetails"
	], function (opaTest) {
		"use strict";
		QUnit.module("Navigation Journey");

		opaTest("Should see the initial page of the app", function (Given, When, Then) {
			// Arrangements
			Given.iStartMyApp();

			// Assertions
			Then.onTheAppPage.iShouldSeeTheApp();
			Then.onTheAppPage.iShouldSeeTitle();
			//Then.onTheAppPage.engagementsShouldBeSelected();   
			
			Then.iTeardownMyApp();
		});
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*
		opaTest("I switch to All Projects. I should see 5 projects", function (Given, When, Then) {
			When.onTheAppPage.iOpenProjectsDropDownList();
			When.onTheAppPage.iSwitchToAllProjects();
			Then.onTheAppPage.iShouldSeeProjectsTable(5);
		});
		
		opaTest("I click on project "+sProjectId+". I should be navigated to the project details page.", function (Given, When, Then) {
			When.onTheAppPage.iClickOnProject(sProjectId);
			Then.onTheProjectDetailsPage.iShouldSeeProjectDetailsPage();
		});
		
		opaTest("I click on project details tab. I should correct project name and description.", function (Given, When, Then) {
			When.onTheProjectDetailsPage.iClickOnTab("Project Details");
			Then.onTheProjectDetailsPage.iShouldSeeCorrectProjectName(sProjectName);
			Then.onTheProjectDetailsPage.iShouldSeeCorrectProjectDescription(sProjectDescription);
		});
		
		opaTest("I click on reference objects tab. I should the correct reference object.", function (Given, When, Then) {
			When.onTheProjectDetailsPage.iClickOnTab("Reference Objects");
			Then.onTheProjectDetailsPage.iShouldSeeCorrectReferenceObject(sIbaseComponent);
		});
		
		opaTest("I click on attachments tab. I should the correct attachment.", function (Given, When, Then) {
			When.onTheProjectDetailsPage.iClickOnTab("Attachments");
			Then.onTheProjectDetailsPage.iShouldSeeCorrectAttachment(sAttachedFile);

			//Cleanup
			Then.iTeardownMyApp();
		});*/
	});