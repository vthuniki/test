/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit"
], function (opaTest) {
	"use strict";

	QUnit.module("Project Details Journey");

	opaTest("Navigate to Project Details Page", function (Given, When, Then) {
		var sProjectID = "20002897";
		var sProjectName = "Project for Integration Tests";
		// Arrangements
		Given.iStartMyApp();

		// Actions
		When.onTheAppPage.iSwitchToProjectsSubpage();
		When.onTheAppPage.iOpenProjectsDropDownList();
		When.onTheAppPage.iSwitchToAllProjects();
		When.onTheAppPage.iClickOnProject(sProjectName);

		// Assertions
		Then.onTheProjectDetailsPage.iShouldSeeCorrectProjectNameID(sProjectName + " (" + sProjectID + ")");

	});

	// Switch to Tab "Service Plan Drafts"
	opaTest("Navigate to Tab 'Service Plan Drafts'", function (Given, When, Then) {

		When.onTheProjectDetailsPage.iClickOnTab("Service Plan Drafts BETA");

		Then.onTheProjectDetailsPage.iShouldSeeServicePlanDraftsTable();

	});

	opaTest("Check Table Columns of tab 'Service Plan Drafts'", function (Given, When, Then) {
		var columns = [{
			id: "Name",
			width: "25%",
			visible: true,
			index: 1
		}, {
			id: "Description",
			width: "25%",
			visible: true,
			index: 2
		}, {
			id: "CreatedAt",
			visible: true,
			index: 3
		}, {
			id: "CreatedBy",
			visible: true,
			index: 4
		}, {
			id: "ChangedAt",
			visible: true,
			index: 5,
			sortIndicator: "Descending"
		}, {
			id: "ChangedBy",
			visible: true,
			index: 6
		}, {
			id: "Actions",
			visible: true,
			width: "6rem",
			index: 7
		}];

		//Assertions
		columns.forEach(function (column, index) {
			if (column.width) Then.onTheProjectDetailsPage.iShouldSeeColumnWithCorrectWidth(column.id, column.width);
			if (column.visible !== undefined) Then.onTheProjectDetailsPage.iSeeTheCorrectColumn(column.id, column.visible);
			if (column.index !== undefined) Then.onTheProjectDetailsPage.iShouldSeeColumnInCorrectOrder(column.id, column.index);
			if (column.sortIndicator !== undefined) Then.onTheProjectDetailsPage.iShouldSeeColumnCorrectlySorted(column.id, column.sortIndicator);
		});
		// Cleanup
		Then.iTeardownMyApp();
	});

});