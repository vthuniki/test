/*global QUnit*/

sap.ui.define([
		"sap/ui/test/opaQunit",
		"./pages/Home",
		"./pages/NewEngagement"
], function(opaTest) {
	"use strict";

	QUnit.module("New Engagement Journey");

	opaTest(`Button "Add Engagement" on should lead to the "Create Engagement" Form` , function(Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();

		// Actions
		When.onTheAppPage.iClickOnAddEngagement();
		
		// Assertions
		Then.onNewEngagementPage.iShouldSeeTitle();

	});
	
	opaTest("Should be able to enter an engagement Name", function (Given, When, Then){
		
		When.onNewEngagementPage.iEnterTextTextArea_engagementNameField("Test Description");
		
		Then.onNewEngagementPage.iSeeValueOnEngagementNameField("Test Description");

	});
	
	opaTest("When Reason is changed to Global Engagement, Parent Engagement Field should be disabled", function (Given, When, Then){
		
		When.onNewEngagementPage.iChangeEngagementReason( "globalEng" );
		
		Then.onNewEngagementPage.iSeeParentEngagementEnabled(false);

	});
	
	opaTest("When Reason is changed to Engagement, Parent Engagement Field should be enabled", function (Given, When, Then){
		
		When.onNewEngagementPage.iChangeEngagementReason( "engagement" );
		
		Then.onNewEngagementPage.iSeeParentEngagementEnabled(true);

	});
	
	opaTest("When I navigate back to 'Home' and again to 'Create Engagement', all data should be cleared", function (Given, When, Then){
		
		When.onNewEngagementPage.iEnterData();
		When.onNewEngagementPage.iClickOnHome();
		When.onTheAppPage.iClickOnAddEngagement();
		
		Then.onNewEngagementPage.iShouldSeeTitle();
		Then.onNewEngagementPage.iShouldSeeAnEmptyForm();
		
	});
	
	/*opaTest(`When typing a customer number it should't be overwritten by backend respones`, function (Given, When, Then){
		
		When.onNewEngagementPage.iEnterTextInput_customerNumber("125599");
		
		Then.onNewEngagementPage.iSeeTheValueITypedInCustomerNoField("125599");

	});*/

	
	opaTest(`Cancel button should lead back to home screen`, function (Given, When, Then) {
		When.onNewEngagementPage.iPressButton_btnCancel();
		
		Then.onTheAppPage.iShouldSeeTitle().and.
		iTeardownMyApp();
		
	});

});