sap.ui.define([
	"sap/ui/test/Opa5",
	'sap/ui/test/actions/Press',
	'sap/ui/test/matchers/Properties',
	'sap/ui/test/matchers/AggregationLengthEquals'
], function (Opa5, Press, Properties, AggregationLengthEquals) {
	"use strict";
	var sViewName = "Home/Home";
	Opa5.createPageObjects({
		onTheAppPage: {

			actions: {
				iOpenProjectsDropDownList: function () {
					return this.waitFor({
						id: "ProjectSearchRange",
						viewName: sViewName,
						actions: new Press(),
						errorMessage: "Did not find the arrow"
					});
				},

				iSwitchToAllProjects: function () {
					return this.waitFor({
						controlType: "sap.ui.core.Item",
						matchers: new Properties({
							text: "All Projects"
						}),
						actions: new Press(),
						errorMessage: "Did not find All Projects in the dropdown box"
					});
				},

				iClickOnProject: function (sProjectId) {
					return this.waitFor({
						controlType: "sap.m.Text",
						viewName: sViewName,
						matchers: new Properties({
							text: sProjectId
						}),
						actions: new Press(),
						errorMessage: "Did not find the project with ID: " + sProjectId
					});
				},

				iClickOnAddEngagement: function () {
					return this.waitFor({
						id: "btnAddEngagement",
						viewName: sViewName,
						actions: new Press(),
						errorMessage: 'Did not find button "Add Engagement" on Home Page.'
					});
				},
                iSwitchToProjectsSubpage: function () {
					return this.waitFor({
						id: "btnProjects",
						viewName: sViewName,
						actions: new Press(),
						errorMessage: 'Did not find segmented Button btnProjects'
					});
				},

				iSwitchToProjectsEnagagements: function (sText) {
					this.waitFor({
						controlType: "sap.m.Button",
						viewName: sViewName,
						properties: {
							text: sText
						},
						actions: new Press()
					});
				},

				iOpenProjectsEngagementsDropDown: function () {
					this.waitFor({
						id: "ProjectSearchRange",
						viewName: sViewName,
						actions: new Press({
							idSuffix: "arrow"
						})
					});
				},

				iSelectAllMyProjectsEngagements: function (sText) {
					// this.waitFor({
					// 	id: "ProjectSearchRange",
					// 	viewName: sViewName,
					// 	actions: new Press({
					// 		idSuffix: "arrow"
					// 	})
					// });

					this.waitFor({
						controlType: "sap.ui.core.Item",
						viewName: sViewName,
						properties: {
							text: sText
						},
						searchOpenDialogs: true,
						actions: new Press()
					});
				},

				iClickOnProjectInList: function (sProjectName) {
					this.waitFor({
						controlType: "sap.m.ColumnListItem",
						viewName: sViewName,
						properties: {
							type: "Active"
						},
						descendant: {
							controlType: "sap.m.Text",
							viewName: sViewName,
							properties: {
								text: sProjectName
							}
						},
						actions: new Press()
					});
				}

			},

			assertions: {

				iShouldSeeTheApp: function () {
					return this.waitFor({
						controlType: "sap.m.App",
						viewName: "App",
						success: function () {
							Opa5.assert.ok(true, "The Home view is displayed");
						},
						errorMessage: "Did not find the Home view"
					});
				},

				iShouldSeeTitle: function () {
					return this.waitFor({
						controlType: "sap.m.Title",
						viewName: sViewName,
						i18NText: {
							propertyName: "text",
							key: "Home.Title"
						},
						success: function () {
							Opa5.assert.ok(true, "The page title is displayed");
						},
						errorMessage: "Did not find the Page title"
					});
				},

				// TODO: this test is not correct.
				engagementsShouldBeSelected: function () {
					return this.waitFor({
						controlType: "sap.m.SegmentedButton",
						viewName: sViewName,
						matchers: sap.ui.test.matchers.Visible,
						success: function (segmentedButton) {
							Opa5.assert.ok(segmentedButton.selectedKey === "engagements", "Engagement is selected in segmented button");
							//Opa5.assert.ok(true, "Engagement is selected in segmented button");
						},
						errorMessage: "Engagements is not selected in segmented button"
					});
				},

				iShouldSeeProjectsTable: function (iNumberOfProjects) {
					this.waitFor({
						id: "projectsTable",
						viewName: sViewName,
						matchers: new AggregationLengthEquals({
							name: "rows",
							length: iNumberOfProjects
						}),
						success: function () {
							Opa5.assert.ok(true, "The table contains " + iNumberOfProjects + " projects.");
						},
						errorMessage: "The table does not contain all projects."
					});
				}
			}
		}
	});

});