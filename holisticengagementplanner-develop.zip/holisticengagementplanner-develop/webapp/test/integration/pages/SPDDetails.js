sap.ui.define([
	"sap/ui/test/Opa5",
	'sap/ui/test/actions/Press',
	'sap/ui/test/actions/EnterText',
	'sap/ui/test/matchers/Properties',
	'sap/ui/test/matchers/AggregationLengthEquals',
	'sap/ui/test/matchers/I18NText'
], function (Opa5, Press, EnterText, Properties, AggregationLengthEquals, I18NText) {
	"use strict";
	Opa5.createPageObjects({
		onTheSPDDetailsPage: {

			actions: {

				iClickOnTab: function (sTabName) {
					this.waitFor({
						controlType: "sap.m.Button",
						viewName: "SPD/SPDDetails",
						properties: {
							text: sTabName
						},
						actions: new Press({
							idSuffix: "BDI-content"
						})
					});
				},

				iClickOnEdit: function () {
					this.waitFor({
						controlType: "sap.m.Button",
						viewName: "SPD/SPDDetails",
						i18NText: {
							propertyName: "text",
							key: "Edit"
						},
						actions: new Press({
							idSuffix: "inner"
						})
					});
				},

				iClickOnCancel: function () {
					this.waitFor({
						controlType: "sap.m.Button",
						viewName: "SPD/SPDDetails",
						i18NText: {
							propertyName: "text",
							key: "Cancel"
						},
						actions: new Press({
							idSuffix: "BDI-content"
						})
					});
				},

				inDialogIClickOnCanel: function () {
					this.waitFor({
						controlType: "sap.m.Button",
						properties: {
							text: "Yes"
						},
						searchOpenDialogs: true,
						actions: new Press({
							idSuffix: "inner"
						})
					});
				},

				inListViewIClickOnExpand: function () {
					this.waitFor({
						controlType: "sap.ui.core.Icon",
						viewName: "SPD/SPDDetails",
						properties: {
							src: {
								regex: {
									source: "expand\\-group"
								}
							}
						},
						actions: new Press()
					});
				}
			},

			assertions: {

				iShouldSeeCorrectPageTitle: function (sTitle) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "SPD/SPDDetails",
						matchers: new Properties({
							text: sTitle
						}),
						success: function () {
							Opa5.assert.ok(true, "The displayed page title: " + sTitle + " is correct.");
						},
						errorMessage: "The displayed page title is not correct."
					});
				},

				iShouldSeeCorrectCustomer: function (sCustomer) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "",
							propertyPath: "/CaseDetails/CustomerName",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: sCustomer
						}),
						success: function () {
							Opa5.assert.ok(true, "The customer name and ID: " + sCustomer + " is shown.");
						},
						errorMessage: "The customer name and ID are not correct."
					});
				},

				iShouldSeeCorrectServicePlanName: function (sServicePlanName) {
					this.waitFor({
						controlType: "sap.m.Link",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "",
							propertyPath: "/Header/Name",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							enabled: false
						}),
						success: function () {
							Opa5.assert.ok(true, "The service plan name: " + sServicePlanName + " is shown.");
						},
						errorMessage: "The service plan name is not correct."
					});
				},

				iShouldSeeCorrectServicePlanItem: function (sTitle) {
					this.waitFor({
						controlType: "sap.m.Title",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "/phases/0/items/0",
							propertyPath: "ComponentDescr",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: sTitle
						}),
						success: function () {
							Opa5.assert.ok(true, "The displayed service plan item: " + sTitle + " is correct.");
						},
						errorMessage: "The displayed service plan item is not correct."
					});
				},

				iShouldSeeCorrectNumberOfServicePlanItems: function (iNum) {
					this.waitFor({
						controlType: "sap.m.Title",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "",
							propertyPath: "/iNumberOfItemsPhaseView",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: "Service Plan Items (" + iNum + ")"
						}),
						success: function () {
							Opa5.assert.ok(true, "The number of service plan items: " + iNum + " is correct.");
						},
						errorMessage: "The number of service plan items is not correct."
					});
				},

				iShouldSeeCorrectEffortOfServicePlanItem: function (sEffort) {
					this.waitFor({
						controlType: "sap.m.Label",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "/phases/0/items/0",
							propertyPath: "EffortTotal",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: "Total Effort: " + sEffort + ".000"
						}),
						success: function () {
							Opa5.assert.ok(true, "The effort of service plan items is correct.");
						},
						errorMessage: "The effort of service plan items is not correct."
					});
				},

				iShouldSeeCorrectStartDateOfServicePlanItem: function (sDate) {
					this.waitFor({
						controlType: "sap.m.Label",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "/phases/0/items/0",
							propertyPath: "StartDate",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: sDate
						}),
						success: function () {
							Opa5.assert.ok(true, "The start date of service plan items is correct.");
						},
						errorMessage: "The start date of service plan items is not correct."
					});
				},

				iShouldSeeCorrectEndDateOfServicePlanItem: function (sDate) {
					this.waitFor({
						controlType: "sap.m.Label",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "/phases/0/items/0",
							propertyPath: "EndDate",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: sDate
						}),
						success: function () {
							Opa5.assert.ok(true, "The end date of service plan items is correct.");
						},
						errorMessage: "The end date of service plan items is not correct."
					});
				},

				iShouldSeeStartDateOfServicePlanItemEditable: function (bEditable) {
					this.waitFor({
						controlType: "sap.m.DatePicker",
						viewName: "SPD/SPDDetails",
						i18NText: {
							propertyName: "tooltip",
							key: "SPDDetails.PhaseView.StartDate"
						},
						matchers: new Properties({
							editable: bEditable
						}),
						success: function () {
							Opa5.assert.ok(true, "The start date of the service plan item in Edit mode is editable.");
						},
						errorMessage: "The start date of service plan item in Edit mode is not editable."
					});
				},

				iShouldSeeEndDateOfServicePlanItemable: function (bEditable) {
					this.waitFor({
						controlType: "sap.m.DatePicker",
						viewName: "SPD/SPDDetails",
						i18NText: {
							propertyName: "tooltip",
							key: "SPDDetails.PhaseView.EndDate"
						},
						matchers: new Properties({
							editable: bEditable
						}),
						success: function () {
							Opa5.assert.ok(true, "The end date of the service plan item in Edit mode is editable.");
						},
						errorMessage: "The end date of service plan item in Edit mode is not editable."
					});
				},

				iShouldSeeEffortOfServicePlanItemEditable: function (bEditable) {
					this.waitFor({
						controlType: "sap.m.internal.NumericInput",
						viewName: "SPD/SPDDetails",
						properties: {
							value: "2.000"
						},
						matchers: new Properties({
							editable: bEditable
						}),
						success: function () {
							Opa5.assert.ok(true, "The effort of service plan item in Edit mode is editable.");
						},
						errorMessage: "The effort of service plan item in Edit mode is not editable."
					});
				},

				iShouldSeeDeleteIcon: function () {
					this.waitFor({
						controlType: "sap.ui.core.Icon",
						viewName: "SPD/SPDDetails",
						properties: {
							src: {
								regex: {
									source: "delete"
								}
							}
						},
						success: function () {
							Opa5.assert.ok(true, "The delete icon is shown.");
						},
						errorMessage: "The delete icon is not shown."
					});
				},

				iShouldSeeDialogDiscardChanges: function () {
					this.waitFor({
						controlType: "sap.m.Text",
						properties: {
							text: "All of your changes will be lost, unless you press \"Save\". \nAre you sure you wish to discard all changes?"
						},
						searchOpenDialogs: true,
						matchers: {
							ancestor: {
								controlType: "sap.m.Dialog",
								properties: {
									icon: "sap-icon://question-mark"
								},
								searchOpenDialogs: true
							}
						},
						success: function () {
							Opa5.assert.ok(true, "The dialog is shown.");
						},
						errorMessage: "The dialog is not shown."
					});
				},

				inListViewIShouldSeeCorrectComponentId: function (sComponentId) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "/phases/0/items/0",
							propertyPath: "ComponentID",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: sComponentId
						}),
						success: function () {
							Opa5.assert.ok(true, "The component ID " + sComponentId + " in service plan item is shown.");
						},
						errorMessage: "The component ID " + sComponentId + " in service plan item is not shown."
					});
				},

				inListViewIShouldSeeCorrectComponentDescription: function (sDescription) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "/phases/0/items/0",
							propertyPath: "ComponentDescr",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: sDescription
						}),
						success: function () {
							Opa5.assert.ok(true, "The component description " + sDescription + " in service plan item is shown.");
						},
						errorMessage: "The component description " + sDescription + " in service plan item is not shown."
					});
				},

				inListViewIShouldSeeCorrectEffort: function (iEffort) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "/phases/0/items/0",
							propertyPath: "EffortTotal",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: iEffort + ".000"
						}),
						success: function () {
							Opa5.assert.ok(true, "The effort " + iEffort + ".000 in service plan item is shown.");
						},
						errorMessage: "The component effort in service plan item is not shown."
					});
				},

				inListViewIShouldSeeCorrectComponentType: function (sType) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "/phases/0/items/0",
							propertyPath: "ItemTypeText",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: sType
						}),
						success: function () {
							Opa5.assert.ok(true, "The component type " + sType + " in service plan item is shown.");
						},
						errorMessage: "The component type in service plan item is not shown."
					});
				},

				inListViewIShouldSeeCorrectComponentNumber: function (sItemNumber) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "/phases/0/items/0",
							propertyPath: "ItemNo",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: sItemNumber
						}),
						success: function () {
							Opa5.assert.ok(true, "The component number " + sItemNumber + " in service plan item is shown.");
						},
						errorMessage: "The component number in service plan item is not shown."
					});
				},

				inListViewIShouldSeeCorrectStartDate: function (sDate) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "/phases/0/items/0",
							propertyPath: "StartDate",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: sDate
						}),
						success: function () {
							Opa5.assert.ok(true, "The start date " + sDate + " in service plan item is shown.");
						},
						errorMessage: "The start date in service plan item is not shown."
					});
				},

				inListViewIShouldSeeCorrectEndDate: function (sDate) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "/phases/0/items/0",
							propertyPath: "EndDate",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: sDate
						}),
						success: function () {
							Opa5.assert.ok(true, "The end date " + sDate + " in service plan item is shown.");
						},
						errorMessage: "The end date in service plan item is not shown."
					});
				},

				inGeneralInformationTabIShouldSeeCorrectCreatedAt: function (sDate) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "SPD/SPDDetails",
						matchers: new Properties({
							text: "Created At: " + sDate
						}),
						success: function () {
							Opa5.assert.ok(true, "The field created at: " + sDate + " in service plan item is shown.");
						},
						errorMessage: "The field created at is not shown."
					});
				},

				inGeneralInformationTabIShouldSeeCorrectCreatedBy: function (sName) {
					this.waitFor({
						controlType: "sap.m.ObjectAttribute",
						viewName: "SPD/SPDDetails",
						i18NText: {
							propertyName: "title",
							key: "SPDDetails.CreatedBy"
						},
						matchers: new Properties({
							text: sName
						}),
						success: function () {
							Opa5.assert.ok(true, "The field created by: " + sName + " in service plan item is shown.");
						},
						errorMessage: "The field created by is not shown."
					});
				},

				inGeneralInformationTabIShouldSeeCorrectDescription: function (sDescription) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "SPD/SPDDetails",
						bindingPath: {
							path: "",
							propertyPath: "/Header/Description",
							modelName: "spdDetails"
						},
						matchers: new Properties({
							text: sDescription
						}),
						success: function () {
							Opa5.assert.ok(true, "The field Description: " + sDescription + " in service plan item is shown.");
						},
						errorMessage: "The field Description is not shown."
					});
				}
			}
		}
	});

});
