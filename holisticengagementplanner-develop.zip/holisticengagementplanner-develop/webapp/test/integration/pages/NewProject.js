sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/actions/EnterText"
], function (Opa5, Press, EnterText) {
	"use strict";

	Opa5.createPageObjects({
		onMyPageUnderTest: {
			actions: {
				iPressHome: function () {
					return this.waitFor({
						id: "MISSING_ID",
						viewName: "NewProject",
						actions: new Press(),
						errorMessage: "Was not able to find the control with the id MISSING_ID"
					});
				},
				iPressButton_btnSave: function () {
					return this.waitFor({
						id: "btnSave",
						viewName: "NewProject",
						actions: new Press(),
						errorMessage: "Was not able to find the control with the id btnSave"
					});
				},
				iPressButton_btnCancel: function () {
					return this.waitFor({
						id: "btnCancel",
						viewName: "NewProject",
						actions: new Press(),
						errorMessage: "Was not able to find the control with the id btnCancel"
					});
				},
				iEnterTextInput_customerNumber: function () {
					return this.waitFor({
						id: "customerNumber",
						viewName: "NewProject",
						actions: new EnterText({
							text: "Text to enter in the control"
						}),
						errorMessage: "Was not able to find the control with the id customerNumber"
					});
				},
				iEnterTextInput_customerName: function () {
					return this.waitFor({
						id: "customerName",
						viewName: "NewProject",
						actions: new EnterText({
							text: "Text to enter in the control"
						}),
						errorMessage: "Was not able to find the control with the id customerName"
					});
				},
				iEnterTextInput_MISSING_ID: function () {
					return this.waitFor({
						id: "MISSING_ID",
						viewName: "NewProject",
						actions: new EnterText({
							text: "Text to enter in the control"
						}),
						errorMessage: "Was not able to find the control with the id MISSING_ID"
					});
				},
				iEnterTextInput_MISSING_ID: function () {
					return this.waitFor({
						id: "MISSING_ID",
						viewName: "NewProject",
						actions: new EnterText({
							text: "Text to enter in the control"
						}),
						errorMessage: "Was not able to find the control with the id MISSING_ID"
					});
				},
				iEnterTextTextArea_projectNameField: function () {
					return this.waitFor({
						id: "projectNameField",
						viewName: "NewProject",
						actions: new EnterText({
							text: "Text to enter in the control"
						}),
						errorMessage: "Was not able to find the control with the id projectNameField"
					});
				},
				iEnterTextTextArea_projectDescription: function () {
					return this.waitFor({
						id: "projectDescription",
						viewName: "NewProject",
						actions: new EnterText({
							text: "Text to enter in the control"
						}),
						errorMessage: "Was not able to find the control with the id projectDescription"
					});
				},
				iEnterTextInput_engagementCase: function () {
					return this.waitFor({
						id: "engagementCase",
						viewName: "NewProject",
						actions: new EnterText({
							text: "Text to enter in the control"
						}),
						errorMessage: "Was not able to find the control with the id engagementCase"
					});
				},
				iPressButton_MISSING_ID: function () {
					return this.waitFor({
						id: "MISSING_ID",
						viewName: "NewProject",
						actions: new Press(),
						errorMessage: "Was not able to find the control with the id MISSING_ID"
					});
				},
				iPressTable_phasesTable: function () {
					return this.waitFor({
						id: "phasesTable",
						viewName: "NewProject",
						actions: new Press(),
						errorMessage: "Was not able to find the control with the id phasesTable"
					});
				},
				iPressButton_messagePopoverButton: function () {
					return this.waitFor({
						id: "messagePopoverButton",
						viewName: "NewProject",
						actions: new Press(),
						errorMessage: "Was not able to find the control with the id messagePopoverButton"
					});
				},
				iPressButton_MISSING_ID: function () {
					return this.waitFor({
						id: "MISSING_ID",
						viewName: "NewProject",
						actions: new Press(),
						errorMessage: "Was not able to find the control with the id MISSING_ID"
					});
				}
			},
			assertions: {
				iDoMyAssertion: function () {
					return this.waitFor({
						id: "ControlId",
						viewName: "NewProject",
						success: function () {
							Opa5.assert.ok(false, "Implement me");
						},
						errorMessage: "Was not able to find the control with the id ControlId"
					});
				}
			}
		}
	});
});