sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/matchers/Properties",
    "sap/ui/test/matchers/Ancestor"
], function (Opa5, Press, EnterText, Properties, Ancestor) {
	"use strict";
	var sViewName = "NewEngagement/NewEngagement";
	Opa5.createPageObjects({
		onNewEngagementPage: {
			actions: {
				iPressLink_MISSING_ID: function () {
					return this.waitFor({
						id: "MISSING_ID",
						viewName: sViewName,
						actions: new Press(),
						errorMessage: "Was not able to find the control with the id MISSING_ID"
					});
				},
				iPressButton_btnSave: function () {
					return this.waitFor({
						id: "btnSave",
						viewName: sViewName,
						actions: new Press(),
						errorMessage: "Was not able to find the control with the id btnSave"
					});
				},
				iPressButton_btnCancel: function () {
					return this.waitFor({
						id: "btnCancel",
						viewName: sViewName,
						actions: new Press(),
						errorMessage: "Was not able to find the control with the id btnCancel"
					});
				},
				iEnterTextInput_customerNumber: function (value) {
					return this.waitFor({
						id: "customerNumber",
						viewName: sViewName,
						autoWait: true,
						actions:  new EnterText({
							text: value ? value : 152299
						}),
						success: function () {},
						errorMessage: "Was not able to find the control with the id customerNumber"
					});
				},
				iEnterTextInput_customerName: function () {
					return this.waitFor({
						id: "customerName",
						viewName: sViewName,
						actions: new EnterText({
							text: "Text to enter in the control"
						}),
						errorMessage: "Was not able to find the control with the id customerName"
					});
				},
				iEnterTextInput_MISSING_ID: function () {
					return this.waitFor({
						id: "MISSING_ID",
						viewName: sViewName,
						actions: new EnterText({
							text: "Text to enter in the control"
						}),
						errorMessage: "Was not able to find the control with the id MISSING_ID"
					});
				},

				iEnterTextTextArea_engagementNameField: function (value) {
					return this.waitFor({
						id: "engagementNameField",
						viewName: sViewName,
						actions: new EnterText({
							text: value
						}),
						errorMessage: "Was not able to find the control with the id engagementNameField"
					});
				},
				iEnterTextTextArea_engagementDescription: function () {
					return this.waitFor({
						id: "engagementDescription",
						viewName: sViewName,
						actions: new EnterText({
							text: "Text to enter in the control"
						}),
						errorMessage: "Was not able to find the control with the id engagementDescription"
					});
				},
				iEnterTextInput_engagementCase: function () {
					return this.waitFor({
						id: "engagementCase",
						viewName: sViewName,
						actions: new EnterText({
							text: "Text to enter in the control"
						}),
						errorMessage: "Was not able to find the control with the id engagementCase"
					});
				},
				iPressButton_messagePopoverButton: function () {
					return this.waitFor({
						id: "messagePopoverButton",
						viewName: sViewName,
						actions: new Press(),
						errorMessage: "Was not able to find the control with the id messagePopoverButton"
					});
				},
				iChangeEngagementReason: function(key){
					return this.waitFor({
						id: "reason",
						viewName: sViewName,
						actions: new Press(),
						success: function(oSelect) {
							oSelect.setSelectedKey(key);
							oSelect.fireChange();
			                /*this.waitFor({
			                    controlType: "sap.ui.core.Item",
			                    matchers: [
			                        new Ancestor(oSelect),
			                        //new Properties( { value: oValue } )
			                    ],
			                    actions: new Press(),
                    		errorMessage: `Cannot select '${ oValue }'' as reason.`
			                });*/
						},
						errorMessage: "Was not able to find the control to select the reason."
					});
				},
				iEnterData: function () {
					this.iEnterTextTextArea_engagementNameField("TEST DESCRIPTION");
					//this.iChangeEngagementReason("globalEng");
				},
				
				iClickOnHome: function() {
					return this.waitFor({
						viewName: sViewName,
						//controlType: "sap.uxap.BreadCrumbs",
						i18NText: {
							propertyName: "text",
							key: "Home.Title"
						},
						actions: new Press(),
						errorMessage: "Was not able to find the control with the Breadcrumb home"
					});
				}
			},
			assertions: {
				iDoMyAssertion: function () {
					return this.waitFor({
						id: "ControlId",
						viewName: sViewName,
						success: function () {
							Opa5.assert.ok(false, "Implement me");
						},
						errorMessage: "Was not able to find the control with the id ControlId"
					});
				},
				iSeeTheValueITypedInCustomerNoField : function(checkValue) {
					return this.waitFor({
						id: "customerNumber",
						viewName: sViewName,
						success: function(oInput) {
							Opa5.assert.ok(oInput.getValue() === checkValue, "BP ID Field doesn't show correct value.");
						},
						errorMessage: `The field "BP ID" does not have the correct value. Input was ${checkValue}.`
					});
				},
				iSeeValueOnEngagementNameField : function(checkValue) {
					return this.waitFor({
						id: "engagementNameField",
						viewName: sViewName,
						success: function(oInput) {
							Opa5.assert.ok(oInput.getValue() === checkValue, "Engagement Name Field doesn't show correct value.");
						},
						errorMessage: `The field "Engagement Name" does not have the correct value. Input was ${checkValue}.`
					});
				},
				iShouldSeeTitle : function () {
					return this.waitFor({
						controlType: "sap.m.Title",
						viewName: sViewName,
						i18NText: {
							propertyName: "text",
							key: "CreateEngagement.Title"
						},
						success: function () {
							Opa5.assert.ok(true, "The page title is displayed");
						},
						errorMessage: "Did not find the Page title"
					});
				},
				iSeeParentEngagementEnabled : function(checkValue){
					var errorText = checkValue ? "enabled" : "disabled";
					return this.waitFor({
						id: "engagementCase",
						viewName: sViewName,
						enabled: checkValue,
						success: function(oInput) {
							Opa5.assert.ok( (oInput.getEnabled() === checkValue), `Field Parent Engagement should be ${errorText}`);
						},
						errorMessage: `The field "Parent Engagement" was not found. It should be ${errorText}`
					});
				},
				iShouldSeeAnEmptyForm: function() {
					this.iSeeValueOnEngagementNameField("");
				}
			}
		}
	});
});