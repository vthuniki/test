sap.ui.define([
	"sap/ui/test/Opa5",
	'sap/ui/test/actions/Press',
	'sap/ui/test/actions/EnterText',
	'sap/ui/test/matchers/Properties',
	'sap/ui/test/matchers/AggregationLengthEquals',
	'sap/ui/test/matchers/I18NText'
], function (Opa5, Press, EnterText, Properties, AggregationLengthEquals, I18NText) {
	"use strict";
	var sViewName = "Details/Project/ProjectDetails";
	var sectionServicePlanDrafts = "Details.Project.subview.SectionServicePlan";
	Opa5.createPageObjects({
		onTheProjectDetailsPage: {

			actions: {

				iClickOnTab: function (sTab) {
					this.waitFor({
						controlType: "sap.m.Button",
						viewName: sViewName,
						properties: {
							text: sTab
						},
						actions: new Press({
							idSuffix: "BDI-content"
						})
					});
				},

				iClickOnAddServicePlan: function () {
					this.waitFor({
						controlType: "sap.m.Button",
						viewName: sViewName,
						i18NText: {
							propertyName: "text",
							key: "ProjectSPD.AddSPD"
						},
						actions: new Press({
							idSuffix: "BDI-content"
						})
					});
				},

				iEnterServicePlanName: function (sServicePlanName) {
					this.waitFor({
						controlType: "sap.m.Input",
						viewName: "Details.Project.subview.SectionServicePlan",
						labelFor: {
							text: "Name"
						},
						searchOpenDialogs: true,
						actions: new EnterText({
							idSuffix: "inner",
							text: sServicePlanName
						})
					});
				},

				iEnterServicePlanDescription: function (sServicePlanDescription) {
					this.waitFor({
						controlType: "sap.m.TextArea",
						viewName: "Details.Project.subview.SectionServicePlan",
						labelFor: {
							text: "Description"
						},
						searchOpenDialogs: true,
						actions: new EnterText({
							idSuffix: "inner",
							text: sServicePlanDescription
						})
					});
				},

				iNavigateToServicePlanItems: function () {
					this.waitFor({
						controlType: "sap.m.ColumnListItem",
						viewName: "Details.Project.subview.SectionServicePlan",
						properties: {
							type: "Navigation"
						},
						actions: new Press()
					});
				},

				iCancelCreatingServicePlan: function () {
					this.waitFor({
						controlType: "sap.m.Button",
						viewName: "Details.Project.subview.SectionServicePlan",
						i18NText: {
							propertyName: "text",
							key: "Cancel"
						},
						searchOpenDialogs: true,
						actions: new Press({
							idSuffix: "content"
						})
					});
				},

			},

			assertions: {

				iShouldSeeCorrectProjectNameID: function (sProjectNameID) {
					this.waitFor({
						controlType: "sap.m.Link",
						viewName: sViewName,
						matchers: new Properties({
							text: sProjectNameID
						}),
						success: function () {
							Opa5.assert.ok(true, "The displayed project name and ID " + sProjectNameID + " are correct.");
						},
						errorMessage: "The displayed project name is not correct."
					});
				},

				iShouldSeeCorrectProjectDescription: function (sProjectDescription) {
					return this.waitFor({
						controlType: "sap.m.Text",
						viewName: sViewName,
						matchers: new Properties({
							text: sProjectDescription
						}),
						success: function () {
							Opa5.assert.ok(true, "The displayed project description: " + sProjectDescription + " is correct.");
						},
						errorMessage: "The displayed project description is not correct."
					});
				},

				iShouldSeeCorrectReferenceObject: function (sIbaseComponent) {
					return this.waitFor({
						controlType: "sap.m.Text",
						viewName: sViewName,
						matchers: new Properties({
							text: sIbaseComponent
						}),
						success: function () {
							Opa5.assert.ok(true, "The displayed reference object with Ibase Component: " + sIbaseComponent + " is correct.");
						},
						errorMessage: "The displayed reference object is not correct."
					});
				},

				iShouldSeeCorrectAttachment: function (sAttachedFile) {
					return this.waitFor({
						controlType: "sap.m.Link",
						matchers: new Properties({
							text: sAttachedFile
						}),
						success: function () {
							Opa5.assert.ok(true, "The displayed attached file: " + sAttachedFile + " is correct.");
						},
						errorMessage: "The displayed attached file is not correct."
					});
				},
                //	onSectionServicePlanDrafts: {
				iShouldSeeServicePlanDraftsTable: function () {
					return this.waitFor({
						id: "servicePlansList",
						viewName: sectionServicePlanDrafts,
						success: function () {
							Opa5.assert.ok(true, "The service plan drafts table was found.");
						},
						errorMessage: "The service plan drafts table was not found."

					});
				},

				iShouldSeeAssignedServicePlan: function (servicePlanName) {
					return this.waitFor({
						viewName: sectionServicePlanDrafts,
						controlType: "sap.m.Text",
						matchers: new Properties({
							text: servicePlanName
						}),
						success: function () {
							Opa5.assert.ok(true, "The service plan " + servicePlanName + " is shown in the table.");
						},
						errorMessage: "The service plan " + servicePlanName + " is not shown in the table."
					});
				},

				iSeeTheCorrectColumn: function (columnId, visible) {
					return this.waitFor({
						controlType: "sap.m.Column",
						viewName: "Details.Project.subview.SectionServicePlan",
						id: columnId,
						success: function (column) {
							Opa5.assert.ok(column.getVisible() === visible, "ColumnId: '" + column.getId() + "'\nshould be visible: '" + visible +
								"' is actually visible: '" +
								column.getVisible() + "'");
						},
						errorMessage: "The column with the ID '" + columnId +
							"' was  not found."
					});
				},

				iShouldSeeColumnWithCorrectWidth: function (columnId, width) {
					return this.waitFor({
						controlType: "sap.m.Column",
						viewName: "Details.Project.subview.SectionServicePlan",
						id: columnId,
						success: function (column) {

							Opa5.assert.ok(column.getWidth() === width, "ColumnId: '" + column.getId() + "'\nexpected width: '" + width +
								"' actual width: '" +
								column.getWidth() + "'");
						},
						errorMessage: "The column with the ID '" + columnId +
							"' was  not found."
					});
				},

				iShouldSeeColumnInCorrectOrder: function (columnId, index) {
					return this.waitFor({
						controlType: "sap.m.Column",
						viewName: "Details.Project.subview.SectionServicePlan",
						id: columnId,
						success: function (column) {

							Opa5.assert.ok(column._index === index, "ColumnId: '" + column.getId() + "'\nexpected position: '" + index +
								"' actual position: '" +
								column._index + "'");
						},
						errorMessage: "The column with the ID '" + columnId +
							"' was  not found."
					});
				},

				iShouldSeeColumnCorrectlySorted: function (columnId, sortIndicator) {
					return this.waitFor({
						controlType: "sap.m.Column",
						viewName: "Details.Project.subview.SectionServicePlan",
						id: columnId,
						success: function (column) {
							Opa5.assert.ok(column.getSortIndicator() === sortIndicator, "ColumnId: '" + column.getId() + "'\nshould be sorted " +
								sortIndicator + " and is sorted " + column.getSortIndicator());
						},
						errorMessage: "The column with the ID '" + columnId + "' was not found."
					});

				},

				iShouldSeeCorrectTab: function (sTab) {
					this.waitFor({
						controlType: "sap.m.Button",
						viewName: sViewName,
						matchers: new Properties({
							text:sTab
						}),
						success: function () {
							Opa5.assert.ok(true, "The tab: " + sTab + " is displayed.");
						},
						errorMessage: "The tab is not displayed."
					});
				},

				iShouldSeeCreateServicePlanDialog: function () {
					this.waitFor({
						controlType: "sap.m.Dialog",
						viewName: "Details.Project.subview.SectionServicePlan",
						matchers: new I18NText({
							propertyName: "title",
							key: "ProjectSPD.Create.Title"
						}),
						searchOpenDialogs: true,
						success: function () {
							Opa5.assert.ok(true, "The dialog Create Service Plan is displayed.");
						},
						errorMessage: "The dialog is not displayed."
					});
				},

				iShouldSeeCorrectCaseNameID: function (sCaseNameId) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "Details.Project.subview.SectionServicePlan",
						bindingPath: {
							path: "",
							propertyPath: "/caseDetails/ProjectName",
							modelName: "servicePlan"
						},
						matchers: new Properties({
							text: sCaseNameId
						}),
						searchOpenDialogs: true,
						success: function () {
							Opa5.assert.ok(true, "The correct case name and ID: " + sCaseNameId + " are shown.");
						},
						errorMessage: "The case name and ID are not correct."
					});
				},

				iShouldSeeServicePlans: function (iRows) {
					this.waitFor({
						id: "servicePlansList",
						viewName: "Details.Project.subview.SectionServicePlan",
						matchers: new AggregationLengthEquals({
							name: "items",
							length: iRows
						}),
						success: function () {
							Opa5.assert.ok(true, "The table has " + iRows + " service plans.");
						},
						errorMessage: "The table does not contain all service plans."
					});
				},

				iShouldSeeCorrectServicePlanName: function (sRow, sText) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "Details.Project.subview.SectionServicePlan",
						bindingPath: {
							path: "/items/" + sRow,
							propertyPath: "Name",
							modelName: "servicePlan"
						},
						matchers: new Properties({
							text: sText
						}),
						success: function () {
							Opa5.assert.ok(true, "The service plan name " + sText + " is correctly shown.");
						},
						errorMessage: "The service plan name is not shown."
					});
				},

				iShouldSeeCorrectServicePlanDescription: function (sRow, sText) {
					this.waitFor({
						controlType: "sap.m.Text",
						viewName: "Details.Project.subview.SectionServicePlan",
						bindingPath: {
							path: "/items/" + sRow,
							propertyPath: "Description",
							modelName: "servicePlan"
						},
						matchers: new Properties({
							text: sText
						}),
						success: function () {
							Opa5.assert.ok(true, "The service plan description " + sText + " is correctly shown.");
						},
						errorMessage: "The service plan description is not shown."
					});
				},

				iShouldSeeCorrectCreatedBy: function (sRow, sText) {
					this.waitFor({
						controlType: "sap.m.Link",
						viewName: "Details.Project.subview.SectionServicePlan",
						bindingPath: {
							path: "/items/" + sRow,
							propertyPath: "CreatedByName",
							modelName: "servicePlan"
						},
						matchers: new Properties({
							text: sText
						}),
						success: function () {
							Opa5.assert.ok(true, "The service plan created by: " + sText + " is correctly shown.");
						},
						errorMessage: "The field created by in the service plan is not shown."
					});
				}

				//}
			}
		}
	});

});