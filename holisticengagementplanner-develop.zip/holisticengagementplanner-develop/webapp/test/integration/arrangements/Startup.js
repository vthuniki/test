sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/model/odata/v2/ODataModel"
], function (Opa5, ODataModel) {
	"use strict";

	return Opa5.extend("com.sap.ui.hep.test.integration.arrangements.Startup", {

		iStartMyApp: function (oOptionsParameter) {
			let oOptions = oOptionsParameter || {};

			this._clearSharedData();

			// start the app with a minimal delay to make tests fast but still async to discover basic timing issues
			oOptions.delay = oOptions.delay || 50;

			// start the app UI component
			// !!! DO NOT DELETE THIS PART !!!
			this.iStartMyUIComponent({
				componentConfig: {
					name: "com.sap.ui.hep",
					async: true
				},
				hash: oOptions.hash,
				autoWait: oOptions.autoWait
			});

		},

		iWaitFor : function (miliseconds){
			if (!miliseconds) miliseconds = 100;

			return setTimeout(function() {}, miliseconds);


		},

		_clearSharedData: function () {
			// clear shared metadata in ODataModel to allow tests for loading the metadata
			ODataModel.mSharedData = {
				server: {},
				service: {},
				meta: {}
			};
		}
	});
});
