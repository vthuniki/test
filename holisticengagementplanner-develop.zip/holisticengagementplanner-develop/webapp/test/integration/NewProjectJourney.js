/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit",
	"./pages/NewProject"
], function (opaTest) {
	"use strict";

	QUnit.module("Module Name");

	opaTest("Should Test Description", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();

		// Actions
		When.onMyPageUnderTest.iDoMyAction();

		// Assertions
		Then.onMyPageUnderTest.iDoMyAssertion();

		// Cleanup
		Then.iTeardownMyApp();
	});

});