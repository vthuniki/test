sap.ui.define([], function () {
	"use strict";
	return {
		getTimeOptions: () => {
			let oTime = {
				"1hour": {
					innerInterval: {
						unit: sap.gantt.config.TimeUnit.hour,
						span: 1,
						range: 90
					},
					largeInterval: {
						unit: sap.gantt.config.TimeUnit.day,
						span: 1,
						pattern: "EEE dd"
					},
					smallInterval: {
						unit: sap.gantt.config.TimeUnit.hour,
						span: 1,
						pattern: "h:mm:ss a"
					}
				},
				"1day": {
					innerInterval: {
						unit: sap.gantt.config.TimeUnit.day,
						span: 1,
						range: 90
					},
					largeInterval: {
						unit: sap.gantt.config.TimeUnit.week,
						span: 1,
						pattern: "MMM yyyy,'Week' ww"
					},
					smallInterval: {
						unit: sap.gantt.config.TimeUnit.day,
						span: 1,
						pattern: "EEE dd"
					}
				},
				"1week": {
					innerInterval: {
						unit: sap.gantt.config.TimeUnit.week,
						span: 1,
						range: 90
					},
					largeInterval: {
						unit: sap.gantt.config.TimeUnit.month,
						span: 1,
						pattern: "MMMM yyyy"
					},
					smallInterval: {
						unit: sap.gantt.config.TimeUnit.week,
						span: 1,
						pattern: "'CW' w"
					}
				},
				"1month": {
					innerInterval: {
						unit: sap.gantt.config.TimeUnit.month,
						span: 1,
						range: 90
					},
					largeInterval: {
						unit: sap.gantt.config.TimeUnit.month,
						span: 3,
						pattern: "yyyy, QQQ"
					},
					smallInterval: {
						unit: sap.gantt.config.TimeUnit.month,
						span: 1,
						pattern: "MMM"
					}
				},
				"1quarter": {
					innerInterval: {
						unit: sap.gantt.config.TimeUnit.month,
						span: 3,
						range: 90
					},
					largeInterval: {
						unit: sap.gantt.config.TimeUnit.year,
						span: 1,
						pattern: "yyyy"
					},
					smallInterval: {
						unit: sap.gantt.config.TimeUnit.month,
						span: 3,
						pattern: "QQQ"
					}
				},
				"1year": {
					innerInterval: {
						unit: sap.gantt.config.TimeUnit.year,
						span: 1,
						range: 90
					},
					largeInterval: {
						unit: sap.gantt.config.TimeUnit.year,
						span: 10,
						pattern: "yyyy"
					},
					smallInterval: {
						unit: sap.gantt.config.TimeUnit.year,
						span: 1,
						pattern: "yyyy"
					}
				}
			};
			return oTime;
		}
	};
});