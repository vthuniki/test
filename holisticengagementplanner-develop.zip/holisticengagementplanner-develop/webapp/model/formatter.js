sap.ui.define([
	"sap/gantt/misc/Format",
	"com/sap/ui/hep/reuse/Constants"
], function (Format, Constants) {
	"use strict";

	/**
	 * Semantic Statuses used for
	 * @type {Map<string, string>}
	 */
	const semanticStatuses = new Map()
		// SO Header
		.set("ZSK00001|E0001", "skNew")
		.set("ZSK00001|E0002", "skDeliveryConfirmed")
		.set("ZSK00001|E0005", "skDelivered")
		.set("ZSK00001|E0007", "skCancelled")
		.set("ZSK00001|E0015", "skServiceProjectPlanning")
		.set("ZSK00001|E0016", "skDeliveryPreparation")
		.set("ZSK00001|E0017", "skRestricted")
		.set("ZSK00001|E0018", "skDraft")
		// SR Header
		.set("ZSRQ0001|E0001", "srNew")
		.set("ZSRQ0001|E0002", "srViolated")
		.set("ZSRQ0001|E0003", "srInScoping")
		.set("ZSRQ0001|E0004", "srInException")
		.set("ZSRQ0001|E0005", "srApproved")
		.set("ZSRQ0001|E0006", "srCancelled")
		.set("ZSRQ0001|E0007", "srSOCreated")
		.set("ZSRQ0001|E0008", "srAuthorAction")
		.set("ZSRQ0001|E0009", "srRestricted")

		.set("DRAFT", "draft")
		.set("unknown", "unknown");

	/**
	 * CSS Classes for Customer Projects
	 * @type {Map<string, string>}
	 */
	const customerProjectClasses = new Map()
		.set("ZSAGSINV00", "cpNotInvolved")
		.set("ZSAGSINV01", "cpReactiveInvolvement")
		.set("ZSAGSINV02", "cpConsulting")
		.set("ZSAGSINV03", "cpProactiveEngagement")
		.set("ZSAGSINV04", "cpJointOwnership")
		.set("ZSAGSINV05", "cpCoInnovation")
		.set("ZSAGSINV06", "cpPreferredSuccessInvolvement")

		.set("unknown", "cpUnknown")
		.set("", "cpEmpty");

	return {
		formatCustomerProjectsSearchPlaceholder: function (sRange, sType) {
			let resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			if (sType === "ENG1") {
				if (sRange === "mine") {
					return resourceBundle.getText("Search through my engagements");
				} else {
					return resourceBundle.getText("Home.SearchPlaceholderAllEngagements");
				}
			} else if (sRange === "mine") {
				return resourceBundle.getText("Home.SearchPlaceholderMyProjects");
			} else {
				return resourceBundle.getText("Home.SearchPlaceholderAllProjects");
			}
		},

		formatFileName: function (sFileName, sFileType, sFileNote = "") {
			let sFileNameNew = sFileName;
			if (sFileName !== undefined) {
				if (sFileName.indexOf(".") < 0) {
					let sFileTypeExtension = this.formatter._fnDetermineFileTypeExtension(sFileType);
					sFileNameNew += "." + sFileTypeExtension;
				}
				if (sFileNote === "") {
					return sFileNameNew;
				} else {
					return sFileNameNew + " (" + sFileNote + ")";
				}
			}
			return "";
		},

		_fnDetermineFileTypeExtension: function (sFileType) {
			let sFileExtension = "";
			switch (sFileType) {
				case "text/plain":
					sFileExtension = "txt";
					break;
				case "image/jpeg":
					sFileExtension = "jpg";
					break;
				case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
					sFileExtension = "doc";
					break;
				case "application/pdf":
					sFileExtension = "pdf";
					break;
				default:
					sFileExtension = "txt";
			}
			return sFileExtension;
		},

		formatHighlightStatus: function (sStatus) {
			let sHighlight;
			switch (sStatus) {
				case "New":
					sHighlight = "Success";
					break;
				case "In Escalation":
					sHighlight = "Error";
					break;
				case "Other1":
					sHighlight = "Information";
					break;
				case "Other2":
					sHighlight = "Warning";
					break;
				default:
					sHighlight = "None";
			}
			return sHighlight;
		},

		/**
		 * Get Semantic Status of the item, based on item's ID.
		 *  @param {string} sItemId - Item ID
		 *  @return {string} - Semanti status string
		 */
		getSemanticStatus(sItemId) {
			return semanticStatuses.get(sItemId) ?? semanticStatuses.get("unknown");
		},

		/**
		 * Get CSS class for customer project / gantt line
		 *  @param {string} sSapInvolvement - Type of SAP involvement
		 *  @return {string} - CSS class used for different themes
		 */
		getCustomerProjectClasses(sSapInvolvement) {
			return customerProjectClasses.get(sSapInvolvement) ?? customerProjectClasses.get("unknown");
		},

		getCustomerProjectGradient(sSapInvolvement) {
			const cpClass = this.getCustomerProjectClasses(sSapInvolvement);
			return `gr${cpClass.slice(2)}`;
		},

		showServiceStatusColour: function (sStatus) {
			let sColour;
			switch (sStatus) {
				case "New":
					sColour = "yellow";
					break;
				case "In Scoping":
				case "In Exception":
					sColour = "purple";
					break;
				default:
					sColour = "";
			}
			return sColour;
		},

		formatHighlightRating: function (sRating) {
			let sHighlight = "";
			switch (sRating) {
				case "A":
					sHighlight = "#2B7C2B"; // "Success";
					break;
				case "B":
					sHighlight = "#FFEF00"; // "Warning";
					break;
				case "C":
					sHighlight = "#BB0000"; // "Error";
					break;
			}
			return sHighlight;
		},

		formatHasPhases: function (oDataTree) {
			return oDataTree ? oDataTree.some(item => item.itemKind === 0) : false;
		},

		formatHasItems: function (oDataTree) {
			return oDataTree ? oDataTree.length > 0 : false;
		},

		/**
		 * Handles the navigation to the respective CRM systrem,
		 * depending on the environment where the application is being accessed:
		 * DEV - ICD
		 * TEST - ICT
		 * PROD - ICP
		 *
		 * @param {number} idProject if the project id sent as a reference
		 * @return {string} the url for the respective CRM system
		 */
		linkFormater: function (idProject) {
			switch (this.getOwnerComponent().getModel("appData").getData().account) {
				case "dev":
					return Constants.getNavigationToICD().url + idProject;
				case "test":
					return Constants.getNavigationToICT().url + idProject;
				case "prod":
					return Constants.getNavigationToICP().url + idProject;
			}
		},

		linkFormaterCreationModeCRM: function () {
			switch (this.getOwnerComponent().getModel("appData").getData().account) {
				case "dev":
					return Constants.getCRMCreationLinks().navigateToCreateToICD;
				case "test":
					return Constants.getCRMCreationLinks().navigateToCreateToICT;
				case "prod":
					return Constants.getCRMCreationLinks().navigateToCreateToICP;
			}
		},

		statusShow: function (status) {
			let sStatus = "";
			if (status) {
				if (status !== "Phases" && status !== "None") {
					sStatus = status;
				}
			}
			return sStatus;
		},

		trTypeShow: function (transType, oContext) {
			let oView = oContext ? oContext.getView() : this.getView();
			if (transType !== null && transType !== undefined) {
				let resourceBundle = oView.getModel("i18n").getResourceBundle(),
					sI18nTrType = "GanttChart.Type." + transType,
					sTransType = resourceBundle.getText(sI18nTrType);
				if ((sTransType.indexOf("GanttChart.Type") >= 0)) {
					sTransType = transType;
				}
				return sTransType;
			} else {
				return null;
			}
		},

		formatUserName: function (sCreatedBy, sFirstName, sLastName) {
			if (sFirstName === "" && sLastName === "") {
				return sCreatedBy;
			}
			return sFirstName + " " + sLastName;
		},

		formatStatusClosed: function (sStatus) {
			return (sStatus !== "90")
		},

		// Methodology "Operations" = ZSPROMET03 - Visible formatter
		formatProjectMethodologyVisible: function (sMethodology) {
			return (sMethodology === "ZSPROMET03" || sMethodology === "")
		},

		// Methodology "Operations" = ZSPROMET03 - Not Visible formatter
		formatProjectMethodologyNotVisible: function (sMethodology) {
			return !(sMethodology === "ZSPROMET03" || sMethodology === "")
		},

		formatInvalidField: function (sFieldState) {
			return (sFieldState === "Error")
		},

		formatValueState: function (bElementExists) {
			if (bElementExists) {
				return "None";
			}
			return "Error";
		},

		formatDateAndTime: function (sDate, sTime) {
			let fOffset = sDate.getTimezoneOffset() * 60000,
				fMiliseconds = sDate.getTime() + fOffset;

			if (sTime !== undefined) {
				if (sDate.toString().includes("GMT")) {
					fMiliseconds = sDate.getTime() + sTime.ms + fOffset + 3600000;
				} else {
					let sDateInit = new Date(parseInt(sDate.substr(6, 13), 10));
					fMiliseconds = sDateInit.getTime() + sTime.ms + fOffset + 3600000;
				}
			}
			return new Date(fMiliseconds);
		},

		formatNoteType: function (sTypeKey) {
			let sText = "Type: " + Constants.getNoteType()[sTypeKey];
			return sText;
		},

		formatNoteContent: function (sNoteTypeKey, sNoteText) {
			let sNoteTypeText = "Type: " + Constants.getNoteType()[sNoteTypeKey];
			return sNoteTypeText + "\n\n" + sNoteText;
		},

		formatGanttEditableItemProperty: function (bEditMode, iItemKind) {
			if (bEditMode) {
				return (iItemKind === 0)
			} else {
				return false;
			}
		},

		fnAddLeadingZeros: function (iNumberOfDigits, iNumber) {
			let sNewNumber = iNumber;
			if (iNumberOfDigits >= 2 && iNumber.toString().length < iNumberOfDigits) {
				sNewNumber = "";
				for (let i = 1; i <= iNumberOfDigits - iNumber.toString().length; i++) {
					sNewNumber += "0";
				}
				sNewNumber += iNumber;
			} else {
				sNewNumber = "0" + sNewNumber;
			}
			return sNewNumber;
		},

		formatSearchListTitle: function (searchMyProjects, amount, scopeView) {
			let iProjects = amount === undefined ? 0 : amount;
			let resourceBundle = this.getView().getModel("i18n").getResourceBundle(),
				sTableTitleMY, sTableTitleAll;
			if (searchMyProjects === true) {
				if (scopeView === Constants.getReasonOptions().project) {
					sTableTitleMY = resourceBundle.getText("Home.Title.MyProjects", [iProjects]);
				} else if (scopeView === Constants.getReasonOptions().services) {
					sTableTitleMY = resourceBundle.getText("Home.Title.MyServices", [iProjects]);
				} else {
					sTableTitleMY = resourceBundle.getText("Home.Title.MyEngagementCases", [iProjects]);
				}
			}
			if (searchMyProjects === false) {
				if (scopeView === Constants.getReasonOptions().project) {
					sTableTitleAll = resourceBundle.getText("Home.Title.AllProjects", [iProjects]);
				} else if (scopeView === Constants.getReasonOptions().services) {
					sTableTitleAll = resourceBundle.getText("Home.Title.AllServices", [iProjects]);
				} else {
					sTableTitleAll = resourceBundle.getText("Home.Title.EngagementCases", [iProjects]);
				}
			}
			return searchMyProjects ? sTableTitleMY : sTableTitleAll;
		},

		formatSearchAttachmentTitle: function (amount, scopeView) {
			let iItems = amount === undefined ? 0 : amount;
			let resourceBundle = this.getView().getModel("i18n").getResourceBundle(),
				sTableTitleMY;
			sTableTitleMY = resourceBundle.getText("Attachments.Title.Attachments", [iItems]);
			return sTableTitleMY;
		},

		formatTaleVisibleRowCount: function (sNumberOfProjects) {
			const iNumberOfProjects = parseInt(sNumberOfProjects, 10);
			if (iNumberOfProjects > 10) {
				return 10;
			}
			return iNumberOfProjects;
		},

		formatContractAvailableForSelection: function (bproductIdSelected, bContractsExist, bRequestedDeliveryDateRequired,
			bRequestedDeliveryDateExists, bGoLiveDateRequired, bGoLiveDateExists) {
			if (bproductIdSelected && bContractsExist) {
				if (bRequestedDeliveryDateRequired) {
					return typeof bRequestedDeliveryDateExists == "boolean" ? bRequestedDeliveryDateExists : false
				} else if (bGoLiveDateRequired) {
					return typeof bGoLiveDateExists == "boolean" ? bGoLiveDateExists : false
				} else {
					return true;
				}
			}
			return false;
		},

		formatContractNotAvailableText: function (bBusyContract, bproductIdSelected, bContractsExist, bRequestedDeliveryDateRequired,
			bRequestedDeliveryDateExists, bGoLiveDateRequired, bGoLiveDateExists) {

			if (!bproductIdSelected || bBusyContract) {
				return "";
			} else if ((bRequestedDeliveryDateRequired && bRequestedDeliveryDateExists) || (bGoLiveDateRequired && bGoLiveDateExists)) {
				return this.getView().getModel("i18n").getResourceBundle().getText("ServiceOrder.NoContractAvailable");
			} else return "";

		},

		formatContractItemsNotAvailableText: function (bBusyContract, bproductIdSelected, bRequestedDeliveryDateRequired,
			bRequestedDeliveryDateExists, bGoLiveDateRequired, bGoLiveDateExists, bItemsAllWithoutContingent) {

			if (!bproductIdSelected || bBusyContract) {
				return "";
			} else if ((bRequestedDeliveryDateRequired && bRequestedDeliveryDateExists) || (bGoLiveDateRequired && bGoLiveDateExists)) {
				if (bItemsAllWithoutContingent) {
					return this.getView().getModel("i18n").getResourceBundle().getText("ServiceOrder.NoContractItemContingent");
				}
				return this.getView().getModel("i18n").getResourceBundle().getText("ServiceOrder.NoContractItemAvailable");
			} else return "";
		},

		formatContractItemComboVisible: function (bContractVisible, bAllItemsWithoutContingent) {
			if (bContractVisible && bAllItemsWithoutContingent) {
				return false;
			}
			return bContractVisible;
		},

		formatTooltipContractAvailableForSelection: function (bproductIdSelected, bReqDelDateRequired, bGoLiveRequired) {
			let oResourceBundle = this.getView().getModel("i18n").getResourceBundle();

			if (bproductIdSelected) {
				if (bReqDelDateRequired) {
					return oResourceBundle.getText("ServiceOrder.Tooltip.ContractId.ReqDelDateMandatory");
				}
				if (bGoLiveRequired) {
					return oResourceBundle.getText("ServiceOrder.Tooltip.ContractId.GoLiveDateMandatory");
				}
			}
			return oResourceBundle.getText("ServiceOrder.Tooltip.ContractId");
		},

		formatAttachmentsNoDataDescription: function (oView, bEditMode) {
			let oResourceBundle = oView.getModel("i18n").getResourceBundle();
			if (bEditMode) {
				return oResourceBundle.getText("ProjectDetails.Attachments.NoDataDescription.EditMode");
			} else {
				return oResourceBundle.getText("ProjectDetails.Attachments.NoDataDescription.DisplayMode");
			}
		},

		formatItemAlreadyExistsColor: function (bExists) {
			if (bExists) {
				return "Positive";
			}
			return "#fafafa";
		},

		formatShowEmployeeDetails: function (sEmplRespID) {
			return sEmplRespID!==undefined && sEmplRespID!==null;
		},

 		/**
 		 *  function, called when is needed to format output considering variable that can be undefined
 		 *  @param {string} sStr1 - the variable that should be avaluated
 		 *  @param {string} sStr2 - return value in case of sStr1 is not undefined
		 *  @param {string} sStr3 - return value in case of sStr1 undefined
		 *
		 *  @returns {string} - return the result of the concatenation.
 		 */
		_concatStrWithUndefined: function (sStr1="", sStr2="", sStr3="") {
			return sStr1 ? sStr2 : sStr3;
		},

		refObjDisplay: function (oRefObject) {
			let sResult = "";
			if (oRefObject.DeployMod === "CLOUD") {
				if (!oRefObject.SystemRefNum) {
					return "";
				}
				sResult = "Tenant " + oRefObject.SystemRefNum;
				sResult += this._concatStrWithUndefined(oRefObject.CarSysRoleText, " / Role " + oRefObject.CarSysRole + " " + oRefObject.CarSysRoleText, "");
			} else if (!oRefObject.SID && !oRefObject.SolmanSID) {
				return "";
			} else {
				sResult = "System ";
				sResult += this._concatStrWithUndefined(oRefObject.SID, oRefObject.SID, "- ");
				sResult += this._concatStrWithUndefined(oRefObject.InstNo, " (" + oRefObject.InstNo + ")", "");
				sResult += this._concatStrWithUndefined(oRefObject.SolmanSID, " / SolMan " + oRefObject.SolmanSID, "");
				sResult += this._concatStrWithUndefined(oRefObject.SolutionDescr, " / Solution " + oRefObject.SolutionDescr, "");
			}

			return sResult;
		},

		formatShowRefObjRequirements: function (iRefObjRequirement) {
			let resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			if (iRefObjRequirement === 0) {
				return resourceBundle.getText("SO.ReferenceObjectSelectionRequirements.Nothing");
			} else if (iRefObjRequirement === 1) {
				return resourceBundle.getText("SO.ReferenceObjectSelectionRequirements.System");
			} else if (iRefObjRequirement === 2) {
				return resourceBundle.getText("SO.ReferenceObjectSelectionRequirements.SolMan");
			} else {
				return resourceBundle.getText("SO.ReferenceObjectSelectionRequirements.Combined");
			}
		},

		formatServiceType: function (cServiceType) {
			if (cServiceType === "A") {
				return "On Site";
			} else if (cServiceType === "B") {
				return "Remote";
			}
			return "";
		},

		fnTimeConverter: function (sTimestamp) {
			return Format.abapTimestampToDate(sTimestamp);
		},

		enabledButtonsActions: function (sStatus, sTranType) {
			let isEnabled = false;
			switch (sTranType) {
				case "ZSK1":
					if (sStatus === "E0001") isEnabled = true;
					break;
				case "ZS43":
					// Not Completed, Cancelled or Restricted
					if (sStatus !== "E0013" && sStatus !== "E0014" && sStatus !== "E0015") {
						isEnabled = true;
					}
					break;
				case "ZS46":
					// Not Completed, Confirmed or Restricted
					if (sStatus !== "E0013" && sStatus !== "E0014" && sStatus !== "E0026") {
						isEnabled = true;
					}
					break;
			}
			return isEnabled;
		},

		formatLinkToSRSApp: function (SoID, ProjectID) {
			let sLink = "";
			let sEnvironment = Constants.getAccount()[this.getModel("appData").getData().account].type;
			sLink = "https://";
			sLink += Constants.getServiceRequestAccountUrl()[sEnvironment];
			sLink += SoID + ",";
			sLink += ProjectID;
			return sLink;
		},

		formatGanttShapeTooltip: function (sTransactionType, sName, sStatusText, sStatus, sStartTime, sEndTime) {
			let sTooltip = this.trTypeShow(sTransactionType) + " - " + sName + " - " + sStatusText + ": " + sStatus + " - " + sStartTime +
				" - " +
				sEndTime;
			return sTooltip;
		},

		showButtonInEditMode: function (bValid, bDisplayMode) {
			return bValid && !bDisplayMode;
		},

		_removeZeroesFromField: function (field) {
			return field.replace(/^0+/, "");
		},

		formatAllowReleaseToDelivery: function (bDataStepValid, bQuestionnaireStepValid, iCurrentStep) {
			const bDataStepValidChk = typeof bDataStepValid == 'boolean'? bDataStepValid : false
			const bQuestionnaireStepValidChk = typeof bQuestionnaireStepValid == 'boolean'? bQuestionnaireStepValid : false
			return (bDataStepValidChk && bQuestionnaireStepValidChk && iCurrentStep === 3);
		},

		showSoFooterMessage: function (bDataStepValid, bQuestionnaireStepValid, iCurrentStep) {
			if (iCurrentStep !== 3) {
				return false;
			}
			const bDataStepValidChk = typeof bDataStepValid == 'boolean'? bDataStepValid : false
			const bQuestionnaireStepValidChk = typeof bQuestionnaireStepValid == 'boolean'? bQuestionnaireStepValid : false
			return !(bDataStepValidChk && bQuestionnaireStepValidChk)
		},

		formatHighlightStatusActivities: function (sStatus) {
			let sHighlight;
			switch (sStatus) {
				case "E0010": // "New":
					sHighlight = "Indication05"; // "Success";
					break;
				case "E0011": //"In Process":
					sHighlight = "Indication06"; // "Success";
					break;
				case "E0012": // "Confirmed":
					sHighlight = "Indication07"; // "Information";
					break;
				case "E0013": // "Completed":
					sHighlight = "Indication04"; // "Information";
					break;
				case "E0014": // "Cancelled":
					sHighlight = "Indication02"; // "Error";
					break;
				case "E0016": // "In CC Front Office
					sHighlight = "Indication03"; // "Warning";
					break;
				case "E0017": // "In SAP Back office
					sHighlight = "Indication03"; // "Warning";
					break;
				case "E0018": // "In SAP Development
					sHighlight = "Indication03"; // "Warning";
					break;
				default:
					sHighlight = "None";
			}
			return sHighlight;
		},

		checkIfENGReason: function (sReason) {
			let aSpecialReasons = Constants.getSpecialReasonCase();
			return !aSpecialReasons.includes(sReason);
		},

		getStatusColor: function (sStatus) {
			let sColor = "";
			switch (sStatus) {
				case "New":
					sColor = "Indication05";
					break;
				case "Closed":
					sColor = "Indication02";
					break;
				case "In Process":
					sColor = "Indication04";
					break;
				case "In Escalation":
					sColor = "Indication01";
					break;
				default:
					sColor = "Indication06";
			}
			return sColor;
		},

		showEditBtn: function (bEditMode, bDisplayPage) {
			return (bEditMode === false && bDisplayPage !== true);
		},

		formatIsProjectCase: function (sReasonCode) {
			return sReasonCode === Constants.getProjectCaseReasonCode();
		},

		formatIsNotProjectCase: function (sReasonCode) {
			return sReasonCode !== Constants.getProjectCaseReasonCode();
		},

		formatSscUrl: function (sSscObjectId) {
			return Constants.getSscUrl(sSscObjectId);
		},

		formatSPDServicePlanDraftTitle: function (sPlanName, iNumberOfItems, iNumberOfDays) {
			if (!iNumberOfItems) {
				iNumberOfItems = 0;
			}
			if (!iNumberOfDays) {
				iNumberOfDays = 0;
			}

			let resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			let titleText = sPlanName;
			let itemsText = resourceBundle.getText("SPDDetails.ListView.Items");
			let daysText = resourceBundle.getText("SPDDetails.ListView.Days");

			return sPlanName ? `${titleText} (${iNumberOfItems} ${itemsText} / ${iNumberOfDays} ${daysText})` : "";
		},

		spdHideActionForSOSR: function (sItemType) {
			return sItemType !== "ZSR1" && sItemType !== "ZSK1";
		},

		spdShowActionForSOSR: function (sItemType) {
			return sItemType === "ZSR1" || sItemType === "ZSK1";
		},

		spdItemNoDetails: function (sItemNo, sTransactionID) {
			return sTransactionID;
		},

		formatEmptyPhase: function (sPhaseText) {
			return sPhaseText === "" ? "None" : sPhaseText;
		},

		/**
		 * Service type "A" (on site)
		 * - exclude sr "X" - SO with single component
		 * - exclude sr ""  - SR with single component
		 * Service type "B" (remote) - SO with multiple components
		 *
		 */
		formatDocTypeExpectedAfterTTE: function (sServiceType, sExcludeSR, sNumberOfComponents) {
			let oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			let iNumberOfComponents = parseInt(sNumberOfComponents, 10);
			if (sServiceType === "A") {
				if (sExcludeSR === "X") {
					return oResourceBundle.getText("SPDDetails.TransferToExecution.SOSingle");
				} else {
					return oResourceBundle.getText("SPDDetails.TransferToExecution.SRSingle");
				}
			} else if (iNumberOfComponents === 1) {
				return oResourceBundle.getText("SPDDetails.TransferToExecution.SOSingle");
			} else {
				return oResourceBundle.getText("SPDDetails.TransferToExecution.SOMultiple", [iNumberOfComponents]);
			}
		},

		showSPDDetailsItemColour: function (sColour) {
			return typeof sColour === "string" ? sColour : "white";
		},

		getUIComponentStatusText: function (sComponentItemData) {
			if (sComponentItemData) {
				const params = sComponentItemData.split("|");
				const sUIComponentStatus = typeof params[1] === "string" ? params[1] : "";
				return sUIComponentStatus;
			} else {
				return "";
			}
		},

		formatUIComponentTooltip: function (sItemStatusText, sComponentStatusT) {
			if (sComponentStatusT && sComponentStatusT !== '') {
				return sItemStatusText + " - " + sComponentStatusT;
			} else {
				return sItemStatusText;
			}
		},

		showSPDDetailsComponentItemHColour: function (sComponentItemData) {
			if (sComponentItemData) {
				const params = sComponentItemData.split("|");
				const sItemType = typeof params[0] === "string" ? params[0] : "";
				const sUIComponentStatus = typeof params[1] === "string" ? params[1] : "";
				return Constants.getSPDDetailsComponentItemColour(sItemType, sUIComponentStatus, "H");
			} else {
				return "";
			}
		},

		/**
		 * Toggles the visibility for the 'Confirm' button of the restricted SPD / Project dialog
		 *
		 * @param {string} sReason - Selected reason code
		 * @param {string} sOtherReason - Free text input for reason 'Other' code 90
		 * @return {Bool} 'Confirm' button is visble
		 *
		 */
		showRestrictedConfirmBtn: function (sReason, sOtherReason) {
			if (sReason && sReason !== "" && sReason !== "90") {
				return true;
			}
			// For the reason 90 (Other) the user needs to enter an additional text
			return (sReason === "90" && sOtherReason !== undefined && sOtherReason !== "")
		},

		formatLink: function (sProdLink, sTestLink) {
			if (Constants.getEnvironment() === "prod") return sProdLink;
			else return sTestLink;
		},
		formatLinkUsageAnalyzer: function (sProdLink, sTestLink, sDevLink, iParam, iNumberOfDigits, customerName) {
			if (!sProdLink || !sTestLink || !sDevLink) return "";
			if (iParam && iNumberOfDigits) iParam = this.formatter.fnAddLeadingZeros(iNumberOfDigits, iParam);
			let sBaseLink;
			if (Constants.getEnvironment() === "prod") sBaseLink = sProdLink;
			else if (Constants.getEnvironment() === "test") sBaseLink = sTestLink;
			else sBaseLink = sDevLink;
			const aParts = sBaseLink.split("${{1}}");
			return aParts[0] + customerName + " (" + iParam + ")" + aParts[1];
		},

		formatLinkWithEndParameter: function (sProdLink, sTestLink, iParam, iNumberOfDigits) {
			if (!sProdLink || !sTestLink) return "";
			if (iParam && iNumberOfDigits) iParam = this.formatter.fnAddLeadingZeros(iNumberOfDigits, iParam);
			let sBaseLink = Constants.getEnvironment() === "prod" ? sProdLink : sTestLink;
			return sBaseLink + iParam;
		},

		formatLinkHealthIndex: function (sProdLink, sTestLink, iParam, iNumberOfDigits) {
			if (!sProdLink || !sTestLink) return "";
			if (iParam && iNumberOfDigits) iParam = this.formatter.fnAddLeadingZeros(iNumberOfDigits, iParam);
			let sBaseLink = Constants.getEnvironment() === "prod" ? sProdLink : sTestLink;
			const aParts = sBaseLink.split("${{1}}");
			return aParts[0] + iParam + aParts[1];
		},

		formatSpdObjectTitle: function (sObjectId, sObjectTitle) {
			if (!sObjectTitle) return sObjectId;
			return `${sObjectId} - ${sObjectTitle}`;
		},
		formatEffort: function (nEffort) {
			if (!nEffort) return "NaN";
			return Math.round(nEffort * 10) / 10 + "d";
		},
		formatItemStatus: function (sColour) {
			switch (sColour) {
				case "white":
				case "light-yellow":
				case "grey":
				case "silver":
					return "None";
				case "light-orange":
					return "Indication03";
				case "light-grey":
					return "Indication07";
				case "light-green":
					return "Indication04";
				case "light-blue":
					return "Indication05";
				default:
					return "Indication08";
			}
		},
		formatItemsColorLegend: function (sItemStatusText) {
			switch (sItemStatusText) {
				case "Proposal":
					return "Indication03";
				case "New":
					return "Indication07";
				case "Frontoffice Action":
					return "Indication03";
				case "Backoffice Action":
					return "Indication07";
				case "In Delivery":
					return "Indication05";
				case "Delivered":
					return "Indication04";
				default:
					return "Indication08";
			}
		},
		showUIComponentStatusTColour: function (sItemType, sStatus) {
			let sColour;
			if (sItemType === "ZSK1") {
				switch (sStatus) {
					case "New":
						sColour = "yellow";
						break;
					case "Backoffice Action":
						sColour = "purple";
						break;
					default:
						sColour = "";
				}
			} else if (sItemType === "ZSR1") {
				switch (sStatus) {
					case "New":
						sColour = "yellow";
						break;
					case "In Scoping":
					case "In Exception":
						sColour = "purple";
						break;
					default:
						sColour = "";
				}
			} else {
				sColour = "";
			}
			return sColour;
		},
		getPhaseVisibility: function (sPhaseName, aPhaseItems, sEditMode, isOperationsProject, bPhaseIsVisible, iitemsVisible) {
			const bPhaseIsVisibleChk = typeof bPhaseIsVisible === 'boolean' ? bPhaseIsVisible : false

			if (isOperationsProject) {
				// called in case the project is of type ZSPROMET03 (Operations)
				// disables all columns of not Run && and "None" (in case this category has items)
				switch (true) {
					case (sPhaseName === "None" && iitemsVisible === 0 && sEditMode === false):
						return false;
					case (sPhaseName === "Discover"):
						return false;
					case (sPhaseName === "Prepare"):
						return false;
					case (sPhaseName === "Explore"):
						return false;
					case (sPhaseName === "Realize"):
						return false;
					case (sPhaseName === "Deploy"):
						return false;
					default:
						return bPhaseIsVisibleChk;
				}
			} else if (bPhaseIsVisibleChk) {
				return !(sPhaseName === "None" && iitemsVisible === 0 && sEditMode === false);
			} else {
				return false;
			}
		},

		formatPhaseDates: function (oStartDate, oEndDate, sPhaseName) {
			if (sPhaseName === "None") return this.getResourceBundle().getText("SPDDetails.PhaseView.PhaseNoneDescription");
			const months = {
				0: "Jan",
				1: "Feb",
				2: "Mar",
				3: "Apr",
				4: "May",
				5: "Jun",
				6: "Jul",
				7: "Aug",
				8: "Sep",
				9: "Oct",
				10: "Nov",
				11: "Dec"
			};

			if (oStartDate && !oEndDate) return `${months[oStartDate.getMonth()]} ${oStartDate.getDate()}, ${oStartDate.getFullYear()} - . . . . . . .`;
			if (!oStartDate && oEndDate) return `. . . . . . .  - ${months[oEndDate.getMonth()]} ${oEndDate.getDate()}, ${oEndDate.getFullYear()}`;
			if (oStartDate && oEndDate) return `${months[oStartDate.getMonth()]} ${oStartDate.getDate()}, ${oStartDate.getFullYear()} - ${months[oEndDate.getMonth()]} ${oEndDate.getDate()}, ${oEndDate.getFullYear()}`;
			return "";
		},

		formatPhaseDatesTooltip: function (oStartDate, oEndDate, sPhaseName) {
			if (sPhaseName === "None") return this.getResourceBundle().getText("SPDDetails.PhaseView.PhaseNoneDescription");

			if (!oStartDate || !oEndDate) {
				return "";
			}
			/*else {
				const months = {
					0: "Jan",
					1: "Feb",
					2: "Mar",
					3: "Apr",
					4: "May",
					5: "Jun",
					6: "Jul",
					7: "Aug",
					8: "Sep",
					9: "Oct",
					10: "Nov",
					11: "Dec"
				};*/
			return oStartDate + " - " + oEndDate;
			//}

		},
		formatItemStartDateTooltip: function (oStartDate) {
			if (oStartDate) {
				return oStartDate.toString();
			} else {
				return "Start Date";
			}
		},
		phaseDroppability: function (aPhases, sSPDValue) {
			const phases = {
				"None": 0,
				"Discover": 1,
				"Prepare": 2,
				"Explore": 3,
				"Realize": 4,
				"Deploy": 5,
				"Run": 6
			};
			return aPhases[phases[sSPDValue]];
		},
		getItemStatusText: function (sItemStatus) {

			switch (sItemStatus) {
				case '':
					return 'Proposal';
				case 'Delivery Preparation':
				case 'Delivery confirmed':
					return 'Delivery';
				case 'Author Action':
				case 'Service / Project Planning':
					return 'Author';
				default:
					return sItemStatus;
			}

		},
		changePhaseViewSelectMode: function (bEditMode) {
			if (!bEditMode) return "None";
			else return "MultiSelect";
		},

		getSPDItemQuickViewTitle: function (sItemType) {
			let sTitle;
			switch (sItemType) {
				case "ZSK1":
					sTitle = "Quick View on Service Order";
					break;
				case "ZSR1":
					sTitle = "Quick View on Service Request";
					break;
				case "YSP1":
					sTitle = "Quick View on Proposal";
			}
			return sTitle;
		},

		getSPDPhaseText: function (sPhaseCode, aPhases) {
			let sSPDPhaseText = "";
			let oPhase = aPhases.find(obj => {
				return obj.DdlbKey === sPhaseCode;
			});
			if (oPhase !== undefined) {
				sSPDPhaseText = oPhase.Value;
			}
			return sSPDPhaseText;
		},

		formatTileTitle: function (sAlternativeDescription, bIsExpanded, sSource) {
			let resFlag = false;
			if (!sAlternativeDescription && bIsExpanded) resFlag = true;
			return resFlag;
		},

		formatTileLabel: function (sItemStatusText, sAlternativeDescription, sObjectTitle) {
			if (sItemStatusText === "Draft") return sAlternativeDescription;
			else return sObjectTitle;
		},

		wrapTileLabel: function (sItemStatusText, sAlternativeDescription, sObjectTitle) {
			let tmpString = "";
			if (sItemStatusText === "Draft") tmpString = sAlternativeDescription;
			else tmpString = sObjectTitle;
			return (tmpString === "")
		},

		phaseDateVisibility: function (oStartDate, oEndDate, sPhaseName) {
			if (sPhaseName === "None") return true;
			return !(!oStartDate || !oEndDate || oStartDate === "" || oStartDate === "");
		},

		formatContractDetails: function (sContractItemNo, sAvailDays, oStartDate, oEndDate, sCountry) {
			if (!(oStartDate && oEndDate && sContractItemNo)) return "";
			return this.getResourceBundle().getText("SPDDetails.TransferToExecution.List.ContractDesc", [
				parseInt(sContractItemNo, 10).toString(),
				this.formatter.formatContractDate(oStartDate),
				this.formatter.formatContractDate(oEndDate),
				Number(sAvailDays).toString(),
				sCountry
			]);
		},

		formatContractDate: function (oDate) {
			if (!(oDate instanceof Date)) return null;
			const oOptions = { year: 'numeric', month: 'short', day: 'numeric' };
			return oDate.toLocaleDateString(undefined, oOptions);
		},

		decimalToPercent: function (oData) {
			return Math.trunc((oData * 100)) + '%';
		},

		cutZeros(oData) {
			if (oData) return Math.round(oData * 10) / 10;
			else return null;
		},

		calcProductSelectionLabel: function (sSessionType) {
			switch (sSessionType) {
				case "service":
					return "Service";
				case "session":
					return "Session";
				default:
					return "Service / Session";
			}
		},

		FormatMaintainSPDItemPhase: function (sPhase, sPhaseID, bIsOperationsProject) {

			if (bIsOperationsProject) {
				// Handles Phase assigment for Operations Projects
				// sPhaseID === "None" handles items in phase view without assigned phase
				// sPhase === "None" handles Add services dialog
				// sPhase === WTF_00 || WTF_01 || WTF_02 || WTF_03 || WTF_05 handles selecting services from list with a non-run status
				// sPhaseID === undefined and sPhase === undefined handles selecting services from list in case they have no phase defined
				// default case handles items in phase view with existing phases
				switch (true) {
					case (sPhaseID === ""):
						return "None";
					case (sPhase === "None"):
						return "WTF_05";
					case (sPhase === "WTF_00" || sPhase === "WTF_01" || sPhase === "WTF_02" || sPhase === "WTF_03" || sPhase === "WTF_04"):
						return "WTF_05";
					case (sPhaseID === undefined && sPhase === undefined):
						return "WTF_05";
					default:
						return sPhaseID;
				}
			} else if ( sPhase === "None" ) {
				// handles assignement of non-operations projects
				return "None"
			} else {
				return (sPhaseID)
			}
		},

		showStatusColour: function () {
			return "yellow2";
		},

		guIconSelector: function (sGuIcon, sExtern) {
			// handles visibility of the guIcon in engagement scope view
			if (sGuIcon) {
				return "sap-icon://world";
			} else if (sExtern) {
				return "sap-icon://employee-rejections";
			} else return null;
		},

		guTooltipSelector: function (sGuIcon, sExtern) {
			let resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			if (sGuIcon) {
				return resourceBundle.getText("Engagement.Scope.Table.guhovertext");
			} else if (sExtern) {
				return resourceBundle.getText("Engagement.Scope.Table.notguhovertext");
			} else return null;
		},

		mainIconSelector: function (sMainIcon) {
			// handles visibility of the mainIcon in engagement scope view
			if (sMainIcon) {
				return "sap-icon://home";
			} else return null;
		},

		inScopeHandler: function (bInScope, bIsMain) {
			// handles the selected state for the checkbox in engagement scope view
			if (bIsMain || bInScope) {
				return true;
			} else return null;
		},

		engScopeJoinProdTotalsText: function (sProd, sTotals) {
			if (sProd === 0 && sTotals === 0) return " - (-)";
			else return "";

		},
		engScopeJoinProdTotalsLink: function (sProd, sTotals) {
			switch (true) {
				case (sProd === 0 && sTotals !== 0):
					return " - (" + sTotals + ")";
				case (sProd !== 0 && sTotals === 0):
					return sProd + "(-)";
				case (sProd === 0 && sTotals === 0):
					return "";
				default:
					return sProd + " (" + sTotals + ")";
			}

		},

		engScopeJoinProdTotals: function (sProd, sTotals) {
			switch (true) {
				case (sProd === 0 && sTotals !== 0):
					return " - (" + sTotals + ")";
				case (sProd !== 0 && sTotals === 0):
					return sProd + "(-)";
				case (sProd === 0 && sTotals === 0):
					return " - (-)";
				default:
					return sProd + " (" + sTotals + ")";
			}

		},

		formatEnterpriseSupporReportingtCockpitUrl: function (sSystemKind, sCustomerErpNo) {
			return Constants.getEnterpriseSupportReportingCockpitURL(sSystemKind, sCustomerErpNo);
		},

		getISDHubIssuesAndActionsManagementURL: function (sErpNo, sProjNo) {
			return Constants.getISDHubIssuesAndActionsManagementURL(sErpNo, sProjNo);
		},

		cloudRefObjectIcon: function (sProductID, sMainObject) {
			if (!sProductID) return null;

			//Tenant or Module?
			if (sProductID.startsWith("S_")) {
				// Main Tenant?
				if (sMainObject === "X") {
					return "sap-icon://home";
				} else {
					return "sap-icon://cloud";
				}
			} else if (sProductID.startsWith("PV_")) {
				return "sap-icon://document";
			} else return null;
		},

		cloudProductID: function (sProductID, sProductDescription) {
			if (!sProductID) return null;

			//Tenant or Module?
			if (sProductID.startsWith("S_")) {
				let aParts = sProductID.split('_0');
				return aParts[1];
			} else if (sProductID.startsWith("PV_")) {
				return sProductDescription;
			} else return null;
		},

		getPartnerFunctionExists: function (oPartnerModel, sPartnerFunction) {
			if (oPartnerModel === null || oPartnerModel === undefined) return false;
			return !(oPartnerModel[sPartnerFunction] === null || typeof oPartnerModel[sPartnerFunction] !== 'object')
		},

		forecastAppTooltip: function (sForecastURL) {
			let resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			if (!sForecastURL || sForecastURL === "") {
				return resourceBundle.getText("Engagement.Contracts.button.openForecastAppNoURL.tooltip");
			} else {
				return resourceBundle.getText("Engagement.Contracts.button.openForecastApp.tooltip");
			}
		},

		forecastAppLinkColor: function (sForecastURL) {
			if (!sForecastURL || sForecastURL === "") {
				return "#629ADC"; // Grey
			} else {
				return "#0854a0"; // Blue
			}
		},

		planListFavorite: function (bIsFavorite, sItemStatusText) {
			const bIsFavoriteChk = typeof bIsFavorite == 'boolean'? bIsFavorite : false
			return (bIsFavoriteChk && sItemStatusText !== "Draft")
		},

		planListUnFavorite: function (bIsFavorite, sItemStatusText) {
			const bIsFavoriteChk = typeof bIsFavorite == 'boolean'? bIsFavorite : false
			return (!bIsFavoriteChk && sItemStatusText !== "Draft")
		},

		linkToSapIt: function(userId){
			const sapItConstants = Constants.getBaseSapIt();
			const linkToEmployeeDetails = sapItConstants.baseLinkEmployees + `('${userId}')`;

			return {
				"employeeData": linkToEmployeeDetails,
				"employeePicture": linkToEmployeeDetails + sapItConstants.employeePictureExtension
			}
		},

		getAttachmentPath: function () {
			return Constants.getAttachmentsUploadUrl();
		}
	};
});
