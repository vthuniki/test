sap.ui.define([
    "sap/ui/core/ComponentContainer",
    "sap/m/Shell",
    "sap/ui/core/Core",
    "sap/base/Log",
    "sap/ui/core/LocaleData"
], function (ComponentContainer, Shell, Core, Log, LocaleData) {
    "use strict";

    Core.ready(() => {
        const config = Core.getConfiguration();
        const currentLocale = config.getLocale();
        config.setLanguage("en"); // override the language
        config.setFormatLocale(currentLocale.toString());

        const currentLocaleData = new LocaleData(currentLocale);
        const dateFormats = ["short", "medium", "long", "full"].map(f => `'${currentLocaleData.getDatePattern(f)}'`);
        Log.debug(`Current language is ${currentLocale}, date formats (s,m,l,f) are "${dateFormats.join(", ")}"`);
    });

    new Shell({
        homeIcon: {
            favicon: "images/favicon.ico"
        },
        appWidthLimited: false,
        app: new ComponentContainer({
            height: "100%",
            name: "com.sap.ui.hep",
            async: true
        })
    }).placeAt("content");
});
