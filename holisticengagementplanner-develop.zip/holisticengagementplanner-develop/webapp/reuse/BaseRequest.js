sap.ui.define([
	"com/sap/ui/hep/reuse/Constants",
	"com/sap/ui/hep/reuse/HandleErrorMessage",
	"com/sap/ui/hep/reuse/HandleSessionTimeout",
	"com/sap/ui/hep/reuse/HandleSuccessMessages",
	"sap/ui/model/odata/v2/ODataModel"
], function (Constants, HandleErrorMessage, HandleSessionTimeout, HandleSuccessMessages, ODataModel) {
	"use strict";
	return {

		_bMetadataLoadingFailed: false,




		handleBusyIndicators: function (params, oModelName) {
			if (params.callbackUnsetBusyIndicator) {
				params.callbackUnsetBusyIndicator();
			} else {
				let oModelNameParam = oModelName;
				if (params.model) {
					oModelNameParam = params.model;
				}
				if (params.busyIndicator !== undefined) {
					if (Array.isArray(params.busyIndicator)) {
						params.busyIndicator.forEach(function (busyIndicatorItem) {
							params.currentView.getModel(oModelNameParam).getData()[busyIndicatorItem] = false;
						});
					} else {
						params.currentView.getModel(oModelNameParam).getData()[params.busyIndicator] = false;
					}
				}
				params.currentView.getModel(oModelNameParam).refresh();
			}
		},

		_onMetadataLoadingFailed: function (oEvent, params) {
			let oModelName = "localModel";
			this.handleBusyIndicators(params, oModelName);
			if (params.model) {
				oModelName = params.model;
			}
			const oResourceBundle = params.currentView.getController().getResourceBundle(),
				sStatusCode = oEvent.getParameters().statusCode,
				sMessage = oEvent.getParameters().message, // $.parseHTML(oEvent.getParameters().responseText)[1]
				sId = "error" + sStatusCode + params.entitySet,
				sType = "Error",
				sTitle = oResourceBundle.getText("Error.ODataNotAvailable.Title"),
				sDescription = sStatusCode + " " + sMessage + "\n" + oResourceBundle.getText("Error.ODataNotAvailable.Description");

			params.oContext.messageHandler.addNewMessageseInsidePopover(sId + sTitle, sType, sTitle, sDescription, null,
				params.oContext);

			params.currentView.getModel(oModelName).refresh();
		},

		handleReadUserData: function (params) {
			const sUrl = Constants.getUserApi(),
				apiKey = Constants.getAPIHeaders().APIKey,
				apiSecret = Constants.getAPIHeaders().APISecret;
			jQuery.ajax({
				url: sUrl,
				method: "GET",
				headers: {
					"X-Requested-With": "XMLHttpRequest",
					"Content-Type": "application/json",
					"DataServiceVersion": "2.0",
					"APIKey": apiKey,
					"APISecret": apiSecret
				},
				success: (oData, oResponse) => {
					return params.callbackSuccess(oData);
				},
				error: (oResponse, sStatus, sError) => {
					return HandleErrorMessage.callbackError(oResponse, params, this);
				}
			});
		},

		_setAPIHeaders: function (params) {
			if (!params) {params = {};}
			if (!params.headers) {params.headers = {};}

			params.headers.APIKey = Constants.getAPIHeaders().APIKey;
			params.headers.APISecret = Constants.getAPIHeaders().APISecret;
			// is sometimes used in other requests but not always?
			params.headers["X-Requested-With"] = 'XMLHttpRequest';
			// was added in SAP IT session
			//params.headers["X-Requested-With"] = 'X';
			// was added in SAP IT session
			params.headers["sap-client"] = "001";
			return params;
		},

		_buildOdataModel: function (params) {

			params = this._setAPIHeaders(params);

			return new ODataModel({
				serviceUrl: params.servicePath,
				useBatch: params.batch ? params.batch : false,
				disableHeadRequestForToken: params.disableHeadRequestForToken ? params.disableHeadRequestForToken : true,
				defaultCountMode: params.defaultCountMode ? params.defaultCountMode : "None",
				defaultUpdateMethod: params.updateMethod ? params.updateMethod : null,
				headers: params.headers ? params.headers : null
			});
		},

		/*============================================= Read ================================================*/

		handleRead: function (params) {

			const urlParameters = this._buildUrlParamsReadCall(params),
				oDataModel = this._buildOdataModel(params),
				entitySet = params.entitySet ? params.entitySet : "",
				navigation = params.navigation ? "/" + params.navigation : "",
				entityCallFormat = this._buildEntityFormatCall(params),
				sPath = "/" + entitySet + entityCallFormat + navigation;

			oDataModel.read(sPath, {
				success: (oData, oResponse) => {
					this._handleSuccess(oResponse, oData, params);
				},
				error: (oResponse, sStatus, sError) => {
					let responseText = "";
					try {
						responseText = JSON.parse(oResponse.responseText);
					} catch (err) {
						responseText = "Error occured in Backend, but cannot parse error text.";
					}
					const oResourceBundle = params.currentView.getController().getResourceBundle(),
						sStatusCode = oResponse.statusCode,
						sMessage = oResponse.message,
						sId = "error" + sStatusCode + params.entitySet,
						sType = "Error",
						sTitle = responseText.error.message.value, //oResourceBundle.getText("Error.ODataNotAvailable.Title"),
						sDescription = sStatusCode + " " + sMessage + "\n" + oResourceBundle.getText("Error.ODataNotAvailable.Description"),
						sLongtext = responseText.error.innererror
							.errordetails?.[0]?.longtext_url ? responseText.error.innererror.errordetails[0].longtext_url.replace("/sap/opu/odata/",
								"/int_ic_orig/") : sTitle;

					if (params.callbackError) {this._handleError(oResponse, params);}
					params.oContext?.messageHandler?.addNewMessageseInsidePopover(sId + sTitle,
						sType, sTitle, sDescription, null, params.oContext, undefined, undefined, sLongtext);
				},
				urlParameters: urlParameters
			});

			oDataModel.attachMetadataFailed(null, (oEvent) => {
				if (!this._bMetadataLoadingFailed) {
					this._onMetadataLoadingFailed(oEvent, params);
				}
				this._bMetadataLoadingFailed = oEvent.getSource().isMetadataLoadingFailed();
			}, null);
		},

		/*============================================= Create ==============================================*/

		handleCreate: function (params) {
			const oDataModel = this._buildOdataModel(params),
				entitySet = params.entitySet ? params.entitySet : "",
				sPath = "/" + entitySet;

			oDataModel.create(sPath, params.data, {
				success: (oData, oResponse) => {
					this._handleSuccess(oResponse, oData, params);
				},
				error: (oResponse, sStatus, sError) => {
					this._handleError(oResponse, params);
				},
				urlParameters: params.aUrlParameters
			});
		},

		handleCreateSync: function (params) {
			const oDataModel = this._buildOdataModel(params),
				entitySet = params.entitySet ? params.entitySet : "",
				sPath = "/" + entitySet;

			oDataModel.create(sPath, params.data, {
				async: params.async,
				success: (oData, oResponse) => {
					this._handleSuccess(oResponse, oData, params);
				},
				error: (oResponse, sStatus, sError) => {
					this._handleError(oResponse, params);
				}
			});
		},

		/*=========================================== Update ================================================*/

		handleUpdate: function (params) {
			const oDataModel = this._buildOdataModel(params),
				entitySet = params.entitySet ? params.entitySet : "",
				entityCallFormat = this._buildEntityFormatCall(params),
				sPath = "/" + entitySet + entityCallFormat;

			oDataModel.update(sPath, params.data, {
				success: (oData, oResponse) => {
					this._handleSuccess(oResponse, oData, params);
				},
				error: (oResponse, sStatus, sError) => {
					this._handleError(oResponse, params);
				},
				urlParameters: params.aUrlParameters
			});
		},

		/*============================================= Delete ============================================*/

		handleRemoveAttachments: function (params) {
			const oDataModel = this._buildOdataModel(params),
				entitySet = params.entitySet ? params.entitySet : "",
				entityCallFormat = this._buildEntityFormatCall(params, true),
				sPath = "/" + entitySet + entityCallFormat;

			oDataModel.remove(sPath, {
				success: (oData, oResponse) => {
					this._handleSuccess(oResponse, oData, params);
				},
				error: (oResponse, sStatus, sError) => {
					this._handleError(oResponse, params);
				}
			});
		},

		handleDelete: function (params) {
			const oDataModel = this._buildOdataModel(params),
				entitySet = params.entitySet ? params.entitySet : "",
				entityCallFormat = this._buildEntityFormatCall(params),
				sPath = "/" + entitySet + entityCallFormat;

			oDataModel.remove(sPath, {
				success: (oData, oResponse) => {
					this._handleSuccess(oResponse, oData, params);
				},
				error: (oResponse, sStatus, sError) => {
					this._handleError(oResponse, params);
				},
				urlParameters: params.aUrlParameters
			});
		},

		/*========================================= Batch ==========================================*/

		batchInit: function () {
			this.BatchModel = this._buildOdataModel({
				servicePath: Constants.getServicePath(),
				useBatch: true,
				disableHeadRequestForToken: true,
				defaultCountMode: "None",
				defaultUpdateMethod: sap.ui.model.odata.UpdateMethod.Put
			});
			this.BatchModel.setUseBatch(true);
			this.BatchModel.setDeferredGroups(["HEP"]);
		},

		handleBatchCreate: function (params) {
			const entitySet = params.entitySet ? params.entitySet : "",
				sPath = "/" + entitySet;
			params = this._setAPIHeaders(params);

			this.BatchModel.create(sPath, params.data, {
				groupId: "HEP",
				success: (oData, oResponse) => {
					this._handleSuccess(oResponse, oData, params);
				},
				error: (oResponse, sStatus, sError) => {
					this._handleError(oResponse, params);
				},
				urlParameters: params.aUrlParameters
			});
		},

		handleBatchUpdate: function (params) {
			const entitySet = params.entitySet ? params.entitySet : "",
				entityCallFormat = this._buildEntityFormatCall(params),
				sPath = "/" + entitySet + entityCallFormat;

			this.BatchModel.update(sPath, params.data, {
				groupId: "HEP",
				success: (oData, oResponse) => {
					this._handleSuccess(oResponse, oData, params);
				},
				error: (oResponse, sStatus, sError) => {
					this._handleError(oResponse, params);
				},
				urlParameters: params.aUrlParameters
			});
		},

		handleBatchDelete: function (params) {
			const entitySet = params.entitySet ? params.entitySet : "",
				entityCallFormat = this._buildEntityFormatCall(params),
				sPath = "/" + entitySet + entityCallFormat;

			params = this._setAPIHeaders(params);

			this.BatchModel.remove(sPath, {
				groupId: "HEP",
				success: (oData, oResponse) => {
					this._handleSuccess(oResponse, oData, params);
				},
				error: (oResponse, sStatus, sError) => {
					this._handleError(oResponse, params);
				},
				urlParameters: params.aUrlParameters
			});
		},

		handleBatchSubmit: function (params) {
			this.BatchModel.setHeaders(this._setAPIHeaders().headers);
			this.BatchModel.submitChanges({
				groupId: "HEP",
				success: function (oResponse) { },
				error: function (oError) { }
			});
		},

		/*========================================= Ajax call ==============================================*/

		handleReadRest: function (params) {
			const sUrl = params.url,
				apiKey = Constants.getAPIHeaders().APIKey,
				apiSecret = Constants.getAPIHeaders().APISecret;
			jQuery.ajax({
				url: sUrl,
				dataType: "json",
				method: "GET",
				headers: {
					"X-Requested-With": "XMLHttpRequest",
					"Content-Type": "application/json",
					"DataServiceVersion": "2.0",
					"APIKey": apiKey,
					"APISecret": apiSecret
				},
				success: (oData, oResponse) => {
					return params.callbackSuccess(oData);
				},
				error: (oResponse, sStatus, sError) => {
					if (params.ignoreErrors === true) {
						return params.callbackError(sError);
					} else {
						return HandleErrorMessage.callbackError(oResponse, params, this);
					}
				}
			});
		},

		/*================================ Succcess/ Error Call  handle ====================================*/

		_handleError: function (oResponse, params) {
			if (oResponse.headers["com.sap.cloud.security.login"] === "login-request") {
				return HandleSessionTimeout.fnSessionTimeout(params, this);
			} else if (params.callbackError) {
				return params.callbackError(oResponse);
			} else {
				return HandleErrorMessage.callbackError(oResponse, params, this);
			}
		},

		_handleSuccess: function (oResponse, oData, params) {
			if (oResponse.headers["com.sap.cloud.security.login"] === "login-request") {
				return HandleSessionTimeout.fnSessionTimeout(params, this);
			} else if (params.expectNonEmptyResponse && oData.results.length === 0) {
				return HandleErrorMessage.callbackError(oResponse, params, this);
			} else {
				if (oResponse.headers["sap-message"] !== undefined) {
					HandleSuccessMessages._fnSuccessMessages(oResponse.headers["sap-message"], params, oData, oResponse);
				}
				if (params.callbackSuccess) {
					return params.callbackSuccess(oData, params);
				}
			}
		},

		/*========================================= Function call ==========================================*/

		handleFunctionCall: function (params) {
			params = this._setAPIHeaders(params);
			const oDataModel = new ODataModel({
				serviceUrl: params.servicePath,
				useBatch: false,
				disableHeadRequestForToken: true,
				tokenHandlingForGet: true,
				headers: params.headers
			}),
				sPath = "/" + params.function;

			oDataModel.callFunction(sPath, {
				method: params.method,
				urlParameters: params.urlParameters,
				success: (oData, oResponse) => {
					this._handleSuccess(oResponse, oData, params);
				},
				error: (oResponse, sStatus, sError) => {
					this._handleError(oResponse, params);
				}
			});
		},

		/*=============================== Build urlparams / specific format entity =========================*/

		_buildUrlParamsReadCall: function (params) {
			const urlParameters = {};
			if (params.expand) {
				urlParameters.$expand = params.expand;
			}
			if (params.filter) {
				urlParameters.$filter = params.filter;
			}
			if (params.select) {
				urlParameters.$select = params.select;
			}
			if (params.sortItem) {
				urlParameters.$orderby = params.sortItem + " ";
				urlParameters.$orderby += params.sortOrder !== undefined ? params.sortOrder : "asc";
			}
			if (params.paginationTop !== undefined) {
				urlParameters.$top = params.paginationTop;
			}
			if (params.paginationSkip !== undefined) {
				urlParameters.$skip = params.paginationSkip;
			}
			if (params.inlineCount) {
				urlParameters.$inlinecount = params.inlineCount;
			}
			if (params.mCustomUrlParameters) {
				params.mCustomUrlParameters.forEach((value, key) => {
					urlParameters[key] = value;
				});
			}
			return urlParameters;
		},

		_buildEntityFormatCall: function (params, deleteAttachments) {
			const getEntityTypeCall = {};

			if (params.hasOwnProperty("getEntity") && Object.prototype.toString.call(params.getEntity) === "[object String]") {
				if (params.isGuid) {
					getEntityTypeCall.getEntity = "(guid'" + params.getEntity + "')";
				} else if (deleteAttachments === true) {
					getEntityTypeCall.getEntity = "(" + params.getEntity + ")";
				} else {
					getEntityTypeCall.getEntity = "('" + params.getEntity + "')";
				}
			}

			if (params.hasOwnProperty("getEntity") && Object.prototype.toString.call(params.getEntity) === "[object Array]") {
				if (params.isGuid) {
					getEntityTypeCall.getEntity = "(guid'" + params.getEntity + "')";
				} else if (deleteAttachments === true) {
					getEntityTypeCall.getEntity = "(" + params.getEntity + ")";
				} else {
					getEntityTypeCall.getEntity = "('" + params.getEntity + "')";
				}
			}

			if (params.getEntityMultiple) {
				getEntityTypeCall.getEntity = "(" + params.getEntityMultiple + ")";
			}

			if (params.pathTO) {
				getEntityTypeCall.getEntity = "(" + params.getEntityMultiple + ")" + params.pathTO;
			}

			return getEntityTypeCall.getEntity ? getEntityTypeCall.getEntity : "";
		}
	};
});
