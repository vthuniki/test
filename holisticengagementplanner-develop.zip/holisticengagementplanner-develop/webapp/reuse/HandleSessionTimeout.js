sap.ui.define([
	"com/sap/ui/hep/reuse/Constants"

], function (Constants) {
	"use strict";
	return {

		fnSessionTimeout: function (params, oContext) {
			let seconds = Constants.getSessionTimeoutRefreshInterval(),
				oModelName = "localModel",
				counter = seconds,
				count;

			count =
				setInterval(() => {
					counter--;
					if (counter >= 0) {
						let sText = params.currentView.getController().getResourceBundle().getText("Session.Timeout.ContentPageReload", [counter]);
						sap.ui.getCore().byId("countReload").setText(sText);
					}
					if (counter === 0) {
						this.dialog.close();
						let mylocation = location;
						/* eslint-disable */
						mylocation.reload(true);
						/* eslint-enable */
						clearInterval(count);
					}
				}, 1000);

			if (params.model !== undefined) {
				oContext.handleBusyIndicators(params, oModelName);
			}

			if (!this.dialog) {
				this.dialog = this._createDialog(params, seconds);
				this.dialog.open();
			} else {
				this.dialog.open();
			}
		},

		_createDialog: function (params, seconds) {
			return new sap.m.Dialog({
				contentWidth: "auto",
				showHeader: true,
				title: params.currentView.getController().getResourceBundle().getText("Session.Timeout.Title"),
				content: [
					new sap.m.VBox({
						width: "20rem",
						alignItems: sap.m.FlexAlignItems.Center,
						items: [
							new sap.m.Label("countReload", {
								text: params.currentView.getController().getResourceBundle().getText("Session.Timeout.ContentPageReload", [seconds])
							}),
							new sap.m.Label({
								text: params.currentView.getController().getResourceBundle().getText("Session.Timeout.ContentReloadNow")
							}),
							new sap.m.BusyIndicator({})
						]
					}).addStyleClass("sapUiTinyMargin")
				],
				beginButton: new sap.m.Button({
					text: params.currentView.getController().getResourceBundle().getText("Ok"),
					press: (oEvent) => {
						this._fnReloadNow();
					}
				})
			});
		},

		_fnReloadNow: function () {
			this.dialog.close();
			let mylocation = location;
			/* eslint-disable */
			mylocation.reload(true);
			/* eslint-enable */
		}
	};
});