sap.ui.define("com/sap/ui/hep/reuse/Constants", [
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/LocaleData",
	"sap/ui/core/Core"
], function (DateFormat, LocaleData, Core) {
	"use strict";

	const sessionTimeoutRefreshInterval = {
		seconds: 10
	};
	const pagination = {
		top: 10,
		initialSkip: 0
	};
	const paginationServices = {
		top: 50,
		initialSkip: 0
	};
	const genericCaseTypeForReasons = "ZS02";
	const constants = {
		servicePathWithoutLangParam: sap.ui.require.toUrl("com/sap/ui/hep") + "/ZS_APP_HEP_SRV/",
		langParam: "?sap-language=en",
		servicePath: sap.ui.require.toUrl("com/sap/ui/hep") + "/ZS_APP_HEP_SRV/?sap-language=en",
		servicePathPEA: sap.ui.require.toUrl("com/sap/ui/hep") + "/ZS_APP_PEA_SRV/",
		servicePathSPD: sap.ui.require.toUrl("com/sap/ui/hep") + "/ZS_APP_SPD_SRV/",
		userApi: sap.ui.require.toUrl("com/sap/ui/hep") + "/ZS_APP_HEP_SRV/UserSet('DUMMY')",

		//Mobile Usage Reporting (MUR)
		usageReportingTrackingUrl: "https://" + "trackingshallwe.hana.ondemand.com/web-client/v3",

		//Service and Support Catalog (SSC)
		SscUrl: "https://" + "servicescatalog.cvdp3eof-dbsservic1-p1-public.model-t.cc.commerce.ondemand.com",
		RequestSscAllFocusPackages: sap.ui.require.toUrl("com/sap/ui/hep") + "/rest/v2/servicescatalog/products/search?query=:relevance:serviceObject:Service+Plan&currentPage=0&pageSize=2000",
		RequestSscAllBusinessScenarioModules: sap.ui.require.toUrl("com/sap/ui/hep") + "/rest/v2/servicescatalog/products/search?query=:relevance:serviceObject:Business+Scenario+module&currentPage=0&pageSize=2000",
		RequestSscAllFocusPackageComponents: sap.ui.require.toUrl("com/sap/ui/hep") + "/odata2webservices/ServicePlannerOutbound/SCServices?$filter=crmSupported%20eq%201%20and%20approvalStatus/code%20eq%20%27approved%27%20and%20(serviceStatus/code%20eq%20%27ZSPM_SERVICE_STATUS_05%27)%20and%20serviceObject/code%20eq%20%27ZSPM_SERVICE_OBJECT_1040%27&$top=1000&$expand=scProjectPhase",
		RequestSscAllBusinessScenarioModuleComponents: sap.ui.require.toUrl("com/sap/ui/hep") + "/odata2webservices/ServicePlannerOutbound/SCServices?$filter=crmSupported%20eq%201%20and%20approvalStatus/code%20eq%20%27approved%27%20and%20(serviceStatus/code%20eq%20%27ZSPM_SERVICE_STATUS_05%27)%20and%20serviceObject/code%20eq%20%27ZSPM_SERVICE_OBJECT_1070%27&$top=1000&$expand=scProjectPhase",
		SSCSingleFP: sap.ui.require.toUrl("com/sap/ui/hep") + "/rest/v2/servicescatalog/products/",
		SSCServiceObjectCodes: sap.ui.require.toUrl("com/sap/ui/hep") + "/odata2webservices/SSCServiceObjectsEnums/ZSPM_SERVICE_OBJECTs",
		SSCItem: sap.ui.require.toUrl("com/sap/ui/hep") + "/odata2webservices/ServicePlannerOutbound/SCServices('Online|servicescatalogProductCatalog|",
		SSCFPItems: "')/childServicesObjects",
		SSCFPServiceObject: "')/serviceObject",
		SSCFPComponentPhases: "')/scProjectPhase",
		SSCComponentEstimatedEffort: sap.ui.require.toUrl("com/sap/ui/hep") + "/odata2webservices/ServicePlannerOutbound/ProductFeatures('Online|servicescatalogProductCatalog|null|null|null|servicescatalogClassification%252F1.0%252FSC.effortestimate|",
		SSCComponentDetailsAndPhases: "')?$expand=scProjectPhase",

		pathModelFrequentlyUsedLinks: sap.ui.require.toUrl("com/sap/ui/hep") + "/model/frequentlyUsedLinks.json",
		SAPPeopleUrl: "https://" + "people.wdf.sap.corp/profiles/",
		attachmentsUploadUrl: sap.ui.require.toUrl("com/sap/ui/hep") + "/ZS_APP_HEP_SRV/AttachmentSet()",

		//Navigation ("sap-ushell-navmode" "explace",  add this param if the navigation target should be opened in a new tab)
		peActivityDevWorkzoneUrl: "https://" + "sapit-customerengagementworkplace-dev-duck.launchpad.cfapps.eu10.hana.ondemand.com/site?siteId=d41bbd55-43eb-47d9-817d-98eeabf4b008&sap-language=en#peactivity-display?sap-ui-app-id-hint=b6f2a838-8b49-468b-8512-d0c11c1beb8f&/",
		peActivtyCrossAppHashDev:  "peactivity-display?ssap-ui-app-id-hint=b6f2a838-8b49-468b-8512-d0c11c1beb8f&sap-ushell-navmode=explace&/",
		peActivtyCrossAppHashTest:  "peactivity-display?sap-ui-app-id-hint=556cc578-48fa-4640-bbfa-a6803d6bf76f&sap-ushell-navmode=explace&/",
		peActivtyCrossAppHashProd:  "peactivity-display?sap-ushell-navmode=explace&/",

		srsCrossAppHashTest: "servicerequestscoping-Display?sap-ui-app-id-hint=0df2cd0e-97c4-43bf-b23d-ebc5e8f2e55a&sap-ushell-navmode=explace",
		srsCrossAppHashProd: "servicerequestscoping-Display?sap-ushell-navmode=explace",


	};

	const sURlJamPageMaintenanceProd = "https:" + "//jam4.sapjam.com/wiki/show/mkzdBB4lvK5SYR72eHOs81";
	const downloadSupportedBrowsersUrl = {
		chrome: "https://" + "www.google.com/chrome",
		edge: "https://" + "www.microsoft.com/edge"
	};
	const requestAuthorizationUrl = {
		tqm: "https://" + "fiorilaunchpad.sap.com/sites#arm-Create&/createRequest/prefilled?system=ICP&mandant=001&role=00:SU02__:GP",
		coe: "https://" + "fiorilaunchpad.sap.com/sites#arm-Create&/createRequest/prefilled?system=ICP&mandant=001&role=00:SU40__:GP",
		bo: "https://" + "fiorilaunchpad.sap.com/sites#arm-Create&/createRequest/prefilled?system=ICP&mandant=001&role=00:SU36__:GP",
		csp: "https://" + "fiorilaunchpad.sap.com/sites#arm-Create&/createRequest/prefilled?system=ICP&mandant=001&role=00:SU07__:GP"
	};
	const messageTypes = {
		info: "Information",
		warning: "Warning",
		success: "Success",
		error: "Error"
	};

	const baseSapIt = {
		baseLinkEmployees: sap.ui.require.toUrl("com/sap/ui/hep") + "/employee-data/Employees",
		employeePictureExtension: "/profilePicture?size=ORIGINAL"
	};

	const serviceType = {
		"onsite": "A",
		"remote": "B"
	};
	const serviceTypeItems = [{
		"ID": "A",
		"Name": "On Site"
	}, {
		"ID": "B",
		"Name": "Remote"
	}];
	const noteTypes = {
		"0001": "Description",
		"0005": "Management Summary",
		"0002": "Internal Note",
		"0003": "Concluding Remark",
		"0007": "Latest Status",
		"0010": "Open Decision",
		"0011": "Rating Reason"
	};
	const noteTypeNone = {
		key: "0000",
		name: "None"
	};
	const projectStatus = {
		"71": "New",
		"80": "In Process",
		"81": "In Escalation",
		"90": "Closed"
	};
	const serviceStatus = {
		SO: {
			"ZSK00001|E0001": "New",
			"ZSK00001|E0007": "Cancelled",
			"ZSK00001|E0005": "Delivered",
			"ZSK00001|E0016": "Delivery Preparation",
			"ZSK00001|E0002": "Delivery Confirmed",
			"ZSK00001|E0015": "Service/Project Planning"
		},
		SR: {
			"ZSRQ0001|E0001": "New",
			"ZSRQ0001|E0003": "In Scoping",
			"ZSRQ0001|E0008": "Author Action",
			"ZSRQ0001|E0002": "Violated",
			"ZSRQ0001|E0004": "In Exception",
			"ZSRQ0001|E0005": "Approved",
			"ZSRQ0001|E0006": "Cancelled",
			"ZSRQ0001|E0007": "SO Created"
		}

	};
	const projectStatusItems = [{
		"key": "71",
		"name": "New"
	}, {
		"key": "80",
		"name": "In Process"
	}, {
		"key": "81",
		"name": "In Escalation"
	}, {
		"key": "90",
		"name": "Closed"
	}];

	const serviceOrderStatus = {
		"cancel": "E0007",
		"release": "E0016",
		"planning": "E0015",
		"new": "E0001"
	};
	const ratingTypes = {
		"0": {
			"Type": "No Rating",
			"Value": "No Rating"
		},
		"1": {
			"Type": "A",
			"Value": "Green"
		},

		"2": {
			"Type": "B",
			"Value": "Yellow"
		},

		"3": {
			"Type": "C",
			"Value": "Red"
		}
	};
	const objectTypes = {
		"0": {
			"Type": "ZSR1",
			"Value": "Service Request"
		},
		"1": {
			"Type": "ZSK1",
			"Value": "Service Order"
		}
	};
	const objectTypesSPD = {
			"0": {
				"Type": "ZSR1",
				"Value": "Service Request"
			},
			"1": {
				"Type": "ZSK1",
				"Value": "Service Order"
			},
			"2": {
				"Type": "YSP1",
				"Value": "Draft"
			}
	};
	const sapInvolvment = {
		"0": {
			"value": "None",
			"key": ""
		},
		"1": {
			"value": "Co-Innovation",
			"key": "ZSAGSINV05"
		},
		"2": {
			"value": "Consulting (SOW based)",
			"key": "ZSAGSINV02"
		},
		"3": {
			"value": "Joint Ownership (Prime, SOW based)",
			"key": "ZSAGSINV04"
		},
		"4": {
			"value": "Not Involved",
			"key": "ZSAGSINV00"
		},
		"5": {
			"value": "Proactive Engagement (contingent based)",
			"key": "ZSAGSINV03"
		},
		"6": {
			"value": "OBSOLETE",
			"key": "ZSAGSINV10"
		},
		"7": {
			"value": "Reactive Involvement (awareness or de-escalation)",
			"key": "ZSAGSINV01"
		},
		"8": {
			"value": "Preferred Success Involvement",
			"key": "ZSAGSINV06"
		}
	};
	const projectStatusTypes = {
		"0": {
			"value": "New",
			"key": "New"
		},
		"1": {
			"value": "In Process",
			"key": "In Process"
		},
		"2": {
			"value": "In Escalation",
			"key": "In Escalation"
		}
	};
	const deploymentType = {
		"0": {
			"value": "None",
			"key": ""
		},
		"1": {
			"value": "HEC / PrivateCloud",
			"key": "ZSPRCLOU02"
		},
		"2": {
			"value": "Hybrid",
			"key": "ZSPRCLOU04"
		},
		"3": {
			"value": "On Premise",
			"key": "ZSPRCLOU01"
		},
		"4": {
			"value": "Public Cloud",
			"key": "ZSPRCLOU03"
		}
	};
	const freeTextColumnsServices = ["SoldToName", "ServiceDescr", "ComponentDescr", "CaseTitle", "ObjectTitle", "ServiceOrderGroup", "ComponentDescrAlternative", "RefSystemNameShort"];
	const freeTextColumnsProjects = ["ReasonDescr", "CustomerName", "ProjectDescription" , "ProjectName"];
	const navigateToICD = {
		url: "https:" +
			"//icd.wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?sap-language=EN&saprole=ZSU_DEFAULT&crm-object-type=CRM_CMG&crm-object-action=B&crm-object-keyname=EXT_KEY&crm-object-value="

	};
	const navigateToICT = {
		url: "https:" +
			"//ict.wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?sap-language=EN&saprole=ZSU_DEFAULT&crm-object-type=CRM_CMG&crm-object-action=B&crm-object-keyname=EXT_KEY&crm-object-value="
	};
	const navigateToICP = {
		url: "https:" +
			"//icp.wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?sap-language=EN&saprole=ZSU_DEFAULT&crm-object-type=CRM_CMG&crm-object-action=B&crm-object-keyname=EXT_KEY&crm-object-value="
	};
	const oCRMCreationLinks = {
		navigateToCreateToICD: "https:" +
			"//icd.wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?sap-language=EN&saprole=ZSU_DEFAULT&crm-object-type=CRM_CMG&crm-object-action=D",
		navigateToCreateToICT: "https:" +
			"//ict.wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?sap-language=EN&saprole=ZSU_DEFAULT&crm-object-type=CRM_CMG&crm-object-action=D",
		navigateToCreateToICP: "https:" +
			"//icp.wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?sap-language=EN&saprole=ZSU_DEFAULT&crm-object-type=CRM_CMG&crm-object-action=D"
	};
	const oCRMCreateEngCaseLinks = {
		dev: "https" +
			"://icd.wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?sap-language=EN&saprole=ZSU_DEFAULT&crm-object-type=ZS_CRM_CMG_ENG2&crm-object-action=D",
		test: "https" +
			"://ict.wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?sap-language=EN&saprole=ZSU_DEFAULT&crm-object-type=ZS_CRM_CMG_ENG2&crm-object-action=D",
		prod: "https" +
			"://icp.wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?sap-language=EN&saprole=ZSU_DEFAULT&crm-object-type=ZS_CRM_CMG_ENG2&crm-object-action=D"
	};

 	// Do not chnage the position of objects inside results-array
	const oCrmCustomizingProjectPhases = {
		"results": [{
			"DdlbKey": "None",
			"Type": "PhaseID",
			"Value": "None"
		}, {
			"DdlbKey": "WTF_00",
			"Type": "PhaseID",
			"Value": "Discover"
		}, {
			"DdlbKey": "WTF_01",
			"Type": "PhaseID",
			"Value": "Prepare"
		}, {
			"DdlbKey": "WTF_02",
			"Type": "PhaseID",
			"Value": "Explore"
		}, {
			"DdlbKey": "WTF_03",
			"Type": "PhaseID",
			"Value": "Realize"
		}, {
			"DdlbKey": "WTF_04",
			"Type": "PhaseID",
			"Value": "Deploy"
		}, {
			"DdlbKey": "WTF_05",
			"Type": "PhaseID",
			"Value": "Run"
		}]
	};

	const projectInitiative = {
		"Project": "ZSPROMET04",
		"Operations": "ZSPROMET03"
		//"Agile": "ZSPROMET02", //do not use any more
		//"Waterfall": "ZSPROMET01" //do not use any more
	};

	const projectInitiativePhases = {
		"ZSPROMET04": [{ //Project
			"PhaseNo": "01",
			"PhaseID": "WTF_00",
			"PhaseName": "Discover"
		}, {
			"PhaseNo": "02",
			"PhaseID": "WTF_01",
			"PhaseName": "Prepare"
		}, {
			"PhaseNo": "03",
			"PhaseID": "WTF_02",
			"PhaseName": "Explore"
		}, {
			"PhaseNo": "04",
			"PhaseID": "WTF_03",
			"PhaseName": "Realize"
		}, {
			"PhaseNo": "05",
			"PhaseID": "WTF_04",
			"PhaseName": "Deploy"
		}, {
			"PhaseNo": "06",
			"PhaseID": "WTF_05",
			"PhaseName": "Run"
		}],

		"ZSPROMET03": [{ //Operations
			"PhaseNo": "01",
			"PhaseID": "WTF_05",
			"PhaseName": "Run"
		}]
	};

	const crmPhaseForSSCPhase = {
		//PhaseID in SSC : PhaseID in CRM
		"1002": "WTF_00",
		"1110": "WTF_01",
		"1111": "WTF_02",
		"1003": "WTF_03",
		"1004": "WTF_04",
		"1005": "WTF_05"
	};

	const entities = {
		"DropDownEntity": "DropDownListSet",
		"CustomerEntity": "CustomerSet",
		"ProjectEntity": "ProjectSet()",
		"ProjectPhasesEntity": "ProjectPhaseSet()",
		"ProjectItemEntity": "ProjectItemSet",
		"ProjectSetEntity": "ProjectSet",
		"ServicePlanItemsEntity": "ServiceOrderItem",
		"ServiceItem": "ServiceItemSet",
		"ValueHelp": "ValueHelpSet",
		"CaseEntitySet": "CaseSet",
		"ContractEntity": "ContractSet",
		"ServicePlanHeaderSet": "ServicePlanHeaderSet",
		"NoteSet": "NoteSet",
		"VariantDataSet": "VariantDataSet",
		"CloudReferenceObjectSet": "CloudReferenceObjectSet",
		"RelatedTenantVHSet" : "RelatedTenantVHSet",
		"CloudModuleVHSet" : "CloudModuleVHSet",
		"IBaseComponentSet" : "IBaseComponentSet",
		"ReferenceObjectSet" : "ReferenceObjectSet"
	};

	const flagValues = {
		0: {
			key: "N",
			name: "No"
		},
		1: {
			key: "Y",
			name: "Yes"
		}
	};
	const systemUsageValues = {
		0: {
			key: "",
			name: "Any"
		},
		1: {
			key: "PROD",
			name: "Productive Use"
		},
		2: {
			key: "TEST",
			name: "Test system"
		},
		3: {
			key: "DEVELOP",
			name: "Development system"
		}
	};
	const deploymentModelValues = {
		0: {
			key: "ALL",
			name: "All"
		},
		1: {
			key: "CLOUD",
			name: "Cloud"
		},
		2: {
			key: "ON_PREM",
			name: "On Premise"
		},
		3: {
			key: "HEC",
			name: "HEC"
		}
	};
	const alreadyAddedOptions = {
		0: {
			key: "ALL",
			name: "Not Relevant"
		},
		1: {
			key: "YES",
			name: "Yes"
		},
		2: {
			key: "NO",
			name: "No"
		}
	};
	const systemSolManOptions = {
		0: {
			key: 0,
			name: "Nothing required"
		},
		1: {
			key: 1,
			name: "At least System"
		},
		2: {
			key: 2,
			name: "At least Solution Manager"
		},
		3: {
			key: 3,
			name: "System and Solution Manager"
		}
	};
	const sortOrder = {
		Ascending: "asc",
		Descending: "desc"
	};
	const attachmentsFileSizeLimit = {
		MB: 10
	};
	const accounts = {
		"dev": {
			internal: true,
			type: "dev"
		},
		"test": {
			internal: false,
			type: "test"
		},
		"prod": {
			internal: false,
			type: "prod"
		}
	};
	const noteTypesArray = {
		"noteTypes": [{
			key: "0000",
			name: "None"
		}, {
			key: "0001",
			name: "Description"
		}, {
			key: "0005",
			name: "Management Summary"
		}, {
			key: "0002",
			name: "Internal Note"
		}, {
			key: "0003",
			name: "Concluding Remark"
		}, {
			key: "0007",
			name: "Latest Status"
		}, {
			key: "0010",
			name: "Open Decision"
		}, {
			key: "0011",
			name: "Rating Reason"
		}]
	};

	const serviceRequestAccountUrl = {
		"dev": "flpsandbox-br339jmc4c.dispatcher.int.sap.eu2.hana.ondemand.com/sites/sapitflpdev?evictCache=true#servicerequestscoping-Display&/DetailView/",
		"test": "fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites?hc_reset&sap-language=en#servicerequestscoping-Display&/DetailView/",
		"prod": "fiorilaunchpad.sap.com/sites?sap-language=en#servicerequestscoping-Display&/DetailView/"
	};

	const accountStatementUrl = {
		"dev": "sap-sac.eu10.sapanalytics.cloud/sap/fpa/ui/app.html#/story2&/s2/EAE0D287B9FEDBE3F5DEABD192FEC794/?",
		"test": "sap-sac.eu10.sapanalytics.cloud/sap/fpa/ui/app.html#/story2&/s2/EAE0D287B9FEDBE3F5DEABD192FEC794/?",
		"prod": "sap-sac.eu10.sapanalytics.cloud/sap/fpa/ui/app.html#/story2&/s2/EAE0D287B9FEDBE3F5DEABD192FEC794/?"

	};

	const oReasonOptions = {
		globalEng: "ENG1",
		engagement: "ENG2",
		project: "ENG3",
		COEWatch: "ENG4",
		COETask: "ENG5",
		COEWar: "ENG6",
		AdvRes: "ENG7",
		AdvStd: "ENG8",
		MCC: "ENGA",
		services: "services"
	};

	const oCaseTypeOptions = {
		caseType: "ZS02",
		caseTypeESCA: "ZS01"
	};

	const oSpecialReasonsCases = [
		"ENG1", "ENG2", "ZS01"
	];

	const oRangeFiltersHome = {
		projectOptions: {
			defaultSelected: "mine",
			options: [{
				key: "mine",
				value: "My Projects"
			}, {
				key: "myFavorite",
				value: "My Favorite Projects"
			}, {
				key: "all",
				value: "All Projects"
			}]
		},
		engagementsOptions: {
			defaultSelected: "mine",
			options: [{
				key: "mine",
				value: "My Engagements",
				defaultSelected: "mine"
			}, {
				key: "myFavorite",
				value: "My Favorite Engagements"
			}, {
				key: "all",
				value: "All Engagements"
				// defaultSelected: "all"
			}]
		},
		servicesOptions: {
			defaultSelected: "mine",
			options: [{
				key: "mine",
				value: "My Services",
				defaultSelected: "mine"
			}, {
				key: "myFavorite",
				value: "My Favorite Services"
			}, {
				key: "all",
				value: "All Services"
				// defaultSelected: "all"
			}, {
				key: "createdByMe",
				value: "Created By Me"
			}]
		}
	};

	const referenceObjectPopupInitialComboValues = {
		relPartnerFlagSelectedKey: "Y",
		deletionFlagSelectedKey: "N",
		systemUsageSelectedKey: "",
		solmanUsageSelectedKey: "",
		installationsSelectedKey: "",
		deploymentModelSelectedKey: "ALL",
		systemSolManSelectedValue: "",
		alreadyAddedSelectedKey: "ALL"
	};

	const caseRatingComboValues = {
		ratings: [{
			key: "",
			value: "(not defined)",
			icon: "sap-icon://circle-task"
		}, {
			key: "A",
			value: "(green)",
			icon: "sap-icon://circle-task-2"
		}, {
			key: "B",
			value: "(yellow)",
			icon: "sap-icon://circle-task-2"
		}, {
			key: "C",
			value: "(red)",
			icon: "sap-icon://circle-task-2"
		}]
	};

	const engagementReasonComboValues = {
		reason: [{
			key: "ENG1",
			value: "Global Engagement Case"
		}, {
			key: "ENG2",
			value: "Engagement Case"
		}]
	};

	const visibleRowsRO = 20;
	const ganttPanelSize = 52 + "%";

	/* Text for client time zone */
	const sTimeZoneText = new Date().toLocaleTimeString("en-us", {
		timeZoneName: "short"
	}).split(" ")[2];

	const sWorkRiskLinkJAM = "https://" + "jam4.sapjam.com/wiki/show/Kp24qdd3ZtWppnnRifu7lI";

	const SPDItemColours = {
		"white": "white",
		"grey": "grey",
		"light-yellow": "light-yellow",
		"dark-yellow": "dark-yellow",
		"light-blue": "light-blue",
		"dark-blue": "dark-blue"
	};

	const cbxCustKey = {
		"NotEvaluatedYet": "T",
		"No": "N",
		"Yes": "Y",
		"ManuallySwitchedToNo": "M",
		"EvaluateAgain": "E"
	};

	const cbxComboValuesBECust = [{
		"Key": "T", //equals "" in BE - translated by BE-oDataService to "T"
		"Value": "Not evaluated yet"
	}, {
		"Key": "N",
		"Value": "No"
	}, {
		"Key": "Y",
		"Value": "Yes"
	}, {
		"Key": "M",
		"Value": "Manually switched to No"
	}, {
		"Key": "E",
		"Value": "Evaluate again"
	}];

	const contractUrl = {
		"dev": "icd.wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?saprole=ZSU_DEFAULT&crm-object-type=BT112_SC&crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-value=",
		"test": "ict.wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?saprole=ZSU_DEFAULT&crm-object-type=BT112_SC&crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-value=",
		"prod": "icp.wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?saprole=ZSU_DEFAULT&crm-object-type=BT112_SC&crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-value="
	};

	const aEventsForMobileUsageReporting = [
		"Display_Engagement", "Edit_Engagement", "Create_Engagement", "Display_Project", "Edit_Project", "Create_Project",
		"Display_ServiceOrder", "Trigger_DisplayServiceOrder_InCRM", "Trigger_DisplayServiceOrder_InISDHub", "Create_ServiceOrder_InHEP",
		"Create_ServiceOrder_InSPD", "Create_ServiceOrder", "Edit_ServiceOrder", "Create_Note", "Trigger_CreateServiceRequest_InSRS",
		"Create_ServiceRequest_InSPD", "Create_SPDItems_ViaAddService", "Create_SPDItems_ViaAddPackage", "Create_SPDItems_ViaAddListOfServices",
		"Create_SPDItems_ViaImportFromSSC", "ReArrange_SPDItems", "Edit_SPDItem", "Add_ContractToEngagement", "Add_BPToEngagement",
		"Add_BPToProject", "Trigger_CreateActivity_InPEA", "Trigger_DisplayActivity_InPEA", "Selected_TabEngagementScope",
		"Selected_EngScope_AllCustomersProductiveSystems", "EngScope_Change_ScopeOfEngagement", "EngScope_Trigger_OpenListSystemsAndTenants", "EngScope_Add_CustomerToContract", "EngScope_Add_CustomerFromOutsideGU"
	];

	const oEnterpriseSupportReportingCockpitUrl = {
		"OnPremise": "successinsightcockpit-eacp.dispatcher.hana.ondemand.com/#/ABCDEFG/onpremise/systems",
		"Cloud": "successinsightcockpit-eacp.dispatcher.hana.ondemand.com/#/ABCDEFG/cloud/systems",
		"HecRise": "successinsightcockpit-eacp.dispatcher.hana.ondemand.com/#/ABCDEFG/hec/systems"
	};

	const oISDHubIssuesAndActionsManagement = {
		// decided to use Link to Test-ISDHub in our HEP-DEV-Env and prod-Link for our Test-System.
		// changed to test->test as requested by Ilka Federkiel
		// ERP-Number placeholder ABCDEFG and project-id placeholder HIJKLMN
		"dev": "xalm-test-eu20-relxtestfeatureeu20-stabledata.eu20.alm.cloud.sap/launchpad#iam-ui&/?erpNumber=ABCDEFG&crmProjectId=HIJKLMN&x-app-name=HEP",
		"test": "xalm-test-eu20-relxtestfeatureeu20-stabledata.eu20.alm.cloud.sap/launchpad#iam-ui&/?erpNumber=ABCDEFG&crmProjectId=HIJKLMN&x-app-name=HEP",
		"prod": "xalm-prod.eu20.alm.cloud.sap/launchpad#iam-ui&/?erpNumber=ABCDEFG&crmProjectId=HIJKLMN&x-app-name=HEP"
	};

	const oPartnerFct = {
		soldToParty: "00000001",
		customerForCallOff: "ZS000005",
		shipToParty1: "00000002",
		shipToParty2: "00000055"
	};

	const config = Core.getConfiguration();
	const formatLocale = config.getFormatSettings().getFormatLocale();
	const formatLocaleData = new LocaleData(formatLocale);

	return {
		getISDHubIssuesAndActionsManagementURL: function (sErpNo, sProjectNo) {
			let sEnv = this.getEnvironment(),
				sUrl = oISDHubIssuesAndActionsManagement[sEnv];
			return sUrl ? "https://" + sUrl.replace("ABCDEFG", sErpNo).replace("HIJKLMN", sProjectNo) : "";
		},

		getEnterpriseSupportReportingCockpitURL: function (sSystemKind, sErpNumber) {
			let sUrl = oEnterpriseSupportReportingCockpitUrl[sSystemKind];
			return sUrl ? "https://" + sUrl.replace("ABCDEFG", sErpNumber) : "";
		},

		getSessionTimeoutRefreshInterval: function () {
			return sessionTimeoutRefreshInterval.seconds;
		},
		getPaginationTopServices: function () {
			return paginationServices.top;
		},
		getPaginationTop: function () {
			return pagination.top;
		},
		getPaginationInitialSkip: function () {
			return pagination.initialSkip;
		},
		getServicePath: function () {
			return constants.servicePath;
		},
		getServicePathWithoutLangParam: function () {
			return constants.servicePathWithoutLangParam;
		},
		getServicePathLangParam: function () {
			return constants.langParam;
		},
		getUsageReportingTrackingUrl: function () {
			return constants.usageReportingTrackingUrl;
		},
		getSscUrl: function (sSscObjectId) {
			return sSscObjectId ? `${constants.SscUrl}/p/${sSscObjectId}` : constants.SscUrl;
		},
		getUserApi: function () {
			return constants.userApi;
		},
		getSSCAllFPs: function () {
			return constants.SSCAllFPs;
		},
		getRequestSscAllFocusPackages: function () {
			return constants.RequestSscAllFocusPackages;
		},
		getRequestSscAllBusinessScenarioModules: function () {
			return constants.RequestSscAllBusinessScenarioModules;
		},
		getRequestSscAllFocusPackageComponents: function () {
			return constants.RequestSscAllFocusPackageComponents;
		},
		getRequestSscAllBusinessScenarioModuleComponents: function () {
			return constants.RequestSscAllBusinessScenarioModuleComponents;
		},
		getAllSSCServiceObjectCodes: function () {
			return constants.SSCServiceObjectCodes;
		},
		getSSCItem: function () {
			return constants.SSCItem;
		},
		getSSCFPItems: function () {
			return constants.SSCFPItems;
		},
		getSSCFPServiceObject: function () {
			return constants.SSCFPServiceObject;
		},
		getSSCFPComponentPhases: function () {
			return constants.SSCFPComponentPhases;
		},
		getSSCComponentDetailsAndPhases: function () {
			return constants.SSCComponentDetailsAndPhases;
		},
		getSSCComponentEstimatedEffort: function () {
			return constants.SSCComponentEstimatedEffort;
		},
		getPathModelFrequentlyUsedLinks: function () {
			return constants.pathModelFrequentlyUsedLinks;
		},
		getSupportedBrowserDownloadUrl: function () {
			return downloadSupportedBrowsersUrl;
		},
		getSAPPeopleUrl: function () {
			return constants.SAPPeopleUrl;
		},
		getRequestAuthorizationUrl: function () {
			return requestAuthorizationUrl;
		},
		getMessageType: function () {
			return messageTypes;
		},
		getServiceType: function () {
			return serviceType;
		},
		getServiceTypeItems: function () {
			return serviceTypeItems;
		},
		getNoteTypeItems: function () {
			return noteTypesArray;
		},
		getNoteType: function () {
			return noteTypes;
		},
		getNoteTypeNone: function () {
			return noteTypeNone;
		},
		getServiceOrderStatusCode: function () {
			return serviceOrderStatus;
		},
		getNavigationToICD: function () {
			return navigateToICD;
		},
		getNavigationToICT: function () {
			return navigateToICT;
		},
		getNavigationToICP: function () {
			return navigateToICP;
		},
		getProjectStatus: function () {
			return projectStatus;
		},
		getServiceStatus: function () {
			return serviceStatus;
		},
		getProjectInitiative: function () {
			return projectInitiative;
		},

		getProjectPhasesCustomizing: function () {
			return oCrmCustomizingProjectPhases;
		},

		getProjectInitiativePhases: function () {
			return projectInitiativePhases;
		},

		getCrmPhaseForSSCPhase: function () {
			return crmPhaseForSSCPhase;
		},

		getEntities: function () {
			return entities;
		},
		getFlagValues: function () {
			return flagValues;
		},
		getSystemUsageValues: function () {
			return systemUsageValues;
		},
		getDeploymentModelValues: function () {
			return deploymentModelValues;
		},
		getAlreadyAddedOptions: function () {
			return alreadyAddedOptions;
		},
		getSystemSolManOptions: function () {
			return systemSolManOptions;
		},
		getSortOrder: function () {
			return sortOrder;
		},
		getAttachmentsFileSizeLimit: function () {
			return attachmentsFileSizeLimit.MB;
		},
		getAccount: function () {
			return accounts;
		},
		getItemStatus: function () {
			return projectStatusItems;
		},
		getServiceRequestAccountUrl: function () {
			return serviceRequestAccountUrl;
		},
		getAccountStatementUrl: function () {
			return accountStatementUrl;
		},
		getPeActivityDevWorkzoneUrl: function(){
			return constants.peActivityDevWorkzoneUrl;
		},
		getPeActivtyCrossAppHash: function () {
			let sEnv = this.getEnvironment();
			let sHash;
			switch (sEnv) {
				case "dev":
					sHash = constants.peActivtyCrossAppHashDev;
					break;
				case "test":
					sHash = constants.peActivtyCrossAppHashTest;
					break;
				default:
					sHash = constants.peActivtyCrossAppHashProd;
			}
			return sHash;
		},
		getSrsCrossAppHash: function () {
			let sEnv = this.getEnvironment();
			let sHash;
			switch (sEnv) {
				case "dev":
					sHash = "";  //n.a.
					break;
				case "test":
					sHash = constants.srsCrossAppHashTest;
					break;
				default:
					sHash = constants.srsCrossAppHashProd;
			}
			return sHash;
		},
		getVisibleRowsRO: function () {
			return visibleRowsRO;
		},
		getGanttPanelSize: function () {
			return ganttPanelSize;
		},
		getReasonOptions: function () {
			return oReasonOptions;
		},
		getRangeFiltersHome: function () {
			return oRangeFiltersHome;
		},
		getTimeZoneText: function () {
			return sTimeZoneText;
		},
		getCRMCreationLinks: function () {
			return oCRMCreationLinks;
		},
		getCRMCreateEngCaseLinks: function () {
			return oCRMCreateEngCaseLinks;
		},
		getCaseTypes: function () {
			return oCaseTypeOptions;
		},
		getServicePathPEA: function () {
			return constants.servicePathPEA;
		},
		getServicePathSPD: function () {
			return constants.servicePathSPD;
		},
		getSpecialReasonCase: function () {
			return oSpecialReasonsCases;
		},
		referenceObjectPopupInitialComboValues: function () {
			return referenceObjectPopupInitialComboValues;
		},
		getCaseRatingComboValues: function () {
			return caseRatingComboValues;
		},
		getEngagementReasonComboValues: function () {
			return engagementReasonComboValues;
		},
		getWorkRiskJAM: function () {
			return sWorkRiskLinkJAM;
		},
		getGenericCaseTypeForReasons: function () {
			return genericCaseTypeForReasons;
		},
		getProjectCaseReasonCode: function () {
			return oReasonOptions.project;
		},
		getSPDItemColour: function () {
			return SPDItemColours;
		},
		getMaintenanceJAM: function () {
			return sURlJamPageMaintenanceProd;
		},
		getEnvironment: function () {
			let sCurrentUrl = window.location.href;
			let sEnv = "dev";
			if (sCurrentUrl.includes("home-prod") || sCurrentUrl.includes("prod-elephant")) {
				sEnv = "prod";
			} else if (sCurrentUrl.includes("home-test") || sCurrentUrl.includes("test-echidna")) {
				sEnv = "test";
			}
			return sEnv;
		},
		getAPIHeaders: function () {
			let sEnv = this.getEnvironment(),
				sApiKey = this._getAPIKey(sEnv),
				sApiSecret = this._getAPISecret(sEnv);

			return {
				APIKey: sApiKey,
				APISecret: sApiSecret
			};
		},

		_getAPIKey: function (env) {
			switch (env) {
				case "dev":
					return "p7hVUQXkJAV69DupuP9z07D5wMz5AzpS";
				case "test":
					return "cZkZvEGWw66T99lxGbtCEQVVyVvfXgpb";
				case "prod":
					return "HHhK3RThWcLOEU7Sg6SSQHIQ1q3ZZfCX";
				default: // return APIKey for DEV Environment
					return "p7hVUQXkJAV69DupuP9z07D5wMz5AzpS";
			}
		},

		_getAPISecret: function (env) {
			switch (env) {
				case "dev":
					return "7dthVdRwFGAB7GJg";
				case "test":
					return "4T9kojVHS2GVL89U";
				case "prod":
					return "szdvAXatYEbQfAQT";
				default: // return APISecret for DEV Environment
					return "7dthVdRwFGAB7GJg";
			}
		},

		getCbxCustKey: function () {
			return cbxCustKey;
		},

		getCbxComboValuesBECust: function () {
			return cbxComboValuesBECust;
		},

		getMobileReportingParameterNewValues: function (sEnv) {
			switch (sEnv) {
				case "dev":
					return {
						reportingId: "holisticengagementplanner_dev",
						reportingHost: window.location.hostname
					};
				case "test":
					return {
						reportingId: "holisticengagementplanner_test",
						reportingHost: window.location.hostname
					};
			}
			return undefined;
		},

		getArrayOfValidEventNames: function () {
			return aEventsForMobileUsageReporting;
		},

		getSPDDetailsComponentItemColour: function (sItemType, sUIComponentStatus, sUIFormatting) {
			const simpleColors = {
				"H": {first: "plan"},
				"L": {first: "light"},
				"T": {first: ""}
			};

			let {first: firstC} = simpleColors[sUIFormatting];

			function getYellow(uiFormatting) {
				return uiFormatting === "T" ? "None" : firstC + "-yellow";
			}

			function getBlue(uiFormatting) {
				return uiFormatting === "T" ? "Indication05" : firstC + "-blue";
			}

			function getOrange(uiFormatting) {
				return uiFormatting === "T" ? "Indication03" : firstC + "-orange";
			}

			function getPurple(uiFormatting, defaultValue) {
				return uiFormatting === "T" ? defaultValue : firstC + "-purple";
			}

			function getGreen(uiFormatting) {
				return uiFormatting === "T" ? "Indication04" : firstC + "-green";
			}

			const colorsTable = {
				"ZSK1": {
					"New": getYellow(sUIFormatting), /*yellow -> Overruled by CSS + CustomData in ObjectStatus of fragment*/
					"Frontoffice Action": getOrange(sUIFormatting), /*orange*/
					"Delivered": getGreen(sUIFormatting), /*green*/
					"In Delivery": getBlue(sUIFormatting), /*blue*/
					"Backoffice Action": getPurple(sUIFormatting, "Indication07"), /*purple -> Overruled by CSS + CustomData in ObjectStatus of fragment*/
					"Cancelled": sUIFormatting === "T" ? "None" : "white-grey"
				},
				"ZSR1": {
					"Delivered": getGreen(sUIFormatting), /*green*/

					"Delivery confirmed": getBlue(sUIFormatting), /*blue*/
					"In Delivery": getBlue(sUIFormatting), /*blue*/
					"Delivery Preparation": getBlue(sUIFormatting), /*blue*/

					"Approved": getOrange(sUIFormatting), /*orange*/
					"Violated": getOrange(sUIFormatting), /*orange*/
					"Author Action": getOrange(sUIFormatting), /*orange*/
					"Info Required": getOrange(sUIFormatting), /*orange*/
					"Service / Project Planning": getOrange(sUIFormatting), /*orange*/

					"In Scoping": getPurple(sUIFormatting, "Indication08"), /*purple -> Overruled by CSS + CustomData in ObjectStatus of fragment*/
					"In Exception": getPurple(sUIFormatting, "Indication08"), /*purple -> Overruled by CSS + CustomData in ObjectStatus of fragment*/

					"New": getYellow(sUIFormatting), /*yellow -> Overruled by CSS + CustomData in ObjectStatus of fragment*/
					"Draft": getYellow(sUIFormatting), /*yellow -> Overruled by CSS + CustomData in ObjectStatus of fragment*/
				},
				"YSP1": {
					"Draft": sUIFormatting === "T" ? "None" : firstC + "-grey"
				},
			}

			let sColor = colorsTable[sItemType]?.[sUIComponentStatus];

			if (sColor === "") {
				sColor = sUIFormatting === "T" ? "None" : "white";
			}
			return sColor;
		},

		getContractUrl: function () {
			return contractUrl;
		},

		getPartnerFct: function () {
			return oPartnerFct;
		},

		getBaseSapIt: function () {
			return baseSapIt;
		},

		getVariantsEntityName: function (guid) {
			return `${entities.VariantDataSet}(guid'${guid}')`;
		},

		getAttachmentsUploadUrl: function () {
			return constants.attachmentsUploadUrl;
		},

		getShortDateFormat: function() {
			return formatLocaleData.getDatePattern("short");
		},

		getMediumDateFormat: function() {
			return formatLocaleData.getDatePattern("medium");
		},

		getRatingTypes: function(){
			return ratingTypes;
		},

		getObjectTypes: function(){
			return objectTypes;
		},

		getObjectTypesSPD: function(){
			return objectTypesSPD;
		},

		getSAPInvolvment(){
			return sapInvolvment;
		},

		getProjectStatusTypes(){
			return projectStatusTypes;
		},

		getDeploymentType(){
			return deploymentType;
		},

		getFreeTextColumnsServices(){
			return freeTextColumnsServices;
		},

		getFreeTextColumnsProjects(){
			return freeTextColumnsProjects;
		}
	};
}, false);
