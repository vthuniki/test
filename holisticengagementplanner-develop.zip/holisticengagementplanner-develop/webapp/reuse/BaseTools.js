sap.ui.define([
	"sap/ui/core/Fragment",
	"sap/ui/core/syncStyleClass",
	"com/sap/ui/hep/util/NavigationToExternalApps",
	"com/sap/ui/hep/reuse/Constants",
], function (Fragment, syncStyleClass, NavigationToExternalApps, Constants) {
	"use strict";
	return {

		loadFragmentWithId: function(oFragmentController, sFragmentId, oView, sFragmentPath, fnInitialCallback){
			return this.loadFragment.call({_sFragmentId: sFragmentId},oFragmentController, oView, sFragmentPath, fnInitialCallback);
		},

		loadFragment: function (oFragmentController, oView, sFragmentPath, fnInitialCallback) {
			let _oView = oView ?? oFragmentController.getView();
			try {
				return Fragment.load({
					id: this._sFragmentId || _oView.getId(),
					name: sFragmentPath,
					controller: oFragmentController
				}).then(oFragmentContent => {
					_oView.addDependent(oFragmentContent);
					syncStyleClass(_oView.getController().getOwnerComponent().getContentDensityClass(), _oView, oFragmentContent);
					if (fnInitialCallback) fnInitialCallback(oFragmentContent);
					return oFragmentContent;
				});
			} catch (oError) {
				if (oError.statusCode === 503) {
					let params = {
						currentView: _oView
					};
					_oView.getController().handleSessionTimeout(params, _oView.getController());
				}
			}
		},

		fnGetAncestorView: function(oStartView, sAncestorViewNamePart){
			let oAncestorElement = oStartView?.getParent();
			while(oAncestorElement){
				if (oAncestorElement?.getViewName && oAncestorElement.getViewName().includes(sAncestorViewNamePart)) return oAncestorElement;
				else oAncestorElement = oAncestorElement?.getParent();
			}
		},

		fnAddOneDay: function(dDate){
			let dDatePlusOneDay = new Date(dDate);
			dDatePlusOneDay.setDate(dDatePlusOneDay.getDate() + 1);
			return dDatePlusOneDay;
		},

		fnNavigateToEngagement: function (sCaseId, sToTab = "") {
			if (sToTab && sToTab !== '') {
				this.getRouter().navTo("EngagementDetailsTab", {
					engagementID: sCaseId,
					toTab: sToTab
				});
			} else {
				this.getRouter().navTo("EngagementDetails", {
					engagementID: sCaseId
				});
			}
		},

		fnNavigateToProject: function (sProjectId, sProjectType, sProjectStatusId) {
			if (sProjectType === Constants.getCaseTypes().caseTypeESCA) {
				if (sProjectStatusId !== "") {
					NavigationToExternalApps.fnHandleLinkNavigation(this.formatter.linkFormater(sProjectId));
				} else {
					let title = this.getResourceBundle().getText("General.MessageMissingAuthDetailsTitle");
					let description = this.getResourceBundle().getText("General.MessageMissingAuthrDetailsDescription");
					let subtitle = this.getResourceBundle().getText("General.MessageMissingAuthDetailsSubtitle");
					this.messageHandler.addNewMessageseInsidePopover("errorAuthMissingDetails", "Error", title, description, subtitle, this);
				}
			} else {
				this.getRouter().navTo("ProjectDetails", {
					projectID: sProjectId
				});
			}
		},

	};
});
