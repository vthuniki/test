sap.ui.define([
	"com/sap/ui/hep/reuse/Constants",
	"com/sap/ui/hep/util/MessageHandlingPopover"
], function (Constants, MessageHandlingPopover) {
	"use strict";
	return {

		messageHandler: MessageHandlingPopover,

		
		/**
		 * @param {string} messages the message manager container
		 * @param {array} params the current parameters from where the method was called
		 * @param {object} oData the odata response
		 * @param {object} oResponse the service call response
		 */
		_fnSuccessMessages: function (messages, params, oData, oResponse) {
			this.messageHandler.resetMessageDataModel(params.oContext.getView());

			let oMessage,
				aListMsg = JSON.parse(messages),
				buttonMsg = params.oContext.getView().byId("messagePopoverButton"),
				aDetailsMsg = aListMsg.details;

			aDetailsMsg.forEach(msg => {
				if (msg.message !== "") {
					oMessage = this._buildMessage(msg);
					this._addMessageInPopover(oMessage, params);
				}
			});

			oMessage = this._buildMessage(aListMsg);
			this._addMessageInPopover(oMessage, params);

			if (!params.oContext._displayMode) {
				params.oContext.oMessagePopover.close();
				if (params.trigger && params.trigger !== "deleteItem" && params.trigger !== "createItem" && params.trigger !==
					"saveItem") {
					params.oContext.oMessagePopover.openBy(buttonMsg);
				}
			}
		},

		_buildMessage: function (msg) {
			let oMessage = {
				Id: msg.code + msg.message,
				Type: Constants.getMessageType()[msg.severity],
				Title: msg.message,
				Description: null,
				Subtitle: null,
				LongtextUrl: msg.longtext_url
			};
			if (oMessage.LongtextUrl) {
				oMessage.LongtextUrl = oMessage.LongtextUrl.replace('/sap/opu/odata/', '/int_ic_orig/');
			}
			return oMessage;
		},

		_addMessageInProjectDetailsPopover: function (oMessage, params) {
			params.oContext.messageHandler.addNewMessageseInsidePopover(
				oMessage.Id, oMessage.Type, oMessage.Title,
				oMessage.Description, oMessage.Subtitle,
				params.oContext);
		},

		_addMessageInPopover: function (oMessage, params) {
			params.oContext.messageHandler.addNewMessageseInsidePopover(
				oMessage.Id, oMessage.Type, oMessage.Title,
				oMessage.Description, oMessage.Subtitle,
				params.oContext, params, undefined, oMessage.LongtextUrl);
		}
	};
});
