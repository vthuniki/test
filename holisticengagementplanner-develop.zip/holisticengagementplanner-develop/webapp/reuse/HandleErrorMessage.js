sap.ui.define([
	"com/sap/ui/hep/reuse/HandleSessionTimeout"
], function (HandleSessionTimeout) {
	"use strict";
	return {

		_resourceBundle: new sap.ui.model.resource.ResourceModel({ bundleName: "com.sap.ui.hep.i18n.i18n" }).getResourceBundle(),

		_buildMessageDetails: function(oMsgData, statusCode, statusText, sErrorMessageStatusText, responseMessageValue){
			return {
				msgData: oMsgData,
				statusCode: statusCode,
				statusText: statusText,
				errorMessageStatusText: sErrorMessageStatusText,
				responseMessageValue: responseMessageValue
			};
		},

		_handleErrorStatusCode(statusCode, errorMessage, params, responseMessageValue, errDetails, oMsgData){
			if (statusCode === 503) {
				HandleSessionTimeout.fnSessionTimeout(params, oContext);
			} else {
				if (!statusCode) {
					statusCode = "Unknown ";
				}
				if (errorMessage !== "") {
					this._handleErrorEmptyErrorMessage(statusCode, params, responseMessageValue, errDetails, oMsgData);
				}
			}
		},

		callbackError: function (oEvent, params, oContext) {
			let oResourceBundle = this._resourceBundle,
				oMsgData = params.currentView.getModel("messageModelBE").getData(),
				oModelName = "localModel",
				responseMessageValue = "",
				errorMessage = "",
				sErrorMessageStatusText = "",
				statusCode,
				statusText = oEvent.statusText,
				errDetails,
				buttonMsg = params.oContext.getView().byId("messagePopoverButton");

			if (oMsgData.messages === undefined) {
				oMsgData.messages = [];
				oMsgData.messagesLength = 0;
			}
			if (params.model) {
				oModelName = params.model;
			}
			if (statusText !== "" && statusText !== undefined) {
				sErrorMessageStatusText += this._resourceBundle.getText('Error.Message.Text') + statusText + "";
			}

			if (params.expectNonEmptyResponse) {
				responseMessageValue = oResourceBundle.getText("Error.EmptyResponseData");
			} else if (oEvent.responseText === undefined) {
				let oMessageDetails = this._buildMessageDetails(oMsgData, statusCode, statusText, sErrorMessageStatusText, responseMessageValue)
				this._handleErrorMessageNoResponseText(oEvent, params, oModelName, oMessageDetails);
			} else if (oEvent.responseText.indexOf("<html>") !== -1) {
				statusCode = oEvent.status;
				responseMessageValue += oEvent.responseText.split("<h1>")[1].split("</h1>")[0];
			} else {
				statusCode = oEvent.statusCode;
				if (typeof oEvent.responseText === "string" && oEvent.responseText.indexOf("innererror") === -1) {
					responseMessageValue += oEvent.responseText;
				} else {
					responseMessageValue += JSON.parse(oEvent.responseText).error.message.value;
					errDetails = JSON.parse(oEvent.responseText).error.innererror.errordetails;
				}
			}
			errorMessage += this._addDetailsOfErrorMessage(statusCode, sErrorMessageStatusText, responseMessageValue);

			this._handleErrorStatusCode(statusCode, errorMessage, params, responseMessageValue, errDetails, oMsgData);

			if (!params.oContext._displayMode) {
				params.oContext.oMessagePopover.close();
				params.oContext.oMessagePopover.openBy(buttonMsg);
			}
			oContext.handleBusyIndicators(params, oModelName);
		},

		_handleErrorMessageNoResponseText: function (oEvent, params, oModelName, oMsg) {
			if (!oMsg.statusCode) {
				oMsg.statusCode = "Unknown ";
			}
			oMsg.data.messages.push({
				id: "error" + oMsg.statusCode + params.entitySet,
				type: "Error",
				title: params.errorMessage !== undefined ? params.errorMessage : this._resourceBundle.getText('Error.Message.ServerError'),
				subtitle: this._resourceBundle.getText('Error.Message.Code') + oMsg.statusCode + oMsg.sErrorMessageStatusText,
				description: this._resourceBundle.getText('Error.Message.Details') + oMsg.responseMessageValue + this._resourceBundle.getText('Error.Message.Inconvenience')
			});

			params.currentView.getModel(oModelName).getData()[params.busyIndicator] = false;
			params.currentView.getModel(oModelName).refresh();

			oMsg.statusCode = oEvent.statusCode;
			oMsg.statusText = oEvent.statusText;
			if (oEvent.statusText !== "") {
				oMsg.responseMessageValue += JSON.parse(oEvent.responseText).error.message.value;
			} else {
				oMsg.responseMessageValue = $("<h1>").html(oEvent.responseText).text();
			}
		},

		_handleProjectDetailsDisplay: function(params, errDetails, type, title, description, subtitle){
			if (errDetails !== undefined && errDetails.length > 0 && errDetails[0] !== undefined && errDetails[0].code !== "CRM_CASE/007") {
				errDetails.forEach(item => {
					params.oContext.messageHandler.addNewMessageseInsidePopover(item.code + item.message, type, title, item.message, item.message,
						params.oContext);
				});
			} else {
				params.oContext.messageHandler.addNewMessageseInsidePopover(id + title, type, title, description, subtitle, params.oContext);
			}
		},

		_handleEngagementDetailsDisplay: function(params, errDetails, id,  type, title, description, subtitle){
			if (!params.oContext._displayMode) {
				if (errDetails !== undefined && errDetails.length > 0) {
					errDetails.forEach(item => {
						params.oContext.messageHandler.addNewMessageseInsidePopover(item.code + item.message, type, title, item.message, item.message,
							params.oContext);
					});
				} else {
					if (params.url && params.url.includes("/ext_commerce")) {
						title = this._resourceBundle.getText('Error.Message.SSCNotReachable');
						description = this._resourceBundle.getText('Error.Message.SSCNoConnection');
						subtitle = this._resourceBundle.getText('Error.Message.TryAgain');
					}
					params.oContext.messageHandler.addNewMessageseInsidePopover(id + title, type, title, description, subtitle, params.oContext);
				}
			}
		},

		_handleErrorEmptyErrorMessage: function (statusCode, params, responseMessageValue, errDetails, oMsgData) {
			let id = "error" + statusCode + params.entitySet,
				type = "Error",
				title = params.errorMessage !== undefined ? params.errorMessage : this._resourceBundle.getText('Error.Message.ServerError'),
				subtitle = this._resourceBundle.getText('Error.Message.Details') + responseMessageValue + this._resourceBundle.getText('Error.Message.Inconvenience'),
				description = this._resourceBundle.getText('Error.Message.Details') + responseMessageValue + this._resourceBundle.getText('Error.Message.Inconvenience');

			if (params.oContext.getView().getViewName().split("ProjectDetails").length > 1) {
				this._handleProjectDetailsDisplay(params, errDetails, type, title, description, subtitle);
			} else {
				this._handleEngagementDetailsDisplay(params, errDetails, id, type, title, description, subtitle);
			}
			oMsgData.messagesLength = oMsgData.messages.length;
			params.currentView.getModel("messageModelBE").refresh();
		},

		_addDetailsOfErrorMessage: function (statusCode, sErrorMessageStatusText, responseMessageValue) {
			return "<ul>" +
				`<li>${this._resourceBundle.getText('Error.Message.Code')}: ` + statusCode + "</li>" +
				sErrorMessageStatusText +
				`<li>${this._resourceBundle.getText('Error.Message.Details')}: ` + responseMessageValue + "</li>" +
				"</ul>" +
				`<p>${this._resourceBundle.getText('Error.Message.Inconvenience')}`;
		}
	};
});