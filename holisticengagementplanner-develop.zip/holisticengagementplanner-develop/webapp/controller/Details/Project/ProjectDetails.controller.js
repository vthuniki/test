sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"com/sap/ui/hep/model/formatter",
	"sap/m/MessageToast",
	"com/sap/ui/hep/util/ServiceOrderManipulation",
	"com/sap/ui/hep/util/ReferenceObjects",
	"com/sap/ui/hep/util/Attachments",
	"com/sap/ui/hep/util/Notes",
	"com/sap/ui/hep/util/Dates",
	"com/sap/ui/hep/util/EmployeeDetails",
	"com/sap/ui/hep/util/MessageHandlingPopover",
	"com/sap/ui/hep/controller/Details/BaseDetails",
	"com/sap/ui/hep/util/Pagination",
	"com/sap/ui/hep/util/TablePersoProActivities",
	"sap/m/TablePersoController",
	"com/sap/ui/hep/util/serviceProductSelection/ServiceProductSelection",
	"com/sap/ui/hep/controller/Project/EditProjectDialog",
	"com/sap/ui/hep/util/NavigationToExternalApps",
	"com/sap/ui/hep/reuse/Constants"

], function ( JSONModel, Formatters,
	MessageToast, ServiceOrderManipulation, ReferenceObjects, Attachments, Notes, Dates,
	EmployeeDetails, MessageHandlingPopover,
	BaseDetails, Pagination, TablePersoProActivities,
	TablePersoController, ServiceProductSelection, EditProjectDialog, NavigationToExternalApps, Constants) {
	"use strict";
	return BaseDetails.extend("com.sap.ui.hep.controller.Details.Project.ProjectDetails", {
		formatter: Formatters,
		soManipulation: ServiceOrderManipulation,
		referenceObjects: ReferenceObjects,
		attachments: Attachments,
		notes: Notes,
		dates: Dates,
		employeeDetails: EmployeeDetails,
		messageHandler: MessageHandlingPopover,
		pagination: Pagination,
		oEditProjectDialog: new EditProjectDialog(),

		/*_____________________________________________________________________________________________________________________________________*/
		/*_____________________________________________________________________________________________________________________________________*/
		/*____________________________________________________________ StartUp  _______________________________________________________________*/
		/*_____________________________________________________________________________________________________________________________________*/

		onInit: function () {
			this.router = this.getRouter();
			this.router.getRoute("ProjectDetails").attachPatternMatched(this._handleRouteMatched, this);
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			this.getView().byId("projectPlanningSectionSS1PD").addEventDelegate({
				onAfterRendering: function () {
					setTimeout(function () {
						this.getView().byId("projectPlanningSectionSS1PD").focus();
					}.bind(this), 500);
				}.bind(this)
			});
		},

		_handleRouteMatched: function (evt) {
			this.getView().byId("ObjectPageLayoutProject").setSelectedSection("projectPlanningsSection");
			this._dataFromBus = false;
			this._initialize();
			this._idProject = evt.getParameters().arguments.projectID;
			this._readDataForAllSections();
			let oEventBusSO = this.getOwnerComponent().getEventBus(); //FOO sap.ui.getCore().getEventBus();

			oEventBusSO.unsubscribe("SOSendDelivery", "soSendToDelivery", this.fnAfterSendToDelivery, this);
			oEventBusSO.subscribe("SOSendDelivery", "soSendToDelivery", this.fnAfterSendToDelivery, this);

			oEventBusSO.unsubscribe("ChannelServicePlanSection", "LocalModelDraftPlanRefreshed", this._fnRefreshLocalModelDraftPlan, this);
			oEventBusSO.subscribe("ChannelServicePlanSection", "LocalModelDraftPlanRefreshed", this._fnRefreshLocalModelDraftPlan, this);

			oEventBusSO.unsubscribe("ChannelServicePlanSection", "DraftPlanControllerInit", this._fnOnDraftPlanControllerInit, this);
			oEventBusSO.subscribe("ChannelServicePlanSection", "DraftPlanControllerInit", this._fnOnDraftPlanControllerInit, this);

			oEventBusSO.unsubscribe("ChannelServicePlanSection", "ReloadProjectSection", this.fnRefreshProjectDetails, this);
			oEventBusSO.subscribe("ChannelServicePlanSection", "ReloadProjectSection", this.fnRefreshProjectDetails, this);
		},

		_initialize: function () {
			this.initializeModelsAndLocalData(this);
			this.partiesInvolved.init(this);

			this._oData = this.getView().getModel("localModel").getData();
			this._oModel = this.getView().getModel("localModel");

			let oLocalDraftModel = new JSONModel({});
			this.getView().setModel(oLocalDraftModel, "localDraftModel");
			this.getView().getModel("localDraftModel").getData().phaseViewRemoveMode = false;
			this.getView().getModel("localDraftModel").getData().phaseViewEditMode = false;
			this.getView().getModel("localDraftModel").getData().bItemsSelectedForRemoval = false;
			this.getView().getModel("localDraftModel").refresh();

			this._oData.paginationClicks = 0;
			this._oData.paginationSkip = 0;

			this.attachments.initializeDetails(this);
			this._oModel.refresh();
			this.initializeMessageArea(this);

			this.getView().getModel("localModel").getData().GanttFullScreen = false;

			let oModelRefObj = new JSONModel({});
			this.getView().setModel(oModelRefObj, "ReferenceObjects");
			this.getView().getModel("ReferenceObjects").getData().numberOfItems = 0;
			this.getView().getModel("ReferenceObjects").refresh();

			this.getView().getModel("localModel").getData().formEditMode = false;
			this.getView().getModel("localModel").getData().bDetailPage = true;
			this.getView().getModel("localModel").refresh();

			let oFilterModel = new JSONModel({});
			this.getView().setModel(oFilterModel, "filterModel");

			let phasesModel = new JSONModel({});
			phasesModel.setSizeLimit(10);
			this.getView().setModel(phasesModel, "projectPhasesModel");

			this._initializeActivitiesTablePerso();
			this.getView().byId("ProActivitiesTable").setContext(this);

		},

		//*  EventBus Event Handler
		_fnRefreshLocalModelDraftPlan: function (sChannel, sEvent, oLocalDraftModelData) {
			if (!this.getView().getModel("localDraftModel")) {
				let oLocalDraftModel = new JSONModel(oLocalDraftModelData);
				this.getView().setModel(oLocalDraftModel, "localDraftModel");
			}
			this.getView().getModel("localDraftModel").setData(oLocalDraftModelData);
			this.getView().getModel("localDraftModel").getData().bItemsSelectedForRemoval = !!(this.getView().getModel("localDraftModel").getData().selectedItemsForRemoval?.length);
			this.getView().getModel("localDraftModel").refresh();
		},

		//*  EventBus Event Handler
		_fnOnDraftPlanControllerInit: function (channel, event, oDraftPlanController) {
			this.DraftController = oDraftPlanController;
		},

		fnRefreshProjectDetails: function () {
			this._bRefreshingProjectDetails = true;
			this.getOwnerComponent().oHelperData.pReadProjectDetails = this.pReadProjectData(); //cached for performance reasons, used in DraftController
			this.getOwnerComponent().oHelperData.pReadProjectDetails.then(() => {
				this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "ProjectPhaseDatesChanged", null);
			});
		},

		_readDataForAllSections: function () { //called from BaseDetails when bringing in the UserDetails! And Attachments!
			this.notes.setNoteTypes(this);
			this.getOwnerComponent().oHelperData.pReadProjectDetails = undefined;
			this.getOwnerComponent().oHelperData.pReadContractCheckSet = undefined;
			this.activateBusyIndicators(this);
			this.getOwnerComponent().oHelperData.pReadProjectDetails = this.pReadProjectData(); //cached for performance reasond, used in DraftController
			this.getOwnerComponent().oHelperData.pReadProjectDetails.then(() => {
				if (!this.getView().getModel("projectDetails").getData().ProjectMethodology) this.fnHandleEditProject();
				this._preReadSPDPerformanceCriticalData(); //preloading Data
				this._readActivities();
				this._readProjectTopIssues();
				this.attachments.fnReadAttachmentsProjectDetails(this);
				this.partiesInvolved.init(this);
				this.partiesInvolved.readPartnerSet();
				this.notes.handleReadNotes(null, this);
				let oEventBus = this.getOwnerComponent().getEventBus(),
					oCaseDetails = this.getView().getModel("projectDetails").getData();
				oEventBus.publish("ChannelServicePlanSection", "ProjectIsLoaded", oCaseDetails);
				return this.referenceObjects.readReferenceObjectsOfProject(this);
			})
				.then(() => {
					this.getView().byId("ObjectPageLayoutProject").rerender();
				});
		},


		pReadProjectData: function () {
			return new Promise((resolve, reject) => {
				let entities = {};
				let idProject = this._idProject;
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "ProjectSet";
				entities.expand = "toProjectPhase";
				entities.getEntity = idProject;
				entities.currentView = this.getView();
				entities.oContext = this;
				entities.errorMessage = this.getResourceBundle().getText("ProjectDetails.ReadProjectDataError", [idProject]);
				entities.busyIndicator = "busyProjectDetailsHeader";
				entities.callbackSuccess = (data) => {
					// we check for status ID 98 which is Restricted status and show a dialog
					if (data.StatusID === "98") this._handleRestrictedProject();
					this._handleSuccessReadProjectData(data).then(() => {
						resolve(data);
					});
				};
				this.readBaseRequest(entities);
			});
		},

		_handleSuccessReadProjectData: function (data) {
			return new Promise((resolve, reject) => {
				this._oData.cloneOfProjectDetails = JSON.stringify(data);
				let aEmployees = this.getView().getModel("projectDetails").getData().employees,
					aSPDs = this.getView().getModel("projectDetails").getData().spds;

				this.getView().getModel("projectDetails").setData(data);
				this.getView().getModel("projectDetails").getData().employees = aEmployees;
				this.getView().getModel("projectDetails").getData().spds = aSPDs;
				if (data.toProjectPhase) this._fnPhasesTableRespectsAllRules(data.toProjectPhase.results);
				this._oData.busyProjectDetailsHeader = false;
				this._oModel.refresh();
				this._trackProjectDetails(data.ReasonCode);
				this._bRefreshingProjectDetails = false;
				resolve();
			});
		},

		_fnPhasesTableRespectsAllRules: function (aProjectPhases) {
			let dPointer = new Date(0); //1970
			let bAtLeastOneDayBetweenDates = true;
			let bGapsBetweenPhases = false;

			//check that at least one day lays between all each other following dates
			//(Howerver, dates can look like there lays a day betweem them, but technically this is not the case. I.e.:
			//   StartDate = 7.1.2022-19:00:00 ------- EndDate = 8.1.2022-05:00:00
			//This would be noticed as problem, but it should ignored, as long as it looks correct for the user. So as long as the day is one bigger
			//So we do not check if (StartDate + 1 Day > EndDate), but if (StartDate-00:00:00 + 1 Day > EndDate-00:00:00 )
			//)
			aProjectPhases.forEach(oPhase => {
				if (oPhase.PhaseStartDate) {
					if (new Date(new Date(oPhase.PhaseStartDate).setHours(0, 0, 0)) < new Date(new Date(dPointer).setHours(0, 0, 0)))
						bAtLeastOneDayBetweenDates = false;
					dPointer = this._fnAddOneDay(oPhase.PhaseStartDate);
				}
				if (oPhase.PhaseEndDate) {
					if (new Date(new Date(oPhase.PhaseEndDate).setHours(0, 0, 0)) < new Date(new Date(dPointer).setHours(0, 0, 0)))
						bAtLeastOneDayBetweenDates = false;
					dPointer = this._fnAddOneDay(oPhase.PhaseEndDate);
				}
			});
			//now we know already if optically there is at least one day between two subsequent dates!
			//next check the gaps between enddates of previous phases and startdates of next phases should not be more than optically one day
			bGapsBetweenPhases = this._fnHelperCheckGapsBetweenEndDatesOfPreviousPhasesAndStartDatesOfNextPhases(aProjectPhases);

			this.getView().getModel("projectDetails").getData().bShowPhaseTableWarning = !!((!bAtLeastOneDayBetweenDates || bGapsBetweenPhases));
			this.getView().getModel("projectDetails").refresh();
		},

		_fnHelperCheckGapsBetweenEndDatesOfPreviousPhasesAndStartDatesOfNextPhases(aProjectPhases) {
			aProjectPhases.forEach((oPhase, index) => {
				if (index !== aProjectPhases.length - 1) {
					if (oPhase.PhaseEndDate && aProjectPhases[index + 1].PhaseStartDate &&
						this._fnAddOneDay(new Date(oPhase.PhaseEndDate).setHours(0, 0, 0)) < new Date(new Date(aProjectPhases[
							index + 1].PhaseStartDate).setHours(0, 0, 0))) {
						return true;
					}
				}
			});
			return false;
		},

		/**
		 *  Track an event if a user displays a case details with reason not equal
		 * ("Global Engagement case" or "Engagement Case")
		 *  @param {string} sReasonCode - The reason code of the case
		 */
		_trackProjectDetails: function (sReasonCode) {
			if (sReasonCode !== "ENG1" && sReasonCode !== "ENG2" && !this.getView().getModel("localModel").getData().btnCancelPressed && !this._bRefreshingProjectDetails) {
				this.getOwnerComponent().trackEvent("Display_Project");
			}
			this.getView().getModel("localModel").getData().btnCancelPressed = false;
		},

		/*_____________________________________________________________________________________________________________________________________*/
		/*_____________________________________________________________________________________________________________________________________*/
		/*__________________________________________________ Project Overview Screen __________________________________________________________*/
		/*_____________________________________________________________________________________________________________________________________*/

		onNavToEngagementDetails: function (oEvent) {
			this.getRouter().navTo("EngagementDetails", {
				engagementID: this.getView().getModel("projectDetails").getData().ParentCaseID
			});
			this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "EmptyServicePlanSection", null); //otherwise user sees temporarily the old, data, in case comes back to another project
			this.activateBusyIndicators(this);
			this.getView().byId("ObjectPageLayoutProject").setSelectedSection("projectPlanningsSection");
			this.getView().byId("ObjectPageLayoutProject").rerender();
		},

		fnHandleShowProjectInformation: function (oEvent) {
			let oPopOverSource = oEvent.getSource();
			this._pPopoverInfoProject ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.fragment.PopoverInfoProjectDetails");
			this._pPopoverInfoProject.then(oPopover => {
				oPopover.setModel(this.getView().getModel("projectDetails"), "projectDetailsModel");
				oPopover.setModel(this.getOwnerComponent().getModel("i18n"), "i18n");
				oPopover.openBy(oPopOverSource);
			});
		},

		fnHandleEditProject: function (oEvent) {
			const sStatusText = this.getView().getModel("projectDetails").getData().StatusDescr;
			const sTitle = this.getResourceBundle().getText("ProjectDetails.EditProject");

			const sStatusClosed = this.getResourceBundle().getText("ProjectDetails.Status.Closed");
			const sStatusInManagementRev = this.getResourceBundle().getText("ProjectDetails.Status.InManagementReview");
			const sStatusInReview = this.getResourceBundle().getText("ProjectDetails.Status.InReview");

			if (sStatusText === sStatusClosed || sStatusText === sStatusInManagementRev || sStatusText === sStatusInReview) {
				this.messageHandler.addNewMessageseInsidePopover("NonEditable", "Warning", sTitle, this.getResourceBundle().getText(
					"ProjectDetails.MsgBox.EditInCRM", [sStatusText]), this.getResourceBundle().getText("ProjectDetails.MsgBox.EditInCRM", [sStatusText]), this);
			} else if (Object.values(Constants.getProjectInitiative()).includes(this.getView().getModel("projectDetails").getData().ProjectMethodology) ||
							this.getView().getModel("projectDetails").getData().ProjectMethodology === "")
						this.oEditProjectDialog.fnEditProjectDialogOpen(this, this.getResourceBundle(), this.getView().getModel("projectDetails").getData());
				else this.messageHandler.addNewMessageseInsidePopover("NonEditable", "Warning", sTitle, this.getResourceBundle().getText(
					"ProjectDetails.MsgBox.WrongMethodology"), this.getResourceBundle().getText("ProjectDetails.MsgBox.WrongMethodology"),this);
		},



		handleSectionChange: function (oEvent) {
			this._resetPaginationProperties();
			if (oEvent.getSource().getSelectedSection().indexOf("servicePlan") > -1) {
				let oEventBus = this.getOwnerComponent().getEventBus(),
					oCaseDetails = this.getView().getModel("projectDetails").getData();
				oEventBus.publish("ChannelServicePlanSection", "ProjectIsLoaded", oCaseDetails);
			}
			if (oEvent.getSource().getSelectedSection().indexOf("activities") > -1) {
				this._readActivities();
			}
			if (oEvent.getSource().getSelectedSection().indexOf("topIssues") > -1) {
				this._readProjectTopIssues();
			}
			if (oEvent.getSource().getSelectedSection().indexOf("partnerSection") > -1) {
				this.partiesInvolved.readPartnerSet();
			}
		},

		_resetPaginationProperties: function () {
			this._oData.paginationClicks = 0;
			this._oData.paginationSkip = 0;
			this._oData.paginationIntervalStart = 0;

			this._oData.paginationNextBtnEnabled = false;
			this._oData.paginationPrevBtnEnabled = false;
			this._oModel.refresh();
		},

		handleMessagePopoverPress: function (oEvent) {
			this.oMessagePopover.toggle(oEvent.getSource());
		},

		/*_____________________________________________________________________________________________________________________________________*/
		/*_____________________________________________________________________________________________________________________________________*/
		/*________________________________________________________ Service Plan Section  ______________________________________________________*/
		/*_____________________________________________________________________________________________________________________________________*/

		/**
		 * user has pressed button to add a new service to the service Plan.
		 * the Dialog to add a service product is openend.
		 * For this module "com/sap/ui/hep/util/serviceProductSelection/ServiceProductSelection" needs to be used.
		 * In that module method "fnOnServProductSelectionDialogOpen" is called and the required parameters handed over.
		 */
		fnOnServProdSelectionDialogOpen: function () {
			let sProjectId = this.getView().getModel("projectDetails").getData().ProjectID;
			let sServicePathSPD = Constants.getServicePathSPD();
			let oResourceBundle = this.getResourceBundle();
			let oView = this.getView();

			ServiceProductSelection.fnOnServProdSelectionDialogOpen(oView, oResourceBundle, sServicePathSPD, sProjectId);
		},

		onPhaseViewSwitchToDisplayMode: function () {
			this.DraftController.onPhaseViewSwitchToDisplayMode();
		},

		onPhaseViewSave: function () {
			this.DraftController.onPhaseViewSave();
		},

		onRemoveSelectedItems: function () {
			this.DraftController.onRemoveSelectedItems();
		},

		onChildProjectPressed: function (oEvent) {
			let sCaseDetails = this._extractDetailsFromBinding(oEvent);
			if (sCaseDetails) {
				this._oData.busyProjectDetailsPage = true;
				this._oModel.refresh();
				this._navToAnotherProjectDetails(sCaseDetails.ProjectID);
			}
		},

		_extractDetailsFromBinding: function (oEvent) {
			let sSelectionDetails = null;
			if (oEvent.getParameters().rowContext !== null) {
				let sCurrentSelectionPath = oEvent.getParameters().rowContext.sPath;
				let oModel = oEvent.getParameters().rowContext.getModel();
				sSelectionDetails = oModel.getProperty(sCurrentSelectionPath);
			}
			return sSelectionDetails;
		},

		_navToAnotherProjectDetails: function (sCaseID) {
			this.getRouter().navTo("ProjectDetails", {
				projectID: sCaseID
			});
		},

		/*_____________________________________________________________________________________________________________________________________*/
		/*_____________________________________________________________________________________________________________________________________*/
		/*________________________________________________________ Activities Section _________________________________________________________*/
		/*_____________________________________________________________________________________________________________________________________*/

		_readActivities: function () {
			this._oData.busyActivitiesProject = true;
			this._oModel.refresh();
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ProjectItemSet";
			entities.paginationTop = Constants.getPaginationTop();
			entities.paginationSkip = this._oData.paginationSkip;
			entities.inlineCount = "allpages";
			entities.busyIndicator = "busyActivitiesProject";
			entities.filter = "(ProjectID eq '" + this._idProject + "' and (TransactionType eq 'ZS43' or TransactionType eq 'ZS46'))";
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.callbackSuccess = (oData) => {
				this._handleSuccessReadActivities(oData);
			};
			this.readBaseRequest(entities);
		},

		_readActivitiesAssignedToProject: function (oSort) {
			this._oData.busyActivitiesList = true;
			this._oModel.refresh();
			let entities = {},
				oSortProperties = oSort || this._determineSortingProjectActivitiesSection();
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ProjectItemSet";
			entities.inlineCount = "allpages";
			if (oSortProperties) {
				entities.sortItem = oSortProperties.field;
				entities.sortOrder = Constants.getSortOrder()[oSortProperties.order];
			}
			entities.paginationTop = Constants.getPaginationTop();
			entities.paginationSkip = this._oData.paginationSkip;
			entities.filter = ` ProjectID eq '${this._idProject}' and (TransactionType eq 'ZS43' or TransactionType eq 'ZS46')`;
			entities.errorMessage = this.getResourceBundle().getText("ProjectEntityPerUser.ErrorMessage");
			entities.oContext = this;
			entities.currentView = this.getView();
			entities.busyIndicator = "busyActivitiesList";
			entities.callbackSuccess = (oData) => {
				this._handleSuccessReadActivities(oData);
			};
			this.readBaseRequest(entities);
		},


		_handleSuccessReadActivities: function (oData) {
			this._oData.busyActivitiesProject = false;
			oData.results = oData.results.map(item => {
				if (item.TransactionType === "ZS46") item.linkDisplay = item.TbuiUrl;
				return item;
			});
			this.getModel("activitiesProject").setProperty("/iNumberOfActivities", oData.__count);
			this.getModel("activitiesProject").setProperty("/results", oData.results);
			this._handlePaginationElementsActivity();
			this.getModel("activitiesProject").refresh();
		},

		_handlePaginationElementsActivity: function () {
			let iNumberOfActivities = this.getView().getModel("activitiesProject").getProperty("/iNumberOfActivities");
			this.pagination._paginationElements(this, iNumberOfActivities,
				this.getView().byId("btnPaginationNextActivities"), this.getView().byId("btnPaginationPrevActivities"));
		},

		navToPreviousRecordsActivities: function () {
			let pagination = this.pagination.goToPreviousPage(this, this._oData.paginationClicks);
			this._oData.paginationClicks = pagination.clicks;
			this._oData.paginationSkip = pagination.skip;
			this._readActivities();
		},

		navToNextRecordsActivities: function () {
			let pagination = this.pagination.goToNextPage(this, this._oData.paginationClicks);
			this._oData.paginationClicks = pagination.clicks;
			this._oData.paginationSkip = pagination.skip;
			this._readActivities();
		},

		handleDisplayPEActivity: function (oEvent, calledFromProjectActivity) {
			let oBindingContext;
			let sPath;
			let oModel;
			let sPeActivityGuid;
			let sPeActivityTxType;
			if (calledFromProjectActivity) {
				oBindingContext = oEvent.getSource().getBindingContext("activitiesProject");
				sPath = oBindingContext.getPath();
				oModel = oBindingContext.getModel();
				sPeActivityGuid = oModel.getProperty(sPath).ObjectGuid;
				sPeActivityTxType = oModel.getProperty(sPath).TransactionType;
			} else {
				oBindingContext = oEvent.getSource().getParent().getParent().getBindingContext("ganttModel");
				sPath = oBindingContext.getPath();
				oModel = oBindingContext.getModel();
				sPeActivityTxType = oModel.getProperty(sPath).TransactionType;
			}

			if (sPeActivityTxType === "ZS43") {
				this.getOwnerComponent().trackEvent("Trigger_DisplayActivity_InPEA");
				NavigationToExternalApps.fnNavigateToPeActivityApp(this, sPeActivityGuid, "ActivityDisplay");
			}

			if (sPeActivityTxType === "ZS46") {
				NavigationToExternalApps.fnHandleLinkNavigation(oModel.getProperty(sPath).linkDisplay);
			}
		},

		handleEditPEActivity: function (oEvent, calledFromProjectActivity) {
			let oBindingCntxt;
			let sPath;
			let oModel;
			let sPeActGuid;
			let sPeActTxType;
			if (calledFromProjectActivity) {
				oBindingCntxt = oEvent.getSource().getBindingContext("activitiesProject");
				sPath = oBindingCntxt.getPath();
				oModel = oBindingCntxt.getModel();
				sPeActGuid = oModel.getProperty(sPath).ObjectGuid;

			} else {
				oBindingCntxt = oEvent.getSource().getParent().getParent().getBindingContext("ganttModel");
				sPath = oBindingCntxt.getPath();
				oModel = oBindingCntxt.getModel();
			}
			sPeActTxType = oModel.getProperty(sPath).TransactionType;

			if (sPeActTxType === "ZS43") {
				this.getOwnerComponent().trackEvent("Trigger_DisplayActivity_InPEA");
				NavigationToExternalApps.fnNavigateToPeActivityApp(this, sPeActGuid, "ActivityEdit");
			}

			if (sPeActTxType === "ZS46") {
				let sURL = oModel.getProperty(sPath).linkDisplay.replace("action=B", "action=C");
				NavigationToExternalApps.fnHandleLinkNavigation(sURL);
			}

		},

		onActivitiesResetSort: function () {
			let oTable = this.getView().byId("ProActivitiesTable");
			oTable.resetSorting();
			this._readActivities();
		},

		_initializeActivitiesTablePerso: function () {
			this.getView().byId("ProActivitiesTable").removeSelections();
			if (this._oTPCActivities === undefined) {
				this._oTPCActivities = new TablePersoController({
					table: this.getView().byId("ProActivitiesTable"),
					componentName: "tablePerso",
					persoService: TablePersoProActivities
				}).activate();

			}
		},

		onActivitiesPersoButtonPressed: function (oEvent) {
			this._oTPCActivities.openDialog();
		},

		onActivitiesTablePersoRefresh: function () {
			TablePersoProActivities.resetPersData();
			this._oTPCActivities.refresh();
		},

		_determineSortingProjectActivitiesSection: function () {
			let oTable = this.getView().byId("ProActivitiesTable");

			let aColumns = oTable.getColumns(),
				oSortProperties = {};
			let oSortingColumn = aColumns.find(oColumn => oColumn.getSortIndicator() !== "None");
			if (oSortingColumn) {
				oSortProperties.field = oSortingColumn.getSortField();
				oSortProperties.order = oSortingColumn.getSortIndicator();
			} else {
				oSortProperties = null;
			}

			return oSortProperties;
		},



		fnShowCreatedByDetails: function (oEvent) {
			let oSource = oEvent.getSource(),
				sSelectedIndex = oSource.getBindingContext("activitiesProject").getPath().split("results/")[1],
				sCreatedBy = this.getView().getModel("activitiesProject").getData().results[sSelectedIndex].CreatedBy;
			this.employeeDetails.displayEmployeePopover(oEvent, this.getView(), "activitiesProject", "CreatedBy", sCreatedBy);
		},

		fnShowResponsibleDetails: function (oEvent) {
			let oSource = oEvent.getSource(),
				sSelectedIndex = oSource.getBindingContext("activitiesProject").getPath().split("results/")[1],
				sResponsibleID = this.getView().getModel("activitiesProject").getData().results[sSelectedIndex].ResponsibleID;
			this.employeeDetails.displayEmployeePopover(oEvent, this.getView(), "activitiesProject", "ResponsibleUsr", sResponsibleID);
		},

		/*_____________________________________________________________________________________________________________________________________*/
		/*_____________________________________________________________________________________________________________________________________*/
		/*________________________________________________________ Top Issues Section _________________________________________________________*/
		/*_____________________________________________________________________________________________________________________________________*/

		_readProjectTopIssues: function () {
			this._oData.busyTopIssuesProject = true;
			this._oModel.refresh();
			this._readTopIssues("topIssuesProject", () => {
				this._oData.busyTopIssuesProject = false;
				this._oModel.refresh();
			});
		},

		navToPreviousRecordsTopissues: function () {
			let pagination = this.pagination.goToPreviousPage(this, this._oData.paginationClicks);
			this._oData.paginationClicks = pagination.clicks;
			this._oData.paginationSkip = pagination.skip;
			this._readProjectTopIssues();
		},

		navToNextRecordsTopIssues: function () {
			let pagination = this.pagination.goToNextPage(this, this._oData.paginationClicks);
			this._oData.paginationClicks = pagination.clicks;
			this._oData.paginationSkip = pagination.skip;
			this._readProjectTopIssues();
		},

		/*_____________________________________________________________________________________________________________________________________*/
		/*_____________________________________________________________________________________________________________________________________*/
		/*______________________________________________ Solution Scope Section (Reference Objects ) __________________________________________*/
		/*_____________________________________________________________________________________________________________________________________*/

		onPressSaveRefObj: function (oEvent) {
			this._oData.formEditMode = false;
			this._oModel.refresh();

			let oPromiseRO = new Promise((resolveRO, rejectRO) => {
				return this.referenceObjects._manipulateReferenceObjects(resolveRO, rejectRO, this);
			});
			oPromiseRO.then(() => {
				MessageToast.show(this.getResourceBundle().getText("RO.Update.Success"));
			}, (error) => {
				let titleErrorRF = this.getResourceBundle().getText("ProjectDetails.ReferenceObject");
				this.messageHandler.addNewMessageseInsidePopover("Reference Object", "Error", titleErrorRF, error.message, error.message,
					this);
			});

		},

		fnHandleAddNewRefObj: function (oEvent) {
			this.referenceObjects.loadReferenceObjectsDialog(oEvent, this);
		},

		fnHandleDiscardRefObj: function (oEvent) {
			this.referenceObjects.discardReferenceObjectsDialog(oEvent, this);
		},

		refObjListSelectionChange: function (oEvent) {
			this.referenceObjects.fnHandleSelectionChange(oEvent, this);
		},

		// Renamed to allign the search of customer search with new popup - KNGMHM02-23694
		customerIdValueHelpTriggerOld: function (oEvent) {
			this.referenceObjects.customerIdValueHelpTrigger(oEvent, this);
		},
		// New Version of popup - KNGMHM02-23694
		customerIdValueHelpTrigger: function (oEvent) {
			this.getView().getModel("localModel").getData().bpSearchReturnType = "ProjectDetailCustomerIdValueHelp";
			this.getView().getModel("localModel").refresh();
			this.partiesInvolved.loadSearchHelpDialog("00000001", "PFCustomer");
		},

		onRONavBack: function (oEvent) {
			this.referenceObjects.onRONavBack(this);
		},

		onSearchForReferenceObjects: function (oEvent) {
			this.referenceObjects.searchROonGOBtn(oEvent, this);
		},

		fnHandleSearchForItems: function (oSort) {
			let sSelectedSection = this.getView().byId("ObjectPageLayoutProject").getSelectedSection();
			if (sSelectedSection.indexOf("activities") > -1) {
				this._readActivitiesAssignedToProject(oSort);
			}

		},

		onCustomerIDOrInstNoChange: function (oEvent) {
			this.referenceObjects.onCustomerIDOrInstNoChange(oEvent, this);
		},

		resetSorting: function (oEvent) {
			this.referenceObjects.resetSorting(oEvent, this);
		},

		handleAddRefObjPersoButtonPressed: function (oEvent, oContext) {
			this.referenceObjects.onAddRefObjPersoButtonPressed(oEvent, this);
		},

		handleAddRefObjSortReset: function () {
			this.referenceObjects.onAddRefObjSortReset(this);
		},

		fnHandleDeleteRefObj: function (oEvent) {
			this.referenceObjects.deleteRefObjConfirmation(oEvent, this);
		},

		searchCustomerSpecific: function (oEvent) {
			this.referenceObjects.searchCustomerSpecific(oEvent, this);
		},

		// Renamed to allign the search of customer search with new popup - KNGMHM02-23694
		handleCustomerItemPressedOld: function (oEvent) {
			this.referenceObjects.handleCustomerItemPressed(oEvent, this);
		},
		// New Version of popup - KNGMHM02-23694
		onVHPartnerSelect: function (oEvent) {
			this.onVHPartnerSelectGetValues(oEvent);
			let sPartnerID = this.getView().getModel("localModel").getData().bpSearchReturnPartnerID ? this.getView().getModel("localModel").getData()
				.bpSearchReturnPartnerID : "";
			let sFullName = this.getView().getModel("localModel").getData().bpSearchReturnFullName ? this.getView().getModel("localModel").getData()
				.bpSearchReturnFullName : "";
			let sBPSearchReturnType = this.getView().getModel("localModel").getData().bpSearchReturnType ? this.getView().getModel(
				"localModel")
				.getData().bpSearchReturnType : "PartiesInvolved";
			if (sBPSearchReturnType === "PartiesInvolved") {
				this.partiesInvolved.setNewPartner(sPartnerID, sFullName);
			} else {
				this.referenceObjects.handleCustomerItemPressedGenCustomerPopup(sPartnerID, this);
			}
			this.partiesInvolved.closeSearchHelpDialog();
		},

		fnHandleAddRefObj: function (oEvent) {
			this.referenceObjects.fnHandleAddRefObj(oEvent, this);
		},

		dataCenterValueHelpTrigger: function (oEvent) {
			this.referenceObjects.dataCenterValueHelpTrigger(oEvent, this);
		},

		searchDataCenters: function (oEvent) {
			this.referenceObjects.searchDataCenters(oEvent, this);
		},

		handleDataCenterItemPressed: function (oEvent) {
			this.referenceObjects.handleDataCenterItemPressed(oEvent, this);
		},


		/* ================================= Restricted Project ==================================== */
		/**
		 * Will handle a restricted project.
		 * Will show the dialog to maintain the access reason.
		 *
		 */
		_handleRestrictedProject: function () {
			this._pRestrictedDialog ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.fragment.RestrictedProject");
			this._pRestrictedDialog.then(oDialog => {
				this._readRestrictedAccessReasons(this, this.getView()).then(function (oData) {
					this.setModel(new JSONModel({
						reasons: oData.results
					}), "restrictedProject");
				}.bind(this));
				oDialog.open();
			})
		},

		/**
		 * Will cancel the restricted access reason dialog and navigate to the home screen.
		 *
		 */
		onPressCancelRestrictedProject: function () {
			this._pRestrictedDialog.then(oDialog=> oDialog.close());
			this.navToHome();
		},

		/**
		 * Will send the selected access reason to the backend (function import) and the call returns the project data.
		 * AccessText is optional only if the access reason is not 'Other'.
		 * Will close the dialog and update the project details if access is granted.
		 *
		 * @param {object} oEvent - Event object of the selected button
		 */
		onPressConfirmRestrictedProject: function (oEvent) {
			let oAccessReasonSelect = this.getView().byId("selectProjectAccessReasons");
			let sText = this.getModel("restrictedProject").getProperty("/otherReason");
			if (sText === undefined || sText === null) {
				sText = "";
			}
			let sAccessReason = oAccessReasonSelect.getSelectedItem().getKey();
			let sProjectId = this.getView().getModel("projectDetails").getData().ProjectID;

			this._readRestrictedProject(sText, sAccessReason, sProjectId).then(data => {
				this._pRestrictedDialog.then(oDialog => oDialog.close());
				this._handleSuccessProjectData(data);
			});
		},

		/**
		 * Calls the function import to log the access of the restricted project.
		 *
		 * @param {string} sText - Free text input for reason "Other"
		 * @param {string} sAccessReason - Selected access reason code
		 * @param {string} sProjectId - Project Id
		 *
		 * @return {Promise} Promise that will resolve with the project data
		 */
		_readRestrictedProject: function (sText, sAccessReason, sProjectId) {
			return new Promise((resolve, reject) => {
				let oParams = {};
				oParams.servicePath = Constants.getServicePath();
				oParams.function = "GetRestrictedProject";
				oParams.method = "GET";
				oParams.currentView = this.getView();
				oParams.oContext = this;
				oParams.urlParameters = {
					"Text": sText,
					"AccessReason": sAccessReason,
					"ProjectID": sProjectId
				};
				oParams.callbackSuccess = (oData) => {
					resolve(oData);
				};
				this.callFunction(oParams);
			});
		},

		//====================================================================================================================
		//====================================================================================================================
		//=================================== PreLoading of Performance Critical Data ================================
		//====================================================================================================================
		//====================================================================================================================

		_preReadSPDPerformanceCriticalData: function () {
			this.getView().getModel("filterModel").getData().phases = Constants.getProjectPhasesCustomizing().results;
			this.getView().getModel("filterModel").refresh();

			//read all contracts for the customer of the project from CRM
			this.getOwnerComponent().oHelperData.pReadContractCheckSet = new Promise((resolve, reject) => {
				let entities = {};
				entities.servicePath = Constants.getServicePathSPD();
				entities.entitySet = "ContractItemF4Set";
				entities.filter = "( CustomerID eq '" + this.getView().getModel("projectDetails").getData().CustomerID +
					"' and ReleasedFlag eq 'X' )";
				entities.paginationTop = "99999"
				entities.currentView = this.getView();
				entities.oContext = this;
				entities.callbackSuccess = (oData) => {
					resolve(oData);
				};
				this.readBaseRequest(entities);
			});

		},

		_readProjectItems: function (oUpdatedSO) {
			this.getView().getModel("localModel").getData().busyProjectPlanning = true;
			this.getView().getModel("localModel").refresh();
			this.oUpdatedSO = oUpdatedSO;
		},

		/* ======================================== Project Header ============================================== */

		/* ======================================== Parties involved ============================================== */
		fnHandlePartnerSetMain: function (oEvent) {
			this.partiesInvolved.setMain(oEvent);
		},

		onSearchPartner: function (oEvent) {

		},

		/* ==================================== Service Request =================================================== */

		handleDisplayTopIssueProject: function (oEvent) {
			this.navToDisplayTopIssueInCrm(oEvent, "topIssuesProject");
		},

		handleEditTopIssue: function (oEvent) {
			this.navToEditTopIssueInCrm(oEvent, "topIssuesProject");
		}

	});
});
