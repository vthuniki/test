sap.ui.define(["sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"com/sap/ui/hep/reuse/Constants",
	"com/sap/ui/hep/controller/BaseController",
	"com/sap/ui/hep/util/TablePersoListView",
	"sap/ui/table/TablePersoController",
	"sap/m/MessageToast",
	"sap/ui/model/odata/v2/ODataModel",
	"com/sap/ui/hep/util/MessageHandlingPopover",
	"com/sap/ui/hep/util/serviceProductSelection/ServiceProductSelection",
	"com/sap/ui/hep/model/formatter",
	"com/sap/ui/hep/util/EmployeeDetails",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library",
	"sap/ui/Device",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"com/sap/ui/hep/util/TablePersoDraftPlan",
	"sap/m/TablePersoController",
	"com/sap/ui/hep/util/Variant",
	"com/sap/ui/hep/util/NavigationToExternalApps",
	"sap/m/Dialog",
	"sap/m/ProgressIndicator",
	"com/sap/ui/hep/util/FilterHelper"
], function (MessageBox, JSONModel, Constants, BaseController,
	TablePersoListView, TablePersoController, MessageToast, ODataModel, MessageHandlingPopover, ServiceProductSelection,
	Formatter, EmployeeDetails, Spreadsheet, ExportLibrary, Device, Filter, FilterOperator,
	TablePersoDraftPlan, TablePersoControllerM, Variant, NavigationToExternalApps, Dialog, ProgressIndicator, FilterHelper
) {
	"use strict";
	return BaseController.extend("com.sap.ui.hep.controller.Details.Project.SectionServicePlans.DraftPlan", {

		messageHandler: MessageHandlingPopover,
		formatter: Formatter,
		employeeDetails: EmployeeDetails,
		variant: Variant,

		onAfterRendering: function () {
			document.addEventListener("fullscreenchange", function (e) {
				if (document.fullscreenElement) {
					// enter full screen detected
					this.getView().getModel("localModel").setProperty("/fullscreen", true);
					this.getView().getModel("localModel").refresh();
					sap.ui.getCore().byId($("[id$=ObjectPageLayoutProject].sapUxAPObjectPageLayout").attr("id")).getAggregation("headerTitle").setVisible(
						false);
					sap.ui.getCore().byId($("[id$=ObjectPageLayoutProject].sapUxAPObjectPageLayout").attr("id")).getAggregation("_headerContent").setVisible(
						false);

				} else {
					// exit full screen detected
					this.getView().getModel("localModel").setProperty("/fullscreen", false);
					this.getView().getModel("localModel").refresh();
					sap.ui.getCore().byId($("[id$=ObjectPageLayoutProject].sapUxAPObjectPageLayout").attr("id")).getAggregation("headerTitle").setVisible(
						true);
					sap.ui.getCore().byId($("[id$=ObjectPageLayoutProject].sapUxAPObjectPageLayout").attr("id")).getAggregation("_headerContent").setVisible(
						true);
				}

			}.bind(this));
		},

		onInit: function () {
			this.getOwnerComponent().pCrmUserDataLoaded.then(() => {
				this._oLoggedInUserCrmData = this.getOwnerComponent().getModel("appData").getData().oCrmUserData;
				let oBus = this.getOwnerComponent().getEventBus();
				oBus.subscribe("ChannelServicePlanSection", "ProjectIsLoaded", this._fnOnProjectIsLoaded, this);
				oBus.subscribe("ChannelSortOrderDraftPlans", "SortOrderReceive", this._setDraftPlanSort, this);
				oBus.subscribe("ChannelServicePlanSection", "ExecutionPlanFocused", this._fnOnExecutionPlanFocused, this);
				oBus.subscribe("ChannelServicePlanSection", "DraftPlanFocused", this._handleInitialization, this);
				oBus.subscribe("ChannelServicePlanSection", "SelectorClosed", this._fnOnServicePlanSelectorClosed, this);
				sap.ui.getCore().getEventBus().subscribe("channelSortDraft", "sortEvent2", this.handleSort, this);
				oBus.subscribe("ChannelServicePlanSection", "NumberOfDraftPlans", this._fnSetNumberOfDraftPlans, this);
				oBus.subscribe("ChannelServicePlanSection", "EmptyServicePlanSection", this._fnEmptyServicePlanSection, this);
				this._mViewSettingsDialogs = {};

				//own version of JSONModel needed, in order to publish refresh to ProjectDetails.controller, where the footer-toolbar with the buttons is located
				this.JSONModelWithRefreshPublish = sap.ui.model.json.JSONModel.extend("JSONModelWithRefreshPublish", {
					refresh: function () {
						sap.ui.model.json.JSONModel.prototype.refresh.apply(this, arguments);
						oBus.publish("ChannelServicePlanSection", "LocalModelDraftPlanRefreshed", this.getData());
					}
				});
			});
		},

		_fnEmptyServicePlanSection: function (sChannel, sEvent) {
			this.getView().getModel("spdDetails").getData().results = [];
			this.getView().getModel("spdDetails").getData().CaseDetails = {};
			this.getView().getModel("spdDetails").getData().Header = {};
			this.getView().getModel("spdDetails").getData().iNumberOfDaysPhaseView = 0;
			this.getView().getModel("spdDetails").getData().iNumberOfDraftPlans = 0;
			this.getView().getModel("spdDetails").getData().iNumberOfItemsPhaseView = 0;
			this.getView().getModel("spdDetails").getData().initialPhases = [];
			this.getView().getModel("spdDetails").getData().notFilteredPhases = [];
			this.getView().getModel("spdDetails").getData().phases = [];
			this.getView().getModel("spdDetails").refresh();
		},

		_fnOnProjectIsLoaded: function (sChannel, sEvent, oProject) {
			this._projectId = oProject.ProjectID;
			this.hasBeenCalled = true;
		},

		_fnOnExecutionPlanFocused: function (sChannel, sEvent, oPublisherViewLocalModelData) {
			this.getView().getModel("localModel").getData().sSelectedViewType = oPublisherViewLocalModelData?.sSelectedViewType ?? "listView"; //defaulting
			this.getView().getModel("localModel").refresh();
			this._handleInitialization(sChannel, sEvent, oPublisherViewLocalModelData);
		},

		_setDraftPlanSort: function (sChannel, sEvent, oPublisherViewLocalModelData) {
			this.sortDraftPlans = oPublisherViewLocalModelData;
		},

		_fnSetNumberOfDraftPlans: function (sChannel, sEvent, oDataDraftPlansHeaders) {
			if (this.getView().getModel("spdDetails") && this.getView().getModel("spdDetails").getData()) {
				let dataLength; // can be number and string
				switch (oDataDraftPlansHeaders.results.length) {
					case 0:
						// dataLength  "Add Service Plan";
						dataLength = this.getResourceBundle().getText("DetailsView.ServicePlan.NoServicePlan");
						 break;
					case 1:
						// dataLength  "Service Plans (1 Draft)";
						dataLength = this.getResourceBundle().getText("DetailsView.ServicePlan.OneServicePlan")
						break;
					default:
						// dataLength  Service Plans (${oDataDraftPlansHeadersResultsLength} Drafts);
						dataLength = this.getResourceBundle().getText("DetailsView.ServicePlan.MultiplePlans", [oDataDraftPlansHeaders.results.length]);
				}
				this.getView().getModel("spdDetails").getData().sServicePlanButtonText = dataLength;
				this.getView().getModel("spdDetails").getData().sServicePlanButtonIcon = oDataDraftPlansHeaders.results.length > 0 ?
					"sap-icon://megamenu" : "sap-icon://create-form";
				this.getView().getModel("spdDetails").getData().iNumberOfDraftPlans = oDataDraftPlansHeaders.results.length;
				this.getView().getModel("spdDetails").refresh();
			}
		},

		_handleInitialization: function (sChannel, sEvent, oSectionServicePlansLocalModelData) { //triggered by an event on the eventBus
			if (sEvent === "ExecutionPlanFocused" || sEvent === "ProjectIsLoaded") {
				this.FocusedOn = "ExecutionPlanFocused";
				this.getView().getModel("localModel").refresh();
			} else {
				this.FocusedOn = "DraftPlanFocused";
				this.getView().getModel("localModel").refresh();
				this._SPDID = oSectionServicePlansLocalModelData.oSelectedDraftPlan.SpGuid; // "0894ef08-0190-1eeb-92bd-74a5319d7362";
			}

			this._sImportPackageFromSSCId = this.getOwnerComponent().getModel("appData").getData().oMyStorage.get("importPackageFromSSCId");

			let remindShow = this.getView().getModel("localModel").getData().bBtnShowSelectorEnabled;

			this._initializeServicesTablePerso();
			this._initializeModels();

			if (remindShow)
				this.getView().getModel("localModel").getData().bBtnShowSelectorEnabled = remindShow;
			else
				this.getView().getModel("localModel").getData().bBtnShowSelectorEnabled = this.hasBeenCalled;

			this.getView().getModel("localModel").getData().sSelectedViewType = oSectionServicePlansLocalModelData.sSelectedViewType;
			this.getView().getModel("localModel").refresh();

			this.hasBeenCalled = false;

			//use the message Handler from ProjectDetails.controller
			this.messageHandler = this._fnGetAncestorView(this.getView(),"ProjectDetails").getController().messageHandler

			this.getView().getModel("localModel").getData().busySPListView = true;
			this.getView().getModel("localModel").refresh();

			this.getView().getModel("filterModel").getData().phases = Constants.getProjectPhasesCustomizing().results;
			this.getView().getModel("filterModel").refresh();

			this._pReadSPDHeader().then(() => {

				//Promise create and executed once during startup of HEP (component.js)
				this._pAllPackagesLoadedFromSSC = this.getOwnerComponent().oHelperData.pReadAllPackagesFromSSC;
				this._pAllPackagesLoadedFromSSC.then((aAllPackages) => {
					this.getView().getModel("focusPackages").getData().allPackages = aAllPackages;
				});

				//Promise create and executed once during startup of HEP (component.js)
				this._pAllComponentsLoadedFromCRM = this.getOwnerComponent().oHelperData.pReadAllCrmServiceComponents;
				this._pAllComponentsLoadedFromCRM.then((oData) => {
					this.getView().getModel("componentsModel").getData().allCRMComponents = oData.results;
					this.getView().getModel("componentsModel").getData().numberOfAllCRMComponents = oData.results.length;
					this.getView().getModel("componentsModel").getData().searchComponentsFilter = {};
					this.getView().getModel("componentsModel").getData().searchComponentsResults = [];
					this.getView().getModel("componentsModel").getData().searchComponentsNumberOfResults = 0;
					this.getView().getModel("componentsModel").refresh();
					this.getView().getModel("localModel").getData().busyComponentsLoading = false;
					this.getView().getModel("localModel").refresh();
				});

				//loaded already in the background, when the Project-controller is setup
				this._pContractCheckSetLoaded = this.getOwnerComponent().oHelperData.pReadContractCheckSet;
				this._pContractCheckSetLoaded.then((oData) => {
					this.getView().getModel("contractCheckSet").getData().allCustomerContractItems = oData.results;
					this.getView().getModel("contractCheckSet").refresh();
				});

				this._resetFilters();
				this._initVariants();
				if (this.getView().getModel("localModel").getData().sSelectedViewType === "phaseView") {
					this._readSPDItems();
				}

				this._oData.filtersSetted = false;
				this._readComponentStatusListFromCRM();
				this._readHeaderStatusListFromCRM();
				this.getView().getModel("localModel").getData().busySPListView = false;
				this.getView().getModel("localModel").refresh();

				this.searchFilters = "";
				this.oStore = {};
				this.lastFilters = [];
				this._oData.filtersSetted = false;

				this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "DraftPlanControllerInit", this);

			});
		},
		_startInitialization: function (sChannel, sEvent, oProject) {
			this._projectId = oProject.ProjectID;
		},
		_readComponentStatusListFromCRM: function () {
			const view = this.getView();
			if (this._ComponentStatus) {
				view.getModel("spdDetails").getData().componentStatuses = this._ComponentStatus;
				view.getModel("spdDetails").refresh();
				this.getView().getModel("filterModel").getData().componentStatuses = this._ComponentStatus;
				this.getView().getModel("filterModel").refresh();
				return;
			}
			view.getModel("localModel").getData().busySPListView = true;
			view.getModel("localModel").refresh();

			const entities = {
				servicePath: Constants.getServicePath(),
				entitySet: Constants.getEntities().DropDownEntity,
				filter: "Type eq 'ComponentStatus'",
				currentView: view,
				oContext: this,
				errorMessage: this.getResourceBundle().getText("Error.DraftPlan.readComponentStatusListFromCRMFailed"),
				callbackSuccess: (oData) => {
					this._ComponentStatus = oData.results;
					view.getModel("spdDetails").getData().componentStatuses = this._ComponentStatus;
					view.getModel("spdDetails").refresh();
					this.getView().getModel("filterModel").getData().componentStatuses = this._ComponentStatus;
					this.getView().getModel("filterModel").refresh();
					view.getModel("localModel").getData().busySPListView = false;
					view.getModel("localModel").refresh();
				}
			};

			this.readBaseRequest(entities);
		},

		_readHeaderStatusListFromCRM: function () {
			const view = this.getView();
			if (this._headerStatus) {
				view.getModel("spdDetails").getData().headerStatus = this._headerStatus;
				view.getModel("spdDetails").refresh();
				this.getView().getModel("filterModel").getData().status2 = this._headerStatus;
				this.getView().getModel("filterModel").refresh();
				return;
			}
			view.getModel("localModel").getData().busySPListView = true;
			view.getModel("localModel").refresh();

			const entities = {
				servicePath: Constants.getServicePath(),
				entitySet: Constants.getEntities().DropDownEntity,
				filter: "Type eq 'Status'",
				currentView: view,
				oContext: this,
				errorMessage: this.getResourceBundle().getText("Error.DraftPlan.readHeaderStatusListFromCRM"),
				callbackSuccess: (oData) => {
					// Adjust some data from backend waiting final solution from Back end (DRAFT)
					oData.results.forEach(oItem => {
						if (oItem.Key === "ZSK00001|E0018") {
							oItem.Value = "Draft";
						}
					});

					this._headerStatus = oData.results;
					view.getModel("spdDetails").getData().headerStatus = this._headerStatus;
					view.getModel("spdDetails").refresh();
					this.getView().getModel("filterModel").getData().status2 = this._headerStatus;
					this.getView().getModel("filterModel").refresh();
					view.getModel("localModel").getData().busySPListView = false;
					view.getModel("localModel").refresh();
				}
			};

			this.readBaseRequest(entities);
		},

		_fnHandleCallFunctionsChange: function () {

			this._resetFilters();
			this._initVariants();
			this.onResetSortServices();
			this.onPhaseViewSwitchToDisplayMode();
			this.getView().getModel("localModel").getData().phaseViewRemoveMode = false;
			this.getView().getModel("spdDetails").getData().phaseViewRemoveMode = false;
			this._uncheckBoxesAfterDeleteModeClosed();
			this.getView().getModel("localModel").refresh();
			this.getView().getModel("spdDetails").refresh();
			this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "selectedViewTypeChanged", this.getView().getModel(
					"localModel")
				.getData());
		},

		fnOnSelectedViewTypeChange: function (oEvent) {
			if (this.getView().getModel("localModel").getData().phaseViewEditMode) {
				this.byId("spdSeg").setSelectedKey("phaseView");
				MessageBox.warning(this.getResourceBundle().getText("SPDDetails.PhaseView.SwitchToListView"), {
					actions: [MessageBox.Action.YES, MessageBox.Action.NO],
					emphasizedAction: MessageBox.Action.YES,
					onClose: (sAction) => {
						if (sAction === "YES") {
							this.onPhaseViewSave();
						}
						this.byId("spdSeg").setSelectedKey("listView");
						this._fnHandleCallFunctionsChange();
					}
				});
			} else {
				this._fnHandleCallFunctionsChange();
			}

		},

		_fnOnServicePlanSelectorClosed: function (sChannel, sEvent) {
			this.getView().getModel("localModel").getData().bBtnShowSelectorEnabled = true;
			this.getView().getModel("localModel").refresh();

		},

		fnHandleOpenServicePlanSelector: function () {
			this.getView().getModel("localModel").getData().bBtnShowSelectorEnabled = false;
			this.getView().getModel("localModel").refresh();
			let bCreateNew = !this.getView().getModel("spdDetails").getData().iNumberOfDraftPlans;
			this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "SelectorOpened", {
				bCreateNew: bCreateNew
			});

		},

		_initializeModels: function () {
			let oLocalModel = new this.JSONModelWithRefreshPublish({});
			this.getView().setModel(oLocalModel, "localModel");
			this.getView().getModel("localModel").getData().generalInformationViewEditMode = false;
			this.getView().getModel("localModel").getData().listViewEditMode = false;
			this.getView().getModel("localModel").getData().phaseViewEditMode = false;
			this.getView().getModel("localModel").getData().phaseViewRemoveMode = false;
			this.getView().getModel("localModel").getData().selectedItemsForRemoval = [];
			this.getView().getModel("localModel").getData().headerSPDEditMode = false;
			this.getView().getModel("localModel").getData().areThereProposalsDisplayed = false;
			this.getView().getModel("localModel").getData().selectedItemsForTransfer = [];
			this.getView().getModel("localModel").getData().expandedMode = true;
			this.getView().getModel("localModel").getData().inCollapsedMode = true;
			this.getView().getModel("localModel").getData().messageStripVisible = false;
			this.getView().getModel("localModel").setProperty("/fullscreen", false);
			this.getView().getModel("localModel").getData().sCurrentStartDate = {};
			this.getView().getModel("localModel").getData().sCurrentEndDate = {};
			this.getView().getModel("localModel").getData().saveRequestDeliveryEnabled = true;
			this.getView().getModel("localModel").getData().saveButtonEnabled = true;
			this.getView().getModel("localModel").getData().phaseSortAsc = false;
			this.getView().getModel("localModel").getData().importPackageFromSSCEnabled = Boolean(this._sImportPackageFromSSCId);
			this.getView().getModel("localModel").getData().removeServicesEnabled = false;
			this.getView().getModel("localModel").getData().busyVHAccBPerson = false;
			this.getView().getModel("localModel").getData().busySOGHelpTable = false;
			this.getView().getModel("localModel").getData().bExecutionPlanFocused = this.FocusedOn === "ExecutionPlanFocused";
			this.getView().getModel("localModel").getData().bDraftPlanFocused = this.FocusedOn === "DraftPlanFocused";
			this.getView().getModel("localModel").getData().bSaveIsBlocked = false;
			this.getView().getModel("localModel").getData().addListSubmitEnabled = false;
			this.getView().getModel("localModel").getData().addServiceListSaveEnabled = false;

			this._oView = this.getView();
			this._oModel = this._oView.getModel("localModel");
			this._oData = this._oModel.getData();

			this.getView().getModel("localModel").refresh();

			let oSPDModel = new JSONModel({});
			this.getView().setModel(oSPDModel, "spdDetails");
			this.getView().getModel("spdDetails").getData().phaseViewRemoveMode = false;
			this.getView().getModel("spdDetails").getData().iNumberOfItems = 0;
			this.getView().getModel("spdDetails").getData().iNumberOfItemsPhaseView = 0;
			this.getView().getModel("spdDetails").getData().iNumberOfDaysPhaseView = 0;
			this.getView().getModel("spdDetails").getData().handleSrSoSubmitButtonEnabled = 0;
			this.getView().getModel("spdDetails").getData().isOperationsProject = false;
			if (this.FocusedOn === "ExecutionPlanFocused") {
				this.getView().getModel("spdDetails").getData().Header = {};
				this.getView().getModel("spdDetails").getData().Header.Name = "Execution Plan";
			}
			this.getView().getModel("spdDetails").refresh();

			let oVizModel = new JSONModel({});
			this.getView().setModel(oVizModel, "vizModel");
			this.getView().getModel("vizModel").getData().iNumberOfPlannedItems = 0;
			this.getView().getModel("vizModel").getData().iNumberOfProposalItems = 0;
			this.getView().getModel("vizModel").getData().iNumberOfProposalDays = 0;
			this.getView().getModel("vizModel").getData().iNumberOfPlannedDays = 0;
			this.getView().getModel("vizModel").refresh();

			let oVizData = new JSONModel({});
			this.getView().setModel(oVizData, "vizData");

			let oGridListModel = new JSONModel({});
			this.getView().setModel(oGridListModel, "gridListModel");
			this.getView().getModel("gridListModel").getData().allPhases = [true, true, true, true, true, true, true];

			let oComponentsModel = new JSONModel({});
			this.getView().setModel(oComponentsModel, "componentsModel");
			this.getView().getModel("componentsModel").getData().allCRMComponents = [];
			this.getView().getModel("componentsModel").getData().numberOfAllCRMComponents = 0;
			this.getView().getModel("componentsModel").getData().replacedAddListPath = "";
			this.getView().getModel("componentsModel").getData().searchComponentsFilter = {};
			this.getView().getModel("componentsModel").getData().searchComponentsFilterAddList = {};
			this.getView().getModel("componentsModel").getData().searchComponentsResults = [];
			this.getView().getModel("componentsModel").getData().searchComponentsResultsAddList = [];
			this.getView().getModel("componentsModel").getData().searchComponentsNumberOfResults = 0;
			this.getView().getModel("componentsModel").refresh();

			let oLayoutModel = new JSONModel({});
			this.getView().setModel(oLayoutModel, "layoutModel");

			let oFocusPackagesModel = new JSONModel({});
			oFocusPackagesModel.setSizeLimit(9999);
			this.getView().setModel(oFocusPackagesModel, "focusPackages");
			this.getView().getModel("focusPackages").getData().allPackages = [];
			this.getView().getModel("focusPackages").getData().searchPackagesFilter = {};
			this.getView().getModel("focusPackages").getData().searchPackagesResults = [];
			this.getView().getModel("focusPackages").getData().selectedPackage = {};
			this.getView().getModel("focusPackages").refresh();

			let oFilterModel = new JSONModel({});
			this.getView().setModel(oFilterModel, "filterModel");

			this.getView().getModel("filterModel").getData().types = Constants.getObjectTypesSPD();

			this.getView().getModel("filterModel").getData().rating = Constants.getRatingTypes();

			this.getView().getModel("filterModel").refresh();

			// model for handling account persons in "Create SR/SO" Dialog
			let oModelAccPerson = new JSONModel({});
			oModelAccPerson.setSizeLimit(1000);
			this.getView().setModel(oModelAccPerson, "oModelAcc");
			oModelAccPerson.setData({
				messageAccVisible: false,
				soacpValueHelp: [],
				selectedAccContact: []
			});

			// model for handling ServiceOrderGroup in "Create SR/SO" Dialog
			let oSOGModel = new JSONModel({});
			this.getView().setModel(oSOGModel, "oSOGroupModel");
			this.getView().getModel("oSOGroupModel").getData().showInfoMessage = false;
			this.getView().getModel("oSOGroupModel").getData().valueStateCreatedBy = "None";
			this.getView().getModel("oSOGroupModel").getData().selectedSOG = "";
			this.getView().getModel("oSOGroupModel").getData().ServiceOrderGroup = "";
			this.getView().getModel("oSOGroupModel").refresh();

			// model for Contract checks
			let oContractCheckSet = new JSONModel({});
			this.getView().setModel(oContractCheckSet, "contractCheckSet");

			// model for SOG live search
			let oSOGSearch = new JSONModel({});
			this.getView().setModel(oSOGSearch, "oSOGSearch");
			this.getView().getModel("oSOGSearch").getData().showWarningMessage = false;
			this.getView().getModel("oSOGSearch").refresh();

		},

		_initVariants: async function () {
			if (this.getView().getModel("localModel").getData().sSelectedViewType === "phaseView") {
				return;
			}
			this.variant.context = this;
			this.variant.pageVariantID = "pageVariantID";
			if (this.getView().getModel("variantModel"))
				this.getView().getModel("variantModel").setData(null);
			this.getView().setModel(this.variant.variantModel, "variantModel");
			this.variant.variantSetName = "HEP_Projects_Drafts_";
			this.variant.variantLoaded = () => {
				if (this.variant.currentVariant.tablePerso.getData()) {
					this.getTablePerso().getPersoService().setPersData(this.variant.currentVariant.tablePerso.getData());
					this.getTablePerso().refresh();
				} else {
					this.getTablePerso().getPersoService().resetPersData();
					this.getTablePerso().refresh();
				}
				this.onResetSortServices();
				this._resetFilters();
				this.variant.currentVariant.filter.getData().hasBeenClicked = false;
				this.lastFiltersSetted = this.getView().getModel("filterModel").getData().selectedKeysFilters;
				this._oSort = this.variant.currentVariant.filter.getData().sortItem;
				this.getView().getModel("localModel").getData().phaseSortAsc = this.variant.currentVariant.filter.getData().phaseSortSelect;

				if (this.variant.currentVariant.filter.getData().sortDraftPlansObject)
					this.getOwnerComponent().getEventBus().publish("ChannelSortOrderDraftPlans", "SortOrderSet", this.variant.currentVariant.filter.getData()
						.sortDraftPlansObject);

				if (this.variant.currentVariant.filter.getData().filtersetted) {
					this.searchFilters = this.variant.currentVariant.filter.getData().filtersetted;
					this._oData.filtersSetted = true;
				} else {
					this._oData.filtersSetted = false;
				}

				if(this.getView().getModel("localModel").getData().sSelectedViewType === "listView")
					this.onSPDDetailsFilterPressed(true)
				else
					this._readSPDItems();
			};

			// Reset table personlization and save as assigne to standard variant
			await this.getTablePerso().getPersoService().resetPersData();
			this.getTablePerso().getPersoService().getPersData().done(function (oPersData) {
				for (const element of oPersData.aColumns) {
					// Standard setting use 'tablePerso'-IDs for some reason.
					// In order to reapply the standard personalization we need to harmonize that by using the componentName
					element.id = element.id.replace("tablePerso-", this.getTablePerso().getComponentName() + "-");
				}
				this.variant.standardVariant.filter.getData().filtersetted = null;
				this.variant.standardVariant.filter.getData().filterlist = null;
				this.variant.standardVariant.filter.getData().sortItem = null;
				this.variant.standardVariant.filter.getData().hasBeenClicked = false;
				this.variant.standardVariant.filter.getData().sortDraftPlansObject = {
					"sortItem": "CreatedAt",
					"sortOrder": "desc"
				};
				this.variant.standardVariant.filter.getData().phaseSortSelect = false;
				this.variant.standardVariant.tablePerso.setData(oPersData);
			}.bind(this));
			this.variant.readVariants(null);

		},

		onVariantSave: function (oEvent) {
			this.variant.currentVariant.filter.getData().filtersetted = this.searchFilters;
			this.variant.currentVariant.filter.getData().filterlist = this.oStore;
			this.variant.currentVariant.filter.getData().sortItem = this._oSort;
			this.variant.currentVariant.filter.getData().sortDraftPlansObject = this.sortDraftPlans;
			this.variant.currentVariant.filter.getData().phaseSortSelect = this.getView().getModel("localModel").getData().phaseSortAsc;

			this.getTablePerso().getPersoService().getPersData().done(function (oPersData) {
				this.variant.currentVariant.tablePerso.setData(oPersData);
				this.variant.onSave(oEvent);
				this.variant.standardVariant.filter.getData().filtersetted = false;
				this.variant.standardVariant.filter.getData().filterlist = "";
				this.variant.standardVariant.filter.getData().sortItem = null;
				this.variant.standardVariant.filter.getData().hasBeenClicked = false;
				this.variant.standardVariant.filter.getData().sortDraftPlansObject = {
					"sortItem": "CreatedAt",
					"sortOrder": "desc"
				};
				this.variant.standardVariant.filter.getData().phaseSortSelect = false;
			}.bind(this));
		},

		onVariantSelect: function (oEvent) {
			this.variant.onSelect(oEvent);
		},

		onVariantManage: function (oEvent) {
			this.variant.onManage(oEvent);
		},

		getTablePerso: function () {
			return this._oTPCServices;
		},

		/**
		 * triggered on startup of SPD
		 * load the list of all Service Object Types from SSC in order to find the code for type "Service Components"
		 *
		 * Remark: In SSC they have the following:
		 * 0. "Service" - ZSPM_SERVICE_OBJECT_1020
		 * 1. "Offering" - ZSPM_SERVICE_OBJECT_1000
		 * 2. "Package" - ZSPM_SERVICE_OBJECT_1010
		 * 3. "Service Component" - ZSPM_SERVICE_OBJECT_1040
		 * 4. "Service Plan" - ZSPM_SERVICE_OBJECT_1050
		 * 5. "Business Scenario" - ZSPM_SERVICE_OBJECT_1060
		 *
		 * Background Information:
		 * What we assign in HEP to a "HEP Service Plan" are SSC-Service-Components.
		 * In SSC these components are part of a SSC-Service-Plan.
		 * There are two types of SSC-Service-Plan-Objects.
		 * We call them in HEP "Focus Packages" and "Business Scenarios"
		 * This is confusing, because in SSC there actually is a service object type that is
		 * called "Business Scenario" (see list above)
		 * So, our HEP-Business-Scenarios are actually SSC-Business-Scenarios-Modules, because they
		 * are part of a SSC-Business-Scenario
		 */

		//============================================================================================
		//============================================================================================

		_pReadSPDHeader: function () {
			return new Promise((resolve, reject) => {
				if (this.FocusedOn !== "ExecutionPlanFocused" && this.FocusedOn !== "ProjectIsLoaded") {
					let entities = {};
					this.getView().getModel("localModel").getData().busySPDGeneralInformation = true;
					this.getView().getModel("localModel").refresh();
					entities.servicePath = Constants.getServicePathSPD();
					entities.entitySet = `${Constants.getEntities().ServicePlanHeaderSet}(guid'${this._SPDID}')`;
					entities.currentView = this.getView();
					entities.busyIndicator = "busySPDGeneralInformation";
					entities.callbackSuccess = (oData) => {
						if (oData.Status === "RESTR") this._handleRestrictedSPD();

						this.getView().getModel("spdDetails").getData().Header = oData;
						this.getView().getModel("spdDetails").refresh();

						this._pReadProjectDetails().then(resolve());
					};
					entities.callbackError = (oError) => {
						this._pReadProjectDetails().then(() => {
							this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "ProjectIsLoaded", this.getView().getModel(
								"spdDetails").getData().CaseDetails); //go to the initial situation, which means the Excecution Plan will be focused...
							//	resolve(); //??
							this.messageHandler.clearAllMessages();
							this.messageHandler.addNewMessageseInsidePopover(
								null,
								"Warning",
								"Focused Draft Plan does not exist any more",
								"Execution Plan is focused instead.");
						});
					};
					this.readBaseRequest(entities);
				} else {
					this._pReadProjectDetails().then(resolve());
				}
			});
		},

		_pReadProjectDetails: function () {
			return new Promise((resolve, reject) => {
				this.getOwnerComponent().oHelperData.pReadProjectDetails.then((oData) => {

					this._handleSuccessProjectData(oData);

					// Sets avialable phases for an item in the dropdown menu
					if (this.getView().getModel("spdDetails").getData().isOperationsProject) { //ZSPROMET03
						this.getView().getModel("gridListModel").getData().allPhases = [true, false, false, false, false, false, true];
						this.getView().getModel("gridListModel").refresh();
					}
					this.getView().getModel("localModel").getData().messageStripVisible = true;
					this.getView().getModel("localModel").refresh();

					resolve();
				});
			});

		},

		_handleSuccessProjectData: function (oData) {
			this.getView().getModel("spdDetails").getData().CaseDetails = oData;
			// Sets a flag isOperationsProject to true in case project has an Operatons code
			// used for handling of phases in phase view, since Operatons projects have only phases "None" and "Run"
			if (oData.ProjectMethodology === "ZSPROMET03") {
				this.getView().getModel("spdDetails").getData().isOperationsProject = true;
			}
			this._enrichPhaseModelWithDates(oData.toProjectPhase.results);
			this.getView().getModel("spdDetails").refresh();
		},

		_enrichPhaseModelWithDates: function (oPhasesWithDates) {
			const oFilterModel = this.getView().getModel("filterModel"),
				oFilterModelPhases = oFilterModel.getData().phases;

			oFilterModelPhases.forEach(function (oPhase) {
				if (oPhase.Value === "None" || oPhase.Name === "" || oPhase.DdlbKey === "None") return;
				const oPhaseWithDates = oPhasesWithDates.find(function (oLookupPhase) {
					return (oLookupPhase.PhaseID === oPhase.DdlbKey && oLookupPhase.PhaseName === oPhase.Value);
				});
				if (oPhaseWithDates) {
					oPhase.StartDate = oPhaseWithDates.PhaseStartDate;
					oPhase.EndDate = oPhaseWithDates.PhaseEndDate;
				}
			});
			oFilterModel.refresh(true);
		},

		_readSPDItems: function () {
			let entities = {};
			this.getView().getModel("localModel").getData().busyDraftPlanItems = true;
			this.getView().getModel("localModel").refresh();
			entities.servicePath = Constants.getServicePathSPD();

			if (this.getView().getModel("localModel").getData().ExecutionPlanFocused || this.FocusedOn === "ExecutionPlanFocused") {
				entities.entitySet = "ServicePlanItemSet";
				entities.filter = "( CaseID eq '" + this._projectId + "' and SpGuid eq guid'00000000-0000-0000-0000-000000000000') ";
			} else {
				entities.entitySet = "ServicePlanHeaderSet(guid'" + this._SPDID + "')" + "/toServicePlanItem";
				entities.filter = "";
			}

			entities.currentView = this.getView();

			if (this.searchFilters) {
				if (["ExecutionPlanFocused", "ProjectIsLoaded"].includes(this.FocusedOn)) {
					entities.filter += this.searchFilters;
				} else {
					entities.filter = this.searchFilters.substring(5);
				}
			}

			entities.oContext = this;

			if (this._oSort) {
				entities.sortItem = this._oSort.myData.field;
				entities.sortOrder = Constants.getSortOrder()[this._oSort.myData.order];
				this.getView().byId(this._oSort.myData.column).setSortIndicator(this._oSort.myData.order);
				this.getView().getModel("localModel").refresh();
			}

			//on phase view the filtering works on the already loaded items. (while for list view every filter change triggers a new BE request)
			//so in case of phase view, we must not apply the filters for the BE-call. It needs to contain everything.
			if (this.getView().getModel("localModel").getData().sSelectedViewType === "listView") {
				entities.filter = this._readSPDItemsFilterHandler(entities)
			}

			entities.busyIndicator = "busyDraftPlanItems";
			entities.errorMessage = this.getResourceBundle().getText("Error.DraftPlan.readSPDItems");
			entities.callbackSuccess = (oData) => {
				this._pContractCheckSetLoaded.then(() => {
					this._handleSuccessReadSPDItems(oData);
					this.getView().getModel("localModel").getData().busyDraftPlanItems = false;
					this.getView().getModel("localModel").refresh();

				});
			};

			this.readBaseRequest(entities);
		},

		_readSPDItemsFilterHandler: function (entities) {
			//--> do not show "Cancelled" (SR header) - if not selected explicitly by the user
			if (!entities.filter.includes("ItemStatusID eq 'ZSRQ0001|E0006'")) {
				entities.filter = entities.filter ? entities.filter + " and " : "";
				entities.filter += "(ItemStatusID ne 'ZSRQ0001|E0006')";

			}
			//--> do not show "SO Created" (SR header) - if not selected explicitly by the user
			if (!entities.filter.includes("ItemStatusID eq 'ZSRQ0001|E0007'")) {
				entities.filter = entities.filter ? entities.filter + " and " : "";
				entities.filter += "(ItemStatusID ne 'ZSRQ0001|E0007')";

			}
			//if the user has NOT selected to see sessions with cancelled header status and also NOT selected to see cancelled sessions themselves...
			if (!entities.filter.includes("ItemStatusID eq 'ZSK00001|E0007'") && !entities.filter.includes(
				"ComponentStatusID eq 'ZSK00003|E0031'")) {
				//..filter them all away...
				entities.filter = entities.filter ? entities.filter + " and " : "";
				entities.filter += "(ItemStatusID ne 'ZSK00001|E0007') and (ComponentStatusID ne 'ZSK00003|E0031')";
				}
			return entities.filter;
		},

		_handleSuccessReadSPDItems: function (oData) {
			let bProposalsThere = false;
			let bExpanded = this.getView().getModel("localModel").getData().expandedMode;

			this.getView().getModel("localModel").getData().numberOfTableEntries = Number(oData.__count);
			this.getView().getModel("spdDetails").getData().iNumberOfItemsPhaseView = 0;
			this.getView().getModel("spdDetails").getData().iNumberOfDaysPhaseView = 0;
			this.getView().getModel("vizModel").getData().iNumberOfPlannedItems = 0;
			this.getView().getModel("vizModel").getData().iNumberOfProposalItems = 0;
			this.getView().getModel("vizModel").getData().iNumberOfProposalDays = 0;
			this.getView().getModel("vizModel").getData().iNumberOfPlannedDays = 0;

			oData.results.forEach(oItem => {
				oItem.bShowAssignMyselfAsConsultantBtn = oItem.SrvConsultID !== this._oLoggedInUserCrmData.BPNo;
				oItem.Colour = this._getSPDItemColour(oItem);
				oItem.FlaggedForDeletion = false;
				oItem.Level = 1;
				oItem.bIsSelected = false;
				oItem.PhaseID = oItem.PhaseID ? oItem.PhaseID : "None";
				if (oItem.ItemType === "YSP1") {
					bProposalsThere = true;
				} else if (oItem.ComponentDescr === "") {
					//Drafts do not have an ObjectTitle (=Description of SR/SO), because there is still no OneOrderObject behind
					// so would not make sense to set the objectTitle as Alternative Dscription for Drafts.
					// Actually only for SRs it is possible, that they do not have a service/component, because SRS allows creation of this.
					// In this case we then set the mandatory SR-Description(ObjectTitle) as alternative description
					oItem.ComponentDescrAlternative = oItem.ObjectTitle;
				}
				oItem.isExpanded = bExpanded;
				oItem.statusIndicator = this.getStatusIndicator(oItem.ItemStatus);

				oItem.UIComponentStatusT = this._getUIComponentText(oItem);
				oItem.UIComponentItemData = oItem.ItemType + "|" + oItem.UIComponentStatusT;
				oItem.bItemIsVisible = true;

				oItem.UIWrapTitle = this.formatter.wrapTileLabel(oItem.ItemStatusText, oItem.ComponentDescrAlternative, oItem.ObjectTitle);

				this._handleContractSituationOfSPDItem(oItem);

				this.getView().getModel("spdDetails").getData().iNumberOfItemsPhaseView++;
				this.getView().getModel("spdDetails").getData().iNumberOfDaysPhaseView += parseFloat(oItem.EffortTotal);
			});
			let aPhases = this.getView().getModel("filterModel").getData().phases;
			aPhases.map(oPhase => {
				oPhase.items = [];
				oPhase.Name = oPhase.Value !== "None" ? oPhase.Value : "";
				oPhase.Level = 0;
			});
			oData.results.forEach(item => {
				this._spdItemPhasesHandler(item, aPhases);
			});
			// Remove all phases which are not "None" and Run in case there is an Operations project
			if (this.getView().getModel("spdDetails").getData().isOperationsProject) {
				aPhases = aPhases.filter(function (item) {
					return item.DdlbKey === 'None' || item.DdlbKey === 'WTF_05';
				});
			}
			this.getView().getModel("spdDetails").getData().phases = aPhases;

			// KNGMHM02-26515 : Change calculation based on filtering
			//this.getView().getModel("spdDetails").getData().iNumberOfItemsPhaseView =
			//	aPhases.reduce((acc, oPhase) => acc + oPhase.items.length, 0);
			//this.getView().getModel("spdDetails").getData().iNumberOfDaysPhaseView =
			//	oData.results.reduce((acc, oItem) => acc + parseFloat(oItem.EffortTotal), 0);

			// create data for the PlanDetalisPopover plot
			// calculate the number of total efforts for planned (non-draft) items
			if (this.getView().getModel("localModel").getData().sSelectedViewType === "listView") {
				this.getView().getModel("vizModel").getData().iNumberOfPlannedDays =
					oData.results.filter(oItem => oItem.ItemType !== "YSP1")
					.reduce((acc, oItem) => acc + parseFloat(oItem.EffortTotal), 0);
				// calculate the number of total efforts for proposal (draft) items
				this.getView().getModel("vizModel").getData().iNumberOfProposalDays =
					oData.results.filter(oItem => oItem.ItemType === "YSP1")
					.reduce((acc, oItem) => acc + parseFloat(oItem.EffortTotal), 0);
				// calculate the number of proposal (draft) items
				this.getView().getModel("vizModel").getData().iNumberOfProposalItems =
					oData.results.filter(oItem => oItem.ItemType === "YSP1")
					.reduce((acc, oItem) => acc + 1, 0);
				// calculate the number of total efforts for planned items
				this.getView().getModel("vizModel").getData().iNumberOfPlannedItems =
					oData.results.filter(oItem => oItem.ItemType !== "YSP1")
					.reduce((acc, oItem) => acc + 1, 0);
			}

			this.onPhaseViewFilterPhaseSelectionChange1();
			this.getView().getModel("spdDetails").refresh(true);

			this.getView().getModel("layoutModel").setData(this.getColumnWidths(this.getView().getModel("spdDetails").getData().phases));

			this.getView().getModel("localModel").getData().selectedItemsForTransfer =
				this.getView().getModel("spdDetails").getData().phases;

			let aItems;
			//get sorted items after phase and date
			if (!this._oSort && this.getView().getModel("localModel").getData().sSelectedViewType === "listView") {
				aItems = this._spdItemsSorter(aPhases);
			}
			this.getView().getModel("spdDetails").getData().results = aItems || oData.results;
			this.getView().getModel("spdDetails").refresh();

			this.getView().getModel("localModel").getData().areThereProposalsDisplayed = bProposalsThere;
			this.getView().getModel("localModel").getData().removeServicesEnabled = bProposalsThere;
			this.getView().getModel("localModel").refresh();
		},

		_spdItemPhasesHandler: function (item, aPhases) {
			let oFindPhase = aPhases.find(oPhase => item.PhaseText.includes(oPhase.Value));
			if (oFindPhase) {
				oFindPhase.items.push(item);
			} else {
				aPhases.find(oPhase => oPhase.Value === "None").items.push(item);
			}
		},

      // Sorts items in Draftplan list view if "Standard" variand was selected.
      // Sorts in ascending and descending order.
		_spdItemsSorter: function (aPhases) {
			let aItems = [];
			if (this.getView().getModel("localModel").getData().phaseSortAsc) {
          // Ascending order sort
        [...aPhases].reverse().forEach(aPhase => {
            aItems.push(...[...aPhase.items].reverse());
        });
			} else {
          // descending order sort
       aPhases.forEach(aPhase => {
            aItems.push(...aPhase.items);
        });
			}
			return aItems;
		},

		setSortingToPhaseDate: function () {
			let oTable = this.getView().byId("draftItemsTable");
			oTable.resetSorting();
			this.getView().getModel("localModel").getData().phaseSortAsc = !this.getView().getModel("localModel").getData().phaseSortAsc;
			this._oSort = null;

			this._readSPDItems();
		},

		_readSingleSPDItem: function (sItemGuid, sSpGuid, fnCallback) {
			if (!sItemGuid || !sSpGuid) return;
			let entities = {};
			this.getView().getModel("localModel").getData().busySPDetails = true;
			this.getView().getModel("localModel").refresh();
			entities.servicePath = Constants.getServicePathSPD();
			entities.entitySet = `ServicePlanItemSet(ItemGuid=guid'${sItemGuid}',SpGuid=guid'${sSpGuid}')`;
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.busyIndicator = "busySPListView";
			entities.errorMessage = this.getResourceBundle().getText("Error.DraftPlan.readSPDItems");
			entities.callbackSuccess = (oData) => {
				oData.Colour = this._getSPDItemColour(oData);
				oData.ComponentUnknown = !(oData.ComponentID);
				oData.statusIndicator = this.getStatusIndicator(oData.ItemStatus);
				this._handleContractSituationOfSPDItem(oData);
				// KNGMHM02-26515: Map UIComponent Text - Ins
				oData.UIComponentStatusT = this._getUIComponentText(oData);
				oData.UIComponentItemData = oData.ItemType + "|" + oData.UIComponentStatusT;
				oData.bItemIsVisible = true;
				// KNGMHM02-26515: Map UIComponent Text - End
				// KNGMHM02-27420: wrap title
				oData.UIWrapTitle = this.formatter.wrapTileLabel(oData.ItemStatusText, oData.ComponentDescrAlternative, oData.ObjectTitle);
				// KNGMHM02-27420: wrap title
				this.getView().getModel("spdDetails").refresh();
				if (fnCallback) fnCallback(oData);
				this.getView().getModel("localModel").getData().busySPDetails = false;
				this.getView().getModel("localModel").getData().busySPListView = false;
				this.getView().getModel("localModel").refresh();
			};
			this.readBaseRequest(entities);
		},

		/**
		 * Item status values:
		 * - E0001 - New - Planned
		 * - E0002 - Sent to delivery - Delivery confirmed
		 * - E0005 - Delivered
		 * - E0016 - Delivery Preparation
		 *
		 * @param {object} oItem - the SPD Item
		 * @return {object} sColour - the SPD item color
		 */
		_getSPDItemColour: function (oItem) {
			let sColour = "silver";
			if (oItem.ItemType === "ZSR1") {
				switch (oItem.ItemStatus) {
				case "E0001":
					sColour = "light-yellow";
					break;
				case "E0003": //In Scoping
				case "E0004": //In Exception
					sColour = "light-purple";
					break;
				case "E0002":
				case "E0005":
				case "E0008":
					sColour = "light-orange";
					break;
				}

			} else if (oItem.ItemType === "ZSK1") {
				switch (oItem.ItemStatus) {
				case "E0001":
					sColour = "light-yellow";
					break;
				case "E0015":
					sColour = "light-orange";
					break;
				case "E0016":
				case "E0002":
					sColour = "light-blue";
					break;
				case "E0005":
					sColour = "light-green";
					break;
				}
			}
			return sColour;
		},
		// KNGMHM02-26515: Map UIComponent Text - Ins
		/**
		 * Item status values:
		 * - E0001 - New - Planned
		 * - E0002 - Delivery confirmed
		 * Component status values:
		 * - E0019 - Open
		 * - E0029 - Delivered with Follow up
		 * - E0030 - Delivered w/o Follow up
		 * - E0020 - Date-New
		 * - E0021 - Date Postponed
		 * - E0022 - Date Confirmed
		 * - E0032 - In Process by 2nd level
		 * - E0023 - Preparation New
		 * - E0024 - Preparation in Process
		 * - E0027 - In Process by QA
		 * - E0026 - Preparation Completed
		 * - E0028 - QA completed
		 */
		_getUIComponentText: function (oItem) {
			let uiStatusText = oItem.ItemStatusText;
			if (oItem.ItemType === "ZSK1") {
				uiStatusText = oItem.ComponentStatusT;
				switch (oItem.ItemStatus) {
				case 'E0001':
					switch (oItem.ComponentStatus) {
					case 'E0019':
					case '':
						uiStatusText = 'New';
						break;
					}
					break;
				case 'E0002':
					switch (oItem.ComponentStatus) {
					case 'E0020':
					case 'E0021':
					case 'E0022':
					case 'E0032':
					case 'E0023':
					case 'E0024':
					case 'E0027':
					case 'E0026':
					case 'E0028':
						uiStatusText = 'In Delivery';
						break;
					}
					break;
				default:
					switch (oItem.ComponentStatus) {
					case 'E0019':
					case 'E0020':
					case 'E0021':
					case 'E0022':
					case 'E0032':
					case 'E0023':
					case 'E0024':
					case 'E0027':
					case 'E0026':
					case 'E0028':
						uiStatusText = 'Backoffice Action';
						break;
					}
				}
				switch (oItem.ComponentStatus) {
				case 'E0029':
				case 'E0030':
					uiStatusText = 'Delivered';
					break;
				}
			}
			return uiStatusText;
		},

		// ==========================================================================================================
		// ==========================================================================================================
		// ==================================== Contract Handling ===================================================
		// ==========================================================================================================
		// ==========================================================================================================

		/**
		 * This method handles the contract situation of an SPD item.
		 * For this, it makes a deep clone copy from the array of all contractItems, that has been loaded from the BE once, for the given customer.
		 * It then loops over that array and pushes all contractItems, that fit to the given SPD Item properties, into a new array.
		 * Relevant properties of the SPD Item are ServiceID, ComponentId and StartDate, depending on if they are available or not
		 * The new array contains then all contractItems that are considered as "valid" for the SPD Item in the current situation.
		 * Finally the SPD-item gets this array assigned as property "ValidContractItems" and also property "showWarningNoValidContract" is set.
		 *
		 * @param {object} oItem - SPDItem to handle
		 */
		_handleContractSituationOfSPDItem: function (oItem) {
				if (oItem?.ItemType === 'YSP1') { //only for Proposals
					oItem.showWarningNoValidContract = false;
					// make a fresh deep copy of the conract items for this SPDItem, and then push fitting contracts-objects from that copy into new array for SPD item
					let aAllCustomerContractItems = Object.values($.extend(true, {}, this.getView().getModel("contractCheckSet").getData().allCustomerContractItems));
					let aValidItemContractItems = [];

					if (aAllCustomerContractItems && aAllCustomerContractItems.length > 0) {
						this._handleAvailableContractsHelper(oItem, aAllCustomerContractItems, aValidItemContractItems);
					}
					oItem.ValidContractItems = aValidItemContractItems;
					oItem.showWarningNoValidContract = !aValidItemContractItems.length;
					// remove potentially old contract data from item
					if (oItem.showWarningNoValidContract) {
						oItem.ContractID = "";
						oItem.ContractItem = "";
						oItem.SelectedContract = {};
				}
			}
		},

		_handleAvailableContractsHelper: function (oItem, aAllCustomerContractItems, aValidItemContractItems) {
			// happens in TTE dialog, where ComponentID is set, but the StartDate is still missing
			const checkAndUpdateContract = (condition) => {
				aAllCustomerContractItems.forEach(oContr => {
					if (condition(oContr)) {
						oContr.GroupId = `${oContr.ContractID} ${oContr.ContractDescription}`;
						aValidItemContractItems.push(oContr);
					}
				});
			};

			if (oItem.ServiceID && oItem.StartDate) {
				checkAndUpdateContract(oContr => oContr.ServiceID === oItem.ServiceID &&
					oContr.ComponentID === oItem.ComponentID &&
					oItem.StartDate >= oContr.StartDate &&
					oItem.StartDate <= oContr.EndDate);
			} else if (oItem.ComponentID) {
				if (oItem.StartDate) {
					checkAndUpdateContract(oContr => oContr.ComponentID === oItem.ComponentID && oItem.StartDate >= oContr.StartDate && oItem.StartDate <= oContr.EndDate);
				} else {
					checkAndUpdateContract(oContr => oContr.ComponentID === oItem.ComponentID);
				}
			} else if (oItem.StartDate) {
				checkAndUpdateContract(oContr => oItem.StartDate >= oContr.StartDate && oItem.StartDate <= oContr.EndDate);
			} else { // nothing given, no ComponentId or StartDate
				checkAndUpdateContract(() => true);
			}
		},

		/**
		 * This method shows a message box with a warning that no valid contracts could be found for an SPDItem.
		 * It offers two buttons. The first button just closes the message box, so the user can change the data
		 * The second button lets the user ignore the warning and continue with whatever comes next (creating the SPD item or updating it)
		 * For this a callback-function must be handed over to the method, togehter with relevant parameters, which is then called.
		 *
		 * @param {object} oItem - SPDItem to handle
		 */
		_showNoValidContractWarningMessageBox: function (fnCallback, ...args) {
			MessageBox.warning(this.getResourceBundle().getText("SPDDetails.PhaseView.AddService.ComponentID.Warning.Message"), {
				icon: MessageBox.Icon.warning,
				title: this.getResourceBundle().getText("SPDDetails.PhaseView.AddService.ComponentID.Warning.Title"),
				actions: [this.getResourceBundle().getText("SPDDetails.PhaseView.AddService.ComponentID.Warning.Button.ok"), MessageBox.Action
					.IGNORE
				],
				emphasizedAction: this.getResourceBundle().getText("SPDDetails.PhaseView.AddService.ComponentID.Warning.Button.ok"),
				onClose: function (oAction) {
					if (oAction === "IGNORE") {
						if (fnCallback) {
							let oContext = args[0];
							let oItem = args[1];
							let bTransferToExecution = args[2];
							fnCallback(oContext, oItem, bTransferToExecution);
						}
					}
				}
			});
		},

		// ==========================================================================================================
		// ==========================================================================================================

		_HandleSaveAutoReArrange: function () {
			let oData = this.getView().getModel("spdDetails").getData().phases;
			oData.forEach(oItems => {
				oItems.items.forEach(oItem => {
					if (oItem.PhaseLocked) {
						let oPhaseIndex = oItem.PhaseCalculated.split("WTF_0")[1];
						oPhaseIndex = Number(oPhaseIndex) + 1;
						if (oItem.PhaseCalculated === "") {
							oPhaseIndex = "0";
						}
						oItem.PhaseID = this.getView().getModel("spdDetails").getData().phases[oPhaseIndex].DdlbKey;
						oItem.PhaseText = this.getView().getModel("spdDetails").getData().phases[oPhaseIndex].Value;
						oItem.Updated = true;
						this.getView().getModel("spdDetails").refresh();
					}
				});
			});
			this.getView().getModel("localModel").getData().busySPDEdit = true;
			this.getView().getModel("localModel").refresh();
			let entities = {},
				dataForUpdate = {
					"PhaseChangeAccepted": true
				};
			entities.servicePath = Constants.getServicePathSPD();
			entities.entitySet = "ServicePlanHeaderSet(guid'" +
				this.getView().getModel("spdDetails").getData().Header.SpGuid + "')";
			entities.currentView = this.getView();
			entities.oContext = this._parentView;
			entities.data = dataForUpdate;
			entities.errorMessage = this.getResourceBundle().getText("ProjectSPD.Edit.Error");
			entities.busyIndicator = "busySPDEdit";
			entities.callbackSuccess = () => {
				this.getView().getModel("localModel").getData().busySPDEdit = false;
				this.getView().getModel("localModel").getData().updateSPDBtnEnabled = false;
				this.getView().getModel("localModel").refresh();
			};
			this.updateBaseRequest(entities);
			this._HandleDiscardWarning();
			this.onListViewSave();
		},

		_HandleDiscardWarning: function (oEvent) {
			this.byId("AutoChangeDialog").close();
		},

		_initializeListViewTablePerso: function () {
			if (this._oTPCListView === undefined) {
				this._oTPCListView = new TablePersoController({
					table: this.getView().byId("tableSPDListViewTree"),
					componentName: "SPDDetails",
					customDataKey: "PersoKey",
					persoService: TablePersoListView
				});
			}
		},

		onListViewPersoButtonPressed: function (oEvent) {
			this._oTPCListView.openDialog();
		},

		onListViewTablePersoRefresh: function () {
			TablePersoListView.resetPersData();
			this._oTPCListView.refresh();
		},

		onListViewResetSort: function () {
			let oTable = this.getView().byId("tableSPDListView");
			oTable.resetSorting();
		},

		onListViewSwitchToEditMode: function () {
			this.getView().getModel("spdDetails").getData().phases.forEach(oPhase => {
				oPhase.items.forEach(oItem => {
					oItem.bIsSelected = false;
				});
			});
			this.getView().getModel("spdDetails").refresh();
			this.getView().getModel("localModel").getData().listViewEditMode = true;
			this.getView().getModel("localModel").getData().phaseViewEditMode = true;
			this.getView().getModel("localModel").refresh();
		},

		_resetSPDListViewModeAfterUpdate: function () {
			this.getView().getModel("localModel").getData().busySPListView = false;
			this.getView().getModel("localModel").getData().busySPDetails = false;
			this.getView().getModel("localModel").getData().listViewEditMode = false;
			this.getView().getModel("localModel").getData().phaseViewEditMode = false;
			this.getView().getModel("localModel").refresh();
		},

		onSPDItemChange: function (oEvent) {
			let oUpdateRow = oEvent.getSource(),
				sPath = oUpdateRow.getBindingContext("spdDetails").getPath(),
				oUpdatedItem = this.getView().getModel("spdDetails").getProperty(sPath);
			oUpdatedItem.Updated = true;
			this.getView().getModel("spdDetails").refresh();
		},

		onListViewSave: function () {
			/*
			bSaveIsBlocked prevents multiple dispatches for the same item and acts as a
			poor man's mutex. Set to "false" on init, if "true", further dispatches to the
			BE are prevented.
			*/
			let bSaveIsBlocked = this.getView().getModel("localModel").getData().bSaveIsBlocked;

			if (!bSaveIsBlocked) {
				this.getView().getModel("localModel").getData().bSaveIsBlocked = true;
				this.getView().getModel("localModel").getData().busySPDetails = true;
				this.getView().getModel("localModel").refresh();
				this.messageHandler.clearAllMessages();

				let oPromiseSPDListViewSaveItems = new Promise((resolveItems, rejectItems) => {
					return this._saveListOfSPDListViewItems(resolveItems, rejectItems);
				});
				oPromiseSPDListViewSaveItems.then(() => {
					this._resetSPDListViewModeAfterUpdate();
				}, (error) => {
					this._resetSPDListViewModeAfterUpdate();
				});

			}
		},

		onPressDisplayAnyServiceItem: function (oEvent) {
			const sType = this.getView().getModel("spdDetails").getProperty(oEvent.getSource().getBindingContext("spdDetails").sPath).ItemType;
			if (sType === "ZSR1") this.onPressDisplayServiceRequest(oEvent);
			else this.handleDisplayServiceOrder(oEvent);

		},

		onPressDisplayServiceRequest: function (oEvent) {
			let oSource = oEvent.getSource(),
				sID = oSource.getBindingContext("spdDetails").getProperty("ObjectID"),
				sProjectID = oSource.getModel("spdDetails").getProperty("/CaseDetails/ProjectID");
			NavigationToExternalApps.fnNavigateToSrsApp("Display", sID, sProjectID);
		},

		_saveListOfSPDListViewItems: function (resolveItems, rejectItems) {
			let aSPDItems = [],
				aPhases = this.getView().getModel("spdDetails").getData().phases;
			aPhases.forEach(oPhase => {
				aSPDItems = aSPDItems.concat(oPhase.items);
			});
			aSPDItems = aSPDItems.filter(oItem => {
				return ((!oItem.ObjectGuid && !oItem.FlaggedForDeletion) || (oItem.FlaggedForDeletion && oItem.ObjectGuid) || oItem.Updated );
			});
			aSPDItems.forEach(oItem => {
				if (oItem.PhaseID === "None") {
					oItem.PhaseID = "";
					oItem.PhaseText = "";
				}
			});

			this.getView().getModel("localModel").getData().busySPDetails = true;
			this.getView().getModel("localModel").refresh();

			let that = this;
			let chain = Promise.resolve();
			aSPDItems.forEach((oItem) => {
				chain = chain.then(() => this._executeProperCrudOperationForItem(oItem).then(() => {
					this._setTrack(that);
				}));
			});
			chain.then(() => {
				this._handleSuccesCreatedSPDService();
				this._resetSPDListViewModeAfterUpdate();
				this._readSPDItems();
				this._handlePackageImportData();
				this.messageHandler.addNewMessageseInsidePopover(
					null,
					"Success",
					"Service Plan Saved",
					"All of your changes have been successfully saved");
				this.getView().getModel("localModel").getData().bSaveIsBlocked = false;
			});
			chain.catch(() => {
				this.getView().getModel("localModel").getData().bSaveIsBlocked = false;
			});
		},

		_setTrack: function (oContext) {
			if (oContext._addServiceSelected) oContext.getOwnerComponent().trackEvent("Create_SPDItems_ViaAddService");
			if (oContext._addPackageSelected) oContext.getOwnerComponent().trackEvent("Create_SPDItems_ViaAddPackage");
			if (oContext._addListOfServicesSelected) oContext.getOwnerComponent().trackEvent("Create_SPDItems_ViaAddListOfServices");
			if (oContext._packageImportSelected) oContext.getOwnerComponent().trackEvent("Create_SPDItems_ViaImportFromSSC");
			if (oContext._reArrangeSelected) oContext.getOwnerComponent().trackEvent("ReArrange_SPDItems");
			oContext._addServiceSelected = false;
			oContext._addPackageSelected = false;
			oContext._addListOfServicesSelected = false;
			oContext._reArrangeSelected = false;
		},

		_handlePackageImportData: function () {
			if (this._packageImportSelected) {
				this.getOwnerComponent().getModel("appData").getData().oMyStorage.remove("importPackageFromSSCId");
				this.getOwnerComponent().getModel("appData").refresh();
				this._sImportPackageFromSSCId = "";
				this.getView().getModel("localModel").getData().importPackageFromSSCEnabled = false;
				this.getView().getModel("localModel").refresh();
				this._packageImportSelected = false;
			}
		},

		_executeProperCrudOperationForItem: function (oItem) {
			return new Promise((resolve, reject) => {
				if (oItem.ObjectGuid === undefined || oItem.ObjectGuid === "") {
					this.getView().getModel("spdDetails").getData().newService = oItem; // oSPDItem;
					this.getView().getModel("spdDetails").refresh();
					this._onCreateService(resolve);
				} else if (oItem.FlaggedForDeletion === true) {
					this._deleteSPDItem(oItem, oItem.Phase, resolve, reject);
				} else {
					this.onUpdateSPDItem(oItem, resolve);
				}
			});
		},

		onListViewSwitchToDisplayMode: function () {
			MessageBox.confirm(this.getResourceBundle().getText("SPDDetails.PhaseView.Confirm.Cancel"), {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				emphasizedAction: MessageBox.Action.YES,
				onClose: (sAction) => {
					if (sAction === "YES") {
						this._readSPDItems();
						this.getView().getModel("localModel").getData().listViewEditMode = false;
						this.getView().getModel("localModel").getData().phaseViewEditMode = false;
						this.getView().getModel("localModel").refresh();
					}
				}
			});
		},

		// =========================== Add/Remove Services Menu  ===========================

		/**
		 * EventHandler, triggered after user has selected one of the four menu entries
		 * of menu-button "Add/Remove Services"
		 *
		 * @param {object} oEvent - Event data
		 */
		onBtnAddItemsPressed: function (oEvent) {
			if (oEvent.getParameters().item.getId().includes("addService")) {
				this._fnOpenDialogAddSpdItem();
			}
			if (oEvent.getParameters().item.getId().includes("add_ServiceList")) {
				this._loadAddServiceListDialogFragment();
			} else if (oEvent.getParameters().item.getId().includes("addPackage")) {
				this._loadAddFocusPackageDialogFragment(true);
			} else if (oEvent.getParameters().item.getId().includes("importPackageFromSSC")) {
				this._importPackageFromSSC();
			} else if (oEvent.getParameters().item.getId().includes("removeServices")) {
				this.onPhaseViewSwitchToRemoveMode();
			}
		},

		// =======================================================================================================
		// =======================================================================================================
		// =====================================       Add / Maintain  SPD Item       ============================
		// =======================================================================================================
		// =======================================================================================================

		/**
		 * Load the required fragment, in case it is not already there.
		 * Initialize the "newService"-path of the spdDetails-Model, and bind it to the fragment
		 */
		_fnOpenDialogAddSpdItem: function () {
			this._pDialogAddItem ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.DialogAddSPDItem");
			this._pDialogAddItem.then(oDialog => {
				this.getView().getModel("spdDetails").getData().newService = {};
				this.getView().getModel("spdDetails").getData().newService.Phase = "None";
				this.getView().getModel("spdDetails").getData().newService.showWarningNoValidContract = false;
				this.getView().getModel("spdDetails").getData().newService.Effort = "";
				this.getView().getModel("spdDetails").getData().newService.componentIdMandatory = true;
				this.getView().getModel("spdDetails").getData().newService.ComponentUnknown = false;
				this.getView().getModel("spdDetails").refresh();
				oDialog.open();
				oDialog.bindElement("spdDetails>/newService");
			})
		},

		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
		// <<<<<<<<<<<<<<<<<<<<<<<<     Event Handler inside Add/Maintain Service Dialog     >>>>>>>>>>>>>>>>>>>>>>>>>>>>
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

		/**
		 * Event-Handler, that is triggered, when the user presses the button "Add"
		 * inside the dialog-popup for adding a single service to the service plan.
		 */
		fnOnAddServicePress: function () {
			this.getView().getModel("localModel").getData().busyDraftPlanItems = true;
			this.getView().getModel("localModel").refresh();

			if (this._validateServiceMaintenanceForm()) {
				this._handleContractSituationOfSPDItem(this.getView().getModel("spdDetails").getData().newService);
				this.getView().getModel("spdDetails").refresh();
				if (this.getView().getModel("spdDetails").getData().newService.showWarningNoValidContract) {
					this._showNoValidContractWarningMessageBox(this._onAddServiceToUI, this, this.getView().getModel("spdDetails").getData().newService);
				} else {
					this._onAddServiceToUI();
				}
				this.onPhaseViewSave();
			}
		},

		/**
		 * Event-Handler, that is triggered, when the user presses the button "Cancel"
		 * inside the dialog-popup for adding or mataining an SPD item
		 * And also, when the dialog is closed.
		 *
		 * @param {object} oEvent - Event data
		 */
		fnHandleCloseDialogAddSpdItem: function (oEvent) {
			if (oEvent.getSource()._oCloseTrigger === undefined) this._addServiceSelected = false;  //for reporting

			// initialize F4-Component-Search
			this.getView().getModel("componentsModel").getData().searchComponentsFilter = {};
			this.getView().getModel("componentsModel").getData().searchComponentsResults = [];
			this.getView().getModel("componentsModel").getData().searchComponentsNumberOfResults = 0;
			this.getView().getModel("componentsModel").refresh();

			//clean up the Dialog
			this._pDialogAddItem?.then(oDialog => oDialog.destroy());
			this._pDialogAddItem = undefined;
		},

		/**
		 * Event-Handler, that is triggered, when the user presses the button
		 * to open the Component ID field Value Help
		 */
		fnOnComponentIdValueHelpRequest: function () {
			this.getView().byId("AddSaveButton").setVisible(false);
			let oNavCon = this.getView().byId("navContainer"),
				oDetailPage = this.getView().byId("srvMaintainDetail");
			if (this.getView().byId("inputComponentID"))
				oNavCon.attachAfterNavigate(function () {
					this.getView().byId("inputComponentID").focus();
				}.bind(this));
			oNavCon.to(oDetailPage);
			this.fnOnSearchComponents();
		},

		/**
		 * Event-Handler, that is triggered, when the user navigtes back from component-selection-page
		 * to the form for adding/maintaing an SPD item.
		 * The function is also called in the event-handler for selecting a component in the result list
		 * of the component-selection serach help
		 */
		fnOnAddSrvNavToForm: function () {
			this.getView().byId("AddSaveButton").setVisible(true);
			let oNavCon = this.getView().byId("navContainer"),
				oMasterPage = this.getView().byId("srvMaintainMaster");
			oNavCon.to(oMasterPage);
		},

		onNavToDialogPage: function (oEvent, sMasterPageId) {
			this.getView().byId("AddSaveButton").setVisible(true);
			const oNavContainer = oEvent.getSource().getParent(),
				oMasterPage = this.getView().byId(sMasterPageId);
			oNavContainer.to(oMasterPage);
		},

		onCloseDialog: function (oEvent) {
			oEvent.getSource().getParent().close();
		},

		/**
		 * triggered, when the user presses the search-button on the Component-F4-Search-Popup.
		 * @param {object} oEvent - Event data
		 */
		fnOnSearchComponents: function (oEvent) {
			let oLocalModel = this.getView().getModel("localModel");
			oLocalModel.getData().busyComponentsLoading = true;
			oLocalModel.refresh();
			this._pAllComponentsLoadedFromCRM.then(() => {
				let oComponentsModel = this.getView().getModel("componentsModel");
				let sFilterComponentDescription = oComponentsModel.getData().searchComponentsFilter.componentDescription;
				if (sFilterComponentDescription) {
					oComponentsModel.getData().searchComponentsResults = oComponentsModel.getData().allCRMComponents.filter(oComp => {
						return (oComp.ComponentDescriptionUc.includes(sFilterComponentDescription.toUpperCase()) || oComp.ComponentID.includes(
							sFilterComponentDescription.toUpperCase()));
					});
				} else {
					oComponentsModel.getData().searchComponentsResults = oComponentsModel.getData().allCRMComponents.filter(oComp => true);
				}
				oComponentsModel.getData().searchComponentsNumberOfResults = oComponentsModel.getData().searchComponentsResults.length;
				oComponentsModel.refresh();
				oLocalModel.getData().busyComponentsLoading = false;
				oLocalModel.refresh();
			});

		},

		/**
		 * Receives the list of ComponentID's entered by user and adds them to a list
		 * Triggered by DialogAddServiceList.fragment
		 **/
		fnOnSearchMultipleComponents: function (oEvent) {
			let oLocalModel = this.getView().getModel("localModel"),
				oComponentsModel = this.getView().getModel("componentsModel"),
				removeContainedItems = this._removeContainedItems,
				removeDuplicates = this._removeDuplicates,
				splitTrimComponents = this._splitTrimComponents,
				clearInvalidItems = this._clearInvalidItems;

			oLocalModel.getData().busyComponentsLoading = true;
			oLocalModel.refresh();

			this._pAllComponentsLoadedFromCRM.then(() => {
				// get raw list of items, separated by the ';'
				let sFilterComponentDescription = oComponentsModel.getData().searchComponentsFilterAddList.componentDescription;
				// split items by being a string of numbers with a length === 7
				let aFilterComponentDescription = splitTrimComponents(sFilterComponentDescription);
				// remove duplicates in user-entried ComponentIDs
				aFilterComponentDescription = removeDuplicates(aFilterComponentDescription);
				// clean invalid items - will do it only for items already checked and in the list
				oComponentsModel.getData().searchComponentsResultsAddList = clearInvalidItems(oComponentsModel.getData().searchComponentsResultsAddList);
				// check if entries aFilterComponentDescription are already in searchComponentsResults to prevent duplicates
				aFilterComponentDescription = removeContainedItems(aFilterComponentDescription, oComponentsModel.getData().searchComponentsResultsAddList);

				if (aFilterComponentDescription) {
					aFilterComponentDescription.forEach(sFilterComponent => {
						// search for results in the list of CRM entries
						let searchResult = oComponentsModel.getData().allCRMComponents.filter(
							oComp => {
								return (oComp.ComponentDescriptionUc.includes(sFilterComponent.toUpperCase()) || oComp.ComponentID.includes(
									sFilterComponent.toUpperCase()));
							});
						if (searchResult.length !== 0) {
							// a result was found
							searchResult[0].isValid = true;
							oComponentsModel.getData().searchComponentsResultsAddList.push(searchResult);
						} else {
							// nothing found, creating a manual entry for user to correct later
							let result = {
								"ComponentID": sFilterComponent,
								"isValid": false
							};
							oComponentsModel.getData().searchComponentsResultsAddList.push([result]);
						}
					});
				}
				// flatten the hierarchy
				oComponentsModel.getData().searchComponentsResultsAddList = oComponentsModel.getData().searchComponentsResultsAddList.flat(1);
				oComponentsModel
					.getData().searchComponentsNumberOfResults = oComponentsModel.getData().searchComponentsResults.length;
				// get phases from BE and enrich phases data, also copy nested data into the top scope
				oComponentsModel.getData().searchComponentsResultsAddList = this._enrichWithPhasesAndNested(oComponentsModel.getData().searchComponentsResultsAddList,
					oComponentsModel);
				// check for links to existing services in SPD
				oComponentsModel.getData().searchComponentsResultsAddList.forEach(oItem => {
					// return the topmost item in SPD
					const aComponentsFromPlan = this._getComponentsFromPlanWithGivenId(oItem.ComponentID);
					// if there is an item in the returned array
					this._compListLinkBuilder(aComponentsFromPlan, oItem)
				});


				// clear items with an empty Component
				oComponentsModel.getData().searchComponentsResultsAddList = this._clearEmptyComponentItems(oComponentsModel.getData().searchComponentsResultsAddList);
				// store the number of Components to be displayed below filterbar
				oComponentsModel.getData().searchComponentsFilterAddList.numberOfComponents = oComponentsModel.getData().searchComponentsResultsAddList
					.length;
				oComponentsModel.refresh();
				oLocalModel.getData().busyComponentsLoading = false;
				oLocalModel.refresh();
			});
		},

    _compListLinkBuilder: function (aComponentsFromPlan, oItem) {
      if (aComponentsFromPlan.length === 0) {
        // no entry in service plan
        // make component field editable
        oItem.isNotInSPD = true;
      } else {
        // only use the first component from the array for building the link...
        oItem.sSpdDetailsModelItemBindingPath = aComponentsFromPlan[0].sSpdDetailsModelItemBindingPath;
        switch (aComponentsFromPlan[0].ItemType) {
          case "ZSR1": //Service Request
            oItem.sLinkText = "SR " + aComponentsFromPlan[0].TransactionID;
            if (aComponentsFromPlan.length > 1) {
              oItem.sLinkText = oItem.sLinkText + "...";
            }
            break;
          case "ZSK1": //Service Order
            oItem.sLinkText = "SO " + aComponentsFromPlan[0].TransactionID;
            if (aComponentsFromPlan.length > 1) {
              oItem.sLinkText = oItem.sLinkText + "...";
            }
            break;
          case "YSP1": //Proposal
            oItem.sLinkText = "Proposal Item";
            if (aComponentsFromPlan.length > 1) {
              oItem.sLinkText = oItem.sLinkText + "...";
            }
        }
        // make componentID field non-editable
        oItem.isNotInSPD = false;
      }
    },

		/*
		 ** Splits a string with regex in separate ComponentIDs. Only numbers == 7 are accepted.
		 ** @param (string): string with components including any kind of delimiters.
		 */
		_splitTrimComponents: function (sComponents) {
			const re = /\d{7}/g;
			const result = sComponents.match(re);
			// if nothing was matched, e.g, user have entered a string
			// we return an empty array to prevent locking up the UI further down the line
			return result || [];
		},

		/*
		 ** Triggered on save of multiple components in DialogAddServiceList
		 ** Similar in functionality to fnOnAddServicePress, but loops over several entries in the list
		 ** Validates every item wth _handleContractSituationOfSPDItem and submits it with _onAddServiceListComponentsToUI
		 */
		onAddMultipleComponentsPress: function () {
			this._addListOfServicesSelected = true;
			let aSelectedItems = [],
				oContext = this,
				oView = this.getView();
			// get selected and valid items from the list for submit
			aSelectedItems = this.getView().getModel("componentsModel").getData().searchComponentsResultsAddList.filter(oItem => oItem.isValid &&
				oItem.isSelected);
			aSelectedItems.forEach(compItem => {
				oContext._handleContractSituationOfSPDItem(compItem);
				oView.getModel("spdDetails").refresh();
				if (compItem.showWarningNoValidContract) {
					oContext._showNoValidContractWarningMessageBox(oContext._onAddServiceToUI, oContext, compItem);
				} else {
					oContext._onAddServiceListComponentsToUI(oContext, compItem);
				}
			});
			oContext.onPhaseViewSave();
			oContext._clearComponentsAddList();
		},

		/*
		 ** Handles Cancel press in DialogAddServiceList
		 */
		onCancelAddServiceListPress: function () {
			this._addListOfServicesSelected = false;
			// reset the dialog position in the container to Master
			this.fnAddListDialogBackToMaster();
			this._clearComponentsAddList();
		},

		/*
		 ** Clears filter and found items in the DialogAddServiceList on Save and Cancel
		 */
		_clearComponentsAddList: function () {
			const oCompModel = this.getView().getModel("componentsModel");
			let oPopup = this.getView().byId("addListDialogMaster").getParent().getParent();
			// reset model to init state
			oCompModel.getData().searchComponentsFilterAddList = {};
			oCompModel.getData().searchComponentsResultsAddList = [];
			oCompModel.getData().searchComponentsNumberOfResults = 0;
			oCompModel.refresh();
			// destroy the popup
			oPopup.destroyDependents();
			oPopup.close();
		},

		/*
		 ** Submits an item as Draft to Phase View
		 ** @param {object} oContext: scope object
		 ** @param {object} compItem: single component item
		 */
		_onAddServiceListComponentsToUI: function (oContext, compItem) {
			oContext.getView().getModel("localModel").getData().busyAddService = true;
			oContext.getView().getModel("localModel").refresh();
			let oComponent = {
				"SpGuid": oContext.getModel("spdDetails").getData().Header.SpGuid,
				"ItemTypeText": "Template",
				"ItemType": "YSP1",
				"ComponentID": compItem.ComponentID,
				"ComponentDescr": compItem.ComponentDescr,
				"ComponentDescrAlternative": "",
				"EffortTotal": compItem.ComponentEffort,
				"PhaseID": compItem.Phase ? compItem.Phase : "None",
				"Effort": compItem.ComponentEffort,
				"ItemStatus": "DRAFT",
				"ItemStatusText": "Draft",
				"TbuiUrl": "",
				"SrsUrl": "",
				"ReleaseAllowed": false,
				"IsdHubUrl": "",
				"Type": "Draft",
				"FlaggedForDeletion": false,
				"isExpanded": oContext.getView().getModel("localModel").getData().expandedMode,
				"showWarningNoValidContract": compItem.showWarningNoValidContract
			};
			oComponent.Colour = oContext._getSPDItemColour(oComponent);

			let oPhaseItemSelectedPhase = oContext.getView().getModel("spdDetails").getData().phases.find(oPhase => {
				if (!oComponent.PhaseID) return oPhase.DdlbKey === oComponent.Phase;
				else return oPhase.DdlbKey === oComponent.PhaseID;
			});
			oComponent.Phase = oPhaseItemSelectedPhase.Value;
			oContext.getView().getModel("spdDetails").getData().results.unshift(oComponent);
			oPhaseItemSelectedPhase.items.unshift(oComponent);
			oContext.getView().getModel("spdDetails").refresh(true);
		},

		/*
		 ** Triggered in DialogAddServiceList > AddServiceList when user clicks on ValueHelp for invalid components
		 ** Navigates to the ValueHelpComponentID fragment within the same dialog
		 */
		fnAddListOnComponentIdValueHelp: function (oEvent) {
			this.getView().byId("AddServiceListButton").setEnabled(false);
			let oNavCon = this.getView().byId("navContainerAddList"),
				oDetailPage = this.getView().byId("addListDialogCompSearch"),
				oComponentsModel = this.getView().getModel("componentsModel"),
				sSearchValue = oEvent.getSource().getValue(),
				sSearchValuePath = oEvent.getSource().getBinding("value").getContext().getPath();

			// set search field in the ValueHelpComponentID to the current value with model
			oComponentsModel.getData().searchComponentsFilter.componentDescription = sSearchValue;
			// store path to the entry changed in the model and store it in oComponents model.
			// it will be used for replacement by the callback from the user selected items in the ValueHelpComponentID dialog
			oComponentsModel.getData().replacedAddListPath = sSearchValuePath;
			if (this.getView().byId("inputComponentIDAL"))
				oNavCon.attachAfterNavigate(function () {
					this.getView().byId("inputComponentIDAL").focus();
				}.bind(this));
			oNavCon.to(oDetailPage);
			this.fnOnSearchComponents();
		},

		/*
		 ** Navigates back from the ValueHelpComponentID to DialogAddServiceList
		 */
		fnAddListDialogBackToMaster: function () {
			this.getView().byId("AddServiceListButton").setEnabled(true);
			let oNavCon = this.getView().byId("navContainerAddList"),
				oMasterPage = this.getView().byId("addListDialogMaster");
			oNavCon.to(oMasterPage);

		},

		/*
		 ** Triggered by text input field in the DialogAddServiceList
		 ** Checks input for length and enables submit button if length > 7
		 */
		enableAddListButton(sInput) {
			let localModel = this.getView().getModel("localModel");
			if (sInput.length >= 7) {
				localModel.getData().addListSubmitEnabled = true;
			} else {
				localModel.getData().addListSubmitEnabled = false;
			}
			localModel.refresh();
		},

		onAddServiceListSelectionChange: function (oEvent) {
			// aSelectedComponents is required only to unblock the submit button
			let oListItems = oEvent.getSource().getAggregation("items"),
				oModel = this.getView().getModel("componentsModel"),
				oLocalModel = this.getView().getModel("localModel"),
				aSelectedComponents = [];
			// set the count of selected items to 0 - will be calculated new in the end
			oModel.getData().searchComponentsFilterAddList.numberOfSelectedComponents = 0;

			// handle the case of selectAll
			if (oEvent?.getParameter("selectAll")) {
				oListItems.forEach(oListItem => {
					this._addServiceSelectAllHelper(oListItem, oModel, aSelectedComponents);
				});
			} else {
				// single item selection logic
				const oListItem = oEvent.getParameter("listItem"),
					sPath = oListItem.getBindingContextPath(),
					oItem = oModel.getProperty(sPath);

				if (oListItem.getProperty("selected")) {
					// select an item
					oItem.isSelected = true;
					aSelectedComponents.push(oItem);
				} else {
					// unselect the ListItem
					oItem.isSelected = false;
					// check if there are still selected items in the list
					oModel.getData().searchComponentsResultsAddList.forEach(compItem => {
						if (compItem.isSelected) {
							aSelectedComponents.push(compItem);
						}
					});
				}
			}
			// re-calculate number of selected items
			oListItems.forEach(oListItem => {
				if (oListItem.isSelected()) {
					oModel.getData().searchComponentsFilterAddList.numberOfSelectedComponents += 1;
				}
			});
			// check if button can be unblocked
			oLocalModel.getData().addServiceListSaveEnabled = aSelectedComponents.length > 0;
			oModel.refresh();
			oLocalModel.refresh();
		},

		_addServiceSelectAllHelper: function (oListItem, oModel, aSelectedComponents) {
			// get model item and check for being a valid one
			const sPath = oListItem.getBindingContextPath();
			const oItem = oModel.getProperty(sPath);
			if (oItem.isValid) {
				aSelectedComponents.push(oItem);
				oItem.isSelected = true;
			} else {
				// do not let invalid items be selected
				oListItem.setSelected(false);
			}
		},
		/*
		Adds a method to disable selection checkboxes on invalid items in Table
		Is called by the method updateFinished by the table in XML view
		*/
		_triggerCheckboxStateBasedOnValidity: function () {
			let oTable = this.getView().byId("AddListComponentsTable"),
				aItems = oTable.getItems(),
				oComponentsModel = this.getView().getModel("componentsModel");

			oComponentsModel.getData().searchComponentsFilterAddList.numberOfSelectedComponents = 0;
			aItems.forEach(item => {

				let sPath = item.getBindingContextPath();
				let oProperty = oComponentsModel.getProperty(sPath);
				if (oProperty.isValid && oProperty.isNotInSPD) {
					// item is valid, enable checkbox
					item.getMultiSelectControl().setBlocked(false);
					// item not in plan yet, pre-select
					item.setSelected(true);
					// set isSelected to true, otherwise item is not consedered on submit
					oProperty.isSelected = true;
					// enable submit button
					this.getView().getModel("localModel").getData().addServiceListSaveEnabled = true;
					this.getView().getModel("localModel").refresh();
					oComponentsModel.getData().searchComponentsFilterAddList.numberOfSelectedComponents += 1;
				} else if (oProperty.isValid && !oProperty.isNotInSPD) {
					// item is valid, enable checkbox, but do not pre-select since already in plan
					item.getMultiSelectControl().setBlocked(false);
				} else {
					// item is invalid, disable checkbox and block
					item.setSelected(false);
					oProperty.isSelected = false;
					item.getMultiSelectControl().setBlocked(true);
				}
				oComponentsModel.refresh();
			});
		},

		// Takes an array of items added by user (aCompIdArr) and an array of Items already in the list (oListOfItems)
		// Checks if added ComponentId is already on the list, returns only the ComponentId's not in the list already.
		_removeContainedItems: function (aCompIdArr, oListOfItems) {
			const aListOfCompID = oListOfItems.map(oItem => oItem.ComponentID);
			return aCompIdArr.filter(el => {return !aListOfCompID.includes(el);})
		},

		/*
		 ** Removes duplicated items in array
		 ** Receives an array with componentIDs aCompArr
		 ** Returns an array with unique items
		 */
		_removeDuplicates: function (aCompArr) {
			const unique = [];
			aCompArr.forEach(element => {
				if (!unique.includes(element)) {
					unique.push(element);
				}
			});
			return unique;
		},

		_enrichWithPhasesAndNested: function (searchComponentResults, oComponentsModel) {
			for (const item of searchComponentResults) {
				let oPromise = this._pGetComponentFirstPhaseFromSSC(item.ComponentID); // is a resolve
				oPromise.then(
					(success) => {
						item.Phase = this._determineCRMPhaseIDBasedOnSSCPhaseID(success);
						oComponentsModel.refresh();
					},
					(error) => {
						item.Phase = "None";
						oComponentsModel.refresh();
					});
			}
			// copy nested information from CRM into the top scope of the object
			searchComponentResults.forEach(oItem => {
				oItem.ComponentDescr = oItem.toServiceF4 ? oItem.toServiceF4.results[0].ComponentDescription : "";
				oItem.ComponentDescrAlternative = oItem.toServiceF4 ? oItem.toServiceF4.results[0].ComponentDescriptionUc : "";
				oItem.ComponentEffort = oItem.toServiceF4 ? oItem.toServiceF4.results[0].ComponentEffort : "";
			});
			return searchComponentResults;

		},

		/*
		 * Removes items with empty componentID in the Add List of Services dialog
		 * @param {array} aComponentList - array with Component objects
		 */
		_clearEmptyComponentItems: function (aComponentList) {
			return aComponentList.filter(oComponent => oComponent.ComponentID !== "");
		},

		/*
		 * Removes items with isValid === false from the list
		 * @param {array} aListOfItems - array with enriched Component Items
		 */
		_clearInvalidItems: function (aListOfItems) {
			return (aListOfItems.filter(oComponent => oComponent.isValid));
		},

		/**
		 * triggered, when the user selects a componentItem in the result list of the Component-F4-Search-Popup.
		 *
		 * @param {object} oEvent - Event data
		 */
		fnOnComponentItemSelected: function (oEvent) {
			const oSource = oEvent.getSource();
			const oSelectedComp = this.getView().getModel("componentsModel").getProperty(oSource.getSelectedContextPaths()[0]);
			// make a distinction from where ComponentIdSearch were triggered by getting ancestor ID and matching them.
			// possible ancestors are srvMaintainDetail for Add Single Service
			// addListDialogCompSearch for Add List of Services
			const sAncestorId = oSource.getParent().getParent().getId();
			if (sAncestorId.match("srvMaintainDetail")) {
				// called from Add Single Service
				if (this.getView().getModel("spdDetails").getData().newService === undefined) this.getView().getModel("spdDetails").getData().newService = {};
				let oParentDialog = oSource.getParent();
				while (oParentDialog.getMetadata()._sClassName !== "sap.m.Dialog") oParentDialog = oParentDialog.getParent();
				const sBindPath = oParentDialog.getBindingContext("spdDetails").getPath();
				this._updateFormModelAfterComponentSelectionHelper(sBindPath, oSelectedComp);
				this.getView().byId("srvComponentDescrAlter").setValueState("None");
				this.getView().byId("componentsTable").removeSelections();
				this.fnOnAddSrvNavToForm();
				this._validateServiceMaintenanceForm();
			} else {
				// called from Add List of Services (ValueHelpComponentAddList.fragment.xml)
				let oComponentsModel = this.getView().getModel("componentsModel"),
					sReplaceAddListPath = oComponentsModel.getData().replacedAddListPath;
				//oEntryToReplace = oComponentsModel.getProperty(sReplaceAddListPath);
				// copy values from selected item to the old one
				this._updateСomponentsModelAfterComponentSelectionHelper(sReplaceAddListPath, oSelectedComp);
				// preset standard phase
				this._enrichWithPhasesAndNested([this.getView().getModel("componentsModel").getProperty(sReplaceAddListPath)], oComponentsModel);
				// re-calculate blocked status for the newly added item
				this._triggerCheckboxStateBasedOnValidity();
				this.fnAddListDialogBackToMaster();

			}
		},

		/**
		 * Event Handler
		 * Triggered when the user presses <Enter> in field ComponentId inside the dialog to add or change an SPD item
		 * the entered value is evaluated and depending on that, the related bound model fields are set.
		 * Depending on if the Dialog is used to add a new item or to change an existing item another model path is used
		 *
		 * @return {object}: oEvent - event related data
		 */
		fnOnComponentFieldChangeOrSubmit: function (oEvent) {
			const oSource = oEvent.getSource();
			const oNewValue = oSource.getValue();
			const bFieldValid = this._validateComponentIdField();
			this._pAllComponentsLoadedFromCRM.then(() => {
				const sPath = oSource.getBindingContext("spdDetails").getPath();
				let oSelComp;
				if (sPath.includes("newService")) { //create new SPD item
					if (oNewValue && bFieldValid) { //field "Component Id" is valid (however, in case it is not required, it might be valid although given ID is not)
						oSelComp = this.getView().getModel("componentsModel").getData().allCRMComponents.find(elm => elm.ComponentID === oNewValue);
						if (oSelComp) { //a component could be identified with the given id
							this._updateFormModelAfterComponentSelectionHelper("/newService", oSelComp);
						} else { // the given Id has no sense, but field is not required either
							this.getView().getModel("spdDetails").getData().newService.ComponentID = oNewValue;
							this.getView().getModel("spdDetails").getData().newService.ComponentDescr = "";
						}
					} else { //no or not valid value in field "Component Id"
						this.getView().getModel("spdDetails").getData().newService.ComponentID = oNewValue;
						this.getView().getModel("spdDetails").getData().newService.ComponentDescr = "";
					}
				} else if (oNewValue && bFieldValid) { //valid value was entered in field "Component Id"
					oSelComp = this.getView().getModel("componentsModel").getData().allCRMComponents.find(elm => elm.ComponentID === oNewValue);
					this._updateFormModelAfterComponentSelectionHelper(sPath, oSelComp);
				} else { //no or not valid value in field "Component Id"
					this.getView().getModel("spdDetails").getProperty(sPath).ComponentID = oNewValue;
					this.getView().getModel("spdDetails").getProperty(sPath).ComponentDescr = "";
				}
				this.getView().getModel("spdDetails").refresh();
			});
		},

		_updateСomponentsModelAfterComponentSelectionHelper: function (sBindPath, oSelectedComp) {
			this.getView().getModel("componentsModel").getProperty(sBindPath).ComponentDescription = oSelectedComp.ComponentDescription;
			this.getView().getModel("componentsModel").getProperty(sBindPath).ComponentDescriptionUc = oSelectedComp.ComponentDescriptionUc;
			this.getView().getModel("componentsModel").getProperty(sBindPath).ComponentID = oSelectedComp.ComponentID;
			this.getView().getModel("componentsModel").getProperty(sBindPath).EffortFixed = oSelectedComp.EffortFixed;
			this.getView().getModel("componentsModel").getProperty(sBindPath).Phase = oSelectedComp.Phase;
			this.getView().getModel("componentsModel").getProperty(sBindPath).isValid = true;
			this.getView().getModel("componentsModel").getProperty(sBindPath).Effort = oSelectedComp.toServiceF4.results[0].ComponentEffort;
			this.getView().getModel("componentsModel").refresh();
		},

		_updateFormModelAfterComponentSelectionHelper: function (sBindPath, oSelectedComp) {
			this.getView().getModel("spdDetails").getProperty(sBindPath).ComponentID = oSelectedComp.ComponentID;
			this.getView().getModel("spdDetails").getProperty(sBindPath).ComponentDescr = oSelectedComp.ComponentDescription;
			this.getView().getModel("spdDetails").getProperty(sBindPath).Phase = oSelectedComp.ComponentFirstPhase;
			this.getView().getModel("spdDetails").getProperty(sBindPath).PhaseID = oSelectedComp.ComponentFirstPhase;
			this.getView().getModel("spdDetails").getProperty(sBindPath).Effort = oSelectedComp.ComponentEffort;
			this.getView().getModel("spdDetails").getProperty(sBindPath).EffortTotal = oSelectedComp.ComponentEffort;
			this.getView().getModel("spdDetails").getProperty(sBindPath).EffortFixed = oSelectedComp.EffortFixed;
			this.getView().getModel("spdDetails").getProperty(sBindPath).ComponentUnknown = false;
			this.getView().getModel("spdDetails").getProperty(sBindPath).StartDate = null;
			this.getView().getModel("spdDetails").getProperty(sBindPath).EndDate = null;
			this.getView().getModel("spdDetails").refresh();
		},

		/**
		 * Event Handler
		 * Triggered when the user changes the flag in the check-box for "not knowing the component yet"
		 *
		 * @return {object}: oEvent - event related data
		 */
		fnOnToggleComponentId: function (oEvent) {
			const oModel = this.getView().getModel("spdDetails"),
				sPath = oEvent.getSource().getBindingContext("spdDetails").sPath,
				oModelData = oModel.getProperty(sPath);
			if (oEvent.getSource().getSelected()) {
				oModelData.ComponentUnknown = true;
				this.getView().byId("srvComponentID").setValueState("None");
			} else {
				oModelData.ComponentUnknown = false;
				this.getView().byId("srvComponentDescrAlter").setValueState("None");
			}
			this.getView().getModel("spdDetails").refresh();
		},

		/**
		 * Event Handler
		 * Triggered when the user changes something in field with the alternative description in the dialog
		 * to add or change an SPD item
		 *
		 * @return {object}: oEvent - event related data
		 */
		fnOnCompDescrAlterLiveChange: function (oEvent) {
			this._validateAlternDescriptionField();
		},

		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<       Field Validation in Add/Maintain Service Dialog      >>>>>>>>>>>>>>>>>>>>>>>
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

		_validateServiceMaintenanceForm: function () {
			let bComponentIdValid = this._validateComponentIdField();
			let bAlternDescriptionValid = this._validateAlternDescriptionField();
			return bComponentIdValid && bAlternDescriptionValid;
		},

		/*
		The purpose of this method is to validate the input in field Component ID in view "Add Service Plan Item".
		It returns a ValueStateText if it matches in Contract or Service Catalogue Set.
		*/
		_validateComponentIdField: function () {
			let oControl = this.getView().byId("srvComponentID");
			let bValError = false;
			if (oControl.getEnabled()) { //if not changeable any more, we do not check it
				const bCompExistsInCRM = this.getView().getModel("componentsModel").getData().allCRMComponents.some(elm => elm.ComponentID ===
					oControl.getValue());
				const bContrExistsForComp = this.getView().getModel("contractCheckSet").getData().allCustomerContractItems.some(oContrItem =>
					oContrItem.ComponentID === oControl.getValue());

				if (bCompExistsInCRM) { // componentId exists in CRM
					if (!bContrExistsForComp) { //no valid contract found for componentId
						oControl.setValueState("Warning");
						oControl.setValueStateText(this.getResourceBundle().getText("SPDDetails.PhaseView.AddService.ComponentID.Warning.Message"));
					} else { //valid contract also found
						oControl.setValueState("None");
					}
				} else if (oControl.getValue() || oControl.getRequired()) { //componentId is required, but given value makes no sense
					oControl.setValueState("Error");
					oControl.setValueStateText(this.getResourceBundle().getText("SPDDetails.PhaseView.AddService.ComponentID.Error"));
					bValError = true;
				} else { //componentId is not required and empty
					oControl.setValueState("None");
				}
			}
			return !bValError;
		},

		_validateAlternDescriptionField: function () {
			let oControl = this.getView().byId("srvComponentDescrAlter");
			let bValError = false;
			if (oControl.getEnabled()) { //if not changeable any more, we do not check it
				if (oControl.getRequired() && !oControl.getValue()) { // AlternativeDescription is required but not filled
					oControl.setValueState("Error");
					oControl.setValueStateText(this.getResourceBundle().getText("SPDDetails.PhaseView.AddService.ComponentDescrAlter.Error"));
					bValError = true;
				} else {
					oControl.setValueState("None");
				}
			}
			return !bValError;
		},

		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<            Change SPD Item            >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

		/*Also used by function onTreeTableRowClick, test in case of changes*/
		_openMaintainDialog: function (oDialogMaintainSpdItem, sBindingContextPath, sModelName) {
			const oBindingContext = this.getView().getModel(sModelName).getProperty(sBindingContextPath);
			oDialogMaintainSpdItem.open();
			oBindingContext.ComponentUnknown = Boolean(oBindingContext.ComponentID);
			oDialogMaintainSpdItem.bindElement({
				path: `${sModelName}>${sBindingContextPath}`
			});
			// set EndDate in Picker to StartDate if Empty so user does not has to go back multiple months
			// has to be set here, because this property only works is set on init of the dialog window
			if (!oBindingContext.EndDate && oBindingContext.StartDate) {
				this.getView().byId("srvEndDate").setInitialFocusedDateValue(new Date(oBindingContext.StartDate));
			}
		},

		fnOnPressCard: function (oEvent) {
			let oPointer = oEvent.getSource();
			while (oPointer?.getParent() && !oPointer.getBindingContextPath) oPointer = oPointer.getParent(); //fallback, in some cases where this method is used, it is needed

			const
				sBindingContextPath = oEvent.getSource().getBindingContextPath ? oEvent.getSource().getBindingContextPath() : oPointer.getBindingContextPath(),
				sModelName = "spdDetails",
				oModel = this.getView().getModel(sModelName),
				bRemoveMode = this.getView().getModel("localModel").getData().phaseViewRemoveMode,
				bEditMode = this.getView().getModel("localModel").getData().phaseViewEditMode,
				oItem = this.getView().getModel(sModelName).getProperty(sBindingContextPath),
				sFragmentPath = oItem.ItemType === "YSP1" ?
				"com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.DialogMaintainSPDItem" :
				"com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.DialogServiceItemQuickView";
			// Disable edit functionality in Remove and Re-arrange Items mode
			if (bRemoveMode === false && bEditMode === false) {
				if (oItem.ItemTypeText !== "Template") {
					this._toggleBusyIndicatorsUpdateSPDItem(true);
					if (!oItem.SpGuid) {
						oItem.SpGuid = "00000000-0000-0000-0000-000000000000";
					}
					this._readSingleSPDItem(oItem.ItemGuid, oItem.SpGuid,
						function (oLoadedItem) {
							oLoadedItem.isExpanded = oItem.isExpanded;
							this._toggleBusyIndicatorsUpdateSPDItem();
							oModel.setProperty(sBindingContextPath, oLoadedItem);
						}.bind(this));
				}
				this._pDialogMaintainItem ??= this._loadFragment(sFragmentPath);
				this._pDialogMaintainItem.then(oDialog => this._openMaintainDialog(oDialog, sBindingContextPath, sModelName));
			}
			this.setGridListModel(sBindingContextPath);
		},

		fnOnSaveAndTransferToExecution: function (oEvent) {
			this.fnHandleMaintainService(oEvent, true);
		},

		fnHandleMaintainService: function (oEvent, bTransferToExecution) {
			if (this._validateServiceMaintenanceForm()) {
				const oSelectedItem = this.getView().getModel("spdDetails").getProperty(oEvent.getSource().getBindingContext("spdDetails").getPath());
				oSelectedItem.PhaseID = this.getView().byId("srvPhase").getSelectedKey() === "None" ? "" : this.getView().byId("srvPhase").getSelectedKey();
				if (oSelectedItem.ItemTypeText !== "Template") {
					this._handleContractSituationOfSPDItem(oSelectedItem);
					if (oSelectedItem.showWarningNoValidContract) {
						this._showNoValidContractWarningMessageBox(this._fnHandleMaintainServiceDoUpdate, this, oSelectedItem, bTransferToExecution);
					} else {
						this._fnHandleMaintainServiceDoUpdate(this, oSelectedItem, bTransferToExecution);
					}
				} else this._handleMaintainTemplateService(oSelectedItem);
			}
		},

		_fnHandleMaintainServiceDoUpdate: function (oContext, oSelectedItem, bTransferToExecution) {
			oContext._toggleBusyIndicatorsUpdateSPDItem(true);
			oContext.onUpdateSPDItem(oSelectedItem, function () {
				oContext._toggleBusyIndicatorsUpdateSPDItem();
				oContext._pDialogMaintainItem?.then(oDialog => oDialog.destroy());
				oContext._pDialogMaintainItem = undefined;
				oContext._readSPDItems();
				if (bTransferToExecution) oContext._fnTransferSingleProposalToExecution(oSelectedItem);
			});
		},
		fnOnServProdSelectionDialogOpen: function () {
			let sServicePathSPD = Constants.getServicePathSPD();
			let oResourceBundle = this.getResourceBundle();
			let oView = this.getView();

			ServiceProductSelection.fnOnServProdSelectionDialogOpen(oView, oResourceBundle, sServicePathSPD, this._projectId);
		},

		_handleMaintainTemplateService: function (oTemplateService) {
			let oPhaseItemSelectedPhase = this.getView().getModel("spdDetails").getData().phases.find(oPhase => {
				if (!oTemplateService.PhaseID) return oPhase.DdlbKey === oTemplateService.Phase;
				else return oPhase.DdlbKey === oTemplateService.PhaseID;
			});

			if (!oPhaseItemSelectedPhase.items.includes(oTemplateService)) {
				const oOldPhase = this.getView().getModel("spdDetails").getData().phases.find(oPhase => {
					return oPhase.items.includes(oTemplateService);
				});

				const nIndex = oOldPhase.items.indexOf(oTemplateService);
				if (nIndex > -1) {
					oOldPhase.items.splice(nIndex, 1);
				}

				oTemplateService.Phase = oPhaseItemSelectedPhase.Value;
				oPhaseItemSelectedPhase.items.unshift(oTemplateService);

			}
			this.getView().getModel("spdDetails").refresh(true);
			this._pDialogMaintainItem?.then(oDialog => oDialog.destroy());
			this._pDialogMaintainItem = undefined;

		},

		fnHandleDiscardServiceChanges: function (oEvent) {
			this._pDialogMaintainItem?.then(oDialog => oDialog.destroy());
			this._pDialogMaintainItem = undefined;

			const oModel = this.getView().getModel("spdDetails"),
				oDialog = oEvent.getSource().getParent(),
				sBindingPath = oDialog.getBindingContext("spdDetails").getPath(),
				oProperty = oModel.getProperty(sBindingPath);

			this._readSingleSPDItem(oProperty.ItemGuid, oProperty.SpGuid, function (oData) {
				oData.isExpanded = oProperty.isExpanded;
				oModel.setProperty(sBindingPath, oData);
			});

		},

		_toggleBusyIndicatorsUpdateSPDItem: function (bForceTrue) {
			const oLocalModel = this.getView().getModel("localModel"),
				oData = oLocalModel.getData();

			oData.busyAddService = bForceTrue ? true : !oData.busyAddService;
			oData.busySPDetails = bForceTrue ? true : !oData.busySPDetails;

			oLocalModel.refresh();
		},

		fnHandleAfterCloseDialogMaintainItem: function () {
			this.getView().getModel("spdDetails").getData().newService = {};
			this.getView().getModel("spdDetails").refresh();

			// clear search string and trigger empty Component Search again
			this.getView().getModel("componentsModel").getData().searchComponentsFilter = {};
			this.getView().getModel("componentsModel").getData().searchComponentsResults = [];
			this.getView().getModel("componentsModel").getData().searchComponentsNumberOfResults = 0;
			this.getView().getModel("componentsModel").refresh();

			this._pDialogMaintainItem.then(oDialog => oDialog.destroy());
			this._pDialogMaintainItem = undefined;
		},

		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<            Remove SPD Item            >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

		/*
		 * Switches the Phase view to remove mode - disables buttons by settind the local model property
		 * phaseViewRemoveMode, expands all items
		 */
		onPhaseViewSwitchToRemoveMode: function () {
			this.getView().getModel("spdDetails").getData().phases.forEach(oPhase => {
				oPhase.items.forEach(oItem => {
					oItem.bIsSelected = false;
				});
			});
			this.getView().getModel("spdDetails").refresh();
			this.getView().getModel("localModel").getData().phaseViewRemoveMode = true;
			this.getView().getModel("spdDetails").getData().phaseViewRemoveMode = true;
			this.getView().getModel("localModel").getData().expandedMode = true;
			this.getView().getModel("localModel").refresh();
			this._setExpandedModeForAllItems(true);
			// Activate expanded mode for all Service entries
		},

		/* triggered, when user selects and deselects single SPDItems in removal mode
		 * called from SPDDetails.view.xml
		 * changes the activity state of the button responsible for removal of selected itmes
		 * stores items marked for removal in localModel
		 * @param {object} oEvent - Event data
		 */
		onPhaseViewItemsSelectionChange: function (oEvent) {
			let oModel = this.getView().getModel("localModel"),
				aSelectedItemsForRemoval = oModel.getData().selectedItemsForRemoval,
				sPath = oEvent.getParameter("listItem") ? oEvent.getParameter("listItem").getBindingContextPath() : oEvent.getSource().getParent()
				.getParent().getBindingContextPath(),
				oSelectedItem = oEvent.getSource().getBindingContext("spdDetails").getProperty(sPath),
				isSelected = oEvent.getParameter("selected");
			if (oSelectedItem.ItemType !== "YSP1") {
				// de-select item in case an SR/SO item was selected
				let isSelected2 = oEvent.getSource().getSelectedItem ? oEvent.getSource().getSelectedItem().getSelected() : oEvent.getParameter(
					"selected");
				if (isSelected2) {
					oEvent.getSource().getSelectedItem ? oEvent.getSource().getSelectedItem().setSelected() : oEvent.getSource().setProperty(
						'selected', false);
					MessageToast.show(this.getResourceBundle().getText(
						"SPDDetails.PhaseView.RemoveService.CannotBeRemoved"), {
						duration: 5000,
						width: "40em",
						my: "center center",
						at: "center center"
					});
				}
			} else if (isSelected === true) {
				// in case a tile is selected: push item to the array
				aSelectedItemsForRemoval.push(oSelectedItem);
				oModel.refresh(true);
			} else {
				// in case a tile is unselected
				let sItemGuid = oSelectedItem.ItemGuid;
				// find and remove the selected object from the array
				aSelectedItemsForRemoval.splice(aSelectedItemsForRemoval.findIndex(item => item.ItemGuid === sItemGuid), 1);
				oModel.refresh(true);
			}
		},
		/* Removes the selected SPDItems items
		 * @param {object} oEvent - Event data
		 */
		onRemoveSelectedItems: function (oEvent) {
			let oModel = this.getView().getModel("localModel"),
				aSelectedItemsForRemoval = oModel.getData().selectedItemsForRemoval;

			if (aSelectedItemsForRemoval.length === 0) {
				return;
			}

			// flagges items for deletion - REMOVE
			aSelectedItemsForRemoval.forEach(oItem => {
				oItem.FlaggedForDeletion = true;
			});

			Promise.allSettled(aSelectedItemsForRemoval.map(oItem => this._handleRemovalOfPhaseViewItems(oItem)))
				.then(results => {
					this.messageHandler.addNewMessageseInsidePopover(
						null,
						"Success",
						null,
						"Your changes have been successfully saved");
					this.onPhaseViewSave();
					this.getView().getModel("spdDetails").refresh();
					this.getView().getModel("localModel").getData().selectedItemsForRemoval = [];
				})
				.finally(() => {
					this._readSPDItems();
					this.getView().getModel("localModel").getData().phaseViewRemoveMode = false;
					this.getView().getModel("spdDetails").getData().phaseViewRemoveMode = false;
					this._uncheckBoxesAfterDeleteModeClosed();
					// in case we changed to the RemoveMode from the EditMode directly
					this.getView().getModel("localModel").getData().phaseViewEditMode = false;
					this.getView().getModel("localModel").refresh(true);
				});
		},

		_uncheckBoxesAfterDeleteModeClosed: function () {
			let oTable = this.getView().byId('draftItemsTable');
			oTable.getAggregation("items").forEach((oItem) => {
				oItem.getAggregation("cells")[0].getAggregation("items")[0].setSelected();
			});
		},

		/*
		 * Handles delete logic for saved drafts
		 */
		_handleRemovalOfPhaseViewItems: function (oItem) {
			return new Promise((resolve, reject) => {
				// Item is a saved draft - delete on backend
				this._executeProperCrudOperationForItem(oItem).then(resolve, reject);
			});
		},

		/*============================== Favorites =========================*/

		_updateProject: function (resolve, reject, oProject) {
			const entities = {
				servicePath: Constants.getServicePath(),
				urlParameters: {
					"IsFavorite": this.bFavorite,
					"ProjectID": oProject.ProjectID
				},
				oContext: this,
				currentView: this.getView(),
				merge: false,
				updateMethod: "POST",
				busyIndicator: "busyIndicatorActivities",
				callbackSuccess: (oData) => {
					const oResult = oData ?? oProject;
					resolve(oResult);
				}
			};
			entities.function = "ChangeFavorite";
			this.callFunction(entities);
		},

		_updateService: function (resolve, reject, oService) {
			const entities = {
				servicePath: Constants.getServicePathWithoutLangParam(),
				entitySet: `ServiceItemSet(guid'${oService.ItemGuid}')`,
				data: {
					"IsFavorite": this.bFavorite
				},
				oContext: this,
				currentView: this.getView(),
				merge: false,
				updateMethod: "PATCH",
				busyIndicator: "busyIndicatorActivities",
				callbackSuccess: (oData) => {
					const oResult = oData ?? oService;
					resolve(oResult);
				}
			};
			this.updateBaseRequest(entities);
		},

		handleMakeItUnfavorite: function (oEvent) {
			this.bFavorite = false;
			if (this.getView().getModel("spdDetails").getProperty(oEvent.getSource().getBindingContext("spdDetails").sPath).ItemType) {
				this._toggleFavoriteService(oEvent);
			} else {
				this._toggleFavorite(oEvent);
			}
		},

		handleMakeItFavorite: function (oEvent) {
			this.bFavorite = true;
			if (this.getView().getModel("spdDetails").getProperty(oEvent.getSource().getBindingContext("spdDetails").sPath).ItemType) {
				this._toggleFavoriteService(oEvent);
			} else {
				this._toggleFavorite(oEvent);
			}
		},

		_toggleFavorite: function (oEvent) {
			this._oData.busyIndicatorActivities = true;
			this._oModel.refresh();

			const oSource = oEvent.getSource(),
				sPath = oSource.getBindingContext("TileCollection").getPath(),
				oProject = this.getView().getModel("TileCollection").getProperty(sPath),
				sText = this.bFavorite
					? this.getResourceBundle().getText("Home.AddedToFavorites")
					: this.getResourceBundle().getText("Home.RemovedFromFavorites");

			return new Promise((resolve, reject) => {
				this._updateProject(resolve, reject, oProject);
			}).then((oData) => {
				MessageToast.show(sText);

				this.getView().getModel("TileCollection").getProperty(sPath).IsFavorite = this.bFavorite;
				this.getView().getModel("TileCollection").refresh();

				this._oData.busyIndicatorActivities = false;
				this._oModel.refresh();
			});
		},

		_toggleFavoriteService: function (oEvent) {
			this._oData.busyIndicatorActivities = true;
			this._oModel.refresh();

			const oSource = oEvent.getSource(),
				sPath = oSource.getBindingContext("spdDetails").getPath(),
				oProject = this.getView().getModel("spdDetails").getProperty(sPath),
				sText = this.bFavorite
					? this.getResourceBundle().getText("Home.Favorite")
					: this.getResourceBundle().getText("Home.Unfavorite");

			this.getView().getModel("spdDetails").getProperty(sPath).IsFavorite = this.bFavorite;
			this.getView().getModel("spdDetails").refresh();
			return new Promise((resolve, reject) => {
				this._updateService(resolve, reject, oProject);
			}).then((oData) => {
				MessageToast.show(sText);
				this._oData.busyIndicatorActivities = false;
				this._oModel.refresh();
			});
		},

		// =======================================================================================================
		// =======================================================================================================
		// =====================================    Add List of Services   =================================
		// =======================================================================================================
		// =======================================================================================================

		/* open the dialog-popup for adding a List of Services to the service plan
		   Initialize the ""-path of the componentsModel, and bind it to the fragment */

		_loadAddServiceListDialogFragment: function () {
			this._pDialogAddServiceList ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.DialogAddServiceList");
			this._pDialogAddServiceList.then(oDialog => {
				this.getView().getModel("spdDetails").getData().newService = {};
				this.getView().getModel("spdDetails").getData().newService.Phase = "None";
				this.getView().getModel("spdDetails").getData().newService.Effort = "";
				oDialog.open();
				oDialog.bindElement("spdDetails>/newService");
			});
		},

		/* triggered, after Add List of Services Dialog is closed*/

		fnHandleCloseDialogAddServiceList: function (oEvent) {
			this.getView().getModel("componentsModel").getData().searchComponentsFilter = {};
			this.getView().getModel("componentsModel").getData().searchComponentsResults = [];
			this.getView().getModel("componentsModel").getData().searchComponentsNumberOfResults = 0;
			this.getView().getModel("componentsModel").refresh();
			// clean up
			this._pDialogAddServiceList?.then(oDialog => oDialog.destroy());
			this._pDialogAddServiceList = undefined;
		},

		/* triggered, when the user presses the Add to Plan button in Add List of Services Dialog */

		OnAddServiceListPress: function () {
			let aSelectedComponents = [];
			aSelectedComponents = this.getView().getModel("componentsModel").getData().searchComponentsFilter.ComponentID.filter(oComp =>
				oComp.bIsSelected === true
			);
			aSelectedComponents.forEach(oComp => {
				this._addComponentToPlan(oComp);
			});

			this.getView().getModel("componentsModel").getData().searchComponentsFilter = {};
			this.getView().getModel("componentsModel").getData().searchComponentsResults = [];
			this.getView().getModel("componentsModel").getData().searchComponentsNumberOfResults = 0;
			this.getView().getModel("componentsModel").refresh();

			this.onPhaseViewSave();

		},

		// =======================================================================================================
		// =======================================================================================================
		// =====================================    Add Focus Package Handling   =================================
		// =======================================================================================================
		// =======================================================================================================

		/**
		 * called when user has selected the entry to add a Package from the menu button "Add/Remove Services"
		 * 1st step to open the dialog-popup for adding Focus Package Components to the service plan:
		 * Loads the required fragment, in case it is not already there.
		 * Then calls the 2nd step		 *
		 */
		_loadAddFocusPackageDialogFragment: function (bOpen, sInitialView) {
			this._pDialogAddFocusPackage ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.FocusPackage.DialogAddFocusPackage");
			this._pDialogAddFocusPackage.then((oDialog) => {
				if (bOpen) oDialog.open();
				if (sInitialView === "selectFPComponents") this._navigateToAddFocusPackageSelectComponents();
				else this._navigateToAddFocusPackageSearch();

			});
		},

		/**
		 * Event Handler is triggered, when the user performs search for Focus Packages
		 * Remark: as search base the model content "focusPackages/allPackages" is used - which has been populated from SSC on SPD startup
		 */
		onFocusPackageSearchLocal: function () {
			let sFilterFPId = this.getView().getModel("focusPackages").getData().searchPackagesFilter.FPId;
			let sFilterFPDescription = this.getView().getModel("focusPackages").getData().searchPackagesFilter.FPDescription;
			// Search with only one field in all fields: let aSearchedInALLObjectProperties = this.getView().getModel("focusPackages").getData().allPackages.filter(obj => Object.values(obj).some(val => val.includes(sFilterFPDescription)));

			this.getView().getModel("focusPackages").getData().searchPackagesResults = this.getView().getModel("focusPackages").getData().allPackages
				.filter(() => true);
			if (sFilterFPId) {
				this.getView().getModel("focusPackages").getData().searchPackagesResults = this.getView().getModel("focusPackages").getData().searchPackagesResults
					.filter(obj => obj.serviceNumber.toUpperCase().includes(sFilterFPId.toUpperCase()));
			}
			if (sFilterFPDescription) {
				this.getView().getModel("focusPackages").getData().searchPackagesResults = this.getView().getModel("focusPackages").getData().searchPackagesResults
					.filter((obj) => {
						if (obj.summary) {
							return obj?.nameFormatted?.toUpperCase().includes(sFilterFPDescription.toUpperCase()) || obj.summary.toUpperCase().includes(
								sFilterFPDescription.toUpperCase());
						} else {
							return obj?.nameFormatted?.toUpperCase().includes(sFilterFPDescription.toUpperCase());
						}
					});
			}

			this.getView().getModel("focusPackages").getData().searchPackagesNumberOfResults = this.getView().getModel("focusPackages").getData()
				.searchPackagesResults
				.length;
			this.getView().getModel("focusPackages").refresh();
		},

		/**
		 * Event Handler triggered when user selects a Focus Package in the AddFocusPackage-Dialog.
		 * Further information about the contained components is loaded, then
		 * navigation to "Add Focus Package - Select Components" Screen is triggered
		 */
		onFocusPackageSelected: function (oEvent) {
			let oFocusPackageSelected = {};
			if (oEvent) {
				oFocusPackageSelected = this.getView().getModel("focusPackages").getProperty(oEvent.getParameters("listItem").listItem.getBindingContextPath());
			} else {
				oFocusPackageSelected = this.getView().getModel("focusPackages").getProperty("/searchPackagesResults/0");
			}
			this.getView().getModel("focusPackages").getData().selectedPackage = oFocusPackageSelected;

			this._pGetFocusPackageComponentsFromSSC(oFocusPackageSelected.code).then((aFPComponents) => {
				let aPromisesAddPhase = [];
				aFPComponents.forEach((oFPComponent) => {
					aPromisesAddPhase.push(this._pGetComponentFirstPhaseFromSSC(oFPComponent.code).then((sCompPhaseSSC) => {
						oFPComponent.firstPhase = this._determineCRMPhaseIDBasedOnSSCPhaseID(sCompPhaseSSC);
					}));
				});
				Promise.all(aPromisesAddPhase).then(() => {
					aFPComponents.forEach((oFPComp) => {
						const res = this._oFPCompHandler(oFPComp);
						oFPComp = res.oFPComp;
						let aComponentsFromPlan = res.aComponentsFromPlan;
						oFPComp.sLinkText = this._focusPackageLinkBuilder(oFPComp, aComponentsFromPlan);
					});

					aFPComponents.sort((a, b) => (a.firstPhase > b.firstPhase) ? 1 : -1);
					this.getView().getModel("focusPackages").getData().selectedPackage.FPComponents = aFPComponents;
					this.getView().getModel("focusPackages").getData().selectedPackage.numberOfComponents = aFPComponents.length;
					this.onFPComponentSelectionChange();
					this.getView().getModel("focusPackages").refresh();
				});
			});
			this._navigateToAddFocusPackageSelectComponents();
		},

		_oFPCompHandler: function (oFPComp) {
			let aComponentsFromPlan = [];
			oFPComp.name = oFPComp.name.length > 40 ? oFPComp.name.slice(0, 38) + ".." : oFPComp.name;
			aComponentsFromPlan = this._getComponentsFromPlanWithGivenId(oFPComp.code);
			oFPComp.scEffortEstimate = Number(oFPComp.scEffortEstimate); // otherwise sorting is not working
			// if FPcomponent is also a CRMcomponent and this component is not currently in the plan, mark it selected
			oFPComp.bIsSelected = Boolean(this.getView().getModel("componentsModel").getData().allCRMComponents.find(oCRMComp =>
				oCRMComp.ComponentID ===
				oFPComp.code)) && aComponentsFromPlan.length === 0;
			// if Project type is "Operations" Phase has to be set to "Run"
			if (this.getView().getModel("spdDetails").getData().isOperationsProject) {
				oFPComp.firstPhase = "WTF_05";
			}
			return {oFPComp, aComponentsFromPlan};
		},

		_focusPackageLinkBuilder: function (oFPComp, aComponentsFromPlan) {
			if (aComponentsFromPlan.length > 0) {
				// only use the first component from the array for building the link...
				oFPComp.sSpdDetailsModelItemBindingPath = aComponentsFromPlan[0].sSpdDetailsModelItemBindingPath;
				switch (aComponentsFromPlan[0].ItemType) {
				case "ZSR1": //Service Request
					oFPComp.sLinkText = "SR " + aComponentsFromPlan[0].TransactionID;
					if (aComponentsFromPlan.length > 1) {
						oFPComp.sLinkText = oFPComp.sLinkText + "...";
					}
					break;
				case "ZSK1": //Service Order
					oFPComp.sLinkText = "SO " + aComponentsFromPlan[0].TransactionID;
					if (aComponentsFromPlan.length > 1) {
						oFPComp.sLinkText = oFPComp.sLinkText + "...";
					}
					break;
				case "YSP1": //Proposal
					oFPComp.sLinkText = "Proposal Item";
					if (aComponentsFromPlan.length > 1) {
						oFPComp.sLinkText = oFPComp.sLinkText + "...";
					}
				}
			}
			return oFPComp.sLinkText;
		},

		/**
		 * get the service components of a Focus Package or Business Scenario from SSC
		 */
		_pGetFocusPackageComponentsFromSSC: function (sFocusPackageId) {
			return new Promise((resolve, reject) => {
				if (sFocusPackageId) {
					let entities = {};
					entities.url = 	Constants.getSSCItem() + sFocusPackageId + Constants.getSSCFPItems();
					entities.currentView = this.getView();
					entities.oContext = this;
					entities.callbackSuccess = (oData) => {
						resolve(oData.d.results);
					};
					this.readBaseRequestRest(entities);
				} else {
					reject(new Error("Could not load Focus Package Components"));
				}
			});
		},

		/**
		 * get the first of the phases of a Component from SSC
		 * (In case it belongs to several phases, return the first one)
		 * @param {string} sComponentId - Component ID
		 *
		 * @return {Promise} Promise that will resolve with an object of component properties
		 */
		_pGetComponentFirstPhaseFromSSC: function (sComponentId) {
			return new Promise((resolve, reject) => {
				let entities = {};
				entities.url = Constants.getSSCItem() +	sComponentId + Constants.getSSCFPComponentPhases();
				entities.currentView = this.getView();
				entities.oContext = this;
				entities.ignoreErrors = true;
				entities.callbackSuccess = (oData) => {
					if (oData.d.results[0]) {
						resolve(oData.d.results[0].value);
					} else {
						resolve();
					}
				};
				entities.callbackError = (oErr) => {
					reject(oErr);
				};

				this.readBaseRequestRest(entities);
			});
		},

		/**
		 * returns the components with the given ID from the SPD Service Plan
		 * @param {string} sCompId - Component ID
		 *
		 * @return {Array} - Components from SPD Plan with provided component ID
		 */
		_getComponentsFromPlanWithGivenId: function (sCompId) {
			let aComponentsFromPlan = [];
			let iPhase = 0;
			let iItem = 0;

			this.getView().getModel("spdDetails").getData().phases.forEach((oPhase) => {
				oPhase.items.forEach((oPhaseItem) => {
					if (oPhaseItem.ComponentID === sCompId) {
						oPhaseItem.sSpdDetailsModelItemBindingPath = "/phases/" + iPhase + "/items/" + iItem;
						aComponentsFromPlan.push(oPhaseItem);
					}
					iItem = iItem + 1;
				});
				iPhase = iPhase + 1;
				iItem = 0;
			});
			return aComponentsFromPlan;
		},

		onFPComponentUpdateFinished: function (oEvent) {
			this._FPComponentsSelectionDisableUnuseableComponents();
		},

		_FPComponentsSelectionDisableUnuseableComponents: function () {
			let oTable = this.byId("tableSelectFocusPackageComponentsId");
			if (oTable) {
				oTable.getItems().forEach(function (oItem) {
					let sFPComponentNumber = oItem.getBindingContext("focusPackages").getModel().getProperty(oItem.getBindingContextPath()).code;
					if (this.getView().getModel("componentsModel").getData().allCRMComponents.find(oCRMComp => oCRMComp.ComponentID ===
							sFPComponentNumber)) {
						oItem.setUseable(true);
						if (oItem.getMultiSelectControl()) {
							oItem.getMultiSelectControl().setVisible(true);
						}
					} else {
						oItem.setUseable(false);
						if (oItem.getMultiSelectControl()) {
							oItem.getMultiSelectControl().setVisible(false);
						}
					}
				}, this);
				oTable.updateSelectAllCheckbox();
			}
		},
		/**
		 *
		 */
		onFPComponentSelectionChange: function (oEvent) {
			// in case "selectAll" was used, take care the disabled FPComponents are not selected
			if (oEvent?.getParameter("selectAll") && oEvent?.getParameter("selected")) {
				this.getView().getModel("focusPackages").getData().selectedPackage.FPComponents.forEach(oFPComp => {
					if (!this.getView().getModel("componentsModel").getData().allCRMComponents.find(oCRMComp => oCRMComp.ComponentID ===
							oFPComp.code)) {
						oFPComp.bIsSelected = false;
					}
				});
			}
			// find out how many components are selected now
			let aSelectedComponents = [];
			aSelectedComponents = this.getView().getModel("focusPackages").getData().selectedPackage.FPComponents.filter(oComp =>
				oComp.bIsSelected === true
			);
			this.getView().getModel("focusPackages").getData().selectedPackage.numberOfSelectedComponents = aSelectedComponents.length;
			this._FPComponentsSelectionDisableUnuseableComponents();
		},

		/**
		 * Opens a Popover to display details about where the component is already used as an
		 * SPD Item..
		 * it first creates a promise to loads the relevant fragment, if this promises does not
		 * already exist (The resolved promise returns then the Popover-Object.)
		 * When the promise is resolved (either the freshly created promise or from before) it
		 * does the data binding to show the infos from component the user clicked on
		 * @param {object} oEvent - Data from the event
		 * @param {object} isServiceComponent - true, if triggered from DialogAddServiceList, false if triggered from
		 */
		openPopoverSPDItemQuickView: function (oEvent, isServiceComponent) {
			// get the corresponding component from the spdDetails-Model that we want to show
			let oLinkClicked = oEvent.getSource(),
				oSPDComponentToShow;
			let oView = this.getView();
			if (isServiceComponent) {
				// called from DialogAddServiceList
				let oFPComponentClicked = oView.getModel("componentsModel").getProperty(oEvent.getSource().getParent().getBindingContextPath());
				oSPDComponentToShow = this._getComponentsFromPlanWithGivenId(oFPComponentClicked.ComponentID)[0];
			} else {
				// called from TableSelectFocusPackageComponents
				let oFPComponentClicked = this.getView().getModel("focusPackages").getProperty(oEvent.getSource().getParent().getBindingContextPath());
				oSPDComponentToShow = this._getComponentsFromPlanWithGivenId(oFPComponentClicked.code)[0];
			}

			// create the Popover
			this._pComponentQuickViewPopover ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.FocusPackage.PopoverSPDItemQuickView");
			this._pComponentQuickViewPopover?.then(oPopover => {
				oPopover.bindObject({
					path: "spdDetails>" + oSPDComponentToShow.sSpdDetailsModelItemBindingPath
				});
				oPopover.openBy(oLinkClicked);
			});
		},

		/**
		 * Navigate to 'Add Focus Package - Select Components' screen
		 */
		_navigateToAddFocusPackageSelectComponents: function () {
			this.getView().getModel("focusPackages").getData().titleAddFocusPackageDialog = this.getResourceBundle().getText(
				"SPDDetails.AddFocusPackage.Title.SelectComponents");
			this.getView().getModel("focusPackages").refresh();

			let oNavCon = this.getView().byId("navContainerAddFocusPackage"),
				oDetailPage = this.getView().byId("selectFPComponents");
			if (oNavCon) {
				oNavCon.to(oDetailPage);
				this._pDialogAddFocusPackage.then(oDialog => {
					if (!oDialog.isOpen()) oDialog.open()
				});
			}
		},

		/**
		 * Event Handler triggered when user clicks button to change the Focus Package in the Add Focus Package Select Components Dialog.
		 * Navigation to FP-Component-Search-Screen is triggered
		 */
		onFocusPackageChange: function () {
			let that = this;
			MessageBox.warning(this.getResourceBundle().getText("SPDDetails.AddFocusPackage.WarningWhenChangeFocusPackage"), {
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function (sAction) {
					if (sAction === MessageBox.Action.OK) {
						that.getView().getModel("focusPackages").getData().selectedPackage = {};
						that.getView().getModel("focusPackages").getData().selectedPackage.numberOfSelectedComponents = 0;
						that.getView().getModel("focusPackages").refresh();
						that._navigateToAddFocusPackageSearch();
					}
				}
			});

		},

		/**
		 * Navigate to "Add Focus Package - Search" screen
		 */
		_navigateToAddFocusPackageSearch: function () {
			this.getView().getModel("focusPackages").getData().titleAddFocusPackageDialog = this.getResourceBundle().getText(
				"SPDDetails.AddFocusPackage.Title.Search");
			this.getView().getModel("focusPackages").refresh();

			let oNavCon = this.getView().byId("navContainerAddFocusPackage"),
				oDetailPage = this.getView().byId("searchFP");
			oNavCon.to(oDetailPage);
		},

		/**
		 * Event Handler triggered when user presses Cancel-button in AddFocusPackage Dialog.
		 * Closes the Dialog and cleans up some values
		 */
		fnHandleCloseDialogAddFocusPackage: function () {
			this.getView().getModel("focusPackages").getData().searchPackagesFilter = {};
			this.getView().getModel("focusPackages").getData().searchPackagesResults = [];
			this.getView().getModel("focusPackages").getData().selectedPackage = {};
			this.getView().getModel("focusPackages").getData().searchPackagesNumberOfResults = 0;
			this.getView().getModel("focusPackages").refresh();
			this._pDialogAddFocusPackage.then(oDialog => oDialog.destroy());
			this._pDialogAddFocusPackage = undefined;
		},

		/**
		 * Event Handler triggered when user presses "Add To Plan"-button in AddFocusPackage Dialog.
		 * Closes the Dialog and cleans up some values
		 */
		onAddToPlanInAddFocusPackageDialog: function () {
			this.getView().getModel("localModel").getData().busyDraftPlanItems = true;
			this.getView().getModel("localModel").refresh();

			let aSelectedComponents = [];
			aSelectedComponents = this.getView().getModel("focusPackages").getData().selectedPackage.FPComponents.filter(oComp =>
				oComp.bIsSelected === true
			);
			aSelectedComponents.forEach(oComp => {
				this._addComponentToPlan(oComp);
			});
			this._pDialogAddFocusPackage.then(oDialog => oDialog.close());
			this._addPackageSelected = true;
			this._showMessageComponentsAddedFromFP();
			this._packageImportSelected = !!(this._packageImportSelected && this.getView().getModel("focusPackages").getData().selectedPackage.code ===
				this._sImportPackageFromSSCId);

			this.getView().getModel("focusPackages").getData().searchPackagesFilter = {};
			this.getView().getModel("focusPackages").getData().searchPackagesResults = [];
			this.getView().getModel("focusPackages").getData().selectedPackage = {};
			this.getView().getModel("focusPackages").getData().searchPackagesNumberOfResults = 0;
			this.getView().getModel("focusPackages").refresh();

			this.onPhaseViewSave();

		},

		/**
		 * helper function to add one component to the Service Plan: put it at the top of the phase
		 * so the user easily sees it, give it the right color, etc..
		 * @param {object} oFPComponent - Focus Package component to be added to the plan
		 */
		_addComponentToPlan: function (oFPComponent) {
			let oComponent = {
				"ComponentID": oFPComponent.code,
				"ComponentDescr": oFPComponent.name === null ?
					"" : oFPComponent.name,
				"SpGuid": this.getModel("spdDetails").getData().Header.SpGuid,
				"ItemType": "YSP1",
				"ItemTypeText": "Template",
				"PhaseID": oFPComponent.firstPhase ? oFPComponent.firstPhase : "None",
				"Effort": oFPComponent.scEffortEstimate !== undefined ? oFPComponent.scEffortEstimate.toString() : "1.000",
				"ItemStatus": "DRAFT",
				"FlaggedForDeletion": false,
				"PackageCode": this.getView().getModel("focusPackages").getData().selectedPackage.code,
				"ItemStatusText": "Draft",
				"TbuiUrl": "",
				"SrsUrl": "",
				"ReleaseAllowed": false,
				"IsdHubUrl": "",
				"Type": "Draft"
			};
			oComponent.Colour = this._getSPDItemColour(oComponent);
			let oPhaseItemSelectedPhase = this.getView().getModel("spdDetails").getData().phases.find(oPhase => {
				return oPhase.DdlbKey === oComponent.PhaseID;
			});
			this._handleContractSituationOfSPDItem(oComponent);
			oPhaseItemSelectedPhase.items.unshift(oComponent);
			this.getView().getModel("spdDetails").getData().results.unshift(oComponent);
			this.getView().getModel("spdDetails").refresh();

		},

		/**
		 * helper function to show a message to the user, that components have been added to the plan and
		 * how many - or a warning that nothing could be added
		 */
		_showMessageComponentsAddedFromFP: function () {
			this.getView().getModel("localModel").getData().busySPDetails = false;
			this.getView().getModel("localModel").refresh();
			let oSelectedPackage = this.getView().getModel("focusPackages").getData().selectedPackage;
			this.messageHandler.clearAllMessages();
			if (oSelectedPackage.numberOfSelectedComponents !== 0) {
				this.messageHandler.addNewMessageseInsidePopover(
					null,
					"Success",
					this.getResourceBundle().getText("SPDDetails.Item.FP.Title.Success"),
					this.getResourceBundle().getText("SPDDetails.Item.FP.Description.Success", [oSelectedPackage.numberOfSelectedComponents,
						oSelectedPackage.name
					]));
			} else {
				this.messageHandler.addNewMessageseInsidePopover(
					null,
					"Warning",
					this.getResourceBundle().getText("SPDDetails.Item.FP.Title.Warning"),
					this.getResourceBundle().getText("SPDDetails.Item.FP.Description.Warning", [oSelectedPackage.name]));
			}
		},

		//******************************************************************************************
		//******************************************************************************************
		//*******************  Import Package From SSC handling *****************************************
		//******************************************************************************************
		//******************************************************************************************
		_importPackageFromSSC: function () {
			this._packageImportSelected = true;
			this._loadAddFocusPackageDialogFragment(false, "selectFPComponents");
			this.getView().getModel("focusPackages").getData().searchPackagesFilter.FPId = this._sImportPackageFromSSCId;
			this.onFocusPackageSearchLocal();
			this.onFocusPackageSelected();
		},

		/**
		 * Association between phases: CRM and SSC
		 * Discover - CRM id: WTF_00 - SSC id: 1002
		 * Prepare  - CRM id: WTF_01 - SSC id: 1110
		 * Explore  - CRM id: WTF_02 - SSC id: 1111
		 * Realize  - CRM id: WTF_03 - SSC id: 1003
		 * Deploy   - CRM id: WTF_04 - SSC id: 1004
		 * Run      - CRM id: WTF_05 - SSC id: 1005
		 *
		 * @param {string} SSCPhaseID - the Phase ID from SSC
		 * @return {string} CRMPhaseID - the Phase ID in CRMs
		 *
		 */
		_determineCRMPhaseIDBasedOnSSCPhaseID: function (SSCPhaseID) {
			let CRMPhaseID = "";
			if (SSCPhaseID === "1002") {
				CRMPhaseID = "WTF_00";
			}
			if (SSCPhaseID === "1110") {
				CRMPhaseID = "WTF_01";
			}
			if (SSCPhaseID === "1111") {
				CRMPhaseID = "WTF_02";
			}
			if (SSCPhaseID === "1003") {
				CRMPhaseID = "WTF_03";
			}
			if (SSCPhaseID === "1004") {
				CRMPhaseID = "WTF_04";
			}
			if (SSCPhaseID === "1005") {
				CRMPhaseID = "WTF_05";
			}
			return CRMPhaseID;
		},

		// ================================== SPD Item Create ===============================

		_onAddServiceToUI: function (oContext, oItem) {
			oContext = oContext || this;
			oContext._addServiceSelected = true;
			oContext.getView().getModel("localModel").getData().busyAddService = true;
			oContext.getView().getModel("localModel").refresh();

			let oNewService = oContext.getView().getModel("spdDetails").getData().newService;
			let oComponent = {
				"SpGuid": oContext.getModel("spdDetails").getData().Header.SpGuid,
				"ItemTypeText": "Template",
				"ItemType": "YSP1",
				"ComponentID": oNewService.ComponentID,
				"ComponentDescr": oNewService.ComponentDescr,
				"ComponentDescrAlternative": oNewService.ComponentDescrAlternative,
				"EffortTotal": oContext.getView().byId("srvEffort").getValue().toString(),
				"PhaseID": oContext.getView().byId("srvPhase").getSelectedKey(),
				"Phase": oNewService.Phase === undefined ? 'None' : oNewService.Phase,
				"Effort": oContext.getView().byId("srvEffort").getValue().toString(),
				"ItemStatus": "DRAFT",
				"ItemStatusText": "Draft",
				"TbuiUrl": "",
				"SrsUrl": "",
				"ReleaseAllowed": false,
				"IsdHubUrl": "",
				"Type": "Draft",
				"FlaggedForDeletion": false,
				"StartDate": oNewService.StartDate,
				"EndDate": oNewService.EndDate,
				"isExpanded": oContext.getView().getModel("localModel").getData().expandedMode,
				"showWarningNoValidContract": oNewService.showWarningNoValidContract
			};
			oComponent.Colour = oContext._getSPDItemColour(oComponent);

			let oPhaseItemSelectedPhase = oContext.getView().getModel("spdDetails").getData().phases.find(oPhase => {
				if (!oComponent.PhaseID) return oPhase.DdlbKey === oComponent.Phase;
				else return oPhase.DdlbKey === oComponent.PhaseID;
			});

			oNewService.Phase = oPhaseItemSelectedPhase.Value;
			oContext.getView().getModel("spdDetails").getData().results.unshift(oComponent);
			oPhaseItemSelectedPhase.items.unshift(oComponent);
			oContext.getView().getModel("spdDetails").refresh(true);

			oContext._handleSuccesCreatedSPDService();
		},

		_getSPDItemCreationPayload: function () {
			let oNewService = this.getView().getModel("spdDetails").getData().newService;
			let oPayload = {
				"SpGuid": this.getModel("spdDetails").getData().Header.SpGuid,
				"ItemType": "YSP1",
				"ComponentID": oNewService.ComponentID,
				"ComponentDescr": this._createCompDesc(oNewService),
				"ComponentDescrAlternative": oNewService.ComponentDescrAlternative,
				"PhaseID": oNewService.PhaseID === "None" ? "" : oNewService.PhaseID,
				"Effort": oNewService.Effort ? (oNewService.Effort).toString() : "0",
				"ItemStatus": "DRAFT",
				"PackageCode": oNewService.PackageCode
			};
			if (oNewService.StartDate) {
				oPayload.StartDate = oNewService.StartDate;
			}
			if (oNewService.EndDate) {
				oPayload.EndDate = oNewService.EndDate ? new Date(oNewService.EndDate.setHours(23, 59, 59, 0)) : oNewService.EndDate;
			}
			return oPayload;
		},

		_onCreateService: function (resolve) {
			this.getView().getModel("localModel").getData().busyAddService = true;
			this.getView().getModel("localModel").refresh();
			let entities = {};
			entities.servicePath = Constants.getServicePathSPD();
			entities.entitySet = "ServicePlanItemSet";
			entities.data = this._getSPDItemCreationPayload();
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.busyIndicator = ["busySPDetails", "busyAddService"];
			entities.callbackSuccess = (oData) => {
				this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "DraftPlanIsUpdated", this);
				resolve();
			};
			this.createBaseRequest(entities);
		},

		_handleSuccesCreatedSPDService: function (oData) {
			this.getView().getModel("localModel").getData().busyAddService = false;
			this.getView().getModel("localModel").refresh();

			this._pDialogAddItem?.then(oDialog => oDialog.destroy());
			this._pDialogAddItem = undefined;

			this.getView().getModel("spdDetails").getData().newService = {};
			this.getView().getModel("spdDetails").getData().newService.Phase = "None";
			this.getView().getModel("spdDetails").getData().newService.Effort = 1;
			this.getView().getModel("spdDetails").refresh();
		},

		// ============================= Field Validations ==========================
		/*
            Triggers a recalcutation of available Phases if user clears the StartDate.
            Using Validation Hook from DatePicker, since normal change events only work for changing dates.
            */
		handleStartDateCleaning: function (oEvent) {
			let value = oEvent.getSource().getValue(),
				allPhases = this.getView().getModel("gridListModel").getData().allPhases;
			if (value === "") {
				this.getView().byId("srvPhase").setSelectedKey("None");
				allPhases.forEach((element, index) => {
					allPhases[index] = true;
				});
				this.getView().getModel("gridListModel").refresh(true);
				this.getView().byId("srvPhase").setEnabled(true);
			}
		},

		/*
		Removes the EndDate in FormMaintainSPDItem if the StartDate was deleted by user.
		In case the StartDate is not empty, calculates delta between new and old value and moves
		the date in EndTime date-picker to a corresponding delta.
		oEvent is the DateTime Picker object from the StartDate
		*/
		fnHandleStartEndDateCoupling: function (oEvent, bIsTTE) {
			let oEndDate,
				currentEndDate,
				oPreviousDate = this.getView().getModel("localModel").getData().sCurrentStartDate,
				oRawDate = oEvent.getSource().getDateValue().setHours(0, 0, 0, 0),
				oNewDate = Date.parse(oEvent.getSource().getDateValue()),
				newEndTimestamp,
				newEndDate,
				sDeltaTime,
				phaseIndex,
				phasesWithDates = [],
				counter = 0,
				oData = this.getView().getModel("spdDetails").getData().phases;

				oData.forEach(oItems => {
				if (oItems.StartDate instanceof Date && oItems.EndDate instanceof Date) {
					phasesWithDates.push(true);
					counter++;
					if (oRawDate >= oItems.StartDate.setHours(0, 0, 0, 0) && oRawDate <= oItems.EndDate.setHours(0, 0, 0, 0)) {
						phaseIndex = oData.indexOf(oItems);
					}
				} else {
					phasesWithDates.push(false);
				}
			});

			if (phaseIndex) {
				phasesWithDates = this._handlePhasesWithDates(phasesWithDates, phaseIndex, oEvent);
			} else {
				phasesWithDates = this._handlePhasesWithoutDates(phasesWithDates, oEvent);
			}
			this.getView().getModel("gridListModel").refresh(true);
			switch (!bIsTTE) {
				case true:
					// called from FormMaintainSPDItem
					oEndDate = this.getView().byId("srvEndDate");
					// set low boundary for EndDate to StartDate
					let oMinDate = new Date(oNewDate);
					oEndDate.setMinDate(oMinDate);
					if (oEndDate.getValue() !== "") {
						currentEndDate = Date.parse(oEndDate.getDateValue().toUTCString());
						// have to calculate new End Date in advance to decide whether the Save button should be enabled
						sDeltaTime = (oNewDate - oPreviousDate);
					}
					// called to check whether the Save/Request Delivery buttons should be enabled
					this.handleEndDate(oEndDate.getDateValue(), oNewDate, sDeltaTime);
					break;
				case false:
					// called from TableTTEList
					oEndDate = oEvent.getSource().getParent().getAggregation("cells")[3];
					if (oEndDate.getValue() !== "") {
						currentEndDate = Date.parse(oEndDate.getDateValue());
					}
					break;
				default:
					break;
			}
			this._handleStartEndDateInterval(oEvent, oEndDate, oPreviousDate, currentEndDate, oNewDate, newEndTimestamp, newEndDate);
		},

		_handlePhasesWithDates: function (phasesWithDates, phaseIndex, oEvent) {
			const aPhases = this.getView().getModel("filterModel").getData().phases;
			phasesWithDates.forEach(function (oItems, i) {
				this.getView().getModel("gridListModel").getData().allPhases[i] = i === phaseIndex;
			}, this);
			if (oEvent.getSource().sParentAggregationName === "fields") {
				this.getView().byId("srvPhase").setSelectedKey(aPhases[phaseIndex].Value);
				this.getView().byId("srvPhase").setEnabled(false);
			} else if (oEvent.getSource().sParentAggregationName === "cells") {
				this.getView().getModel("spdDetails").getData().TTEItems[0].PhaseText = aPhases[phaseIndex].Value;
			}
			return phasesWithDates;
		},

		_handlePhasesWithoutDates: function (phasesWithDates, oEvent) {
			phasesWithDates.forEach(function (oItems, i) {
				this.getView().getModel("gridListModel").getData().allPhases[i] = !phasesWithDates[i];
			}, this);
			if (oEvent.getSource().sParentAggregationName === "fields") {
				if (counter !== 0) {
					this.getView().byId("srvPhase").setSelectedKey("None");
					this.getView().byId("srvPhase").setEnabled(true);
				}
				if (counter === 6) {
					this.getView().byId("srvPhase").setEnabled(false);
				}
			} else if (oEvent.getSource().sParentAggregationName === "cells") {
				this.getView().getModel("spdDetails").getData().TTEItems[0].PhaseText = "";
			}
			return phasesWithDates;
		},

		_handleStartEndDateInterval: function (oEvent, oEndDate, oPreviousDate, currentEndDate, oNewDate, newEndTimestamp, newEndDate) {
			if (!oEvent.getParameter("newValue")) {
				// StartDate is empty
				oEndDate.setValue("");
			} else if (!oEndDate.getValue()) {
				// EndDate is not set, set the StartDate Value State to "None", since it is valid
				oEvent.getSource().setValueState("None");
			} else if (oPreviousDate > currentEndDate || !oPreviousDate) {
				// StartDate is set later than EndDate, but new set StartDate is valid
				// Reset the Error valueState for EndDate

				oEvent.getSource().setValueState("None");
				if (oNewDate <= currentEndDate) {
					if (oEndDate.getValueState() === "Error") {
						oEndDate.setValueState("None");
					}
				} else {
					// Start date is set later tnan End date -> do nothing
					oEvent.getSource().setValueState("Error");
					oEndDate.setMinDate(null);
				}
			} else {
				// calculate and set new EndDate value
				let deltaTime = (oNewDate - oPreviousDate);
				newEndTimestamp = currentEndDate + deltaTime;
				newEndDate = new Date(newEndTimestamp);
				oEndDate.setDateValue(newEndDate);
				// set the StartDate Value State to "None", since EndDate is valid
				oEvent.getSource().setValueState("None");
				// set Value state of EndDate to "None" if was on "Error" before
				if (oEndDate.getValueState() === "Error") {
					oEndDate.setValueState("None");
				}
			}

		},

		/*
		Displays a warning and disables save if EndDate is earlier than StartDate
		@oEvent - Date object from the EndDate control
		@oNewStartDate - new Start date, only used in case the call is coming from the
		@sDeltaTime - delta between new and old start date. Is needed, if handleEndDate is triggered by start date
		since we have to calculate the new End Date ad hoc to check for validity
		fnHandleStartEndDateCoupling function. Used to enable the Save button if dates are valid again.
		*/
		handleEndDate: function (oEvent, oNewStartDate, sDeltaTime) {
			let oCurrentStartDate, oNewEndDate;
			if (oNewStartDate) {
				oCurrentStartDate = oNewStartDate;
			} else {
				oCurrentStartDate = this.getView().getModel("localModel").getData().sCurrentStartDate;
			}
			if (oEvent) {
				oNewEndDate = Date.parse(oEvent.toUTCString());
			}
			if (sDeltaTime) {
				// handles the requests which are triggered by the start date
				if (oNewEndDate < oCurrentStartDate && (oNewEndDate + sDeltaTime) < oCurrentStartDate) {
					// checks if current End Date as well as End Date after supposed change is earlier then Start Date ==> invalid
					this.getView().byId("srvEndDate").setValueState(sap.ui.core.ValueState.Error);
					this.getView().byId("srvEndDate").setValueStateText(
						this.getResourceBundle().getText("SPDDetails.PhaseView.FieldValidations.EndDateTooLow"));
					this.getView().getModel("localModel").getData().saveRequestDeliveryEnabled = false;
					this.getView().getModel("localModel").getData().saveButtonEnabled = false;
					this.getView().getModel("localModel").refresh();
				} else {
					this.getView().byId("srvEndDate").setValueState(sap.ui.core.ValueState.None);
					this.getView().getModel("localModel").getData().saveRequestDeliveryEnabled = true;
					this.getView().getModel("localModel").getData().saveButtonEnabled = true;
					this.getView().getModel("localModel").refresh();
				}
			} else if (oNewEndDate < oCurrentStartDate) {
				this.getView().byId("srvEndDate").setValueState(sap.ui.core.ValueState.Error);
				this.getView().byId("srvEndDate").setValueStateText(
					this.getResourceBundle().getText("SPDDetails.PhaseView.FieldValidations.EndDateTooLow"));
				this.getView().getModel("localModel").getData().saveRequestDeliveryEnabled = false;
				this.getView().getModel("localModel").getData().saveButtonEnabled = false;
				this.getView().getModel("localModel").refresh();
			} else {
				this.getView().byId("srvEndDate").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("srvStartDate").setValueState(sap.ui.core.ValueState.None);
				this.getView().getModel("localModel").getData().saveRequestDeliveryEnabled = true;
				this.getView().getModel("localModel").getData().saveButtonEnabled = true;
				this.getView().getModel("localModel").refresh();
			}
		},

		/*
		Since DatePicker does not maintains the previous date in a change event, date is saved
		in a navigate event to the local model (sCurrentStartDate), so that delta between two dates
		can be calculated later in function hadleStartDateCoupling.
		Function is called by StartDate and EndDate, since EndDate makes checks to prevent being set to a date < StartDate.
		EndDate also saves the current value for setting it back in case it is set earlier then StartDate by user.
		Function is called by DatePickers in in FormMaintainSPDItem and TableTTEList fragments, since the logic is very similar
		StartDate is passed only by calls from EndDate picker
		*/
		saveCurrentDate: function (oDate, bIsStartDate, bIsTTE, startDate) {

			if (bIsTTE) {
				this.getView().getModel('localModel').getData().sCurrentStartDate = Date.parse(oDate);
				if (!bIsStartDate) {
					this.getView().getModel('localModel').getData().sCurrentEndDate = Date.parse(oDate);
				}
				// in TableTTEList.fragment.xml
			} else {
				this.getView().getModel('localModel').getData().sCurrentStartDate = bIsStartDate ? Date.parse(oDate) : Date.parse(startDate);
				if (!bIsStartDate) {
					this.getView().getModel('localModel').getData().sCurrentEndDate = Date.parse(oDate);
				}
				// in FormMaintainSPDItem.fragment.xml
			}
		},

		// ============================ Page Actions =================

		onListViewExport: function () {
			this._onDownload(false);
		},

		navToHome: function () {
			this.getRouter().navTo("Home");

		},

		onNavToEngagementDetails: function (oEvent) {
			this.getRouter().navTo("EngagementDetails", {
				engagementID: this.getView().getModel("spdDetails").getData().CaseDetails.ParentCaseID
			});
		},

		onNavToProjectDetails: function (oEvent) {
			this.getRouter().navTo("ProjectDetails", {
				projectID: this.getView().getModel("spdDetails").getData().Header.CaseID
			});
		},

		onSPDDetailsFilterPressed1: function () {
			this.getView().getModel("filterModel").getData().status2 = this.getView().getModel("spdDetails").getData().headerStatus;
			this.getView().getModel("filterModel").getData().componentStatuses = this.getView().getModel("spdDetails").getData().componentStatuses;
			this.getView().getModel("filterModel").refresh();
			let oView = this.getView();
			let oThis = this;
			FilterHelper.getViewSettingsDialog(
					"com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.DialogPhaseFilter", this, this._mViewSettingsDialogs)
				.then(function (oViewSettingsDialog) {
					if (oView.byId("filterDialog1"))
						oView.byId("filterDialog1").clearFilters();
					if (oThis.oPhaseViewFilterStore) {
						oView.byId("filterDialog1").getFilterItems().forEach(entry => {
							oThis._spdDetailsFilterHelper(entry, oThis)
						});
					}
					oViewSettingsDialog.open();
				});
		},

		_spdDetailsFilterHelper: function (entry, oThis) {
			if (entry?.getCustomControl?.()?.getValue)
				oThis.lastFilters.push(entry.getCustomControl().getValue());
			if (oThis.oPhaseViewFilterStore[entry.getProperty("text")] || oThis.oPhaseViewFilterStore[entry.getProperty("key")]) {
				if (entry.getCustomControl !== undefined) {
					entry.setFilterCount(1);
					entry.getCustomControl().setValue(this.oPhaseViewFilterStore[entry.getProperty("key")][0]);
					oThis.lastFilters.pop();
					oThis.lastFilters.push(entry.getCustomControl().getValue());

				} else {
					entry.getItems().forEach(item => {
						if (oThis.oPhaseViewFilterStore[entry.getProperty("text")].includes(item.getProperty("key"))) {
							item.setSelected(true);
						}
					});
				}
			}
			return entry;
		},

		onListViewFilterPhaseSelectionChange: function (oEvent) {
			this.getView().getModel("spdDetails").getData().items =
				this.getView().getModel("spdDetails").getData().initialItems;

			let aSelectedPhases = [];
			oEvent.getSource().getSelectedItems().forEach(phaseItem => {
				aSelectedPhases.push(phaseItem.getText());
			});
			let aItems = this.getView().getModel("spdDetails").getData().items;

			if (aSelectedPhases.length) {
				this.getView().getModel("spdDetails").getData().items =
					aItems.filter(oItem =>
						aSelectedPhases.includes(oItem.Phase));
			}

			this.getView().getModel("spdDetails").refresh();
		},

		fnShowEmployeeRespDetails: function (oEvent) {
			this.employeeDetails.displayEmployeePopover(oEvent, this.getView(), "spdDetails", "CreatedBy");
		},

		/* =============================== Message Headlling ================================ */

		handleMessagePopoverPress: function (oEvent) {
			this.oMessagePopover.toggle(oEvent.getSource());
		},

		handleClearAllMessages: function () {
			this.messageHandler.clearAllMessages();
		},

		/* ================================== SPD Header ==================================== */

		onGeneralInformationViewSwitchToEditMode: function () {
			this.getView().getModel("localModel").getData().generalInformationViewEditMode = true;
			this.getView().getModel("localModel").refresh();
		},

		onGeneralInformationViewSave: function () {
			this.onUpdateSPDHeader();
		},

		onGeneralInformationViewSwitchToDisplayMode: function () {
			this.getView().getModel("localModel").getData().generalInformationViewEditMode = false;
			this.getView().getModel("localModel").refresh();
		},

		onUpdateSPDHeader: function () {
			this.getView().getModel("localModel").getData().busySPDGeneralInformation = true;
			this.getView().getModel("localModel").refresh();
			let entities = {},
				dataForUpdate = {
					"Name": this.getView().getModel("spdDetails").getData().Header.Name,
					"Description": this.getView().getModel("spdDetails").getData().Header.Description
				};
			entities.servicePath = Constants.getServicePathSPD();
			entities.entitySet = "ServicePlanHeaderSet(guid'" +
				this.getView().getModel("spdDetails").getData().Header.SpGuid + "')";
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.data = dataForUpdate;
			entities.errorMessage = this.getResourceBundle().getText("ProjectSPD.Edit.Error");
			entities.busyIndicator = "busySPDGeneralInformation";
			entities.callbackSuccess = () => {
				this.onGeneralInformationViewSwitchToDisplayMode();
				this.getView().getModel("localModel").getData().busySPDGeneralInformation = false;
				this.getView().getModel("localModel").refresh();
			};
			this.updateBaseRequest(entities);
		},

		/* ================================== Phase View ========================================= */
		onPhaseViewSwitchToEditMode: function (oEvent) {
			if (oEvent !== undefined) {
				this._reArrangeSelected = true;
			}
			this.getView().getModel("localModel").getData().phaseViewEditMode = true;
			this.getView().getModel("localModel").getData().listViewEditMode = true;
			this.getView().getModel("localModel").refresh();
		},

		onPhaseViewSave: function () {
			this.onListViewSave();
		},

		onPhaseViewSwitchToDisplayMode: function () {
			if (this.getView().getModel("localModel").getData().sSelectedViewType === "phaseView") {
				this._readSPDItems();
			}
			this.getView().getModel("localModel").getData().listViewEditMode = false;
			this.getView().getModel("localModel").getData().phaseViewEditMode = false;
			this.getView().getModel("localModel").getData().phaseViewRemoveMode = false;
			this.getView().getModel("spdDetails").getData().phaseViewRemoveMode = false;
			this._uncheckBoxesAfterDeleteModeClosed();
			this.getView().getModel("localModel").getData().selectedItemsForRemoval = [];
			this.getView().getModel("localModel").refresh();
			this.getView().getModel("spdDetails").refresh();
			this._packageImportSelected = false;
			this._addServiceSelected = false;
			this._addPackageSelected = false;
			this._addListOfServicesSelected = false;
			this._reArrangeSelected = true;
		},

		_assignNewPhaseToItem: function (oDragged, oDroppedPhaseIndex) {
			let oDraggedItemPath = oDragged.getBindingContextPath("spdDetails"),
				oDraggedItem = this.getView().getModel("spdDetails").getProperty(oDraggedItemPath);
			oDraggedItem.PhaseID = this.getView().getModel("spdDetails").getData().phases[oDroppedPhaseIndex].DdlbKey;
			oDraggedItem.PhaseText = this.getView().getModel("spdDetails").getData().phases[oDroppedPhaseIndex].Value;
			oDraggedItem.Updated = true;
			this.getView().getModel("spdDetails").refresh();
		},

		onDragStartPhaseView: function (oInfo) {
			if (this.getView().getModel("spdDetails").getProperty(oInfo.getParameter("target").getBindingContextPath()).PhaseLocked !==
				false) {
				oInfo.preventDefault(true);
			}
			this.setGridListModel(oInfo.getParameter("target").getBindingContextPath());
		},
		setGridListModel: function (sPath) {
			if (this.getView().getModel("spdDetails").getProperty(sPath).PhasesToDrop) {
				let phaseList = this.getView().getModel("spdDetails").getProperty(sPath).PhasesToDrop.split(";");
				phaseList.pop();
				phaseList.forEach(function (oItems, i) {
					let value = oItems.split("=").pop();
					this.getView().getModel("gridListModel").getData().allPhases[i] = value === "true";
				}, this);
				this.getView().getModel("gridListModel").refresh(true);
			}
		},

		onDropPhaseView: function (oInfo) {
			const oDragged = oInfo.getParameter("draggedControl");
			if (oDragged) {
				const oDropped = oInfo.getParameter("droppedControl"),
					sInsertPosition = oInfo.getParameter("dropPosition"),
					sourceGrid = oDragged.getParent(),
					destinationGrid = oDropped !== null ? oDropped.getParent() : null,
					iDragPosition = sourceGrid.indexOfItem(oDragged),
					iDropPosition = destinationGrid !== null ? destinationGrid.indexOfItem(oDropped) : 0;
				let oDraggedPhaseIndex = oDragged.getParent().getBindingContext("spdDetails").getPath().split("/")[2];
				let oDroppedPhaseIndex =
					oInfo.getParameter("dragSession").getDropInfo().getParent().getBindingContext("spdDetails").getPath().split("/")[2];

				this._assignNewPhaseToItem(oDragged, oDroppedPhaseIndex);

				let oDraggedData = this.getView().getModel("spdDetails").getProperty(oDragged.getBindingContext("spdDetails").getPath());
				let iDraggedPosition = iDragPosition;
				this.getView().getModel("spdDetails").getData().phases[oDraggedPhaseIndex].items.splice(iDraggedPosition, 1);
				if (sInsertPosition === "Before") {
					this.getView().getModel("spdDetails").getData().phases[oDroppedPhaseIndex].items.splice(iDropPosition, 0, oDraggedData);
				} else {
					this.getView().getModel("spdDetails").getData().phases[oDroppedPhaseIndex].items.splice(iDropPosition + 1, 0, oDraggedData);
				}
				this.getView().getModel("spdDetails").refresh();
			}
		},

		onDropListView: function () {
		},

		onPhaseViewFilterPhaseSelectionChange1: function (oEvent) {
			// KNGMHM02-26515 : Change implemantation of filtering - Ins
			this._oData.filtersPlanSetted = false;
			if (this.getView().getModel("localModel").getData().sSelectedViewType !== "phaseView") {
				this.getView().getModel("localModel").refresh();
				this.getView().getModel("spdDetails").refresh();
				return;
			}
			if (oEvent) {
				this._phaseViewSelectionEventHelper(oEvent);

				if (this.oPhaseViewFilterStore['Status']) {
					if (this.oPhaseViewFilterStore['Status'].includes('E0018') || this.oPhaseViewFilterStore['Status'].includes('ZSK00001|E0018')) {
						this.oPhaseViewFilterStore['Status'].push('DRAFT');
					}
				}
			} else if (!this.oPhaseViewFilterStore) {
				this.oPhaseViewFilterStore = {};
			}

			const oPhaseViewFilter = this._phaseViewFilterInitializer();
			// Determinating visible Phase & Items
			this.getView().getModel("spdDetails").getData().iNumberOfItemsPhaseView = 0;
			this.getView().getModel("spdDetails").getData().iNumberOfDaysPhaseView = 0;
			this.getView().getModel("vizModel").getData().iNumberOfPlannedItems = 0;
			this.getView().getModel("vizModel").getData().iNumberOfProposalItems = 0;
			this.getView().getModel("vizModel").getData().iNumberOfProposalDays = 0;
			this.getView().getModel("vizModel").getData().iNumberOfPlannedDays = 0;

			this.phaseViewApplyFiltersToHeaders(oPhaseViewFilter);
			if (this.getView().getModel("localModel").getData().sSelectedViewType !== "phaseView") {
				this._oData.filtersPlanSetted = false;
			}
			this.getView().getModel("localModel").refresh();
			this.getView().getModel("spdDetails").refresh();
			// KNGMHM02-26515 : Change implemantation of filtering - End
		},

		_phaseViewSelectionEventHelper: function (oEvent) {
			let oPhaseViewFilterStore = {};
			oEvent.getParameters().filterItems.forEach(filterItem => {
				const filterText = filterItem.getParent().getProperty("text");
				const validFilters = ['Phase', 'Status', 'Component Status'];
				if (validFilters.includes(filterText)) {
					if (!this.oPhaseViewFilterStore[filterItem.getParent().getProperty("text")]) {
						this.oPhaseViewFilterStore[filterItem.getParent().getProperty("text")] = [];
					}
					this.oPhaseViewFilterStore[filterItem.getParent().getProperty("text")].push(filterItem.getKey());
				}
			});
			return oPhaseViewFilterStore
		},

		_phaseViewFilterInitializer: function () {
			const oPhaseViewFilter = {};
			const sFilterNames = ['Phase', 'Status', 'Component Status'];
			sFilterNames.forEach((sFilterName) => {
				const filterStore = this.oPhaseViewFilterStore[sFilterName];

				if (filterStore && filterStore.length > 0) {
					this._oData.filtersPlanSetted = true;
					oPhaseViewFilter[sFilterName] = sFilterName === "Phase"
						? filterStore
						: filterStore.map(psFilter => {
							const parArr = psFilter.split('|');
							return parArr.length > 1 ? psFilter : parArr[0];
						});
				}
			});
			return oPhaseViewFilter
		},

		phaseViewApplyFiltersToHeaders: function (oPhaseViewFilter) {
			this.getView().getModel("spdDetails").getData().phases.forEach(oPhase => {
				oPhase.bPhaseIsVisible = true;
				if (oPhaseViewFilter['Phase'] && oPhaseViewFilter['Phase'].length > 0) {
					oPhase.bPhaseIsVisible = oPhaseViewFilter['Phase'].includes(oPhase.DdlbKey);
				}
				oPhase.nVisibleItems = 0;
				oPhase.items.forEach(oPhaseItem => {
					oPhaseItem.bItemIsVisible = true;

					//if the user has not set any status filter, we have to filter away
					// - SO sessions with cancelled header "ItemStatusID eq 'ZSK00001|E0007'"
					// - cancelled SO sessions "ComponentStatusID eq 'ZSK00003|E0031'"
					// - SR sessions with cancelled header "ItemStatusID eq 'ZSRQ0001|E0006'"
					// (cancelled SR sessions can not exist do to Status profile in BE)
					// - SR sessions with header in status "SO Created" "ItemStatusID eq 'ZSRQ0001|E0007'"
					const status = oPhaseViewFilter['Status'];
					const componentStatus = oPhaseViewFilter['Component Status'];
					if (this._bCheckForStatus(status, componentStatus)) {
						//no status related filter maintained - remove everything that is somehow cancelled	and also SRs in Status "SO Created"
						const itemStatusIDCheck = ['ZSK00001|E0007', 'ZSRQ0001|E0006', 'ZSK00003|E0031', 'ZSRQ0001|E0007'].includes(oPhaseItem.ItemStatusID)
						oPhaseItem.bItemIsVisible = itemStatusIDCheck ? false : oPhaseItem.bItemIsVisible;
					} else {
						//header- or session-status or both set - apply them
						this._applyHeaderOrSessionStatus(oPhaseItem, oPhaseViewFilter)
					}
					if (oPhase.bPhaseIsVisible) {
						this._handleVisiblePhaseItemProperties(oPhaseItem, oPhase);
					}
				});
			});
		},


		_bCheckForStatus: function  (status, componentStatus) {
			return ((!status || status.length === 0) && (!componentStatus || componentStatus.length === 0));
		},

		_applyHeaderOrSessionStatus: function (oPhaseItem, oPhaseViewFilter) {
			//header- or session-status or both set - apply them
			if (oPhaseViewFilter['Status'] && !oPhaseViewFilter['Component Status']) {
				oPhaseItem.bItemIsVisible = oPhaseViewFilter['Status'].includes(oPhaseItem.ItemStatusID);
			}
			if (oPhaseItem.bItemIsVisible && oPhaseViewFilter['Component Status'] && !oPhaseViewFilter['Status']) {
				oPhaseItem.bItemIsVisible = oPhaseViewFilter['Component Status'].includes(oPhaseItem.ComponentStatusID);
			}
			if (oPhaseItem.bItemIsVisible && oPhaseViewFilter['Status'] && oPhaseViewFilter['Component Status']) {
				oPhaseItem.bItemIsVisible = oPhaseViewFilter['Status'].includes(oPhaseItem.ItemStatusID) && oPhaseViewFilter[
					'Component Status'].includes(oPhaseItem.ComponentStatusID);
			}

		},

		_handleVisiblePhaseItemProperties: function (oPhaseItem, oPhase) {
			if (oPhaseItem.bItemIsVisible) {
				oPhase.nVisibleItems++;
				this.getView().getModel("spdDetails").getData().iNumberOfItemsPhaseView++;
				this.getView().getModel("spdDetails").getData().iNumberOfDaysPhaseView += parseFloat(oPhaseItem.EffortTotal);
				if (oPhaseItem.ItemType !== "YSP1") {
					this.getView().getModel("vizModel").getData().iNumberOfPlannedDays += parseFloat(oPhaseItem.EffortTotal);
					this.getView().getModel("vizModel").getData().iNumberOfPlannedItems++;
				} else {
					this.getView().getModel("vizModel").getData().iNumberOfProposalDays += parseFloat(oPhaseItem.EffortTotal);
					this.getView().getModel("vizModel").getData().iNumberOfProposalItems++;
				}
			}
		},

		onSPDPhaseViewDeleteItem: function (oEvent) {
			this.onSPDDeleteItem(oEvent, false);
		},

		onSPDListViewDeleteItem: function (oEvent) {
			this.onSPDDeleteItem(oEvent, true);
		},

		onSPDDeleteItem: function (oEvent, bDeleteFromListView) {
			let sSelectedSPDItemPath = oEvent.getSource().getBindingContext("spdDetails").sPath,
				oSelectedSPDItem = this.getView().getModel("spdDetails").getProperty(sSelectedSPDItemPath),
				sRowIndex;
			if (bDeleteFromListView) {
				sRowIndex = oEvent.getParameter("row").getIndex();
			}
			let sConfirmationMessage = oSelectedSPDItem.ItemNo === undefined ?
				this.getResourceBundle().getText("SPDDetails.Delete.Confirm.Proposal.Content") :
				this.getResourceBundle().getText("SPDDetails.Delete.Confirm.SPDItem.Content");

			MessageBox.confirm(sConfirmationMessage, {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				emphasizedAction: MessageBox.Action.YES,
				onClose: (sAction) => {
					if (sAction === "YES") {
						oSelectedSPDItem.FlaggedForDeletion = true;
						this.getView().getModel("spdDetails").refresh();

						let oTreeTable = this.getView().byId("tableSPDListViewTree"),
							aFilters = [];
						aFilters.push(new Filter("FlaggedForDeletion", FilterOperator.EQ, false));
						aFilters.push(new Filter("Type", FilterOperator.EQ, "PhaseID"));
						let allFilters = new Filter(aFilters, false),
							oBinding = oTreeTable.getBinding("rows");
						if (bDeleteFromListView) {
							oTreeTable.removeSelectionInterval(sRowIndex, sRowIndex);
						}
						oBinding.filter(allFilters);
					}
				}
			});
		},

		_deleteSPDItem: function (oSPDItemSelected, sSelectedSPDItemPhase, resolve, reject) {
			this.getView().getModel("localModel").getData().busyDraftPlanItems = true;
			this.getView().getModel("localModel").refresh();

			let entities = {};
			entities.servicePath = Constants.getServicePathSPD();
			entities.entitySet = "ServicePlanItemSet(" +
				"ItemGuid=guid'" + oSPDItemSelected.ItemGuid +
				"',SpGuid=guid'" + oSPDItemSelected.SpGuid + "')";
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.busyIndicator = "busyDraftPlanItems";
			entities.sDeletedItemGuid = oSPDItemSelected.ItemGuid;
			entities.callbackSuccess = (data, oParams) => {
				oParams.oContext.oView.getModel("localModel").getData().selectedItemsForRemoval = oParams.oContext.oView.getModel("localModel")
					.getData().selectedItemsForRemoval.filter(item => item.ItemGuid !== oParams.sDeletedItemGuid);
				oParams.currentView.getModel("spdDetails").getData().phases.forEach(oPhase => {
					oPhase.items.forEach(oItem => {
						if (oItem.ItemGuid === oParams.sDeletedItemGuid) {
							oItem.FlaggedForDeletion = false;
						}
					});
				});
				resolve();
			};
			entities.callbackError = (data) => {
				reject();
			};
			this.deleteBaseRequest(entities);
		},

		onPhaseViewRefresh: function (oEvent) {
			MessageBox.confirm(this.getResourceBundle().getText("SPDDetails.Refresh.Confirm.Content"), {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				emphasizedAction: MessageBox.Action.YES,
				onClose: (sAction) => {
					if (sAction === "YES") {
						this._readSPDItems();
					}
				}
			});
		},

		onPhaseViewSelectAll: function () {
			let oGridContainer = this.getView().byId("gridContainer");
			oGridContainer.getItems().forEach(oGirPhaseList => {
				oGirPhaseList.selectAll();
			});
		},

		onPhaseViewSelectNone: function () {
			let oGridContainer = this.getView().byId("gridContainer");
			oGridContainer.getItems().forEach(oGirPhaseList => {
				oGirPhaseList.removeSelections();
			});
		},

		onPhaseViewDeleteBulk: function (oEvent) {
			let oGridContainer = this.getView().byId("gridContainer"),
				oSelection = oGridContainer.getItems().filter(oGirPhaseList =>
					oGirPhaseList.getSelectedContexts().length !== 0
				);
			if (oSelection.length) {
				MessageBox.confirm(this.getResourceBundle().getText("SPDDetails.DeleteBulk.Confirm.Content"), {
					actions: [MessageBox.Action.YES, MessageBox.Action.NO],
					emphasizedAction: MessageBox.Action.YES,
					onClose: (sAction) => {
						if (sAction === "YES") {
							MessageToast.show("Proceed to delete bulk of selected items");
							this._deleteBulkOfSelectedItems();
						}
					}
				});
			} else {
				MessageBox.information(this.getResourceBundle().getText("SPDDetails.DeleteBulk.NoSelection.Content"), {
					actions: [MessageBox.Action.OK],
					emphasizedAction: MessageBox.Action.OK
				});
			}
		},

		_deleteBulkOfSelectedItems: function () {
			let oGridContainer = this.getView().byId("gridContainer");
			oGridContainer.getItems().forEach(oGirPhaseList => {
				let aSelectedContextsInAList = oGirPhaseList.getSelectedContexts();
				aSelectedContextsInAList.forEach(oContext => {
					let sPath = oContext.getPath();
					let oSelectedItem = this.getView().getModel("spdDetails").getProperty(sPath);
					oSelectedItem.FlaggedForDeletion = true;
				});
			});
			this.getView().getModel("spdDetails").getData().phases.forEach(oPhase => {
				oPhase.items = oPhase.items.filter(oItem => oItem.FlaggedForDeletion !== true);
			});
			this.getView().getModel("spdDetails").refresh();

			MessageToast.show(this.getResourceBundle().getText("SPD Bulk of Items Deleted SUCCESSFULLY"));
		},

		fnHandleSectionServicePlanRefresh: function (oEvent) {
			this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "ReloadProjectSection");
		},

		onPhaseViewOpenLegend: function (oEvent) {
			let oButton = oEvent.getSource();
			this._pLegendPopover ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.PopoverLegend");
			this._pLegendPopover.then(oPopover => oPopover.openBy(oButton));
		},

		onActivateCompactMode: function (oEvent) {
			this.getView().byId("sgmtBtnExpandCollapse").setSelectedItem(oEvent.getSource());
			this.getView().getModel("localModel").getData().expandedMode = false;
			this.getView().getModel("localModel").refresh();
			this._setExpandedModeForAllItems(false);

		},

		onActivateExpandedMode: function (oEvent) {
			this.getView().byId("sgmtBtnExpandCollapse").setSelectedItem(oEvent.getSource());
			this.getView().getModel("localModel").getData().expandedMode = true;
			this.getView().getModel("localModel").refresh();
			this._setExpandedModeForAllItems(true);
		},

		_setExpandedModeForAllItems: function (bAllItemsExpanded) {
			const aPhases = this.getView().getModel("spdDetails").getData().phases;
			for (let phase of aPhases) {
				for (let item of phase.items ) {
					item.isExpanded = bAllItemsExpanded;
				}
			}
			this.getView().getModel("spdDetails").refresh();
		},

		onPressToggleFullscreen: function () {
			if (this.getView().getModel("localModel").getProperty("/fullscreen")) {
				document.exitFullscreen();
			} else {
				document.querySelector("html").requestFullscreen();
			}

		},

		/* ========================= List View ======================== */

		/*
		Triggers an event in case of a click on the Row in TreeTable (ListView)
		Ignores node level 0 (Phases)
		Reuses _openMaintainDialog code and fragment DialogMaintainSPDItem
		*/
		onTreeTableRowClick: function (oEvent) {
			let sBindingContextPath = oEvent.getParameters("sPath").rowBindingContext.getPath(),
				oModel = this.getView().getModel("spdDetails"),
				oItem = this.getView().getModel("spdDetails").getProperty(sBindingContextPath),
				sFragmentPath = oItem.ItemType === "YSP1" ?
				"com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.DialogMaintainSPDItem" :
				"com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.DialogServiceItemQuickView";

			// check if selected item is a node: do nothing, if level 0
			let oSelectedItem = oEvent.getParameters("sPath").rowBindingContext.getObject();
			if (oSelectedItem.Level !== 0) {
				this._toggleBusyIndicatorsUpdateSPDItem(true);
				this._readSingleSPDItem(oItem.ItemGuit, oItem.SpGuid,
					function (oLoadedItem) {
						oModel.setProperty(sBindingContextPath, oLoadedItem);
					});

				this._pDialogMaintainItem ??= this._loadFragment(sFragmentPath);
				this._pDialogMaintainItem?.then(oDialog => {
					this._openMaintainDialog(oDialog, sBindingContextPath, "spdDetails");
					this._toggleBusyIndicatorsUpdateSPDItem(false);
				});

			}
		},

		/* ================================== Item manipulation =============================== */

		handleUpdateSPDItem: function (oEvent) {
			let oSource = oEvent.getSource(),
				oSelectedItemPath = oSource.getBindingContext("spdDetails").getPath(),
				oSelectedItem = this.getView().getModel("spdDetails").getProperty(oSelectedItemPath);
			this.onUpdateSPDItem(oSelectedItem);
		},

		/* Handles the logic for creating and truncating text in component description property*/
	    _createCompDesc: function (oItem) {
			let compDesc = "";
			if(oItem.ComponentDescr) {
				if(oItem.ComponentDescr.length > 40) {
					compDesc = oItem.ComponentDescr.slice(0, 38) + "..";
				} else {
					compDesc = oItem.ComponentDescr;
				}
			}
			return compDesc;
		},

		onUpdateSPDItem: function (oSelectedItem, resolve) {
			this.messageHandler.clearAllMessages();
			this.getView().getModel("localModel").getData().busySPDetails = true;
			this.getView().getModel("localModel").refresh();


			let entities = {},
				dataForUpdate = {
					"ComponentID": oSelectedItem.ComponentID,
					"ComponentDescr": this._createCompDesc(oSelectedItem),
					"PhaseID": oSelectedItem.PhaseID,
					"Effort": this.getView().byId("srvEffort") ? this.getView().byId("srvEffort").getValue().toString() : oSelectedItem.Effort.toString(),
					"StartDate": oSelectedItem.StartDate,
					"EndDate": oSelectedItem.EndDate ? new Date(oSelectedItem.EndDate.setHours(23, 59, 59, 0)) : oSelectedItem.EndDate,
					"ComponentDescrAlternative": oSelectedItem.ComponentDescrAlternative
				};
			entities.servicePath = Constants.getServicePathSPD();
			entities.entitySet = "ServicePlanItemSet(ItemGuid=guid'" + oSelectedItem.ItemGuid + "'," +
				"SpGuid=guid'" + oSelectedItem.SpGuid + "')";
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.data = dataForUpdate;
			entities.busyIndicator = "busySPDetails";
			entities.callbackSuccess = () => {
				if (!entities.oContext._reArrangeSelected) {
					entities.oContext.getOwnerComponent().trackEvent("Edit_SPDItem");
				}
				resolve();
			};
			this.updateBaseRequest(entities);
		},


		/*
		Called on change Events of EndDate and selection.
		Iterates through all selected table items and checks for items where EndDate is set wrong.
		If number of such items is > 0, submit button in DialogTransferToExecution.fragment remains disabled.
		*/
		handleSrSoSubmitButtonEnabled: function () {
			let oSelectedItems = this.getView().byId("spdTTEitemsTable").getSelectedItems();
			this.getView().getModel("spdDetails").getData().handleSrSoSubmitButtonEnabled = 0;

			oSelectedItems.forEach(oItem => {
				if (oItem.getAggregation("cells")[3].getValueState() === "Error" || oItem.getAggregation("cells")[2].getValueState() ===
					"Error") {
					this.getView().getModel("spdDetails").getData().handleSrSoSubmitButtonEnabled += 1;
				}
			});
			this.getView().getModel("spdDetails").refresh();
		},

		/**
		 * EventHandler: Button to create SO/SR is pressed on List-View
		 * @param {object} oEvent - Event data
		 */
		onListViewTransferToExecution: function (oEvent) {
			this.isCurrentViewPhaseView = false;
			this._fnTransferAllProposalsToExecution();
		},

		/**
		 * EventHandler: Button to create SO/SR is pressed on Phase-View
		 * @param {object} oEvent - Event data
		 */
		onPhaseViewTransferToExecution: function (oEvent) {
			this.isCurrentViewPhaseView = true;
			this._fnTransferAllProposalsToExecution();
		},

		/*
		 load the fragment for Account contact search
		*/
		fnHandleSOACPValueHelp: function (oEvent) {
			let sBpFct = "ACP";

			this._pVHSOAccContactPers ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.DialogVHAccContactPers");
			this._pVHSOAccContactPers?.then(oDialog => {
				oDialog.getCustomData()[0].setValue(sBpFct);
				this.getView().getModel("oModelAcc").getData().HasEmail = true;
				oDialog.open();
				this.searchSOACP();
			});
		},
		/*
		 * Handles a cancel/close evend for the Search for Account Contact Person-Dialog
		 */
		fnHandleDiscardSOAccContactPers: function () {
			this.getView().getModel("oModelAcc").getData().busySO = false;
			this.getView().getModel("oModelAcc").getData.soacpValueHelp = [];
			this.getView().getModel("oModelAcc").refresh();

			this._pVHSOAccContactPers.then(oDialog => {
				oDialog.close();
				oDialog.destroy();
			});
			this._pVHSOAccContactPers = undefined;
		},

		/**
		 * @param {object} oEvent triggered when the user searches for the Account Contact Person
		 */
		searchSOACP: function (oEvent) {
			this.getView().getModel("localModel").getData().busyVHAccPerson = true;
			this.getView().getModel("localModel").refresh();
			let modelROData = this.getView().getModel("oModelAcc").getData();
			let customerId = this.getView().getModel("spdDetails").getData().Header.CustomerID;
			// remove leading zeroes from the Header CustomerID
			customerId = String(+customerId);

			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "CustomerSet";
			entities.getEntity = customerId;
			entities.filter = this._prepareFilterPayloadSearchSOACP(modelROData);
			entities.navigation = "toContacts";
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.busyIndicator = "busyVHAccPerson";

			entities.errorMessage = this.getResourceBundle().getText("SO.ReadContactsError");
			entities.callbackSuccess = (data) => {
				this._handleSuccessAccountPerson(data);
			};
			this.readBaseRequest(entities);
		},

		_generateFilterParams: function (arrFilters) {
			return "(" + arrFilters.join(" and ") + ")";
		},

		_handleSuccessAccountPerson: function (data) {
			let oControl = this.getView().byId("soAccContactPersTable");
			oControl.rerender();
			let oModelAcc = this.getView().getModel("oModelAcc");
			oModelAcc.getData().soacpValueHelp = data.results;
			oModelAcc.refresh();
			if (data.results.length > 0) {
				oControl.addEventDelegate({
					onAfterRendering: () => {
						let oLocalModel = this.getView().getModel("localModel");
						oLocalModel.getData().busyVHAccPerson = false;
						oLocalModel.refresh();
					}
				});
			} else {
				this.getView().getModel("localModel").getData().busyVHAccPerson = false;
				this.getView().getModel("localModel").refresh();
			}
		},

		/* load the Service Order Group fragment */
		fnHandleSOGroupValueHelp: function (oEvent) {
			this._setCurrentUserAsDefaultForCreateByField();
			this._pVHSOGroup ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.DialogVHServiceOrderGroup");
			this._pVHSOGroup.then(oDialog => {
				oDialog.getModel("oSOGroupModel").getData().numberOfGroups = 0;
				oDialog.getModel("oSOGroupModel").refresh();
				this.onSearchSOGroup();
				oDialog.open();
			});
		},

		/*
		handles the selected contact, assignes it to oModelAcc
		*/
		handleSOACPItemPressed: function (oEvent) {
			let path = oEvent.getSource().getSelectedContextPaths()[0];
			let modelAcc = this.getView().getModel("oModelAcc");
			let dataFromIndex = modelAcc.getProperty(path);
			modelAcc.getData().selectedAccContact = dataFromIndex;
			// add a full name to display in form
			modelAcc.getData().selectedAccContact.Fullname = modelAcc.getData().selectedAccContact.Firstname.concat(
				" ", modelAcc.getData().selectedAccContact.Lastname);

			this.fnHandleDiscardSOAccContactPers();
			this.getView().byId("AccountContactPerson").fireLiveChange();

		},

		/* ==== Code handling the Service Order Group Popup ==== */



		/* get current user ID */
		_setCurrentUserAsDefaultForCreateByField: function () {
			let oSOGModel = this.getView().getModel("oSOGroupModel");
			oSOGModel.getData().createdBy = this.getView().getModel("spdDetails").getProperty("/Header/CreatedBy");
			oSOGModel.refresh();
		},



		/* handle click on an SOG entry in the SOG Detail Dialog */
		handleSOGItemPressed: function (oEvent) {
			let sPath = oEvent.getParameters().listItem.getBindingContextPath();
			let oModel = oEvent.getParameters().listItem.getModel("oSOGroupModel");
			let sSelectedEntry = oModel.getProperty(sPath);
			oModel.getData().ServiceOrderGroup = sSelectedEntry.Description;
			oModel.refresh();
			this.fnHandleDiscardSOGroup();

		},

		/* Destory SOGroup fragment */
		fnHandleDiscardSOGroup: function () {
			this._pVHSOGroup.then(oDialog => {
				oDialog.close();
				oDialog.destroy();
			});
			this._pVHSOGroup = undefined;
		},


		//************************************************************************************************************************
		//************************************************************************************************************************
		//**********************************************   Transfer To Execution   ***********************************************
		//************************************************************************************************************************
		//************************************************************************************************************************

		//
		//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>   Bring up TTE Dialog   <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
		//
		_fnTransferSingleProposalToExecution: function (oItem) {
			this._readSingleSPDItem(oItem.ItemGuid, oItem.SpGuid, function (oLoadedItem) {
				oLoadedItem.bIsSelected = true;
				this._filterAndEnrichProposalsWithCRMDataForTTE([oLoadedItem]);
				this._pDialogTransferToExecution ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.DialogTransferToExecution");
				this._pDialogTransferToExecution?.then(() => this._openTransferToExecutionDialog([oLoadedItem], true));
			}.bind(this));
		},

		/**
		 * this helper method is called by the two event handlers methods,
		 * which are triggered if on phase-view or list-view the button to create SR/SOs is pressed.
		 * It collects the currently available "proposals" into an array and prepares opening the multi-select-popup
		 * where the user can select those, for which an SR or SO should be created
		 *
		 * @param {object} oEvent - Event data
		 */
		_fnTransferAllProposalsToExecution: function () {
			this.getView().getModel("localModel").getData().busySPDetails = true;
			this.getView().getModel("localModel").refresh();
			this._pAllComponentsLoadedFromCRM.then(() => {
				let aProposalsForTTE = [];
				aProposalsForTTE = this._filterAndEnrichProposalsWithCRMDataForTTE(this._getAllProposalsOfServicePlan());
				this._pDialogTransferToExecution ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.DialogTransferToExecution");
				this._pDialogTransferToExecution.then(() => this._openTransferToExecutionDialog(aProposalsForTTE, false));
				this.getView().getModel("localModel").getData().busySPDetails = false;
				this.getView().getModel("localModel").refresh();
			});
		},
		/**
		 * fill the model data for the multi-select-popup
		 * where the user can select those, for which an SR or SO should be created
		 *
		 * @param {object} oEvent - Event data
		 */
		_openTransferToExecutionDialog: function (aProposals, bKeepSelected) {
			aProposals.forEach(item => {
				item.bIsSelected = !!bKeepSelected;
				this._handleContractSituationOfSPDItem(item, true);
			});
			this.getView().getModel("spdDetails").getData().TTEItems = aProposals;
			this.getView().getModel("spdDetails").getData().NumberOfTTEItems = aProposals.length;
			this.getView().getModel("spdDetails").getData().iNumberOfTTEItemsSelected = this.getView().getModel("spdDetails").getData().TTEItems
				.filter(oItem => oItem.bIsSelected).length;
			this.getView().getModel("spdDetails").refresh();

			// disable contract-combo direct input and  open
			this._pDialogTransferToExecution.then(oDialog => {
				oDialog.addEventDelegate({
					onAfterRendering: function () {
						$(".sapMComboBoxBase").each(function () {
							$(this).find("input").attr("readonly", true);
							sap.ui.getCore().byId(this.id).addEventDelegate({
								onAfterRendering: function () {
									$(this).find("input").attr("readonly", true);
								}.bind(this)
							});
						});
					}
				}, this);
				oDialog.open();
			});
		},

		/**
		 * helper method fetch additional data for each item in the "Proposals"-Array.
		 * and removes the proposals with components not "known" in CRM (in the "component"-list that was received earlier)
		 *
		 *  @return {Array} Array with all proposals of the SPD items, enriched with additinal data, that have components known in CRM
		 */
		_filterAndEnrichProposalsWithCRMDataForTTE: function (aProposals) {
			aProposals.forEach(oItem => {
				let oComponentDetails = this.getView().getModel("componentsModel").getData().allCRMComponents.find(oComponent =>
					oComponent.ComponentID === oItem.ComponentID);
				if (oComponentDetails) {
					oItem.ServiceID = oComponentDetails.toServiceF4.results[0].ServiceID;
					oItem.Services = oComponentDetails.toServiceF4.results;
					oItem.ServiceType = oItem.Services[0].ServiceType;
					oItem.ExcludeSR = oItem.Services[0].ExcludeSR;
					oItem.NrComponents = oItem.Services[0].NrComponents;
					oItem.EffortFixed = oComponentDetails.EffortFixed === "X";
					oItem.ComponentEffort = oComponentDetails.ComponentEffort;
					oItem.bFoundInCRM = true;
				} else {
					oItem.bFoundInCRM = false;
				}
			});
			return aProposals.filter(oItem => oItem.bFoundInCRM === true);
		},

		_getAllProposalsOfServicePlan: function () {
			let aProposals = [];
			this.getView().getModel("spdDetails").getData().phases.forEach(oPhase => {
				oPhase.items.forEach(oItem => {
					if (oItem.ItemType === "YSP1") {
						aProposals.push(oItem);
					}
				});
			});
			return aProposals;
		},

		//
		//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  TTE Dialog Event Handling  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
		//

		/**
		 * EventHandler: Triggered when user selects or delselects an item.
		 * Then the related model-property is set accordingly
		 *
		 * @param {object} oEvent - Event data
		 */
		fnOnTTEItemSelectionChange: function (oEvent) {
			let oSPDItem = this.getView().getModel("spdDetails").getProperty(oEvent.getParameters().listItem.getBindingContextPath());
			oSPDItem.bIsSelected = oEvent.getParameter("selected");
			this.getView().getModel("spdDetails").getData().iNumberOfTTEItemsSelected = this.getView().getModel("spdDetails").getData().TTEItems
				.filter(oItem => oItem.bIsSelected).length;
			this.handleSrSoSubmitButtonEnabled(oEvent);
			this.getView().getModel("spdDetails").refresh();
		},

		/**
		 * EventHandler: user has changed the selected Service Product in a line
		 *
		 * @param {object} oEvent - Event data
		 */
		fnOnTTEServiceSelectionChange: function (oEvent) {
			let oSPDItem = this.getView().getModel("spdDetails").getProperty(oEvent.getSource().getParent().getBindingContextPath());
			const oSelectedService = this.getView().getModel("spdDetails").getProperty(oEvent.getSource().getSelectedItem().getBindingContext(
				"spdDetails").getPath());
			oSPDItem.EffortFixed = oSelectedService.EffortFixed === "X";
			oSPDItem.ServiceType = oSelectedService.ServiceType;
			oSPDItem.ExcludeSR = oSelectedService.ExcludeSR;
			oSPDItem.NrComponents = oSelectedService.NrComponents;
			this._handleContractSituationOfSPDItem(oSPDItem);
			oEvent.getSource().getParent().getCells().pop(elm => elm.getId().includes("idContractCombo")).clearSelection(); // clear dependend contract field
			this.getView().getModel("spdDetails").refresh();
		},

		/**
		 * EventHandler: Triggered when use changes the Start Date of a TTE-item.
		 * @param {object} oEvent - Event data
		 */
		fnHandleTTEStartDateChange: function (oEvent) {
			const oDateField = oEvent.getSource(),
				sCurrentItemPath = oDateField.getBindingContext("spdDetails").getPath(),
				oCurrentItem = this.getView().getModel("spdDetails").getProperty(sCurrentItemPath),
			    bDateFieldValid = oEvent.getParameter("valid") && !(oDateField.getRequired() && oDateField.getValue().length === 0),
				oEndDateField = oDateField.getParent().getCells().find(elm=>elm.getId().includes("idTTEEndDate"));

			if (!bDateFieldValid) {
				oDateField.setValueState("Error");
				oEndDateField.setMinDate(null);
			} else {
				oDateField.setValueState("None");
				oEndDateField.setMinDate(oDateField.getDateValue());
				if (!!oCurrentItem.EndDate && oCurrentItem.StartDate > oCurrentItem.EndDate) oEndDateField.setDateValue(this._fnAddOneDay(oDateField.getDateValue()));
				this._handleContractSituationOfSPDItem(oCurrentItem);
				oEvent.getSource().getParent().getCells().pop(elm => elm.getId().includes("idContractCombo")).clearSelection(); // clear dependend contract field
			}
			this.getView().getModel("spdDetails").refresh();
			this.handleSrSoSubmitButtonEnabled();
		},

		/**
		 * EventHandler: Triggered when use changes the End Date of a TTE-item.
		 * @param {object} oEvent - Event data
		 */
		fnHandleTTEEndDateChange: function (oEvent) {
			const oDateField = oEvent.getSource(),
				sCurrentItemPath = oDateField.getBindingContext("spdDetails").getPath(),
				oCurrentItem = this.getView().getModel("spdDetails").getProperty(sCurrentItemPath);

			if (!oEvent.getParameter("valid") || (!!oCurrentItem.StartDate && !!oCurrentItem.EndDate && oCurrentItem.StartDate > oCurrentItem.EndDate))
				oDateField.setValueState("Error");
				else oDateField.setValueState("None");

			this.getView().getModel("spdDetails").refresh();
			this.handleSrSoSubmitButtonEnabled();
		},


		/**
		 * EventHandler: user has picked an item form the contract combo in one line of TTE-Dialog
		 * This "selectionChange"-event is triggered before the "change"-event
		 *
		 * @param {object} oEvent - Event data
		 */
		fnOnTTEContractComboSelectionChange: function (oEvent) {
			let sContractItemPath = oEvent.getParameters("selectedItem").selectedItem.getBindingInfo("key").binding.getContext().sPath,
				selectedContractItem = this.getView().getModel("spdDetails").getProperty(sContractItemPath),
				tteItemPath = oEvent.getSource().getParent().getBindingContextPath(),
				tteItem = this.getView().getModel("spdDetails").getProperty(tteItemPath);

			tteItem.ContractID = selectedContractItem.ContractID;
			tteItem.ContractItem = selectedContractItem.ContractItemNo;
			tteItem.SelectedContract = selectedContractItem;
			this.getView().getModel("spdDetails").refresh();
		},

		/**
		 * EventHandler: the selected value in the contract-combo in one line of the TTE-Dialog has changed.
		 * This "change"-event is triggered after a potentionally triggered "selectionChange"-event
		 *
		 * this code validates the user selection in the Contract Items Combobox
		 */
		fnOnTTEContractComboChange: function (oEvent) {
			let oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue(),
				i18nModel = this.getView().getModel("i18n");
			if (oValidatedComboBox.getValueState() !== "Warning") { // State "None" or "Error"
				if (!sSelectedKey && sValue) {
					oValidatedComboBox.setValueState(sap.ui.core.ValueState.Error);
					oValidatedComboBox.setValueStateText(i18nModel.getResourceBundle().getText(
						"SPDDetails.TranferToExecution.InvalidContractItem"));
				} else {
					oValidatedComboBox.setValueState(sap.ui.core.ValueState.None);
				}
			} else { // State "Warning"
				oValidatedComboBox.setValue("");
			}
		},

		/**
		 * EventHandler: Button to cancel on Multiselect Popup pressed
		 * close Popup and reload SPD Items from BE
		 *
		 * @param {object} oEvent - Event data
		 */
		fnOnHandleDiscardTransferToExecutionDialogPress: function (oEvent) {
			this.messageHandler.clearAllMessages();
			this._pDialogTransferToExecution.then(oDialog => oDialog.close());
			this._readSPDItems();
			this.getView().getModel("spdDetails").getData().TTEItems = [];
			this.getView().getModel("spdDetails").getData().NumberOfTTEItems = 0;
			this.getView().getModel("spdDetails").refresh();
		},

		/**
		 * EventHandler: Button to create SO/SR is pressed on TTE Dialog
		 * Only do something if at least one item is selected
		 * @param {object} oEvent - Event data
		 */
		fnHandleTransferToExecutionPress: function () {
			if (this.getView().getModel("spdDetails").getData().TTEItems.filter(item => item.bIsSelected === true).length > 0) {
				if (this._fnValidateTransferToExecutionForm()) {
					this.messageHandler.clearAllMessages();
					this._fnTransferToExecutionInBE();
				}
			}
		},

		/**
		 * check that strt date is filled, in the Multiselect Popup, for the selected items
		 * @return {boolean}} - true=OK, false=some date not provided
		 */
		_fnValidateTransferToExecutionForm: function () {
			let aSelectedTTEItems = this.getView().getModel("spdDetails").getData().TTEItems.filter(item => item.bIsSelected === true);
			aSelectedTTEItems.forEach(oItem => {
				oItem.isStartDateValid = !!oItem.StartDate;
				oItem.isEndDateValid = true;
				oItem.EndDate = oItem.EndDate ? oItem.EndDate : oItem.StartDate; // if no EndDate set by user, End date is set to Start date
			});
			this.getView().getModel("spdDetails").refresh();
			return !aSelectedTTEItems.find(oItem => oItem.isStartDateValid === false || oItem.isEndDateValid === false);
		},

		/**
		 * get the selected items from  Multiselect Popup and fill them into a batch-call to BE,
		 * so that SOs and SRs are created
		 */
		_fnTransferToExecutionInBE: function () {
			// get contact ID from the selected Contact
			let AccountContactID, SOGroup,
				goLiveDate = this.getView().getModel("spdDetails").getData().CaseDetails.ProjectGoLiveDate;

			// Checks for Account Contact selected. If user submits nothing, empty Array is provided, otherwise
			// an Object containing the Account Contact data.
			if (this.getView().getModel("oModelAcc").getData().selectedAccContact instanceof Array) {
				AccountContactID = "";
			} else {
				AccountContactID = this.getView().getModel("oModelAcc").getData().selectedAccContact.ContactID;
			}

			// Check the SOGroup the Field by Id, since it can also be "assigned" by LiveSearch only
			const SOGGroupFieldValue = this.getView().byId("SOGroupField").getValue();
			SOGroup = SOGGroupFieldValue !== "" ? SOGGroupFieldValue : "";

			this.getView().getModel("localModel").getData().busyTransferToExecution = true;
			this.getView().getModel("localModel").refresh();

			let // sServiceUrl = Constants.getServicePathSPD(),
			//	oModel = new ODataModel(sServiceUrl),
				aTTEItems = this.getView().getModel("spdDetails").getData().TTEItems,
				aSelectedTTEItems = aTTEItems.filter(item => item.bIsSelected === true);
			// Check for the EndDate - if empty, set equal to the StartDate
			aSelectedTTEItems.forEach(oItem => {
				if (oItem.EndDate) {
					oItem.EndDate = oItem.StartDate;
				}
			});

			//batch-processing is causing problems, because seems calls >30s jump to error state (Fiori-Launchpad setting)
			//need send single calls, one after the other (cannot send them in parrallel, because each locks the case in BE to create link to new SR/SO)

			let pFnTransferAllToExecution = () => {
				//show progress indicator
				this._oDialogProgressIndicator = new Dialog({
					type: "Message",
					showHeader: false,
					state: this._bErrorSavingPhases ? "Warning" : "Information",
					content: new ProgressIndicator({
						displayAnimation: false,
						displayValue: "Creating ",
						percentValue: 0,
						state: "Success",
						displayOnly: true
					})
				});
				this._oDialogProgressIndicator.addStyleClass("sapUiSizeCompact");
				if (aSelectedTTEItems.length > 1) this._oDialogProgressIndicator.open();

				this.bKeepMessagePopoverClosed = true;
				let p = Promise.resolve();
				aSelectedTTEItems.forEach((oItem, index) => {
					let iCurrNo = index + 1;
					p = p.then(() => {
						this._oDialogProgressIndicator.getContent()[0].setPercentValue(index / aSelectedTTEItems.length * 100);
						this._oDialogProgressIndicator.getContent()[0].setDisplayValue("Creating " + iCurrNo + " / " + aSelectedTTEItems.length +
							" ");
						return this._pFnSendOneItemToExcecution(oItem, AccountContactID, goLiveDate, SOGroup);
					});
				});
				return p;
			};

			pFnTransferAllToExecution().then(() => {
				//we are through.... clean up
				this._oDialogProgressIndicator.close();
				this._pDialogTransferToExecution.then(oDialog => oDialog.close());
				this.bKeepMessagePopoverClosed = false; //reset this
				this.oMessagePopover.navigateBack(); //want to see the list page
				this.oMessagePopover.openBy(sap.ui.getCore().byId($("[id$=messagePopoverButton]").attr("id")));
				this._readSPDItems();
				this.getView().getModel("localModel").getData().busyTransferToExecution = false;
				this.getView().getModel("localModel").refresh();

				// //<-- reporting
				// we do not get back the information how many SOs and SRs have been really created - so we assume all the ones we expected, also have been created
				// (otherwise we would not be in the success-, but in the error-handler of the batch...)
				let noOfExpectedNewServiceOrders = this.getView().getModel("spdDetails").getData().TTEItems.filter(item => item.bIsSelected &&
					item.ExcludeSR).length;
				for (let i = 0; i < noOfExpectedNewServiceOrders; i++) {
					this.getOwnerComponent().trackEvent("Create_ServiceOrder_InSPD");
					this.getOwnerComponent().trackEvent("Create_ServiceOrder");
				}

				let noOfExpectedNewServiceRequests = this.getView().getModel("spdDetails").getData().TTEItems.filter(item => item.bIsSelected &&
					!item.ExcludeSR).length;
				for (let i = 0; i < noOfExpectedNewServiceRequests; i++) this.getOwnerComponent().trackEvent(
					"Create_ServiceRequest_InSPD");
				//--> reporting

			});

		},

		_pFnSendOneItemToExcecution: function (oItem, AccountContactID, goLiveDate, SOGroup) {
			return new Promise((resolve, reject) => {
				let sServiceUrl = Constants.getServicePathSPD();
				let oModel = new ODataModel(sServiceUrl);

				oModel.setHeaders(Constants.getAPIHeaders());
				oModel.setDeferredGroups(["batchFunctionImport"]);
				oModel.callFunction("/TransferToExecution", {
					method: "POST",
					urlParameters: {
						"ItemGuid": oItem.ItemGuid,
						"ServiceID": oItem.ServiceID,
						"Effort": oItem.Effort,
						"StartDate": oItem.StartDate,
						"EndDate": oItem.EndDate,
						"GoLiveDate": goLiveDate || new Date(0),
						"ServiceOrderGroup": SOGroup,
						"ContractID": oItem.ContractID,
						"ContractItemNo": oItem.ContractItem,
						"AccountContactID": AccountContactID
					},
					batchGroupId: "batchFunctionImport"
				});

				oModel.submitChanges({
					batchGroupId: "batchFunctionImport",
					success: oData => {
						if (!$.isEmptyObject(oData)) {
							let sMessageId = "";
							let sMessageType = "";
							let sMessageTitle = "";
							try {
								let sCreatedObjectId = oData.__batchResponses[0].__changeResponses.map(chResp => chResp.data.results[0].NewObjectId)[0];
								sMessageId = sCreatedObjectId;
								sMessageType = "Success";
								sMessageTitle = sCreatedObjectId.slice(0, 2) === "73" ? "SO " + sCreatedObjectId + " created" : "SR " +
									sCreatedObjectId +
									" created";
							} catch (err) {
								sMessageId = null;
								sMessageType = "Warning";
								sMessageTitle = "Some SR/SO not created - Please refresh screen and try again";
							}
							this.messageHandler.addNewMessageseInsidePopover(
								sMessageId,
								sMessageType,
								sMessageTitle
							);
						}
						resolve();
					},
					error: oError => {
						this._oDialogProgressIndicator.getContent()[0].setState("Warning");
						this.messageHandler.addNewMessageseInsidePopover(
							null,
							"Warning",
							"Some SR/SO not created - Please refresh screen and try again"
						);
						resolve();
					}
				});
			});
		},

		//************************************************************************************************************************
		//************************************************************************************************************************
		//***************************************************   Restricted SPD  **************************************************
		//************************************************************************************************************************
		//************************************************************************************************************************

		/**
		 * Will handle a restricted SPD.
		 * Will show the dialog to maintain the access reason.
		 *
		 */
		_handleRestrictedSPD: function () {
			this._showRestrictedSPDDialog();
		},

		/**
		 * Create and show the restricted SPD dialog.
		 * Will read the restriced access reasons that the user can choose from.
		 *
		 */
		_showRestrictedSPDDialog: function () {
			this._pRestrictedDialog ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.DialogRestrictedSPD");
			this._pRestrictedDialog?.then(oDialog => {
				this._readRestrictedAccessReasons(this, this.getView()).then(function (oData) {
					this.setModel(new JSONModel({
						reasons: oData.results
					}), "restrictedSPD");
				}.bind(this));
				oDialog.open();
			});
		},

		/**
		 * Will cancel the restricted access reason dialog and navigate to the home screen.
		 *
		 */
		onPressCancelRestrictedSPD: function () {
			this._pRestrictedDialog.then(oDialog => oDialog.close());
			this.navToHome();
		},

		/**
		 * Will send the selected access reason to the backend (function import) and the call returns the project data.
		 * AccessText is optional only if the access reason is not 'Other'.
		 * Will also read the project details with the access reason.
		 * Will close the dialog and update the project details if access is granted.
		 *
		 * @param {object} oEvent - Event object of the selected button
		 */
		onPressConfirmRestrictedSPD: function (oEvent) {
			let oAccessReasonSelect = this.getView().byId("selectSPDAccessReasons");
			let sText = this.getModel("restrictedSPD").getProperty("/otherReason");
			if (sText === undefined || sText === null) {
				sText = "";
			}
			let sAccessReason = oAccessReasonSelect.getSelectedItem().getKey();
			let sSpGuid = this.getView().getModel("spdDetails").getData().Header.SpGuid;
			let sCaseId = this.getView().getModel("spdDetails").getData().Header.CaseID;

			Promise.all([this._readRestrictedSPD(sText, sAccessReason, sSpGuid, sCaseId), this._readRestrictedProject(sText,
					sAccessReason,
					sCaseId)])
				.then(function (oData) {
					this._pRestrictedDialog.then(oDialog => oDialog.close());
				}.bind(this));
		},

		/**
		 * Calls the function import to log the access of the restricted Service Plan.
		 *
		 * @param {string} sText - Free text input for reason "Other"
		 * @param {string} sAccessReason - Selected access reason code
		 * @param {string} sSpGuid - Guid of the SP
		 * @param {string} sCaseId - Case Id of the SP
		 *
		 * @return {Promise} Promise that will resolve with the accessed data
		 */
		_readRestrictedSPD: function (sText, sAccessReason, sSpGuid, sCaseId) {
			return new Promise((resolve, reject) => {
				let oParams = {};
				oParams.servicePath = Constants.getServicePathSPD();
				oParams.function = "GetRestrictedSPHeader";
				oParams.method = "GET";
				oParams.currentView = this.getView();
				oParams.oContext = this;
				oParams.urlParameters = {
					"Text": sText,
					"AccessReason": sAccessReason,
					"SpGuid": sSpGuid,
					"CaseID": sCaseId
				};
				oParams.callbackSuccess = (oData) => {
					this.getView().getModel("spdDetails").getData().Header = oData;
					this.getView().getModel("spdDetails").refresh();

					this._readSPDItems();
					resolve();
				};
				this.callFunction(oParams);
			});
		},

		/**
		 * Calls the function import to log the access of the restricted case.
		 *
		 * @param {string} sText - Free text input for reason "Other"
		 * @param {string} sAccessReason - Selected access reason code
		 * @param {string} sCaseId - Case Id of the SP
		 *
		 * @return {Promise} Promise that will resolve with the accessed data
		 */
		_readRestrictedProject: function (sText, sAccessReason, sCaseId) {
			return new Promise((resolve, reject) => {
				let oParams = {};
				oParams.servicePath = Constants.getServicePath();
				oParams.function = "GetRestrictedProject";
				oParams.method = "GET";
				oParams.currentView = this.getView();
				oParams.oContext = this;
				oParams.urlParameters = {
					"Text": sText,
					"AccessReason": sAccessReason,
					"ProjectID": sCaseId
				};
				oParams.callbackSuccess = (oData) => {
					this._handleSuccessProjectData(oData);
					resolve();
				};
				this.callFunction(oParams);
			});
		},

		toggleItemExpanded: function (oEvent) {
			const sPath = oEvent.getSource().getBindingContext("spdDetails").sPath,
				oModel = this.getView().getModel("spdDetails"),
				bIsExpanded = oModel.getProperty(sPath).isExpanded;

			oModel.getProperty(sPath).isExpanded = !bIsExpanded;
			oModel.refresh();

			this.getView().byId("sgmtBtnExpandCollapse").setSelectedItem("none");
		},

		getStatusIndicator: function (sStatus) {
			switch (sStatus) {
			case "DRAFT":
				return "None";
			case "E0001":
				return "None";
			case "E0008":
			case "E0015":
				return "Indication03"; //orange
			case "E0003":
			case "E0004":
				return "Indication07"; //violet
			case "E0005":
				return "Indication04"; //green
			case "E0016":
			case "E0002":
				return "Indication05"; //blue
			default:
				return "None";
			}

		},

		getColumnWidths(aPhases) {
			const oLayoutOptions = {
				phaseNoneVisible: {
					M: "13.5rem",
					L: "13.5rem",
					XL: "18.5rem"
				},

				phaseNoneInvisible: {
					M: "13.5rem",
					L: "13.5rem",
					XL: "18.5rem"
				}
			};

			const sLayoutOption = aPhases.find(function (element) {
				return element.Value === "None";
			}).items.length > 0 ? "phaseNoneVisible" : "phaseNoneInvisible";

			return oLayoutOptions[sLayoutOption];
		},

		onResetSortServices: function () {
			let oTable = this.getView().byId("draftItemsTable");
			this.onResetSort(oTable);
			this._oSort = null;
		},

		onResetSort: function (oTable) {
			oTable.resetSorting();
		},

		onServicesPersoButtonPressed: function (oEvent) {
			this._oTPCServices.openDialog();
		},

		_initializeServicesTablePerso: function () {
			if (this._oTPCServices === undefined) {
				this._oTPCServices = new TablePersoControllerM({
					table: this.getView().byId("draftItemsTable"),
					componentName: "draftItemsTable",
					persoService: TablePersoDraftPlan
				}).activate();
			}

			TablePersoDraftPlan.setContext(this);
		},

		onServicesTablePersoRefresh: function () {
			TablePersoDraftPlan.resetPersData();
			this._oTPCServices.refresh();
		},


		//************************************************************************************************************************
		//**********************************************   Export Service Plan To Excel  *****************************************

		fnOpenDialogExportToExcel: function () {
			this._pDialogUserExport ??= this._loadFragment("com.sap.ui.hep.view.Details.fragment.ExportUserDialog");
			this._pDialogUserExport.then(oDialog => oDialog.open());
		},

		onListViewExportSelected: function (oParam) {
			this._onDownload(oParam);
		},

		_onDownload: function (oParam) {
			let aCols = this.createColumnConfig2(oParam),
				sFileName = "PROJECT_SO_EXPORT" + ".xlsx",
				oTreeData = [];

			let results = this.getView().getModel("spdDetails").getData().results;
			results.forEach(oItem => {
				oTreeData.push(oItem);
			});

			let oSettings = {
				workbook: {
					columns: aCols,
					hierarchyLevel: "Level",
					context: {
						sheetName: "Export from HEP"
					}
				},
				dataSource: oTreeData,
				fileName: sFileName
			};

			let oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function () {
				oSheet.destroy();
			});

		},

		createColumnConfig2: function (oParam) {
			let EdmType = ExportLibrary.EdmType,
				aCols = [];
			aCols.push({
				label: "Phase",
				property: "PhaseText",
				type: EdmType.String
			});

			let items = this.getView().byId("draftItemsTable").getColumns();

			items = oParam ? items.filter(function (arg) {
				return arg.getProperty("visible") !== false;
			}) : items;

			items.forEach(function (arg) {
				if (arg.getHeader().getProperty("text") !== "Phase" && arg.getHeader().getProperty("text") !== "Actions") {
					aCols.push({
						label: arg.getHeader().getProperty("text"),
						property: arg.getProperty("sortField"),
						width: 10
					});
				}
			});
			return aCols;
		},

		//************************************************************************************************************************
		//*****************************************************   Event Handler  *************************************************

		onCloseExportDialog: function () {
			this._pDialogUserExport.then(oDialog => oDialog.close());
		},

		onNavToSSC: function (oEvent) {
			let sPath = oEvent.getSource().getParent().getBindingContext("spdDetails").getPath();
			let oItem = this.getView().getModel("spdDetails").getProperty(sPath);

			const sUrlToSsc = Constants.getSscUrl(oItem.ServiceID);
			NavigationToExternalApps.fnHandleLinkNavigation(sUrlToSsc);
		},

		onSPDDetailsFilterPressed: function (oParam) {
			let filterlist = this.variant.currentVariant.filter.getData().filterlist;
			let hasBeenClicked = this.variant.currentVariant.filter.getData().hasBeenClicked;

			FilterHelper.getViewSettingsDialog("com.sap.ui.hep.view.Details.fragment.DialogFilterHome",this, this._mViewSettingsDialogs)
				.then((oViewSettingsDialog) => {
					if (this.searchFilters === "" && this.getView().byId("filterDialog"))
						this.getView().byId("filterDialog").clearFilters();
					if (filterlist && !hasBeenClicked) {
						this.variant.currentVariant.filter.getData().hasBeenClicked = true;
						this.getView().byId("filterDialog").getFilterItems().forEach(entry => {
							if (entry.getCustomControl !== undefined && entry.getCustomControl().getValue)
								this.lastFilters.push(entry.getCustomControl().getValue());

							this.lastFilters = FilterHelper.handleCreationOfFilterPopUpFromVariantServices(entry, filterlist, this.lastFilters);
						});
					}

					oParam === true ? this.getView().byId("filterDialog").fireConfirm() : oViewSettingsDialog.open(this.getView().byId("filterDialog")._getPage1());;

					["dynamic-range", "dynamic-range2", "dynamic-range3"].forEach(oDateFilter => FilterHelper.buildOptionsForDateFilters(oDateFilter, this));
				});

		},

		onPhaseViewFilterPhaseSelectionChange: function (oEvent) {

			let aItemsSelected = oEvent ?
				oEvent.getParameters().filterItems :
				this.getView().getModel("filterModel").getData().rangeSelected;

			if (aItemsSelected === undefined) {
				if (this.getView().byId("filterDialog")) {
					aItemsSelected = this.getView().byId("filterDialog").getSelectedFilterItems();
				}
			}

			let aParams = " and (";
			this.lastFilters = [];
			this.oStore = {};
			FilterHelper.refreshMultiInput(this);

			this.getView().getModel("spdDetails").getData().iNumberOfItemsPhaseView = 0;
			this.getView().getModel("spdDetails").getData().iNumberOfDaysPhaseView = 0;

			oEvent.getSource().getFilterItems().forEach(item => {


				if (item.getText().includes("Date")) {
					aParams = FilterHelper.generateFilterStringForDateFilters(item, this, aParams);
				}

				if (item.getCustomControl !== undefined && item.getCustomControl().getValue && !item.getText().includes("Date")) {
					this.lastFilters.push(item.getCustomControl().getValue());
				}

				if (item.getCustomControl?.().getValue && item.getCustomControl().getValue() !== "" && !item.getText().includes("Date")) {

					aParams = FilterHelper.generateFilterStringForFreeText(item, this, aParams, "services");

				}
			});

			if (aParams.length > 6) {
				aParams = aParams.substring(0, aParams.length - 4);
				aParams += ")";
			} else {
				aParams = aParams.substring(0, aParams.length - 5);
			}

			aParams = FilterHelper.generateFilterStringForStandardFiltersServices(aItemsSelected, this, aParams, "SPD");

			this._handleFilterCreated(aParams);

			this._readSPDItems();
			this.getView().getModel("localModel").refresh();
			this.getView().getModel("spdDetails").refresh();

		},

		_handleFilterCreated: function(aParams){
			if (aParams.length !== 1) {
				this.searchFilters = aParams;
				this._oData.filtersSetted = true;
			} else {
				this.searchFilters = "";
				this._oData.filtersSetted = false;
			}
		},

		cancelInputs: function (oEvent) {
			FilterHelper.cancelInputs(oEvent, this, this.lastFilters, 5);
		},

		resetInputs: function (oEvent) {
			FilterHelper.resetInputs(oEvent);
		},

		eventFired: function (oEvent, sId) {
			FilterHelper.eventFired(oEvent, sId, this);
		},

		_resetFilters: function () {
			FilterHelper.resetFilters(this)
		},

		refreshSPDStatusFilter: function () {
			if (this.getView().getModel("localModel").getData().sSelectedViewType !== "listView") {
				return;
			}
			FilterHelper.refreshMultiInput(this);
		},

		removeFilterFromBar: function (oEvent) {
			FilterHelper.removeFilterFromBar(oEvent, this);
		},

		handleDisplayServiceOrder: function (oEvent) {
			let sPath = oEvent.getSource().getParent().getBindingContext("spdDetails").getPath();
			let oItem = this.getView().getModel("spdDetails").getProperty(sPath);

			this.getRouter().navTo("ServiceOrderDisplay", {
				serviceOrderID: oItem.ObjectID
			});
		},

		handleDisplayButtonPressed: function (oEvent) {
			let sPath = oEvent.getSource().getParent().getBindingContext("spdDetails").getPath(),
				oSelectedItem = this.getView().getModel("spdDetails").getProperty(sPath);
			if (oSelectedItem.Type === "SR") {
				let sProjectId = oSelectedItem.CaseID;
				let sId = oSelectedItem.ObjectID;
				NavigationToExternalApps.fnNavigateToSrsApp("Display", sId, sProjectId);
			} else {
				let sUrl = oSelectedItem.TbuiUrl;
				this.getOwnerComponent().trackEvent("Trigger_DisplayServiceOrder_InCRM");
				NavigationToExternalApps.fnHandleLinkNavigation(sUrl);
			}
		},

		handleEditSOButtonClick: function (oEvent) {
			let sPath = oEvent.getSource().getParent().getBindingContext("spdDetails").getPath(),
				oSelectedItem = this.getView().getModel("spdDetails").getProperty(sPath);

			if (oSelectedItem.ItemType === "YSP1") {
				this.fnOnPressCard(oEvent);
			} else {
				this.getRouter().navTo("ServiceOrderMaintain", {
					serviceOrderID: oSelectedItem.ObjectID
				});
			}
		},
		handleAssignConsultant: function (oEvent) {
			this.getView().getModel("localModel").getData().busyDraftPlanItems = true;
			this.getView().getModel("localModel").refresh();
			const
				sBindingContextPath = oEvent.getSource().getBindingContextPath ? oEvent.getSource().getBindingContextPath() : oEvent.getSource()
				.getParent()
				.getParent().getParent().getBindingContextPath(),
				sModelName = "spdDetails",
				oItem = this.getView().getModel(sModelName).getProperty(sBindingContextPath);
			let oParams = {};
			oParams.servicePath = Constants.getServicePathSPD();
			oParams.function = "AssignMyselfAsSC";
			oParams.method = "POST";
			oParams.busyIndicator = "busyDraftPlanItems";
			oParams.currentView = this.getView();
			oParams.oContext = this;
			oParams.urlParameters = {
				"ItemGuid": oItem.ItemGuid
			};
			oParams.callbackSuccess = (oData) => {
				this.fnHandleSectionServicePlanRefresh();
				sap.m.MessageToast.show("Consultant assigned");
				this.getView().getModel("localModel").getData().busyDraftPlanItems = false;
				this.getView().getModel("localModel").refresh();

			};
			oParams.callbackError = (error) => {
				let errorMsg = (error?.responseText) ? JSON.parse(error.responseText) : "";
				let errorText = (errorMsg?.error?.innererror?.errordetails) ? errorMsg
					.error
					.innererror.errordetails[0].message : "";
				this.messageHandler.addNewMessageseInsidePopover(
					null,
					"Error",
					"Could not assign consultant",
					errorText,
					"");

				this.getView().getModel("localModel").getData().busyDraftPlanItems = false;
				this.getView().getModel("localModel").refresh();
			};
			this.callFunction(oParams);
		},

		handleISDHubButtonPress: function (oEvent) {
			let sPath = oEvent.getSource().getParent().getBindingContext("spdDetails").getPath(),
				oSelectedItem = this.getView().getModel("spdDetails").getProperty(sPath),
				sUrl = oSelectedItem.IsdHubUrl;
			this.getOwnerComponent().trackEvent("Trigger_DisplayServiceOrder_InISDHub");
			NavigationToExternalApps.fnHandleLinkNavigation(sUrl);
		},

		handleCancelButtonPressed: function (oEvent) {
			let sPath = oEvent.getSource().getParent().getBindingContext("spdDetails").getPath(),
				oSelectedItem = this.getView().getModel("spdDetails").getProperty(sPath);

			this.getView().getModel("localModel").getData().busyDraftPlanItems = true;
			this.getView().getModel("localModel").refresh();

			let entities = {};

			entities.servicePath = Constants.getServicePathWithoutLangParam();
			entities.entitySet = "ServiceItemSet/" + "?sap-language=en";
			entities.filter = "(ObjectID eq '" + oSelectedItem.ObjectID + "') and (ComponentStatus eq 'E0019')";
			entities.busyIndicator = "busyDraftPlanItems";
			entities.errorMessage = this.getResourceBundle().getText("Error.DraftPlan.handleCancelButtonPressed");
			entities.callbackSuccess = (oData) => {
				this.getView().getModel("localModel").getData().busyDraftPlanItems = false;
				this.getView().getModel("localModel").refresh();

				let title = "Confirmation",
					text = this.getResourceBundle().getText("SO.Planning.Cancel.Content", [oSelectedItem.ObjectTitle]),
					icon = null,
					flexBox = null,
					text2 = null,
					link = null;

				if (oData.results.length > 1) {
					title = "Warning";
					text = this.getResourceBundle().getText("SO.Planning.CancelMultipleComponents.Content1", [oSelectedItem.ObjectTitle]);
					text2 = this.getResourceBundle().getText("SO.Planning.CancelMultipleComponents.Content2", [oData.results.length]);
					icon = "WARNING";
					link = new sap.m.Link({
						text: oData.results[0].ObjectID,
						press: [() => {
							this.getRouter().navTo("ServiceOrderDisplay", {
								serviceOrderID: oData.results[0].ObjectID
							});
						}, this]
					});
				}

				flexBox = new sap.m.FlexBox({
					items: [
						new sap.m.Text({
							text: text
						}),
						link,
						new sap.m.Text({
							text: text2
						})
					]
				});

				MessageBox.confirm(flexBox, {
					title: title,
					icon: icon,
					actions: [MessageBox.Action.YES, MessageBox.Action.NO],
					onClose: (sAction) => {
						if (sAction === "YES") {
							this.onCancelItem(oSelectedItem, function () {}, function () {});
						}
					}
				});
			};
			this.readBaseRequest(entities);
		},

		onCancelItem: function (oSelectedItem, resolve, reject) {

			this.getView().getModel("localModel").getData().busyDraftPlanItems = true;
			this.getView().getModel("localModel").refresh();
			this._oModel.refresh();
			let entities = {},
				dataForUpdate = {
					// data for cancel request
					SoID: oSelectedItem.ObjectID,
					StatusCode: "E0007"
				};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ServiceOrderSet(guid'" + oSelectedItem.ItemGuid + "')";
			entities.currentView = this.getView();
			entities.updateMethod = "PUT";
			entities.oContext = this;
			entities.data = dataForUpdate;
			entities.busyIndicator = "busySPListView";
			entities.callbackSuccess = (data) => {
				this.getOwnerComponent().trackEvent("Edit_ServiceOrder");
				resolve(data);
				this.messageHandler.clearAllMessages();
				this.messageHandler.addNewMessageseInsidePopover(
					null,
					"Success",
					"Service Order Item " + oSelectedItem.ServiceDescr + " cancelled.",
					"All of your changes have been successfully saved",
					"");
				this._readSPDItems();
			};
			entities.callbackError = (error) => {
				reject(error);
				this.messageHandler.clearAllMessages();
				this.messageHandler.addNewMessageseInsidePopover(
					null,
					"Error",
					"Service Order Item '" + oSelectedItem.ServiceDescr + "' could not be cancelled.",
					"",
					"");

				this.getView().getModel("localModel").getData().busySPListView = false;
				this.getView().getModel("localModel").getData().busyDraftPlanItems = false;
				this._readSPDItems();
				this.getView().getModel("localModel").refresh();
			};
			this.updateBaseRequest(entities);
		},

		handleReleaseAndShipSOButton: function (oEvent) {
			let sPath = oEvent.getSource().getParent().getBindingContext("spdDetails").getPath(),
				oSelectedItem = this.getView().getModel("spdDetails").getProperty(sPath);

			// Ask for user confirmation
			MessageBox.confirm(this.getResourceBundle().getText("SO.Planning.Release.Content", [oSelectedItem.ObjectTitle]), {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				onClose: (sAction) => {
					if (sAction === "YES") {
						this.onReleaseAndShipSO(oSelectedItem, function () {}, function () {});
					}
				}
			});
		},

		onReleaseAndShipSO: function (oSelectedItem, resolve, reject) {
			this.getView().getModel("localModel").getData().busySPListView = true;
			this._oModel.refresh();
			let oParams = {},
				sSoGUID = oSelectedItem.ObjectGuid.replace(/-/g, "");

			oParams.servicePath = Constants.getServicePath();
			oParams.function = "SORelease";
			oParams.currentView = this.getView();
			oParams.method = "GET";
			oParams.errorMessage = this.getResourceBundle().getText("SO.ReleaseSOError");

			oParams.urlParameters = {
				"SoGUID": sSoGUID.toUpperCase()
			};
			oParams.callbackSuccess = (data) => {
				this.getOwnerComponent().trackEvent("Edit_ServiceOrder");
				resolve(data);
				this.messageHandler.addNewMessageseInsidePopover(
					null,
					"Success",
					"Service Order Item " + oSelectedItem.ServiceDescr + " released.",
					"All of your changes have been successfully saved",
					"",
					this,
					null);
				this._readSPDItems();
			};
			oParams.callbackError = (error) => {
				let errorMsg = JSON.parse(error.responseText),
					errorText = errorMsg.error.innererror.errordetails[0].message;
				this.messageHandler.addNewMessageseInsidePopover(
					null,
					"Error",
					"Service Order Item '" + oSelectedItem.ServiceDescr + "' could not be released.",
					errorText,
					"");

				this.getView().getModel("localModel").getData().busySPListView = false;
				this.getView().getModel("localModel").refresh();
				reject(error);
			};
			this.callFunction(oParams);
		},

		handleSort: function (channelId, eventId, parametersMap) {
			this._oSort = parametersMap;
		},

		onPlanDetailsOpenPopup: function () {
			let oView = this.getView(),
				oTextField = this.getView().byId("buttonInfoPlan");

			//prepare existing data for the VizFrame
			let vizData = this.getView().getModel("vizData");
			let localData = ({
				data: [{
					name: "Services",
					category: "Proposal",
					value: this.getView().getModel("vizModel").getData().iNumberOfProposalItems
				}, {
					name: "Services",
					category: "Planned",
					value: this.getView().getModel("vizModel").getData().iNumberOfPlannedItems
				}, {
					name: "Days",
					category: "Proposal",
					value: this.getView().getModel("vizModel").getData().iNumberOfProposalDays
				}, {
					name: "Days",
					category: "Planned",
					value: this.getView().getModel("vizModel").getData().iNumberOfPlannedDays
				}]
			});
			vizData.setData(localData);
			this.getView().getModel("vizData").refresh();

			if (!oView.byId("planDetailsPopover")) {
				this._pdPopover ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.PopoverPlanDetails");
				this._pdPopover?.then(oPopover => oPopover.openBy(oTextField));
			};
		},

		onPlanDetailsClosePopup: function () {
			this.getView().byId("planDetailsPopover").close();
			this.getView().byId("planDetailsPopover").destroy();
		}

	});
});
