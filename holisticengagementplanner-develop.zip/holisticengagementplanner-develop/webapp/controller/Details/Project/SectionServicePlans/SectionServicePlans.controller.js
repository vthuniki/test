sap.ui.define([
	"com/sap/ui/hep/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"com/sap/ui/hep/model/formatter",
	"com/sap/ui/hep/util/projectSelection/ProjectSelection",
	"com/sap/ui/hep/reuse/Constants"

], function (BaseController, JSONModel, MessageToast, MessageBox, formatter,
	ProjectSelection, Constants) {
	"use strict";
	return BaseController.extend("com.sap.ui.hep.controller.Details.Project.SectionServicePlans.SectionServicePlans", {

		formatter: formatter,

		/* ============================================= General =================================================== */

		onInit: function () {
			this.getOwnerComponent().pCrmUserDataLoaded.then(()=> {
				this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());

				this._fnInitializeModels();

				// register EventBus Event Handler
				const oBus = this.getOwnerComponent().getEventBus();
				oBus.subscribe("ChannelServicePlanSection", "ProjectIsLoaded", this._fnOnGetProjectDetails, this);
				oBus.subscribe("ChannelServicePlanSection", "SelectorOpened", this._fnOnOpenServicePlanSelector, this);
				oBus.subscribe("ChannelServicePlanSection", "selectedViewTypeChanged", this._fnOnSelectedViewTypeChanged, this);
				oBus.subscribe("ChannelServicePlanSection", "DraftPlanIsUpdated", this._fnHandleLoadDraftServicePlansFromBE, this);
				oBus.subscribe("ChannelSortOrderDraftPlans", "SortOrderSet", this._fnInitializeVariant, this);
				oBus.subscribe("ChannelServicePlanSection", "ProjectPhaseDatesChanged", this._fnOnProjectPhaseDatesChanged, this);
				oBus.subscribe("ChannelServicePlanSection", "EmptyServicePlanSection", this._fnEmptyServicePlanSection, this);
			});
		},

		_fnInitializeModels: function () {
			this.getView().setModel(new JSONModel({}), "localModel");
			this.getView().setModel(new JSONModel({}), "draftPlansModel");
			this.getView().getModel("localModel").refresh();
			this.getView().getModel("draftPlansModel").refresh();

			this.getView().getModel("localModel").getData().bExecutionPlanFocused = true; //initially the Execution Plan is highlighted
			this.getView().getModel("localModel").getData().sSelectedViewType = "listView"; //initially the ListViewType has to be displayed
			this.getView().getModel("localModel").getData().bSelectorVisible = false; //initially show the selector
			this.getView().getModel("localModel").getData().sSegmentedButtonSortOrder = "desc";
			this.getView().getModel("localModel").refresh();

		},

		//*  EventBus Event Handler
		_fnOnGetProjectDetails: function (channel, event, oProjectDetails) {
			this._fnInitializeModels();
			this.getView().getModel("localModel").getData().projectDetails = oProjectDetails;
			this.getView().getModel("localModel").refresh();
			this.fnOnExecutionPlanFocused(); //publishes Event
			//	this._fnLoadDraftServicePlansFromBE();  //now done with variant management
		},

		//*  EventBus Event Handler
		_fnOnOpenServicePlanSelector: function (channel, event, data) {
			this.getView().getModel("localModel").getData().bSelectorVisible = true;
			this.getView().getModel("localModel").refresh();
			if (data?.bCreateNew) this.fnOnCreateNewServicePlan();
		},

		//*  EventBus Event Handler
		_fnOnSelectedViewTypeChanged: function (channel, event, oPublisherViewLocalModelData) {
			this.getView().getModel("localModel").getData().sSelectedViewType = oPublisherViewLocalModelData.sSelectedViewType; //"listView", "phaseView", "calendarView"
			this.getView().getModel("localModel").refresh();
		},

		//*  EventBus Event Handler
		_fnOnProjectPhaseDatesChanged: function (channel, event, oData) {
			if (this.getView().getModel("localModel").getData().bExecutionPlanFocused) {
				this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "ExecutionPlanFocused", this.getView().getModel(
					"localModel").getData());
			} else {
				this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "DraftPlanFocused", this.getView().getModel(
					"localModel").getData());
			}
		},

		//*  EventBus Event Handler
		_fnInitializeVariant: function (channel, event, oPublisherViewLocalModelData) {
			this.getView().getModel("localModel").getData().sSegmentedButtonSortOrder = oPublisherViewLocalModelData.sortOrder;
			this.getView().byId("draftSortSelect").setSelectedKey(oPublisherViewLocalModelData.sortItem);
			this.getView().byId("sortOrder").setSelectedButton(this.getView().byId(oPublisherViewLocalModelData.sortOrder));
			this.getView().getModel("localModel").refresh();
			this._fnLoadDraftServicePlansFromBE(oPublisherViewLocalModelData.sortItem);
		},

		//*  EventBus Event Handler
		_fnHandleLoadDraftServicePlansFromBE: function (channel, event, oPublisherViewLocalModelData) {
			this.getView().getModel("localModel").getData().sSegmentedButtonSortOrder = oPublisherViewLocalModelData.sortDraftPlans.sortOrder;
			this._fnLoadDraftServicePlansFromBE(oPublisherViewLocalModelData.sortDraftPlans.sortItem);
		},

		//*  EventBus Event Handler
		_fnEmptyServicePlanSection: function () {
			this.fnOnCloseServicePlanSelector();
		},

		_fnLoadDraftServicePlansFromBE: function (sSorter) {
			this.getView().getModel("localModel").getData().busyServicePlanSelector = true;
			this.getView().getModel("localModel").refresh();

			const entities = {};
			entities.servicePath = Constants.getServicePathSPD();
			entities.entitySet = Constants.getEntities().ServicePlanHeaderSet;
			entities.expand = "toUsedPackages";
			entities.currentView = this.getView();
			entities.filter = "CaseID eq '" +
				this.getView().getModel("localModel").getData().projectDetails.ProjectID +
				"'";
			if (sSorter) {
				entities.sortItem = sSorter;
			} else {
				entities.sortItem = "CreatedAt";
			}
			entities.sortOrder = this.getView().getModel("localModel").getData().sSegmentedButtonSortOrder;
			this.getOwnerComponent().getEventBus().publish("ChannelSortOrderDraftPlans", "SortOrderReceive", {
				"sortItem": entities.sortItem,
				"sortOrder": entities.sortOrder
			});

			entities.oContext = this;
			entities.busyIndicator = "busySPD";
			entities.errorMessage = this.getResourceBundle().getText("ProjectDetails.ReadServicePlansErrors");
			entities.callbackSuccess = (oData) => {
				this.getView().getModel("draftPlansModel").getData().items = oData.results;
				if (this.getView().getModel("localModel").getData().oSelectedDraftPlan) //highlight the plan again, that was highlighted before
					this.getView().getModel("draftPlansModel").getData().items.find(oPlan => oPlan.SpGuid === this.getView().getModel("localModel").getData()
					.oSelectedDraftPlan.SpGuid).bFocusedServicePlan = true;
				this.getView().getModel("draftPlansModel").getData().numberOfServicePlans = oData.results.length;
				this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "NumberOfDraftPlans", oData); //publish to Draft and Execution

				//get URL and title of package log
				let oFocusPackageFromSSC = {};
				let iCounter = 0;
				this.getOwnerComponent().oHelperData.pReadAllPackagesFromSSC.then(oAllPackagesFromSSC => {
					this.getView().getModel("draftPlansModel").getData().items.forEach(oDraftPlan =>
						oDraftPlan.toUsedPackages.results.forEach(oUsedPackage => {
							oFocusPackageFromSSC = oAllPackagesFromSSC.find(({
								code
							}) => code === oUsedPackage.PackageCode);
							if (oFocusPackageFromSSC) {
								iCounter++;
								oUsedPackage.LinkText = `${iCounter}. [${oFocusPackageFromSSC.code}] - ${oFocusPackageFromSSC.name}`;
								oUsedPackage.PackageUrl = oFocusPackageFromSSC.url;
							}
						})
					);
					this.getView().getModel("draftPlansModel").refresh();
				});

				this.getView().getModel("draftPlansModel").refresh();
				this.getView().getModel("localModel").getData().busyServicePlanSelector = false;
				this.getView().getModel("localModel").refresh();

			};
			this.readBaseRequest(entities);
		},

		//*************************************************************************************************
		//*************************************************************************************************
		//**************************************  Event Handler *******************************************
		//*************************************************************************************************
		//*************************************************************************************************

		fnOnCloseServicePlanSelector: function () {
			this.getView().getModel("localModel").getData().bSelectorVisible = false; //initially show the selector
			this.getView().getModel("localModel").refresh();
			this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "SelectorClosed");
		},

		fnOnExecutionPlanFocused: function () {
			if (this.getView().getModel("draftPlansModel").getData().items) {
				this.getView().getModel("localModel").getData().oSelectedDraftPlan = null;
				this.getView().getModel("draftPlansModel").getData().items.forEach(oFP => {
					oFP.bFocusedServicePlan = false;
				});
				this.getView().getModel("draftPlansModel").refresh();
			}

			this.getView().getModel("localModel").getData().bExecutionPlanFocused = true; // now the Execution Plan is highlighted
			this.getView().getModel("localModel").refresh();
			this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "ExecutionPlanFocused",
				this.getView().getModel("localModel").getData());
		},

		handleSortDraftsSegment: function (ascDescSortOrder) {
			this.getView().getModel("draftPlansModel").getData().bSortDrafts = true; // Sort Drafts
			this.getView().getModel("draftPlansModel").refresh();
			this.getView().getModel("localModel").getData().sSegmentedButtonSortOrder = ascDescSortOrder;
			this.getView().getModel("localModel").refresh();

			let sSortProperty = this.getView().byId("draftSortSelect").getSelectedKey();
			this._fnLoadDraftServicePlansFromBE(sSortProperty);

		},

		handleSortDraftsSelect: function (sSelectedKey) {
			this._fnLoadDraftServicePlansFromBE(sSelectedKey);
		},

		fnOnDraftPlanFocused: function (oEvent) {
			const sSelectedSPPath = oEvent.getParameter("listItem").getBindingContext("draftPlansModel").getPath();
			const oSelectedSP = this.getView().getModel("draftPlansModel").getProperty(sSelectedSPPath);
			this.getView().getModel("draftPlansModel").getData().items.forEach(oFP => {
				oFP.bFocusedServicePlan = false;
			});
			oSelectedSP.bFocusedServicePlan = true;
			this.getView().getModel("draftPlansModel").refresh();

			this.getView().getModel("localModel").getData().oSelectedDraftPlan = oSelectedSP;
			this.getView().getModel("localModel").getData().bExecutionPlanFocused = false; //now one of the Draft Plans is highlighted
			this.getView().getModel("localModel").refresh();
			this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "DraftPlanFocused",
				this.getView().getModel("localModel").getData());
		},

		fnOnCreateNewServicePlan: function () {
			this._pDialogCreateNewServicePlan ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.fragments.CreateNewServicePlan");
			this._pDialogCreateNewServicePlan.then(oDialog => {
				const oProjectDetails = this.getView().getModel("localModel").getData().projectDetails,
					oUserDetails = this.getOwnerComponent().getModel("appData").getData().oCrmUserData;
				this.getView().getModel("localModel").getData().oNewServicePlan = {};
				this.getView().getModel("localModel").getData().bServicePlanNameEntered = false;
				this.getView().getModel("localModel").getData().oNewServicePlan.StartDate = oProjectDetails.ProjectStarDate;
				this.getView().getModel("localModel").getData().oNewServicePlan.EndDate = oProjectDetails.ProjectEndDate;
				this.getView().getModel("localModel").getData().oNewServicePlan.CreatedBy = oUserDetails.UserId;
				this.getView().getModel("localModel").getData().oNewServicePlan.CreatedByName = oUserDetails.UserName + " (" + oUserDetails.UserId + ")";
				this.getView().getModel("localModel").getData().oNewServicePlan.ProjectName = oProjectDetails.ProjectName;
				this.getView().getModel("localModel").getData().oNewServicePlan.ProjectID = oProjectDetails.ProjectID;
				this.getView().getModel("localModel").refresh();
				oDialog.open();
			});
		},

		fnOnShowInfoForServicePlan: function (oEvent) {
			const oPopOverSource = oEvent.getSource();
			const sSelectedSPPath = oEvent.getSource().getBindingContext("draftPlansModel").sPath;

			this._pPopoverInfoServicePlan ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.fragments.InfoServicePlan");
			this._pPopoverInfoServicePlan.then(oPopover => {
				oPopover.bindElement({
					path: 'draftPlansModel>' + sSelectedSPPath
				});
				if (oPopover.sServicePlan !== sSelectedSPPath) {
					oPopover.close();
					oPopover.sServicePlan = sSelectedSPPath;
				}
				oPopover.openBy(oPopOverSource);
			});
		},

		fnOnEditServicePlanHeader: function (oEvent) {
			const sSelectedSPPath = oEvent.getSource().getBindingContext("draftPlansModel").sPath,
				oSelectedSP = this.getView().getModel("draftPlansModel").getProperty(sSelectedSPPath);
			this.getView().getModel("localModel").getData().oServicePlanDummyForEdit = JSON.parse(JSON.stringify(oSelectedSP)); // oSelectedSP;
			this.getView().getModel("localModel").refresh();

			this._pDialogEditServicePlanHeader ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.fragments.EditServicePlanHeader");
			this._pDialogEditServicePlanHeader.then(oDialog => oDialog.open());
		},

		fnOnCopyServicePlan: function (oEvent) {
			const sSelectedSPPath = oEvent.getSource().getBindingContext("draftPlansModel").sPath,
				oSelectedSP = this.getView().getModel("draftPlansModel").getProperty(sSelectedSPPath);
			this.getView().getModel("localModel").getData().oCopyTemplateServicePlan = oSelectedSP;
			this.getView().getModel("localModel").refresh();

			this._pDialogCopyServicePlan ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.fragments.CopyServicePlan");
			this._pDialogCopyServicePlan.then(oDialog => {
				const oCurrentItem = this.getView().getModel("localModel").getData().oCopyTemplateServicePlan,
					oProjectDetails = this.getView().getModel("localModel").getData().projectDetails,
					oUserDetails = this.getOwnerComponent().getModel("appData").getData().oCrmUserData;
				this.getView().getModel("localModel").getData().oNewServicePlan = {};
				this.getView().getModel("localModel").getData().oNewServicePlan.IDOfSourceSPD = oCurrentItem.SpGuid;
				this.getView().getModel("localModel").getData().oNewServicePlan.Name = "Copy of " + oCurrentItem.Name;
				this.getView().getModel("localModel").getData().bServicePlanNameEntered = true;
				this.getView().getModel("localModel").getData().oNewServicePlan.Description = "Copy of " + oCurrentItem.Description;
				this.getView().getModel("localModel").getData().oNewServicePlan.StartDate = oProjectDetails.ProjectStarDate;
				this.getView().getModel("localModel").getData().oNewServicePlan.EndDate = oProjectDetails.ProjectEndDate;
				this.getView().getModel("localModel").getData().oNewServicePlan.CreatedBy = oUserDetails.name;
				this.getView().getModel("localModel").getData().oNewServicePlan.CreatedByName = oUserDetails.displayName;
				this.getView().getModel("localModel").getData().oNewServicePlan.CaseID = oProjectDetails.ProjectID;
				this.getView().getModel("localModel").getData().oNewServicePlan.CaseGUID = oProjectDetails.ProjectGUID;
				this.getView().getModel("localModel").getData().oNewServicePlan.CaseName = oProjectDetails.ProjectName;
				this.getView().getModel("localModel").refresh();
				oDialog.open();
			});
		},

		fnOnDeleteServicePlan: function (oEvent) {
			const sSelectedSPPath = oEvent.getSource().getBindingContext("draftPlansModel").sPath,
				oSelectedSP = this.getView().getModel("draftPlansModel").getProperty(sSelectedSPPath);

			MessageBox.confirm(this.getResourceBundle().getText("ProjectSPD.Delete.Confirm.Content", [
				oSelectedSP.Name
			]), {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				emphasizedAction: MessageBox.Action.YES,
				onClose: (sAction) => {
					if (sAction === "YES") {
						this._fnDeleteServicePlanInBE(oSelectedSP, this);
					}
				}
			});
		},

		fnOnServicePlanNameLiveChange: function (oEvent) {
			this.getView().getModel("localModel").getData().bServicePlanNameEntered = oEvent.getParameter("newValue") !== "";
			this.getView().getModel("localModel").refresh();
		},

		//******************************************************************************************
		//******************************* Popover INFO Servivce Plan *******************************

		_getSSCPackageURL: function (oData) {
			let oFocusPackageFromSSC = {};
			const aValidUsedPackages = [];
			let iCounter = 0;
			oData.results.forEach(oUsedPackage => {
				// check the code received from BE is belonging to a FP in SSC
				oFocusPackageFromSSC = this.getView().getModel("focusPackages").getData().allPackages.find(({
					code
				}) => code === oUsedPackage.PackageCode);
				if (oFocusPackageFromSSC) {
					aValidUsedPackages.push(oFocusPackageFromSSC);
				}
			});
			// enrich data for all valid FP
			aValidUsedPackages.forEach(oPackage => {
				iCounter++;
				oPackage.LinkText = `${iCounter}. [${oPackage.code}] - ${oPackage.name}`;
				oPackage.PackageUrl = oPackage.url;
			});
		},

		//******************************************************************************************
		//************************ Dialog CREATE a New Servivce Plan *******************************

		fnHandleCreateNewServicePlanBtnCreate: function () {
			this.getView().getModel("localModel").getData().busyNewServicePlanCreate = true;
			this.getView().getModel("localModel").refresh();
			const oCreateNewServicePlanPayload = {
				"CaseGuid": this.getModel("localModel").getData().projectDetails.ProjectGUID,
				"Name": this.getView().getModel("localModel").getData().oNewServicePlan.Name,
				"Description": this.getView().getModel("localModel").getData().oNewServicePlan.Description,
				"ProcessType": "ZSP1",
				"Status": "DRAFT",
				"ResponsibleUsID": this.getOwnerComponent().getModel("appData").getData().oCrmUserData.UserId
			};
			const entities = {};
			const oBus = this.getOwnerComponent().getEventBus();
			entities.servicePath = Constants.getServicePathSPD();
			entities.entitySet = Constants.getEntities().ServicePlanHeaderSet;
			entities.data = oCreateNewServicePlanPayload;
			entities.currentView = this.getView();
			entities.oContext = this._parentView;
			entities.busyIndicators = "busyNewServicePlanCreate";
			entities.errorMessage = this.getResourceBundle().getText("ProjectDetails.CreateSPError");
			entities.callbackSuccess = (oData) => {
				this.getView().getModel("draftPlansModel").getData().items.push(oData);
				this.getView().getModel("draftPlansModel").refresh();
				this._pDialogCreateNewServicePlan.then(oDialog => oDialog.close());
				this.getView().getModel("localModel").getData().oSelectedDraftPlan = oData;
				this.getView().getModel("localModel").getData().bExecutionPlanFocused = false; //now one of the Draft Plans is highlighted
				this.getView().getModel("localModel").refresh();
				oBus.publish("ChannelServicePlanSection", "DraftPlanFocused", this.getView().getModel("localModel").getData());
			};
			this.createBaseRequest(entities);

		},

		setBusyToFalse: function () {
			this.getView().getModel("localModel").getData().busyNewServicePlanCreate = false;
			this.getView().getModel("localModel").refresh();
		},

		fnHandleCreateNewServicePlanBtnCancel: function () {
			this.getView().getModel("localModel").getData().oNewServicePlan = {};
			this.getView().getModel("localModel").refresh();
			this._pDialogCreateNewServicePlan.then(oDialog => oDialog.close());
		},

		//******************************************************************************************
		//****************************** Dialog EDIT a Servivce Plan *******************************

		fnHandleEditServicePlanHeaderBtnSave: function () {
			this.getView().getModel("localModel").getData().busyServicePlanEdit = true;
			this.getView().getModel("localModel").refresh();
			const entities = {},
				dataForUpdate = {
					"Name": this.getView().getModel("localModel").getData().oServicePlanDummyForEdit.Name,
					"Description": this.getView().getModel("localModel").getData().oServicePlanDummyForEdit.Description
				};
			entities.servicePath = Constants.getServicePathSPD();
			entities.entitySet = "ServicePlanHeaderSet(guid'" +
				this.getView().getModel("localModel").getData().oServicePlanDummyForEdit.SpGuid + "')";
			entities.currentView = this.getView();
			entities.oContext = this._parentView;
			entities.data = dataForUpdate;
			entities.errorMessage = this.getResourceBundle().getText("ProjectSPD.Edit.Error");
			entities.busyIndicator = "busyServicePlanEdit";
			entities.callbackSuccess = () => {
				this._pDialogEditServicePlanHeader.then(oDialog => oDialog.close());
				this.getView().getModel("localModel").getData().busyServicePlanEdit = false;
				this.getView().getModel("localModel").refresh();
				this._fnLoadDraftServicePlansFromBE();
			};
			this.updateBaseRequest(entities);
		},

		fnHandleEditServicePlanHeaderBtnCancel: function () {
			this._pDialogEditServicePlanHeader.then(oDialog => oDialog.close());
		},

		//******************************************************************************************
		//****************************** Dialog COPY a Servivce Plan *******************************

		fnHandleCopyServicePlanBtnCopy: function () {
			this.getView().getModel("localModel").getData().busyServicePlanCopy = true;
			this.getView().getModel("localModel").refresh();
			const entities = {};

			entities.servicePath = Constants.getServicePathSPD();
			entities.function = "CopyServicePlan";
			entities.currentView = this.getView();
			entities.oContext = this._parentView;
			entities.method = "POST";
			entities.urlParameters = {
				"SpGuid": this.getView().getModel("localModel").getData().oNewServicePlan.IDOfSourceSPD,
				"NewCaseGuid": this.getView().getModel("localModel").getData().oNewServicePlan.CaseGUID,
				"NewSPName": this.getView().getModel("localModel").getData().oNewServicePlan.Name,
				"NewResponsible": this.getOwnerComponent().getModel("appData").getData().oCrmUserData.UserId,
				"NewDescription": this.getView().getModel("localModel").getData().oNewServicePlan.Description
			};
			entities.errorMessage = this.getResourceBundle().getText("ProjectSPD.Copy.Error");
			entities.busyIndicator = "busyServicePlanCopy";
			entities.callbackSuccess = (oData) => {
				if (oData.CaseGuid === this.getView().getModel("localModel").getData().projectDetails.ProjectGUID) {
					this.getView().getModel("draftPlansModel").getData().items.push(oData);
					this.getView().getModel("draftPlansModel").refresh();
				}
				this._pDialogCopyServicePlan.then(oDialog => oDialog.close());

				this.getView().getModel("localModel").getData().busyServicePlanCopy = false;
				this.getView().getModel("localModel").refresh();
			};
			this.callFunction(entities);
		},

		fnHandleCopyServicePlanBtnCancel: function () {
			this.getView().getModel("localModel").getData().oNewServicePlan = {};
			this.getView().getModel("localModel").refresh();
			this._pDialogCopyServicePlan.then(oDialog => oDialog.close());
		},

		//----------------- VH Project Trigger  ----------------------------------------------------------
		fnOnProjectSelectionVHTrigger: function (oEvent) {
			const oResourceBundle = this.getResourceBundle();
			const oView = this.getView();
			const oDestinationModel = this.getView().getModel("localModel");
			const oDestModelPathObject = this.getView().getModel("localModel").getData().oNewServicePlan;

			// the user selects a project in the popup and this is written into the model in the property names, that are handed over here
			ProjectSelection.fnOnProjectSelectionDialogOpen(oView, oResourceBundle, oDestinationModel, oDestModelPathObject, "CaseID",
				"CaseGUID", "CaseName");
		},

		//******************************************************************************************
		//********************************* Delete Servicer Plan ***********************************

		_fnDeleteServicePlanInBE: function (oSPSelected) {
			const sSPSelectedCreatedByName = oSPSelected.Created,
				sSPSelectedCreatedByID = oSPSelected.Created,
				sSPSelectedName = oSPSelected.Name,
				sSpGuid = oSPSelected.SpGuid,
				sSPSelectedstatus = oSPSelected.Status;

			const entities = {};
			this.getView().getModel("localModel").getData().busyServicePlanSelector = true;
			this.getView().getModel("localModel").refresh();
			entities.servicePath = Constants.getServicePathSPD();
			entities.entitySet = "ServicePlanHeaderSet(guid'" + oSPSelected.SpGuid + "')";
			entities.errorMessage = this.getResourceBundle().getText("ProjectDetails.DeleteNotesError", [
				sSPSelectedCreatedByName, sSPSelectedCreatedByID, sSPSelectedName, sSPSelectedstatus
			]);
			entities.currentView = this.getView();
			entities.oContext = this._parentView;
			entities.busyIndicator = "busyServicePlanSelector";
			entities.callbackSuccess = (data) => {
				MessageToast.show(this.getResourceBundle().getText("SPDDetails.SuccessDeleteServicePlan"));
				const oSPData = this.getView().getModel("draftPlansModel").getData().items;
				const filteredData = oSPData.filter(sp => sp.SpGuid !== sSpGuid);
				this.getView().getModel("draftPlansModel").getData().items = filteredData;
				this.getView().getModel("draftPlansModel").refresh();

				this.getView().getModel("localModel").getData().busyServicePlanSelector = false;
				this.getView().getModel("localModel").refresh();

				//after the deletion of a service plan, the execution plan is focused
				this.fnOnExecutionPlanFocused();

			};
			this.deleteBaseRequest(entities);
		}

	});
});
