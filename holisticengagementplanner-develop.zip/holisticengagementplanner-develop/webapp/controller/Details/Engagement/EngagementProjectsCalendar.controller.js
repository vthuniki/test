sap.ui.define([
	"com/sap/ui/hep/controller/Details/BaseDetails",
	"sap/ui/model/json/JSONModel",
	"sap/gantt/misc/Format",
	"sap/gantt/misc/Utility",
	"com/sap/ui/hep/reuse/BaseRequest",
	"com/sap/ui/hep/reuse/Constants",
	"sap/ui/core/Core",
	"sap/ui/core/EventBus",
	"com/sap/ui/hep/model/formatter"
], function (BaseDetails, JSONModel, Format, Utility, BaseRequest, Constants, Core, EventBus, Formatters) {
	"use strict";

	return BaseDetails.extend("com.sap.ui.hep.controller.Details.Engagement.EngagementProjectsCalendar", {

		_fnCreateUid: sap.ui.require("sap/base/util/uid"),
		formatter: Formatters,

		onAfterRendering: function () {
			if (this.aAllRowsFiltered) {
				this._fnAdjustDesignOfVisibleShapes();
				document.defaultView.addEventListener("resize", () => {
					//like this we have "this" available in the event handler
					this._fnCreateBoxAroundFocusedQuarter(); //after screen resizing - for strange reason this is sometime not calling the gantt-renderComplete handler!?
				});
			}
		},

		fnHandleGanttRenderComplete: function () {
			if (this.aAllRowsFiltered) {
				this._fnAdjustDesignOfVisibleShapes();
				this._fnCreateBoxAroundFocusedQuarter(); //after every rendering
			}
		},

		_fnCreatePromisesToGetTheData: function () {
			//create a promise to get the projectsArrangement from BE
			this.aArrangementData = null;
			this._pGetProjectsArrangementFromBE = new Promise(fnRes => {
				const entities = {
					servicePath: Constants.getServicePath(),
					entitySet: `EngagementMapSet(CaseId='${this.sParentEngagementId}')`,
					callbackSuccess: (oArrangementDataBE) => {
						try {
							this.aArrangementData = JSON.parse(oArrangementDataBE.Map);
							fnRes();
						} catch (oErr) {
							fnRes();
						}
					}
				};
				this.readBaseRequest(entities);
			});

			//create a promise to get all projects without any filter (will be resolved when the eventbus-handler "this._fnHandleProjectsUnfilteredAreLoadedFromBE" is called)
			this._oAllProjectsUnfilteredLoadedPromiseExecutor = {};
			this._pAllProjectsUnfilteredLoaded = new Promise(fnResolve => {
				this._oAllProjectsUnfilteredLoadedPromiseExecutor.fnResolve = fnResolve;
			});
		},

		onInit: function () {
			//listen to eventBus-events
			const eventBus = EventBus.getInstance();
			eventBus.subscribe("Engagements", "engagementViewControllerLoaded", this._fnHandleEngagementViewControllerLoaded, this);
			eventBus.subscribe("Engagements", "relatedProjectsFilteredLoaded", this._fnHandleProjectsFilteredAreLoadedFromBE, this);
			eventBus.subscribe("Engagements", "relatedProjectsUnfilteredLoaded", this._fnHandleProjectsUnfilteredAreLoadedFromBE, this);

			//init time axis strategy for gantt char
			let _oMyTLOs = this.getView().byId("idEngagementProjectGanttChartWithTable").getAxisTimeStrategy().getTimeLineOptions();
			for (let elm in _oMyTLOs) {
				_oMyTLOs[elm].innerInterval.range = 91;
				_oMyTLOs[elm].innerInterval.span = 1;
				_oMyTLOs[elm].innerInterval.unit = "d3.time.month";
				_oMyTLOs[elm].largeInterval.format = "yyyyq";
				_oMyTLOs[elm].largeInterval.span = 3;
				_oMyTLOs[elm].largeInterval.unit = "d3.time.month";
				delete _oMyTLOs[elm].largeInterval.pattern;
				_oMyTLOs[elm].smallInterval.span = 3;
				_oMyTLOs[elm].smallInterval.pattern = " ";
				_oMyTLOs[elm].smallInterval.unit = "d3.time.month";
			}
			this.getView().byId("idEngagementProjectGanttChartWithTable").getAxisTimeStrategy().setTimeLineOptions(_oMyTLOs);

			//initialize local Model
			let oLocalData = {
				oVisibleArea: {
					sStartTime: null,
					sEndTime: null,
					dStartTime: null,
					dEndTime: null
				}
			};
			this.oLocalModel = new JSONModel(oLocalData);
			this.getView().setModel(this.oLocalModel);

			//focus the visible area to today's date
			this._fnCalculateVisibleAreaForToday();
			let bSuppressAdjustEmptyRows = true; //still in the initialization: there are no rows yet
			this._fnAdjustCalendarBtnLabelAndEmptyRows(bSuppressAdjustEmptyRows);
		},

		//______________________________________________________________________________________________________________________
		//______________________________________________________________________________________________________________________
		//_____________________________________________								 ___________________________________________
		//_____________________________________________      Eventbus Handler        ___________________________________________
		//______________________________________________________________________________________________________________________
		//______________________________________________________________________________________________________________________

		/**
		 * we want to inject this class in the EngagementDetails-controller, so that it is avaialable there and the
		 * buttons there are able to trigger methods here, so we emit an event to the eventBus, that the engagementDetails-controller listens to...
		 * also we define already some properties and start loading the projectsArrangement-string from BE.
		 * (So we later do not have to wait for it, when it is actually needed)
		 */
		_fnHandleEngagementViewControllerLoaded: function (sChannel, sEvent, oData) { //triggered from EngagementDetails-controller
			EventBus.getInstance().publish("Engagements", "ganttViewControllerInitialized", this);
			this.oParentEngagementDetailsController = oData;
			this.sParentEngagementId = oData._idProject;
			this._fnCreatePromisesToGetTheData(); //so that promises to get data are known, and consumers can attach to them, and eventBus-Handler can resolve them....
		},

		/**
		 * we have created the promise for getting the unfiltered list of all projects related to the engagement from the BE already in the init-method
		 * so consumers can already attach to it but it is still pending....
		 * However, when this method is triggered via eventBus, it gets the complete unfiltered list of all projects related to the engagement via input parameter oData.
			 * With this it builds the basis "row-array" for this module, taking also a saved projectsArrangement into account
		 * This basis array we build here, contains then rows, and in each row "shapes", which represent the projects in the gantt-chart terminology.
		 * For each shape the basic setting are defined
		 * Once all this is done, we trigger saving this build array as the new arrangement in the BE.
		 * This is needed, because the "old" arrangement might not be correct any more, i.e. if
		 *  - new projects were created in the meanwhile
		 *  - existing projects might have a changed start- or end-date, so that they now might be overlapping and need to moved into a new line
		 *
		 * Finally, we can set the promise to resolved, by calling the resolve-method to inform potential consumers, that they can continue...
		 */
		_fnHandleProjectsUnfilteredAreLoadedFromBE: function (sChannel, sEvent, oData) { //triggered from EngagementDetails-controller
			this.aAllRowsUnfiltered = [];

			// first, build a temporary array as a basis, with simply one row for each project
			const aRowsTemp = oData.map(oProject => ({
   				iId: this._fnCreateUid(),
				aShapes: [ {
					oProjectDetails: oProject,
					sTitle: oProject.ProjectName,
					dStartTime: oProject.ProjectStartDate,
					dEndTime: oProject.ProjectEndDate,
					sProjectId: oProject.ProjectID,
					sClass: this.formatter.getCustomerProjectClasses(oProject.SapInvolvement),
					dStartTimeEndArrow: this._fnShiftDateByDays(oProject.ProjectEndDate, -5),
					bEndArrowVisible: false,
					dStartTimeStartArrow: this._fnShiftDateByDays(oProject.ProjectStartDate, 5),
					bStartArrowVisible: false,
					dStartTimeText: this._fnShiftDateByDays(oProject.ProjectStartDate, 2),
				}]
   			}));

			// check if there is an arrangement available for this enagement and if not just use the tempArray, but if yes consider the arrangmenet-information
			this._pGetProjectsArrangementFromBE.then(() => {
				if (!this.aArrangementData) {
					this.aAllRowsUnfiltered = aRowsTemp;
				}
				else {
					this._fnHelperBuildAllRowsUnfilteredArrayBasedOnGivenArrangementInformations(aRowsTemp);
				}
			});

			// resolve the related promise, so that consumers can start....
			this._oAllProjectsUnfilteredLoadedPromiseExecutor.fnResolve();
		},

		//helper function to build the aAllRowsUnfiltered-Array based on given Arrangement-information
		//four steps are done to build the array and save the new arrangement-information to BE, in case something was changed
		_fnHelperBuildAllRowsUnfilteredArrayBasedOnGivenArrangementInformations: function (aRowsTemp) {
			let bChangesToArrangementDone = false;
			//step 1)
			//create as many rows in the new array, as defined in the existing arrangement
			this.aArrangementData.map(() => {
				this.aAllRowsUnfiltered.push({
					aShapes: [],
					iId: this._fnCreateUid()
				});
			});
			// step 2)
			// the temp-array contains all projects, that we want to have in the final array.
			// But not all of them might exist in the arrangement-array - and there migth also be projects in the arrangement-array, that are not in the temp-array (any more).
			// So we go through the temp-array and try to put each project from there into the right row of the final-array, according the given arrangement-array.
			aRowsTemp.forEach(row => {
				let iRowOfArrangement = this.aArrangementData.findIndex(r => r.aShapes.find(s => s === row.aShapes[0].sProjectId));
				if (iRowOfArrangement >= 0) {
					//project is found in the arrangement-array - put it into the row where it belongs
					this.aAllRowsUnfiltered[iRowOfArrangement].aShapes.push(row.aShapes[0]);
				} else {
					bChangesToArrangementDone = true;
					//project is not found in the arrangement-array - create a new row at the end and put it there
					this.aAllRowsUnfiltered.push({
						aShapes: [row.aShapes[0]],
						iId: this._fnCreateUid()
					});
				}
			});
			this.aAllRowsUnfiltered.filter(elm => elm.aShapes.length > 0); //remove all rows, that stayed empty, because temp-array does not contain the projects, that according to arrangement-array should be in that row

			// step 3)
			// projects from the arrangement could have been changed in the meanwhile in a way, that now they overlap with other projects in the same row
			// so need to check for each row if something is overlapping now, and if yes, create a new row below and move the overlapping project there
			// if this adjustment has to be done at least once, we also save that new arrangement secretly in the BE.
			let aRowsTemp2 = [];
			this.aAllRowsUnfiltered.forEach(oRow => {
				if (this._fnCheckAreIntervalsOverlapping(oRow.aShapes)) {
					bChangesToArrangementDone = true;
					this._fnCreateRowsForOverlappersInRow(oRow, aRowsTemp2);
				} else {
					aRowsTemp2.push(oRow);
				}
			});
			this.aAllRowsUnfiltered = aRowsTemp2;

			// step 4)
			// in case some changes to the arrangement that is currently persisted in BE needed to be done, we save the updated row-array as new arrangement
			// so BE is up to date
			if (bChangesToArrangementDone) {
				let aConfigurationToSave = [];
				this.aAllRowsUnfiltered.forEach(oRow => {
					let aShapesToSaveInRow = [];
					oRow.aShapes.forEach(oShape => aShapesToSaveInRow.push(oShape.sProjectId));
					let oRowForSave = {
						aShapes: aShapesToSaveInRow
					};
					aConfigurationToSave.push(oRowForSave);
				});
				let sConfigToSave = JSON.stringify(aConfigurationToSave);

				//prepare BE call to save
				let entities = {
					servicePath: Constants.getServicePath(),
					entitySet: "EngagementMapSet",
					data: {
						"CaseId": this.sParentEngagementId,
						"Map": sConfigToSave
					},
					currentView: this.oParentEngagementDetailsController.getView(),
					oContext: this.oParentEngagementDetailsController,
					errorMessage: "Tried to save Configuration, but something went wrong",
					callbackSuccess: () => {
						//do nothing, save happens only in background
					}
				};
				BaseRequest.handleCreate(entities);
			}
		},

		_fnCreateRowsForOverlappersInRow: function (oRow, aAllNewRows) {
			let oNewRow = {
				aShapes: [],
				iId: this._fnCreateUid()
			};
			aAllNewRows.push(oNewRow);

			let oTempRow = { //this row is a collector for all overlappers. It will be handled in next recursion
				aShapes: [],
				iId: this._fnCreateUid()
			};

			//put all shapes in the new Row, if not posible put them into the tempRow
			oRow.aShapes.forEach(oShape => {
				if (this._fnCheckAreIntervalsOverlapping(oNewRow.aShapes.concat([oShape]))) {
					oTempRow.aShapes.push(oShape);
				} else {
					oNewRow.aShapes.push(oShape);
				}
			});

			if (oTempRow.aShapes.length > 0) {
				//if we had to move something in the temp row, that has to be organized now as well
				this._fnCreateRowsForOverlappersInRow(oTempRow, aAllNewRows);
			}
		},

		/**
		 * we have to wait until the projects for the engagement are loaded from the EngagementDetails-controller to really start up...
		 * when this is done, this method here is triggered via the eventBus and builds the array with all projects, that should be available in DISPLAY mode.
		 * For this, it uses the array with the unfiltered list of projects as a basis. So it needs to wait for it...
		 * The input parameter "oData" contains the list of projects that apply to the currently set filter.
		 * Taking this into account, it creates the new filtered array, by taking the unfiltered array as a basis, but only those projecxts, that are available in oData
		 */
		_fnHandleProjectsFilteredAreLoadedFromBE: function (sChannel, sEvent, oData) { //triggered from EngagementDetails-controller
			this._pAllProjectsUnfilteredLoaded.then(() => {
				//build the array that serves as basis for the Gantt-chart in Display mode
				//...first create a new array with the same amout of empty rows
				this.aAllRowsFiltered = [];
				this.aAllRowsUnfiltered.forEach(() => {
					this.aAllRowsFiltered.push({
						aShapes: [],
						iId: this._fnCreateUid()
					});
				});

				//...then go through projects that have been found for the users current filter settings and look if it is in the unfiltered array
				//   and if it is there, then put it into the same row of the filtered array
				oData.forEach(oProject => {
					this.aAllRowsUnfiltered.forEach((oRow, iRowIndex) => {
						let oFoundShape = oRow.aShapes.find(oShape => oShape.sProjectId === oProject.ProjectID);
						if (oFoundShape) this.aAllRowsFiltered[iRowIndex].aShapes.push(oFoundShape);
					});
				});

				//..to clean up,  remove all rows that now do not contain any shapes any more a
				this.aAllRowsFiltered = this.aAllRowsFiltered.filter(oRow => oRow.aShapes.length !== 0);

				this._fnSetScreenModeAndEmptyRows("Display");
				this._fnAdjustCalendarBtnLabelAndEmptyRows();
				this._fnAdjustDesignOfVisibleShapes();
			});
		},

		//______________________________________________________________________________________________________________________
		//______________________________________________________________________________________________________________________
		//_____________________________________________								 ___________________________________________
		//_____________________________________________       Little Helpers         ___________________________________________
		//______________________________________________________________________________________________________________________
		//______________________________________________________________________________________________________________________

		/**
		 * Shift a given date by given amount of days (can also be negative)
		 *  @param {date} dDate - date to be shifted (is not changed!!)
		 *  @param {number} iDaysToShift - number of days to be shifted (can also be negative)
		 *  @return {date} - new resulting shifted date
		 */
		_fnShiftDateByDays: function (dDate, iDaysToShift) {
			return new Date(new Date(dDate).setDate(new Date(dDate).getDate() + iDaysToShift));
		},

		/**
		 * check if at least two shapes from the array are "overlapping", or if a shape "overlaps" with the selected time range
		 * (which means it is visible, at least a part of it)
		 * "Overlapping" of two objects means that one object includes at least one day, that is within the start- and end-date of another object
		 *    @param {array} aShapes - array of objects, each object represents a "shape", with start-and end-date
		 *    @return {boolean} - true, if some shapes are overlapping, otherwise false
		 */
		_fnCheckAreIntervalsOverlapping: function (aShapes) {
			//the difficulty is, that shapes of long projects that continue ouside the currently selected time range (visible area), could
			//overlap in the not visible range with another project.
			//But the shapes of these long projects are shortened, so that they start at the first day of the selected time range bzw. end
			//at the last day of the visible time range - so their dStartDate and dEndDate properties might not be the same like those of the
			//project, they represent.
			//So for the comparision, in order to decide, if they overlap or not, we have to considert their real-dates:
			//create a new array for comparing that can be messed up - deep copy
			let aCompare = Object.values($.extend(true, {}, aShapes));
			aCompare.forEach(oShape => {
				oShape.dStartTime = oShape.oProjectDetails ? oShape.oProjectDetails.ProjectStartDate : oShape.dStartTime;
				oShape.dEndTime = oShape.oProjectDetails ? oShape.oProjectDetails.ProjectEndDate : oShape.dEndTime;
			});

			aCompare.sort((a, b) => (a.dStartTime > b.dStartTime) - (a.dStartTime < b.dStartTime)); //array needs to be sorted
			let i, j;
			for (i = 0; i < aCompare.length - 1; i++) {
				for (j = i + 1; j < aCompare.length; j++) {
					if ((aCompare[i].dStartTime <= aCompare[j].dEndTime) && (aCompare[j].dStartTime <= aCompare[i].dEndTime)) {
						return true;
					}
				}
			}
			return false;
		},

		//______________________________________________________________________________________________________________________
		//______________________________________________________________________________________________________________________
		//_____________________________________________								 ___________________________________________
		//_____________________________________________        Main Stuff            ___________________________________________
		//______________________________________________________________________________________________________________________
		//______________________________________________________________________________________________________________________

		_fnCreateBoxAroundFocusedQuarter: function (evt) {
			let _fnPaintTheBox = () => {
				try {
					$("[id$='idEngagementProjectGanttChartWithTable-header-svg'] > g > rect").remove(); //first remove any old box, in case it exists

					let iLeftX = null;
					let iRightX = null;
					let sCalBtnLabelFormatted = "Q" + Math.floor((new Date().getMonth() + 3) / 3) + " " + new Date().getFullYear();
					let iQuarterTextX = parseFloat($("text.sapGanttTimeHeaderSvgText:contains('" + sCalBtnLabelFormatted + "')").attr("x"));
					let aPath = $(
						"[id$='idEngagementProjectGanttChartWithTable-header-svg'] > g:not(.sapGanttNowLineHeaderSvgPath, .sapGanttChartHeaderSelection) > path.sapGanttTimeHeaderLargeIntervalSvgPath"
					).attr("d").split(" ");
					aPath.forEach((elm, index) => {
						if (elm === "M" && parseFloat(aPath[index + 1]) < iQuarterTextX) iLeftX = parseFloat(aPath[index + 1]);
						if (!iRightX && elm === "M" && parseFloat(aPath[index + 1]) > iQuarterTextX) iRightX = parseFloat(aPath[index + 1]);
					});
					let height = $("[id$='idEngagementProjectGanttChartWithTable-header-svg']").attr("height").slice(0, -2);
					if (iLeftX && iRightX && height) {
						/* eslint-disable sap-no-element-creation */
						let myRect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
						/* eslint-enable sap-no-element-creation */
						myRect.setAttribute("x", iLeftX + 2);
						myRect.setAttribute("y", 1.5);
						myRect.setAttribute("width", iRightX - iLeftX - 5);
						myRect.setAttribute("height", parseFloat(height - 5));
						/* eslint-disable sap-no-hardcoded-color */
						myRect.setAttribute("style", "stroke: #c0399f; stroke-width: 1; fill: transparent");
						/* eslint-enable sap-no-hardcoded-color */
						/* eslint-disable sap-no-dom-insertion */
						$(
							"[id$='idEngagementProjectGanttChartWithTable-header-svg'] > g:not(.sapGanttNowLineHeaderSvgPath, .sapGanttChartHeaderSelection)"
						)[0].appendChild(myRect);
						/* eslint-enable sap-no-dom-insertion */
					}

				} catch (err) {
					// do nothing
				}
			};

			_fnPaintTheBox(); //first try directly, so there is no delay for the user....

			//do grafical css stuff to gantt-elements after UI-Framework is done with its manipulations
			/* eslint-disable sap-timeout-usage */
			setTimeout(() => {
				_fnPaintTheBox(); //in case it has not worked directly :-)
				if (this.oLocalModel.getData().bDisplayMode) {
					$('[data-sap-gantt-shape-id]').css("cursor", "pointer"); //assign hand-pointer to all shapes when in Display Mode
				}
			}, 1000);
			/* eslint-enable sap-timeout-usage */
		},

		/**
		 * set the label for the "calendar button" (i.e. "Q4, 2022").
		 */
		_fnAdjustCalendarBtnLabelAndEmptyRows: function (bSuppressAdjustEmptyRows) {
			let iFocusYear = parseInt(this.oLocalModel.getData().oVisibleArea.sStartTime.substring(0, 4), 10); // first guess, later correct it, if not good.
			let iFocusQuarter = Math.floor((parseInt(this.oLocalModel.getData().oVisibleArea.sStartTime.substring(4, 6), 10) + 2) / 3) +
				1;
			if (iFocusQuarter === 5) {
				iFocusYear++;
				iFocusQuarter = 1;
			}
			this.oLocalModel.getData().sQuarterPickerBtnLabel = "Q" + iFocusQuarter + ", " + iFocusYear;
			this.oLocalModel.refresh();

			if (!bSuppressAdjustEmptyRows) this._fnAdjustEmptyRows();
		},

		/**
		 * Set the controller property "this.bDisplayMode" to either "Display" or "Rearrange".
		 * In Dispplay-mode rows should not have any border, but in Rearrange-mode the should in order facilitate draggin and dropping.
		 * For this behavior we toggle a style-class "rearrangeMode" (which is defined in style.css-file)
		 * When the user switches mode we additinally have to take care of the empty rows, we need some fo dragging and dropping in Rearrange-mode and remove all in Display mode
		 *
		 *   @param {string} sMode - only "Display" and "Rearrange" are allowed values
		 */
		_fnSetScreenModeAndEmptyRows: function (sMode) {
			sMode = ["Display", "Rearrange"].includes(sMode) ? sMode : "Display"; //only "Display" and "Rearrange" are allowed, if other set to "Display"

			if (sMode === "Display") {
				this.getView().byId("idEngagementProjectGanttChartWithTable").removeStyleClass("rearrangeMode");
				this.oLocalModel.getData().bDisplayMode = true;
			} else {
				this.getView().byId("idEngagementProjectGanttChartWithTable").addStyleClass("rearrangeMode");
				this.oLocalModel.getData().bDisplayMode = false;
			}
			this._fnAdjustEmptyRows();
		},

		/**
		 * Taking care of the empty rows (in aVisibleRows):
		 * In Display mode: We need to recalculate which rows are visible for the currently selected time range
		 *  	If a row does not have any project in the currently selected time range, we filter out that row
		 * In Rearrange mode: there has to be at least one emtpy row at the end (for Drag&Drop).
		 *		Maybe even more rows are needed at the end because Gantt-UI-Control fills all screen-space at the end with empty UI-rows.
		 *		These UI-rows need also model-rows behind them, in order that Drag&Drop works
		 */
		_fnAdjustEmptyRows: function () {
			if (this.oLocalModel.getData().bDisplayMode) {
				//determine aVisibleRows freshly from allRows, by taking only those rows, that have a least one shape in the selected time range of the gantt-chart
				this.oLocalModel.getData().aVisibleRows = [];
				this.aAllRowsFiltered.forEach(oRow => {
					let bVisibleShapeFoundInRow = false;
					oRow.aShapes.forEach(oShape => {
						if (this._fnCheckAreIntervalsOverlapping([oShape, this.oLocalModel.getData().oVisibleArea]))
							bVisibleShapeFoundInRow = true;
					});
					if (bVisibleShapeFoundInRow) this.oLocalModel.getData().aVisibleRows.push(oRow);
				});

			} else {
				//adjust empty rows - remove any empty row from the end of the model, in order to be in a clearly defined state, for the next steps....
				while (this.oLocalModel.getData().aVisibleRows[this.oLocalModel.getData().aVisibleRows.length - 1].aShapes.length === 0)
					this.oLocalModel.getData().aVisibleRows.pop();

				//...adding one empty row at the end of the model, for droping shapes there... (after the model refresh, the UI also shows the new row)
				this.oLocalModel.getData().aVisibleRows.push({
					aShapes: [],
					iId: this._fnCreateUid()
				});
				this.oLocalModel.refresh();

				//...adding more rows to the end of the model, one for each further UI-row that Gantt-Controll has created to fill space on screen
				let iUIRows = this.getView().byId("idEngagementProjectGanttChartWithTable").getTable().getRows().length;
				for (let i = this.oLocalModel.getData().aVisibleRows.length; i < iUIRows - 1; i++) {
					this.oLocalModel.getData().aVisibleRows.push({
						aShapes: [],
						iId: this._fnCreateUid()
					});
				}
			}
			this.oLocalModel.refresh();
		},

		/**
		 * - For all shapes in the visible area, we have to check the appeareance and maybe adjust it:
		 * -   (i.e. 1. small arrows and begin or end, if the shape continues outside the visible date range
		 * -         2. show projects smaller than 80px without border, but with color gradient AND enlarged to 80px
		 */
		_fnAdjustDesignOfVisibleShapes: function () {
			//go over the visible rows and adjust the design of all shapes of each row
			//   Shapes of these rows, even if they are not visible currently are also adjusted - but this does not matter. Too much effort to exclude them
			//   Please notice, that the changes done to a shape of aVisibleRows, are implicitely also present in allRows
			//      (Because both are arrays of row-objects - only that not all row-objects from allRows are contained in aVisibleRows, but a change to such a row-object
			//       is independent for the array, that was used to access it)
			//
			//3.1. First requirement for the design is, that the gantt-shapes of projects with a very short runtime are not so small that the user cannot
			//     read the project-title. So it is defined, that every shape should be shown with at least 80px and in order that the user notices this,
			//     that the shape is artificially shown larger than the project in reallity is, those shapes are to be shown without stroke (border)
			//
			//3.2. Second requirement for the design is, that projects that cross the time range borders, are displayed with an arrow either on the
			//	   left side of the shape, pointing to the left, in order to indicate the project is starting already before the current time range - or/and with
			//     an arrow at the end of the shape, pointing to the right, in order to indicate the project is continueing over the end of the current time range.
			//     To realize this, we need to artificially "shorten" the shape, that represents the project, in order to achieve the following:
			//		- in case the project starts already earlier, the user would not see the colored bold left border line of the shape and would
			//  	  also not see the title of the project
			//         --> so we need to set the starttime of the shape to the start date of the visible time frame and show an arrow to the left, before the title
			//      - in case the project ends after the enddate of the visible time frame, the user would not know, because for him it looks like
			//        it ends, where the timeframe ends.
			//         --> so we need to set the endtime of the shape to the end date of the visible time frame, and show an arrow to the right, at the end of the shape...! (possible?)

			//gantt-chart shows always 1 year, so we can calulate how many pixels belong to a single day, by deviding the gantt-chart-width by 365
			let _iPixelForOneDay = parseInt($("[id$='idEngagementProjectGanttChartWithTable-ganttSyncedControlTable']").css("width")
				.slice(0, -2), 10) / 365;

			if (_iPixelForOneDay) {
				let _iDaysToShiftText = 15 / _iPixelForOneDay; //should start 10px after shape begin (because of colored small bar, that is shown on the left side of each project)
				let _iDaysToShiftBeginArrow = 20 / _iPixelForOneDay; //should start 20px after shape-begin
				let _iDaysToShiftEndArrow = -15 / _iPixelForOneDay; //should start 15px before shape-end

				this.oLocalModel.getData().aVisibleRows.forEach(oRow => {
					oRow.aShapes.forEach(oShape => {
						//set shape properties to "normal" values
						oShape.dStartTime = oShape.oProjectDetails.ProjectStartDate;
						oShape.dStartTimeText = this._fnShiftDateByDays(oShape.dStartTime, _iDaysToShiftText);
						oShape.dEndTime = oShape.oProjectDetails.ProjectEndDate;
						oShape.bStartArrowVisible = false;
						oShape.dStartTimeStartArrow = this._fnShiftDateByDays(oShape.dStartTime, _iDaysToShiftBeginArrow);
						oShape.bEndArrowVisible = false;

						//only do any adjustment to the shape, if it is actually in the visible area, according to its original dates
						if (this._fnCheckAreIntervalsOverlapping([oShape, this.oLocalModel.getData().oVisibleArea])) {

							//3.1.) adjust shape, if it is shorter than 80px ->make it 80px, but change design by applying a .short class
							if (Math.round(oShape.dEndTime - oShape.dStartTime) / 1000 / 60 / 60 / 24 * _iPixelForOneDay < 80) {
								oShape.dEndTime = this._fnShiftDateByDays(oShape.dStartTime, (80 / _iPixelForOneDay)); // new end time!
								oShape.sClass = this.formatter.getCustomerProjectClasses(oShape.oProjectDetails.SapInvolvement) + " short";
								oShape.sGradient = this.getView().byId(this.formatter.getCustomerProjectGradient(oShape.oProjectDetails.SapInvolvement)).getId();
							}

							//these properties we could not set before, because dEndTime might have changed
							oShape.nTextTruncateWidth = Math.round(oShape.dEndTime - oShape.dStartTimeText) / 1000 / 60 / 60 / 24 * _iPixelForOneDay;
							oShape.dStartTimeEndArrow = this._fnShiftDateByDays(oShape.dEndTime, _iDaysToShiftEndArrow);

							//3.2.) adjust shape, if not completely visible, because of the currently visible area
              				this._fnHelperAdjustShapeIfNotCompletelyVisibleBecauseOfTheCurrentlyVisibleArea(oShape, _iDaysToShiftBeginArrow, _iDaysToShiftText, _iPixelForOneDay, _iDaysToShiftEndArrow);
						}
					});
				});
			}
			this.oLocalModel.refresh();
			// when screen is visible, no project should be already internally "selected" - other the "onSelectedChanged"-Event
			// does not trigger for that event (because the "shapePressed"-event is not working well for some strange reason
			// we need to use the "selectionChanged"-event instead... :-()
			this.getView().byId("idEngagementProjectGanttChartWithTable").deselectShapes(this.getView().byId("idEngagementProjectGanttChartWithTable").getSelectedShapeUid());
		},

		_fnHelperAdjustShapeIfNotCompletelyVisibleBecauseOfTheCurrentlyVisibleArea: function (oShape, _iDaysToShiftBeginArrow, _iDaysToShiftText, _iPixelForOneDay, _iDaysToShiftEndArrow) {
			if (this._fnCheckAreIntervalsOverlapping([oShape, this.oLocalModel.getData().oVisibleArea])) {
				if (oShape.dStartTime < this.oLocalModel.getData().oVisibleArea.dStartTime) { //shape starts earlier than visible area...
					oShape.dStartTime = this.oLocalModel.getData().oVisibleArea.dStartTime;
					oShape.bStartArrowVisible = true;
					oShape.dStartTimeStartArrow = this._fnShiftDateByDays(oShape.dStartTime, _iDaysToShiftBeginArrow);
					oShape.dStartTimeText = this._fnShiftDateByDays(oShape.dStartTimeStartArrow, _iDaysToShiftText);
					oShape.nTextTruncateWidth = Math.round(oShape.dEndTime - oShape.dStartTimeText) / 1000 / 60 / 60 / 24 * _iPixelForOneDay;
				}
				if (oShape.oProjectDetails.ProjectEndDate > this.oLocalModel.getData().oVisibleArea.dEndTime) { //shape ends later than visible area... (shape enlargement is considered!!)
					oShape.dEndTime = this.oLocalModel.getData().oVisibleArea.dEndTime;
					oShape.bEndArrowVisible = true;
					oShape.dStartTimeEndArrow = this._fnShiftDateByDays(oShape.dEndTime, _iDaysToShiftEndArrow);
					oShape.nTextTruncateWidth = Math.round(oShape.dEndTime - oShape.dStartTimeText) / 1000 / 60 / 60 / 24 * _iPixelForOneDay - 30;
				}
			}
		},

		//______________________________________________________________________________________________________________________
		//______________________________________________________________________________________________________________________
		//_____________________________________________								 ___________________________________________
		//_____________________________________________         Event Handler        ___________________________________________
		//______________________________________________________________________________________________________________________
		//______________________________________________________________________________________________________________________

		_fnCalculateVisibleAreaForToday: function () {
			let dToday = new Date();
			let iCurrentYear = dToday.getFullYear();
			let iCurrentQuarter = Math.floor((dToday.getMonth() + 3) / 3);
			switch (iCurrentQuarter) {
				case 1:
					this.oLocalModel.getData().oVisibleArea.sStartTime = iCurrentYear - 1 + "1001000000";
					this.oLocalModel.getData().oVisibleArea.sEndTime = iCurrentYear + "0930235959";
					break;
				case 2:
					this.oLocalModel.getData().oVisibleArea.sStartTime = iCurrentYear + "0101000000";
					this.oLocalModel.getData().oVisibleArea.sEndTime = iCurrentYear + "1231235959";
					break;
				case 3:
					this.oLocalModel.getData().oVisibleArea.sStartTime = iCurrentYear + "0401000000";
					this.oLocalModel.getData().oVisibleArea.sEndTime = iCurrentYear + 1 + "0331235959";
					break;
				case 4:
					this.oLocalModel.getData().oVisibleArea.sStartTime = iCurrentYear + "0701000000";
					this.oLocalModel.getData().oVisibleArea.sEndTime = iCurrentYear + 1 + "0630235959";
					break;
			}
			this.oLocalModel.getData().oVisibleArea.dStartTime = Format.abapTimestampToDate(this.oLocalModel.getData().oVisibleArea.sStartTime);
			this.oLocalModel.getData().oVisibleArea.dEndTime = Format.abapTimestampToDate(this.oLocalModel.getData().oVisibleArea.sEndTime);
			this.oLocalModel.refresh();
		},

		fnHandleBtnTodayPress: function (oEvent) {
			this._fnCalculateVisibleAreaForToday();
			this._fnAdjustCalendarBtnLabelAndEmptyRows();
			this._fnAdjustDesignOfVisibleShapes();
		},

		fnHandleBtnPreviousQuarterPress: function (oEvent) {
			let sCurrentStartDate = this.oLocalModel.getData().oVisibleArea.sStartTime;
			let sCurrentEndDate = this.oLocalModel.getData().oVisibleArea.sEndTime;
			switch (sCurrentStartDate.substring(4, 6)) {
				case "01":
					//StartDate: 20220101 -> 20211001
					this.oLocalModel.getData().oVisibleArea.sStartTime = parseInt(sCurrentStartDate.substring(0, 4), 10) - 1 + "1001000000";
					this.oLocalModel.getData().oVisibleArea.sEndTime = sCurrentEndDate.replace("1231", "0930");
					break;
				case "04":
					this.oLocalModel.getData().oVisibleArea.sStartTime = sCurrentStartDate.replace("0401", "0101");
					//EndDate: 20220331 -> 20211231
					this.oLocalModel.getData().oVisibleArea.sEndTime = parseInt(sCurrentEndDate.substring(0, 4), 10) - 1 + "1231235959";
					break;
				case "07":
					this.oLocalModel.getData().oVisibleArea.sStartTime = sCurrentStartDate.replace("0701", "0401");
					this.oLocalModel.getData().oVisibleArea.sEndTime = sCurrentEndDate.replace("0630", "0331");
					break;
				case "10":
					this.oLocalModel.getData().oVisibleArea.sStartTime = sCurrentStartDate.replace("1001", "0701");
					this.oLocalModel.getData().oVisibleArea.sEndTime = sCurrentEndDate.replace("0930", "0630");
					break;
			}
			this.oLocalModel.getData().oVisibleArea.dStartTime = Format.abapTimestampToDate(this.oLocalModel.getData().oVisibleArea.sStartTime);
			this.oLocalModel.getData().oVisibleArea.dEndTime = Format.abapTimestampToDate(this.oLocalModel.getData().oVisibleArea.sEndTime);
			this._fnAdjustCalendarBtnLabelAndEmptyRows();
			this._fnAdjustDesignOfVisibleShapes();
		},

		fnHandleBtnNextQuarterPress: function (oEvent) {
			let sCurrentStartDate = this.oLocalModel.getData().oVisibleArea.sStartTime;
			let sCurrentEndDate = this.oLocalModel.getData().oVisibleArea.sEndTime;
			switch (sCurrentStartDate.substring(4, 6)) {
				case "01":
					this.oLocalModel.getData().oVisibleArea.sStartTime = sCurrentStartDate.replace("0101", "0401");
					//EndDate: 20221231 -> 20230331
					this.oLocalModel.getData().oVisibleArea.sEndTime = parseInt(sCurrentEndDate.substring(0, 4), 10) + 1 + "0331235959";
					break;
				case "04":
					this.oLocalModel.getData().oVisibleArea.sStartTime = sCurrentStartDate.replace("0401", "0701");
					this.oLocalModel.getData().oVisibleArea.sEndTime = sCurrentEndDate.replace("0331", "0630");
					break;
				case "07":
					this.oLocalModel.getData().oVisibleArea.sStartTime = sCurrentStartDate.replace("0701", "1001");
					this.oLocalModel.getData().oVisibleArea.sEndTime = sCurrentEndDate.replace("0630", "0930");
					break;
				case "10":
					//StartDate: 20221001 -> 20230101
					this.oLocalModel.getData().oVisibleArea.sStartTime = parseInt(sCurrentStartDate.substring(0, 4), 10) + 1 + "0101000000";
					this.oLocalModel.getData().oVisibleArea.sEndTime = sCurrentEndDate.replace("0930", "1231");
					break;
			}
			this.oLocalModel.getData().oVisibleArea.dStartTime = Format.abapTimestampToDate(this.oLocalModel.getData().oVisibleArea.sStartTime);
			this.oLocalModel.getData().oVisibleArea.dEndTime = Format.abapTimestampToDate(this.oLocalModel.getData().oVisibleArea.sEndTime);
			this._fnAdjustCalendarBtnLabelAndEmptyRows();
			this._fnAdjustDesignOfVisibleShapes();
		},

		fnHandleBtnQuarterPickerPress: function (evt) {
			let oSource = evt.getSource();
			//load the popover fragment, in case it is not loaded yet
			this._pPopoverQuarterPicker ??= this._loadFragment("com.sap.ui.hep.view.Details.Engagement.fragment.PopoverQuarterPicker");
			this._pPopoverQuarterPicker.then(oPopover => {
				oPopover.openBy(oSource);
				//set year range of quarterPicker and highlight focused quarters
				let iCurrentYear = new Date().getFullYear();
				this._fnSetQuarterPickerTimeRange(iCurrentYear);
			});
		},

		fnHandleOpenLegend: function (oEvent) {
			let oButton = oEvent.getSource();

			this._pLegendPopover ??= this._loadFragment("com.sap.ui.hep.view.Details.Engagement.fragment.PopoverLegendProjectCalendar");
			this._pLegendPopover.then(oPopover => oPopover.openBy(oButton));
		},

		fnHandleShapeMouseEnter: function (oEvent) {
			let oSourceShape = oEvent.getParameter("shape");
			this.oLocalModel.getData().selectedProjectDetails = this.oLocalModel.getProperty(oSourceShape.getBindingContext().getPath()).oProjectDetails;
			this.oLocalModel.refresh();

			//load the popover fragment, in case it is not loaded yet
			this._pPopoverInfoProject ??= this._loadFragment("com.sap.ui.hep.view.Details.Engagement.fragment.PopoverInfoProjectDetails");
			this._pPopoverInfoProject.then(oPopover => oPopover.openBy(oSourceShape));
		},

		fnHandleShapeMouseLeave: function (oEvent) {
			let oShapeCoordinates = Core.byId(oEvent.getParameter("shape").getId()).$()[0].getBoundingClientRect();
			let oMouseCoordinates = sap.gantt.simple.CoordinateUtils.getLatestCursorPosition();
			if (oShapeCoordinates.left < oMouseCoordinates.pageX && oMouseCoordinates.pageX < oShapeCoordinates.right &&
				oShapeCoordinates.top < oMouseCoordinates.pageY && oMouseCoordinates.pageY < oShapeCoordinates.bottom) {
				// mouse still in the shape, do not close the popup - instead fire the mouseEnter-Event again.
				// Thisis important, otherwise this MouseLeave-Event is not fired any more, even when the mouse really leaves the shape
				// .... (for understanding see in sap/gantt/simple/BaseShape.js in onmouseout-event-handler, where private property bShapeMouseEnterFired is checked....
				oEvent.getParameter("shape").getGanttChartBase().fireShapeMouseEnter({
					shape: oEvent.getParameter("shape"),
					pageX: oMouseCoordinates.pageX,
					pageY: oMouseCoordinates.pageY
				});
			} else this._pPopoverInfoProject?.then(oPopover => oPopover.close());
		},

		/**
		 * the button "Re-Arrange Projects" is placed on the Engagements-Controllers-View. But because this controller is known by the
		 * EngagementsDetails.controller, it can call the handler method placed in this controller
		 * When Rearrange-Mode is entered, the user will be changing the assignment of shapes to rows and create/delete new rows
		 */
		fnHandleReArrangeProjectsPressed: function () { //called from EngagementDetails.controller
			//backup the current situation for if user wants to cancel
			this.aTempAllRowsBackup = Object.values($.extend(true, {}, this.aAllRowsUnfiltered)); //deep copy as backup
			//basically the user has now to options to leave the re-arrange mode. One is to cancel - then we use this backup, to restore the
			//situation before he entered re-arrange mode (In re-arrange morde the Unfiltered-array is the basis for the manipulations of the visible rows, the user might do)
			//second option is to save - then we save the new arrangement in BE and refresh the gantt-chart by reloading everything (projects and arrangement) from BE

			this.oLocalModel.getData().aVisibleRows = Array.from(this.aAllRowsUnfiltered); //shallow copy to have everything available in gantt
			this._fnSetScreenModeAndEmptyRows("Rearrange");
			this._fnAdjustDesignOfVisibleShapes(); //could be we get a scrollbar and shape design needs to be recalculated

			//this is needed for a better refesh of the Gantt-Chart... otherwise the little arrow at the end of a project, that contiunues outside the visible area,
			//migth be hidden due to a missplaced vertical scroll-bar  - no idea why, but this helps
			this.fnHandleBtnNextQuarterPress();
			this.fnHandleBtnPreviousQuarterPress();
		},

		/**
		 * there are some cases to distinguish
		 * 1. user drops it into a free space in the target line
		 * 2. user drops it into the target line, but there it is overlapping with a shape that is already there - But the dragging mouse pointer is NOT touching that shape.
		 * 3. user drops it into the target line, but there it is overlapping with a shape that is already there - AND the dragging mouse pointer is touching that shape.
		 * For our use cases there is no difference between cases 2 and 3, but the incomming event parameter are differently fillted, so in coding we need to handle both approriately
		 *
		 * However, in cases 2 and 3, we need to move existing shapes, in order to free the space for the droping shape.
		 * In order to achieve this, we insert a NEW row, where the user wants to drop the shape, and move the row with the bothering shape one row down, out of the way.
		 * (By this also all below rows will be moved one row down - which will result in a vertical scrollbar, because of the additional row.
		 *  Then, in case this scrollbar would actually not be required, because there is more than one empty row at the end, we have to remove one of these empty rows, to get rid of the scrollbar.
		 *  .... but ONE empty row always has to be avialable at the end, in case the user wants to drop something at the end of the list)
		 */
		fnHandleShapeDrop: function (oEvent) {
			let oSourceShapeInfo = Utility.parseUid(oEvent.getParameter("lastDraggedShapeUid")),
				oSourceShape = this.oLocalModel.getProperty(oSourceShapeInfo.shapeDataName),
				oSourceRow = this.oLocalModel.getData().aVisibleRows.find(elm => elm.iId === oSourceShapeInfo.rowPath);

			oSourceShape.bMoving = true; //set a flag to find the moving shape later easily

			if (oEvent.getParameter("targetRow")) {
				//the mousepointer is NOT targeted over an existing shape.... but still the moving shape itself could overlap somehow with an existing shape in that row
				let oTargetRow = this.oLocalModel.getProperty(oEvent.getParameter("targetRow").getBindingContext().getPath());

				if (oTargetRow.iId !== oSourceRow.iId) {
					//create shape in target row and check if it fits there without overlapping with any shape that is already there
					oTargetRow.aShapes.push(oSourceShape);
					if (!this._fnCheckAreIntervalsOverlapping(oTargetRow.aShapes)) {
						//no overlapping in target row with the new shape! fine! just remove it form the source row and delete the moving flag
						oSourceRow.aShapes = oSourceRow.aShapes.filter(elm => !elm.bMoving);
						delete oSourceShape.bMoving;
					} else {
						//overlapping in target row!!! - so insert a new row for the moving shape for dropping it there (this moves all other rows one down!)
						let iTargetRow = this.oLocalModel.getData().aVisibleRows.findIndex(elm => elm.iId === oTargetRow.iId);
						this.oLocalModel.getData().aVisibleRows.splice(iTargetRow, 0, {
							aShapes: [oSourceShape],
							iId: this._fnCreateUid()
						});
						//now -remove the moving shape from the source row, but -remove it also from the original target row, where it was only placed for testing if it is overlapping there,
						//because now it is in a completely new now and -delete the moving flag and -check if we can remove an uncessary empty row from the end, in order to have no unecessary scrollbar
						oSourceRow.aShapes = oSourceRow.aShapes.filter(elm => !elm.bMoving);
						oTargetRow.aShapes = oTargetRow.aShapes.filter(elm => !elm.bMoving);
						delete oSourceShape.bMoving;
					}
				}

			} else if (oEvent.getParameter("targetShape")) {
				//the mousepointer is targeted over an existing shape - so the user has positioned the moving shape over another shape in the target row
				//so insert a new row for the moving shape for dropping it there (this moves all other rows one down!)
				let iTargetRow = this.oLocalModel.getData().aVisibleRows.findIndex(elm => elm.iId === Utility.parseUid(oEvent.getParameter(
					"targetShape").getProperty("shapeUid")).rowPath);
				this.oLocalModel.getData().aVisibleRows.splice(iTargetRow, 0, {
					aShapes: [oSourceShape],
					iId: this._fnCreateUid()
				});
				//now -remove the moving shape from the source row and -delete he moving flag and -check if we can remove an uncessary empty row from the end, in order to have no unecessary scrollbar
				oSourceRow.aShapes = oSourceRow.aShapes.filter(elm => !elm.bMoving);
				delete oSourceShape.bMoving;
			}

			this._fnAdjustEmptyRows(); //so that there is always at least one empty row at the end, and additionally in case there are empty UI-rows visible, also for each an empty model row

			//fixing strange UI-Framework behavior...
			//...for unknown reason the next shape of the source row is automatically selected by framework - so we remove any selection here!
			this.getView().byId("idEngagementProjectGanttChartWithTable").selectShapes([], true);
			//...krass, but the following is necessary that Gantt-chart does not hide and show shapes randomly when vertical scrolling after having droped shapes on other shapes
			this.oLocalModel.getData().aVisibleRowsTemp = Array.from(this.oLocalModel.getData().aVisibleRows);
			this.oLocalModel.getData().aVisibleRows = [];
			this.oLocalModel.refresh();
			this.oLocalModel.getData().aVisibleRows = Array.from(this.oLocalModel.getData().aVisibleRowsTemp);
			delete this.oLocalModel.getData().aVisibleRowsTemp;
			this.oLocalModel.refresh();

			this.fnHandleBtnNextQuarterPress();
			this.fnHandleBtnPreviousQuarterPress();
			this._fnCreateBoxAroundFocusedQuarter();
		},

		/**
		 * Button "Delete" needed as a helper for Develpopment - show or hide according to your need....
		 */
		fnHandleDeleteProjectsArrangementPressed: function () { //called from EngagementDetails.controller
			return new Promise((res, rej) => {
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "EngagementMapSet(CaseId='" + this.sParentEngagementId + "')";
				entities.currentView = this.oParentEngagementDetailsController.getView();
				entities.oContext = this.oParentEngagementDetailsController;
				entities.errorMessage = "Tried to delete Configuration, but something went wrong";
				entities.busyIndicator = "busySaveEngagementProjectsCalendar";
				entities.callbackSuccess = () => {
					res();
				};
				BaseRequest.handleDelete(entities);
			});
		},

		/**
		 * the button "Save" is placed on the Engagements-Controllers-View (Objectpage Footer). But because this controller is known by the
		 * EngagementsDetails.controller, it can call the handler method placed in this controller
		 *
		 * When the user presses the button, the current situation in allRows is taken as the basis to build an array of all
		 * rows, with an array of all all projectIds in that row. This is saved as a string in BE.
		 * (When the user opens later the engagement, that string is retrieved and evaluated against the project that currently part of the engagement)
		 */
		fnHandleSaveProjectsArrangementPressed: function () { //called from EngagementDetails.controller
			return new Promise((resolve, reject) => {

				//get rid off empty rows
				this.oLocalModel.getData().aVisibleRows = this.oLocalModel.getData().aVisibleRows.filter(oRow => oRow.aShapes.length !== 0);

				//prepare the configuration string that we want to save
				let aConfigurationToSave = [];
				this.oLocalModel.getData().aVisibleRows.forEach(oRow => {

					let aShapesToSaveInRow = [];
					oRow.aShapes.forEach(oShape => {
						aShapesToSaveInRow.push(oShape.sProjectId);
					});
					let oRowToSave = {
						aShapes: aShapesToSaveInRow
					};
					aConfigurationToSave.push(oRowToSave);
				});
				let sConfigurationToSave = JSON.stringify(aConfigurationToSave);

				//prepare BE call to save
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "EngagementMapSet";
				entities.data = {
					"CaseId": this.sParentEngagementId,
					"Map": sConfigurationToSave
				};
				entities.currentView = this.oParentEngagementDetailsController.getView();
				entities.oContext = this.oParentEngagementDetailsController;
				entities.errorMessage = "Tried to save Configuration, but something went wrong";
				entities.callbackSuccess = (oData) => {
					sap.m.MessageToast.show("Project arrangement saved");
					this._fnTriggerRefreshProjects();
					resolve();
				};
				BaseRequest.handleCreate(entities);

			});
		},

		_fnTriggerRefreshProjects: function () {
			this._fnCreatePromisesToGetTheData();
			EventBus.getInstance().publish("Engagements", "refreshProjectList", this);
		},

		/**
		 * the button "Cancel" is placed on the Engagements-Controllers-View (Objectpage Footer). But because this controller is known by the
		 * EngagementsDetails.controller, it can call the handler method placed in this controller
		 */
		fnHandleCancelProjectsArrangementPressed: function () { //called from EngagementDetails.controller
			//restore the original situation from before the user pressed the Rearrange-button
			this.aAllRowsUnfiltered = Object.values($.extend(true, {}, this.aTempAllRowsBackup)); //deep copy to get back the original situation
			this._fnSetScreenModeAndEmptyRows("Display");
			this._fnAdjustDesignOfVisibleShapes(); //next to other things, this will also recalculate  aVisibleRows

			//this is needed for a better refesh of the Gantt-Chart... otherwise the place, where the vertical scorllbar was that might have been there in Rearrange-mode,
			//is still displayed strangely, but not the scrollbar itself - no idea, why, but this helps
			this.fnHandleBtnNextQuarterPress();
			this.fnHandleBtnPreviousQuarterPress();
		},

		/**
		 * When the user clicks on a projectBox in Display, we want to navigate to that project.
		 * However, for some reason the "shapePress"-event is not triggered well. So we use the "shapeSelectionChange"
		 * event, as we have set the gantt-chart to SelectionMode=Single, the first click on a projectBox already is
		 * inperpreted as a selectionChange and we can trigger tha navigation to it.
		 */
		fnHandleShapeSelectionChange: function (oEvent) {
			if (this.oLocalModel.getData().bDisplayMode) {
				if (oEvent.getParameter("shapeUids") && oEvent.getParameter("shapeUids").length !== 0) {
					let oSourceShapeInfo = Utility.parseUid(oEvent.getParameter("shapeUids")[0]);
					let oSourceShape = this.oLocalModel.getProperty(oSourceShapeInfo.shapeDataName);
					this._pPopoverInfoProject?.then(oPopover => oPopover.close());
					this.getRouter().navTo("ProjectDetails", {
						projectID: oSourceShape.sProjectId
					});
				}
			}
		},

		//______________________________________________________________________________________________________________________
		//______________________________________________________________________________________________________________________
		//_____________________________________________					             ___________________________________________
		//_____________________________________________     Quarter Picker Popover   ___________________________________________
		//______________________________________________________________________________________________________________________
		//______________________________________________________________________________________________________________________

		_fnSetQuarterPickerTimeRange: function (iFocusYear) {
			this.oLocalModel.getData().quarterPicker = {};
			this.oLocalModel.getData().quarterPicker.year0 = iFocusYear - 1;
			this.oLocalModel.getData().quarterPicker.year1 = iFocusYear;
			this.oLocalModel.getData().quarterPicker.year2 = iFocusYear + 1;
			this.oLocalModel.getData().quarterPicker.year3 = iFocusYear + 2;
			this.oLocalModel.refresh();
			//highlight the currently visible quarters, in case they are in the year range
			this._fnQuarterPickerEmphasizeFocusedQuarters();
		},

		_fnQuarterPickerEmphasizeFocusedQuarters: function () {
			let iQuarter = Math.floor((parseInt(this.oLocalModel.getData().oVisibleArea.sStartTime.substring(4, 6), 10) + 2) / 3);
			let iQuarterIndex = iQuarter === 4 ? 0 : iQuarter;

			let iYearIndex = parseInt(this.oLocalModel.getData().oVisibleArea.sStartTime.substring(0, 4), 10) -
				parseInt(this.oLocalModel.getData().quarterPicker.year0, 10);
			if (iQuarterIndex === 0) iYearIndex++;

			this._fnHelperCleanCurrentEmphazisingBeforeEmphaziceNewQuarter(); //clear current emphazising from screen

			//emphasize the selected Qarter
			let sSelector = "";
			sSelector = "[id$='year" + iYearIndex + "q" + iQuarterIndex + "']";
			$(sSelector).addClass("quarterPickerQuarterEmphazised");
			//find and light-emphazise the previous Quarter
			if (iQuarterIndex === 0) {
				if (iYearIndex !== 0) {
					sSelector = "[id$='year" + (iYearIndex - 1) + "q3']";
					$(sSelector).addClass("quarterPickerQuarterEmphazisedLight");
				}
			} else {
				sSelector = "[id$='year" + iYearIndex + "q" + (iQuarterIndex - 1) + "']";
				$(sSelector).addClass("quarterPickerQuarterEmphazisedLight");
			}

			//find and emphasize next quarter
			if (iQuarterIndex === 3) {
				if (iYearIndex !== 3) {
					sSelector = "[id$='year" + (iYearIndex + 1) + "q0']";
					$(sSelector).addClass("quarterPickerQuarterEmphazisedLight");
				}
			} else {
				sSelector = "[id$='year" + iYearIndex + "q" + (iQuarterIndex + 1) + "']";
				$(sSelector).addClass("quarterPickerQuarterEmphazisedLight");
			}

			//find and emphasize over-next quarter
			if (iQuarterIndex > 1) {
				if (iYearIndex !== 3) {
					sSelector = "[id$='year" + (iYearIndex + 1) + "q" + (iQuarterIndex + 2) % 4 + "']";
					$(sSelector).addClass("quarterPickerQuarterEmphazisedLight");
				}
			} else {
				sSelector = "[id$='year" + iYearIndex + "q" + (iQuarterIndex + 2) + "']";
				$(sSelector).addClass("quarterPickerQuarterEmphazisedLight");
			}

		},

		//helper method to clean current emphazising from screen
		_fnHelperCleanCurrentEmphazisingBeforeEmphaziceNewQuarter: function () {
			let sSelector = "";
			for (let iY = 0; iY < 4; iY++) {
				for (let jQ = 0; jQ < 4; jQ++) {
					sSelector = "[id$='year" + iY + "q" + jQ + "']";
					$(sSelector).removeClass("quarterPickerQuarterEmphazisedLight");
					$(sSelector).removeClass("quarterPickerQuarterEmphazised");
				}
			}
		},

		fnHandleQuarterPickerQuarterPress: function (evt) {
			this._pPopoverQuarterPicker.then(oPopover => oPopover.close());

			let iQuarter = parseInt(evt.getParameter("id").split("year")[1].slice(2, 3), 10);
			let iYearIndex = parseInt(evt.getParameter("id").split("year")[1].slice(0, 1), 10);
			let iYear = parseInt(this.oLocalModel.getData().quarterPicker["year" + iYearIndex], 10);

			//set time range of gantt to selected quarter(s)
			let sMonthDayStart = "";
			let sMonthDayEnd = "";
			let iYearStart = iYear;
			let iYearEnd = iYear;
			switch (iQuarter) {
				case 0:
					sMonthDayStart = "1001";
					sMonthDayEnd = "0930";
					iYearStart = iYear - 1;
					break;
				case 1:
					sMonthDayStart = "0101";
					sMonthDayEnd = "1231";
					break;
				case 2:
					sMonthDayStart = "0401";
					sMonthDayEnd = "0331";
					iYearEnd = iYear + 1;
					break;
				case 3:
					sMonthDayStart = "0701";
					sMonthDayEnd = "0630";
					iYearEnd = iYear + 1;
					break;
			}
			this.oLocalModel.getData().oVisibleArea.sStartTime = iYearStart + sMonthDayStart + "000000";
			this.oLocalModel.getData().oVisibleArea.sEndTime = iYearEnd + sMonthDayEnd + "235959";
			this.oLocalModel.getData().oVisibleArea.dStartTime = Format.abapTimestampToDate(this.oLocalModel.getData().oVisibleArea.sStartTime);
			this.oLocalModel.getData().oVisibleArea.dEndTime = Format.abapTimestampToDate(this.oLocalModel.getData().oVisibleArea.sEndTime);
			this._fnAdjustCalendarBtnLabelAndEmptyRows();
			this._fnAdjustDesignOfVisibleShapes();
		},

		fnHandleBtnQuarterPickerPreviousYearPress: function () {
			let iCurrentlyFocusedYear = this.oLocalModel.getData().quarterPicker.year1;
			this._fnSetQuarterPickerTimeRange(iCurrentlyFocusedYear - 1);
		},

		fnHandleBtnQuarterPickerNextYearPress: function () {
			let iCurrentlyFocusedYear = this.oLocalModel.getData().quarterPicker.year1;
			this._fnSetQuarterPickerTimeRange(iCurrentlyFocusedYear + 1);
		}
	});
});
