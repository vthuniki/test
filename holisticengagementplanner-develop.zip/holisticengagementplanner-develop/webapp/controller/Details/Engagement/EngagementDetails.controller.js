sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"com/sap/ui/hep/model/formatter",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"com/sap/ui/hep/util/ServiceOrderManipulation",
	"com/sap/ui/hep/util/ReferenceObjects",
	"com/sap/ui/hep/util/Attachments",
	"com/sap/ui/hep/util/Notes",
	"com/sap/ui/hep/util/Dates",
	"com/sap/ui/hep/util/EmployeeDetails",
	"com/sap/ui/hep/util/MessageHandlingPopover",
	"sap/ui/export/Spreadsheet",
	"com/sap/ui/hep/controller/Details/BaseDetails",
	"com/sap/ui/hep/util/Pagination",
	"com/sap/ui/hep/util/TablePersoActivities",
	"com/sap/ui/hep/util/TablePersoLinkedObjects",
	"com/sap/ui/hep/util/TablePersoCustomerProjects",
	"com/sap/ui/hep/util/TablePersoEngagementScope",
	"sap/m/TablePersoController",
	"com/sap/ui/hep/util/EngagementContracts",
	"com/sap/ui/hep/controller/Project/CreateProjectDialog",
	"com/sap/ui/hep/util/NavigationToExternalApps",
	"com/sap/ui/hep/util/engagementSelection/EngagementSelection",
	"com/sap/ui/hep/util/Variant",
	"com/sap/ui/hep/util/EngagementScope",
	"sap/ui/model/Sorter",
	"com/sap/ui/hep/controller/Engagement/EditEngagementDialog",
	"sap/m/Dialog",
	"sap/m/ProgressIndicator",
	"com/sap/ui/hep/util/employeeSelection/EmployeeSelection",
	"sap/m/FormattedText",
	"sap/m/Button",
	"com/sap/ui/hep/util/URLValidator",
	"com/sap/ui/hep/reuse/Constants",
	"com/sap/ui/hep/util/FilterHelper",
	"sap/ui/core/EventBus"
], function (JSONModel, Formatters,
	MessageToast, MessageBox, ServiceOrderManipulation, ReferenceObjects, Attachments, Notes, Dates,
	EmployeeDetails, MessageHandlingPopover, Spreadsheet,
	BaseDetails, Pagination, TablePersoActivities, TablePersoLinkedObjects,
	TablePersoCustomerProjects, TablePersoEngagementScope, TablePersoController, EngagementContracts, CreateProjectDialog,
	NavigationToExternalApps,
	EngagementSelection, Variant, EngagementScope, Sorter, EditEngagementDialog,
	Dialog, ProgressIndicator, EmployeeSelection, FormattedText, Button, URLValidator, Constants, FilterHelper, EventBus) {

	"use strict";
	return BaseDetails.extend("com.sap.ui.hep.controller.Details.Engagement.EngagementDetails", {
		formatter: Formatters,
		soManipulation: ServiceOrderManipulation,
		referenceObjects: ReferenceObjects,
		attachments: Attachments,
		notes: Notes,
		dates: Dates,
		employeeDetails: EmployeeDetails,
		messageHandler: MessageHandlingPopover,
		pagination: Pagination,
		variant: Variant,
		engagementScope: EngagementScope,
		urlValidator: URLValidator,
		_oCreateProjectDialog: new CreateProjectDialog,
		_oEditEngagementDialog: new EditEngagementDialog,

		/* ============================================= General ==================================================== */

		onInit: function () {
			this.router = this.getRouter();
			this.router.getRoute("EngagementDetails").attachPatternMatched(this._handleRouteMatched, this);
			this.router.getRoute("EngagementDetailsTab").attachPatternMatched(this._handleRouteMatched, this);
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			this.getView().byId("projectsSectionSS1").addEventDelegate({
				onAfterRendering: function () {
					setTimeout(function () {
						this.getView().byId("projectsSectionSS1").focus();
					}.bind(this), 500);
				}.bind(this)
			});
			this.urlValidator.initValidUrl(this);
		},

		_handleRouteMatched: function (evt) {
			this._dataFromBus = false;
			this._initialize();
			this._idProject = this._idProject = evt.getParameters().arguments.engagementID;
			let moveToTab = evt.getParameters().arguments.toTab;
			let _oView = this.getView();
			let _oContext = this;

			this._readDataForAllSections();

			_oContext.sIdTabInURL = _oView.createId("projectsSection");
			_oView.byId("ObjectPageLayoutEngagement").setSelectedSection(_oContext.sIdTabInURL);
			_oContext.sIdTabInURL = "";

			let _aValidTabKeys = ["AssignedContracts"];
			let oQuery = evt.getParameter("arguments")["?query"];
			if (oQuery && _aValidTabKeys.indexOf(oQuery.tab) > -1) {
				if (oQuery.tab === "AssignedContracts") this.sIdTabInURL = this.getView().createId("contractsSection");
			}

			this.getOwnerComponent().getEventBus().subscribe("SOSendDeliveryENG", "soSendToDeliveryENG", this.fnAfterSendToDelivery, this);
			const eventBus = EventBus.getInstance();
			eventBus.subscribe("Engagements", "ganttViewControllerInitialized", this._fnHandleGanttViewControllerInitialized, this);
			eventBus.subscribe("Engagements", "refreshProjectList", this._fnRefreshProjectList, this);
			eventBus.publish("Engagements", "engagementViewControllerLoaded", this);

			if (moveToTab && moveToTab === 'ToParties') {
				MessageBox.alert(this.getView().getModel("i18n").getResourceBundle().getText("EngagementDetails.MsgBox.MoveToParties"), {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					title: this.getView().getModel("i18n").getResourceBundle().getText("EngagementDetails.MsgBox.MoveToPartiesTitle"),
					emphasizedAction: MessageBox.Action.OK,
					onClose: function (sAction) {
						if (sAction === 'OK') {
							// Move to Tab "parties involved"
							_oContext.sIdTabInURL = _oView.createId("partnerSection");
							_oView.byId("ObjectPageLayoutEngagement").setSelectedSection(_oContext.sIdTabInURL);
							_oContext.sIdTabInURL = "";
						}
					}
				});
			}
		},

		_fnHandleGanttViewControllerInitialized: function (sChannel, sEvent, oGanttController) {
			this.GanttViewController = oGanttController;
		},

		_initialize: function () {
			this.initializeModelsAndLocalData(this);
			this.getView().getModel("localModel").getData().bIsInRearrangeMode = false;
			this.getView().getModel("localModel").refresh();

			// New Version of popup - KNGMHM02-23694
			this.partiesInvolved.init(this);

			this.activateBusyIndicators(this);
			this.attachments.initializeDetails(this);
			this._oModel.refresh();
			this.initializeMessageArea(this);

			this._initializeActivitiesTablePerso();
			this.getView().byId("ActivitiesTable").setContext(this);

			this._initializeLinkedObjectsTablePerso();
			this.getView().byId("LinkedObjectsTable").setContext(this);

			this.getView().getModel("localModel").getData().initialLoad = true;
			this.getView().getModel("localModel").refresh();

			this.getView().byId("customerProjectTable").setContext(this);
			this._initializeProjectsTablePerso();

			this._oData.paginationClicks = 0;
			this._oData.paginationSkip = 0;
			this._oModel.refresh();

			this.getView().getModel("localModel").getData().bDetailPage = false;

			this.getView().getModel("localModel").getData().dropDownRelPart = [{
				key: "X",
				text: "Yes"
			}, {
				key: "",
				text: "No"
			}];

			this.getView().getModel("localModel").refresh();

			this.getView().setModel(new JSONModel({}), "VHCustomer");

			this._mViewSettingsDialogs = {};

			if (this.getView().byId("filterDialog")) {
				this._resetFilters();
				this.getView().byId("filterDialog").destroy();
			}

			this.getView().getModel("localModel").getData().filtersSetted = false;
			this.getView().getModel("localModel").getData().busyEngScopeTable = false;
			this.getView().getModel("localModel").getData().sSelectedViewTypeEngProjects = "listView";
			this.getView().getModel("localModel").refresh();


			this.getView().setModel(new JSONModel({}), "engScope");
			this.getView().getModel("engScope").getData().results = {};
			this.getView().getModel("engScope").getData().customerCount = 0;
			this.getView().getModel("engScope").getData().inScopeCount = 0;
			this.getView().getModel("engScope").getData().sPathToggled = "";
			this.getView().getModel("engScope").getData().oCheckBoxControlId = "";
			this.getView().getModel("engScope").getData().bIsPersoCalled = false;
			this.getView().getModel("engScope").getData().oScopeKeys = {
				scopeKeys: [{
					key: "prod",
					name: this.getView().getModel("i18n").getProperty("Engagement.Scope.Select.prod")
				}, {
					key: "all",
					name: this.getView().getModel("i18n").getProperty("Engagement.Scope.Select.all")
				}]
			};
			this.getView().getModel("engScope").refresh();
		},

		_readDataForAllSections: function () {
			this.pReadProjectData().then(() => {
				this._fnRefreshProjectList();
				this.notes.setNoteTypes(this);
				this.notes.handleReadNotes(null, this);
				this._readLinkedObjects();
				this.attachments.fnReadAttachmentsProjectDetails(this);
				if (!this._bIsGlobalEngagement) {
					this._readDataForScopeSection();
					this._readActivitiesAssignedToEngagement();
					this._readEngagementTopIssues();
					this.partiesInvolved.readPartnerSet(this._handleSuccessReadPartnerSet.bind(this));
					this._fnEngCaseContractSectionRead(this._idProject);
				}
			});
		},

		_readDataForScopeSection: function (bResetFilter = true) {
			this.engagementScope.pEngScopeSectionRead(this, this._idProject, bResetFilter).then(() => {
				this._fnLoadAllContractsOfGUHierarchyFromBE();
			});
			this._initializeEngagementScopeTablePerso();

		},

		handleSectionChange: function (oEvent) {
			this._resetPaginationProperties();

			if (oEvent.getSource().getSelectedSection().indexOf("topIssues") > -1) {
				this._readEngagementTopIssues();
			}
			if (oEvent.getSource().getSelectedSection().indexOf("linkedObjects") > -1) {
				this._readLinkedObjects();
			}
			if (oEvent.getSource().getSelectedSection().indexOf("activities") > -1) {
				this._readActivitiesAssignedToEngagement();
			}
			if (oEvent.getSource().getSelectedSection().indexOf("projects") > -1) {
				this._initVariants();
				this._fnReadAllEngagementProjectsWithoutFilter();
			}
			if (oEvent.getSource().getSelectedSection().indexOf("contracts") > -1) {
				this._fnEngCaseContractSectionRead(this._idProject);
			}
			if (oEvent.getSource().getSelectedSection().indexOf("partnerSection") > -1) {
				this.partiesInvolved.init(this);
				this.partiesInvolved.readPartnerSet();
			}
			if (oEvent.getSource().getSelectedSection().indexOf("scopeSection") > -1) {
				this._readEngagementScopeVariants();
				this.getOwnerComponent().trackEvent("Selected_TabEngagementScope");
			}
		},

		onPartnerAvatarPressed: function (oEvent, sPartnerFunction) {
			const sUserId = this.getView().getModel("PartnerModel").getData()[sPartnerFunction].UserID;
			if (sUserId) {
				NavigationToExternalApps.fnHandleLinkNavigation(Constants.getSAPPeopleUrl() + sUserId);
			}
		},

		_resetPaginationProperties: function () {
			this._oData.paginationClicks = 0;
			this._oData.paginationSkip = 0;
			this._oData.paginationIntervalStart = 0;

			this._oData.paginationNextBtnEnabled = false;
			this._oData.paginationPrevBtnEnabled = false;
			this._oModel.refresh();
		},

		_fnRefreshProjectList: function () {
			this._readProjectsAssignedToEngagement();
			this._fnReadAllEngagementProjectsWithoutFilter();
		},

		_fnRefreshEngagementDetails: function () {
			this.pReadProjectData();
		},

		/* ========================================= Engagement Scope Tab  ============================================== */

		fnTrackNavigationToReportingCockpit: function (oEvent) {
			this.getOwnerComponent().trackEvent("EngScope_Trigger_OpenListSystemsAndTenants");
		},

		/* ========================================= Assign Customer To Contracts - START ============================================== */

		_fnLoadAllContractsOfGUHierarchyFromBE: function () {
			this._pAllContractsOfGUHierarchy = new Promise(resolve => {
				let sGlobalHierarchyCustomer = this.getView().getModel("engScope").getData().results.find(elm => elm.GuFlag === true).PartnerNo;
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "ContractSet";
				entities.filter =
					`CustomerID eq '${sGlobalHierarchyCustomer}' and IncludeRelPartners eq 'X' and RecDelDate eq datetime'${this.dates._convertDateToBEZuluFormat(new Date())}'`;
				entities.mCustomUrlParameters = new Map().set("Source", "Case");
				entities.currentView = this.getView();
				entities.oContext = this;
				entities.callbackSuccess = oData => {
					//enrich URL to contract in Webui
					let sContractBaseUrl = Constants.getContractUrl()[Constants.getEnvironment()];
					oData.results.forEach(oContract => {
						oContract.sUrlContractInWebui = "https://" + sContractBaseUrl + oContract.ContractID;
					});
					resolve(oData);
				};
				this.readBaseRequest(entities);
			});
		},

		_fnPAssignCustomerToContractInBE: function () {
			const oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			return new Promise((resolve, reject) => {
				this.oDialogAssignCustomerToContractModel.getData().busy = true;
				this.oDialogAssignCustomerToContractModel.refresh();
				let oParams = {};
				oParams.servicePath = Constants.getServicePath();
				oParams.function = "AddPartnerToContract";
				oParams.method = "GET";
				oParams.currentView = this.getView();
				oParams.oContext = this;
				oParams.urlParameters = {
					"ContractID": this.oDialogAssignCustomerToContractModel.getData().sSelectedContractId,
					"PartnerID": this.oDialogAssignCustomerToContractModel.getData().selectedCustomerRow.PartnerNo
				};
				oParams.callbackSuccess = oData => {
					this.getOwnerComponent().trackEvent("EngScope_Add_CustomerToContract");
					MessageToast.show(oResourceBundle.getText("Engagement.Scope.AddCustomerToContract.Success.PartnerAssignedToContract"));
					this._pDialogAssignCustomerToContract.then(oDialog => oDialog.close());
					this.oDialogAssignCustomerToContractModel.getData().busy = false;
					this.oDialogAssignCustomerToContractModel.refresh();
					this._readDataForScopeSection();
					resolve();
				};
				oParams.callbackError = oError => {
					switch (JSON.parse(oError.responseText).error.code) {
						case 'ZS_APP_HEP/070':
							this._fnShowCustomerAssignToContractAssignErrorDialog("UserNotTqmOfContract", JSON.parse(oError.responseText).error.message.value);
							break;
						case 'ZS_APP_HEP/071':
							this._fnShowCustomerAssignToContractAssignErrorDialog("CustomerNotInGUHierachy");
							break;
						case 'ZS_APP_HEP/072':
							this._fnShowCustomerAssignToContractAssignErrorDialog("CustomerNotInGUFrtherSecurityCheck", JSON.parse(oError.responseText).error
								.message.value);
							break;
						default:
							this._fnShowCustomerAssignToContractAssignErrorDialog("FromBEError", JSON.parse(oError.responseText).error.message.value);
					}
					this.oDialogAssignCustomerToContractModel.getData().busy = false;
					this.oDialogAssignCustomerToContractModel.refresh();
					resolve();
				};
				this.callFunction(oParams);
			});
		},

		_fnShowCustomerAssignToContractAssignErrorDialog: function (sError, sText = "") {
			const oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			if (!this.oErrorMessageDialogAssignCustomerToContract) {
				this.oErrorMessageDialogAssignCustomerToContract = new Dialog({
					type: "Message",
					title: "Error",
					state: "Error",
					content: new FormattedText({
						htmlText: ""
					}),
					beginButton: new Button({
						type: "Emphasized",
						text: "OK",
						press: function () {
							this.oErrorMessageDialogAssignCustomerToContract.close();
						}.bind(this)
					})
				});
			}
			let conHtmlBody = "";
			let errorS = "",
				diagnosisS = "",
				procedureS = "",
				linkS = "";
			let diagnosisL = 0,
				procedureL = 0,
				linkL = 0;

			switch (sError) {
				case 'UserNotTqmOfContract': //fall through feature of case
				case 'CustomerNotInGUFrtherSecurityCheck':
					try {
						diagnosisL = sText.toUpperCase().indexOf("DIAGNOSIS");
						errorS = sText.substring(0, diagnosisL);
						procedureL = sText.toUpperCase().indexOf("PROCEDURE");
						diagnosisS = sText.substring(diagnosisL + 9, procedureL);
						linkL = sText.toUpperCase().indexOf("LINK");
						procedureS = sText.substring(procedureL + 9, linkL);
						linkS = sText.substring(linkL);
					} catch (oError) { }
					conHtmlBody = oResourceBundle.getText("Engagement.Scope.AddCustomerToContract.Error.MappedErrorFromBackEnd");
					conHtmlBody = conHtmlBody.replace("!-ERROR-!", errorS);
					conHtmlBody = conHtmlBody.replace("!-DIAGNOSIS-!", diagnosisS);
					conHtmlBody = conHtmlBody.replace("!-PROCEDURE-!", procedureS);
					conHtmlBody = conHtmlBody.replace("!-LINK-!", linkS);
					this.oErrorMessageDialogAssignCustomerToContract.getContent()[0].setProperty("htmlText", conHtmlBody);
					break;
				case 'CustomerNotInGUHierachy':
					conHtmlBody = oResourceBundle.getText("Engagement.Scope.AddCustomerToContract.Error.PartnerNotInHierarchyOfContractSoldTo");
					this.oErrorMessageDialogAssignCustomerToContract.getContent()[0].setProperty("htmlText", conHtmlBody);
					break;
				case 'FromBEError':
					this.oErrorMessageDialogAssignCustomerToContract.getContent()[0].setHtmlText(sText);
					break;
				default:
					this.oErrorMessageDialogAssignCustomerToContract.getContent()[0].setHtmlText(oResourceBundle.getText(
						"Engagement.Scope.AddCustomerToContract.Error.UnknownAssignError"));
			}
			this.oErrorMessageDialogAssignCustomerToContract.open();
		},

		fnHandleEngCaseScopeCustomerAddToContractOpenDialog: function (oEvent) {
			let sBindingPath = oEvent.getSource().getBindingContext("engScope").getPath();
			let oClickedRow = sBindingPath ? this.getView().getModel("engScope").getProperty(sBindingPath) : null;
			if (oClickedRow.Extern) this._fnShowCustomerAssignToContractAssignErrorDialog("CustomerNotInGUHierachy");
			else {
				let oDialogAssignCustomerToContractModel = new JSONModel({}); //every time user opens the popup we create the model freshly and empty
				this.oDialogAssignCustomerToContractModel = oDialogAssignCustomerToContractModel;
				oDialogAssignCustomerToContractModel.getData().selectedCustomerRow = oClickedRow;
				oDialogAssignCustomerToContractModel.getData().searchFilter = {};
				oDialogAssignCustomerToContractModel.getData().bUserHasConfirmed = false;

				this._pDialogAssignCustomerToContract ??= this._loadFragment("com.sap.ui.hep.view.Details.Engagement.fragment.DialogAssignCustomerToContract");
				this._pDialogAssignCustomerToContract.then(oDialog => {
					oDialog.setModel(oDialogAssignCustomerToContractModel, "local");
					oDialog.open();
					this.fnHandleDialogAssignCustomerToContractSearch(); //initially fill the list
				});
			}
		},

		fnHandleDialogAssignCustomerToContractSearch: function () {
			this.oDialogAssignCustomerToContractModel.getData().sSelectedContractId = "";
			this.oDialogAssignCustomerToContractModel.getData().busy = true;
			this.oDialogAssignCustomerToContractModel.refresh();
			this.getView().byId("idTableAssignCustomerToContract").removeSelections();
			this._pAllContractsOfGUHierarchy.then(oData => {
				let aFilteredData = oData.results.slice(); //shallow copy
				if (this.oDialogAssignCustomerToContractModel.getData().searchFilter.ContractHint) {
					let sContractHint = this.oDialogAssignCustomerToContractModel.getData().searchFilter.ContractHint;
					aFilteredData = oData.results.filter(elm => elm.ContractID.includes(sContractHint) ||
						elm.ContractName.toUpperCase().includes(sContractHint.toUpperCase())); //shallow copy
				}
				aFilteredData.forEach(oContractLine => {
					oContractLine.bAlreadyAssigned = this.oDialogAssignCustomerToContractModel.getData().selectedCustomerRow.Contracts.includes(
						oContractLine.ContractID);
				});
				this.oDialogAssignCustomerToContractModel.getData().results = aFilteredData;
				this.oDialogAssignCustomerToContractModel.getData().nNumberOfResults = aFilteredData.length;
				this.oDialogAssignCustomerToContractModel.getData().busy = false;
				this.oDialogAssignCustomerToContractModel.refresh();
				if (!this.getView().byId("idTableAssignCustomerToContract").hasRenderingDelegate()) this.getView().byId(
					"idTableAssignCustomerToContract").addEventDelegate({
						"onAfterRendering": function () {
							this.getView().byId("idTableAssignCustomerToContract").getItems().forEach(oRow => {
								if (oRow.getCells()[0].getItems()[0].getVisible())
									oRow.getSingleSelectControl().setVisible(false);
								else oRow.getSingleSelectControl().setVisible(true);
							});
						}.bind(this)
					});
			});
		},

		fnHandleDialogAssignCustomerToContractSearchClear: function () {
			this.oDialogAssignCustomerToContractModel.getData().searchFilter.ContractHint = "";
			this.fnHandleDialogAssignCustomerToContractSearch();
		},

		fnHandleDialogAssignCustomerToContractContractSelected: function (oEvent) {
			this.oDialogAssignCustomerToContractModel.getData().sSelectedContractId = oEvent.getParameter("listItem").getCells()[1].getText();
			this.oDialogAssignCustomerToContractModel.refresh();
			let oDomRefPanelUserDeclaration = this.getView().byId("idPanelUserDeclaration").getDomRef();
			this.getView().byId("idAssignCustomerToContractDialog").getScrollDelegate().scrollToElement(oDomRefPanelUserDeclaration);
		},

		fnHandleDialogAssignCustomerToContractAssign: function (oEvent) {
			this._fnPAssignCustomerToContractInBE();
		},

		fnHandleDialogAssignCustomerToContractCancel: function () {
			this._pDialogAssignCustomerToContract.then(oDialog => {
				oDialog.close();
			});
		},

		/* ========================================= Assign Customer To Contracts - END ============================================== */

		onEngagementScopeSelectionChange: function (oEvent) {
			const sPath = oEvent.getSource().getParent().getBindingContextPath();
			const oProperty = oEvent.getSource().getParent().getModel('engScope').getProperty(sPath);
			const sCaseId = oProperty.CaseId,
				sPartnerNo = oProperty.PartnerNo,
				bInScope = oEvent.getSource().getSelected();
			// store the path for recalculation of the count of selected items
			this.getView().getModel("engScope").getData().sPathToggled = sPath;
			// store the reference to oEvent object to be able to reset the checkbox in case BE resonds with an error
			this.getView().getModel("engScope").getData().oCheckBoxControlId = oEvent.getSource().getId();
			this.getView().getModel("engScope").refresh();
			this.engagementScope._fnEngScopeUpdateInScopeFlag(this, sCaseId, sPartnerNo, bInScope, oProperty);
			// reads in the table and variant data, contained in /util/EngagementScope.js
			this._initializeEngagementScopeTablePerso();
		},

		// receives results and creates two items for each entry conCAR and conCDR (first &rest)
		// conCAR will be displayed with sap.m.Link
		// conCDR is rendered as html text with proprer links and will be displayed in FormattedText control as html
		_parseContractsToLinks: function (aResult) {
			aResult.forEach(oItem => {
				if (oItem.Contracts === "") {
					// no contracts
					oItem.conCAR = "";
					oItem.conCDR = "";
				} else if (oItem.Contracts.includes(",")) {
					// multiple contracts
					const aConSplit = oItem.Contracts.split(",");
					oItem.conCAR = aConSplit[0];
					oItem.conCDR = aConSplit.slice(1).join();
				} else {
					// only one contract available
					oItem.conCAR = oItem.Contracts;
					oItem.conCDR = "";
				}
			});
			return aResult;
		},

		// resets the state of the select control to the initial one, since filter is set every time user clicks
		// on the engagement scope tab
		_initEngScopeFilters: function (sKey) {
			const oSelect = this.getView().byId("systemsToggleSelect");
			oSelect.setSelectedKey(sKey);
			this._applyEngScopeFilters(sKey);
		},
		// filters the table based on the the scope: all or prod (MSysAllP !== 0)
		_applyEngScopeFilters: function (sKey) {
			let oFilter, oTable = this.getView().byId("engScopeTable");

			if (sKey === "prod") {
				oFilter = new sap.ui.model.Filter("MSysAllP", sap.ui.model.FilterOperator.GT, "0");
			} else {
				oFilter = new sap.ui.model.Filter("MSysAllP", sap.ui.model.FilterOperator.GE, "0");
				this.getOwnerComponent().trackEvent("Selected_EngScope_AllCustomersProductiveSystems");
			}
			oTable.getBinding("items").filter(oFilter);
		},

		_initializeEngagementScopeTablePerso: function () {
			this.getView().byId("engScopeTable").removeSelections();
			if (this._oTPCEngagementScope === undefined) {
				this._oTPCEngagementScope = new TablePersoController({
					table: this.getView().byId("engScopeTable"),
					componentName: "TablePerso",
					persoService: TablePersoEngagementScope
				}).activate();
			}
			// set context for EngagementScopeTablePerso
			TablePersoEngagementScope.setContext(this);
		},

		onEngScopePersoButtonPressed: function (oEvent) {
			let oEngModel = this.getView().getModel("engScope");
			oEngModel.getData().bIsPersoCalled = true;
			oEngModel.refresh();
			this._oTPCEngagementScope.openDialog();

		},

		_onEngScopeVariantChanged: function (oPromise) {
			// called from TablePersoEnagegmentScope in case user changes Column layout
			let oEngModel = this.getView().getModel("engScope");
			oPromise.done((oPersData) => {
				TablePersoEngagementScope.getPersData().done(
					(oPersData1) => {
						// call _handleEngagementScopeVariantsSave and ensure that the changed data is passed and saved in BE
						this._handleEngagementScopeVariantsSave(oPersData1);
					});
			});
			oEngModel.getData().bIsPersoCalled = false;
			oEngModel.refresh();
		},

		//triggered when we navigate into the engagement scope tab
		_readEngagementScopeVariants: function () {
			this.variant.context = this;
			this.getView().setModel(this.variant.variantModel, "variantModel");
			this.variant.variantSetName = "Engagement_Scope";
			this.getView().getModel("variantModel").refresh();
			this.variant.variantLoaded = () => {
				if (this.variant.currentVariant.tablePerso.getData()) {
					this._oTPCEngagementScope.getPersoService().setPersData(this.variant.currentVariant.tablePerso.getData());
					this._oTPCEngagementScope.refresh();
					this.getView().getModel("localModel").getData().busyEngScopeTable = false;
					this.getView().getModel("localModel").refresh();
				} else {
					//Reset to default variants if nothing found
					this._oTPCEngagementScope.getPersoService().resetPersData();
					this._oTPCEngagementScope.refresh();
					this.getView().getModel("localModel").getData().busyEngScopeTable = false;
					this.getView().getModel("localModel").refresh();
				}


			};
			this.getView().getModel("localModel").refresh();
			this.variant.readVariants(null);
		},

		_handleEngagementScopeVariantsSave: function (oPersData) {
			const variant = this.variant;
			const defaultVariant = "X";
			const variantData = {
				filter: {},
				tablePerso: oPersData
			};
			const newVariant = {
				"VariantSetName": "Engagement_Scope",
				"VariantDisplayName": "default",
				"VariantContent": JSON.stringify(variantData),
				"IsDefault": defaultVariant,
				"Scope": "LOCAL"
			};
			variant.createVariant(newVariant);
		},

		onEngagementScopeReset: function () {
			this._applyEngScopeFilters("prod");
			this._initEngScopeFilters("prod");

			const oTable = this.getView().byId("engScopeTable"),
				oBindings = oTable.getBinding("items");
			// to reset all sort indicators in the table columns
			oTable.resetSorting();
			const guSorter = new Sorter({
				path: 'GuFlag',
				descending: true
			});
			const mainSorter = new Sorter({
				path: 'MainFlag',
				descending: true
			});
			const scopeSorter = new Sorter({
				path: 'InScope',
				descending: true
			});
			const allsysSorter = new Sorter({
				path: 'MSysAllP',
				descending: true
			});
			oBindings.sort([guSorter, mainSorter, scopeSorter, allsysSorter]);
		},

		fnHandleEngScopeShowContracts: function (oEvent) {
			const oPopOverSource = oEvent.getSource();
			this._pPopoverShowContracts ??= this._loadFragment("com.sap.ui.hep.view.Details.Engagement.fragment.PopoverShowContracts");
			this._pPopoverShowContracts.then(oPopover => {
				const sPath = oPopOverSource.getParent().getParent().getBindingContextPath(),
					oModel = this.getView().getModel("engScope"),
					oEntry = oModel.getProperty(sPath),
					generateHtml = this._contractLinkHtmlGenerator;
				this.getView().byId("showContractsText").setHtmlText(generateHtml(oEntry.conCDR, this));
				oPopover.openBy(oPopOverSource);
			});
		},

		onEngagementInfoButtonPress: function (oEvent, sCaller) {
			const oPopOverSource = oEvent.getSource(),
				oView = this.getView();
			this._pPopoverShowInfo ??= this._loadFragment("com.sap.ui.hep.view.Details.Engagement.fragment.PopoverShowInfo");
			this._pPopoverShowInfo.then(oPopover => {
				const oInfoPopupTextField = this.getView().byId("showEngInfoText"),
					oResourceBundle = oView.getModel("i18n").getResourceBundle();
				switch (sCaller) {
					case "info":
						oInfoPopupTextField.setText(oResourceBundle.getText("Engagement.Scope.Table.scopeinfo"));
						break;
					case "prod":
						oInfoPopupTextField.setText(oResourceBundle.getText("Engagement.Scope.Table.sysprodinfo"));
						break;
					case "contract":
						oInfoPopupTextField.setText(oResourceBundle.getText("Engagement.Scope.Table.contractinfo"));
						break;
					case "customer":
						oInfoPopupTextField.setText(oResourceBundle.getText("Engagement.Scope.Table.customerinfo"));
						break;
					case "rise":
						oInfoPopupTextField.setText(oResourceBundle.getText("Engagement.Scope.Table.riseinfo"));
						break;
					case "actions":
						oInfoPopupTextField.setText(oResourceBundle.getText("Engagement.Scope.Table.tooltip.actions"));
						break;
					default:
						oInfoPopupTextField.setText(oResourceBundle.getText("Error: text not found!"));
				}
				oPopover.openBy(oPopOverSource);
			});
		},

		onContractLinkPress: function (oEvent) {
			const sText = oEvent.getSource().getText(),
				sEnv = Constants.getEnvironment(),
				sContractUrl = Constants.getContractUrl()[sEnv];

			if (sText !== undefined && sText !== "" && sText !== null) {
				let sUrl = "https://" + sContractUrl + sText;
				NavigationToExternalApps.fnHandleLinkNavigation(sUrl);
			}
		},

		// Takes in a string of contracts and creates an HTML with clickable links
		_contractLinkHtmlGenerator: function (conCDR, oContext) {
			const sEnv = Constants.getEnvironment(),
				sContractUrl = Constants.getContractUrl()[sEnv];

			let conHtmlBody = "";
			const conSplit = conCDR.split(",");
			if (conSplit.length === 1) {
				// handling a case with a single element
				conSplit.forEach(sItem => {
					const sItemLink = `https://${sContractUrl}${sItem.trim()}`
					conHtmlBody = `<a href=${sItemLink}" style="font-weight:400; line-height: 150%";> ${sItem.trim()}</a>`;
				});
			} else {
				for (let i = 0; i < conSplit.length; i++) {
					const sItem = conSplit[i];
					const sItemLink = `https://${sContractUrl}${sItem.trim()}`
					if (i === conSplit.length - 1) conHtmlBody += `<a href="${sItemLink}" style="font-weight:400; line-height: 150%;">${sItem.trim()}</a>`;
					else conHtmlBody += `<a href=${sItemLink}" style="font-weight:400; line-height: 150%;">${sItem.trim()}, </a>`;
				}
			}

			return conHtmlBody;
		},

		onMenuItemAction: function (oEvent) {
			if (oEvent === "AddCustomerNotGU") this.fnAddCustomerToEngagementScope(oEvent);
		},

		onDisclaimerGUToggleSelection: function (oEvent) {
			let bSelected = oEvent.getParameter("selected");
			if (bSelected) {
				this.partiesInvolved.setDisclaimerGU(false);
			}
		},

		fnAddCustomerToEngagementScope: function (oEvent) {
			this.getView().getModel("localModel").getData().bpSearchReturnType = "EngScopeSearchPopupCustomerValueHelp";
			this.getView().getModel("localModel").getData().bpGlobalGUBp = this._getGlobalGUBp();
			this.getView().getModel("localModel").refresh();
			this.partiesInvolved.loadSearchHelpDialog("00000001", "PFCustomer");
		},

		_getGlobalGUBp: function (oEvent) {
			let scopeItems = this.getView().getModel("engScope").getData().results;
			let GlobalGUBp = "";
			scopeItems.forEach((item, index) => {
				if (item.GuFlag) {
					GlobalGUBp = item.PartnerNo;
				}
			});
			return GlobalGUBp;
		},

		fnEngCaseScopeCustomerHandleDelete: function (oEvent) {
			let sPartnerID = "";
			let bExtern = false;
			oEvent.getSource().getCustomData().forEach(function (elem) {
				switch (elem.getKey()) {
					case "PartnerNo":
						sPartnerID = elem.getValue();
						break;
					case "Extern":
						bExtern = elem.getValue();
						break;
					default:
						break;
				}
			});
			if (bExtern === true) {
				let oScopeData = new JSONModel({});
				oScopeData.getData().PartnerNo = sPartnerID;
				this._saveEngagementScopeDeleteCustomerData(oScopeData.getData());
			}
		},

		_saveEngagementScopeCreateCustomerData: function (oData) {
			if (this.getView().getModel("projectDetails").getData().ProjectID !== '') {

				this._fnShowSaveDialog("Saving Scope Customer");

				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "EngagementScopeSet";
				entities.errorMessage = this.getResourceBundle().getText("Engagement.AddScopeCustomer.error.BECall");
				oData.CaseId = this.getView().getModel("projectDetails").getData().ProjectID;
				oData.InScope = true;
				entities.data = oData;
				entities.oContext = this;
				entities.currentView = this.getView();
				entities.callbackSuccess = (oDataC) => {
					// Success
					this._oDialogProgressIndicator.close();
					this.getOwnerComponent().trackEvent("EngScope_Add_CustomerFromOutsideGU");
					this._readDataForScopeSection(false);
				};
				entities.callbackError = (oError) => {
					// release busy indicator in case of an error
					this._oDialogProgressIndicator.close();
					const parsedError = JSON.parse(oError.responseText);
					// Inform user about an error via MessageBus
					this.messageHandler.clearAllMessages();
					this.messageHandler.addNewMessageseInsidePopover(
						null,
						"Error",
						"Error occured adding customer to scope",
						parsedError.error.message.value);
					this.getView().getModel("localModel").getData().busyEngScopeTable = false;
					this.getView().getModel("localModel").refresh();
				};
				this.createBaseRequest(entities);
			}
		},

		_fnShowSaveDialog: function (sDisplayString) {
			if (!this._oDialogProgressIndicator) {
				this._oDialogProgressIndicator = new Dialog({
					type: "Message",
					showHeader: false,
					state: this._bErrorSavingPhases ? "Warning" : "Information",
					content: new ProgressIndicator({
						displayAnimation: false,
						displayValue: sDisplayString,
						percentValue: 50,
						state: "Success",
						displayOnly: true
					})
				});
				this._oDialogProgressIndicator.addStyleClass("sapUiSizeCompact");
			} else {
				this._oDialogProgressIndicator.getContent()[0].setDisplayValue(sDisplayString);
			}
			this._oDialogProgressIndicator.open();
		},

		_saveEngagementScopeDeleteCustomerData: function (oData) {
			if (this.getView().getModel("projectDetails").getData().ProjectID !== '') {

				this._fnShowSaveDialog("Deleting Customer from engagement scope");

				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "EngagementScopeSet(CaseId='" + this.getView().getModel("projectDetails").getData().ProjectID +
					"',PartnerNo='" + oData.PartnerNo + "')";
				entities.errorMessage = this.getResourceBundle().getText("Engagement.AddScopeCustomer.error.BECall");
				entities.oContext = this;
				entities.currentView = this.getView();
				entities.callbackSuccess = (oDataC) => {
					// Success
					this._oDialogProgressIndicator.close();
					this._readDataForScopeSection(false);
				};
				entities.callbackError = (oError) => {
					// release busy indicator in case of an error
					this._oDialogProgressIndicator.close();
					const parsedError = JSON.parse(oError.responseText);
					// Inform user about an error via MessageBus
					this.messageHandler.clearAllMessages();
					this.messageHandler.addNewMessageseInsidePopover(
						null,
						"Error",
						"Backend Error: " + parsedError.error.message,
						"");
					this.getView().getModel("localModel").getData().busyEngScopeTable = false;
					this.getView().getModel("localModel").refresh();
				};
				this.deleteBaseRequest(entities);
			}
		},

		/* ============================== Customer Projects Tab - Projects assigned to the Engagement =================== */

		_initFilterModel: function () {
			let oFilterRangeModel = new JSONModel({}),
				oRangeOptions = {};
			if (this.getView().getModel("projectDetails").getData().ReasonCode === "ENG1") {
				oRangeOptions = Constants.getRangeFiltersHome().engagementsOptions.options;
			} else {
				oRangeOptions = Constants.getRangeFiltersHome().projectOptions.options;
			}
			this.getView().setModel(oFilterRangeModel, "filterModel");
			this.getView().getModel("filterModel").getData().rangeOptions = oRangeOptions;
			this.getView().getModel("filterModel").getData().rangeSelected = "all";

			this.getView().getModel("filterModel").getData().statusOptions = [];
			const arrKeySelected = [];
			$.each(Constants.getProjectStatus(), (index, item) => {
				let selected = false;
				if (index !== "90") {
					selected = true;
				}
				if (selected) {
					arrKeySelected.push(index);
				}

				let oStatus = {
					key: index,
					value: item,
					selected: selected
				};
				this.getView().getModel("filterModel").getData().statusOptions.push(oStatus);
			});
			this.getView().getModel("filterModel").getData().statusSelected = arrKeySelected;
			this.getView().getModel("filterModel").getData().searchTerm = "";

			this.getView().getModel("filterModel").getData().deploymentType = Constants.getDeploymentType();
			this.getView().getModel("filterModel").getData().status = Constants.getProjectStatusTypes();
			this.getView().getModel("filterModel").getData().sapInvolvment = Constants.getSAPInvolvment();
			this.getView().getModel("filterModel").refresh();
		},

		fnHandleSearchForProjects: function (oEvent) {
			this._readProjectsAssignedToEngagement();
			this._fnReadAllEngagementProjectsWithoutFilter();
		},

		_initializeProjectsTablePerso: function () {
			this.getView().byId("customerProjectTable").removeSelections();
			if (this._oTPCCustomerProjects === undefined) {
				this._oTPCCustomerProjects = new TablePersoController({
					table: this.getView().byId("customerProjectTable"),
					componentName: "tablePerso",
					persoService: TablePersoCustomerProjects
				}).activate();
			}
		},

		onProjectsPersoButtonPressed: function (oEvent) {
			this._oTPCCustomerProjects.openDialog();
		},

		onProjectsTablePersoRefresh: function () {
			TablePersoCustomerProjects.resetPersData();
			this._oTPCCustomerProjects.refresh();
		},

		generateCustomerProjectsTabFilter: function () {
			let sFilter = `( ParentCaseID eq '${this._idProject}'`,
				aFilterStatusItems = [],
				sFilterStatuses = "";
			let aItems = this.getView().getModel("filterModel").getData().statusSelected.length ?
				this.getView().getModel("filterModel").getData().statusSelected :
				this.getView().getModel("filterModel").getData().statusOptions;

			if (this.getView().getModel("filterModel").getData().searchTerm !== "") {
				sFilter += " and Search eq '" + this.getView().getModel("filterModel").getData().searchTerm + "'";
			}
			if (this.getView().getModel("filterModel").getData().rangeSelected === "mine") {
				sFilter += " and MyProjects eq 'X' ";
			}

			if (this.getView().getModel("filterModel").getData().rangeSelected === "myFavorite") {
				sFilter += " and IsFavorite eq true ";
			}

			aItems.forEach(oItem => {
				let sStatusID = {
					id: typeof oItem === "object" ? oItem.key : oItem
				};
				aFilterStatusItems.push(sStatusID);
			});

			aFilterStatusItems.forEach((item, index) => {
				sFilterStatuses += `StatusID eq '${item.id}'`;
				if (index < aFilterStatusItems.length - 1) {
					sFilterStatuses += " or ";
				}
			});
			sFilter += aFilterStatusItems.length && sFilter !== "" ? ` and ( ${sFilterStatuses} )` : `( ${sFilterStatuses})`;
			sFilter += " )";
			return sFilter;
		},

		_fnReadAllEngagementProjectsWithoutFilter: function () { //relevant for EngagementProjectsCalendar
			const entities = {
				servicePath: Constants.getServicePath(),
				entitySet: Constants.getEntities().ProjectSetEntity,
				filter: `ParentCaseID eq '${this._idProject}'`,
				callbackSuccess: (oData) => {
					this.iNumberOfAllProjectsUnderEngagement = oData.results.length;
					EventBus.getInstance().publish("Engagements", "relatedProjectsUnfilteredLoaded", oData.results); //inform subscribers, like EngagmementProjectsCalendar.controller
				}
			};

			this.readBaseRequest(entities);
		},

		_readProjectsAssignedToEngagement: function (oSort) {
			let entities = {},
				oSortProperties = oSort; // ? oSort : this._determineSortingCriterias(oSort);
			this._oData.busyCustomerProjectsList = true;
			this._oModel.refresh();
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = Constants.getEntities().ProjectSetEntity;
			entities.inlineCount = "allpages";
			entities.filter = this.generateCustomerProjectsTabFilter();

			if (this.searchFilters)
				entities.filter += this.searchFilters;

			if (oSortProperties) {
				if (!this._oSort || this._oSort.field !== oSortProperties.field || this._oSort.order !== oSortProperties.order)
					this._oSort = oSortProperties;

				entities.sortItem = oSortProperties.field;
				entities.sortOrder = Constants.getSortOrder()[oSortProperties.order];
			}
			if (this._oSort && !oSortProperties) {
				entities.sortItem = this._oSort.field;
				entities.sortOrder = Constants.getSortOrder()[this._oSort.order];

				if (this.getView().byId(this._oSort.column))
					this.getView().byId(this._oSort.column).setSortIndicator(this._oSort.order);

				this.getView().getModel("localModel").refresh();
			}
			entities.errorMessage = this.getResourceBundle().getText("ProjectEntityPerUser.ErrorMessage");
			entities.oContext = this;
			entities.currentView = this.getView();
			entities.busyIndicator = "busyCustomerProjectsList";
			entities.callbackSuccess = this._fnHandleSuccessReadProjectsAssignedToEngagement.bind(this);
			this.readBaseRequest(entities);
		},

		_fnHandleSuccessReadProjectsAssignedToEngagement: function (oData) {
			this._handleSuccessReadingProjectList(oData);
			if (this.getView().getModel("localModel").getData().initialLoad &&
				oData.__count === 0 &&
				this.getView().getModel("projectDetails").getData().ReasonCode ===
				Constants.getReasonOptions().globalEng) {
				this.getView().getModel("localModel").getData().initialLoad = false;
				MessageBox.alert(
					'To manage Premium Engagements, please use the CRM Case Reason “Engagement Case” instead of “Global Engagement Case”!', {
					title: "No subordinate engagements"
				}
				);
			}
			if (this.sIdTabInURL) {
				this.getView().byId("ObjectPageLayoutEngagement").setSelectedSection(this.sIdTabInURL);
				this.sIdTabInURL = "";
			}

			this.getView().byId("ObjectPageLayoutEngagement").rerender();
			this.getView().byId("ObjectPageLayoutEngagement").getScrollDelegate().setVertical(false);

			if (this._bIsGlobalEngagement) {
				TablePersoCustomerProjects.getPersData().then(oPersData => {
					let oColumnDeployment = oPersData.aColumns.find(elm => elm.id === "tablePerso-customerProjectTable-projectDeploymentPR");
					if (oColumnDeployment) oColumnDeployment.visible = false;
					let oColumnInvolvement = oPersData.aColumns.find(elm => elm.id ===
						"tablePerso-customerProjectTable-projectSapInvolvementPR");
					if (oColumnInvolvement) oColumnInvolvement.visible = false;
					TablePersoCustomerProjects.setPersData(oPersData);
					this.getTablePerso().refresh();
				});
			}
		},

		_handleSuccessReadingProjectList: function (oData) {
			this.getView().getModel("projectsUnderEngagement").setData({
				results: oData.results,
				iNumberOfProjects: oData.__count
			});
			this.getView().getModel("projectsUnderEngagement").refresh();
			this._oData.busyCustomerProjectsList = false;
			this._oModel.refresh();

			EventBus.getInstance().publish("Engagements", "relatedProjectsFilteredLoaded", oData.results); //inform subscribers, like EngagmementProjectsCalendar.controller

			this.pagination._paginationElements(this, oData.__count);
		},

		fnHandleOpenExportDialog: function () {
			this._pDialogUserExport ??= this._loadFragment("com.sap.ui.hep.view.Details.fragment.ExportUserDialog");
			this._pDialogUserExport.then(oDialog => oDialog.open());
		},

		onListViewExportSelected: function (oParam) {
			this._onDownloadCustomerProject(oParam);
		},

		_onDownloadCustomerProject: function (oParam) {
			let entities = {};

			let aColumnConfig = [];
			let aItems = this.getView().byId("customerProjectTable").getColumns();
			aItems = oParam ? aItems.filter(function (arg) {
				return arg.getProperty("visible") !== false;
			}) : aItems;
			aItems.forEach(function (arg) {
				aColumnConfig.push({
					label: arg.getHeader().getProperty("text"),
					property: arg.getProperty("sortField"),
					width: 10
				});
			});

			this._buildExportCustomerProjects(entities);
			entities.callbackSuccess = (oData) => {
				let aTreeData = [];
				oData.results.forEach(oItem => aTreeData.push(oItem));
				this._oSort = null;
				let oSpreadsheetSettings = {
					workbook: {
						columns: aColumnConfig,
						hierarchyLevel: "Level",
						context: {
							sheetName: "Export from HEP"
						}
					},
					dataSource: aTreeData,
					fileName: "CUSTOMER_PROJECTS_EXPORT.xlsx"
				};
				let oSheet = new Spreadsheet(oSpreadsheetSettings);
				oSheet.build().finally(function () {
					oSheet.destroy();
				});
				this._oData.busyIndicatorProjects = false;
				this._oModel.refresh();
			};
			this.readBaseRequest(entities);
		},

		onCloseExportDialog: function () {
			this._pDialogUserExport.then(oDialog => oDialog.close());
		},

		_buildExportCustomerProjects: function (entities) {
			const sMine = "mine";
			let oLocalModel = this.getView().getModel("localModel");
			let bProjectSelection = oLocalModel.getData().defaultSelected === "" ? sMine : oLocalModel.getData().defaultSelected;
			this._oData.showFavoritesOnly = oLocalModel.getData().defaultSelected === "myFavorite";
			this._oData.searchMyProjects = bProjectSelection === sMine;
			this._oData.busyIndicatorProjects = true;
			this._oModel.refresh();
			entities.servicePath = Constants.getServicePath();

			if (this._scopeView === "ENG3") {
				entities.entitySet = Constants.getEntities().ServiceItem;
				entities.filter = this.generateCustomerProjectsTabFilter();
			} else {
				entities.entitySet = Constants.getEntities().ProjectSetEntity;
				entities.filter = this.generateCustomerProjectsTabFilter();
			}

			if (this.searchFilters !== "")
				entities.filter = entities.filter + this.searchFilters;
			this._oSort = {

			};

			entities.inlineCount = "allpages";
			entities.errorMessage = this.getResourceBundle().getText("ProjectEntityPerUser.ErrorMessage");

			if (this._oSort) {
				entities.sortItem = this._oSort.field;
				entities.sortOrder = Constants.getSortOrder()[this._oSort.order];
			}
			entities.oContext = this;
			entities.currentView = this.getView();
			entities.busyIndicator = "busyIndicatorProjects";
		},

		fnHandleCloseDialogExcelExport: function (oEvent) {  //needed for closing Exel-Export Dialog
			this._pDialogUserExport.then(oDialog => oDialog.close());
			this._pDialogUserExport = undefined;
		},

		onCustomerProjectsResetSort: function () {
			let oTable = this.getView().byId("customerProjectTable");
			oTable.resetSorting();
			this._oSort = null;
			this._readProjectsAssignedToEngagement();
		},

		fnAddProject: function (oEvent) {
			let sCaseID = this.getView().getModel("projectDetails").getData().ProjectID;
			this._oCreateProjectDialog.fnCreateProjectDialogOpen(this, this.getResourceBundle(), sCaseID);
		},

		fnEditEngagement: function (oEvent) {
			this._oEditEngagementDialog.fnEditEnagagementDialogOpen(this, this.getResourceBundle(), this.getView().getModel("projectDetails").getData());
		},

		fnOnEngProjectsCalendarListSelectionChange: function () {
			this.getView().getModel("localModel").refresh();
		},

		/* ================================================================================================================== */
		/* ========================================== Project Calendar START  =============================================== */

		fnHandleReArrangeProjects: function () { //relevant for EngagementProjectsCalendar
			this.iNumberOfFilteredProjectsUnderEngagement = this.getView().getModel("projectsUnderEngagement").getData().iNumberOfProjects;
			this.getView().getModel("projectsUnderEngagement").getData().iNumberOfProjects = this.iNumberOfAllProjectsUnderEngagement;
			this.getView().getModel("projectsUnderEngagement").refresh();
			this.GanttViewController.fnHandleReArrangeProjectsPressed();
			this.getView().getModel("localModel").getData().bVsdFilterBarVisible = false;
			this.getView().getModel("localModel").getData().bIsInRearrangeMode = true;
			this.getView().getModel("localModel").refresh();
		},

		fnHandleDeleteProjectsArrangement: function () { //relevant for EngagementProjectsCalendar
			this.GanttViewController.fnHandleDeleteProjectsArrangementPressed().then(() => {
				this.getView().getModel("localModel").refresh();
			});
		},
		fnHandleSaveProjectsArrangement: function () { //relevant for EngagementProjectsCalendar
			this.GanttViewController.fnHandleSaveProjectsArrangementPressed().then(() => {
				this.getView().getModel("projectsUnderEngagement").getData().iNumberOfProjects = this.iNumberOfFilteredProjectsUnderEngagement;
				this.getView().getModel("projectsUnderEngagement").refresh();
				this.getView().getModel("localModel").getData().bVsdFilterBarVisible = !!this.getView().byId("multiInput").getTokens().length;
				this.getView().getModel("localModel").getData().bIsInRearrangeMode = false;
				this.getView().getModel("localModel").refresh();
			});
		},

		fnHandleCancelProjectsArrangement: function () { //relevant for EngagementProjectsCalendar
			this.getView().getModel("projectsUnderEngagement").getData().iNumberOfProjects = this.iNumberOfFilteredProjectsUnderEngagement;
			this.getView().getModel("projectsUnderEngagement").refresh();
			this.GanttViewController.fnHandleCancelProjectsArrangementPressed();
			this.getView().getModel("localModel").getData().bVsdFilterBarVisible = !!this.getView().byId("multiInput").getTokens().length;
			this.getView().getModel("localModel").getData().bIsInRearrangeMode = false;
			this.getView().getModel("localModel").refresh();

		},

		/* ========================================== Project Calendar END  =============================================== */
		/* ================================================================================================================== */




		handleClearAllMessages: function () {
			this.messageHandler.clearAllMessages(this.getView(), this.oMessagePopover);
		},


		/* =================================================================================================================== */
		/*=======================================================================================================================*/
		/*========================================= Search Help - Engagement Case ===============================================*/
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		handleValueHelpEngagementCase: function (oEvent, oInitialFilterValues) {
			let oFilterValues = {};
			Object.assign(oFilterValues, oInitialFilterValues, {
				CustomerBpId: this.getView().getModel("projectDetails").getData().CustomerID,
				CustomerName: this.getView().getModel("projectDetails").getData().CustomerName,
				ExactCustomerId: true,
				DisableCustomerFields: false,
				sDialogWidth: "1200px",
				sDialogHeight: "790px",
				DisableReasonCombo: true,
				ReasonCode: "ENG1" //fix to "Global Engagements"
			});
			EngagementSelection.fnEngagementSelectionDialogOpen(this.getView(), this.getResourceBundle(), oFilterValues, (oSelectedEngCase) => {
				if (oSelectedEngCase) {
					this.getView().getModel("projectDetails").getData().ParentCaseID = oSelectedEngCase.ProjectID;
					this.getView().getModel("projectDetails").refresh();
				} else {
					// user has cancelled the Eng-Selection-Dialog - nothing was selected, keep the current values - so do nothing
				}
			});
		},

		onChildProjectPressed: function (oEvent) {
			let sCurrentSelectionPath = oEvent.getParameters().listItem.getBindingContext("projectsUnderEngagement").getPath(),
				oModel = this.getView().getModel("projectsUnderEngagement"),
				sCaseDetails = oModel.getProperty(sCurrentSelectionPath);
			if (sCaseDetails) {
				let aReasonOptions = Constants.getReasonOptions();
				this._oData.busyProjectDetailsPage = true;
				this._oModel.refresh();
				if (sCaseDetails.ReasonCode === aReasonOptions.globalEng || sCaseDetails.ReasonCode === aReasonOptions.engagement) {
					this._navToEngagement(sCaseDetails.ProjectID);
				} else {
					this._navToDetails(sCaseDetails.ProjectID);
				}
			}
		},

		onLinkGlobalEngPressed: function (oEvent) {
			try {
				this._navToEngagement(this.getView().getModel("projectDetails").getData().ParentCaseID);
			} catch (oError) {
				//
			}
		},

		_navToDetails: function (sCaseID) {
			this.getRouter().navTo("ProjectDetails", {
				projectID: sCaseID
			});
		},

		_navToEngagement: function (sCaseID) {
			this.getRouter().navTo("EngagementDetails", {
				engagementID: sCaseID
			});
		},

		onChildActivityPressed: function (oEvent) {
			let sCurrentSelectionPath = oEvent.getParameters().listItem.getBindingContext("activities").getPath(),
				oModel = this.getView().getModel("activities"),
				oActivity = oModel.getProperty(sCurrentSelectionPath);
			if (oActivity) {
				this.getOwnerComponent().trackEvent("Trigger_DisplayActivity_InPEA");
				NavigationToExternalApps.fnNavigateToPeActivityApp(this, oActivity.ActivityGuid, "ActivityDisplay");
			}
		},

		onNavToEngagementDetails: function (oEvent) {
			let sEngId = this.getView().getModel("projectDetails").getData().ParentCaseID;
			this._navToEngagement(sEngId);
		},

		/* ======================================== Project General Data =========================================== */
		/* ============================================ Load section =========================================== */

		pReadProjectData: function () {
			return new Promise((res, rej) => {
				let entities = {};
				let idProject = this._idProject;
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "ProjectSet";
				entities.getEntity = idProject;
				entities.currentView = this.getView();
				entities.oContext = this;
				entities.errorMessage = this.getResourceBundle().getText("ProjectDetails.ReadProjectDataError", [idProject]);
				entities.busyIndicator = "busyProjectDetailsHeader";
				entities.expand = "toProjectCustomer";
				entities.callbackSuccess = (data) => {
					this._handleSuccessProjectData(data);
					res();
				};
				this.readBaseRequest(entities);
			});
		},

		_handleSuccessProjectData: function (data) {
			this._oData.cloneOfProjectDetails = JSON.stringify(data);
			let oEmployees = this.getView().getModel("projectDetails").getData().employees;
			this.getView().getModel("projectDetails").setData(data);
			this.getView().getModel("projectDetails").getData().employees = oEmployees;
			this._oData.minDatePhaseItems = this.getView().getModel("projectDetails").getData().ProjectStartDate;
			this._oData.maxDatePhaseItems = this.getView().getModel("projectDetails").getData().ProjectEndDate;
			this.getView().getModel("projectDetails").getData().projectStatus = Constants.getItemStatus();
			this.getView().getModel("projectDetails").getData().caseRatings = Constants.getCaseRatingComboValues();
			this._bIsGlobalEngagement = data.ReasonCode === "ENG1";
			this.getView().getModel("localModel").getData().customerProjectsTabTitle = this._bIsGlobalEngagement ? this.getResourceBundle().getText(
				"EngagementDetails.EngagementList.Title") : this.getResourceBundle().getText("EngagementDetails.ProjectList.Title");
			this._oData.busyProjectDetailsHeader = false;
			this._oModel.refresh();
			this._initFilterModel();
			if (!this._bIsGlobalEngagement) this._initVariants();
			this._trackEngagementDetails(data.ReasonCode);
			this._loadCustomerData(data.CustomerID);
		},

		_loadCustomerData: function (nCustomerNumber) {
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = Constants.getEntities().CustomerEntity;
			entities.filter = `CustomerID eq '${nCustomerNumber}'`;
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.callbackSuccess = (data) => {
				this.getView().getModel("VHCustomer").setData(data.results[0]);
				this.getView().getModel("VHCustomer").refresh();
			};
			this.readBaseRequest(entities);

		},

		_setProjectStatus: function () {
			this.getView().getModel("projectDetails").getData().projectStatus = Constants.getItemStatus();
			this.getView().getModel("projectDetails").refresh();
		},

		/**
		 *  Track an event if a user displays a case details with reason "Engagement Case"
		 *  @param {string} sReasonCode - The reason code of the case
		 */
		_trackEngagementDetails: function (sReasonCode) {
			if (!this.getView().getModel("localModel").getData().disableReporting &&
				!this.getOwnerComponent().getModel("appData").getData().noReporting
			) {
				this.getOwnerComponent().trackEvent("Display_Engagement");
			}
			this.getView().getModel("localModel").getData().disableReporting = false;
			this.getOwnerComponent().getModel("appData").getData().noReporting = false;
		},

		/* ===================================================================================================== */
		/* ===================================================================================================== */
		/* ======================================== Contracts Section ========================================== */

		_fnEngCaseContractSectionRead: function (sCaseId) {
			EngagementContracts._fnEngCaseContractSectionRead(this, sCaseId);
		},

		fnEngCaseContractSectionHandleDelete: function (oEvent) {
			EngagementContracts.fnEngCaseContractSectionHandleDelete(this, oEvent);
		},
		fnEngCaseContractSectionHandleShowAccountStatement: function (oEvent) {
			EngagementContracts.fnEngCaseContractSectionHandleShowAccountStatement(this, oEvent);
		},
		fnEngCaseContractSectionHandleOpenForecastApp: function (oEvent) {
			EngagementContracts.fnEngCaseContractSectionHandleOpenForecastApp(this, oEvent);
		},
		fnEngCaseContractSectionHandleMainFlag: function (oEvent) {
			EngagementContracts.fnEngCaseContractSectionHandleMainFlag(this, oEvent);
		},

		fnEngCaseContractSearchPopupOpen: function (oEvent) {
			EngagementContracts.fnInitialize(this);
			EngagementContracts.fnEngCaseContractSearchPopupOpen(this, oEvent);
		},

		fnEngCaseContractSearchPopupSearch: function (oEvent) {
			EngagementContracts.fnEngCaseContractSearchPopupSearch(this, oEvent);
		},

		fnEngCaseContractSearchPopupClose: function (oEvent) {
			EngagementContracts.fnEngCaseContractSearchPopupClose(this, oEvent);
		},

		// New Version of popup - KNGMHM02-23694
		onVHPartnerSelect: function (oEvent) {
			this.onVHPartnerSelectGetValues(oEvent);
			let sPartnerID = this.getView().getModel("localModel").getData().bpSearchReturnPartnerID || "";
			let sFullName = this.getView().getModel("localModel").getData().bpSearchReturnFullName || "";
			let sBPSearchReturnType = this.getView().getModel("localModel").getData().bpSearchReturnType || "PartiesInvolved";
			if (sBPSearchReturnType === "PartiesInvolved") {
				this.partiesInvolved.setNewPartner(sPartnerID, sFullName);
			} else if (sBPSearchReturnType === "EngScopeSearchPopupCustomerValueHelp") {
				let oScopeData = new JSONModel({});
				oScopeData.getData().PartnerNo = sPartnerID;
				this._saveEngagementScopeCreateCustomerData(oScopeData.getData());
			}
			this.partiesInvolved.closeSearchHelpDialog();
		},

		/* =================================================================================================== */
		/* =================================================================================================== */
		/* ======================================== Activities List ========================================== */

		_determineSortingEngagementTasksSection: function () {
			let oTable = this.getView().byId("ActivitiesTable");

			let aColumns = oTable.getColumns(),
				oSortProperties = {};
			let oSortingColumn = aColumns.find(oColumn => oColumn.getSortIndicator() !== "None");
			if (oSortingColumn) {
				oSortProperties.field = oSortingColumn.getSortField();
				oSortProperties.order = oSortingColumn.getSortIndicator();
			} else {
				oSortProperties = null;
			}

			return oSortProperties;
		},

		_readActivitiesAssignedToEngagement: function (oSort) {
			this._oData.busyActivitiesList = true;
			this._oModel.refresh();
			let entities = {},
				oSortProperties = oSort || this._determineSortingEngagementTasksSection();
			entities.servicePath = Constants.getServicePathPEA();
			entities.entitySet = "ActivitySet";
			entities.inlineCount = "allpages";
			if (oSortProperties) {
				entities.sortItem = oSortProperties.field;
				entities.sortOrder = Constants.getSortOrder()[oSortProperties.order];
			}
			entities.paginationTop = Constants.getPaginationTop();
			entities.paginationSkip = this._oData.paginationSkip;
			entities.filter = ` RefDocID eq '${this._idProject}'`;
			entities.errorMessage = this.getResourceBundle().getText("ProjectEntityPerUser.ErrorMessage");
			entities.oContext = this;
			entities.currentView = this.getView();
			entities.busyIndicator = "busyActivitiesList";
			entities.callbackSuccess = (oData) => {
				this._handleSuccessReadingActivitiestList(oData);
			};
			this.readBaseRequest(entities);
		},

		_handleSuccessReadingActivitiestList: function (oData) {
			this.getView().getModel("activities").getData().results = oData.results;
			this.getView().getModel("activities").getData().iNumberOfActivities = oData.__count;
			this.getView().getModel("activities").refresh();
			this._oData.busyActivitiesList = false;
			this._oModel.refresh();
			this._handlePaginationElementsActivity();
		},

		fnHandleSearchForItems: function (oSort) {
			let sSelectedSection = this.getView().byId("ObjectPageLayoutEngagement").getSelectedSection();
			if (sSelectedSection.indexOf("projects") > -1) {
				this._readProjectsAssignedToEngagement(oSort);
			}
			if (sSelectedSection.indexOf("activities") > -1) {
				this._readActivitiesAssignedToEngagement(oSort);
			}
			if (sSelectedSection.indexOf("linkedObjects") > -1) {
				this._readLinkedObjectsAssigned(oSort);
			}
		},

		fnShowResponsibleDetails: function (oEvent) {
			let oSource = oEvent.getSource(),
				sSelectedIndex = oSource.getBindingContext("activities").getPath().split("results/")[1],
				sResponsibleID = this.getView().getModel("activities").getData().results[sSelectedIndex].ResponsibleID;
			this.employeeDetails.displayEmployeePopover(oEvent, this.getView(), "activities", "ResponsibleID", sResponsibleID);
		},

		fnShowCreatedByDetails: function (oEvent) {
			let oSource = oEvent.getSource(),
				sSelectedIndex = oSource.getBindingContext("activities").getPath().split("results/")[1],
				sCreatedBy = this.getView().getModel("activities").getData().results[sSelectedIndex].CreatedBy;
			this.employeeDetails.displayEmployeePopover(oEvent, this.getView(), "activities", "CreatedBy", sCreatedBy);
		},

		fnAddEngagementActivity: function (oEvent) {
			let sCaseID = this.getView().getModel("projectDetails").getData().ProjectID;
			this.getOwnerComponent().trackEvent("Trigger_CreateActivity_InPEA");
			NavigationToExternalApps.fnNavigateToPeActivityApp(this, sCaseID, "ActivityCreate");
		},

		fnSearchEngagementActivity: function (oEvent) {
			let sCaseID = this.getView().getModel("projectDetails").getData().ProjectID;
			this.getOwnerComponent().trackEvent("Trigger_DisplayActivity_InPEA");
			NavigationToExternalApps.fnNavigateToPeActivityApp(this, sCaseID, "ActivitySearch");
		},

		_initializeActivitiesTablePerso: function () {
			this.getView().byId("ActivitiesTable").removeSelections();
			if (this._oTPCActivities === undefined) {
				this._oTPCActivities = new TablePersoController({
					table: this.getView().byId("ActivitiesTable"),
					componentName: "tablePerso",
					persoService: TablePersoActivities
				}).activate();
			}
		},

		onActivitiesPersoButtonPressed: function (oEvent) {
			this._oTPCActivities.openDialog();
		},

		onActivitiesTablePersoRefresh: function () {
			TablePersoActivities.resetPersData();
			this._oTPCActivities.refresh();
		},

		onActivitiesResetSort: function () {
			let oTable = this.getView().byId("ActivitiesTable");
			oTable.resetSorting();
			this._readActivitiesAssignedToEngagement();
		},

		fnEngagementTasksRefresh: function (oEvent) {
			this._readActivitiesAssignedToEngagement();
		},

		_handlePaginationElementsActivity: function () {
			let iNumberOfActivities = this.getView().getModel("activities").getData().iNumberOfActivities;
			this.pagination._paginationElements(this, iNumberOfActivities,
				this.getView().byId("btnPaginationNextActivities"), this.getView().byId("btnPaginationPrevActivities"));
		},

		navToPreviousRecordsActivities: function () {
			let pagination = this.pagination.goToPreviousPage(this, this._oData.paginationClicks);
			this._oData.paginationClicks = pagination.clicks;
			this._oData.paginationSkip = pagination.skip;
			this._readActivitiesAssignedToEngagement();
		},

		navToNextRecordsActivities: function () {
			let pagination = this.pagination.goToNextPage(this, this._oData.paginationClicks);
			this._oData.paginationClicks = pagination.clicks;
			this._oData.paginationSkip = pagination.skip;
			this._readActivitiesAssignedToEngagement();
		},

		fnHandleShowEngagementInformation: function (oEvent) {
			let oPopOverSource = oEvent.getSource();
			this._pPopoverInfoEngagement ??= this._loadFragment("com.sap.ui.hep.view.Details.Engagement.fragment.PopoverInfoEngagementDetails");
			this._pPopoverInfoEngagement.then(oPopover => {
				oPopover.setModel(this.getView().getModel("projectDetails"), "projectDetailsModel");
				oPopover.setModel(this.getOwnerComponent().getModel("i18n"), "i18n");
				oPopover.openBy(oPopOverSource);
			});
		},

		fnShowEmployeeRespDetailsPop: function (oEvent) {
			const sEmplId = this.getView().getModel("projectDetails").getData().EmplRespID;
			this.employeeDetails._loadEmployeePopover(sEmplId, this.getView(), oEvent, this._oPopoverSource);
		},

		fnShowEmployeeTqmDetailsPop: function (oEvent) {			
			const sEmplId = this.getView().getModel("projectDetails").getData().TqmID;

			if (!this.EmployeeSelection1) this.EmployeeSelection1 = new EmployeeSelection();
			this.EmployeeSelection1._fnGetOneEmployeeFromBE("", sEmplId, (aODataResults) => {
				if (aODataResults.length === 1) {
					this.employeeDetails._loadEmployeePopover(aODataResults[0].UserId, this.getView(), oEvent, this._oPopoverSource);
				}
			});
		},
		fnShowEmployeeLtqmDetailsPop: function (oEvent) {
			let sEmplId = this.getView().getModel("projectDetails").getData().LtqmID;

			if (!this.EmployeeSelection1) this.EmployeeSelection1 = new EmployeeSelection();
			this.EmployeeSelection1._fnGetOneEmployeeFromBE("", sEmplId, (aODataResults) => {
				if (aODataResults.length === 1) {
					this.employeeDetails._loadEmployeePopover(aODataResults[0].UserId, this.getView(), oEvent, this._oPopoverSource);
				}
			});
			
		},

		//************************************************************************************************************
		// ****************************************  SECTION Top Issues **********************************************

		_readEngagementTopIssues: function () {
			this._oData.busyTopIssuesEngagement = true;
			this._oModel.refresh();
			this._readTopIssues("topIssuesEngagementModel", () => {
				this._oData.busyTopIssuesEngagement = false;
				this._oModel.refresh();
			});
		},

		navToPreviousRecordsTopIssues: function () {
			let pagination = this.pagination.goToPreviousPage(this, this._oData.paginationClicks);
			this._oData.paginationClicks = pagination.clicks;
			this._oData.paginationSkip = pagination.skip;
			this._readEngagementTopIssues();
		},

		navToNextRecordsTopIssues: function () {
			let pagination = this.pagination.goToNextPage(this, this._oData.paginationClicks);
			this._oData.paginationClicks = pagination.clicks;
			this._oData.paginationSkip = pagination.skip;
			this._readEngagementTopIssues();
		},

		//*************************************************************************************************************
		// ****************************************  SECTION Linked Objects *******************************************

		_readLinkedObjects: function () {
			this._oData.busyLinkedObjects = true;
			this._oModel.refresh();
			let oEntities = {
				"servicePath": Constants.getServicePath(),
				"entitySet": "ProjectItemSet",
				"paginationTop": Constants.getPaginationTop(),
				"paginationSkip": this._oData.paginationSkip,
				"inlineCount": "allpages",
				"busyIndicator": "busyLinkedObjects",
				"filter": "(ProjectID eq '" + this._idProject + "' and TransactionType eq 'ZS46')",
				"currentView": this.getView(),
				"oContext": this,
				"callbackSuccess": (oData) => {
					this._handleSuccessReadLinkedObjects(oData);
				}
			}
			this.readBaseRequest(oEntities);
		},

		_readLinkedObjectsAssigned: function (oSort) {
			this._oData.busyLinkedObject = true;
			this._oModel.refresh();
			let entities = {},
				oSortProperties = oSort || this._determineSortingLinkedObjectsSection();
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ProjectItemSet";
			entities.inlineCount = "allpages";
			if (oSortProperties) {
				entities.sortItem = oSortProperties.field;
				entities.sortOrder = Constants.getSortOrder()[oSortProperties.order];
			}
			entities.paginationTop = Constants.getPaginationTop();
			entities.paginationSkip = this._oData.paginationSkip;
			entities.filter = ` ProjectID eq '${this._idProject}' and TransactionType eq 'ZS46'`;
			entities.errorMessage = this.getResourceBundle().getText("ProjectEntityPerUser.ErrorMessage");
			entities.oContext = this;
			entities.currentView = this.getView();
			entities.busyIndicator = "busyLinkedObjects";
			entities.callbackSuccess = (oData) => {
				this._handleSuccessReadLinkedObjects(oData);
			};
			this.readBaseRequest(entities);
		},


		_determineSortingLinkedObjectsSection: function () {
			let oTable = this.getView().byId("LinkedObjectsTable");

			let aColumns = oTable.getColumns(),
				oSortProperties = {};
			let oSortingColumn = aColumns.find(oColumn => oColumn.getSortIndicator() !== "None");
			if (oSortingColumn) {
				oSortProperties.field = oSortingColumn.getSortField();
				oSortProperties.order = oSortingColumn.getSortIndicator();
			} else {
				oSortProperties = null;
			}

			return oSortProperties;
		},


		_handleSuccessReadLinkedObjects: function (oData) {
			this._oData.busyLinkedObjects = false;
			oData.results = oData.results.map(function (item) {
				let sLinkDisplay = "";
				sLinkDisplay = item.TbuiUrl;
				item.linkDisplay = sLinkDisplay;
				return item;
			}, this);
			this.getModel("linkedObjectsModel").setProperty("/iNumberOfLinkedObjects", oData.__count);
			this.getModel("linkedObjectsModel").setProperty("/results", oData.results);
			this._handlePaginationElementsLinkedObjects();
			this.getModel("linkedObjectsModel").refresh();
		},

		_handlePaginationElementsLinkedObjects: function () {
			let iNumberOfLinkedObjects = this.getView().getModel("linkedObjectsModel").getProperty("/iNumberOfLinkedObjects");
			this.pagination._paginationElements(this, iNumberOfLinkedObjects,
				this.getView().byId("btnPaginationNextLinkedObjects"), this.getView().byId("btnPaginationPrevLinkedObjects"));
		},

		navToPreviousRecordsLinkedObjects: function () {
			let pagination = this.pagination.goToPreviousPage(this, this._oData.paginationClicks);
			this._oData.paginationClicks = pagination.clicks;
			this._oData.paginationSkip = pagination.skip;
			this._readLinkedObjects();
		},

		navToNextRecordsLinkedObjects: function () {
			let pagination = this.pagination.goToNextPage(this, this._oData.paginationClicks);
			this._oData.paginationClicks = pagination.clicks;
			this._oData.paginationSkip = pagination.skip;
			this._readLinkedObjects();
		},

		handleOpenLinkInNewWindowDisplay: function (sLink) {
			NavigationToExternalApps.fnHandleLinkNavigation(sLink);
		},
		handleOpenLinkInNewWindowEdit: function (sLink) {
			NavigationToExternalApps.fnHandleLinkNavigation(sLink.replace("crm-object-action=B", "crm-object-action=C"));
		},

		onLinkedObjectsResetSort: function () {
			let oTable = this.getView().byId("LinkedObjectsTable");
			oTable.resetSorting();
			this._readLinkedObjects();
		},

		_initializeLinkedObjectsTablePerso: function () {
			this.getView().byId("LinkedObjectsTable").removeSelections();
			if (this._oTPCLinkedObjects === undefined) {
				this._oTPCLinkedObjects = new TablePersoController({
					table: this.getView().byId("LinkedObjectsTable"),
					componentName: "tablePerso",
					persoService: TablePersoLinkedObjects
				}).activate();
			}
		},

		onLinkedObjectsPersoButtonPressed: function (oEvent) {
			this._oTPCLinkedObjects.openDialog();
		},

		onLinkedObjectsTablePersoRefresh: function () {
			TablePersoLinkedObjects.resetPersData();
			this._oTPCLinkedObjects.refresh();
		},

		fnShowLOResponsibleDetails: function (oEvent) {
			let oSource = oEvent.getSource(),
				sSelectedIndex = oSource.getBindingContext("linkedObjectsModel").getPath().split("results/")[1],
				sResponsibleID = this.getView().getModel("linkedObjectsModel").getData().results[sSelectedIndex].ResponsibleID;
			this.employeeDetails.displayEmployeePopover(oEvent, this.getView(), "linkedObjectsModel", "ResponsibleUsr", sResponsibleID);
		},

		fnShowLOCreatedByDetails: function (oEvent) {
			let oSource = oEvent.getSource(),
				sSelectedIndex = oSource.getBindingContext("linkedObjectsModel").getPath().split("results/")[1],
				sCreatedBy = this.getView().getModel("linkedObjectsModel").getData().results[sSelectedIndex].CreatedBy;
			this.employeeDetails.displayEmployeePopover(oEvent, this.getView(), "linkedObjectsModel", "CreatedBy", sCreatedBy);
		},

		/* ======================================== Reference Objects ============================================== */

		fnHandleAddNewRefObj: function (oEvent) {
			this.referenceObjects.loadReferenceObjectsDialog(oEvent, this);
		},

		fnHandleDiscardRefObj: function (oEvent) {
			this.referenceObjects.discardReferenceObjectsDialog(oEvent, this);
		},

		refObjListSelectionChange: function (oEvent) {
			this.referenceObjects.fnHandleSelectionChange(oEvent, this);
		},

		onRONavBack: function (oEvent) {
			this.referenceObjects.onRONavBack(this);
		},

		onSearchForReferenceObjects: function (oEvent) {
			this.referenceObjects.searchROonGOBtn(oEvent, this);
		},

		onCustomerIDOrInstNoChange: function () {
			this.referenceObjects.onCustomerIDOrInstNoChange(this);
		},

		resetSorting: function (oEvent) {
			this.referenceObjects.resetSorting(oEvent, this);
		},

		searchCustomerSpecific: function (oEvent) {
			this.referenceObjects.searchCustomerSpecific(oEvent, this);
		},

		handleCustomerItemPressed: function (oEvent) {
			let oSource = oEvent.getSource(),
				sPath = oSource.getSelectedContextPaths(),
				iSelectedItemIndex = parseInt(sPath[0].split("/")[2], 10),
				oSelectedItemFromModel = this.getView().getModel("customerSearchHelp").getData().results[iSelectedItemIndex];
			if (oEvent.getSource().getParent().getParent().getParent().getId().indexOf("detail") === -1) {
				this._oSelectedItem = oSelectedItemFromModel;
				this.onCustomerResultsPressed();
			} else {
				this.getView().getModel("engagementsSearchHelp").getData().CustomerBpId = oSelectedItemFromModel.CustomerID;
				this.getView().getModel("engagementsSearchHelp").getData().CustomerName = oSelectedItemFromModel.CustomerName;
				this.getView().getModel("engagementsSearchHelp").refresh();
				this._oSelectedItem = oSelectedItemFromModel;
				this.getView().getModel("customerSearchHelp").getData().selectedItem = oSelectedItemFromModel;
				this.getView().getModel("customerSearchHelp").refresh();
				this.fnSearchEngagementCases();
				this.onEngCaseVHNavBack();
			}
		},
		onEngCaseVHNavBack: function (oContext) {
			let oNavCon = this.getView().byId("navContainer");
			oNavCon.back();
			this.getView().getModel("customerSearchHelp").getData().selectedCustomerName = "";
			this.getView().getModel("customerSearchHelp").refresh();
		},

		fnHandleAddRefObj: function (oEvent) {
			this.referenceObjects.fnHandleAddRefObj(oEvent, this);
		},



		// ==================================== Tiles in screen Frequently used tools =================================================== */

		onPressTile: function (oEvent) {
			let sUrl = oEvent.getSource().getUrl();
			if (sUrl) {
				NavigationToExternalApps.fnHandleLinkNavigation(sUrl);
			}
		},

		handleDisplayTopIssueEngagement: function (oEvent) {
			this.navToDisplayTopIssueInCrm(oEvent, "topIssuesEngagementModel");
		},

		handleEditTopIssue: function (oEvent) {
			this.navToEditTopIssueInCrm(oEvent, "topIssuesEngagementModel");
		},

		// ================================== Filters Customer Projects =============================================

		onFilterItemPressed: function (oParam) {
			let filterlist = this.variant.currentVariant.filter.getData().filterlist;
			let hasBeenClicked = this.variant.currentVariant.filter.getData().hasBeenClicked;

			FilterHelper.getViewSettingsDialog("com.sap.ui.hep.view.Details.Engagement.fragment.CustomerProjectsFilters", this, this._mViewSettingsDialogs)
				.then((oViewSettingsDialog) => {
					if (this.searchFilters === "" && this.getView().byId("filterDialog"))
						this.getView().byId("filterDialog").clearFilters();
					if (filterlist && !hasBeenClicked) {
						this.variant.currentVariant.filter.getData().hasBeenClicked = true;
						this.getView().byId("filterDialog").getFilterItems().forEach(oEntry => {
							if (oEntry.getCustomControl?.().getValue) this.lastFilters.push(oEntry.getCustomControl().getValue());
							this.lastFilters = FilterHelper.handleCreationOfFilterPopUpFromVariantServices(oEntry, filterlist, this.lastFilters);
						});
					}

					["dynamic-range", "dynamic-range2", "dynamic-range3"].forEach(oDateFilter => FilterHelper.buildOptionsForDateFilters(oDateFilter, this));

					let oFD2 = this.getView().byId("filterDialog");
					oParam === true ? oFD2.fireConfirm() : oViewSettingsDialog.open(oFD2._getPage1());
				});
		},

		onConfirmPressed: function (oEvent) {

			this._oData.paginationClicks = 0;
			this._oData.paginationSkip = 0;

			let aItemsSelected = oEvent.getParameters().filterItems;
			this.byId("multiInput").removeAllTokens();

			FilterHelper.refreshMultiInput(this);

			let aParams = " and (";
			this.lastFilters = [];
			this.oStore = {};

			if (aItemsSelected === undefined) {
				aItemsSelected = this.getView().byId("filterDialog").getSelectedFilterItems();
			}

			oEvent.getSource().getFilterItems().forEach(oItemED => {

				if (oItemED.getText().includes("Date")) {
					aParams = FilterHelper.generateFilterStringForDateFilters(oItemED, this, aParams);
				}

				if (oItemED.getCustomControl?.().getValue && !oItemED.getText().includes("Date")) {
					this.lastFilters.push(oItemED.getCustomControl().getValue());
				}

				if (oItemED.getCustomControl?.().getValue?.() && !oItemED.getText().includes("Date")) {

					aParams = FilterHelper.generateFilterStringForFreeText(oItemED, this, aParams, "projects");

				}
			});

			if (aParams.length > 6) {
				aParams = aParams.substring(0, aParams.length - 4);
				aParams += ")";
			} else {
				aParams = aParams.substring(0, aParams.length - 5);
			}

			aParams = FilterHelper.generateFilterStringForStandardFiltersServices(aItemsSelected, this, aParams, "Project");



			if (aParams.length !== 1) {
				this.searchFilters = aParams;
				this.getView().getModel("localModel").getData().filtersSetted = true;
			} else {
				this.searchFilters = "";
				this.getView().getModel("localModel").getData().filtersSetted = false;
			}

			this._readProjectsAssignedToEngagement();
			this._fnReadAllEngagementProjectsWithoutFilter();
			this.getView().getModel("localModel").refresh();

		},

		eventFired: function (oEvent, sId) {
			FilterHelper.eventFired(oEvent, sId, this);
		},

		cancelInputs: function (oEvent) {
			FilterHelper.cancelInputs(oEvent, this, this.lastFilters, 3);
		},

		resetInputs: function (oEvent) {
			FilterHelper.resetInputs(oEvent);
		},

		removeFilterFromBar: function (oEvent) {
			FilterHelper.removeFilterFromBar(oEvent, this);
		},

		_resetFilters: function () {
			FilterHelper.resetFilters(this)
		},

		//triggered in the initial loading, since we land on the tab customer projects and when we navigate back to customer projects
		_initVariants: async function () {
			this.variant.context = this;
			this.variant.pageVariantID = "pageVariantID";
			this.getView().setModel(this.variant.variantModel, "variantModel");
			this.variant.variantSetName = "Engagements_Home";
			this.variant.variantLoaded = () => {
				// Update view model from current variant
				let oTablePerso = this.getTablePerso();
				if (this.variant.currentVariant.tablePerso.getData()) {
					oTablePerso.getPersoService().setPersData(this.variant.currentVariant.tablePerso.getData());
				} else {
					oTablePerso.getPersoService().resetPersData();
				}
				oTablePerso.refresh();

				this._initFilterModel();
				this._resetFilters();
				this.getView().getModel("filterModel").getData().searchTerm = this.variant.currentVariant.filter.getData().searchTerm ===
					undefined ? "" : this.variant.currentVariant.filter.getData().searchTerm;
				this.getView().getModel("filterModel").getData().statusSelected = this.variant.currentVariant.filter.getData().statusSelected;
				this.getView().getModel("filterModel").getData().rangeSelected = this.variant.currentVariant.filter.getData().rangeSelected;
				this.getView().getModel("filterModel").refresh();

				this.getView().getModel("localModel").refresh();

				this.getView().byId("customerProjectTable").resetSorting();

				this._oSort = this.variant.currentVariant.filter.getData().sortItem;
				this.variant.currentVariant.filter.getData().hasBeenClicked = false;

				if (this.variant.currentVariant.filter.getData().filtersetted) {
					this.searchFilters = this.variant.currentVariant.filter.getData().filtersetted;
					this._oData.filtersSetted = true;
					this.oStore = this.variant.currentVariant.filter.getData().filterlist;
				} else {
					this._oData.filtersSetted = false;
				}

				this.onFilterItemPressed(true);
			};

			// Reset table personlization and save as assigne to standard variant
			await this.getTablePerso().getPersoService().resetPersData();
			this.getTablePerso().getPersoService().getPersData().done(function (oPersData) {
				for (const element of oPersData.aColumns) {
					// Standard setting use 'tablePerso'-IDs for some reason.
					// In order to reapply the standard personalization we need to harmonize that by using the componentName
					element.id = element.id.replace("tablePerso-", this.getTablePerso().getComponentName() + "-");
				}
				let oStandardVariant = this.variant.standardVariant;
				oStandardVariant.tablePerso.setData(oPersData);
				oStandardVariant.filter.getData().filtersetted = "";
				oStandardVariant.filter.getData().filterlist = "";
				oStandardVariant.filter.getData().sortItem = undefined;
				oStandardVariant.filter.getData().hasBeenClicked = false;
				oStandardVariant.filter.getData().searchTerm = "";
				oStandardVariant.filter.getData().statusSelected = ['71', '80', '81'];
				oStandardVariant.filter.getData().rangeSelected = "all";
			}.bind(this));

			this.variant.readVariants(null);
		},

		onVariantSaveCustomerProjects: function (oEvent) {
			let oCurrentVariant = this.variant.currentVariant;
			oCurrentVariant.filter.getData().searchTerm = this.getView().getModel("filterModel").getData().searchTerm;
			oCurrentVariant.filter.getData().statusSelected = this.getView().getModel("filterModel").getData().statusSelected;
			oCurrentVariant.filter.getData().rangeSelected = this.getView().getModel("filterModel").getData().rangeSelected;
			oCurrentVariant.filter.getData().filtersetted = this.searchFilters;
			oCurrentVariant.filter.getData().filterlist = this.oStore;
			oCurrentVariant.filter.getData().sortItem = this._oSort;

			this.getTablePerso().getPersoService().getPersData().done(function (oPersData) {
				let oStandardVariant = this.variant.standardVariant;
				this.variant.currentVariant.tablePerso.setData(oPersData);
				this.variant.onSave(oEvent);
				oStandardVariant.filter.getData().filtersetted = "";
				oStandardVariant.filter.getData().filterlist = "";
				oStandardVariant.filter.getData().sortItem = undefined;
				oStandardVariant.filter.getData().hasBeenClicked = false;
				oStandardVariant.filter.getData().searchTerm = "";
				oStandardVariant.filter.getData().statusSelected = ['71', '80', '81'];
				oStandardVariant.filter.getData().rangeSelected = "all";
			}.bind(this));
		},

		onVariantSelect: function (oEvent) {
			this.variant.onSelect(oEvent);
		},

		onVariantManage: function (oEvent) {
			this.variant.onManage(oEvent);
		},

		getTablePerso: function () {
			return this._oTPCCustomerProjects;
		},

		handleMakeItUnfavorite: function (oEvent) {
			this.bFavorite = false;
			this._toggleFavoriteEngagements(oEvent);
		},

		handleMakeItFavorite: function (oEvent) {
			this.bFavorite = true;
			this._toggleFavoriteEngagements(oEvent);
		},

		_toggleFavoriteEngagements: function (oEvent) {
			this._oData.busyIndicatorActivities = true;
			this._oModel.refresh();

			let oSrc = oEvent.getSource(),
				sPath = oSrc.getBindingContext("projectsUnderEngagement").getPath(),
				oProject = this.getView().getModel("projectsUnderEngagement").getProperty(sPath);

			return new Promise((resolve, reject) => {
				this._updateProject(resolve, reject, oProject);
			}).then((oData) => {
				let sShowText = this.bFavorite ? this.getResourceBundle().getText("Home.AddedToFavorites") : this.getResourceBundle().getText("Home.RemovedFromFavorites");
				MessageToast.show(sShowText);

				let oEngProjectsModel = this.getView().getModel("projectsUnderEngagement");
				oEngProjectsModel.getProperty(sPath).IsFavorite = this.bFavorite;
				oEngProjectsModel.refresh();

				this._oData.busyIndicatorActivities = false;
				this._oModel.refresh();
			});
		},

	});

});
