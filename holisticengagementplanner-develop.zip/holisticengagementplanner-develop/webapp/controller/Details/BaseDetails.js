sap.ui.define([
	"com/sap/ui/hep/util/PartiesInvolved",
	"sap/ui/model/json/JSONModel",
	"com/sap/ui/hep/controller/BaseController",
	"com/sap/ui/hep/model/formatter",
	"com/sap/ui/hep/reuse/Constants",
	"com/sap/ui/hep/util/NavigationToExternalApps"

], function (PartiesInvolved, JSONModel, BaseController, Formatter, Constants, NavigationToExternalApps) {

	return BaseController.extend("com.sap.ui.hep.controller.Details.BaseDetails", {

		partiesInvolved: PartiesInvolved,

		onAfterRendering: function () {
			this.getValidToken(this);
		},

		navToHome: function () {
			this.getOwnerComponent().getEventBus().publish("ChannelServicePlanSection", "EmptyServicePlanSection", null); //otherwise user sees temporarily the old, data, in case comes back to another project
			this.activateBusyIndicators(this);
			this.handleClearAllMessages();
			this._oData.formEditMode = false;
			this._oModel.refresh();
			this.getRouter().navTo("Home");
		},


		activateBusyIndicators: function (oContext) {
			oContext._oData.busyProjectDetailsHeader = true;
			oContext._oData.busyProjectPlanning = true;
			oContext._oData.busyAttachments = true;
			oContext._oData.busyProjectDetailsPage = true;
			oContext._oData.busyTQMs = true;
			oContext._oData.busyReferenceObjects = true;
			oContext._oData.busyNotesBox = true;
			oContext._oData.busyCustomerProjectsList = true;
			oContext._oData.busyActivitiesList = true;
			oContext._oData.busyActivitiesProject = true;
			oContext._oData.busyLinkedObjects = true;
			oContext._oData.busyTopIssuesProject = true;
			oContext._oData.busyTopIssuesEngagement = true;
			oContext._oModel.refresh();
		},

		inactiveBusyIndicators: function (oContext) {
			oContext._oData.busyProjectDetailsHeader = false;
			oContext._oData.busyProjectPlanning = false;
			oContext._oData.busyAttachments = false;
			oContext._oData.busyProjectDetailsPage = false;
			oContext._oData.busyTQMs = false;
			oContext._oData.busyNotesBox = false;
			oContext._oData.busyReferenceObjects = false;
			oContext._oData.busyCustomerProjectsList = false;
			oContext._oData.busyActivitiesList = false;
			oContext._oData.busyActivitiesProject = false;
			oContext._oData.busyLinkedObjects = false;
			oContext._oData.busyTopIssuesProject = false;
			oContext._oData.busyTopIssuesEngagement = false;
			oContext._oModel.refresh();
		},

		// ---------------------------------------------------------------------------------------------
		// Attachments
		// ---------------------------------------------------------------------------------------------

		fnHandleBeforeUploadStarts: function (oEvent) {
			this.attachments.fnHandleBeforeUploadStarts(oEvent, this);
		},

		fnHandleFileSizeExceed: function (oEvent) {
		   this.attachments.fnHandleFileSizeExceed(oEvent, this);
	   }, 

		fnHandleUploadCompleted: function (oEvent) {
			this.attachments.fnHandleUploadCompleted(oEvent, this);
		},

		// ---------------------------------------------------------------------------------------------
		// Notes
		// ---------------------------------------------------------------------------------------------

		groupByChanged: function (oEvent) {
			let sKey = oEvent.getParameter("selectedItem").getProperty("key");
			this._timeline.setGroupByType(sKey);
		},

		groupByTypeChanged: function (oEvent) {
			let sKey = oEvent.getParameter("selectedItem").getProperty("key");
			this.notes.handleReadNotes(sKey, this);
		},

		fnAddNote: function (oEvent) {
			this.notes._openDialogAddNewNote(oEvent, this);

		},

		fnHandleAddNote: function (oEvent) {
			this.notes.handleAddNote(oEvent, this);
		},

		handleFieldSelectionChange: function (oEvent) {
			this.notes.handleFieldSelectionChangeNotes(oEvent, this.getView());
		},

		handleNoteTypeSelectionChange: function (oEvent) {
			this.notes.handleNoteTypeSelectionChange(oEvent, this.getView());
		},

		fnHandleDiscardNote: function (oEvent) {
			this.notes.handleDiscardNote(this);
		},

		fnShowUserDetails: function (oEvent) {
			this.employeeDetails.displayEmployeePopover(oEvent, this.getView(), "oModelNotes", "CreatedBy");
		},

		fnHandleDeleteNewNoteAdded: function (oEvent) {
			this.notes.removeNote(oEvent, this);
		},

		// ---------------------------------------------------------------------------------------------
		// Top Issues
		// ---------------------------------------------------------------------------------------------

		_readTopIssues: function (sTopIssuesModel, fnCallbackReadTopIssues) {
			let oModelTopIssues = this.getModel(sTopIssuesModel);
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.paginationTop = Constants.getPaginationTop();
			entities.paginationSkip = this._oData.paginationSkip;
			entities.inlineCount = "allpages";
			entities.entitySet = "ProjectItemSet";
			entities.filter = "(ProjectID eq '" + this._idProject + "' and (TransactionType eq 'ZS34'))";
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.callbackSuccess = (oData) => {
				oModelTopIssues.setProperty("/results", oData.results);
				oModelTopIssues.setProperty("/iNumberOfTopIssues", oData.__count);
				let iNumberOfTopIssues = oModelTopIssues.getProperty("/iNumberOfTopIssues");
				this.pagination._paginationElements(this, iNumberOfTopIssues,
					this.getView().byId("btnPaginationNextTopIssues"), this.getView().byId("btnPaginationPrevTopIssues"));
				oModelTopIssues.refresh();
				if (fnCallbackReadTopIssues) fnCallbackReadTopIssues(oData);
			};
			this.readBaseRequest(entities);
		},

		navToDisplayTopIssueInCrm: function (oEvent, oModel) {
			const sPath = oEvent.getSource().getParent().getBindingContext(oModel).getPath(),
				oSelectedItem = this.getView().getModel(oModel).getProperty(sPath),
				sURL = oSelectedItem.TbuiUrl;
			NavigationToExternalApps.fnHandleLinkNavigation(sURL);
		},

		navToEditTopIssueInCrm: function (oEvent, oModel) {
			let sPath = oEvent.getSource().getParent().getBindingContext(oModel).getPath(),
				oSelectedItem = this.getView().getModel(oModel).getProperty(sPath),
				sURL = oSelectedItem.TbuiUrl;
			sURL = sURL.replace("action=B", "action=C");
			NavigationToExternalApps.fnHandleLinkNavigation(sURL);
		},	

		onExit: function () {
			if (this._oPopover) {
				this._oPopover.destroy();
			}
		},

		initializeModelsAndLocalData: function (oContext) {
			let oLocalModel = new JSONModel({}),
				oModelDetails = new JSONModel({}),
				oModelInstallationVH = new JSONModel({}),
				helpCustomerModel = new JSONModel({}),
				projectsUnderEngagement = new JSONModel({}),
				oModelRO = new JSONModel({}),
				oHelpEngagementModel = new JSONModel({}),
				activitiesEngagement = new JSONModel({}),
				oActivitiesProject = new JSONModel({}),
				oLinkedObjectsModel = new JSONModel({}),
				oEngCaseContractsModel = new JSONModel({}),
				oEngCaseContractsSearchHelpModel = new JSONModel({}),
				oEngCaseContractCustomerSearchHelpModel = new JSONModel({}),
				oTopIssuesProject = new JSONModel({}),
				oTopIssuesEngagementModel = new JSONModel({}),
				oCreateProject = new JSONModel({});

			oLocalModel.setSizeLimit(1000);
			this.messageHandler.initializeMsgHandlling(this);
			oContext.getView().setModel(oModelRO, "oModelRO");
			oContext.getView().setModel(oModelDetails, "projectDetails");
			oContext.getView().setModel(oModelInstallationVH, "installationSearchHelp");
			oContext.getView().setModel(oCreateProject, "createModel");
			helpCustomerModel.setSizeLimit(1000);
			oModelRO.setSizeLimit(10000); // Needed to provide all DDLB value (e.g. for system role)
			oContext.getView().setModel(helpCustomerModel, "customerSearchHelp");
			oHelpEngagementModel.setSizeLimit(1000);
			this.getView().setModel(oHelpEngagementModel, "engagementsSearchHelp");
			oContext.getView().setModel(projectsUnderEngagement, "projectsUnderEngagement");
			oContext.getView().setModel(activitiesEngagement, "activities");
			oContext.getView().setModel(oEngCaseContractsModel, "engCaseContracts");
			oContext.getView().setModel(oEngCaseContractsSearchHelpModel, "engCaseContractsSearchHelp");
			oContext.getView().setModel(oEngCaseContractCustomerSearchHelpModel, "engCaseContractCustomerSearchHelp");
			oContext.getView().setModel(oActivitiesProject, "activitiesProject");
			oContext.getView().setModel(oLinkedObjectsModel, "linkedObjectsModel");
			oContext.getView().setModel(oTopIssuesProject, "topIssuesProject");
			oContext.getView().setModel(oTopIssuesEngagementModel, "topIssuesEngagementModel");
			oContext.getView().setModel(new JSONModel({}), "PartnerModel");

			oContext.getView().setModel(oLocalModel, "localModel");

			oContext._oModel = oContext.getView().getModel("localModel");
			oContext._oData = oContext._oModel.getData();
			oContext._oData.customerProjectsTabTitle = "";
			oContext._oData.bDetailPage = true;
			oContext._oData.formEditMode = false;
			oContext._oData.formEditModePlanning = false;
			oContext._oData.showEditPlanning = false;
			oContext._isActivityAssistance = false;
			oContext._isIssue = false;
			oContext._isQGate = false;
			oContext.__isActivityBackoffice = false;
			oContext._savePhases = true;
			oContext._savePhasesOutside = true;
			oContext.messageFlag = false;
			oContext._fileSize = null;
			oContext._timeline = oContext.getView().byId("idTimeline");
			oContext._firstDateWasSetEditable = false;
			oContext._oData.projectGoLiveDateValueState = "None";
			oContext._oData.projectNameValueState = "None";
			oContext._oData.projectDescriptionValueState = "None";
			oContext._oData.projectStartDateValueState = "None";
			oContext._oData.projectEndDateValueState = "None";
			oContext._oData.projectStartDateValueText = "";
			oContext._oData.projectEndDateValueText = "";
			oContext._oData.projectGoLiveDateValueText = "";
			oContext._oData.projectCaseValueState = "None";
			oContext._oData.busyProjectDetailsHeader = true;
			oContext._oData.busyTQMs = true;
			oContext._oData.busyReferenceObjects = true;
			oContext._oData.busyProjectPlanning = true;
			oContext._oData.busyProjectDetailsPage = true;
			oContext._oData.busyNewNote = false;
			oContext._oData.busyNotesBox = true;
			oContext._oData.busyNotes = false;

			oContext._oData.minDatePhase = null;
			oContext._oData.maxDatePhase = null;
			oContext._oData.startDateProject = null;
			oContext._oData.endDateProject = null;
			oContext._oData.requiredGoLiveDate = false;
			oContext._oData.busyAddRO = false;
			oContext._oData.busyCustomerHelpTable = false;
			oContext._oData.cloneOfProjectDetails = {};
			oContext._oData.headerInfoChanged = false;
			oContext._oData.busyEngagementsHelpTable = false;
			oContext._oData.sItemSearch = "";
			oContext._oData.totalNumberOfProjects = 30;

			oContext._oData.paginationClicks = 0;
			oContext._oData.paginationSkip = 0;
			oContext._oData.paginationIntervalStart = 0;
			oContext._oData.paginationNextBtnEnabled = false;
			oContext._oData.paginationPrevBtnEnabled = false;

			oContext._oData.enabledEngagementSearch = true;
			oContext._oData.paginationIntervalEnd = Constants.getPaginationTop();
			oContext._oData.timeZone = Constants.getTimeZoneText();

			oContext.getView().getModel("engagementsSearchHelp").getData().showNoEngCaseMsg = false;
			oContext.getView().getModel("engagementsSearchHelp").getData().showEngCaseMsg = false;
			oContext.getView().getModel("engagementsSearchHelp").refresh();
			let sAccountType = Constants.getAccount()[oContext.getModel("appData").getData().account].type;
			oContext.getView().getModel("createModel").getData().CRMLink = Constants.getCRMCreateEngCaseLinks()[sAccountType];
			this._initializeROData(oContext);

			this.partiesInvolved.init(this);

			let oLinkModel = new JSONModel(Constants.getPathModelFrequentlyUsedLinks());
			oContext.setModel(oLinkModel, "linkModel");

		},

		_initializeROData: function (oContext) {
			oContext.getView().getModel("oModelRO").getData().customerIDExists = true;
			oContext.getView().getModel("oModelRO").getData().instNoExists = true;
			oContext.getView().getModel("oModelRO").getData().roSelectionPage = false;
			oContext.getView().getModel("oModelRO").getData().refObjRequirements =
				Constants.getSystemSolManOptions()[0].key;
			oContext.getView().getModel("oModelRO").refresh();
		},

		_clearAllDataFromModels: function () {
			this.getView().getModel("localModel").setData({});
			this.getView().getModel("projectDetails").setData({});
			if (this.getView().getModel("ReferenceObjects")) {
				this.getView().getModel("ReferenceObjects").setData({});
				this.getView().getModel("ReferenceObjects").refresh();
			}
			if (this.getView().getModel("oModelRO")) {
				this.getView().getModel("oModelRO").setData({});
				this.getView().getModel("oModelRO").refresh();
			}
			if (this.getView().getModel("PartnerSet")) {
				this.getView().getModel("PartnerSet").setData({});
				this.getView().getModel("PartnerSet").refresh();
			}
			this.getView().getModel("installationSearchHelp").setData({});
			this.getView().getModel("localModel").refresh();
			this.getView().getModel("projectDetails").refresh();
			this.getView().getModel("installationSearchHelp").refresh();
		},

		fnAfterSendToDelivery: function (channel, event, data) {
			this.handleClearAllMessages();
			this._dataFromBus = true;
			let sStatusText = "Released";
			let SOid = data.SOId;
			this.messageHandler.addNewMessageseInsidePopover("SOStatusChangeDelivery", "Success",
				this.getResourceBundle().getText("SO." + sStatusText + ".Success.Title"),
				this.getResourceBundle().getText("SO." + sStatusText + ".Success.DescriptionLong", [SOid]),
				this.getResourceBundle().getText("SO." + sStatusText + ".Success.DescriptionShort", [SOid]), this);
			this._readProjectItems(data);
		},


		// ---------------------------------------------------------------------------------------------
		// Employee Details
		// ---------------------------------------------------------------------------------------------

		fnShowEmployeeRespDetails: function (oEvent) {
			this.employeeDetails.displayEmployeePopover(oEvent, this.getView(), "projectDetails", "EmplRespID");
		},

		fnShowEmployeeDetails: function (oEvent) {
			this.employeeDetails.displayEmployeePopover(oEvent, this.getView(), "projectDetails", "UserID");
		},

		fnShowEmployeePartiesInvolved: function (oEvent) {
			let sUserID = "";
			oEvent.getSource().getCustomData().forEach(function (elem) {
				if (elem.getKey() === "UserID") sUserID = elem.getValue();
			});
			this.employeeDetails.displayEmployeePopoverGeneric(oEvent, this.getView(), sUserID);
		},

		// ---------------------------------------------------------------------------------------------
		// Parties Involved
		// ---------------------------------------------------------------------------------------------


		fnHandleAddNewPartner: function (oEvent) {
			this.partiesInvolved.loadAddNewDialog(oEvent);
			this.getView().byId("tablePartiesInvolved").getAggregation("items")[1].focus();
		},

		fnHandlePartnerSetMain: function (oEvent) {
			this.partiesInvolved.setMain(oEvent);
		},

		onSelectPartnerFct: function (oEvent) {
			this.partiesInvolved.setNewPartnerFct(oEvent.getSource().getSelectedKey());
		},

		onNewPartnerSave: function (oEvent) {
			this.partiesInvolved.saveNewPartner(this._handleSuccessReadPartnerSet.bind(this));
		},

		onNewPartnerCancel: function (oEvent) {
			this.partiesInvolved.cancelNewPartner();
		},

		onPartnerDelete: function (oEvent) {
			let sPartnerID = "";
			let sPartnerFct = "";
			let bNewPartner = false;
			oEvent.getSource().getCustomData().forEach(function (elem) {
				switch (elem.getKey()) {
					case "PartnerID":
						sPartnerID = elem.getValue();
						break;
					case "PartnerFct":
						sPartnerFct = elem.getValue();
						break;
					case "NewPartner":
						bNewPartner = elem.getValue();
						break;
					default:
						break;
				}
			});
			if (bNewPartner === true) {
				this.partiesInvolved.cancelNewPartner();
			} else {
				this.partiesInvolved.deletePartner(sPartnerFct, sPartnerID, this._handleSuccessReadPartnerSet.bind(this));
			}
		},

		_handleSuccessReadPartnerSet: function (data) {
			if (!data || (!data[0] && !data.results[0])) return;
			if (data.results) data = data.results
			const oPartnerModel = {};

			data.forEach(function (oElement) {

				if (!oElement.UserID) return;

				const sAbsolutePath = Formatter.linkToSapIt(oElement.UserID).employeePicture;
				oElement.src = sAbsolutePath;

				if (!oPartnerModel[oElement.PartnerFct] || oElement.MainPartner)
					oPartnerModel[oElement.PartnerFct] = oElement;

			});
			this.getView().setModel(new JSONModel(oPartnerModel), "PartnerModel");

		},

		onPartnerSetMain: function (oEvent) {
			let sPartnerID = "";
			let sPartnerFct = "";
			let bNewPartner = false;
			oEvent.getSource().getCustomData().forEach(function (elem) {
				switch (elem.getKey()) {
					case "PartnerID":
						sPartnerID = elem.getValue();
						break;
					case "PartnerFct":
						sPartnerFct = elem.getValue();
						break;
					case "NewPartner":
						bNewPartner = elem.getValue();
						break;
					default:
						break;
				}
			});
			if (bNewPartner === true) {
				return;
			} else {
				this.partiesInvolved.setMain(sPartnerFct, sPartnerID, this._handleSuccessReadPartnerSet.bind(this));
			}
		},

		onNewPartnerLiveChange: function (oEvent) {

		},

		onNewPartnerSuggest: function (oEvent) {
			this.partiesInvolved.fastSearchPartner(oEvent.getSource().getValue(), oEvent.getSource());
		},

		onCustomerSearchCountrySelected: function (oEvent) {
			this.partiesInvolved.setCustomerSearchCountry(oEvent.getSource().getSelectedKey());
		},

		onServiceTeamSearchCountrySelected: function (oEvent) {
			this.partiesInvolved.setServiceTeamSearchCountry(oEvent.getSource().getSelectedKey());
		},

		onNewPartnerSuggestSelected: function (oEvent) {
			this.partiesInvolved.setNewPartner(oEvent.getSource().getSelectedKey(), oEvent.getSource().getValue());
		},

		onNewPartnerValueHelp: function (oEvent) {
			this.getView().getModel("localModel").getData().bpSearchReturnType = "PartiesInvolved";
			this.getView().getModel("localModel").getData().bpSearchReturnPartnerID = "";
			this.getView().getModel("localModel").getData().bpSearchReturnFullName = "";
			this.partiesInvolved.loadSearchHelpDialog(this.partiesInvolved.getNewPartnerFct());
		},

		onSearchCustomer: function (oEvent) {
			this.partiesInvolved.searchPartner("PFCustomerSet", this.getView().getModel("CustomerSearch").getData());
		},

		onSearchEmployee: function (oEvent) {
			this.partiesInvolved.searchPartner("PFEmployeeSet", this.getView().getModel("EmployeeSearch").getData());
		},

		onSearchContact: function (oEvent) {
			this.partiesInvolved.searchPartner("PFContactSet", this.getView().getModel("ContactSearch").getData());
		},

		onSearchServiceTeam: function (oEvent) {
			this.partiesInvolved.searchPartner("PFServiceTeamSet", this.getView().getModel("ServiceTeamSearch").getData());
		},

		onPartnerTooltip: function (oEvent) {

		},

		onVHPartnerSelect: function (oEvent) {
			this.onVHPartnerSelectGetValues(oEvent);
			let sPartnerID = this.getView().getModel("localModel").getData().bpSearchReturnPartnerID ? this.getView().getModel("localModel").getData()
				.bpSearchReturnPartnerID : "";
			let sFullName = this.getView().getModel("localModel").getData().bpSearchReturnFullName ? this.getView().getModel("localModel").getData()
				.bpSearchReturnFullName : "";
			let sBPSearchReturnType = this.getView().getModel("localModel").getData().bpSearchReturnType ? this.getView().getModel("localModel")
				.getData().bpSearchReturnType : "PartiesInvolved";
			if (sBPSearchReturnType === "PartiesInvolved") {
				this.partiesInvolved.setNewPartner(sPartnerID, sFullName);
			}
			this.partiesInvolved.closeSearchHelpDialog();
		},
		onVHPartnerSelectGetValues: function (oEvent) {
			let sPartnerID = "";
			let sFullName = "";
			oEvent.getSource().getSelectedItem().getCustomData().forEach(function (elem) {
				switch (elem.getKey()) {
					case "PartnerID":
						sPartnerID = elem.getValue();
						break;
					case "FullName":
						sFullName = elem.getValue();
						break;
					default:
						break;
				}
			});
			this.getView().getModel("localModel").getData().bpSearchReturnPartnerID = sPartnerID;
			this.getView().getModel("localModel").getData().bpSearchReturnFullName = sFullName;
		},


		onVHPartnerCancel: function (oEvent) {
			this.partiesInvolved.closeSearchHelpDialog();
		},

		getPartnerGroupTitle: function (oGroup) {
			return this.partiesInvolved.getPartnerGroupTitle(oGroup);
		}

	});
});
