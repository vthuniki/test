sap.ui.define([
	"com/sap/ui/hep/controller/Engagement/BaseEngagementDialog",
	"sap/ui/model/json/JSONModel",
	"com/sap/ui/hep/reuse/BaseRequest",
	"com/sap/ui/hep/reuse/Constants",
	"com/sap/ui/hep/util/engagementSelection/EngagementSelection"

], function (BaseEngagementDialog, JSONModel, BaseRequest, Constants, EngagementSelection) {

	"use strict";

	return BaseEngagementDialog.extend("com.sap.ui.hep.controller.Engagement.EditEngagementDialog", {

		fnEditEnagagementDialogOpen: function (oContext, oResourceBundle, oEngagementData) {
			this._oContext = oContext;
			this._oView = oContext.getView();
			this._oResourceBundle = oResourceBundle;
			oEngagementData.NumberOfAllProjectsUnderEngagement = oContext.iNumberOfAllProjectsUnderEngagement || 0;

			this._initializeModels();

			this._pDialogEditEngagement ??= this._loadFragment(this, oContext.getView(), "com.sap.ui.hep.view.Engagement.DialogEditEngagement");
			this._pDialogEditEngagement.then(oDialog => {
				this._oView.addDependent(oDialog);
				oDialog.setModel(this._modelEngagementDialog, "modelEngagementDialog");
				oDialog.addStyleClass("sapUiSizeCompact");
				oDialog.open();
				this._fnFillFieldDataAfterOpen(oEngagementData);
				this._fnValidateFieldsAndSetSaveBtnState();
			});
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ========================================== Initialization ========================================================= */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_initializeModels: function () {
			/* "_modelProjectDialog" is the main model for the Dialog, it holds everything*/
			this._modelEngagementDialog = new JSONModel({});
			this._modelEngagementDialog.getData().aFieldValueStates = [];
			this._modelEngagementDialog.getData().aFieldValueStateTexts = [];
			this._modelEngagementDialog.getData().aEngagementRatingsList = [];
			this._modelEngagementDialog.getData().engagementRating = ""; //this needs to be done already here, otherwise there is a console error, in case the user opens the dialog a second time
			this._modelEngagementDialog.getData().aEngagementReasonList = [];
			this._modelEngagementDialog.getData().aEngagementStatusList = [];
			this._modelEngagementDialog.getData().timeZone = Constants.getTimeZoneText();
			this._modelEngagementDialog.refresh();
		},

		_fnFillFieldDataAfterOpen: function (oEngagementData) {
			this._oOldEngagementData = oEngagementData;
			this._modelEngagementDialog.getData().busyEditEngagement = false;
			this._modelEngagementDialog.getData().bAllowChangeOfReason = oEngagementData.NumberOfAllProjectsUnderEngagement === 0 && oEngagementData.ReasonCode === 'ENG1';
			this._modelEngagementDialog.refresh();

			this._fnLoadEngagementRatingsFromLocal();
			this._fnLoadEngagementStatusFromLocal();

			//get Global Engagement Name
			this._modelEngagementDialog.getData().busyGlobalEngCaseSearch = true;
			EngagementSelection.fnGetDetailsForEngagement(this._oOldEngagementData.ParentCaseID, true, (oEngCasesFound) => {
				this._modelEngagementDialog.getData().busyGlobalEngCaseSearch = false;
				if (oEngCasesFound.results.length === 1) {
					this._oContext.getView().byId("idFieldGlobalEngagementCase").setValue(oEngCasesFound.results[0].ProjectID);
					this._oContext.getView().byId("idFieldGlobalEngagementCaseName").setText(oEngCasesFound.results[0].ProjectName);
				} else {
					this._oContext.getView().byId("idFieldGlobalEngagementCaseName").setText("");
				}
				this._modelEngagementDialog.refresh();
				this._fnValidateFieldsAndSetSaveBtnState();
			});

			//set field Person Responsible with ID and Name
			this._setUpEmployeeSelectionModule1(oEngagementData.EmplRespID);

			//set up all other fields with data from engagement
			this._oView.byId("idFieldEngCustomerNumber").setValue(this._oOldEngagementData.CustomerID);
			this._oView.byId("idFieldEngCustomerName").setText(this._oOldEngagementData.CustomerName);
			this._oView.byId("idFieldEngagementName").setValue(this._oOldEngagementData.ProjectName);
			this._oView.byId("idFieldEngagementNameCounter").setText(80 - Number(this._oOldEngagementData.ProjectName.length) + " characters remaining");
			this._oView.byId("idFieldEngagementDescription").setValue(this._oOldEngagementData.ProjectDescription);
			this._oView.byId("idFieldEngagementDescriptionCounter").setText(1333 - Number(this._oOldEngagementData.ProjectDescription.length) + " characters remaining");
			this._oView.byId("idFieldEngagementStatus").setSelectedKey(this._oOldEngagementData.StatusID);
			this._oView.byId("idFieldEngagementRating").setSelectedKey(this._oOldEngagementData.CaseRating);
			this._oView.byId("idFieldEngagementStartDate").setDateValue(this._oOldEngagementData.ProjectStartDate);
			this._oView.byId("idFieldEngagementEndDate").setDateValue(this._oOldEngagementData.ProjectEndDate);
			this._oView.byId("idFieldEngagementReason").setSelectedKey(this._oOldEngagementData.ReasonCode);
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ============================================ Event Handler (except "save") ======================================== */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		fnHandleCancelPress: function () {
			this._pDialogEditEngagement.then(oDialog => oDialog.close());
		},

		fnOnEngagementReasonShowInformation: function () {
			this._pdPopover ??= this._loadFragment(this, this._oView, "com.sap.ui.hep.view.Details.Engagement.fragment.EngagementInfoPopover");
			this._pdPopover.then(oPopover => {
				this._oView.addDependent(oPopover);
				oPopover.openBy(this._oView.byId("idFieldEngagementReason"));
			});
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ===========================================   Validation   ======================================================== */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_fnAllRequiredFieldsFilled: function () {
			return (!!this._oView.byId("idFieldEngagementName").getValue() && !!this._oView.byId("idFieldEngagementDescription").getValue() &&
				!!this._oView.byId("idFieldEngagementStartDate").getDateValue() && !!this._oView.byId("idFieldEngagementEndDate").getDateValue() &&
				(this._oEmployeeSelection1._fnGetEmployeeIdFieldValueState() === "None" && !!this._oEmployeeSelection1.fnGetEmployeeId())
				&& this._oView.byId("idFieldGlobalEngagementCase").getValueState() === "None");
		},

		_fnValidateFieldsAndSetSaveBtnState: function () {
			let bSaveBtnEnableState = this._fnAllRequiredFieldsFilled();
			this._oView.byId("idBtnSave").setEnabled(bSaveBtnEnableState);
			return bSaveBtnEnableState;
		},

		/* =================================================================================================================== */
		/*=====================================================================================================================*/
		/*================================================== Person Responsable================================================*/
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_fnCallbackEmployeeSelectionChange: function (oNewEmployee, sValueState) {
			this._modelEngagementDialog.getData().aaFieldValueStates.fragmentFieldPersonResponsible = sValueState;
			this._fnValidateFieldsAndSetSaveBtnState();
			this._oPersonResponsibleSelected = oNewEmployee;
		},

		/* =================================================================================================================== */
		/*=====================================================================================================================*/
		/*=================================================   SAVE Engagement   ===============================================*/
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		fnHandleSavePress: function (evt) {
			if (this._fnValidateFieldsAndSetSaveBtnState()) {
				this._fnClearAllMessages();
				this._fnShowProgressIndicator();
				this._pFnSaveEngagement().then(() => {
					this._oDialogProgressIndicator.close();
					this._modelEngagementDialog.getData().busyEditEngagement = false;
					this._modelEngagementDialog.refresh();
					this._pDialogEditEngagement.then(oDialog => oDialog.close());
					this._oContext._fnRefreshEngagementDetails();
				});
			}
		},

		_pFnSaveEngagement: function () {
			return new Promise((resolve, reject) => {
				if (this._fnValidateFieldsAndSetSaveBtnState()) { //returns TRUE if everything is correct!
					this._modelEngagementDialog.getData().busyEditEngagement = true;
					this._modelEngagementDialog.refresh();
					let entities = {};
					entities.servicePath = Constants.getServicePath();
					entities.entitySet = "ProjectSet";
					entities.getEntity = this._oOldEngagementData.ProjectID;
					entities.data = this._fnPrepareDataForSaveProjectDetails();
					entities.currentView = this._oView;
					entities.oContext = this._oContext;
					entities.errorMessage = this._oResourceBundle.getText("ProjectDetails.UpdateProjectError");
					entities.callbackUnsetBusyIndicator = () => {
						this._modelEngagementDialog.getData().busyEditEngagement = false;
						this._modelEngagementDialog.refresh();
					};
					entities.callbackSuccess = (oData) => {
						this._oContext.getOwnerComponent().trackEvent("Edit_Engagement");
						resolve();
					};
					entities.callbackError = oError => this._fnHandleEngagementSaveError(oError, "busyEditEngagement");
					BaseRequest.handleUpdate(entities);
				}
			});
		},

		_fnPrepareDataForSaveProjectDetails: function () {
			let dStartDate = this._oView.byId("idFieldEngagementStartDate").getDateValue(),
				dEndDate = this._oView.byId("idFieldEngagementEndDate").getDateValue();
			return {
				"CaseRating": this._oView.byId("idFieldEngagementRating").getSelectedKey(),
				"CustomerID": this._oView.byId("idFieldEngCustomerNumber").getValue(),
				"EmplRespID": this._oEmployeeSelection1.fnGetEmployeeId() || this._oOldEngagementData.EmplRespID,
				"GlobalUltimateID": this._oOldEngagementData.GlobalUltimateID,
				"ParentCaseID": this._oContext.getView().byId("idFieldGlobalEngagementCase").getValue(),
				"ProjectDescription": this._oView.byId("idFieldEngagementDescription").getValue(),
				"ProjectEndDate": dEndDate === null ? null : dEndDate,
				"ProjectGUID": this._oOldEngagementData.ProjectGUID,
				"ProjectID": this._oOldEngagementData.ProjectID,
				"ProjectName": this._oView.byId("idFieldEngagementName").getValue(),
				"ProjectStartDate": dStartDate === null ? null : dStartDate,
				"StatusID": this._oView.byId("idFieldEngagementStatus").getSelectedKey(),
				"TqmID": this._oOldEngagementData.TqmID,
				"ReasonCode": this._oView.byId("idFieldEngagementReason").getSelectedKey()
			};
		}
	});
});
