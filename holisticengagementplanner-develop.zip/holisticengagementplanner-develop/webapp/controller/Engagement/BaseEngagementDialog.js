sap.ui.define([
	"sap/ui/base/Object",
	"com/sap/ui/hep/reuse/BaseTools",
	"com/sap/ui/hep/util/employeeSelection/EmployeeSelection",
	"com/sap/ui/hep/util/engagementSelection/EngagementSelection",
	"sap/m/Dialog",
	"sap/m/ProgressIndicator",
	"com/sap/ui/hep/reuse/Constants",

], function (sapUiBaseObject, BaseTools, EmployeeSelection, EngagementSelection, Dialog, ProgressIndicator, Constants) {

	return sapUiBaseObject.extend("com.sap.ui.hep.controller.Engagement.BaseEngagementDialog", {



		_loadFragment: function (oFragmentController, oView, sFragmentPath, fnInitialCallback) {
			return BaseTools.loadFragment(oFragmentController, oView, sFragmentPath, fnInitialCallback);
		},

		_fnClearAllMessages: function () {
			this._oView.getController().messageHandler.clearAllMessages(this._oView, this._oView.getController().oMessagePopover);
		},

		_clearDateIfNotValid: function (sDateControlId) {
			if (!this._oView.byId(sDateControlId).isValidValue()) {
				this._oView.byId(sDateControlId).setDateValue(null);
			}
		},
		_fnAddOneDay: function (dDate) {
			return BaseTools.fnAddOneDay(dDate);
		},

		_fnShowProgressIndicator: function () {
			//show progress indicator
			this._oDialogProgressIndicator ??= new Dialog({
				type: "Message",
				showHeader: false,
				state: "Information",
				content: new ProgressIndicator({
					displayAnimation: false,
					state: "Success",
					displayOnly: true
				})
			});
			this._oDialogProgressIndicator.getContent()[0].setDisplayValue("Saving Engagement");
			this._oDialogProgressIndicator.getContent()[0].setPercentValue(50);
			this._oDialogProgressIndicator.addStyleClass("sapUiSizeCompact");
			this._oDialogProgressIndicator.open();
		},

		/* =================================================================================================================== */
		/* ========================================== Loading Combo Lists ==================================================== */

		_fnLoadEngagementRatingsFromLocal: function () {
			if (this._oView.byId("idFieldEngagementRating").getCustomData().length === 0) {
				this._oView.byId("idFieldEngagementRating").addCustomData(new sap.ui.core.CustomData({
					writeToDom: true,
					key: "iconProjectRating",
					value: "{modelEngagementDialog>/engagementRating}"
				}));
				if (this._oView.byId("idFieldEngagementRating").getBindingInfo("items").template.getCustomData().length === 0) {
					this._oView.byId("idFieldEngagementRating").getBindingInfo("items").template.addCustomData(new sap.ui.core.CustomData({
						writeToDom: true,
						key: "iconProjectRating",
						value: "{modelEngagementDialog>key}"
					}));
				}
			}
			this._modelEngagementDialog.getData().aEngagementRatingsList = Constants.getCaseRatingComboValues().ratings;
			this._modelEngagementDialog.getData().aEngagementReasonList = Constants.getEngagementReasonComboValues().reason;
			this._modelEngagementDialog.refresh();
		},

		_fnLoadEngagementStatusFromLocal: function () {
			this._modelEngagementDialog.getData().aEngagementStatusList = Constants.getItemStatus();
			this._modelEngagementDialog.refresh();
		},

		/* =================================================================================================================== */
		/* ========================================== Event Handler  ========================================================= */

		fnHandleEngagementNameChanged: function (oEvent) {
			this._oView.byId("idFieldEngagementNameCounter").setText(80 - Number(oEvent.getParameter("value").length) +
				" characters remaining");
			this._fnValidateFieldsAndSetSaveBtnState();
		},

		fnHandleEngagementDescriptionChanged: function (oEvent) {
			this._oView.byId("idFieldEngagementDescriptionCounter").setText(1333 - Number(oEvent.getParameter("value").length) +
				" characters remaining");
			this._fnValidateFieldsAndSetSaveBtnState();
		},

		fnHandleEngagementStartDateChanged: function () {
			if (this._oView.byId("idFieldEngagementStartDate").isValidValue()) {
				this._oView.byId("idFieldEngagementEndDate").setMinDate(this._fnAddOneDay(this._oView.byId("idFieldEngagementStartDate").getDateValue()));
				this._modelEngagementDialog.getData().aFieldValueStates["idFieldEngagementStartDate"] = sap.ui.core.ValueState.None;
				this._modelEngagementDialog.getData().aFieldValueStateTexts["idFieldEngagementStartDate"] = "";
			} else {
				this._modelEngagementDialog.getData().aFieldValueStates["idFieldEngagementStartDate"] = sap.ui.core.ValueState.Error;
				this._modelEngagementDialog.getData().aFieldValueStateTexts["idFieldEngagementStartDate"] = this._oResourceBundle.getText("Engagement.MsgErrorNotValid.idFieldEngagementStartDate", [Constants.getMediumDateFormat()]);
			}
			this._modelEngagementDialog.refresh();
			this._fnValidateFieldsAndSetSaveBtnState();
		},

		fnHandleEngagementEndDateChanged: function () {
			let bFieldValid = this._oView.byId("idFieldEngagementEndDate").isValidValue();
			this._modelEngagementDialog.getData().aFieldValueStates["idFieldEngagementEndDate"] = bFieldValid ? sap.ui.core.ValueState.None : sap.ui.core.ValueState.Error;
			this._modelEngagementDialog.getData().aFieldValueStateTexts["idFieldEngagementEndDate"] = bFieldValid ? "" : this._oResourceBundle.getText("Engagement.MsgErrorNotValid.idFieldEngagementEndDate", [Constants.getMediumDateFormat()])
			this._modelEngagementDialog.refresh();
			this._fnValidateFieldsAndSetSaveBtnState();
		},

		/* =================================================================================================================== */
		/*================================================ Person Responsible =================================================*/

		_setUpEmployeeSelectionModule1: function (sInitialEmployeeId) {
			let oEmployeeSelectionCustomizing = {
				sInputFragmentId: "idFragmentEmployeeIdDialogEngagement", //the name you have given to the fragment that you put into your view
				bInputFragmentHasTextField: true, //you are either using the fragment for forms or the simple one ... the later does not have the "EmployeeName"-field and no grid-layout setup
				sValueHelpFragmentId: "EmployeeSelection1", //a string that the module uses to prefix the ids of the value help fragment fields
				sDialogWidth: "1200px", //dimensions of the value help dialog
				sDialogHeight: "770px", //dimensions of the value help dialog
				sEmployeeIdFieldGridSpan: "XL3 L3 M3 S3", //only in case of using the form-fragment
				sEmployeeNameFieldGridSpan: "XL5 L5 M5 S5", //only in case of using the form-fragment
				bEmployeeIdRequired: true, //puts a red asterisk to the input field and takes care the the value state is set to error
				bEmployeeTextFieldVisible: true, //it is also possible to use the form-fragment, but to hide the EmployeeName field from the user
				fnCallBackAfterValueChange: (oNewEmployee, sValueState, bInputFieldSubmit) => {
					//define what needs to happen in your view controller, when the Employee has changed....
					this._fnCallbackEmployeeSelectionChange(oNewEmployee, sValueState, bInputFieldSubmit);
				}
			};
			//get your instance and then initialize it
			if (!this._oEmployeeSelection1) this._oEmployeeSelection1 = new EmployeeSelection();
			this._oEmployeeSelection1.fnInitialize(this._oView, oEmployeeSelectionCustomizing, sInitialEmployeeId);
		},

		/*=====================================================================================================================*/
		/*============================================ Global Engagement Field ================================================*/
		/* =================================================================================================================== */

		//helper function to be used for setting the value in the global engagement field
		_fnHelperSetFieldsGlobalEngCase: function (sGlobalCaseId, sGlobalCaseName, bValid = true) {
			this._oView.byId("idFieldGlobalEngagementCase").setValue(sGlobalCaseId);
			this._oView.byId("idFieldGlobalEngagementCaseName").setText(sGlobalCaseName);
			if (bValid || sGlobalCaseId === "") {
				this._oView.byId("idFieldGlobalEngagementCase").setValueState(sap.ui.core.ValueState.None);
				this._oView.byId("idFieldGlobalEngagementCase").setValueStateText("");
				this._oView.byId("idFieldGlobalEngagementCase").closeValueStateMessage();
			} else {
				this._oView.byId("idFieldGlobalEngagementCase").setValueState(sap.ui.core.ValueState.Error);
				this._oView.byId("idFieldGlobalEngagementCase").setValueStateText(this._oResourceBundle.getText("Engagement.MsgEnterValidGlobalEngagementOrNone"));
			}
			this._fnValidateFieldsAndSetSaveBtnState();
		},

		fnOnValueHelpEngagementCase: function (oEvent, oInitialFilterValues) {
			let oFilterValues = {};
			Object.assign(oFilterValues, oInitialFilterValues, {
				CustomerBpId: this._oCustomerSelection1?.fnGetCustomerId() || this._oOldEngagementData?.CustomerID || "",
				CustomerName: this._oCustomerSelection1?.fnGetCustomerFullName() || this._oOldEngagementData?.CustomerName || "",
				sDialogWidth: "1200px",
				sDialogHeight: "770px",
				ExactCustomerId: true,
				DisableCustomerFields: false,
				DisableReasonCombo: true,
				ReasonCode: Constants.getReasonOptions().globalEng //default - allow no other option
			});
			this._modelEngagementDialog.getData().busyGlobalEngCaseSearch = true;
			this._modelEngagementDialog.refresh();
			EngagementSelection.fnEngagementSelectionDialogOpen(this._oView, this._oResourceBundle, oFilterValues, (oSelectedEngCase) => {
				this._modelEngagementDialog.getData().busyGlobalEngCaseSearch = false;
				this._modelEngagementDialog.refresh();
				if (oSelectedEngCase) this._fnHelperSetFieldsGlobalEngCase(oSelectedEngCase.ProjectID, oSelectedEngCase.ProjectName);
				this._fnValidateFieldsAndSetSaveBtnState();
			});
			this._fnValidateFieldsAndSetSaveBtnState();
		},

		fnHandleGlobalEngCaseChanged: function (evt) {
			if (evt.getParameter("newValue") === "") this._fnHelperSetFieldsGlobalEngCase("", "");
			else {
				this._modelEngagementDialog.getData().busyGlobalEngCaseSearch = true;
				this._modelEngagementDialog.refresh();
				EngagementSelection.fnGetDetailsForEngagement(evt.getParameter("newValue"), true, (oEngCasesFound) => {
					this._modelEngagementDialog.getData().busyGlobalEngCaseSearch = false;
					this._modelEngagementDialog.refresh();
					if (oEngCasesFound.results.length === 1) {
						this._fnHelperSetFieldsGlobalEngCase(oEngCasesFound.results[0].ProjectID, oEngCasesFound.results[0].ProjectName);
					} else {
						//given ID not clear, open the Engagement-Selection Popup and prefill the given ID
						this._fnHelperSetFieldsGlobalEngCase(evt.getParameter("newValue"), "Does not exist", false);
						let oInitialFilterValues = {
							CaseId: evt.getParameter("newValue")
						};
						this.fnOnValueHelpEngagementCase(undefined, oInitialFilterValues);
					}
				});
			}
			this._fnValidateFieldsAndSetSaveBtnState();
		},

		/*=====================================================================================================================*/
		/*====================================================== Saving =======================================================*/

		_fnHandleEngagementSaveError: function (oError, sBusyIndicator) {
			const parsedError = JSON.parse(oError.responseText);
			// Inform user about an error via MessageBus
			this._oContext.messageHandler.clearAllMessages();
			this._oContext.messageHandler.addNewMessageseInsidePopover(
				null,
				"Error",
				"Backend Error: " + parsedError.error.innererror.errordetails[0].message,
				"");
			this._oDialogProgressIndicator.close();
			this._modelEngagementDialog.getData()[sBusyIndicator] = false;
			this._modelEngagementDialog.refresh();
		}

	})
});
