sap.ui.define([
	"com/sap/ui/hep/controller/Engagement/BaseEngagementDialog",
	"sap/ui/model/json/JSONModel",
	"com/sap/ui/hep/util/customerSelection/CustomerSelection",
	"com/sap/ui/hep/reuse/BaseRequest",
	"com/sap/ui/hep/util/EngagementContracts",
	"com/sap/ui/hep/util/contractSelection/ContractSelection",
	"com/sap/ui/hep/reuse/Constants"

], function (BaseEngagementDialog, JSONModel, CustomerSelection, BaseRequest, EngagementContracts, ContractSelection, Constants) {

	"use strict";

	return BaseEngagementDialog.extend("com.sap.ui.hep.controller.Engagement.CreateEngagementDialog", {

		fnCreateEnagagementDialogOpen: function (oContext, oResourceBundle, oEngagementData) {
			this._oContext = oContext;
			this._oView = oContext.getView();
			this._oResourceBundle = oResourceBundle;

			this._initializeModel();

			//needed for the EngagementContracts-Module
			if (!this._oContext.getView().getModel('projectDetails')) this._oContext.getView().setModel(new JSONModel({}), "projectDetails");

			this._pDialogCreateEngagement ??= this._loadFragment(this, oContext.getView(), "com.sap.ui.hep.view.Engagement.DialogCreateEngagement", () => {
				this._oView.byId("idFieldMainContractId").addEventDelegate({
					onAfterRendering: () => {
						setTimeout(() => {
							this._oView.byId("idFieldMainContractId").focus();
						}, 500);
					}
				});
				this._oView.byId("idFieldComboCustomerId").addEventDelegate({
					onAfterRendering: () => {
						$("[id*='idFieldComboCustomerId-inner']").attr("readonly", true);
					}
				});
			});

			this._pDialogCreateEngagement.then(oDialog => {
				this._oView.addDependent(oDialog);
				oDialog.setModel(this._modelEngagementDialog, "modelEngagementDialog");
				oDialog.open();
				this._fnFillFieldDataAfterOpen();
				this._fnValidateFieldsAndSetSaveBtnState();
			});
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ========================================== Initialization ========================================================= */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_initializeModel: function () {
			/* "_modelProjectDialog" is the main model for the Dialog, it holds everything*/
			this._modelEngagementDialog = new JSONModel({});
			this._modelEngagementDialog.getData().aFieldValueStates = {};
			this._modelEngagementDialog.getData().aFieldValueStateTexts = {};
			this._modelEngagementDialog.getData().aEngagementReasonList = [];
			this._modelEngagementDialog.getData().sSelectedEngagementReason = Constants.getReasonOptions().engagement; //"ENG2" = Normal Engagement
			this._modelEngagementDialog.getData().aCustomerComboItems = [];
			this._modelEngagementDialog.getData().bShipToAlert = false;
			this._modelEngagementDialog.getData().aEngagementRatingsList = [];
			this._modelEngagementDialog.getData().engagementRating = ""; 	//this needs to be done already here, otherwise there is a console error, in case the user opens the dialog a second time
			this._modelEngagementDialog.getData().aEngagementStatusList = [];
			this._modelEngagementDialog.getData().busyCreateEngagement = false;
			this._modelEngagementDialog.refresh();
		},

		_fnFillFieldDataAfterOpen: function () {
			this._setUpCustomerSelectionModule1();
			this._setUpEmployeeSelectionModule1(this._oContext.getOwnerComponent().getModel("appData").getData().oCrmUserData.UserId);

			this._fnLoadEngagementRatingsFromLocal();
			this._fnLoadEngagementStatusFromLocal();

			this._oView.byId("idFieldEngagementName").setValue("");
			this._oView.byId("idFieldEngagementNameCounter").setText("80 characters remaining");
			this._oView.byId("idFieldEngagementDescription").setValue("");
			this._oView.byId("idFieldEngagementDescriptionCounter").setText("1333 characters remaining");
			this._oView.byId("idFieldEngagementStatus").setSelectedKey("71");
			this._oView.byId("idFieldEngagementRating").setSelectedKey("");
			this._oView.byId("idFieldEngagementStartDate").setDateValue(null);
			this._oView.byId("idFieldEngagementEndDate").setDateValue(null);
			this._oView.byId("idFieldEngagementReason").setSelectedKey("");
			this._oView.byId("idFieldComboCustomerId").setSelectedKey("");
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ============================================ Event Handler (except "save") ======================================== */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		fnHandleCancelPress: function () {
			this._pDialogCreateEngagement.then(oDialog => oDialog.close());
		},

		fnHandleEngagementReasonChange: function () {
			this._modelEngagementDialog.getData().bShipToAlert = false;
			if (this._oView.byId("idFieldEngagementReason").getSelectedKey() === Constants.getReasonOptions().engagement) { //normal Engagement
				let selectedBP = this._oView.byId("idFieldComboCustomerId").getSelectedKey();
				let selectedPF = selectedBP.split('|')[1];
				if (selectedPF !== Constants.getPartnerFct().shipToParty1 && selectedPF !== Constants.getPartnerFct().shipToParty2 && selectedPF !== undefined) {
					this._modelEngagementDialog.getData().bShipToAlert = true;
				}
			} else {
				this._fnHelperSetFieldsGlobalEngCase("", "");
			}
			this._modelEngagementDialog.refresh();
			this._fnValidateFieldsAndSetSaveBtnState();
		},



		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ===========================================   Validation   ======================================================== */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_fnAllRequiredFieldsFilled: function () {
			return (!!this._oView.byId("idFieldEngagementName").getValue() && !!this._oView.byId("idFieldEngagementDescription").getValue() &&
				!!this._oView.byId("idFieldEngagementStartDate").getDateValue() && !!this._oView.byId("idFieldEngagementEndDate").getDateValue() &&
				(this._oEmployeeSelection1._fnGetEmployeeIdFieldValueState() === "None" && !!this._oEmployeeSelection1.fnGetEmployeeId()) && !this._oCustomerSelection1.bWorkingOnChange &&
				((this._oCustomerSelection1._fnGetCustomerIdFieldValueState() === "None" && !!this._oCustomerSelection1.fnGetCustomerId()) || !!this._oView.byId("idFieldComboCustomerId").getValue()) &&
				this._oView.byId("idFieldMainContractId").getValueState() === "None" && this._oView.byId("idFieldGlobalEngagementCase").getValueState() === "None");
		},

		_fnValidateFieldsAndSetSaveBtnState: function () {
			let bSaveBtnEnableState = this._fnAllRequiredFieldsFilled();
			this._oView.byId("idBtnSave").setEnabled(bSaveBtnEnableState);
			return bSaveBtnEnableState;
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ===================================== Customer Search Help and Combo ============================================== */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_setUpCustomerSelectionModule1: function (sInitialCustomerId) {
			let oCustomerSelectionCustomizing = {
				sInputFragmentId: "idFragmentCustomerIdDialogCreateEngagement",
				bInputFragmentHasTextField: true,
				sValueHelpFragmentId: "CustomerSelection1",
				sDialogWidth: "833px",
				sDialogHeight: "770px",
				sCustomerIdFieldGridSpan: "XL3 L3 M3 S3",
				sCustomerNameFieldGridSpan: "XL4 L4 M4 S4",
				bCustomerIdRequired: true,
				bCustomerTextFieldVisible: true,
				fnCallBackAfterValueChange: (oNewCustomer, sValueState) => {
					//define what needs to happen in your view controller, when the Customer has changed....
					let aCustomerList = [];
					if (oNewCustomer?.PartnerID && sValueState === "None") {
						this._fnHelperSetFieldMainContractId(""); //clear the contract field
						aCustomerList.push({
							"customerId": oNewCustomer.PartnerID,
							"comboValue": oNewCustomer.PartnerID + " - " + oNewCustomer.FullName,
							"comboAdditional": "Manual selection",
							"customerName": oNewCustomer.FullName
						});
					}
					this._fnSetDataForCustomerCombo(aCustomerList, oNewCustomer?.PartnerID);
					this._fnValidateFieldsAndSetSaveBtnState();
				}
			};
			//get the single instance and then initialize
			if (!this._oCustomerSelection1) this._oCustomerSelection1 = new CustomerSelection(); //get the instance and then initialize
			this._oCustomerSelection1.fnInitialize(this._oView, oCustomerSelectionCustomizing, sInitialCustomerId);
		},

		//when clicked on the Button next to the Customer-Combo, in order to open the Customer Search
		fnCustomerSelectionBtnDialogOpen: function (oEvent) {
			this._oCustomerSelection1.fnCustomerSelectionDialogOpen(oEvent);
		},

		//when the user has selected another item from the customer combo list
		fnHandleCustomerComboChange: function (oEvent) {
			let selectedBP = oEvent?.getSource()?.getSelectedKey() || "";
			let selectedID = selectedBP.split('|')[0];
			let selectedPF = selectedBP.split('|')[1];
			let selectedCustomerName = oEvent?.getSource()?.getItemByKey(selectedBP)?.getProperty("text")?.split(" - ")[1];

			this._modelEngagementDialog.getData().bShipToAlert = selectedPF !== Constants.getPartnerFct().shipToParty1 && selectedPF !== Constants.getPartnerFct().shipToParty2;
			this._modelEngagementDialog.refresh();
			this._oCustomerSelection1.fnSetCustomerIdNoHandle(selectedID, selectedCustomerName);   //set the selected customer also to the currently hidden CustomerSelection-module-field
			this._fnHelperSetFieldsGlobalEngCase("", "");  //clear the Global Engagement field
			this._fnValidateFieldsAndSetSaveBtnState();
		},

		//data for customer combo is set either indirectly by selecting a contract, or directly by using customer search help
		_fnSetDataForCustomerCombo: function (aCustomersList, selectedCustomerId) {
			this._fnHelperSetFieldsGlobalEngCase("", "");  //clear the Global Engagement field

			this._modelEngagementDialog.getData().bShipToAlert = false;
			this._modelEngagementDialog.getData().aCustomerComboItems = aCustomersList;
			this._modelEngagementDialog.refresh();

			let bSelectedCustomerInComboList = aCustomersList.findIndex(oElm => oElm.customerId === selectedCustomerId) > -1;
			if (bSelectedCustomerInComboList && aCustomersList.length === 1) {
				//user has manually selected the customer via search help, or via CustomerSelection-module
				this._oContext.getView().byId("idFieldComboCustomerId").setSelectedKey(selectedCustomerId);  //set customer into combo
				this._oCustomerSelection1.fnSetCustomerIdNoHandle(selectedCustomerId, aCustomersList[0].customerName);   //set customer into CustomerSelection-module-field
			} else {
				//indirect selection of customers via contract or not well selected via CustomerSelection-module
				this._oContext.getView().byId("idFieldComboCustomerId").setSelectedKey("");  //clear the selected customer
				if (!selectedCustomerId) this._oCustomerSelection1.fnSetCustomerIdNoHandle("", ""); //only clear the customerSelection-module, in case its not the one that is triggering this change....
			}
			this._fnValidateFieldsAndSetSaveBtnState();
		},


		/* =================================================================================================================== */
		/*=====================================================================================================================*/
		/*================================================== Contract Field  ==================================================*/
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		//open the Contract-Search-Popup, using the EngagementContracts-Module
		fnOnValueHelpMainContractId: function () {
			//data needed for EngagmentContracts-Module
			this._oContext.getModel("projectDetails").getData().CustomerID = this._oCustomerSelection1.fnGetCustomerId();
			this._oContext.getModel("projectDetails").refresh();
			let oEngagementContractSelectionCustomizing = {
				fnCallBackAfterValueChange: (oNewContractData) => {
					//triggered when a contract form popup result list is selected to set it into the contract field
					this._fnHelperSetFieldMainContractId(oNewContractData.ContractID);
				},
				bFieldCustomerIDVisible: false,
				bFieldSoldToVisible: true,
				bFieldServiceProductVisible: true,
				bColumnAssignedVisible: false,
				sContrRelPartner: "No",
				bShowClearButton: true
			};
			EngagementContracts.fnInitialize(this._oContext, oEngagementContractSelectionCustomizing);
			EngagementContracts.fnEngCaseContractSearchPopupOpen(this._oContext);
		},

		//check for the manually entered number if it is a valid contract in BE before setting it into the contract field
		fnHandleMainContractIdChanged: function (evt) {
			if (this._oView.byId("idFieldMainContractId").getValue()?.length > 0) {
				//something is entered, check its a valid contract number
				this._modelEngagementDialog.getData().busyMainContractSearch = true;
				this._modelEngagementDialog.refresh();
				ContractSelection.fnGetDetailsForContract(evt.getParameter("newValue"), false, (oContractFound) => {
					this._modelEngagementDialog.getData().busyMainContractSearch = false;
					this._modelEngagementDialog.refresh();
					if (oContractFound.results.length === 1) {
						//manually entered number is valid!
						this._fnHelperSetFieldMainContractId(oContractFound.results[0].ContractID);
					} else {
						//the manually entered number is no contract
						this._fnHelperSetFieldMainContractId(evt.getParameter("newValue"), false);
					}
				});
			} else {
				//user has cleared the field, that is OK, it is not mandatory
				this._fnHelperSetFieldMainContractId("");
			}
		},

		//helper function to be used for setting the value in the contract field, either manually or by search help and triggering the
		//filling of the related customer-combo.
		_fnHelperSetFieldMainContractId: function (sContractId, bValid = true) {
			if (bValid || sContractId === "") {
				this._oView.byId("idFieldMainContractId").setValueState("None");
				this._oView.byId("idFieldMainContractId").setValueStateText();
				this._oView.byId("idFieldMainContractId").setValue(sContractId);
				if (sContractId === "") this._fnSetDataForCustomerCombo([], "");
				else this._fnGetCustomersForContractFromBE(sContractId);
			} else {
				this._oView.byId("idFieldMainContractId").setValueState("Error");
				this._oView.byId("idFieldMainContractId").setValueStateText(this._oResourceBundle.getText("Engagement.MsgEnterValidContractIdOrNone"));
				this._fnSetDataForCustomerCombo([], "");
			}
			this._fnValidateFieldsAndSetSaveBtnState();
		},

		_fnGetCustomersForContractFromBE: function (sContractId) {
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ContractSet";
			entities.entitySet = "ContractSet(CustomerID='0000000000',ContractID='" + sContractId + "')";
			entities.navigation = "toContractPartners";
			entities.oContext = this._oContext;
			entities.currentView = this._oContext.getView();
			entities.callbackSuccess = (oData) => {
				let oCustomerComboListModel = new JSONModel({
					result: []
				});
				oData.results.forEach((oBP) => {
					if (oBP.PartnerFct === Constants.getPartnerFct().shipToParty1 ||
						oBP.PartnerFct === Constants.getPartnerFct().shipToParty2 ||
						oBP.PartnerFct === Constants.getPartnerFct().customerForCallOff)
						oCustomerComboListModel.getData().result.push({
							"customerId": oBP.PartnerNo + "|" + oBP.PartnerFct,
							"comboValue": oBP.PartnerNo + " - " + oBP.Name,
							"comboAdditional": oBP.PartnerFctDesc,
							"customerName": oBP.Name
						});
				});
				oData.results.forEach((oBP) => {
					if (oBP.PartnerFct === Constants.getPartnerFct().soldToParty)
						oCustomerComboListModel.getData().result.push({
							"customerId": oBP.PartnerNo + "|" + oBP.PartnerFct,
							"comboValue": oBP.PartnerNo + " - " + oBP.Name + " ", //so the combo-value-changed-event is recognized
							"comboAdditional": oBP.PartnerFctDesc,
							"customerName": oBP.Name
						});
				});
				this._modelEngagementDialog.getData().aCustomerComboItems = oCustomerComboListModel.getData().result;
				this._modelEngagementDialog.refresh();
				this._fnSetDataForCustomerCombo(oCustomerComboListModel.getData().result, "");
			};
			this._oContext.readBaseRequest(entities);
		},

		fnEngCaseContractSearchPopupSearch: function (oEvent) {
			EngagementContracts.fnEngCaseContractSearchPopupSearch(this._oContext, oEvent);
		},

		fnEngCaseContractSearchPopupFilterBarClear: function (oEvent) {
			EngagementContracts.fnEngCaseContractSearchPopupFilterBarClear(this._oContext, oEvent);
		},

		fnEngCaseContractSearchPopupClose: function (oEvent) {
			EngagementContracts.fnEngCaseContractSearchPopupClose(this._oContext, oEvent);
			this._fnValidateFieldsAndSetSaveBtnState();
		},

		/* =================================================================================================================== */
		/*=====================================================================================================================*/
		/*================================================== Person Responsable================================================*/
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_fnCallbackEmployeeSelectionChange: function () {
			this._fnValidateFieldsAndSetSaveBtnState();
		},

		/* =================================================================================================================== */
		/*=====================================================================================================================*/
		/*=========================================   SAVE Engagement =========================================================*/
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		fnHandleSavePress: function (evt) {
			if (this._fnValidateFieldsAndSetSaveBtnState()) {
				this._fnClearAllMessages();
				this._fnShowProgressIndicator();
				this._pFnSaveEngagement().then(oData => {
					this._oContext.getOwnerComponent().trackEvent("Create_Engagement");
					//in case a contract was maintained and it is not a global engagement, save the contract as well now
					if (this._oView.byId("idFieldEngagementReason").getSelectedKey() === Constants.getReasonOptions().engagement &&
						this._oView.byId("idFieldMainContractId").getValue() !== '') this._pSaveContractData(oData);
					this._fnCloseAndNavigateToNewEngagement(oData);
				});
			}
		},

		_pFnSaveEngagement: function () {
			return new Promise(resolve => {
				if (this._fnValidateFieldsAndSetSaveBtnState()) { //returns TRUE if everything is correct!
					this._modelEngagementDialog.getData().busyCreateEngagement = true;
					this._modelEngagementDialog.refresh();
					let entities = {};
					entities.servicePath = Constants.getServicePath();
					entities.entitySet = Constants.getEntities().ProjectEntity;
					entities.data = this._fnPrepareDataForSaveProjectDetails();
					entities.currentView = this._oView;
					entities.oContext = this._oContext;
					entities.errorMessage = this._oResourceBundle.getText("CreateEngagement.SaveNewEngagement");
					entities.callbackUnsetBusyIndicator = () => {
						this._modelEngagementDialog.getData().busyCreateEngagement = false;
						this._modelEngagementDialog.refresh();
					};
					entities.callbackSuccess = oData => resolve(oData);
					entities.callbackError = oError => this._fnHandleEngagementSaveError(oError, "busyCreateEngagement");
					BaseRequest.handleCreate(entities);
				}
			});
		},

		_pSaveContractData: function (oData) {
			return new Promise((resolve, reject) => {
				this._oDialogProgressIndicator.getContent()[0].setDisplayValue("Saving Main Contract linkage");
				this._oDialogProgressIndicator.getContent()[0].setPercentValue(70);
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "ProjectContractSet";
				entities.errorMessage = this._oContext.getResourceBundle().getText("Engagement.Contracts.error.BECall");
				entities.data = {
					"CaseId": oData.ProjectID,
					"ContrId": this._oView.byId("idFieldMainContractId").getValue()
				};
				entities.oContext = this._oContext;
				entities.currentView = this._oContext.getView();
				entities.callbackSuccess = (oDataC) => {
					entities.oContext.getOwnerComponent().trackEvent("Add_ContractToEngagement");
					resolve();
				};
				this._oContext.createBaseRequest(entities);
			});
		},

		_fnCloseAndNavigateToNewEngagement: function (oData) {
			this._oDialogProgressIndicator.close();
			this._modelEngagementDialog.refresh();
			this._pDialogCreateEngagement.then(oDialog => oDialog.close());
			let subNavigateToTab = this._oView.byId("idFieldEngagementReason").getSelectedKey() === Constants.getReasonOptions().engagement ? "ToParties" : ""
			this._oContext.fnHandleNavToNewCreatedEngagement(oData.ProjectID, subNavigateToTab); //Navigate to engagement detail + tab
			this._modelEngagementDialog.getData().busyCreateEngagement = false;
		},

		_fnPrepareDataForSaveProjectDetails: function () {
			let dStartDate = this._oView.byId("idFieldEngagementStartDate").getDateValue(),
				dEndDate = this._oView.byId("idFieldEngagementEndDate").getDateValue(),
				sReason = this._oView.byId("idFieldEngagementReason").getSelectedKey();
			let data = {
				"CaseRating": this._oView.byId("idFieldEngagementRating").getSelectedKey(),
				"CustomerID": this._oCustomerSelection1.fnGetCustomerId(),
				"CustomerName": "",
				"EmplRespID": this._oEmployeeSelection1.fnGetEmployeeId(),
				"ProjectName": this._oView.byId("idFieldEngagementName").getValue(),
				"ProjectDescription": this._oView.byId("idFieldEngagementDescription").getValue(),
				"ProjectStartDate": dStartDate === null ? null : dStartDate,
				"ProjectEndDate": dEndDate === null ? null : dEndDate,
				"ReasonCode": sReason,
				"StatusID": this._oView.byId("idFieldEngagementStatus").getSelectedKey()
			};
			if (sReason === Constants.getReasonOptions().engagement) {
				data.ParentCaseID = this._oContext.getView().byId("idFieldGlobalEngagementCase").getValue();
			}
			return data;
		}
	});
});
