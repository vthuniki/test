sap.ui.define([
 	"com/sap/ui/hep/controller/ServiceOrder/ServiceOrder",
 	"sap/ui/model/json/JSONModel",
 	"com/sap/ui/hep/model/formatter",
 	"sap/m/MessageBox",
 	"com/sap/ui/hep/util/Dates",
 	"sap/ui/core/Fragment",
 	"sap/ui/core/syncStyleClass",
 	"com/sap/ui/hep/util/MessageHandlingPopover",
 	"com/sap/ui/hep/util/Questionnaire",
 	"com/sap/ui/hep/util/Validator",
 	"com/sap/ui/hep/util/ServiceOrderManipulation",
 	"com/sap/ui/hep/util/ServiceOrderValidation",
 	"com/sap/ui/hep/util/ReferenceObjects",
	"com/sap/ui/hep/util/Attachments",
	"com/sap/ui/hep/reuse/Constants"

 ], function (ServiceOrder, JSONModel, Formatters,
 	MessageBox, Dates,
 	Fragment, syncStyleClass,
 	MessageHandlingPopover, Questionnaire, Validator, ServiceOrderManipulation, ServiceOrderValidation,
	ReferenceObjects, Attachments, Constants) {

 	"use strict";
	
 	return ServiceOrder.extend("com.sap.ui.hep.controller.ServiceOrder.ServiceOrderMaintain", {
 		formatter: Formatters,
 		dates: Dates,
 		soManipulation: ServiceOrderManipulation,
 		SOValidation: ServiceOrderValidation,
 		messageHandler: MessageHandlingPopover,
 		questionnaire: Questionnaire,
 		referenceObjects: ReferenceObjects,
 		attachments: Attachments,

 		/* ============================================ General ================================================ */

 		onInit: function () {
 			this.router = this.getRouter();
 			this.router.getRoute("ServiceOrderMaintain").attachPatternMatched(this._handleRouteMatchedEdit, this);
 			this.router.getRoute("ServiceOrderCreate").attachPatternMatched(this._handleRouteMatchedCreate, this);

 			this.byId("soDescription").addEventDelegate({
 				onAfterRendering: function () {
 					setTimeout(function () {
 						this.byId("soDescription").focus();
 					}.bind(this), 500);
 				}.bind(this)
 			});
 			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
 		},

 		onAfterRendering: function () {
 			Object.getPrototypeOf(this.constructor.prototype).onAfterRendering.apply(this, arguments);
 			this.getValidToken(this);
 		},

 		_handleRouteMatchedCreate: function (oEvent) {
 			this._idServiceOrder = "";
 			this._idProject = oEvent.getParameters().arguments.projectID;
 			this._oDataToCreateSO = oEvent.getParameters().arguments['?details'];

 			this._displayMode = false;
 			this.initialize();
 			this.initSOModel(this);
 			this._readDataForCreateMode();
 			this._pLoadServiceHierarchyBaseDataFromCRM().then(() => {
 				if (this._oDataToCreateSO.sessionId) {
 					this.oSelectedServiceProduct = this.serviceHierarchyBaseData.find(elm => elm.CatalogId === this._oDataToCreateSO.catalogId &&
 						elm.ServiceProductId === this._oDataToCreateSO.serviceProductId &&
 						elm.SessionProductId === this._oDataToCreateSO.sessionId);
 				} else {
 					this.oSelectedServiceProduct = this.serviceHierarchyBaseData.find(elm => elm.CatalogId === this._oDataToCreateSO.catalogId &&
 						elm.ServiceProductId === this._oDataToCreateSO.serviceProductId);
 				}
 				this.getView().getModel("oModelSO").getData().SelectedProductText = this.oSelectedServiceProduct.ServiceProductId + " " + this.oSelectedServiceProduct
 					.ServiceDescription;
 				this.getView().getModel("oModelSO").getData().MainProductText = this.oSelectedServiceProduct.ServiceDescription;
 				this.getView().getModel("oModelSO").getData().MainProduct = this.oSelectedServiceProduct.ServiceProductId;
 				this.getView().getModel("oModelSO").getData().productIdSelected = this.oSelectedServiceProduct.ServiceProductId ? true : false;
 				this.getView().getModel("oModelSO").refresh();

 				if (this.getView().byId("CreateSOWizard").getProgress() === 1) {
 					this.getView().byId("CreateSOWizard").nextStep();
 					this.getView().byId("CreateSOWizard").goToStep(this.getView().byId("CreateSOWizard").getSteps()[0]);
 				}

 				this.soManipulation.proceedAfterServiceProductIsSet(this.getView().getModel("oModelSO").getData().MainProduct, this);
 			});
 		},

 		_handleRouteMatchedEdit: function (oEvent) {
 			this._idServiceOrder = oEvent.getParameters().arguments.serviceOrderID;
 			this.initialize();
 			this._pLoadServiceHierarchyBaseDataFromCRM().then(() => {
 				this.checkServiceOrderIsLocked(this._idServiceOrder).then(() => {
 					this.getAppData().getData().requestSOLockedInfo = true;
 					this.getRouter().navTo("ServiceOrderDisplay", {
 						serviceOrderID: this._idServiceOrder
 					});
 				}, () => {
 					this._displayMode = false;
 					this.initSOModel(this);
 					this._readDataForEditMode();
 				});
 			});
 		},

 		_readDataForCreateMode: function () {
 			this.resetWizard();
 			this._oData.currentStep = this._idServiceOrder ? 3 : 1;

 			this.getView().getModel("localModel").getData().formEditMode = true;
 			this.getView().getModel("localModel").getData().SOEdit = false;
 			this.getView().getModel("localModel").getData().SOCreate = true;

 			this.attachments.initializeDetails(this);
 			this.attachments.fnBuildAttachmentsCollection(this, false);
 			this.getView().getModel("localModel").refresh();
 			this.cloudRefObjects.initialize();

 			this.pReadProjectData().then(() => {
 				this.getView().byId("ReferenceObject").setValue("");
 				this.referenceObjects.readReferenceObjectsOfProject(this);
					this._setUpCbxCombo(Constants.getCbxCustKey().NotEvaluatedYet);
 				this._checkSurveyRecExist(this.getView().getModel("projectDetails").getData().CustomerID);
 			});
 			this._readQualification();
 		},

 		_readDataForEditMode: function () {
 			this.resetWizard();
 			this._oData.currentStep = this._idServiceOrder ? 3 : 1;

 			this.attachments.initializeDetails(this);
 			this.getView().getModel("localModel").getData().SOEdit = true;
 			this.getView().getModel("localModel").getData().SOCreate = false;
 			this.getView().getModel("localModel").getData().formEditMode = true;
 			this.getView().getModel("localModel").getData().loadingDataForEditMode = true;

 			this.getView().getModel("localModel").refresh();
 			this.getView().getModel("oModelSO").getData().productIdSelected = true;
 			this.getView().getModel("oModelSO").refresh();

 			this.getView().byId("CreateSOWizard").setCurrentStep(this.getView().byId("ServiceQuestionnaireStep"));

 			this.getView().getModel("localModel").getData().busyServiceOrderPage = true;

 			this.soManipulation.pReadAllServiceProductsFromCRM(this).then(() => {
 				return this.pLoadDataForAlreadyExistingSO();
 			}).then((oDataSo) => {
 				this.getView().getModel("messagesModel").getData().messagesTmp = this.getView().getModel("messagesModel").getData().messages; ///prevent messagePopover mess-up
 				this.getView().getModel("messagesModel").getData().messages = []; ///prevent messagePopover mess-up
 				this.handleSuccessReadSOData(oDataSo);
 				this._setUpCbxCombo(this.getView().getModel("oModelSO").getData().CbxEnabled);
 				this.attachments.fnReadAttachmentsSO(this);
 				this.soManipulation.additionalInfoValidation(this);
 				// For cloud tenants, read CloudReferenceObjects
 				this.cloudRefObjects.pReadByOrderID(this).then(() => {
 					this.cloudRefObjects.buildTree(this);
 				});

 				this.getView().getModel("localModel").getData().busyServiceOrderPage = false;
 				this.getView().getModel("localModel").refresh();

 				this.getView().byId("SOComponents").expandToLevel(3);

 				this.soManipulation.proceedAfterServiceProductIsSet(this.getView().getModel("oModelSO").getData().MainProduct, this);

 				this._checkSurveyRecExist(this.getView().getModel("oModelSO").getData().CustomerID);
 				return this.pReadProjectData();
 			}).then(() => {
 				this.getView().getModel("messagesModel").getData().messages = this.getView().getModel("messagesModel").getData().messagesTmp; ///prevent messagePopover mess-up
 				delete this.getView().getModel("messagesModel").getData().messagesTmp; ///prevent messagePopover mess-up
 				return this.referenceObjects.readReferenceObjectsOfProject(this);
 			}).then(() => {
 				return this._selectSORefObjInCombo();
 			});
 			this._readQualification();
 		},

 		_checkSurveyRecExist: function (sCustomerID) {
 			return new Promise((resolve, reject) => {
 				let oParams = {
						servicePath: Constants.getServicePath(),
 					function: "HasSurveyRecipients",
 					method: "GET",
 					urlParameters: {
 						"CustomerID": sCustomerID
 					},
 					callbackSuccess: function (data) {
 						let bHasSurveyRec = data.HasSurveyRecipients === "X" || data.HasSurveyRecipients === true ? true : false;

 						this.getView().getModel("localModel").getData().hasSurveyRec = bHasSurveyRec;
 						this.getView().getModel("localModel").refresh();
 						if (!bHasSurveyRec) {
 							this.getView().getModel("oModelSO").getData().FeedbackEnabled = false;
 						}
 						this.getView().getModel("oModelSO").refresh();
 						resolve();
 					}.bind(this)
 				};
 				this.callFunction(oParams);
 			});
 		},

 		onNavToEngagementDetails: function (oEvent) {
 			this.navToEngagement(oEvent);
 		},

 		/**
 		 * After SO-Data has been read from BE, fill the view Model "oModelSO" with it.
 		 * @param {object} oData - result set
 		 */
 		handleSuccessReadSOData: function (oData) {
 			this._idServiceOrderGuid = oData.SoGUID;
 			this._idProject = oData.ProjectID;
 			let oMergedData = Object.assign({}, this.getView().getModel("oModelSO").getData(), oData);
 			this.getView().getModel("oModelSO").setData(oMergedData);
 			this.getView().getModel("oModelSO").getData().displayMode = this._displayMode;
 			this.getView().getModel("oModelSO").refresh();
 			this.setAllServiceDataFieldValueStatesToNone();
 			this.manipulateSOData();

 			let oProdIdSelected = this._findProdIdInSelectionList(this.getView().getModel("oModelSO").getData().MainProduct);
 			if (oProdIdSelected) {
 				this.getView().getModel("oModelSO").getData().SelectedProductText =
 					oProdIdSelected.Key + " - " + oProdIdSelected.Value;
 				this.getView().getModel("oModelSO").getData().MainProductText = oProdIdSelected.Value;
 			} else {
 				if (this.getView().getModel("oModelSO").getData().ProductText.length) {
 					this.getView().getModel("oModelSO").getData().SelectedProductText =
 						this.getView().getModel("oModelSO").getData().ProductText;
 				} else {
 					this.getView().getModel("oModelSO").getData().SelectedProductText =
 						this.getView().getModel("oModelSO").getData().MainProduct;
 				}
 			}
 			this.getView().getModel("oModelSO").getData().selectedRefObj = {};
 			this.getView().getModel("oModelSO").getData().selectedRefObj.SystemID = this.getView().getModel("oModelSO").getData().SystemSID;
 			this.getView().getModel("oModelSO").getData().selectedRefObj.SolmanSID = this.getView().getModel("oModelSO").getData().SolmanSID;
 			this.getView().getModel("oModelSO").getData().selectedRefObj.SolmanComponent = this.getView().getModel("oModelSO").getData().SolmanIBComp;
 			this.getView().getModel("oModelSO").getData().selectedRefObj.IbComponent = this.getView().getModel("oModelSO").getData().SystemIBComp;
 			this.getView().getModel("oModelSO").getData().refObjExist = true;

 			if (this.getView().getModel("oModelSO").getData().ContractID !== "") {
 				this.getView().getModel("oModelSO").getData().contractsExist = true;
 				this.getView().getModel("oModelSO").getData().contractSelected = true;
 			}

 			
 			this.getView().getModel("oModelSO").getData().reqDelDateExists = !!this.getView().getModel("oModelSO").getData().RecDelDate;
			this.getView().getModel("oModelSO").getData().goLiveExists = !!this.getView().getModel("oModelSO").getData().GoLiveDate;
 			this.getView().getModel("oModelSO").refresh();
 		},

 		additionalInfoValidation: function () {
 			if (!this._oDialogSO) {
 				this.soManipulation.additionalInfoValidation(this);
 			}
 		},

 		/* ============================================ Save SO ================================================ */

 		fnHandleSave: function (oEvent) {
 			this.getView().getModel("oSOGSearch").getData().showWarningMessage = false;
 			this.getView().getModel("oSOGSearch").refresh();
 			this.oMessagePopover.close();
 			this._oData.isSavePress = true;
 			this._oModel.refresh();

 			if (this.getView().getModel("oModelSO").getData().SoID) {
 				this.soManipulation.updateSO(this);
 			} else {
 				this.soManipulation.handleSOCreation(this);
 			}

 			this._oData.isSavePress = false;
 			this._oModel.refresh();
 			this._isSaved = true;
 		},

 		fnHandleRealeaseForDelivery: function (oEvent) {
 			this.oMessagePopover.close();
 			this._oData.isSavePress = true;
 			this._oData.isReleasePress = true;
 			this._oModel.refresh();

 			this.soManipulation.updateSO(this);

 			this._oData.isReleasePress = false;
 			this._oData.isSavePress = false;
 			this._oModel.refresh();

 		},

 		/* =============================== Switch to Display mode ============================================== */

 		fnHandleDisplaySO: function (oEvent) {
 			this.questionnaire.destroyQuestionnaire(this);
 			this.getOwnerComponent().getModel("appData").getData().noReporting = true;
 			this.getRouter().navTo("ServiceOrderDisplay", {
 				// mode: "display",
 				// projectID: this._idProject,
 				serviceOrderID: this._idServiceOrder
 			});
 		},

 		/* ==================================== Description ==================================================== */

 		handleDescriptionChange: function (oEvent) {
 			this.SOValidation.validateSoDataStepField(this.getView().getModel("oModelSO"), this);
 		},

 		/* ==================================== Service Order Group ============================================ */

 		fnHandleSOGroupValueHelp: function (oEvent) {
 			this._setCurrentUserAsDefaultForCreateByField();
 			if (!this._oVHSOGroup) {
 				try {
 					Fragment.load({
 						id: this.getView().getId(),
 						name: "com.sap.ui.hep.view.ServiceOrder.fragment.VHServiceOrderGroup",
 						controller: this
 					}).then(oDialogVHSO => {
 						this._oVHSOGroup = oDialogVHSO;
 						this._oVHSOGroup.setModel(this.getModel("i18n"), "i18n");
 						this._oVHSOGroup.setModel(this.getView().getModel("localModel"), "localModel");
 						this._oVHSOGroup.setModel(this.getView().getModel("oSOGroupModel"), "oSOGroupModel");
 						this.getView().addDependent(this._oVHSOGroup);
 						syncStyleClass(this.getView().getController().getOwnerComponent().getContentDensityClass(),
 							this.getView(), this._oVHSOGroup);
 						this._oVHSOGroup.getModel("oSOGroupModel").getData().currentView = "fields";
 						this._oVHSOGroup.getModel("oSOGroupModel").getData().numberOfGroups = 0;
 						this._oVHSOGroup.getModel("oSOGroupModel").refresh();
 						this.onSearchSOGroup();
 						this._oVHSOGroup.open();
 					});
 				} catch (oError) {
 					if (oError.statusCode === 503) {
 						let oView = this.getView();
 						let params = {
 							currentView: oView
 						};
 						this.handleSessionTimeout(params, this);
 					}
 				}
 			} else {
 				this._oVHSOGroup.open();
 			}
 		},

 		_setCurrentUserAsDefaultForCreateByField: function () {
 			let oSOGModel = this.getView().getModel("oSOGroupModel");
 			oSOGModel.getData().createdBy = this.currentUserId;
 			oSOGModel.refresh();
 		},

 		fnHandleDiscardSOGroup: function () {
 			this._oVHSOGroup.close();
 			this._oVHSOGroup.destroy();
 			this._oVHSOGroup = undefined;
 		},

 		_determineAndStoreMostFrequentlyUsed: function () {
 			let oSOGData = JSON.stringify(this.getView().getModel("oSOGroupModel").getData().results);
 			this.getView().getModel("oSOGroupModel").getData().frequencies = [];
 			let oMostFrequentlyUsed = JSON.parse(oSOGData).sort((oSOG1, oSOG2) =>
 				(-(oSOG1.Frequency - oSOG2.Frequency)));
 			this.getView().getModel("oSOGroupModel").getData().frequencies = oMostFrequentlyUsed.slice(0, 3);
 			if (this.getView().getModel("oSOGroupModel").getData().frequencies.length) {
 				let iSum = this.getView().getModel("oSOGroupModel").getData().frequencies.map(item => item.Frequency)
 					.reduce((oPreviusSOGFrequency, oCurrentSOGFrequency) => oPreviusSOGFrequency + oCurrentSOGFrequency);
 				this.getView().getModel("oSOGroupModel").getData().frequencies.map(oSOG => {
 					let oIndividualPercentage = parseFloat(((oSOG.Frequency / iSum) * 100).toFixed(1), 10);
 					oSOG.Value = parseInt(oSOG.Frequency, 10);
 					oSOG.DisplayedValue = oIndividualPercentage + "%";
 				});
 			}
 			this.getView().getModel("oSOGroupModel").refresh();
 		},

 		fnHandleCreateByLiveChange: function (oEvent) {
 			let sUserValue = oEvent.getParameters().value;
 			let isValidUser = this._validUserSOGSearch(sUserValue);
 			this.getView().getModel("oSOGroupModel").getData().valueStateCreatedBy = isValidUser || sUserValue.trim().length === 0 ? "None" :
 				"Error";
 			this.getView().getModel("oSOGroupModel").refresh();
 		},

 		createdByValueHelpTrigger: function () {
 			this.getView().byId("createdByTable").removeSelections();
 			let oNavCon = this.getView().byId("navContainerSOG"),
 				oDetailPage = this.getView().byId("detailSOG");
 			this.loadResponsibleSelectionList();
 			oNavCon.to(oDetailPage);

 		},

 		onSOGNavBack: function () {
 			let oNavCon = this.getView().byId("navContainerSOG");
 			oNavCon.back();
 		},

 		handleSOGItemPressed: function (oEvent) {
 			let sPath = oEvent.getParameters().listItem.getBindingContextPath();
 			let oModel = oEvent.getParameters().listItem.getModel("oSOGroupModel");
 			let sSelectedEntry = oModel.getProperty(sPath);
 			this.getView().getModel("oModelSO").getData().ServiceOrderGroup = sSelectedEntry.Description;
 			this.getView().getModel("oModelSO").refresh();
 			this.fnHandleDiscardSOGroup();

 		},

 		onSOGVHFilterModeSelectionChange: function (oEvent) {
 			this.getView().getModel("oSOGroupModel").getData().currentView = oEvent.getSource().getSelectedKey();
 			this.getView().getModel("oSOGroupModel").refresh();
 		},

 		onSOGSelectionChanged: function (oEvent) {
 			let oSelected = [],
 				oSource = oEvent.getSource();
 			if (oEvent.getSource()) {
 				oSelected = oEvent.getParameter("segment");
 				oSource.setSelectedSegments([oSelected]);
 				this.getView().getModel("oModelSO").getData().ServiceOrderGroup = oSource.getSelectedSegments()[0].getProperty("label");
 				this.getView().getModel("oModelSO").refresh();
 				this.fnHandleDiscardSOGroup();
 			}
 		},

 		fnShowDetailsContractId: function (oEvent) {
 			let oSource = oEvent.getSource();
 			let sFragmentName = this.getView().getModel("oModelSO").getData().validContract ? "ServiceOrderPopoverContract" :
 				"ServiceOrderPopoverNoContract";
 			try {
 				Fragment.load({
 					id: this.getView().getId(),
 					name: "com.sap.ui.hep.view.ServiceOrder.fragment." + sFragmentName,
 					controller: this
 				}).then(oPopover => {
 					this._SOCPopover = oPopover;
 					this._SOCPopover.setModel(this.getModel("i18n"), "i18n");
 					this.getView().addDependent(this._SOGPopover);
 					syncStyleClass(this.getView().getController().getOwnerComponent().getContentDensityClass(),
 						this.getView(), this._SOCPopover);
 					this._SOCPopover.openBy(oSource);
 				});
 			} catch (oError) {
 				if (oError.statusCode === 503) {
 					let params = {
 						currentView: this.getView()
 					};
 					this.handleSessionTimeout(params, this);
 				}
 			}
 		},

 		fnShowDetailsServiceOrderGroup: function (oEvent) {
 			let oSource = oEvent.getSource();
 			if (!this._SOGPopover) {
 				try {
 					Fragment.load({
 						id: this.getView().getId(),
 						name: "com.sap.ui.hep.view.ServiceOrder.fragment.ServiceOrderPopover",
 						controller: this
 					}).then(oPopover => {
 						this._SOGPopover = oPopover;
 						this._SOGPopover.setModel(this.getModel("i18n"), "i18n");
 						this.getView().addDependent(this._SOGPopover);
 						syncStyleClass(this.getView().getController().getOwnerComponent().getContentDensityClass(),
 							this.getView(), this._SOGPopover);
 						this._SOGPopover.openBy(oSource);
 					});
 				} catch (oError) {
 					if (oError.statusCode === 503) {
 						let params = {
 							currentView: this.getView()
 						};
 						this.handleSessionTimeout(params, this);
 					}
 				}
 			} else {
 				this._SOGPopover.openBy(oSource);
 			}
 		},

 		handleSOCDetailsPopoverClose: function (oEvent) {
 			this._SOCPopover.close();
 			this._SOCPopover.destroy();
 			this._SOCPopover = undefined;
 		},

 		handleSOGDetailsPopoverClose: function (oEvent) {
 			this._SOGPopover.close();
 			this._SOGPopover.destroy();
 			this._SOGPopover = undefined;
 		},

 		/* ==================================== Account Contact Person ========================================= */

 		/**
 		 * @param {object} oEvent getSource().data("BpFct") Pass partner function via custom data
 		 * oEvent.getSource().data("BpFct") Pass partner function via custom data
 		 */
 		fnHandleSOACPValueHelp: function (oEvent) {
 			let sBpFct = oEvent.getSource().data("BpFct");

 			if (!this._oVHSOAccContactPers) {
 				try {
 					Fragment.load({
 						id: this.getView().getId(),
 						name: "com.sap.ui.hep.view.ServiceOrder.fragment.VHAccContactPers",
 						controller: this
 					}).then(oDialogACC => {
 						this._oVHSOAccContactPers = oDialogACC;
 						this._oVHSOAccContactPers.setModel(this.getModel("i18n"), "i18n");
 						this._oVHSOAccContactPers.setModel(this.getView().getModel("localModel"));
 						this._oVHSOAccContactPers.getCustomData()[0].setValue(sBpFct);
 						this.getView().getModel("oModelAcc").getData().HasEmail = true;
 						if(sBpFct === "SVR") {
 							this.getView().getModel("oModelAcc").getData().DialogTitle = this.getResourceBundle().getText("ValueHelp.SOACP.SVRTitle");
 							this.getView().getModel("oModelAcc").getData().SearchResultTitle = this.getResourceBundle().getText(
 								"ValueHelp.SOACP.SVRTableHeader");
						}else{
 							this.getView().getModel("oModelAcc").getData().DialogTitle = this.getResourceBundle().getText("ValueHelp.SOACP.Title");
 							this.getView().getModel("oModelAcc").getData().SearchResultTitle = this.getResourceBundle().getText(
 								"ValueHelp.SOACP.PeopleTableHeader");
 						}
 						this.getView().addDependent(this._oVHSOAccContactPers);
 						syncStyleClass(this.getView().getController().getOwnerComponent().getContentDensityClass(),
 							this.getView(), this._oVHSOAccContactPers);
 						this._oVHSOAccContactPers.open();
 						this.searchSOACP(null, sBpFct);
 					});
 				} catch (oError) {
 					if (oError.statusCode === 503) {
 						let oView = this.getView();
 						let params = {
 							currentView: oView
 						};
 						this.handleSessionTimeout(params, this);
 					}
 				}
 			} else {
 				this._oVHSOAccContactPers.open();
 			}
 		},

 		/**
 		 * @param {object} oEvent triggered when the user searches for the Account Contact Person
 		 */
 		searchSOACP: function (oEvent, sBpFct) {
 			if (!sBpFct || sBpFct === "") {
 				sBpFct = oEvent.getSource().getParent().getParent().getCustomData().find(elem => elem.getKey() === "BpFct").getValue();
 			}
 			this.getView().getModel("localModel").getData().busyVHAccPerson = true;
 			this.getView().getModel("localModel").refresh();
 			let modelROData = this.getView().getModel("oModelAcc").getData();
 			let customerId = this.getView().getModel("projectDetails").getData().CustomerID;

 			let entities = {};
				entities.servicePath = Constants.getServicePath();
 			entities.entitySet = "CustomerSet";
 			entities.getEntity = customerId;
 			entities.navigation = "toContacts";
 			entities.filter = this._prepareFilterPayloadSearchSOACP(modelROData, sBpFct);
 			entities.currentView = this.getView();
 			entities.oContext = this;
 			entities.busyIndicator = "busyVHAccPerson";

 			entities.errorMessage = this.getResourceBundle().getText("SO.ReadContactsError");
 			entities.callbackSuccess = (data) => {
 				this._handleSuccessAccountPerson(data, false);
 			};
 			this.readBaseRequest(entities);
 			const selectedRefObj = this.getView().byId("ReferenceObject").getSelectedItem();
 			if (selectedRefObj) {
 				if (this.getModel("ReferenceObjects").getProperty(selectedRefObj.getBindingContext(
 						"ReferenceObjects").getPath()).Customer !== customerId) {
 					this.getView().getModel("localModel").getData().busyVHAccPerson = true;
 					this.getView().getModel("localModel").refresh();
 					let modelROData = this.getView().getModel("oModelAcc").getData();
 					let shipTo = this.getModel("ReferenceObjects").getProperty(selectedRefObj.getBindingContext(
 						"ReferenceObjects").getPath()).Customer;

 					let entities = {};
						entities.servicePath = Constants.getServicePath();
 					entities.entitySet = "CustomerSet";
 					entities.getEntity = shipTo;
 					entities.navigation = "toContacts";
 					entities.filter = this._prepareFilterPayloadSearchSOACP(modelROData, sBpFct);
 					entities.currentView = this.getView();
 					entities.oContext = this;
 					entities.busyIndicator = "busyVHAccPerson";

 					entities.errorMessage = this.getResourceBundle().getText("SO.ReadContactsError");
 					entities.callbackSuccess = (data) => {
 						this._handleSuccessAccountPerson(data, true);
 					};
 					this.readBaseRequest(entities);
 				}
 			}
 		},

 		_handleSuccessAccountPerson: function (data, bIsShipTo) {
 			let oControl = this.getView().byId("soAccContactPersTable");
 			oControl.rerender();
 			if (bIsShipTo) {
 				this.getView().getModel("oModelAcc").getData().soacpValueHelp = this.getView().getModel("oModelAcc").getData().soacpValueHelp.concat(
 					data.results);
 			} else {
 				this.getView().getModel("oModelAcc").getData().soacpValueHelp = data.results;
 			}
 			this.getView().getModel("oModelAcc").refresh();
 			if (data.results.length > 0) {
 				oControl.addEventDelegate({
 					onAfterRendering: () => {
 						this.getView().getModel("localModel").getData().busyVHAccPerson = false;
 						this.getView().getModel("localModel").refresh();
 					}
 				});
 			} else {
 				this.getView().getModel("localModel").getData().busyVHAccPerson = false;
 				this.getView().getModel("localModel").refresh();
 			}
 		},

 		handleSOACPItemPressed: function (oEvent) {
 			let path = oEvent.getSource().getSelectedContextPaths()[0];
 			let modelAcc = this.getView().getModel("oModelAcc");
 			let dataFromIndex = modelAcc.getProperty(path);
 			let sBpFct = oEvent.getSource().getParent().getParent().getParent().getCustomData().find(elem => elem.getKey() === "BpFct").getValue();
 			if(sBpFct === "SVR") {
 				this.getView().getModel("oModelSO").getData().SurveyRecValue = "";
 				this.getView().getModel("oModelSO").getData().SurveyRecId = "";
 				this.getView().getModel("oModelSO").refresh();
 				this.getView().getModel("oModelSO").getData().SurveyRecValue = dataFromIndex.Firstname + " " +
 					dataFromIndex.Lastname;
 				this.getView().getModel("oModelSO").getData().SurveyRecId = dataFromIndex.ContactID;
 				this.getView().getModel("oModelSO").refresh();
 				this.fnHandleDiscardSOAccContactPers();
 				this.getView().byId("SurveyRecipient").fireLiveChange();
			} else{
 				this.getView().getModel("oModelSO").getData().accountPersonValue = "";
 				this.getView().getModel("oModelSO").getData().ContactID = "";
 				this.getView().getModel("oModelSO").refresh();
 				this.getView().getModel("oModelSO").getData().accountPersonValue = dataFromIndex.Firstname + " " + dataFromIndex.Lastname;
 				this.getView().getModel("oModelSO").getData().ContactID = dataFromIndex.ContactID;
 				this.getView().getModel("oModelSO").refresh();
 				this.fnHandleDiscardSOAccContactPers();
 				this.getView().byId("AccountContactPerson").fireLiveChange();
 			}
 		},

 		fnHandleSOACPHasEmailFlag: function (oEvent) {
 			let sSelectedKey = oEvent.getParameter("selectedItem").getKey();
 			this.getView().getModel("oModelAcc").getData().HasEmail = (sSelectedKey === "yes") ? true : false;
 			this.getView().getModel("oModelAcc").refresh();
 		},

 		fnHandleDiscardSOAccContactPers: function () {
 			this.getView().getModel("oModelAcc").getData().busySO = false;
 			this.getView().getModel("oModelAcc").setData({
 				soacpValueHelp: []
 			});
 			this.getView().getModel("oModelSO").refresh();
 			this._oVHSOAccContactPers.close();
 			this._oVHSOAccContactPers.destroy();
 			this._oVHSOAccContactPers = undefined;
 		},

 		checkIfOneItemIsSelected: function (oEvent) {
 			this.soManipulation.checkIfOneItemIsSelected(oEvent, this);
 			this.soManipulation.additionalInfoValidation(this);
 		},

 		fnHandleAccContactPersonChange: function (oEvent) {
 			let oSource = this.getView().byId("AccountContactPerson");
 			this.getView().getModel("oModelSO").refresh();
 			this.SOValidation.validateSoDataStepField(this.getView().getModel("oModelSO"), this);
 		},

 		fnHandleSuveyRecipientChange: function (oEvent) {
 			let oSource = this.getView().byId("SurveyRecipient");
 			this.getView().getModel("oModelSO").refresh();
 			this.SOValidation.validateSoDataStepField(this.getView().getModel("oModelSO"), this);
 		},

 		fnHandleSendFeedbackChange: function (oEvent) {
 			this.getView().getModel("oModelSO").refresh();
 			this.SOValidation.validateSoDataStepField(this.getView().getModel("oModelSO"), this);
 		},

 		/* ==================================== Billable Box ========================================= */

 		billingOptionChanged: function (oEvt) {
 			let aCustData = oEvt.getSource().getSelectedButton().getCustomData(),
				sOption,
				bContractAllowed;

			aCustData.forEach(custData => {
				if(custData.getKey() === "Option")
					sOption = custData.getValue();
				
				if(custData.getKey() === "ContractAllowed")
					bContractAllowed = custData.getValue();
			});

 			this.setBillingOption(sOption, bContractAllowed);

 		},

 		/* ==================================== Service Hierarchy  ============================================== */

 		/**
 		 * The service hierarchy (all services from all catalogs, with all contained sessions) is loaded
 		 * from CRM and stored under "this.serviceHierarchyBaseData"
 		 */
 		_pLoadServiceHierarchyBaseDataFromCRM: function () {
 			return new Promise((res, rej) => {
 				let entities = {};
					entities.servicePath = Constants.getServicePath();
 				entities.entitySet = "ProductValueHelpSet";
 				entities.currentView = this.getView();
 				entities.oContext = this;
 				entities.filter = "";
 				entities.errorMessage = this.getResourceBundle().getText("SO.ReadSrvHierarchyError");
 				entities.callbackSuccess = (data) => {
 					data.results.sort();
 					this.serviceHierarchyBaseData = data.results;
 					res();
 				};
 				this.readBaseRequest(entities);
 			});
 		},

 		/**
 		 * all components below the selected service product are already determined from CRM customizing
 		 * also 
 		 */

		_createMaintainItem: function(oServiceDetails){
			return {
				Handle: this._newHandle(),
				ProductID: this.getView().getModel("oModelSO").getData().MainProduct,
				Description: this.getView().getModel("oModelSO").getData().MainProductText,
				ProductText: this.getView().getModel("oModelSO").getData().MainProductText,
				EditAllowed: false,
				CreateSubAllowed: false,
				DeleteAllowed: false,
				SystemRequired: oServiceDetails === null ? false : oServiceDetails.SystemRequired,
				SolmanRequired: oServiceDetails === null ? false : oServiceDetails.SolmanRequired
			}
		},

		_createComponent: function(oMainItem, oComponentDetails, oSessionDetails){
			return {
				Handle: this._newHandle(),
				ProductID: this.oSelectedServiceProduct.SessionProductId,
				ParentHandle: oMainItem.Handle,
				ParentProductID: oMainItem.ProductID,
				ComponentText: oComponentDetails.SessionDescription,
				Description: oComponentDetails.SessionDescription,
				ServiceType: oComponentDetails.ServiceType,
				RefObjRequirement: oComponentDetails.RefObjRequirement,
				CallOfDays: oComponentDetails.CallOffDays,
				QualificationId: oComponentDetails.QualificationId,
				QualificationName: oComponentDetails.QualificationName,
				EditAllowed: oComponentDetails.EditAllowed,
				CreateSubAllowed: oComponentDetails.AddAllowed,
				DeleteAllowed: false,
				SystemRequired: oSessionDetails === null ? false : oSessionDetails.SystemRequired,
				SolmanRequired: oSessionDetails === null ? false : oSessionDetails.SolmanRequired
			};
		},

		_createComponent2: function(elem, oMainItem, oSessionDetails){
			return {
				Handle: this._newHandle(),
				ProductID: elem.SessionProductId,
				ParentHandle: oMainItem.Handle,
				ParentProductID: oMainItem.ProductID,
				ComponentText: elem.SessionDescription,
				Description: elem.SessionDescription,
				ServiceType: elem.ServiceType,
				RefObjRequirement: elem.RefObjRequirement,
				CallOfDays: elem.CallOffDays,
				QualificationId: elem.QualificationId,
				QualificationName: elem.QualificationName,
				EditAllowed: elem.EditAllowed,
				CreateSubAllowed: false,
				DeleteAllowed: false,
				SystemRequired: oSessionDetails === null ? false : oSessionDetails.SystemRequired,
				SolmanRequired: oSessionDetails === null ? false : oSessionDetails.SolmanRequired
			}
		},

		_createComponentStaffing: function(aComponent, oComponent){
			return {
				Handle: this._newHandle(),
				ProductID: aComponent.ComponentID,
				ParentProductID: aComponent.ParentProductId,
				ParentHandle: oComponent.Handle,
				ComponentText: aComponent.ComponentText,
				Description: aComponent.ComponentText,
				ServiceType: aComponent.ServiceType,
				CallOfDays: aComponent.Quantity,
				QualificationId: aComponent.QualifId,
				QualificationName: aComponent.QualifText,
				EditAllowed: true,
				CreateSubAllowed: false,
				DeleteAllowed: aComponent.UsageType !== "A" ? true : false
			}
		},

		_handleSessionIdAvailable: function(aComponents, oMainItem){
			let aSOItems = [];

			let oComponentDetails = this.serviceHierarchyBaseData.find(elem => elem.SessionProductId === this._oDataToCreateSO.sessionId &&
				elem.ServiceProductId === oMainItem.ProductID && elem.StaffingProductId === "");
			const oSessionDetails = this._getSessionDetails(oComponentDetails.SessionProductId);
			let oComponent = this._createComponent(oMainItem, oComponentDetails, oSessionDetails);
			aSOItems.push(oComponent);

			aComponents.forEach( aComponent => {
				if (aComponent.ProductID === oMainItem.ProductID && aComponent.ParentProductId === this._oDataToCreateSO.sessionId &&
				   aComponent.UsageType !== "B") {
					const oComponentStaffing = this._createComponentStaffing(aComponent, oComponent);
					aSOItems.push(oComponentStaffing);
				}
			});

			return aSOItems;
		},

		_handleSessionIdUnavailable: function(aComponents, oMainItem){
			let aSOItems = [];
			let sCatalogId = "";

			this.serviceHierarchyBaseData.forEach(elem => {
				if ((sCatalogId === "" || sCatalogId === elem.CatalogId) && elem.ServiceProductId === this.getView().getModel("oModelSO").getData().MainProduct &&
					elem.BomUsageType !== "B" && elem.StaffingProductId === "") {
					sCatalogId = elem.CatalogId;
					let oSessionDetails = this._getSessionDetails(elem.SessionProductId);
					let oComponent = this._createComponent2(elem, oMainItem, oSessionDetails);
					aSOItems.push(oComponent);

					aComponents.forEach(aComponent => {
						if (aComponent.ProductID === oMainItem.ProductID && aComponent.ParentProductId === oComponent.ProductID &&
							aComponent.UsageType !== "B") {
							const oComponentStaffing = this._createComponentStaffing(aComponent, oComponent);
							aSOItems.push(oComponentStaffing);
						}
					});
				}
			});

			return aSOItems;
		},

 		collectSoRelevantServiceProductComponents: function () {
 			let aComponents = this.getModel("oModelSO").getData().aServiceProductAllComponents;
 			let aSOItems = [];
 			let oServiceDetails = this._getServiceDetails(this.getView().getModel("oModelSO").getData().MainProduct);
 			let oMainItem = this._createMaintainItem(oServiceDetails);
			
 			aSOItems.push(oMainItem);
 			this.getView().getModel("localModel").getData().SOItems = [];

			let soItems = [];

 			if (this._oDataToCreateSO && this._oDataToCreateSO.sessionId !== "") {
				soItems = this._handleSessionIdAvailable(aComponents, oMainItem);

 			} else {
				soItems = this._handleSessionIdUnavailable(aComponents, oMainItem);
 			}

			aSOItems.push(...soItems);

 			this.getView().getModel("localModel").getData().SOItems = aSOItems;
 			this.getView().getModel("localModel").refresh();

 			this.getView().getModel("oModelSO").refresh();
 			this.getView().byId("SOComponents").expandToLevel(3);
 			this.buildSOItemTree();
 		},

 		/* ==================================== Reference Objects ============================================== */

 		fnHandleAddNewRefObj: function (oEvent) {
 			this.referenceObjects.loadReferenceObjectsDialog(oEvent, this);
 		},

 		fnHandleDiscardRefObj: function (oEvent) {
 			this.referenceObjects.discardReferenceObjectsDialog(oEvent, this);
 		},

 		expandListOfRO: function () {
 			this.referenceObjects.expandListOfRO(this);
 		},
 		handleInstallationItemPressed: function (oEvent) {
 			this.referenceObjects.handleInstallationItemPressed(oEvent, this);
 		},

 		onRONavBack: function () {
 			this.referenceObjects.onRONavBack(this);
 		},

 		onSearchForReferenceObjects: function (oEvent) {
 			this.referenceObjects.searchROonGOBtn(oEvent, this);
 		},

 		onCustomerIDOrInstNoChange: function (oEvent) {
 			this.referenceObjects.onCustomerIDOrInstNoChange(oEvent, this);
 		},

 		fnHandleAddRefObj: function (oEvent) {
 			this.referenceObjects.fnHandleAddRefObj(oEvent, this);
 		},

 		resetSorting: function (oEvent) {
 			this.referenceObjects.resetSorting(oEvent, this);
 		},

 		onRefObjFiltersClear: function (oEvent) {
 			this.referenceObjects.onRefObjFiltersClear(oEvent, this);
 		},

 		/**
 		 * triggered if the combo value in the related view is changed
 		 * in case the user has selected a semantically not valid RefObj, the value state and value state text are set accordingly to error
 		 * otherwise the data from the selected RefObj is added to oModelSO and also some information, that controls the behavior of other SO fields
 		 * (the value state is evaluated by the validator, and only if it is "Error", the validator can know the field is not valid - otherwise it
 		 * just validates if the field is mandatory and not empty)
 		 * 
 		 * @param {object} oEvent - event
 		 */
 		fnHandleRefObjChange: function (oEvent) {
 			this.referenceObjects.fnHandleRefObjChangeSO(oEvent, this);
 			this.cloudRefObjects.setMainObject(this);
 			this.cloudRefObjects.buildTree(this);
 			this.SOValidation.validateSoDataStepField(this.getView().getModel("oModelSO"), this);
 		},

 		/**
 		 * Checks if a ReferenceObject is semantically valid, 
 		 * by checking if a Solution Manager is part of it, if required (by the selected product)
 		 * The actual check: SolMan is required and assigned
 		 */
 		checkRefObjValueIsValid: function () {
 			this.referenceObjects.fnValidatedRefObjectsSO(this);
 		},

 		refObjListSelectionChange: function (oEvent) {
 			this.referenceObjects.fnHandleSelectionChange(oEvent, this);
 		},

 		fnHandleSearchForItems: function (oSort) {
 			this.referenceObjects.searchROonGOBtn(null, this, oSort);
 		},

 		handleAddRefObjPersoButtonPressed: function (oEvent, oContext) {
 			this.referenceObjects.onAddRefObjPersoButtonPressed(oEvent, this);
 		},

 		handleAddRefObjSortReset: function () {
 			this.referenceObjects.onAddRefObjSortReset(this);
 		},

 		onPressSaveRefObj: function (oEvent) {
 			this._oData.formEditMode = false;
 			this._oModel.refresh();

 			let oPromiseRO = new Promise((resolveRO, rejectRO) => {
 				return this.referenceObjects._manipulateReferenceObjects(resolveRO, rejectRO, this);
 			});
 			oPromiseRO.then(() => {
 			}, (error) => {
 				let titleErrorRF = this.getResourceBundle().getText("ProjectDetails.ReferenceObject");
 				this.messageHandler.addNewMessageseInsidePopover("Reference Object", "Error", titleErrorRF, error.message, error.message);
 			});

 		},

 		/* ============================ Reference Objects - Customer ID Value Help ============================= */

 		// Renamed to allign the search of customer search with new popup - KNGMHM02-23694
 		customerIdValueHelpTriggerold: function (oEvent) {
 			this.referenceObjects.customerIdValueHelpTrigger(oEvent, this);
 		},
 		customerIdValueHelpTrigger: function (oEvent) {
 			this.getView().getModel("localModel").getData().bpSearchReturnType = "ProjectDetailCustomerIdValueHelp";
 			this.getView().getModel("localModel").refresh();
 			this.partiesInvolved.loadSearchHelpDialog("00000001", "PFCustomer");
 		},

 		searchCustomerSpecific: function (oEvent) {
 			this.referenceObjects.searchCustomerSpecific(oEvent, this);
 		},

 		// Renamed to allign the search of customer search with new popup - KNGMHM02-23694
 		handleCustomerItemPressed: function (oEvent) {
 			this.referenceObjects.handleCustomerItemPressed(oEvent, this);
 		},
 		// New Version of popup - KNGMHM02-23694
 		onVHPartnerSelect: function (oEvent) {
 			this.onVHPartnerSelectGetValues(oEvent);
 			let sPartnerID = this.getView().getModel("localModel").getData().bpSearchReturnPartnerID ? this.getView().getModel("localModel").getData()
 				.bpSearchReturnPartnerID : "";
 			let sFullName = this.getView().getModel("localModel").getData().bpSearchReturnFullName ? this.getView().getModel("localModel").getData()
 				.bpSearchReturnFullName : "";
 			let sBPSearchReturnType = this.getView().getModel("localModel").getData().bpSearchReturnType ? this.getView().getModel(
 				"localModel").getData().bpSearchReturnType : "PartiesInvolved";
 			if (sBPSearchReturnType === "PartiesInvolved") {
 				this.partiesInvolved.setNewPartner(sPartnerID, sFullName);
 			} else {
 				this.referenceObjects.handleCustomerItemPressedGenCustomerPopup(sPartnerID, this);
 				this.referenceObjects.searchROonGOBtn(oEvent, this);
 			}
 			this.partiesInvolved.closeSearchHelpDialog();
 		},

 		/* ============================ Reference Objects - Data Center Value Help ============================= */

 		dataCenterValueHelpTrigger: function (oEvent) {
 			this.referenceObjects.dataCenterValueHelpTrigger(oEvent, this);
 		},

 		searchDataCenters: function (oEvent) {
 			this.referenceObjects.searchDataCenters(oEvent, this);
 		},

 		handleDataCenterItemPressed: function (oEvent) {
 			this.referenceObjects.handleDataCenterItemPressed(oEvent, this);
 		},

 		/* ========================================== CBX Delivery ================================================ */

 		/**
 		 * user has changed the value of the CBX combo. In case the it was set to "Manually Switched to No", we have to
 		 * take care to remove the currently selected Reference Object 
 		 * Then we can call the method to setUp the CBX-combo values and editmode according to the newly selected value
 		 * @param {object} oEvent - Incoming event data
 		 */
 		handleSOCbxSelection: function (oEvent) {
 			let sSelectedKey = oEvent.getSource().getSelectedKey();
				if (sSelectedKey === Constants.getCbxCustKey().ManuallySwitchedToNo) {
 				this.getView().getModel("oModelSO").getData().selectedRefObj.IbComponent = "";
 				this.getView().getModel("oModelSO").getData().selectedRefObj.SolmanComponent = "";
 				this.getView().getModel("oModelSO").getData().refObjComboEnabled = true;
 				this.getView().getModel("oModelSO").refresh();
 				this.getView().byId("ReferenceObject").clearSelection();
 				this.getView().byId("ReferenceObject").setValue("");
 			}
 			this._setUpCbxCombo(sSelectedKey);
 		},

 		/**
 		 * after each time the SO is read from BE, adjust the Reference Object Combo depending on the CBX value that has come in
 		 * @param {object} oEvent - Incoming event data
 		 */
 		_refObjHandlingAfterCBXChangesFromBE: function (oData) {
				if (oData.CbxEnabled === Constants.getCbxCustKey().Yes) {
 				this.getView().getModel("oModelSO").getData().refObjComboEnabled = false;
 				this.getView().getModel("oModelSO").refresh();
 			}
 			this._setUpCbxCombo(oData.CbxEnabled);
 		},

 		/* ========================================== Contracts ================================================ */

		_initContractSelection: function(){
			this.SOValidation.validateSoDataStepField(this.getView().getModel("oModelSO"), this);
 			this.getView().getModel("oModelSO").getData().contractSelected = false;
 			this.getView().getModel("oModelSO").getData().contractItemsAllWithoutContingent = false;
 			this.getView().getModel("oModelSO").getData().contractItemSelectedKey = "";
 			this.getView().getModel("oModelSO").getData().contractItems = [];
 			this.getView().getModel("oModelSO").getData().newSOValid.contractItems = "None";
		},

		_handleNoContractSelected: function(){
			this.getView().getModel("oModelSO").getData().contractSelected = false;
			this.getView().getModel("oModelSO").getData().contractItems = [];
			this.getView().getModel("oModelSO").getData().newSOValid.contractItems = "None";
			this.getView().getModel("oModelSO").refresh();
			this.getView().getModel("oModelSO").getData().busyContract = false;
			this.getView().getModel("oModelSO").refresh();
			this.getView().getModel("localModel").getData().loadingDataForEditMode = false;
			this.getView().getModel("localModel").refresh();
		},

		_setWBSEnabled: function(aContracts, sContractID){

			aContracts.forEach(aContract => {
				if(aContract.ContractID === sContractID)
					this.getView().getModel("oModelSO").getData().WbsEnabled = aContract.ProcessType === "ZCTF" ? true : false;
			});
		},

 		handleSOContractSelection: function (oEvent) {
 			
			this._initContractSelection();

 			if (this.getView().byId("soContract").getValue() !== "" || this.getView().getModel("oModelSO").getData().contractSelectedKey) {
 				let sContractID = oEvent.getSource().getSelectedItem() ? oEvent.getSource().getSelectedItem().getKey() : this.getView().getModel(
 					"oModelSO").getData().contractSelectedKey;

 				this.getView().getModel("oModelSO").getData().contractSelected = true;
 				this.getView().getModel("oModelSO").refresh();
 				if (sContractID) {
 					this.soManipulation.readSOContractItems(sContractID, this);
 				} else {
 					this.soManipulation.setContractItemFromBE(this);
 					this.getView().getModel("oModelSO").getData().busyContract = false;
 					this.getView().getModel("oModelSO").refresh();
 					this.getView().getModel("localModel").getData().loadingDataForEditMode = false;
 					this.getView().getModel("localModel").refresh();
 				}
 				let aContracts = this.getView().getModel("oModelSO").getData().contracts;
				this._setWBSEnabled(aContracts, sContractID);
 				
 			} else {
				this._handleNoContractSelected();
 			}
 		},

 		handleSOContractItemSelection: function (oEvent) {
 			let oModelSO = this.getView().getModel("oModelSO");

 			if (oEvent.getParameter("value") !== "") {
 				if (oModelSO.getData().contractItems.length === 1 && !this.getView().getModel("localModel").getData().loadingDataForEditMode) {
 					oModelSO.getData().contractItemSelectedKey = oModelSO.getData().contractItems[0].ContractItemID;
 				}
 				oModelSO.refresh();
 				this._handleWorkRisk(oEvent);
 			}
 			this.SOValidation.validateSoDataStepField(oModelSO, this);
 		},

 		_handleWorkRisk: function (oEvent) {
 			let oCtx = oEvent.getSource().getSelectedItem() ? oEvent.getSource().getSelectedItem().getBindingContext("oModelSO") : null;
 			let oContractDetails = oCtx !== null ? oCtx.getModel().getProperty(oCtx.getPath()) : null;
 			if (oContractDetails !== null && oContractDetails.WorkAtRisk === "X" && this._workAtRiskVisible === false) {
 				let oContractItemID = parseInt(oContractDetails.ContractItemID, 10);
 				let oMessage = this.getResourceBundle().getText("SO.ContractWorkRisk", [oContractDetails.ContractID, oContractItemID]);
 				let oMessageDetails = this.getResourceBundle().getText("SO.ContractWorkRisk.Details");
 				let oMessageJamPage = this.getResourceBundle().getText("SO.SOG.Details.JAMPage");
					let sJamLink = Constants.getWorkRiskJAM();
 				MessageBox.warning(oMessage, {
 					details: `<p>${oMessageDetails}<a href='${sJamLink}' target='_blank' rel='noopener noreferrer'>${oMessageJamPage}</a>.`
 				});
 				this._workAtRiskVisible = true;
 			}
 		},

 		/* ====================================== Requested Delivery Date Change =============================== */

 		soRecDelDateChange: function (oEvent) {
 			if (!oEvent.getParameter("valid")) {
 				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
 				this.SOValidation.validateSoDataStepField(this.getView().getModel("oModelSO"), this);
 				if (this.getView().getModel("oModelSO").getData().reqDelRequired) {
 					this._removeContractAfterChange(oEvent);
 					this.getView().getModel("oModelSO").getData().contractVisible = false;
 					this.getView().getModel("oModelSO").refresh();
 				}
 			} else {
 				this.getView().getModel("oModelSO").getData().reqDelDateExists = !!oEvent.getSource().getValue();
 				this.getView().getModel("oModelSO").refresh();
 				this.SOValidation.validateSoDataStepField(this.getView().getModel("oModelSO"), this);
 				if (this.getView().byId("soRecDelDate").getValue() !== "") {
 					if (this.getView().getModel("oModelSO").getData().reqDelRequired) {
 						this._removeContractAfterChange(oEvent);
 						this.soManipulation._readSOContracts(this.getView().getModel("oModelSO").getData().MainProduct, this);
 					}
 				} else {
 					if (this.getView().getModel("oModelSO").getData().reqDelRequired) {
 						this._removeContractAfterChange(oEvent);
 					}
 				}
 				this.getView().getModel("oModelSO").refresh();
 				this.checkBilling();
 			}
 		},

 		_removeContractAfterChange: function (oEvent) {
 			this.getView().getModel("oModelSO").getData().contractRemovedAfterDateChange = true;

 			this.getView().getModel("oModelSO").getData().contractSelectedKey = "";
 			this.getView().getModel("oModelSO").getData().ContractID = "";
 			this.getView().getModel("oModelSO").getData().ContractText = "";
 			this.getView().getModel("oModelSO").getData().contractSelected = false;
 			this.getView().getModel("oModelSO").getData().contractsExist = false;
 			this.getView().getModel("oModelSO").getData().contracts = [];
 			this.getView().getModel("oModelSO").getData().newSOValid.contractID = "None";

 			this.getView().getModel("oModelSO").getData().contractItemSelectedKey = "";
 			this.getView().getModel("oModelSO").getData().ContractItem = "";
 			this.getView().getModel("oModelSO").getData().ContractItemText = "";
 			this.getView().getModel("oModelSO").getData().contractItems = [];
 			this.getView().getModel("oModelSO").getData().newSOValid.contractItems = "None";
 			this.getView().getModel("oModelSO").getData().validContract = false;
 			this.getView().getModel("oModelSO").refresh();

 			this.getView().byId("soContract").setValue("");
 			this.getView().byId("soContractItem").setValue("");
 		},

 		/* ================================== Go live date change ============================================== */

 		soGoLiveDateChange: function (oEvent) {
 			if (!oEvent.getParameter("valid")) {
 				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
 				this.SOValidation.validateSoDataStepField(this.getView().getModel("oModelSO"), this);
 				if (this.getView().getModel("oModelSO").getData().goLiveRequired) {
 					this._removeContractAfterChange(oEvent);
 					this.getView().getModel("oModelSO").getData().contractVisible = false;
 					this.getView().getModel("oModelSO").refresh();
 				}
 			} else {
 				this.getView().getModel("oModelSO").getData().goLiveExists = !!oEvent.getSource().getValue();
 				this.getView().getModel("oModelSO").refresh();
 				this.SOValidation.validateSoDataStepField(this.getView().getModel("oModelSO"), this);
 				if (this.getView().byId("soGoLliveDate").getValue() !== "") {
 					if (this.getView().getModel("oModelSO").getData().goLiveRequired) {
 						this._removeContractAfterChange(oEvent);
 						this.soManipulation._readSOContracts(this.getView().getModel("oModelSO").getData().MainProduct, this);
 					}
 				} else {
 					if (this.getView().getModel("oModelSO").getData().goLiveRequired) {
 						this._removeContractAfterChange(oEvent);
 					}
 				}
 				this.getView().getModel("oModelSO").refresh();
 				this.checkBilling();
 			}
 		},

 		/* ======================== First section (step 1) - Service Data section completed ==================== */

 		/**
 		 * Send SO to backend and set field ServiceProductId to display only
 		 * @param {object} oEvent triggered when the "step 2" button is pressed, after completing the first section (service data section)
 		 */
 		handleServiceDataCompleted: function (oEvent) {
 			this.getView().getModel("localModel").getData().currentStep = 2;
 			this.getView().getModel("localModel").refresh();
 		},

 		/* =================================== Section / step 2 - Service Components =========================== */

 		buildSOItemTree: function () {
 			this.soManipulation.buildSOItemsTree(this);
 		},

 		/**
 		 * Ask for qualification or effort - Moved to separate method to be able to call it for a given item (e.g. after adding a new one)
 		 * @param {object} oEvent triggered when the SO component edit button is pressed
 		 */
 		handleEditButtonPress: function (oEvent) {
 			let parentItem;
 			let oSelectedItem = this.getView().getModel("treeSO").getProperty(oEvent.getSource().getBindingContext("treeSO").getPath());
 			let aParentPath = oEvent.getSource().getBindingContext("treeSO").getPath().split("/");
 			if (aParentPath.length >= 7) {
 				let parentPathRebuild = this.removeItemFromArray(aParentPath, 2);
 				parentItem = this.getView().getModel("treeSO").getProperty(parentPathRebuild);
 			}

 			this.showEditComponentDialog(oSelectedItem, parentItem);
 		},

 		showEditComponentDialog: function (oTreeItem, parentItem) {
 			let editModel = new JSONModel({});
 			this.oMessagePopover.close();
 			this.getView().setModel(editModel, "editModel");
 			this.initialComponentData = JSON.parse(JSON.stringify(oTreeItem));
 			this.initialComponentData.StartDate = this._setDefaultDate(this.initialComponentData.StartDate) === null ? null : new Date(this
 				._setDefaultDate(
 					this.initialComponentData.StartDate));
 			this.initialComponentData.EndDate = this._setDefaultDate(this.initialComponentData.EndDate) === null ? null : new Date(this._setDefaultDate(
 				this.initialComponentData.EndDate));

 			if (parentItem !== undefined && parentItem !== null) {
 				this.initialComponentData.minDate = parentItem.StartDate;
 				this.initialComponentData.maxDate = parentItem.EndDate;
 			} else {
 				this.initialComponentData.minDate = new Date(this._setDefaultDate(this.initialComponentData.minDate));
 				this.initialComponentData.minDate.setMonth(this.initialComponentData.minDate.getMonth() - 12);
 				this.initialComponentData.maxDate = new Date(this._setDefaultDate(this.initialComponentData.maxDate));
 			}
 			editModel.setData(this.initialComponentData);
 			editModel.getData().QualificationState = "None";
 			editModel.getData().StartDateState = "None";
 			editModel.getData().EndDateState = "None";
 			editModel.getData().LocationState = "None";
 			editModel.getData().CallOfDaysState = "None";
 			editModel.getData().TimeZone = this.getView().getModel("oModelSO").getData().TimeZone;
 			editModel.getData().RefObjText = this.getView().getModel("oModelSO").getData().RefObjText;
 			this._openEditServiceComponentDialog();
 		},

 		_openEditServiceComponentDialog: function () {
 			if (!this._oDialogEditService) {
 				try {
 					Fragment.load({
 						id: this.getView().getId(),
 						name: "com.sap.ui.hep.view.ServiceOrder.fragment.ServiceComponentEdit",
 						controller: this
 					}).then(oDialog => {
 						this._oDialogEditService = oDialog;
 						this._oDialogEditService.setModel(this.getModel("i18n"), "i18n");
 						this._oDialogEditService.setModel(this.getView().getModel("localModel"));
 						this._oDialogEditService.setModel(this.getView().getModel("editModel"), "editModel");
 						this.getView().addDependent(this._oDialogEditService);
 						syncStyleClass(this.getView().getController().getOwnerComponent().getContentDensityClass(),
 							this.getView(), this._oDialogEditService);
 						this._oDialogEditService.open();
 						this.getView().byId("qualdEDit").setFilterFunction(function (sTerm, oItem) {
 							return oItem.getText().match(new RegExp(sTerm, "i")) || oItem.getKey().match(new RegExp(sTerm, "i"));
 						});
 					});
 				} catch (oError) {
 					if (oError.statusCode === 503) {
 						let oView = this.getView();
 						let params = {
 							currentView: oView
 						};
 						this.handleSessionTimeout(params, this);
 					}
 				}
 			} else {
 				this._oDialogEditService.open();
 			}
 		},

 		_setDefaultDate: function (dDate) {
 			let sDefaultDate = null;
 			if (!dDate || dDate === null) {
 				if (this.getView().getModel("oModelSO").getData().goLiveRequired === true) {
 					sDefaultDate = this.getView().getModel("oModelSO").getData().GoLiveDate;
 				} else {
 					sDefaultDate = this.getView().getModel("oModelSO").getData().RecDelDate;
 				}
 			} else {
 				sDefaultDate = dDate;
 			}
 			return sDefaultDate;
 		},

 		_getTreeItemByGUID: function (sItemGUID) {
 			let oItem = {};
 			if (!this.getView().getModel("treeSO").getData().itemsSO) {
 				return true;
 			}
 			this.getView().getModel("treeSO").getData().itemsSO.forEach((item, index) => {
 				if (sItemGUID === item.ItemGUID) {
 					oItem = item;
 				} else {
 					let aChildren = this._getTreeChildren(item);
 					if (aChildren) {
 						aChildren.forEach((subItem, subIndex) => {
 							if (sItemGUID === subItem.ItemGUID) {
 								oItem = subItem;
 							}
 						});
 					}
 				}
 			});
 			return oItem;
 		},

 		_getTreeChildren: function (oItem) {
 			let aItems = oItem.itemsSO;
 			aItems.forEach((item, index) => {
 				aItems.push.apply(aItems, this._getTreeChildren(item));
 			});
 			return aItems;
 		},

 		fnHandleDiscardeditSoItems: function () {
 			this._oDialogEditService.close();
 			this._oDialogEditService.destroy();
 			this._oDialogEditService = undefined;
 			this.getView().getModel("editModel").setData({});
 			this.getView().getModel("editModel").refresh();
 		},
 		/**
 		 * First, validate the SO component edit form (if all required fields have data) and then proceed to saving
 		 */
 		fnHandleSaveSoItems: function () {
 			let editModel = this.getView().getModel("editModel").getData();
 			this.oMessagePopover.close();
 			if (this.validateEditSC() === true) {
 				this.getView().getModel("localModel").refresh();
 				let entities = {};
 				let SoGUID = this.getView().getModel("oModelSO").getData().SoGUID;
					entities.servicePath = Constants.getServicePath();
 				entities.entitySet = "ServiceOrderItemSet";
 				entities.getEntity = editModel.ItemGUID;
 				entities.isGuid = true;
 				entities.currentView = this.getView();
 				entities.oContext = this;
 				entities.merge = false;
 				entities.errorMessage = this.getResourceBundle().getText("SO.UpdateSOItemsError");
 				entities.aUrlParameters = [
 					["CurrentStep=" + (this.getView().getModel("localModel").getData().currentStep ? this.getView().getModel("localModel").getData()
 						.currentStep.toString() : "").toString()]
 				];

 				let aItems = this.getView().getModel("localModel").getData().SOItems;
 				this.getView().getModel("localModel").getData().SOItems = [];
 				aItems.forEach(item => {
 					let oTempItem = item;
 					if (item.ItemGUID === editModel.ItemGUID && item.Handle === editModel.Handle) {
 						oTempItem.QualificationId = editModel.QualificationId;
 						oTempItem.CallOfDays = editModel.CallOfDays;
 						oTempItem.StartDate = editModel.StartDate;
 						oTempItem.EndDate = editModel.EndDate;
 					}
 					this.getView().getModel("localModel").getData().SOItems.push(oTempItem);
 				});

 				entities.data = this._createPayloadUpdateSCItem();
 				if (parseInt(entities.data.Handle, 10) > 0) {
 					if (this.bEditNewItem) {
 						this.bEditNewItem = false;
 						this.soManipulation.createItemUI(entities.data, SoGUID, this);
 						this.checkRefObjValueIsValid();
 					}
 				} else {
 					entities.updateMethod = "PUT";
 					this.updateBaseRequestBatch(entities);
 				}
 				this.buildSOItemTree();
 				this.fnHandleDiscardeditSoItems();
 			}
 		},

 		_newHandle: function () {
 			if (!this.handle) {
 				this.handle = 0;
 			}
 			this.handle++;
 			let sHandle = this.handle.toString();
 			while (sHandle.length < 10) {
 				sHandle = "0" + sHandle;
 			}
 			return sHandle;
 		},

		_createPayLoad: function(editModel, bEditAllowed, bAddAllowed, bDeleteAllowed){
			return {
				"HeaderGuid": this.getView().getModel("oModelSO").getData().SoGUID,
				"Handle": editModel.Handle,
				"ParentHandle": editModel.ParentHandle,
				"ProjectID": this._idProject,
				"ServiceType": editModel.ServiceType,
				"EditAllowed": bEditAllowed,
				"CreateSubAllowed": bAddAllowed,
				"DeleteAllowed": bDeleteAllowed,
				"ProjectItemKind": null,
				"ServiceorderID": this.getView().getModel("oModelSO").getData().SoID,
				"Description": editModel.Description,
				"ItemNo": editModel.ItemNo,
				"ItemGUID": editModel.ItemGUID,
				"ParentNo": null,
				"ParentGUID": editModel.ParentGUID,
				"ItemType": null,
				"StartDate": editModel.StartDate,
				"EndDate": editModel.EndDate,
				"ContractID": null,
				"ContractName": null,
				"ContractItemID": null,
				"ContractItemName": null,
				"ProductID": editModel.ProductID,
				"ProductText": editModel.ComponentText,
				"CallOfDays": editModel.CallOfDays.toString(),
				"ConsultantID": editModel.ConsultantID === undefined ? null : editModel.ConsultantID,
				"ConsultantText": editModel.ConsultantName,
				"Status": editModel.StatusKey,
				"StatusText": editModel.Status,
				"RatingID": null,
				"UsageType": null,
				"RatingText": null,
				"QualificationId": editModel.QualificationId,
				"SolmanRequired": editModel.SolmanRequired,
				"SystemRequired": editModel.SystemRequired
			}
		},

 		_createPayloadUpdateSCItem: function () {
 			let editModel = this.getView().getModel("editModel").getData();

 			let bAddAllowed = false;
 			let bEditAllowed = true;
 			let bDeleteAllowed = true;

 			if (this.getView().getModel("oModelAdd")) {
 				let oParent = this.getView().getModel("oModelAdd").getData().parentOfAdded;
 				if (oParent) {
 					let oModelSO = this.getView().getModel("oModelSO").getData();
 					let sSessionProductID = "";
 					let sStaffingProductID = "";
 					if (oParent.ProductID === oModelSO.MainProduct) {
 						sSessionProductID = editModel.ProductID;
 					} else {
 						sSessionProductID = oParent.ProductID;
 						sStaffingProductID = editModel.ProductID;
 					}
 					let oComponentDetails = this.serviceHierarchyBaseData.find(elem => elem.ServiceProductId === oModelSO.MainProduct &&
 						elem.SessionProductId === sSessionProductID && elem.StaffingProductId === sStaffingProductID);
 					if (oComponentDetails) {
 						bAddAllowed = oComponentDetails.AddAllowed;
 						bEditAllowed = oComponentDetails.EditAllowed;
 						bDeleteAllowed = oComponentDetails.DeleteAllowed;
 					}
 				} else {
 					bAddAllowed = editModel.CreateSubAllowed;
 					bEditAllowed = editModel.EditAllowed;
 					bDeleteAllowed = editModel.DeleteAllowed;
 				}
 				this.getView().getModel("oModelAdd").setData({});
 			} else {
 				bAddAllowed = editModel.CreateSubAllowed;
 				bEditAllowed = editModel.EditAllowed;
 				bDeleteAllowed = editModel.DeleteAllowed;
 			}
 			let payload = this._createPayLoad(editModel, bAddAllowed, bEditAllowed, bDeleteAllowed);
 			return payload;
 		},

 		handleAddButtonPress: function (oEvent) {
 			let entities = {};
 			this.oMessagePopover.close();
 			let oBindingcxt = oEvent.getSource().getBindingContext("treeSO");
 			let prodIdSelected = this.getView().getModel("treeSO").getProperty(oBindingcxt.getPath()).ProductID;
 			let sMainProductID = this.getView().getModel("oModelSO").getData().MainProduct;
 			let addModel = new JSONModel({});
 			this.getView().setModel(addModel, "oModelAdd");
 			this.getView().getModel("oModelAdd").getData().parentOfAdded = null;
 			this.getView().getModel("oModelAdd").getData().parentOfAdded = this.getView().getModel("treeSO").getProperty(oBindingcxt.getPath());
 			this.getView().getModel("oModelAdd").refresh();

				entities.servicePath = Constants.getServicePath();
 			entities.entitySet = "ProductSet('" + sMainProductID + "')";
 			entities.expand = "toProductComponents";
 			entities.currentView = this.getView();
 			entities.oContext = this;
 			entities.errorMessage = this.getResourceBundle().getText("SO.AddSOItemsError");
 			entities.callbackSuccess = (data) => {
 				let aSubComp = [];
 				data.toProductComponents.results.forEach((component, index) => {
 					// Avoid duplicates (ITD 8006882827)
 					if (component.ParentProductId === prodIdSelected && !aSubComp.find(elem => elem.ComponentID === component.ComponentID)) {
 						aSubComp.push(component);
 					}
 				});
 				this._showOptionalComponents(aSubComp);
 			};
 			this.readBaseRequest(entities);
 		},

 		_showOptionalComponents: function (data) {
 			let addModel = this.getView().getModel("oModelAdd");
 			addModel.setData({
 					results: data
 				},
 				addModel.getData().parentOfAdded);
 			addModel.refresh();
 			this._addDialogSOSubItems();
 		},

 		_addDialogSOSubItems: function () {
 			if (!this._oDialogAddSubItem) {
 				try {
 					Fragment.load({
 						id: this.getView().getId(),
 						name: "com.sap.ui.hep.view.ServiceOrder.fragment.ServiceComponentAdd",
 						controller: this
 					}).then((oDialog) => {
 						this._oDialogAddSubItem = oDialog;
 						this._oDialogAddSubItem.setModel(this.getModel("i18n"), "i18n");
 						this._oDialogAddSubItem.setModel(this.getView().getModel("localModel"));
 						this._oDialogAddSubItem.setModel(this.getView().getModel("oModelAdd"), "oModelAdd");
 						this.getView().addDependent(this._oDialogAddSubItem);
 						syncStyleClass(this.getView().getController().getOwnerComponent().getContentDensityClass(),
 							this.getView(), this._oDialogAddSubItem);
 						this._oDialogAddSubItem.open();
 					});
 				} catch (oError) {
 					if (oError.statusCode === 503) {
 						let oView = this.getView();
 						let params = {
 							currentView: oView
 						};
 						this.handleSessionTimeout(params, this);
 					}
 				}
 			} else {
 				this._oDialogAddSubItem.open();
 			}
 		},

 		onCloseDialog: function () {
 			this._oDialogAddSubItem.close();
 		},

 		fnHandleDiscardAddSoItems: function () {
 			this._oDialogAddSubItem.close();
 			this._oDialogAddSubItem.destroy();
 			this._oDialogAddSubItem = undefined;
 		},

 		handleSOSubItemmPressed: function () {
 			this._oData.addSubItemButton = true;
 			this._oModel.refresh();
 		},

 		fnHandleSaveSubItems: function () {
 			this.getView().getModel("localModel");
 			let oBindingCxt = this.getView().byId("soAddSubItemsTable").getSelectedItem().getBindingContext("oModelAdd");
 			let oPath = oBindingCxt.getPath();
 			let oModel = oBindingCxt.getModel();
 			let dataSelected = oModel.getProperty(oPath);

 			this._oDialogAddSubItem.close();
 			this._oDialogAddSubItem.destroy();
 			this._oDialogAddSubItem = undefined;

 			if (dataSelected !== null) {
 				let parent = oModel.getData().parentOfAdded;
 				let SoGUID = this.getView().getModel("oModelSO").getData().SoGUID;
 				let oSessionDetails = this._getSessionDetails(dataSelected.ComponentID);
 				let oComponent = {
 					HeaderGuid: SoGUID,
 					Handle: this._newHandle(),
 					ProductID: dataSelected.ComponentID,
 					Description: dataSelected.ComponentText,
 					CallOfDays: dataSelected.Quantity,
 					ParentGUID: parent.ItemGUID,
 					ParentHandle: parent.Handle,
 					SystemRequired: oSessionDetails === null ? false : oSessionDetails.SystemRequired,
 					SolmanRequired: oSessionDetails === null ? false : oSessionDetails.SolmanRequired
 				};
 				this.bEditNewItem = true;
 				this.showEditComponentDialog(oComponent);
 			}
 		},

 		_getSessionDetails: function (sSessionProductID) {
 			let oSessionDetails = this.serviceHierarchyBaseData.find(session => session.ServiceProductId === this.getModel("oModelSO").getData()
 				.MainProduct &&
 				session.SessionProductId === sSessionProductID);
 			if (!oSessionDetails) return null;
 			switch (oSessionDetails.RefObjRequirement) {
 			case "1":
 				oSessionDetails.SystemRequired = true;
 				oSessionDetails.SolmanRequired = false;
 				break;
 			case "2":
 				oSessionDetails.SystemRequired = false;
 				oSessionDetails.SolmanRequired = true;
 				break;
 			case "3":
 				oSessionDetails.SystemRequired = true;
 				oSessionDetails.SolmanRequired = true;
 				break;
 			default:
 				oSessionDetails.SystemRequired = false;
 				oSessionDetails.SolmanRequired = false;
 				break;
 			}
 			return oSessionDetails;
 		},

 		_getServiceDetails: function (sServiceProductID) {
 			let oServiceDetails = this.serviceHierarchyBaseData.find(service => service.ServiceProductId === sServiceProductID);
 			if (!oServiceDetails) return null;
 			switch (oServiceDetails.RefObjRequirement) {
 			case "1":
 				oServiceDetails.SystemRequired = true;
 				oServiceDetails.SolmanRequired = false;
 				break;
 			case "2":
 				oServiceDetails.SystemRequired = false;
 				oServiceDetails.SolmanRequired = true;
 				break;
 			case "3":
 				oServiceDetails.SystemRequired = true;
 				oServiceDetails.SolmanRequired = true;
 				break;
 			default:
 				oServiceDetails.SystemRequired = false;
 				oServiceDetails.SolmanRequired = false;
 				break;
 			}
 			return oServiceDetails;
 		},

 		/**
 		 * Whenever a property from the component changes its property in edit mode, 
 		 * we determine if, in case of a mandatory property, the field is valid
 		 * @param {object} oEvent when the field is changed
 		 */
 		handleComponentPropertyLivechange: function (oEvent) {
 			let oSource = oEvent.getSource(),
 				validator = new Validator(),
 				oFieldValue = validator.getFieldValue(oSource),
 				oModelEditData = this.getView().getModel("editModel").getData(),
 				sValueStatePropertyName = oSource.getBindingInfo("valueState").binding.sPath.split("/")[1];

 			if (oFieldValue) {
 				oModelEditData[sValueStatePropertyName] = "None";
 			} else if (oSource.required === true) {
 				oModelEditData[sValueStatePropertyName] = "Error";
 			}

 				if (oSource.getBindingInfo("value") 
					&& oSource.getBindingInfo("value").hasOwnProperty("parts") 
					&& oSource.getBindingInfo("value").parts.length === 1 
					&& oSource.getBindingInfo("value").parts[0].type) {
 						const oFormatter = oSource.getBindingInfo("value").parts[0].type.oFormatOptions;
 						if (!$.isEmptyObject(oFormatter)) {
 							const sValuePropertyName = oSource.getBindingInfo("value").parts[0].path.split("/")[1];
 							oModelEditData[sValuePropertyName] = oFieldValue ? oFieldValue : null;

 						}
 				}
 			if (oSource.getId().toLowerCase().indexOf("enddate") > 0) {
 				let oStartDate = this.getView().byId("startDateSCItem");
 				oModelEditData.maxDate = new Date(oFieldValue);
 				if (!oStartDate.getDateValue() && oFieldValue) {
 					this.getView().byId("startDateSCItem").setValue(oFieldValue);
 					let sStartDateValueStatePropertyName = oStartDate.getBindingInfo("valueState").binding.sPath.split("/")[1];
 					oModelEditData[sStartDateValueStatePropertyName] = "None";
 				}
 			}
 			if (oSource.getId().toLowerCase().indexOf("calloffdays") > 0) {
 				oSource.setValue(oSource.getValue().replace(",", "."));
 			}
 			this._createNewDateForSpecificFields(oModelEditData);
 			this._validateSDEDDates(oModelEditData, oModelEditData.StartDate, oModelEditData.EndDate);
 			this.getView().getModel("editModel").refresh();
 		},

 		/**
 		 * Check if the required fields have data
 		 * @param {object} oEvent from the save button
 		 * @returns {boolean} If the component is valid and ready to be saved
 		 */
 		validateEditSC: function (oEvent) {
 			let bDialogValid = true;
 			let oModelEdit = this.getView().getModel("editModel").getData();
 			this._createNewDateForSpecificFields(oModelEdit);
 			let aMandFields = ["StartDate", "EndDate", "CallOfDays"];
 			aMandFields.forEach((item, index) => {
 				if (!oModelEdit[item]) {
 					oModelEdit[item + "State"] = "Error";
 					bDialogValid = false;
 				}
 			});
 			if (!this._validateSDEDDates(oModelEdit, oModelEdit.StartDate, oModelEdit.EndDate)) {
 				bDialogValid = false;
 			}
 			if (!oModelEdit.CallOfDays || oModelEdit.CallOfDays === "") {
 				bDialogValid = false;
 			}
 			this.getView().getModel("editModel").refresh();
 			return bDialogValid;
 		},

 		_createNewDateForSpecificFields: function (oModel) {
 			let aDatesToBeConvert = ["StartDate", "EndDate", "minDate", "maxDate"];
 			aDatesToBeConvert.forEach(item => {
 				oModel[item] = oModel[item] ? new Date(oModel[item]) : new Date(new Date().setHours(0, 0, 0, 0));
 			});
 		},
 		_validateSDEDDates: function (oModel, dStart, dEnd) {

 			let bValidDates = true;
 			if (dStart > 0 && dEnd > 0 && this.dates.checkGreaterDate(dStart, dEnd)) {
 				oModel.StartDateState = "Error";
 				oModel.EndDateState = "Error";
 				bValidDates = false;
 			} else {
 				oModel.StartDateState = "None";
 				oModel.EndDateState = "None";
 			}
 			return bValidDates;
 		},

 		/**
 		 * Delete Service Order Item + build item tree
 		 * @param {object} oEvent triggered when the SO component delete button is pressed
 		 */
 		handleDeleteButtonPress: function (oEvent) {
 			this.oMessagePopover.close();
 			let path = oEvent.getSource().getBindingContext("treeSO").getPath();
 			let model = oEvent.getSource().getBindingContext("treeSO").getModel();
 			let dataToBeDeleted = model.getProperty(path);
 			let oSOData = this.soManipulation._createPaylodSODraftAndUpdate(this, false, "Draft");
 			let oComponent = {
 				Handle: dataToBeDeleted.Handle,
 				ItemGUID: dataToBeDeleted.ItemGUID,
 				ItemNo: dataToBeDeleted.ItemNo
 			};
 			this.soManipulation.deleteItemUI(oComponent, oSOData, this);
 			this.getView().getModel("treeSO").refresh();
 			this.checkRefObjValueIsValid();
 		},

 		_readQualification: function () {
 			this._oData.busyQualifications = true;
 			this._oModel.refresh();
 			let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = Constants.getEntities().DropDownEntity;
 			entities.filter = "(Type eq 'Qualification')";
 			entities.currentView = this.getView();
 			entities.oContext = this;
 			entities.errorMessage = this.getResourceBundle().getText("SO.ReadQualError");
 			entities.callbackSuccess = (data) => {
 				this.handleSuccesQualification(data);
 			};
 			this.readBaseRequest(entities);
 		},

 		handleSuccesQualification: function (data) {
 			this.getView().getModel("qualificationModel").setSizeLimit(500);
 			this.getView().getModel("qualificationModel").setData(data);
 			this.getView().getModel("qualificationModel").refresh();
 			this._oData.busyQualifications = false;
 			this._oModel.refresh();
 		},

 		/* ============================= Section / step 3: Service Questionnaire =============================== */

 		handleServiceComponentsCompleted: function (oEvent) {
 			this.getModel("localModel").getData().currentStep = 3;
 			this.getModel("localModel").refresh();
 			if (this._idServiceOrder && !this._displayMode && !this.getModel("localModel").getData().SOEdit) {
 				this.readQuestionnaire();
 			}
 		},


 		// ============================= Responsible VH =============================

 		_generateVHresponsibleFilterParams: function () {
 			let sFields = " and Fields eq '[",
 				aFilterProperties = ["userID", "firstName", "lastName"];

 			aFilterProperties.forEach((oFilterProperty, iIndex) => {
 				let sValue = this.getView().getModel("oModelResponsibleVH").getData()[oFilterProperty];
 				if (sValue !== undefined && sValue !== "") {
 					let sPropertyName = oFilterProperty.charAt(0).toUpperCase() + oFilterProperty.slice(1);
 					sFields += "{'name'\: '" + sPropertyName + "', 'value'\: '" + sValue + "'}";
 				}
 			});
 			sFields += "]'";
 			return sFields;
 		},

 		filterResponsibleSelectionList: function (oEvent) {
 			let aResponsibleList = this.getView().getModel("oModelResponsibleVH").getData().responsibleAll,
 				aFilterProperties = ["userID", "firstName", "lastName"];

 			aFilterProperties.forEach((oFilterProperty, iIndex) => {
 				let sValue = this.getView().getModel("oModelResponsibleVH").getData()[oFilterProperty];
 				if (sValue !== undefined && sValue !== "") {
 					let sPropertyName = oFilterProperty;
 					if (oFilterProperty !== "userID") {
 						sPropertyName = oFilterProperty.toLowerCase();
 					}
 					sPropertyName = sPropertyName.charAt(0).toUpperCase() + sPropertyName.slice(1);
 					aResponsibleList = aResponsibleList.filter(item =>
 						item[sPropertyName].toLowerCase().indexOf(sValue.toLowerCase()) > -1);
 				}
 			});
 			this.getView().getModel("oModelResponsibleVH").getData().responsible = aResponsibleList;
 			this.getView().getModel("oModelResponsibleVH").getData().NumberOfResponsible = this.getView().getModel("oModelResponsibleVH").getData()
 				.responsible
 				.length;
 			this.getView().getModel("oModelResponsibleVH").refresh();
 		},

 		loadResponsibleSelectionList: function () {
 			let entities = {};
 			this._oData.busyVHResponsible = true;
 			this._oModel.refresh();
				entities.servicePath = Constants.getServicePath();
 			entities.entitySet = "ValueHelpSet";
 			entities.filter =
 				"(Entity eq 'SAP_CONTACT_TEXT'" + this._generateVHresponsibleFilterParams() + ")";
 			entities.oContext = this;
 			entities.currentView = this.getView();
 			entities.busyIndicator = "busyVHResponsible";
 			entities.callbackSuccess = (oData) => {
 				this._oData.busyVHResponsible = false;
 				this._oModel.refresh();
 				this._handleSuccessLoadResponsibleSelectionList(oData);
 			};
 			this.readBaseRequest(entities);
 		},

 		_handleSuccessLoadResponsibleSelectionList: function (oData) {
 			this.getView().getModel("oModelResponsibleVH").getData().responsibleAll = JSON.parse(oData.results[0].Results);
 			this.getView().getModel("oModelResponsibleVH").getData().responsible = JSON.parse(oData.results[0].Results);
 			this.getView().getModel("oModelResponsibleVH").getData().NumberOfResponsible = this.getView().getModel("oModelResponsibleVH").getData()
 				.responsible.length;
 			this.getView().getModel("oModelResponsibleVH").refresh();

 		},

 		handleResponsibleItemPressed: function (oEvent) {
 			let path = oEvent.getSource().getSelectedContextPaths()[0];
 			let modelAcc = this.getView().getModel("oModelResponsibleVH");
 			let dataFromIndex = modelAcc.getProperty(path);
 			this.getView().getModel("oSOGroupModel").getData().createdBy = dataFromIndex.UserID;
 			this.getView().getModel("oSOGroupModel").refresh();
 			let oUserIDInput = this.getView().byId("createdBySOG");
 			oUserIDInput.fireSubmit();
 			this.onSOGNavBack();
 		},

 		fnHandleUserIDLiveChange: function (oEvent) {
 			let sUserValue = oEvent.getParameters().value;
 			let isValidUser = this._validUserSOGSearch(sUserValue);
 			this.getView().getModel("oModelResponsibleVH").getData().valueStateUserId = isValidUser || sUserValue.trim().length === 0 ?
 				"None" :
 				"Error";
 			this.getView().getModel("oModelResponsibleVH").refresh();
 		}
 	});
 });
