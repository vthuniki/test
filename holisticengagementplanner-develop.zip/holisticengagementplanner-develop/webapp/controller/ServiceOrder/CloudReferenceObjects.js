sap.ui.define([
	"com/sap/ui/hep/reuse/Constants",
	"com/sap/ui/hep/reuse/BaseRequest",
	"sap/ui/model/json/JSONModel"

], function (Constants, BaseRequest, JSONModel) {
	"use strict";

	return {

		handle: 0,
		oModel: new JSONModel(),


		initialize: function () {
			this.oModel.setData("");
			this.oModel.refresh();
		},

		setMainObject: function (oContext) {
			let oRefObject = oContext.getView().getModel("oModelSO").getData().selectedRefObj;
			if (oRefObject.DeployMod !== "CLOUD") {
				this.initialize();
				return;
			}
			this.oModel.setData([{
				ObjectID: oContext.getModel("oModelSO").getData().SoID,
				ProductID: "S_0" + oRefObject.SystemNumber,
				ProductText: oRefObject.SystemDescription,
				CarSystemRole: oRefObject.SystemRoleText,
				MainObject: "X",
				IbComponent: oRefObject.IbComponent // Important already at this stage as it is needed to build up the tree correctly
			}]);
			this.oModel.refresh();
		},

		pReadByOrderID: function (oContext) {
			return new Promise((resolve, reject) => {
				let oRequest = {};
				oRequest.servicePath = Constants.getServicePath();
				oRequest.entitySet = Constants.getEntities().CloudReferenceObjectSet;
				oRequest.filter = `ObjectID eq '${oContext.getModel("oModelSO").getData().SoID}'`;
				oRequest.oContext = oContext;
				oRequest.currentView = oContext.getView();
				oRequest.callbackSuccess = (oData) => {
					this.oModel.setData(oData.results);
					this.oModel.refresh();
					resolve();
				};
				BaseRequest.handleRead(oRequest);
			});
		},

		pGetCloudModuleVH: function (oContext, sTenantid) {
			return new Promise((resolve, reject) => {
				let oRequest = {};
				oRequest.servicePath = Constants.getServicePath();
				oRequest.entitySet = Constants.getEntities().CloudModuleVHSet;
				oRequest.filter = `Tenantid eq '${sTenantid}' and Serviceproductid eq '${oContext.getModel("oModelSO").getData().MainProduct}'`;
				oRequest.oContext = oContext;
				oRequest.currentView = oContext.getView();
				oRequest.callbackSuccess = (oData) => {
					resolve(oData);
				};
				BaseRequest.handleRead(oRequest);
			});
		},

		pGetRelatedTenantVH: function (oContext) {
			return new Promise((resolve, reject) => {
				let oMainTenant = this.oModel.getData().find(elem => elem.MainObject === "X");
				let oRequest = {};
				oRequest.servicePath = Constants.getServicePath();
				oRequest.entitySet = Constants.getEntities().RelatedTenantVHSet;
				oRequest.filter = "Tenantid eq '" + oMainTenant.ProductID + "'";
				oRequest.oContext = oContext;
				oRequest.currentView = oContext.getView();
				oRequest.callbackSuccess = (oData) => {
					for (let oResult of oData.results) {
						if (this.oModel.getData().find(elem => elem.ProductID === oResult.Addtenantid)) {
							oResult.AlreadyAdded = true;
						}
					}
					resolve(oData);
				};
				BaseRequest.handleRead(oRequest);
			});
		},

		pDeleteObject: function (oContext, sProductID, sParentComponent) {
			return new Promise((resolve, reject) => {
				let oObjectDelete = {};
				if (sParentComponent && sParentComponent !== "") {
					oObjectDelete = this.oModel.getData().find(elem => elem.ProductID === sProductID && elem.ParentComponent ===
						sParentComponent);
				} else {
					oObjectDelete = this.oModel.getData().find(elem => elem.ProductID === sProductID);
				}
				let aDataNew = [];
				for (let oObject of this.oModel.getData()) {
					if (oObject.ProductID === oObjectDelete.ProductID && oObject.ParentComponent ===
						oObjectDelete.ParentComponent) {
						// Delete in BE as well
						this._deleteObjectBE(oContext, oObject);
						continue;
					}
					aDataNew.push(oObject);
				}
				this.oModel.setData(aDataNew);
				this.oModel.refresh();
				resolve();
			});
		},

		_deleteObjectBE: function (oContext, oObject) {
			let oRequest = {
				servicePath: this.constants.getServicePath(),
				entitySet: Constants.getEntities().CloudReferenceObjectSet,
				oContext: oContext
			};
			if (oObject.GuidObject && oObject.GuidObject !== "" && oData.GuidObject !==
				"undefined") {
				oRequest.getEntityMultiple = `ObjectID='${oContext.getModel("oModelSO").getData().SoID}',GuidObject=guid'${oObject.GuidObject}',ParentComponent='${oObject.ParentComponent}'`;
				oContext.deleteBaseRequestBatch(oRequest);
			}

		},

		pAddTenant: function (oNewTenant, oContext) {
			let oRefObject = this.oModel.getData().find(elem => elem.ProductID === oNewTenant.tenantID);
			if (oRefObject) {
				return;
			}
			return new Promise((resolve, reject) => {
				// Add to UI context
				let oNewCloudRefObject = {
					ObjectID: oContext.getModel("oModelSO").getData().SoID,
					ProductID: oNewTenant.tenantID,
					ProductText: oNewTenant.tenantDescription,
					CarSystemRole: oNewTenant.systemRole,
					IbComponent: oNewTenant.ibComponent // Important already at this stage as it is needed to build up the tree correctly
				};
				this.oModel.getData().push(oNewCloudRefObject);
				this.oModel.refresh();

				// Create in BE via batch request
				let oRequest = {};
				oRequest.servicePath = Constants.getServicePath();
				oRequest.entitySet = Constants.getEntities().CloudReferenceObjectSet;
				oRequest.data = {
					ObjectID: oNewCloudRefObject.ObjectID,
					IbComponent: oNewCloudRefObject.IbComponent
				};
				oRequest.oContext = oContext;
				oContext.createBaseRequestBatch(oRequest);

				resolve();
			});
		},

		pAddModule: function (oNewModule, oContext) {
			let oRefObject = this.oModel.getData().find(elem => elem.ProductID === oNewModule.ProductID && elem.IbComponent === oNewModule.ParentComponent);
			if (oRefObject) {
				return;
			}
			return new Promise((resolve, reject) => {
				// Add to UI context
				let oNewCloudRefObject = {
					ObjectID: oContext.getModel("oModelSO").getData().SoID,
					ProductID: oNewModule.ProductID,
					ProductText: oNewModule.ProductDescription,
					ParentComponent: oNewModule.ParentComponent
				};
				this.oModel.getData().push(oNewCloudRefObject);
				this.oModel.refresh();

				// Create in BE via batch request
				let oRequest = {};
				oRequest.servicePath = Constants.getServicePath();
				oRequest.entitySet = Constants.getEntities().CloudReferenceObjectSet;
				oRequest.data = {
					ObjectID: oNewCloudRefObject.ObjectID,
					ProductID: oNewCloudRefObject.ProductID,
					ParentComponent: oNewCloudRefObject.ParentComponent
				};
				oRequest.oContext = oContext;
				oContext.createBaseRequestBatch(oRequest);

				resolve();
			});

		},

		buildTree: function (oContext) {

			let aTenant = oContext.getModel("cloudRefObj").getData();

			if (!oContext.getView().getModel("cloudRefObjTree")) {
				oContext.getView().setModel(new JSONModel({}), "cloudRefObjTree");
			}
			let oTreeModel = oContext.getView().getModel("cloudRefObjTree");
			oTreeModel.setData({
				tenants: []
			});
			for (let oTenant of aTenant) {
				if (oTenant.IbComponent === "0" || oTenant.IbComponent === "" || !oTenant.IbComponent) {
					continue;
				}
				this._addTenantToTree(oContext, oTenant);
			}
			// Main Object on top
			oTreeModel.getData().tenants.sort(function (a, b) {
				if (a.MainObject === "X") {
					return -1;
				} else {
					return 0;
				}
			});
			oTreeModel.refresh();
		},

		_addTenantToTree: function (oContext, oTenant) {
			let aModule = oContext.getModel("cloudRefObj").getData();
			let oTreeModel = oContext.getView().getModel("cloudRefObjTree");
			oTenant.modules = [];
			for (let oModule of aModule) {
				if (oModule.ParentComponent === "0" || oModule.ParentComponent === "" || !oModule.ParentComponent ||
					oModule.ParentComponent !== oTenant.IbComponent) {
					continue;
				}
				aModule[j].hasModules = false;
				oTenant.modules.push(aModule[j]);
			}
			this.pGetCloudModuleVH(oContext, oTenant.ProductID).then((oData) => {
				oTenant.modulesVH = oData.results;
				oTenant.hasModules = oData.results.length > 0;
			});
			oTreeModel.getData().tenants.push(oTenant);

		}

	};
});
