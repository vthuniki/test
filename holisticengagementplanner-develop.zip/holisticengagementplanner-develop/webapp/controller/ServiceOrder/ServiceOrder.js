 sap.ui.define([
 	"jquery.sap.global",
 	"sap/ui/model/json/JSONModel",
 	"com/sap/ui/hep/model/formatter",
 	"com/sap/ui/hep/util/EmployeeDetails",
 	"com/sap/ui/hep/util/Dates",
 	"sap/m/MessageBox",
 	"com/sap/ui/hep/util/MessageHandlingPopover",
 	"com/sap/ui/hep/util/Questionnaire",
 	"com/sap/ui/hep/util/ServiceOrderManipulation",
 	"com/sap/ui/hep/util/ReferenceObjects",
 	"com/sap/ui/hep/util/PersonalizationSOC",
 	"sap/ui/table/TablePersoController",
 	"com/sap/ui/hep/util/ServiceOrderValidation",
 	"com/sap/ui/hep/controller/Details/BaseDetails",
	 "com/sap/ui/hep/controller/ServiceOrder/CloudReferenceObjects",
	 "com/sap/ui/hep/reuse/Constants"

 ], function (jQuery, JSONModel, Formatters,
 	EmployeeDetails, Dates, MessageBox,
 	MessageHandlingPopover, Questionnaire, ServiceOrderManipulation,
 	ReferenceObjects, PersonalizationSOC, TablePersoController, ServiceOrderValidation,
	 BaseDetails, CloudRefObjects, Constants) {
 	"use strict";
 	return BaseDetails.extend("com.sap.ui.hep.controller.ServiceOrder.ServiceOrder", {
 		formatter: Formatters,
 		dates: Dates,
 		employeeDetails: EmployeeDetails,
 		soManipulation: ServiceOrderManipulation,
 		messageHandler: MessageHandlingPopover,
 		questionnaire: Questionnaire,
 		referenceObjects: ReferenceObjects,
 		SOValidation: ServiceOrderValidation,
 		cloudRefObjects: CloudRefObjects,


 		/* ============================================ General ================================================ */

 		initialize: function () {

 			// New Version of popup - KNGMHM02-23694
 			try {
 				this.initializeModelsAndLocalData(this);
 			} catch (oError) { }
 			this.partiesInvolved.init(this);

 			let oLocalModel = new JSONModel({}),
 				oModelRefObj = new JSONModel({}),
 				oModelRO = new JSONModel({}),
 				oModelAccPerson = new JSONModel({}),
 				oModelProjectDetails = new JSONModel({}),
 				oQualificationModel = new JSONModel({}),
 				oModelCustomerVH = new JSONModel({}),
 				oModelCbxDelivery = new JSONModel({}),
 				oModelSO = new JSONModel({}),
 				oModelSrvHierarchy = new JSONModel({}),
 				oModelResponsibleVH = new JSONModel({}),
 				oSOGroupModel = new JSONModel({}),
 				oSOGSearch = new JSONModel({}),
 				oSOGModel = new JSONModel({});

 			this.getView().setModel(this.cloudRefObjects.oModel, "cloudRefObj");

 			this.getView().setModel(oModelSO, "oModelSO");
 			this.getView().getModel("oModelSO").getData().displayMode = this._displayMode;
 			this.getView().getModel("oModelSO").getData().contracts = [];
 			this.getView().getModel("oModelSO").getData().validContract = false;
 			this.getView().getModel("oModelSO").getData().contractItems = [];
 			this.getView().getModel("oModelSO").refresh();
 			this.soManipulation._setValidContract(this);

 			this.getView().setModel(oSOGModel, "oSOGroupModel");

 			if (this.getView().getModel("localModel") === undefined) {
 				this.getView().setModel(oLocalModel, "localModel");
 			}
 			this.getView().setModel(oModelRefObj, "ReferenceObjects");
 			this.getView().setModel(oModelRO, "oModelRO");
 			this.getView().setModel(oModelCustomerVH, "customerSearchHelp");
 			oModelAccPerson.setData({
 				messageAccVisible: false,
 				soacpValueHelp: []
 			});
 			oModelAccPerson.setSizeLimit(1000);
 			this.getView().setModel(oModelAccPerson, "oModelAcc");
 			this.getView().setModel(oModelProjectDetails, "projectDetails");
 			this.getView().setModel(oModelCbxDelivery, "oModelCbxCombo");
 			oModelSrvHierarchy.setData({
 				Items: []
 			});
 			this.getView().setModel(oModelSrvHierarchy, "SrvHierarchy");
 			this.getView().setModel(oSOGroupModel, "oSOGroupModel");
 			this.getView().getModel("oSOGroupModel").getData().showInfoMessage = false;
 			this.getView().getModel("oSOGroupModel").getData().valueStateCreatedBy = "None";
 			this.getView().getModel("oSOGroupModel").refresh();
 			this.getView().setModel(oModelResponsibleVH, "oModelResponsibleVH");
 			this.getView().getModel("oModelResponsibleVH").getData().valueStateUserId = "None";
 			this.getView().getModel("oModelResponsibleVH").refresh();
 			this.getView().setModel(oSOGSearch, "oSOGSearch");
 			this.getView().getModel("oSOGSearch").getData().showWarningMessage = false;
 			this.getView().getModel("oSOGSearch").refresh();

 			this._oView = this.getView();
 			this._oModel = this._oView.getModel("localModel");
 			this._oData = this._oModel.getData();
 			this._oData.SOEdit = false;
 			this._oData.busyServiceOrderPage = false;
 			this._oData.busyServiceDataStep = false;
 			this._oData.busyServiceComponentStep = false;
 			this._oData.busyServiceQuestionareStep = false;
 			this._oData.busyServiceComponentEditStep = false;
 			this._oData.busySrvHierarchyVH = false;
 			this._oData.saveAsDraft = "Clear";
 			this._oData.busyAdd = false;
 			this._oData.addSubItemButton = false;
 			this._oData.editSCButton = false;
 			this._oData.ProductIdValid = false;
 			this._oData.DescriptionValid = false;
 			this._oData.refrenceObject = false;
 			this._oData.newSOGoLiveMandatory = false;
 			this._oData.busyServiceDataStep = false;
 			this._oData.isSavePress = false;
 			this._oData.isReleasePress = false;
 			this._oData.saveBtnEnabled = true;
 			this._oData.busyVHAccPerson = false;
 			this._oData.busyAddRO = false;
 			this._oData.busyVHInput = false;
 			this._oData.busySOGHelpTable = false;
				this._oData.timeZone = Constants.getTimeZoneText();
 			this._isSaved = false;
 			this._oData.busyQualifications = false;

				this.getView().getModel("oModelCbxCombo").getData().cbxAllItems = Constants.getCbxComboValuesBECust();

 			this.getView().getModel("oModelRO").getData().customerIDExists = true;
 			this.getView().getModel("oModelRO").getData().instNoExists = true;
 			this.getView().getModel("oModelRO").getData().roSelectionPage = false;
 			this.getView().getModel("oModelRO").getData().refObjExist = false;
 			this.getView().getModel("oModelRO").getData().refObjRequirements =
					Constants.getSystemSolManOptions()[0].key;
 			this.getView().getModel("oModelRO").refresh();
 			this.messageHandler.initializeMsgHandlling(this);
 			this._getMockLocations();
 			this.getView().setModel(oQualificationModel, "qualificationModel");

 			this._initializeTablePerso();

 			this._oModel.refresh();
 			this.getOwnerComponent().pCrmUserDataLoaded.then(()=> {
				this.currentUserId = this.getOwnerComponent().getModel("appData").getData().oCrmUserData.UserId;
			});
 			this._workAtRiskVisible = false;

 			this.initBatch();
 		},

 		_initializeTablePerso: function () {
 			if (this._oTPC === undefined) {
 				this._oTPC = new TablePersoController({
 					table: this.getView().byId("SOComponents"),
 					persoService: PersonalizationSOC
 				});
 			}
 			PersonalizationSOC.setContext(this);

 		},

 		initSOModel: function (oContext) {
 			let ostatusModel = new JSONModel({});
 			this.getView().setModel(ostatusModel, "treeSO");

 			let oModelDetails = new JSONModel({});
 			oModelDetails.setSizeLimit(1000);
 			this.getView().setModel(oModelDetails, "oModelSO");
 			this.getView().getModel("oModelSO").getData().contractsExist = false;
 			this.getView().getModel("oModelSO").getData().contractItemsExist = false;

 			this.getView().getModel("oModelSO").getData().MainProduct = "";
 			this.getView().getModel("oModelSO").getData().refObjExist = false;
 			this.getView().getModel("oModelSO").getData().selectedRefObj = {};
 			this.getView().getModel("oModelSO").getData().solmanRequired = false;
 			this.getView().getModel("oModelSO").getData().systemRequired = false;
 			this.getView().getModel("oModelSO").getData().refObjRequired = false;
 			this.getView().getModel("oModelSO").getData().refObjComboEnabled = false;
 			this.getView().getModel("oModelSO").getData().refObjComboValueStateText =
 				this.getResourceBundle().getText("SO.Error.Subtitle.RefObj");

 			this.getView().getModel("oModelSO").getData().busySO = false;
 			this.getView().getModel("oModelSO").getData().busyContract = false;
 			this.getView().getModel("oModelSO").getData().busyContractItem = false;

 			this.getView().getModel("oModelSO").getData().contractRequired = false;
 			this.getView().getModel("oModelSO").getData().contractVisible = false;
 			this.getView().getModel("oModelSO").getData().contractRemovedAfterDateChange = false;
 			this.getView().getModel("oModelSO").getData().billingOptionsVisible = false;

 			this.getView().getModel("oModelSO").getData().newSOValid = {};
 			this.getView().getModel("oModelSO").getData().newSOValid.save = false;

 			this.getView().getModel("oModelSO").getData().productIdSelected = false;
 			this.getView().getModel("oModelSO").getData().contractSelected = false;
 			this.getView().getModel("oModelSO").getData().showDescription = false;

 			this.getView().getModel("oModelSO").getData().soMandatoryComponentsExist = false;
 			this.getView().getModel("oModelSO").getData().additionalComponentsExist = false;
 			this.getView().getModel("oModelSO").getData().wizardDataStepValid = false;
 			this.getView().getModel("oModelSO").getData().wizardQuestionnaireStepValid = false;
 			this.getView().getModel("oModelSO").getData().reqDelDateExists = false;
 			this.getView().getModel("oModelSO").getData().RecDelDate = null;
			this.getView().getModel("oModelSO").getData().goLiveExists = false;
			this.getView().getModel("oModelSO").getData().GoLiveDate = null;
 			this.getView().getModel("oModelSO").getData().FeedbackEnabled = true;

 			this.getView().getModel("oModelSO").refresh();
 		},

 		handleSOCPersonalization: function (oEvent) {
 			this._oTPC.openDialog();
 		},

 		resetWizard: function () {
 			let oWizardSO = this.getView().byId("CreateSOWizard"),
 				oFirstStep = oWizardSO.getSteps()[0];
 			oWizardSO.discardProgress(oWizardSO.getSteps()[0]);
 			oWizardSO.goToStep(oFirstStep);
 			oFirstStep.setValidated(false);

 			this.getView().byId("questionnaire").destroyItems();
 			this.getView().byId("soContract").setSelectedKey("");
 			this.getView().byId("soContractItem").setSelectedKey("");
 		},

 		navToHome: function () {
 			this.handleClearAllMessages();
 			this._oData.busyServiceOrderPage = true;
 			this._oModel.refresh();
 			this.questionnaire.destroyQuestionnaire(this);
 			this.getRouter().navTo("Home");
 		},

 		navToProjectDetails: function () {
 			this._oData.busyServiceOrderPage = true;
 			this._oModel.refresh();
 			if (!this._displayMode) {
 				this.handleClearAllMessages();
 				this.resetWizard();
 			}
 			this.questionnaire.destroyQuestionnaire(this);
 			this.getRouter().navTo("ProjectDetails", {
 				projectID: this._idProject
 			});
 		},

 		navToEngagement: function (oEvent) {
 			let sEngId = this.getView().getModel("projectDetails").getData().ParentCaseID;
 			let sEngCaseID = this.getView().getModel("projectDetails").getData().ProjectID;
				let aSpecialReasons = Constants.getSpecialReasonCase();
 			if (!aSpecialReasons.includes(this.getView().getModel("projectDetails").getData().ReasonCode)) {
 				this._navToENGDetails(sEngId);
 			} else {
 				this._navToENGDetails(sEngCaseID);
 			}
 		},

 		_navToENGDetails: function (sCaseID) {
 			this.getRouter().navTo("EngagementDetails", {
 				engagementID: sCaseID
 			});
 		},

 		_getMockLocations: function () {
 			let oLocationsModel = new JSONModel({});
				oLocationsModel.setData(Constants.getServiceTypeItems());
 			this.getView().setModel(oLocationsModel, "Locations");
 		},

 		_generateFilterParams: function (arrFilters) {
 			return "(" + arrFilters.join(" and ") + ")";
 		},

 		activateSOPageBusyIndicator: function (bActivate) {
 			this.getView().getModel("localModel").getData().busyServiceOrderPage = !!bActivate;
 			this.getView().getModel("localModel").refresh();
 		},

 		checkServiceOrderIsLocked: function (sServiceOrderId) {
 			return new Promise((resolve, reject) => {
 				if (sServiceOrderId) {
 					let oParams = {};
 					oParams.oContext = this;
					oParams.servicePath = Constants.getServicePath();
 					oParams.function = "CheckServiceOrderIsLocked";
 					oParams.method = "GET";
 					oParams.urlParameters = {
 						"SoId": sServiceOrderId
 					};
 					oParams.callbackSuccess = (data) => {
 						if (data.IsLocked === false) {
 							reject();
 						} else {
 							resolve();
 						}
 					};
 					this.callFunction(oParams);
 				}
 			});
 		},

 		/* ======================== Read data for an already existing Service Order =========================== */

 		/**
 		 * Read the SO-Data from BE
 		 * @return {Promise} resolved - to inform higher level functions when done
 		 */
 		pLoadDataForAlreadyExistingSO: function () {
 			return new Promise((resolve, reject) => {
 				this.messageHandler.resetMessageDataModel(this.getView());
 				this.getView().getModel("localModel").getData().busyServiceDataStep = true;
 				this.getView().getModel("localModel").getData().busyServiceComponentStep = true;
 				this.getView().getModel("localModel").getData().busyServiceQuestionareStep = true;
 				this.getView().getModel("localModel").refresh();
 				let entities = {};
					entities.servicePath = Constants.getServicePath();
 				entities.entitySet = "ServiceOrderSet()";
 				if (this.getAppData().getData().requestSOLockedInfo === true) {
 					entities.filter = "( SoID eq '" + this._idServiceOrder + "' and ShowOOMessages eq true and ShowIsLocked eq true )";
 				} else {
 					entities.filter = "( SoID eq '" + this._idServiceOrder + "' and ShowOOMessages eq true )";
 				}
 				entities.currentView = this.getView();
 				entities.oContext = this;
 				entities.busyIndicator = "busyServiceDataStep";
 				entities.callbackSuccess = (oData) => {
 					//also when changing to Edit-Mode the user displays the SO beforehead - but in case the user was already in Display,
 					// do not triggered, otherwise it would be triggered twice - only trigger, when opening the SO directly in Edit-Mode
 					if (!this.getOwnerComponent().getModel("appData").getData().noReporting) {
 						this.getOwnerComponent().trackEvent("Display_ServiceOrder");
 					}
 					this.getOwnerComponent().getModel("appData").getData().noReporting = false;
 					this.getAppData().getData().requestSOLockedInfo = false;
 					resolve(oData.results[0]);
 				};
 				this.readBaseRequest(entities);
 			});
 		},

 		/**
 		 * After SO-Data has been read from BE, fill the view Model "oModelSO" with it.
 		 */
 		manipulateSOData: function () {
 			let oSOModelData = this.getView().getModel("oModelSO").getData();

 			oSOModelData.accountPersonValue = oSOModelData.ContactFirst + " " + oSOModelData.ContactLast;
 			oSOModelData.SurveyRecValue = oSOModelData.SurveyRecFirst + " " + oSOModelData.SurveyRecLast;
 			oSOModelData.contractsExist = oSOModelData.contractSelected = oSOModelData.ContractID !== "";
 			oSOModelData.contractVisible = oSOModelData.contractSelected = oSOModelData.ContractID !== "";
 			oSOModelData.reqDelDateExists = !!oSOModelData.RecDelDate;
			oSOModelData.goLiveExists = !!oSOModelData.GoLiveDate;

 			this.getView().getModel("oModelSO").refresh();
 		},

 		/**
 		 * @return {object} try to find the RefObj from the SO in the RefObj-Combolist and return its GUID
 		 *
 		 **/
 		_findRefObjInComboList: function () {
 			let sRefObjKey = "";
 			let oModelSO = this.getView().getModel("oModelSO").getData();
 			$.each(this.getView().getModel("ReferenceObjects").getData().results, function (iItem, oItem) {
 				if (oItem.IbComponent === oModelSO.SystemIBComp && oItem.SolmanComponent === oModelSO.SolmanIBComp) {
 					sRefObjKey = oItem.Guid;
 				}
 			});
 			return sRefObjKey;
 		},

 		/**
 		 * All Reference Objects, which are assigned to the related project, have been loaded into the Combo List (View-Model "ReferenceObjects)
 		 * Also the SystemIBComp and SolmanIBComp from the service order are known (in View-Model "oModelSO")
 		 * Now the entry with same SystemIBComp and SolmanIBComp from the SO has to be found and selected in the Combolist.
 		 *
 		 * @return {Promise} resolved - to inform higher level functions when done
 		 */
		_selectSORefObjInCombo: function () {
			return new Promise((resolve, reject) => {
				let sRefObjKey = this._findRefObjInComboList();

				if (this._displayMode) {
					if (sRefObjKey) {
						this._setRefObjectRelatedFields(sRefObjKey);
					}
					resolve();
				} else if (sRefObjKey) {
						this.getView().byId("ReferenceObject").setSelectedKey(sRefObjKey);
						this._setRefObjectRelatedFields(sRefObjKey);
						this.getView().getModel("oModelSO").getData().contractSelected = false;
						resolve();
					} else {
						this._handleRefObjNotInComboList().then(() => {
							this.getView().getModel("oModelSO").getData().contractSelected = false;
							resolve();
						});
					}
			});
		},

		_setRefObjectRelatedFields: function (sRefObjKey) {
			let oSelectedRefObj = this.getView().getModel("ReferenceObjects").getData().results.find(elm => elm.Guid === sRefObjKey);
			if (oSelectedRefObj) {
				this.getView().getModel("oModelSO").getData().DeliveryModel = oSelectedRefObj.DeliveryModel;
				this.getView().getModel("oModelSO").getData().DeliveryModelText = oSelectedRefObj.DeliveryModelText;
				this.getView().getModel("oModelSO").getData().selectedRefObj.InstNo = oSelectedRefObj.InstNo;
				this.getView().getModel("oModelSO").getData().RefObjText = this.formatter.refObjDisplay(oSelectedRefObj);
			}
		},

 		_selectSORefObjInComboDisplayMode(sRefObjKey, oSelectedRefObj) {
 			if (sRefObjKey) {
 				oSelectedRefObj = this.getView().getModel("ReferenceObjects").getData().results.find(elm => elm.Guid === sRefObjKey);
 				if (oSelectedRefObj) {
 					this.getView().getModel("oModelSO").getData().DeliveryModel = oSelectedRefObj.DeliveryModel;
 					this.getView().getModel("oModelSO").getData().DeliveryModelText = oSelectedRefObj.DeliveryModelText;
 					this.getView().getModel("oModelSO").getData().selectedRefObj.InstNo = oSelectedRefObj.InstNo;
 					this.getView().getModel("oModelSO").getData().RefObjText = this.formatter.refObjDisplay(oSelectedRefObj);
 				}
 			}
 		},

 		/**
 		 * All Reference Objects, which are assigned to the related project, have been loaded into the Combo List (View-Model "ReferenceObjects)
 		 * Also the SystemIBComp and SolmanIBComp from the service order are known (in View-Model "oModelSO")
 		 * However, the SystemIBcomp and SolmanIBComp from the SO are not part of the Combo List.
 		 * This can sometimes be the case, if a CBX-Solman has been selected
 		 * This is also possible, if the SO has been created in WebUI, where it is possible to assign any valid combination of System and Solman
 		 * regardless of if they are assigned to any project.
 		 *
 		 * In case a CBX Solman is selected, the combination of System and CBX-Solman is not added to the Combo-List. Instead the combo is disabled for input
 		 * and the combination of System and Solman is just displayed to the user. The user cannot change the value.
 		 * If the user wants to change the value, he/she first needs to select that no delivery via CBX is desired (in the CBX-Delivery Combo)  only after that
 		 * the RefObj Comob is opened for input again, and the user can change the value.
 		 *
 		 * In case it is not a CBX Solman, but the combination of System and Solman is not in the RefObj-List, we try to read the infos for the combination
 		 * from the iBase
 		 *
 		 * @return {Promise} resolved - to inform higher level functions when done
 		 */
 		_handleRefObjNotInComboList: function () {
 			return new Promise((resolve, reject) => {
				if (this.getView().getModel("oModelSO").getData().CbxEnabled === Constants.getCbxCustKey().Yes) {
 					resolve();
 				} else {
 					this._readRefObjDataFromIBase().then(() => {
 						resolve();
 					});
 				}
 			});
 		},

 		/**
 		 * set up the CBX-Combo for current situation (selected key, available items, editmode):
 		 *  + set the selected key and long text
 		 *  + only show combo items, dependend on which are allowed for the selected key
 		 *  + enable or disable the combo
 		 * @param {string} sKey - cbx entry that is visible now
 		 */
 		_setUpCbxCombo: function (sKey) {
 			this.getView().getModel("oModelCbxCombo").getData().cbxComboItems = [...this.getView().getModel("oModelCbxCombo").getData().cbxAllItems];

 			// set the currently selectedKey
 			this.getView().getModel("oModelCbxCombo").getData().cbxSelectedKey = sKey;
 			this.getView().getModel("oModelCbxCombo").getData().cbxSelectedValue =
 			this.getView().getModel("oModelCbxCombo").getData().cbxComboItems.find(elm => elm.Key === sKey).Value;

 			// get CBX customizing keys
			let oCbxCustKey = Constants.getCbxCustKey();

 			// depending on the currently selected item, ajust the editmode and the list-items according to BE-logic in
 			// ZCL_Z_TBUI_S_STEP3_CN17->GET_V_ZZS_CBX_ENABLED
 			// ZCL_Z_TBUI_S_STEP3_CN17->GET_I_ZZS_CBX_ENABLED
 			switch (sKey) {
 			case oCbxCustKey.NotEvaluatedYet:
 				this.getView().getModel("oModelCbxCombo").getData().cbxComboEnabled = false;
 				break;
 			case oCbxCustKey.Yes:
 				this.getView().getModel("oModelCbxCombo").getData().cbxComboItems = this.getView().getModel("oModelCbxCombo").getData().cbxAllItems
 					.filter(oItem => {
 						return oItem.Key !== oCbxCustKey.NotEvaluatedYet && oItem.Key !== oCbxCustKey.No;
 					});
 				this.getView().getModel("oModelCbxCombo").getData().cbxComboEnabled = true;
 				break;
			case oCbxCustKey.ManuallySwitchedToNo:
			// Fallthrough to case oCbxCustKey.EvaluateAgain
			case oCbxCustKey.EvaluateAgain:
				this.getView().getModel("oModelCbxCombo").getData().cbxComboItems = this.getView().getModel("oModelCbxCombo").getData().cbxAllItems
					.filter(oItem => {
						return oItem.Key !== oCbxCustKey.NotEvaluatedYet && oItem.Key !== oCbxCustKey.No && oItem.Key !== oCbxCustKey.Yes;
					});
				this.getView().getModel("oModelCbxCombo").getData().cbxComboEnabled = true;
				break;
 			case oCbxCustKey.No:
 				this.getView().getModel("oModelCbxCombo").getData().cbxComboItems = this.getView().getModel("oModelCbxCombo").getData().cbxAllItems
 					.filter(oItem => {
 						return oItem.Key !== oCbxCustKey.NotEvaluatedYet && oItem.Key !== oCbxCustKey.Yes && oItem.Key !== oCbxCustKey.ManuallySwitchedToNo;
 					});
 				this.getView().getModel("oModelCbxCombo").getData().cbxComboEnabled = true;
 			}
 			this.getView().getModel("oModelCbxCombo").refresh();
 		},

 		/**
 		 * All Reference Objects, which are assigned to the related project, have been loaded into the Combo List (View-Model "ReferenceObjects)
 		 * Also the SystemIBComp and SolmanIBComp from the service order are known (in View-Model "oModelSO")
 		 * However, the SystemIBcomp and SolmanIBComp from the SO are not part of the Combo List.
 		 * This is i.e. possible, if the SO has been created in WebUI, where it is possible to assign any valid combination of System and Solman
 		 * regardless of if they are assigned to any project.
 		 * Here we try to determine the combination of System and Solman directly from the iBase. In case this works, we can add it to the Combo-List
 		 * However it does not contain the values for the Delivery Model
 		 * fields like DeliveryModel, Solution, etc... so we can save the BE call and keep everything simplier
 		 *
 		 * @return {Promise} resolved - to inform higher level functions when done
 		 */
		_readRefObjDataFromIBase: function () {
			return new Promise((resolve, reject) => {
				let entity = {};
				entity.oView = this.getView();
				entity.servicePath = Constants.getServicePath();
				entity.entitySet = "IBaseComponentSet";
				entity.filter = `IbComponent eq '${this.getView().getModel("oModelSO").getData().SystemIBComp}'`;
				if ((this.getView().getModel("oModelSO").getData().SolmanIBComp) && (this.getView().getModel("oModelSO").getData().SolmanIBComp !==
					"0")) {
					entity.filter += ` and SolmanComponent eq '${this.getView().getModel("oModelSO").getData().SolmanIBComp}' and DeletionFlag eq 'N'`;
				}
				entity.callbackSuccess = (data) => {
					this._handleRefObjIBaseDataAfterRead(data);
					resolve();
				};
				this.readBaseRequest(entity);
			});
		},

 		/**
 		 * All Reference Objects, which are assigned to the related project, have been loaded into the Combo List (View-Model "ReferenceObjects)
 		 * Also the SystemIBComp and SolmanIBComp from the service order are known (in View-Model "oModelSO")
 		 * However, the SystemIBcomp and SolmanIBComp from the SO are not part of the Combo List.
 		 * This is i.e. possible, if the SO has been created in WebUI, where it is possible to assign any valid combination of System and Solman
 		 * regardless of if they are assigned to any project.
 		 * So we tried to read the combination of Sytem and Solman directly from the iBase and
 		 * now we add the found values to the ComboList....
 		 * if the combination could not be found in the iBase, we just take the values from the SO
 		 *
 		 * @param {object} data - data set
 		 */
 		_handleRefObjIBaseDataAfterRead: function (data) {
 			let oRefObject = {};
 			oRefObject.AlreadyExists = false;
 			if (data.results.length > 0) {
 				oRefObject = data.results[0];
 				oRefObject.comboValue = this.formatter.refObjDisplay(oRefObject);
 				this.referenceObjects._createGroupingRO(oRefObject, this);
 				this._updateRefObjComboWithFoundRefObj(oRefObject);
 			} else if (this.oView.getModel("oModelSO").getData().SolmanIBComp && this.oView.getModel("oModelSO").getData().SolmanIBComp !== "0" ===
 					this.oView.getModel("oModelSO").getData().SystemIBComp && this.oView.getModel("oModelSO").getData().SystemIBComp !== "0") {
 					oRefObject.SID = this.oView.getModel("oModelSO").getData().SystemSID;
 					oRefObject.SolmanSID = this.oView.getModel("oModelSO").getData().SystemSID;
 					oRefObject.SolmanComponent = this.oView.getModel("oModelSO").getData().SolmanIBComp;
 					oRefObject.IbComponent = this.oView.getModel("oModelSO").getData().SystemIBComp;
 					oRefObject.SolmanAssigned = this.getResourceBundle().getText("RO.GroupCaptionWithSolman");
 					oRefObject.comboValue = this.oView.getModel("oModelSO").getData().RefObjText;
 					this.referenceObjects._createGroupingRO(oRefObject, this);
 					this._updateRefObjComboWithFoundRefObj(oRefObject);
 				}
 		},

 		_updateRefObjComboWithFoundRefObj: function (oRefObject) {
 			this.oView.getModel("ReferenceObjects").getData().results.push(oRefObject);
 			this.oView.getModel("ReferenceObjects").refresh();
 			let nSelItemIndex = this.oView.byId("ReferenceObject").getItems().findIndex(elm => elm.getText() === oRefObject.comboValue);
 			let oComboBoxItem = this.oView.byId("ReferenceObject").getItems()[nSelItemIndex];
 			this.oView.byId("ReferenceObject").setSelectedItem(oComboBoxItem);
 		},

 		setAllServiceDataFieldValueStatesToNone: function () {
 			let oNewSOValid = this.getView().getModel("oModelSO").getData().newSOValid;
 			oNewSOValid.productID =
 				oNewSOValid.descr =
 				oNewSOValid.reqDelDate =
 				oNewSOValid.goLiveDate =
 				oNewSOValid.contractID =
 				oNewSOValid.contractItems =
 				oNewSOValid.refObj =
 				oNewSOValid.accountContactPerson =
 				oNewSOValid.surveyRecipient = "None";
 			this.getView().getModel("oModelSO").refresh();
 		},

 		_findProdIdInSelectionList: function (sProd) {
 			let oItem = null;
 			this.getView().getModel("oModelSO").getData().products.map(function (elem) {
 				if (elem.Key === sProd) {
 					oItem = elem;
 				}
 			});
 			return oItem;
 		},

 		/* ==================================== Cloud Reference Objects ============================================== */
 		onCloudRefObjectInfoButton: function (oEvent) {
 			let oSource = oEvent.getSource();
			this._pPopoverCloudRefObjInfo ??= this._loadFragment("com.sap.ui.hep.view.ServiceOrder.fragment.SOCloudRefObjectsInfo");
			this._pPopoverCloudRefObjInfo.then(oPopover => oPopover.openBy(oSource));
 		},

 		onCloudRefObjectsInfoClose: function (oEvent) {
			this._pPopoverCloudRefObjInfo.then(oPopover => oPopover.close());
 		},

 		onCloudTenantAdd: function (oEvent) {
			this._pDialogRelatedTenantVH ??= this._loadFragment("com.sap.ui.hep.view.ServiceOrder.fragment.VHRelatedTenant");
			this._pDialogRelatedTenantVH.then(oDialog => this._openRelatedTenantVH());
 		},

 		onCloudModuleAdd: function (oEvent) {
 			let aData = oEvent.getSource().getCustomData();
 			let sTenantID = aData.find(elem => elem.getKey() === "ProductID").getValue();
 			let sParentComponent = aData.find(elem => elem.getKey() === "ComponentID").getValue();

			this._pDialogCloudModuleVH ??= this._loadFragment("com.sap.ui.hep.view.ServiceOrder.fragment.VHCloudModule");
			this._pDialogCloudModuleVH.then(oDialog => this._openCloudModuleVH(sTenantID, sParentComponent))
 		},

 		onCloudRefObjectDelete: function (oEvent) {
 			let aData = oEvent.getSource().getCustomData();
 			this.cloudRefObjects.pDeleteObject(this, aData.find(elem => elem.getKey() === "ProductID").getValue(), aData.find(elem => elem.getKey() ===
 				"ParentComponentID").getValue()).then(() => {
 					this.cloudRefObjects.buildTree(this);
 				});
 		},

 		_openRelatedTenantVH: function () {
 			this.cloudRefObjects.pGetRelatedTenantVH(this).then((oData) => {
 				let oModelVH = new JSONModel();
 				oModelVH.setData(oData.results);
 				oModelVH.refresh();
				this._pDialogRelatedTenantVH.then(oDialog => {
					oDialog.setModel(oModelVH, "VH");
					oDialog.open();
				});
 			});
 		},

 		_openCloudModuleVH: function (sTenantID, sParentComponent) {
 			this.cloudRefObjects.pGetCloudModuleVH(this, sTenantID).then((oData) => {
 				let oModelVH = new JSONModel();
 				oModelVH.setData(oData.results);
 				oModelVH.refresh();
				this._pDialogCloudModuleVH.then(oDialog => oDialog.setModel(oModelVH, "VH"));

 				let oModelViewVH = new JSONModel();
 				oModelViewVH.getData().ParentComponent = sParentComponent;
 				oModelViewVH.refresh();
				this._pDialogCloudModuleVH.then(oDialog => {
					oDialog.setModel(oModelViewVH, "view");
					oDialog.open();
				});
 			});
 		},

 		onConfirmAddRelatedTenantVH: function (oEvent) {
			this._pDialogRelatedTenantVH.then(oDialog => oDialog.close());
 			let aItems = this.getView().byId("RelatedTenantVHTable").getSelectedItems() || [];

 			for (let oItem of aItems) {
				let aData = oItem.getCustomData();
 				let oNewTenant = {
 					tenantID: aData.find(elem => elem.getKey() === "tenantID").getValue(),
 					tenantDescription: aData.find(elem => elem.getKey() === "tenantDescription").getValue(),
 					systemRole: aData.find(elem => elem.getKey() === "systemRole").getValue(),
 					ibComponent: aData.find(elem => elem.getKey() === "ibComponent").getValue()
 				};
				this.cloudRefObjects.pAddTenant(oNewTenant, this)?.then(() => {
 					this.cloudRefObjects.buildTree(this);
 				});
 			}

 		},

 		onCancelAddRelatedTenantVH: function (oEvent) {
			this._pDialogRelatedTenantVH.then(oDialog => oDialog.close());
 		},

 		onConfirmAddCloudModulesVH: function (oEvent) {
			this._pDialogCloudModuleVH.then(oDialog => oDialog.close());
 			let aItems = this.getView().byId("CloudModuleVHTable").getSelectedItems() || [];

 			for (let oItem of aItems) {
				let aData = oItem.getCustomData();
 				let oNewModule = {
 					ProductID: aData.find(elem => elem.getKey() === "ProductVersion").getValue(),
 					ProductDescription: aData.find(elem => elem.getKey() === "ProductName").getValue(),
 					ParentComponent: aData.find(elem => elem.getKey() === "ParentComponent").getValue()
 				};
 				this.cloudRefObjects.pAddModule(oNewModule, this).then(() => {
 					this.cloudRefObjects.buildTree(this);
 				});
 			}

 		},

 		onCancelAddCloudModulesVH: function (oEvent) {
			this._pDialogCloudModuleVH.then(oDialog => oDialog.close());
 		},

 		/* ======================================= Read project data =========================================== */

 		/**
 		 * Read the project data from BE
 		 * @return {Promise} resolved - to inform higher level functions when done
 		 */
 		pReadProjectData: function () {
 			return new Promise((resolve, reject) => {
 				let entities = {},
 					idProject = this._idProject;
 				this.getView().getModel("localModel").getData().busyServiceDataStep = true;
 				this.getView().getModel("localModel").refresh();

				entities.servicePath = Constants.getServicePath();
 				entities.entitySet = "ProjectSet";
 				entities.getEntity = idProject;
 				entities.currentView = this.getView();
 				entities.oContext = this;
 				entities.busyIndicator = "busyServiceDataStep";
 				entities.errorMessage = this.getResourceBundle().getText("ProjectDetails.ReadProjectDataError");
 				entities.callbackSuccess = (data) => {
 					this._handleSuccessReadProjectData(data);
 					resolve();
 				};
 				this.readBaseRequest(entities);
 			});
 		},

 		/**
 		 * Fill the project data from BE into the view model "projectDetails"
 		 * @param {object} data - data set
 		 */
 		_handleSuccessReadProjectData: function (data) {
 			this.getView().getModel("projectDetails").setData(data);
 			this.getView().getModel("projectDetails").refresh();
 			this.getView().getModel("localModel").getData().busyServiceDataStep = false;
 			this.getView().getModel("localModel").refresh();
 		},

 		/* ==================================== Billable Box ========================================= */

 		setBillingOption: function (sOption, bContractAllowed) {
 			this.getView().getModel("oModelSO").getData().BillingOption = sOption;
 			if (bContractAllowed === false) {

 				// also check if it is at all needed, as the properties should have been moved to the model
 				if (!this._displayMode) {
 					this.getView().byId("soContract").setValue("");
 					this.getView().byId("soContractItem").setValue("");
 				}

 				this.getView().getModel("oModelSO").getData().contractSelectedKey = "";
 				this.getView().getModel("oModelSO").getData().contractItemSelectedKey = "";
 				this.getView().getModel("oModelSO").getData().contractRequired = false;
 			} else {
 				this.getView().getModel("oModelSO").getData().contractRequired = true;
 			}
 			if (this.getView().getModel("oModelSO").getData().contracts.length > 0) {
 				this.getView().getModel("oModelSO").getData().contractVisible = bContractAllowed;
 			}
 			this.getView().getModel("oModelSO").refresh();

 			this.checkDeliveryRules();
 		},

 		checkBilling: function () {
 			let oSOData = this.getView().getModel("oModelSO").getData();
 			let sProductID = oSOData.MainProduct,
 				sDeliveryDate = oSOData.RecDelDate ? oSOData.RecDelDate : oSOData.GoLiveDate,
 				oRefObject = {};
 			oRefObject = this._displayMode === true ? {
 				IbComponent: oSOData.SystemIBComp !== "" ? oSOData.SystemIBComp : ""
 			} :
 				oSOData.selectedRefObj;

 			if (!oRefObject.IbComponent || oRefObject.IbComponent === "0") {
 				return;
 			}

 			let sIBCompSys = oRefObject !== null ? oRefObject.IbComponent : "";

 			if (sProductID && sDeliveryDate && sIBCompSys) {
 				let oParams = {};
					oParams.servicePath = Constants.getServicePath();
 				oParams.function = "CheckBilling";
 				oParams.method = "GET";
 				oParams.urlParameters = {
 					"ProductId": sProductID,
 					"DeliveryDate": sDeliveryDate,
 					"IbCompSystem": sIBCompSys
 				};
 				oParams.callbackSuccess = (data) => {
 					this._handleCheckBillingSuccess(data);
 				};
 				this.callFunction(oParams);
 			}
 		},

 		_handleCheckBillingSuccess: function (oData) {
 			if (oData.results.length > 1 && !this._displayMode) {
 				this.getView().getModel("oModelSO").getData().billingButtonSelected = false;
 				let oSelectedOption = oData.results.find(res => res.Option === this.getView().getModel("oModelSO").getData().BillingOption);

 				this.getView().getModel("oModelSO").getData().billingOptionsVisible = true;
 				this.getView().byId("rgBillOptions").destroyButtons();
 				for (let oResult of oData.results) {
 					let oRadioButton = new sap.m.RadioButton({
						text: oResult.TextS,
						selected: oSelectedOption !== undefined ? oResult.Option === oSelectedOption.Option : oResult.Default
 					});
						oRadioButton.setTooltip(oResult.TextL);
 					oRadioButton.addCustomData(new sap.ui.core.CustomData({
 						key: "Option",
						value: oResult.Option
 					}));
 					oRadioButton.addCustomData(new sap.ui.core.CustomData({
 						key: "ContractAllowed",
						value: oResult.ContractAllowed
 					}));
 					this.getView().byId("rgBillOptions").addButton(oRadioButton);
 				}
 				let oSelectedOptionBiling = this.getView().byId("rgBillOptions").getButtons().find(button => button.getProperty("selected") ===
 					true);
 				let sOptionSelected, bContractAlowed;
 				oSelectedOptionBiling.getCustomData().forEach(elm => {
 					if (elm.getKey() === "Option") sOptionSelected = elm.getValue(); else bContractAlowed = elm.getValue();
 				});
 				this.setBillingOption(sOptionSelected, bContractAlowed);
 			} else {
 				this._handleCheckBillingSuccessMoreThan1OrDisplay(oData);
 			}
 			this.getView().getModel("oModelSO").refresh();
 		},

 		_handleCheckBillingSuccessMoreThan1OrDisplay: function (oData) {
 			this.getView().getModel("oModelSO").getData().billingOptionsVisible = false;
 			let oResults = this._displayMode ? oData.results.find(res => res.Option === this.getView().getModel("oModelSO").getData().BillingOption) :
 				oData.results[0];
 			if (oResults) {
 				this.setBillingOption(oResults.Option, oResults.ContractAllowed);
 				this.getView().getModel("oModelSO").getData().BillingInfo = oResults.TextS;
 				this.getView().getModel("oModelSO").getData().BillingInfoTooltip = oResults.TextL;
 				this.getView().getModel("oModelSO").refresh();
 			}
 		},


 		checkDeliveryRules: function () {
 			let oSOData = this.getView().getModel("oModelSO").getData(),
 				sProductID = oSOData.MainProduct,
 				sDeliveryDate = oSOData.RecDelDate ? oSOData.RecDelDate : oSOData.GoLiveDate,
 				oParams = {},
 				oRefObject = {};

 			oRefObject = this._displayMode === true ? {
 				IbComponent: oSOData.SystemIBComp !== "" ? oSOData.SystemIBComp : "",
 				SolmanComponent: oSOData.SolmanIBComp !== "" ? oSOData.SolmanIBComp : ""
 			} : oSOData.selectedRefObj;

 			if (!oRefObject.IbComponent || oRefObject.IbComponent === "0") {
 				return;
 			}

 			let {
 				IbComponent,
 				SolmanComponent
 			} = oRefObject !== null ? oRefObject : "";
 			let {
 				BillingOption
 			} = this.getView().getModel("oModelSO").getData();

				oParams.servicePath = Constants.getServicePath();
 			oParams.function = "CheckDeliveryRules";
 			oParams.method = "GET";
 			oParams.urlParameters = {
 				"ProductId": sProductID,
 				"DeliveryDate": sDeliveryDate,
 				"IbCompSystem": IbComponent,
 				"IbCompSolman": SolmanComponent,
 				"BillingOption": BillingOption
 			};
 			oParams.callbackError = (error) => {
 				this._handleCheckDeliveryRulesError(error);
 			};
 			this.callFunction(oParams);
 			if (!this._displayMode) {
 				this.SOValidation.validateSoDataStepField(this.getView().getModel("oModelSO"), this);
 			}
 		},

 		_handleCheckDeliveryRulesError: function (oError) {
 			let oMessage = jQuery.parseJSON(oError.responseText);
				let sJamMaintenance = Constants.getMaintenanceJAM();
 			let sURLDetails = "<p>For more details access:</p>\n" +
 				`<a href='${sJamMaintenance}' target='_blank' rel='noopener noreferrer'>Jam Page</a>.`;
 			MessageBox.error(oMessage.error.message.value, {
 				details: oMessage.error.message.value.indexOf("Maintenance") > 0 ? sURLDetails : oMessage.error.code
 			});
 		},

 		/* ============================= Section / step 3: Service Questionnaire =============================== */

 		readQuestionnaire: function () {
 			this.getModel("localModel").getData().busyServiceQuestionareStep = true;
 			this.getModel("localModel").refresh();

 			let entities = {};
				entities.servicePath = Constants.getServicePath();
 			entities.entitySet = "ServiceOrderSet(guid'" + this.getView().getModel("oModelSO").getData().SoGUID + "')/toQuestionnaireSet";
 			entities.currentView = this.getView();
 			entities.oContext = this;
 			entities.busyIndicator = "busyServiceQuestionareStep";
 			entities.errorMessage = this.getResourceBundle().getText("SO.ReadQuestionnareError");
 			entities.callbackSuccess = (oData) => {
 				this._handleSuccessReadQuestionnaire(oData);
 			};
 			this.readBaseRequest(entities);
 		},

 		_handleSuccessReadQuestionnaire: function (oData) {
 			let oQuestionnaireModel = new JSONModel({});
 			this.getView().setModel(oQuestionnaireModel, "questionnaire");
 			if (oData.results.length) {
 				this.getView().byId("questionnaire").removeAllItems();
 				this._createQuestionnaireTemplateLayout(oData.results);
 			} else {
 				let oLabel = new sap.m.Label({
 					text: this.getResourceBundle().getText("Questionnaire.NoDataAvailable")
 				});
 				this.getView().byId("questionnaire").addItem(oLabel);
 			}
 			this.getModel("localModel").getData().busyServiceQuestionareStep = false;
 			this.getModel("localModel").refresh();
 		},

 		_checkSameRowFieldLabels: function (oLayout, oRow, oColumn, oCurrentField) {
 			let bSameLabel = false;
 			$.each(oLayout.flat(), function (iField, oField) {
 				if (oField.FieldLabel === oCurrentField.FieldLabel) {
 					bSameLabel = true;
 				}
 			});
 			return bSameLabel;
 		},

 		/**
 		 * Create questionnaire template, based on the fields returned by the back-end
 		 * @param {Array.<Object>} oFields list of fields returned by the back-end
 		 */
		_createQuestionnaireTemplateLayout: function (aFields) {
			let oLayout = [],
				iRow = 0,
				iColumn = 0,
				aReferences = [];

			$.each(aFields, (iField, oField) => {
				if (oField.Column >= 1) {
					let bSameLabel = this._checkSameRowFieldLabels(oLayout, oField.Row, oField.Column, oField);
					if (bSameLabel) {
						// Keep on the same row
						iRow--;
						iColumn = oField.Column;
					} else {
						// Move to the next row
						iColumn = 0;
					}
				}

				oField.oMetadata = this._buildQuestionnaireFieldMetadata(oField);

				oLayout[iRow] = oLayout[iRow] === undefined ? [] : oLayout[iRow];
				oLayout[iRow][iColumn] = oField;

				oField.layoutRow = iRow;
				oField.layoutColumn = iColumn;
				oField.sFieldName = this.createId(oField.FieldName + "" + iRow + iColumn);
				oField.sFieldWidth = (oField.Length) + "rem";
				if (iRow === 0 && iColumn === 0) {
					oField.sFieldWidth = "3.5rem";
				}
				oField.bValueStateError = false;

				iRow++;
				iColumn = 0;

				aReferences.push(...this._buildQuestReferences(oField));
			});

			$.each(oLayout, function (iNewRow, oNewRow) {
				$.each(oNewRow, function (iNewField, oNewField) {
					$.each(aReferences, function (iReference, oReference) {
						if (oReference.ReferencedField === oNewField.FieldName) {
							oNewField.DeterminedBy = {
								"FieldRow": oReference.FieldRow,
								"FieldColumn": oReference.FieldColumn,
								"FieldSelectionIndex": oReference.FieldSelectionIndex
							};
						}
					})
				});
			});

			this.getView().getModel("questionnaire").getData().results = oLayout;
			this.getView().getModel("questionnaire").refresh();

			this.questionnaire.createQuestionnaireLayout(this.getView(), this.getView().getModel("questionnaire").getData().results);
		},

		_buildQuestionnaireFieldMetadata: function (oField) {
			if (oField.MetaData !== "" && oField.MetaData !== "[]") {
				let oMetadata = JSON.parse(oField.MetaData);
				$.each(oMetadata, function (iItem, oItem) {
					if (oItem.value === "true" || oItem.value === "false") {
						oItem.value = JSON.parse(oItem.value);
					}
				});
				return oMetadata;
			}
		},

		_buildQuestReferences: function (oField) {
			let aReferences = [];
			let iFieldSelectionIndex; /*, sReference;*/
			if (oField.oMetadata !== undefined) {
				$.each(oField.oMetadata, function (iItem, oItem) {
					if (oItem.reference !== "" && oItem.reference !== undefined) {
						aReferences = oItem.reference.split(",");
						$.each(aReferences, function (iReference, sReference) {
							iFieldSelectionIndex = iItem;

							let oDeterminedByInfo = {
								"ReferencedField": sReference,
								"FieldRow": oField.layoutRow,
								"FieldColumn": oField.layoutColumn,
								"FieldSelectionIndex": iFieldSelectionIndex
							};
							aReferences.push(oDeterminedByInfo);
						});
					}
				});
			}
			return aReferences;
		},

 		fnHandleDiscardVHInput: function (oEvent) {
 			this._oVHInput.close();
 		},

 		/* ====================================== Message Manager ============================================== */

 		handleClearAllMessages: function () {
 			this.messageHandler.clearAllMessages(this.getView(), this.oMessagePopover);
 		},

 		handleMessagePopoverPress: function (oEvent) {
 			this.oMessagePopover.toggle(oEvent.getSource());
 		},

 		removeItemFromArray: function (arr, nbOfItems) {
 			for (let i = 0; i < nbOfItems; i++) {
 				arr.pop();
 			}
 			return arr.join("/");
 		},

 		/* ====================================== Message Popover Formatting ========================================== */
 		msgButtonTypeFormatter: function () {
 			return this.messageHandler.msgButtonTypeFormatter(this.getView());
 		},

 		highestSeverityMessages: function () {
 			return this.messageHandler.highestSeverityMessages(this.getView());
 		},

 		msgButtonIconFormatter: function () {
 			return this.messageHandler.msgButtonIconFormatter(this.getView());
 		},


		

 	});
 });
