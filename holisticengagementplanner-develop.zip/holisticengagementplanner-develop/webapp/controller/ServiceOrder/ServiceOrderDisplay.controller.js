sap.ui.define([
 	"com/sap/ui/hep/controller/ServiceOrder/ServiceOrder",
 	"com/sap/ui/hep/model/formatter",
 	"com/sap/ui/hep/util/Questionnaire",
 	"com/sap/ui/hep/util/ServiceOrderManipulation",
 	"com/sap/ui/hep/util/ServiceOrderValidation",
 	"com/sap/ui/hep/util/ReferenceObjects",
 	"com/sap/ui/hep/util/Attachments",
 	"com/sap/ui/hep/util/MessageHandlingPopover"	
	
 ], function (ServiceOrder, Formatters, Questionnaire, ServiceOrderManipulation, ServiceOrderValidation,
 	ReferenceObjects, Attachments, MessageHandlingPopover) {
 	"use strict";
 	return ServiceOrder.extend("com.sap.ui.hep.controller.ServiceOrder.ServiceOrderDisplay", {
 		formatter: Formatters,
 		soManipulation: ServiceOrderManipulation,
 		SOValidation: ServiceOrderValidation,
 		questionnaire: Questionnaire,
 		referenceObjects: ReferenceObjects,
 		attachments: Attachments,
 		messageHandler: MessageHandlingPopover,

 		/* ============================================ General ================================================ */

 		onInit: function () {
 			this.router = this.getRouter();
 			this.router.getRoute("ServiceOrderDisplay").attachPatternMatched(this._handleRouteMatched, this);
 			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
 		},

 		_handleRouteMatched: function (oEvent) {
 			this._idServiceOrder = oEvent.getParameters().arguments.serviceOrderID;
 			this._displayMode = true;
 			this.questionnaire.destroyQuestionnaire(this);
 			this.initialize();
 			this.initSOModel(this);
 			this._readData();
 		},

 		_readData: function () {
 			this.getView().getModel("localModel").getData().busyServiceOrderPage = true;
 			this.attachments.initializeDetails(this);
 			this.getView().getModel("oModelSO").refresh();

 			this.pLoadDataForAlreadyExistingSO().then((oDataSO) => {
 				this.getView().getModel("messagesModel").getData().messagesTmp = this.getView().getModel("messagesModel").getData().messages; ///prevent messagePopover mess-up
 				this.getView().getModel("messagesModel").getData().messages = []; ///prevent messagePopover mess-up
 				this.handleSuccessReadSOData(oDataSO);
 				return this.pReadProjectData();
 			}).then(() => {
 				this.getView().getModel("messagesModel").getData().messages = this.getView().getModel("messagesModel").getData().messagesTmp; ///prevent messagePopover mess-up
 				delete this.getView().getModel("messagesModel").getData().messagesTmp; ///prevent messagePopover mess-up
 				return this.referenceObjects.readReferenceObjectsOfProject(this);
 			}).then(() => {
 				return this._selectSORefObjInCombo();
 			}).then(() => {
 				// For cloud tenants, read CloudReferenceObjects
 				this.cloudRefObjects.pReadByOrderID(this).then(() => {
 					this.cloudRefObjects.buildTree(this);
 				});
 				this._setUpCbxCombo(this.getView().getModel("oModelSO").getData().CbxEnabled);
 				return this.soManipulation._pReadServiceProductAllComponents(this.getView().getModel("oModelSO").getData().MainProduct, this);
 			}).then(() => {
 				return this.readQuestionnaire();
 			}).then(() => {
 				return this.attachments.fnReadAttachmentsSO(this);
 			}).then(() => {
 				this.getView().getModel("localModel").getData().busyServiceOrderPage = false;
 				this.getView().getModel("localModel").getData().busyServiceDataStep = false;
 				this.getView().getModel("localModel").getData().busyServiceComponentStep = false;
 				this.getView().getModel("localModel").getData().busyServiceQuestionareStep = false;
 				this.getView().getModel("localModel").getData().formEditMode = false;
 				this.getView().getModel("localModel").getData().SOCreate = false;
 				this.getView().getModel("localModel").refresh();

 				this.getView().byId("SOComponents").expandToLevel(3);
 			});
 		},

 		/**
 		 * After SO-Data has been read from BE, fill the view Model "oModelSO" with it.
 		 * @param {object} oData - result set 
 		 */
 		handleSuccessReadSOData: function (oData) {
 			if (oData) {
 				this._idServiceOrderGuid = oData.SoGUID;
 				this._idProject = oData.ProjectID;
 				let oMergedData = Object.assign({}, this.getView().getModel("oModelSO").getData(), oData);
 				this.getView().getModel("oModelSO").setData(oMergedData);
 				this.getView().getModel("oModelSO").getData().displayMode = this._displayMode;
 				this.getView().getModel("oModelSO").refresh();
 				this.setAllServiceDataFieldValueStatesToNone();
 				this.manipulateSOData();
 			} else {
 				let titleError = this.getResourceBundle().getText("SO.Error.Title.NotFound");
 				let description = this.getResourceBundle().getText("SO.Error.Subtitle.NotFound");
 				this.messageHandler.addNewMessageseInsidePopover("Reference Object", "Error", titleError, description, description);
 			}
 		},

 		onNavToEngagementDetails: function (oEvent) {
 			this.navToEngagement(oEvent);
 		},

 		/* ====================================== Switch to Edit mode ========================================== */

 		fnHandleEditSO: function (oEvent) {
 			this.questionnaire.destroyQuestionnaire(this);
 			this.getOwnerComponent().getModel("appData").getData().noReporting = true; // when coming from here do not trace the DISPLAY_SO-event, that is triggered before the EDIT_SO-event....
 			this.getRouter().navTo("ServiceOrderMaintain", {
 				serviceOrderID: this._idServiceOrder
 			});
 		}

 	});
 });
