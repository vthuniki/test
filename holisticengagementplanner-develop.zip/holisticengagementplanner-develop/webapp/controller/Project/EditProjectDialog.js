sap.ui.define([
	"com/sap/ui/hep/controller/Project/BaseProjectDialog",
	"com/sap/ui/hep/util/engagementSelection/EngagementSelection",
	"com/sap/ui/hep/reuse/BaseRequest",
	"com/sap/ui/hep/util/employeeSelection/EmployeeSelection",
	"sap/m/MessageBox",
	"com/sap/ui/hep/reuse/Constants"

], function (BaseProjectDialog, EngagementSelection, BaseRequest, EmployeeSelection, MessageBox, Constants) {

	"use strict";

	return BaseProjectDialog.extend("com.sap.ui.hep.controller.Project.EditProjectDialog", {

		EmployeeSelection1: EmployeeSelection,

		fnEditProjectDialogOpen: function (oContext, oResourceBundle, oProjectData) {
			this._oContext = oContext;
			this._oView = oContext.getView();
			this._oResourceBundle = oResourceBundle;
			this.sInitiativeIdOriginal = oProjectData.ProjectMethodology;

			this._initializeModels();
			this._triggerRequestsToBEForInitialSetup();

			this._pDialogEditProject ??= this._loadFragment(this, oContext.getView(), "com.sap.ui.hep.view.Project.DialogEditProject");
			this._pDialogEditProject.then(oDialog => {
				oDialog.addStyleClass("sapUiSizeCompact");
				oDialog.setModel(this._modelProjectDialog, "modelProjectDialog");
				this._oView.byId("idIconTabBarNoIcons").setSelectedKey("keyTabProjectDetails");
				oDialog.open();
				this._fnFillFieldDataAfterOpen(oProjectData);
				this._fnValidateAndSetTabsAndSaveBtnState();
			});
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ========================================== Initialization ========================================================= */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_initializeModels: function () {
			this._initializeModelProjectDialog(); //_modelProjectDialog
		},

		_fnFillFieldDataAfterOpen: function (oProjectData) {
			this._oOldProjectData = oProjectData;
			this._modelProjectDialog.getData().sProjectGuid = oProjectData.ProjectGUID;
			this._modelProjectDialog.getData().sProjectId = oProjectData.ProjectID;
			this._modelProjectDialog.getData().sGlobalUltimateId = oProjectData.GlobalUltimateID;
			this._modelProjectDialog.getData().sTqmId = oProjectData.TqmID;
			this._modelProjectDialog.getData().busyEditProject = false;
			this._modelProjectDialog.getData().minDateGoLive = this._fnAddOneDay(oProjectData.ProjectStartDate);
			this._modelProjectDialog.getData().maxDateGoLive = oProjectData.ProjectEndDate;

			this._modelProjectDialog.getData().sEngCaseId = oProjectData.ParentCaseID;
			this._modelProjectDialog.getData().busyEngCaseSearch = true;
			this._modelProjectDialog.getData().bStartDateAndEndDateIsSelected = !!(oProjectData.ProjectStartDate && oProjectData.ProjectEndDate);

			this._modelProjectDialog.getData().sInitiativeId = oProjectData.ProjectMethodology ? oProjectData.ProjectMethodology :
				Constants.getProjectInitiative().Operations; // ZSPROMET03 //in the crappy-data-case there is no Intiative, default it to Operations
			this._modelProjectDialog.getData().sInitiativeText = oProjectData.ProjectMethodologyText ? oProjectData.ProjectMethodologyText :
				"Operations"; //in the crappy-data-case there is no Intiative, default it to Operations

			this._modelProjectDialog.getData().sCustomerId = oProjectData.CustomerID;
			this._modelProjectDialog.getData().sCustomerName = oProjectData.CustomerName;
			this._modelProjectDialog.refresh();

			this._setUpEmployeeSelectionModule1(oProjectData.EmplRespID);

			//get Engagement Name
			this._sLastVeryifiedEngagementId = this._modelProjectDialog.getData().sEngCaseId; //here we still assume the BE data is correct and verified - but now we trigger a check
			EngagementSelection.fnGetDetailsForEngagement(this._modelProjectDialog.getData().sEngCaseId, true, (oEngCasesFound) => {
				this._modelProjectDialog.getData().busyEngCaseSearch = false;
				if (oEngCasesFound.results.length === 1) {
					this._sLastVeryifiedEngagementId = oEngCasesFound.results[0].ProjectID;
					this._modelProjectDialog.getData().sEngCaseName = oEngCasesFound.results[0].ProjectName;
				} else {
					this._sLastVeryifiedEngagementId = "";
					this._modelProjectDialog.getData().sEngCaseName = "Does not exist for this customer";
					this._parentEngCaseId = ""; //because it does not exist anyway
				}
				this._modelProjectDialog.refresh();
				this._fnValidateAndSetTabsAndSaveBtnState();
			});

			this._fnLoadProjectRatingsFromLocal();
			this._fnLoadProjectStatusFromLocal();

			this._oView.byId("idFieldProjectName").setValue(oProjectData.ProjectName);
			this._oView.byId("idFieldProjectNameCounter").setText(80 - Number(oProjectData.ProjectName.length) +
				" characters remaining");
			this._oView.byId("idFieldProjectDescription").setValue(oProjectData.ProjectDescription);
			this._oView.byId("idFieldProjectDescriptionCounter").setText(1333 - Number(oProjectData.ProjectDescription.length) +
				" characters remaining");
			if (oProjectData.ProjectMethodology === Constants.getProjectInitiative().Project)
				this._oView.byId("idFieldInitiativeTypeGroup").setSelectedIndex(0);
			else this._oView.byId("idFieldInitiativeTypeGroup").setSelectedIndex(1);
			this._oView.byId("idFieldSapInvolvement").setSelectedKey(oProjectData.SapInvolvement);
			this._oView.byId("idFieldDeploymentType").setSelectedKey(oProjectData.DeploymentType);
			this._oView.byId("idFieldProjectType").setSelectedKey(oProjectData.ProjectType);
			this._oView.byId("idFieldProjectStatus").setSelectedKey(oProjectData.StatusID);
			this._oView.byId("idFieldProjectRating").setSelectedKey(oProjectData.CaseRating);

			this._oView.byId("idFieldStartDate").setDateValue(oProjectData.ProjectStartDate);
			this._oView.byId("idFieldEndDate").setDateValue(oProjectData.ProjectEndDate);
			this._oView.byId("idFieldGoLiveDate").setDateValue(oProjectData.ProjectGoLiveDate);

			this._fnLoadProjectPhasesForInitiativeFromLocal(oProjectData.toProjectPhase.results);
		},

		/* ========================================== Load Data (Locally) ========================================================= */

		_fnLoadProjectPhasesForInitiativeFromLocal: function (aProjectPhases) {
			let oPhaseToFill;
			//load empty Phases from customizing
			let aPhasesTemplate = Constants.getProjectInitiativePhases()[this._modelProjectDialog.getData().sInitiativeId];
			aPhasesTemplate.forEach(function (elm) {
				elm.PhaseStartDate = null;
				elm.PhaseEndDate = null;
			});

			if (aProjectPhases) {
				//fill phases from Project into template
				aProjectPhases.forEach(oProjectPhase => {
					oPhaseToFill = aPhasesTemplate.find(oTemplatePhase => oProjectPhase.PhaseID === oTemplatePhase.PhaseID);
					if (oPhaseToFill) {
						oPhaseToFill.PhaseStartDate = oProjectPhase.PhaseStartDate;
						oPhaseToFill.PhaseEndDate = oProjectPhase.PhaseEndDate;
					}
				});
			}
			this._modelProjectDialog.getData().projectPhasesList = aPhasesTemplate;
			this._modelProjectDialog.refresh();

			this._fnSetMinMaxForPhaseDates();

			this._fnValidateAndSetTabsAndSaveBtnState();
		},



		_fnLoadProjectStatusFromLocal: function () {
			this._modelProjectDialog.getData().projectStatusList = Constants.getItemStatus();
			this._modelProjectDialog.refresh();
		},





		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ============================================ Event Handler (except "save") ======================================== */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		fnHandleCancelPress: function () {
			if (!this.sInitiativeIdOriginal) {
				if (this._modelProjectDialog.getData().sEngCaseId)
					sap.ui.core.UIComponent.getRouterFor(this._oContext).navTo("EngagementDetails", {
						engagementID: this._modelProjectDialog.getData().sEngCaseId
					});
				else sap.ui.core.UIComponent.getRouterFor(this._oContext).navTo("Home");
			}
			this._pDialogEditProject.then(oDialog => oDialog.close());
		},

		/* ============================================ Event Handler - Field Specific ========================================= */

		fnHandleProjectNameChanged: function (oEvent) {
			this._oView.byId("idFieldProjectNameCounter").setText(80 - Number(oEvent.getParameter("value").length) +
				" characters remaining");
			this._fnValidateAndSetTabsAndSaveBtnState();
		},

		fnHandleProjectDescriptionChanged: function (oEvent) {
			this._oView.byId("idFieldProjectDescriptionCounter").setText(1333 - Number(oEvent.getParameter("value").length) +
				" characters remaining");
			this._fnValidateAndSetTabsAndSaveBtnState();
		},

		fnHandleProjectTypeChanged: function (oEvent) {
			this._fnValidateAndSetTabsAndSaveBtnState();
		},

		fnHandleDeploymentTypeChanged: function (evt) {
			this._fnValidateAndSetTabsAndSaveBtnState();
		},

		fnHandleSapInvolvementChanged: function (evt) {
			this._fnValidateAndSetTabsAndSaveBtnState();
		},

		fnHandleEngCaseChanged: function (evt) {
			let oModelEditProject = this._modelProjectDialog;
			if (oModelEditProject.getData().sEngCaseId && oModelEditProject.getData().sEngCaseId.length > 0) {
				oModelEditProject.getData().sEngCaseName = "";
				oModelEditProject.getData().busyEngCaseSearch = true;
				oModelEditProject.refresh();

				EngagementSelection.fnGetDetailsForEngagement(evt.getParameter("newValue"), false, (oEngCasesFound) => {
					oModelEditProject.getData().busyEngCaseSearch = false;
					oModelEditProject.refresh();
					if (oEngCasesFound.results.length === 1) {
						this._sLastVeryifiedEngagementId = oEngCasesFound.results[0].ProjectID;
						oModelEditProject.getData().sEngCaseId = oEngCasesFound.results[0].ProjectID;
						oModelEditProject.getData().sEngCaseName = oEngCasesFound.results[0].ProjectName;
						this._fnValidateAndSetTabsAndSaveBtnState();
					} else {
						this._sLastVeryifiedEngagementId = "";
						//given ID not clear, open the Engagement-Selection Popup and prefill the given ID
						let oInitialFilterValues = {
							CaseId: oModelEditProject.getData().sEngCaseId
						};
						this._fnValidateAndSetTabsAndSaveBtnState();
						this.fnOnValueHelpEngagementCase(undefined, oInitialFilterValues);
					}
				});
			} else {
				//user has emptied field EngCaseId...
				oModelEditProject.getData().sEngCaseName = "";
				oModelEditProject.refresh();
				this._fnValidateAndSetTabsAndSaveBtnState();
			}
		},

		fnHandleProjectStartDateChanged: function (evt) {
			let oModelEditProject = this._modelProjectDialog;
			if (evt.getParameter("valid") && evt.getParameter("value") !== "") {
				if (this._oView.byId("idFieldEndDate").getDateValue()) {
					oModelEditProject.getData().projectPhasesList[0].PhaseStartDate = evt.getSource().getDateValue();
					oModelEditProject.getData().projectPhasesList[oModelEditProject.getData().projectPhasesList.length - 1].PhaseEndDate =
						this._oView.byId("idFieldEndDate").getDateValue();
				}
				this._fnSetMinMaxForPhaseDates();
				this._oView.byId("idFieldEndDate").setMinDate(this._fnAddOneDay(this._oView.byId("idFieldStartDate").getDateValue()));
				oModelEditProject.getData().bStartDateAndEndDateIsSelected = !!this._oView.byId("idFieldEndDate").getDateValue();
				oModelEditProject.refresh();
				this._clearProjectDateIfNotValid("idFieldEndDate");
			} else {
				oModelEditProject.getData().bStartDateAndEndDateIsSelected = false;
			}
			this._setMinMaxDateForGoLive();
			this._clearProjectDateIfNotValid("idFieldGoLiveDate");

			oModelEditProject.getData().aBackupOfInitiativeProjectPhases = null;
			oModelEditProject.getData().aBackupOfInitiativeOperationsPhases = null;

			this._fnValidateAndSetTabsAndSaveBtnState();
		},

		fnHandleProjectEndDateChanged: function (evt) {
			if (evt.getParameter("valid") && evt.getParameter("value") !== "") {
				if (this._oView.byId("idFieldStartDate").getDateValue()) {
					this._modelProjectDialog.getData().projectPhasesList[0].PhaseStartDate = this._oView.byId("idFieldStartDate").getDateValue();
					this._modelProjectDialog.getData().projectPhasesList[this._modelProjectDialog.getData().projectPhasesList.length - 1].PhaseEndDate =
						evt.getSource().getDateValue();
				}
				this._fnSetMinMaxForPhaseDates();
				this._modelProjectDialog.getData().bStartDateAndEndDateIsSelected = !!this._oView.byId("idFieldStartDate").getDateValue();
				this._modelProjectDialog.refresh();
			} else {
				this._modelProjectDialog.getData().bStartDateAndEndDateIsSelected = false;
			}
			this._setMinMaxDateForGoLive();
			this._clearProjectDateIfNotValid("idFieldGoLiveDate");

			this._modelProjectDialog.getData().aBackupOfInitiativeProjectPhases = null;
			this._modelProjectDialog.getData().aBackupOfInitiativeOperationsPhases = null;

			this._fnValidateAndSetTabsAndSaveBtnState();
		},

		fnHandleInitiativeSelect: function (oEvent) {
			if (oEvent.getSource().getSelectedButton().getId().includes("idInitiativeOperations")) this._fnHandleInitiativeSelectOperations();
			if (oEvent.getSource().getSelectedButton().getId().includes("idInitiativeProject")) this._fnHandleInitiativeSelectProject();
			this._modelProjectDialog.refresh();
			this._fnValidateAndSetTabsAndSaveBtnState();
			this._fnSetMinMaxForPhaseDates();
		},

		_fnHandleInitiativeSelectOperations: function () {
			let oModelEditProject = this._modelProjectDialog;
			//initiative "Operations" selected
			oModelEditProject.getData().sInitiativeId = Constants.getProjectInitiative().Operations; // ZSPROMET03
			oModelEditProject.getData().sInitiativeText = "Operations";
			//backup data belonging to previous initiative "Project"
			oModelEditProject.getData().sBackupOfProjectType = this._oView.byId("idFieldProjectType").getSelectedKey();
			oModelEditProject.getData().sBackupOfGoLiveDate = this._oView.byId("idFieldGoLiveDate").getDateValue();
			oModelEditProject.getData().aBackupOfInitiativeProjectPhases = Object.values($.extend(true, {}, oModelEditProject.getData()
				.projectPhasesList));
			//load fresh phases table for the new initiative (Operations) from customizing
			this._fnLoadProjectPhasesForInitiativeFromLocal();
			//if already phases are backed up for "Operations", take them and overwrite the fresh phases and clear the backup
			if (oModelEditProject.getData().aBackupOfInitiativeOperationsPhases?.length) {
				oModelEditProject.getData().projectPhasesList = oModelEditProject.getData().aBackupOfInitiativeOperationsPhases;
				oModelEditProject.getData().aBackupOfInitiativeOperationsPhases = null;
			}
			//in case "start date of the first phase" is still empty, set it to the project start date, in case that exists
			if (this._oView.byId("idFieldStartDate").getDateValue() && !oModelEditProject.getData().projectPhasesList[0].PhaseStartDate) {
				oModelEditProject.getData().projectPhasesList[0].PhaseStartDate = this._oView.byId("idFieldStartDate").getDateValue();
			}
			//in case "end date of the last phase" is still empty, set it to the project end date, in case that exists
			if (this._oView.byId("idFieldEndDate").getDateValue() && !oModelEditProject.getData().projectPhasesList[oModelEditProject
				.getData().projectPhasesList.length - 1].PhaseEndDate) {
				oModelEditProject.getData().projectPhasesList[oModelEditProject.getData().projectPhasesList.length - 1].PhaseEndDate =
					this._oView.byId("idFieldEndDate").getDateValue();
			}
			//clear fields that do not exist for "Operations"
			this._oView.byId("idFieldProjectType").setSelectedKey(null);
			this._oView.byId("idFieldGoLiveDate").setDateValue(null);
		},

		_fnHandleInitiativeSelectProject: function () {
			let oModelEditProject = this._modelProjectDialog;
			//initiative "Project" selected
			oModelEditProject.getData().sInitiativeId = Constants.getProjectInitiative().Project; //ZSPROMET04
			oModelEditProject.getData().sInitiativeText = "Project";
			//backup data belonging to previous initiative "Operations"
			oModelEditProject.getData().aBackupOfInitiativeOperationsPhases = Object.values($.extend(true, {}, oModelEditProject
				.getData().projectPhasesList));
			//load fresh phases table for the new initiative (Project) from customizing
			this._fnLoadProjectPhasesForInitiativeFromLocal();
			//if already phases dates are backed up for "Project", take them and overwrite the fresh phases and clear the backup
			if (oModelEditProject.getData().aBackupOfInitiativeProjectPhases?.length) {
				oModelEditProject.getData().projectPhasesList = oModelEditProject.getData().aBackupOfInitiativeProjectPhases;
				oModelEditProject.getData().aBackupOfInitiativeProjectPhases = null;
			}
			//also apply backed up data for ProjectType and GoLiveDate
			if (oModelEditProject.getData().sBackupOfProjectType) {
				this._oView.byId("idFieldProjectType").setSelectedKey(oModelEditProject.getData().sBackupOfProjectType);
			}
			if (oModelEditProject.getData().sBackupOfGoLiveDate) {
				this._oView.byId("idFieldGoLiveDate").setDateValue(oModelEditProject.getData().sBackupOfGoLiveDate);
			}
			//in case "start date of the first phase" is still empty, set it to the project start date, in case that exists
			if (this._oView.byId("idFieldStartDate").getDateValue() && !oModelEditProject.getData().projectPhasesList[0].PhaseStartDate) {
				oModelEditProject.getData().projectPhasesList[0].PhaseStartDate = this._oView.byId("idFieldStartDate").getDateValue();
			}
			//in case "end date of the last phase" is still empty, set it to the project end date, in case that exists
			if (this._oView.byId("idFieldEndDate").getDateValue() && !oModelEditProject.getData().projectPhasesList[oModelEditProject
				.getData().projectPhasesList.length - 1].PhaseEndDate) {
				oModelEditProject.getData().projectPhasesList[oModelEditProject.getData().projectPhasesList.length - 1].PhaseEndDate =
					this._oView.byId("idFieldEndDate").getDateValue();
			}
		},

		fnHandleProjectGoLiveDateChanged: function (evt) {
			this._fnValidateAndSetTabsAndSaveBtnState();
		},

		/**
		 *  In case the user changes the start date of a phase, the requirement is that the end date of the
		 *  previous phase is also changed. The previous phase has to end the day before this phase starts now.
		 *
		 */
		fnHandlePhaseStartDateChange: function (oEvent) {
			this._fnHandlePhaseStartDateChange(oEvent);
			this._fnValidateAndSetTabsAndSaveBtnState();
		},

		/**
		 *  In case the user changes the end date of a phase, the requirement is that the start date of the
		 *  next phase is also changed. The next phase has to start the day after this phase ends now.
		 *
		 */
		fnHandlePhaseEndDateChange: function (oEvent) {
			this._fnHandlePhaseEndDateChange(oEvent);
			this._fnValidateAndSetTabsAndSaveBtnState();
		},

		fnHandleWarningPhasesProblemFurtherInfoPressed: function () {
			MessageBox.information(this._oResourceBundle.getText("Project.WarningPhasesTableProblemAdditionalInfo"));
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ===========================================   Validation   ======================================================== */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_fnValidateAndSetTabsAndSaveBtnState: function () {
			let bTabDetailsValid = this._fnIsTabValid("idTabProjectDetails");
			let bTabDatesValid = this._fnIsTabValid("idTabProjectDates");

			this._fnAdjustTabDesign("idTabProjectDetails", bTabDetailsValid);
			this._fnAdjustTabDesign("idTabProjectDates", bTabDatesValid);
			this._oView.byId("idBtnSave").setEnabled(bTabDetailsValid && bTabDatesValid);
			return bTabDetailsValid && bTabDatesValid;
		},

		_fnIsTabValid: function (sTabId) { //check one Tab
			if (sTabId === "idTabProjectDetails") {
				this._fnSetFieldsValueState(null, true, false); //validate tab1-fields...
				for (let key in this._modelProjectDialog.getData().fieldValueStatesTab1) { //...evaluation
					if (this._modelProjectDialog.getData().fieldValueStatesTab1[key] === "Error") return false;
				}
			} else {
				this._fnSetFieldsValueState(null, false, true); //validate tab2-fields...
				this._fnPhasesTableRespectsAllRules(); //validate phases table
				for (let key in this._modelProjectDialog.getData().fieldValueStatesTab2) { //...evaluation
					if (this._modelProjectDialog.getData().fieldValueStatesTab2[key] === "Error") return false;
				}
			}
			return true;
		},

		_fnAdjustTabDesign: function (sTabId, bTabIsValid) { //idTabProjectDates OR idTabProjectDetails
			if (bTabIsValid) {
				this._oView.byId(sTabId).setIconColor("Default"); //makes it normal color
				this._oView.byId(sTabId).setText(this._oResourceBundle.getText("Project.TabDefaultDesignText." + sTabId));
			} else {
				this._oView.byId(sTabId).setIconColor("Critical"); //makes it red
				this._oView.byId(sTabId).setText(this._oResourceBundle.getText("Project.TabRequiredDesignText." + sTabId));
			}
		},

		_fnPhasesTableRespectsAllRules: function () {
			let dPointer = new Date(0); //1970
			let bAtLeastOneDayBetweenDates = true;
			let bGapsBetweenPhases = false;

			//check that at least one day lays between all each other following dates
			//(Howerver, dates can look like there lays a day betweem them, but technically this is not the case. I.e.:
			//   StartDate = 7.1.2022-19:00:00 ------- EndDate = 8.1.2022-05:00:00
			//This would be noticed as problem, but it should ignored, as long as it looks correct for the user. So as long as the day is one bigger
			//So we do not check if (StartDate + 1 Day > EndDate), but if (StartDate-00:00:00 + 1 Day > EndDate-00:00:00 )
			//)
			this._modelProjectDialog.getData().projectPhasesList.forEach(oPhase => {
				oPhase.valueStateSD = "None";
				oPhase.valueStateED = "None";
				if (oPhase.PhaseStartDate) {
					if (new Date(new Date(oPhase.PhaseStartDate).setHours(0, 0, 0)) < new Date(new Date(dPointer).setHours(0, 0, 0))) {
						bAtLeastOneDayBetweenDates = false;
						oPhase.valueStateSD = "Warning";
					}
					dPointer = this._fnAddOneDay(oPhase.PhaseStartDate);
				}
				if (oPhase.PhaseEndDate) {
					if (new Date(new Date(oPhase.PhaseEndDate).setHours(0, 0, 0)) < new Date(new Date(dPointer).setHours(0, 0, 0))) {
						bAtLeastOneDayBetweenDates = false;
						oPhase.valueStateED = "Warning";
					}
					dPointer = this._fnAddOneDay(oPhase.PhaseEndDate);
				}
			});
			//now we know already if optically there is at least one day between two subsequent dates!

			//next check the gaps between enddates of previous phases and startdates of next phases should not be more than optically one day
			dPointer = new Date(0); //1970
			this._modelProjectDialog.getData().projectPhasesList.forEach((oPhase, index) => {
				if (index !== this._modelProjectDialog.getData().projectPhasesList.length - 1) {
					bGapsBetweenPhases = this.__fnHelperCheckOpticallyGapsBetweenPhases(index, oPhase, bGapsBetweenPhases);
				}
			});

			this._modelProjectDialog.getData().bShowPhaseTableWarning = !!((!bAtLeastOneDayBetweenDates || bGapsBetweenPhases));
			this._modelProjectDialog.getData().fieldValueStatesTab2.PhasesTable = (!bAtLeastOneDayBetweenDates || bGapsBetweenPhases) ? "Error" :
				"None";
			this._modelProjectDialog.refresh();
		},

		__fnHelperCheckOpticallyGapsBetweenPhases: function (index, oPhase, bGapsBetweenPhases) {
			if (oPhase.PhaseEndDate && this._modelProjectDialog.getData().projectPhasesList[index + 1].PhaseStartDate &&
				this._fnAddOneDay(new Date(oPhase.PhaseEndDate).setHours(0, 0, 0)) < new Date(new Date(this._modelProjectDialog.getData().projectPhasesList[
					index + 1].PhaseStartDate).setHours(0, 0, 0))) {
				bGapsBetweenPhases = true;
				this._modelProjectDialog.getData().projectPhasesList[index + 1].valueStateSD = "Warning";
			}
			return bGapsBetweenPhases;
		},

		_fnSetFieldsValueState: function (aFlds, bChckTab1, bChckTab2, fnCallBack) {
			const aFldsTab1 = ["idFieldProjectName", "idFieldProjectDescription", "idFieldProjectType", "idFieldDeploymentType",
				"idFieldSapInvolvement", "idFieldProjectType", "idFieldCustomerNumber", "idFieldEngagementCase", "fragmentFieldEmpResp"
			];
			const aFldsTab2 = ["idFieldStartDate", "idFieldEndDate", "idFieldGoLiveDate"];

			if (bChckTab1 && bChckTab2) aFlds = aFlds.Tab1.concat(aFldsTab2);
			else if (bChckTab1) aFlds = aFldsTab1;
			else if (bChckTab2) aFlds = aFldsTab2;
			else aFlds = aFlds || aFldsTab1.concat(aFlds);

			aFlds.forEach(elm => {
				switch (elm) {
					//____________  Tab 1 ____________
					case "idFieldProjectName":
					case "idFieldProjectDescription":
						this.__fnHelperSetFieldsValueStateTextFields(elm);
						break;
					case "idFieldProjectType":
						this.__fnHelperSetFieldsValueStateIdFieldProjectType(elm);
						break;
					case "idFieldDeploymentType":
					case "idFieldSapInvolvement":
						this.__fnHelperSetFieldsValueStateComboFields(elm);
						break;
					case "idFieldEngagementCase":
						this.__fnHelperSetFieldsValueStateIdFieldEngagementCase(elm);
						break;
					//_________________  Tab 2 _________________
					case "idFieldStartDate":
					case "idFieldEndDate":
						this.__fnHelperSetFieldsValueStateDateGen(elm);
						break;
					case "idFieldGoLiveDate":
						this.__fnHelperSetFieldsValueStateIdFieldGoLiveDate(elm);
						break;
				}
			});
			this._modelProjectDialog.refresh();
		},

		__fnHelperSetFieldsValueStateIdFieldEngagementCase: function (elm) {
			let oModelEditProject = this._modelProjectDialog;
			oModelEditProject.getData().fieldValueStatesTab1[elm] = "None";
			oModelEditProject.getData().fieldValueStateTextsTab1[elm] = "";
			if (!this._oView.byId(elm).getValue()) {
				oModelEditProject.getData().fieldValueStatesTab1[elm] = "Error";
				oModelEditProject.getData().fieldValueStateTextsTab1[elm] = this._oResourceBundle.getText(
					"Project.MsgError" + elm);
			} else if (this._sLastVeryifiedEngagementId !== this._oView.byId(elm).getValue()) { //to reduce number of BE calls
				oModelEditProject.getData().busyEngCaseSearch = true;
				oModelEditProject.refresh();
				EngagementSelection.fnGetDetailsForEngagement(this._oView.byId(elm).getValue(), true, (oData) => {
					this._modelProjectDialog.getData().busyEngCaseSearch = false;
					this._modelProjectDialog.refresh();
					if (oData.results.length !== 1) {
						this._sLastVeryifiedEngagementId = "";
						this._modelProjectDialog.getData().fieldValueStatesTab1[elm] = "Error";
						this._modelProjectDialog.getData().fieldValueStateTextsTab1[elm] = "Entered value is not a valid Engagement Case";
						this._modelProjectDialog.refresh();
					} else {
						this._sLastVeryifiedEngagementId = this._oView.byId(elm).getValue();
						this._modelProjectDialog.getData().fieldValueStatesTab1[elm] = "None";
						this._modelProjectDialog.getData().fieldValueStateTextsTab1[elm] = "";
						this._modelProjectDialog.refresh();
					}
				});
			}
		},


		/* =================================================================================================================== */
		/*=======================================================================================================================*/
		/*========================================= Search Help - Engagement Case ===============================================*/
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		fnOnValueHelpEngagementCase: function (oEvent, oInitialFilterValues) {
			let oResourceBundle = this._oResourceBundle;
			let oView = this._oView;

			let oFilterValues = {};
			Object.assign(oFilterValues, oInitialFilterValues, {
				CustomerBpId: this._modelProjectDialog.getData().sCustomerId,
				CustomerName: this._modelProjectDialog.getData().sCustomerName,
				sDialogWidth: "1200px",
				sDialogHeight: "770px",
				ExactCustomerId: true,
				DisableCustomerFields: false,
				DisableReasonCombo: true,
				ReasonCode: "ENG2" //default - allow no other option

			});
			this._modelProjectDialog.getData().busyEngCaseSearch = true;
			this._modelProjectDialog.refresh();
			EngagementSelection.fnEngagementSelectionDialogOpen(oView, oResourceBundle, oFilterValues, (oSelectedEngCase) => {
				this._modelProjectDialog.getData().busyEngCaseSearch = false;
				this._modelProjectDialog.refresh();
				if (oSelectedEngCase) {
					this._sLastVeryifiedEngagementId = oSelectedEngCase.ProjectID;
					this._modelProjectDialog.getData().sEngCaseId = oSelectedEngCase.ProjectID;
					this._modelProjectDialog.getData().sEngCaseName = oSelectedEngCase.ProjectName;
					this._modelProjectDialog.refresh();
				} else {
					this._sLastVeryifiedEngagementId = "";
				}
				this._fnValidateAndSetTabsAndSaveBtnState();
			});
		},

		/* =================================================================================================================== */
		/*=====================================================================================================================*/
		/*========================================= Search Help - Person Responsible ==========================================*/
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_setUpEmployeeSelectionModule1: function (sInitialEmployeeId) {
			let oEmployeeSelectionCustomizing = {
				sInputFragmentId: "idFragmentEmployeeIdDialogCreateProject", //the name you have given to the fragment that you put into your view
				bInputFragmentHasTextField: true, //you are either using the fragment for forms or the simple one ... the later does not have the "EmployeeName"-field and no grid-layout setup
				sValueHelpFragmentId: "EmployeeSelection2", //a string that the module uses to prefix the ids of the value help fragment fields
				sDialogWidth: "1200px", //dimensions of the value help dialog
				sDialogHeight: "770px", //dimensions of the value help dialog
				sEmployeeIdFieldGridSpan: "XL3 L3 M3 S3", //only in case of using the form-fragment
				sEmployeeNameFieldGridSpan: "XL6 L6 M6 S6", //only in case of using the form-fragment
				bEmployeeIdRequired: true, //puts a red asterisk to the input field and takes care the the value state is set to error
				bEmployeeTextFieldVisible: true, //it is also possible to use the form-fragment, but to hide the EmployeeName field from the user
				fnCallBackAfterValueChange: (oNewEmployee, sValueState, bInputFieldSubmit) => {
					//define what needs to happen in your view controller, when the Employee has changed....
					this._modelProjectDialog.getData().fieldValueStatesTab1.fragmentFieldPersonResponsible = sValueState;
					this._fnValidateAndSetTabsAndSaveBtnState();
					this._oPersonResponsibleSelected = oNewEmployee;
				}
			};

			//get your instance and then initialize it
			if (!this.EmployeeSelection2) this.EmployeeSelection2 = new EmployeeSelection();
			this.EmployeeSelection2.fnInitialize(this._oView, oEmployeeSelectionCustomizing, sInitialEmployeeId);
		},

		/* =================================================================================================================== */
		/*=====================================================================================================================*/
		/*=========================================   SAVE Project and Phases   ===============================================*/
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		fnHandleSavePress: function (evt) {
			// in case the user has closed the project we cannot save the project in BE and afterwards update the phases of it,
			// because BE would not allow to change the phases of a closed project.
			// So we FIRST have to save the phases in this case, and in the end save the project.
			// (normally we do it the other way round, so first save the project and then save the phases, in case the project
			// could be successfully changed.)
			this._bErrorSavingPhases = false;
			this._fnClearAllMessages();

			//show progress indicator
			this._fnShowProgressIndicator();

			//now start saving, but depending on wheather the project is closed, take a different order when saving (but ignore that in the progress indicator :-) )
			if (this._oView.byId("idFieldProjectStatus").getSelectedKey() === "90") { //status set to closed
				this._fnDeleteAllProjectPhases().then(() => {
					this._fnSaveOneRowOfPhasesTable(0).then(() => {
						this._fnSaveProject().then(() => {
							this._oDialogProgressIndicator.close();
							this._modelProjectDialog.getData().busyEditProject = false;
							this._modelProjectDialog.refresh();
							this._oContext.fnRefreshProjectDetails(); //update the main project screen
							this._pDialogEditProject.then(oDialog => oDialog.close());
						});
					});
				});
			} else { //normal case is that status is not set to closed
				this._fnSaveProject().then(() => {
					this._fnDeleteAllProjectPhases().then(() => {
						this._fnSaveOneRowOfPhasesTable(0).then(() => {
							this._oDialogProgressIndicator.close();
							this._modelProjectDialog.getData().busyEditProject = false;
							this._modelProjectDialog.refresh();
							if (this._bErrorSavingPhases) MessageBox.error(
								"At least one of the phases could not be saved. Please check and save again.");
							else {
								this._oContext.fnRefreshProjectDetails(); //update the main project screen
								this._pDialogEditProject.then(oDialog => oDialog.close());
							}
						});
					});
				});
			}
		},



		_fnSaveProject: function () {
			return new Promise((resolve, reject) => {
				if (this._fnValidateAndSetTabsAndSaveBtnState()) { //returns TRUE if everything is correct!
					this._modelProjectDialog.getData().busyEditProject = true;
					this._modelProjectDialog.refresh();
					let entities = {};
					entities.servicePath = Constants.getServicePath();
					entities.entitySet = "ProjectSet";
					entities.getEntity = this._modelProjectDialog.getData().sProjectId;
					entities.data = this._fnPrepareDataForSaveProjectDetails();
					entities.currentView = this._oView;
					entities.oContext = this._oContext;
					entities.errorMessage = this._oResourceBundle.getText("ProjectDetails.UpdateProjectError");
					entities.callbackUnsetBusyIndicator = () => {
						this._modelProjectDialog.getData().busyEditProject = false;
						this._modelProjectDialog.refresh();
					};
					entities.callbackSuccess = (oData) => {
						this._oContext.getOwnerComponent().trackEvent("Edit_Project");
						resolve();
					};
					BaseRequest.handleUpdate(entities);
				}
			});
		},

		_fnDeleteAllProjectPhases: function () {
			return new Promise((resolve, reject) => {
				let oParams = {};
				oParams.servicePath = Constants.getServicePath();
				oParams.function = "DeleteProjectPhases";
				oParams.method = "GET";
				oParams.currentView = this._oView;
				oParams.oContext = this._oContext;
				oParams.urlParameters = {
					"ProjectID": this._modelProjectDialog.getData().sProjectId
				};
				oParams.callbackSuccess = (oData) => {
					resolve(oData);
				};
				BaseRequest.handleFunctionCall(oParams);
			});
		},

		/* recursivley save the phases for this project */
		_fnSaveOneRowOfPhasesTable: function (rowNb) {
			return new Promise((resolve, reject) => {
				let entities = {};
				let itemsOfTable = this._oView.byId("idPhasesTable").getItems();

				// update progress indicator
				if (rowNb < itemsOfTable.length) {
					this._oDialogProgressIndicator.getContent()[0].setDisplayValue("Saving Phase " + parseInt(rowNb + 1, 10) + " / " + itemsOfTable.length +
						" ");
				}
				if (itemsOfTable.length === 1) {
					this._oDialogProgressIndicator.getContent()[0].setPercentValue(60 + (parseInt(rowNb, 10) + 1) * 40);
				} else {
					this._oDialogProgressIndicator.getContent()[0].setPercentValue(28 + (parseInt(rowNb, 10) + 1) * 12);
				}

				//recursivly save rows
				if (rowNb >= itemsOfTable.length) {
					resolve();

				} else {
					entities.servicePath = Constants.getServicePath();
					entities.data = this._fnPrepareDataForSaveOneRowOfProjectPhasesTable(rowNb, itemsOfTable);

					entities.currentView = this._oView;
					entities.oContext = this._oContext;
					entities.callbackSuccess = () => {

						resolve(this._fnSaveOneRowOfPhasesTable(rowNb + 1));
					};
					entities.callbackError = (oError) => {
						if (oError.responseText.includes("ZS_APP_HEP/010")) this._modelProjectDialog.getData().projectPhasesList[rowNb].valueStateED =
							"Warning"; //I think other errors than this (End Date is earlier than Start Date of the Phase) are not checked by BE.
						this._oDialogProgressIndicator.getContent()[0].setState("Warning");
						this._bErrorSavingPhases = true;
						resolve(this._fnSaveOneRowOfPhasesTable(rowNb + 1));

					};

					entities.entitySet = Constants.getEntities().ProjectPhasesEntity;
					entities.data = this._fnPrepareDataForSaveOneRowOfProjectPhasesTable(rowNb, itemsOfTable);
					entities.errorMessage = this._oResourceBundle.getText("NewProject.SavePhasesNewProject");
					BaseRequest.handleCreate(entities);
					//}
				}
			});
		},

		_fnPrepareDataForSaveOneRowOfProjectPhasesTable: function (rowNb, itemsOfTable) {
			let dataForOneRow = {},
				PhaseStartDate = this._modelProjectDialog.getData().projectPhasesList[rowNb].PhaseStartDate,
				PhaseEndDate = this._modelProjectDialog.getData().projectPhasesList[rowNb].PhaseEndDate;

			dataForOneRow = {
				"ProjectID": this._modelProjectDialog.getData().sProjectId,
				"PhaseNo": this._modelProjectDialog.getData().projectPhasesList[rowNb].PhaseNo,
				"PhaseID": this._modelProjectDialog.getData().projectPhasesList[rowNb].PhaseID,
				"PhaseStartDate": PhaseStartDate === null ? null : PhaseStartDate,
				"PhaseEndDate": PhaseEndDate === null ? null : PhaseEndDate
			};
			return dataForOneRow;
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* =========================================== Little Helpers ======================================================== */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_fnClearAllMessages: function () {
			this._oView.getController().messageHandler.clearAllMessages(this._oView, this._oView.getController().oMessagePopover);
		},

		/**
		 * The logic in the method _fnSetMinMaxForPhaseDatesOLDButGood is too strict, because we have crappy data in the DB.
		 * The logic would then set the min and max dates according to the same logic like for creation, but when opening an exising
		 * project, it's crappy phase dates would conflict and so those would be cleared by the method.
		 * The user would not know if the date is really empty, or was just cleared by the logic
		 * So the decision from business was to simplify the logic and only set the project's Start- and End-Date to all
		 * phase date fields as min- and max-dates
		 */
		_fnSetMinMaxForPhaseDates: function () {
			//set the min- and max-dates for all fields of the phases table (set them to the extremes, because maybe Project-Start/End has times set)
			let dMin = new Date(new Date(this._oView.byId("idFieldStartDate").getDateValue()).setHours(0, 0, 0));
			let dMax = new Date(new Date(this._oView.byId("idFieldEndDate").getDateValue()).setHours(23, 59, 59));

			this._modelProjectDialog.getData().projectPhasesList.forEach(oPhase => {
				oPhase.disabledSD = false;
				oPhase.disabledED = false;

				if (oPhase.PhaseStartDate && (oPhase.PhaseStartDate < dMin || oPhase.PhaseStartDate > dMax)) {
					oPhase.PhaseStartDate = null;
				}
				oPhase.startDateMin = dMin;
				oPhase.startDateMax = dMax;

				if (oPhase.PhaseEndDate && (oPhase.PhaseEndDate < dMin || oPhase.PhaseEndDate > dMax)) {
					oPhase.PhaseEndDate = null;
				}
				oPhase.endDateMin = dMin;
				oPhase.endDateMax = dMax;
			});

			this._modelProjectDialog.refresh();
		}

	});
});