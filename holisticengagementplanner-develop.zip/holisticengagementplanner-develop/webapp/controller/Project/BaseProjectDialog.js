sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"com/sap/ui/hep/reuse/BaseRequest",
	"com/sap/ui/hep/reuse/BaseTools",
	"sap/m/Dialog",
	"sap/m/ProgressIndicator",
	"com/sap/ui/hep/reuse/Constants",

], function (sapUiBaseObject, JSONModel, BaseRequest, BaseTools, Dialog, ProgressIndicator, Constants) {

	return sapUiBaseObject.extend("com.sap.ui.hep.controller.Project.BaseProjectDialog", {
		_loadFragment: function (oFragmentController, oView, sFragmentPath, fnInitialCallback) {
			return BaseTools.loadFragment(oFragmentController, oView, sFragmentPath, fnInitialCallback);
		},

		_fnNavigateToEngagement: function (sCaseId, sToTab = "") {
			BaseTools.fnNavigateToEngagement(sCaseId, sToTab);
		},

		_fnNavigateToProject: function (sProjectId, sProjectType, sProjectStatusId) {
			BaseTools.fnNavigateToProject(sProjectId, sProjectType, sProjectStatusId);
		},

		_removeOneDay: function (dDate) {
			let dDateMinusOneDay = new Date(dDate);
			dDateMinusOneDay.setDate(dDateMinusOneDay.getDate() - 1);
			return dDateMinusOneDay;
		},

		_fnAddOneDay: function(dDate){
			return BaseTools.fnAddOneDay(dDate);
		},

		_initializeModelProjectDialog: function () {
			/* "_modelProjectDialog" is the main model for the Dialog, it holds everything*/
			this._modelProjectDialog = new JSONModel({});
			this._modelProjectDialog.getData().fieldValueStatesTab1 = {};
			this._modelProjectDialog.getData().fieldValueStatesTab2 = {};
			this._modelProjectDialog.getData().fieldValueStateTextsTab1 = {};
			this._modelProjectDialog.getData().fieldValueStateTextsTab2 = {};
			this._modelProjectDialog.getData().sapInvolvementsList = {};
			this._modelProjectDialog.getData().deploymentTypesList = {};
			this._modelProjectDialog.getData().projectTypesList = {};
			this._modelProjectDialog.getData().projectPhasesList = {};
			this._modelProjectDialog.getData().projectRatingsList = {};
			this._modelProjectDialog.getData().projectStatusList = {};

			this._modelProjectDialog.getData().projectRating = ""; //this needs to be done already here, otherwise
			//there is a console error, in case the user opens the dialog a second time

			this._modelProjectDialog.refresh();

		},

		_fnLoadProjectRatingsFromLocal: function () {
			let oView = this._oView;
			if (oView.byId("idFieldProjectRating").getCustomData().length === 0) {
				oView.byId("idFieldProjectRating").addCustomData(new sap.ui.core.CustomData({
					writeToDom: true,
					key: "iconProjectRating",
					value: "{modelProjectDialog>/projectRating}"
				}));
				if (oView.byId("idFieldProjectRating").getBindingInfo("items").template.getCustomData().length === 0) {
					oView.byId("idFieldProjectRating").getBindingInfo("items").template.addCustomData(new sap.ui.core.CustomData({
						writeToDom: true,
						key: "iconProjectRating",
						value: "{modelProjectDialog>key}"
					}));
				}
			}
			this._modelProjectDialog.getData().projectRatingsList = Constants.getCaseRatingComboValues().ratings;
			this._modelProjectDialog.refresh();
		},


		/* ========================================== Load Data (From BE) ========================================================= */

		_triggerRequestsToBEForInitialSetup: function () {
			//REMARK: all BE calls are only triggered and run then in parallel, because they don't depend on eachother
			this._getSapInvolvementsFromBE(); //fill Combovalues
			this._getDeploymentTypesFromBE(); //fill Combovalues
			this._getProjectTypesFromBE(); //fill Combovalues
		},

		_getProjectTypesFromBE: function () {
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = Constants.getEntities().DropDownEntity;
			entities.filter = "Type eq 'ProjectType'";
			entities.oContext = this;
			entities.errorMessage = this._oResourceBundle.getText("NewProject.ProjectTypeError");
			entities.callbackSuccess = (data) => {
				this._modelProjectDialog.getData().projectTypesList = data.results;
				this._modelProjectDialog.refresh();

			};
			BaseRequest.handleRead(entities);
		},

		_getSapInvolvementsFromBE: function () {
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "DropDownListSet";
			entities.oContext = this;
			entities.filter = "Type eq 'SapInvolvement'";
			entities.busyIndicator = "busySapInvolvementDropdown";
			entities.callbackSuccess = (data) => {
				this._modelProjectDialog.getData().sapInvolvementsList = data.results;
				this._modelProjectDialog.refresh();
			};
			BaseRequest.handleRead(entities);
		},

		_getDeploymentTypesFromBE: function () {
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "DropDownListSet";
			entities.oContext = this;
			entities.filter = "Type eq 'DeploymentType'";
			entities.busyIndicator = "busyDeploymentTypeDropdown";
			entities.callbackSuccess = (data) => {
				this._modelProjectDialog.getData().deploymentTypesList = data.results;
				this._modelProjectDialog.refresh();
			};
			BaseRequest.handleRead(entities);
		},

		/* ========================================== Event Handler  ========================================================= */

		_fnHandlePhaseStartDateChange: function (oEvent) {
			oEvent.getSource().setValueState(null);
			this._fnSetMinMaxForPhaseDates();

			if (oEvent.getSource().getDateValue()) {
				//try set EndDate of Previous Phase to previous day
				let iIndexThisPhase = parseInt(oEvent.getSource().getBindingContext("modelProjectDialog").getPath().split("/")[2], 10);
				let oPreviousPhase;
				if (typeof (iIndexThisPhase) === "number" && iIndexThisPhase > 0)
					oPreviousPhase = this._modelProjectDialog.getData().projectPhasesList[iIndexThisPhase - 1];
				if (oPreviousPhase) {
					oPreviousPhase.PhaseEndDate = this._removeOneDay(oEvent.getSource().getDateValue());
					this._fnSetMinMaxForPhaseDates();
				}
			}
		},

		_fnHandlePhaseEndDateChange: function (oEvent) {
			oEvent.getSource().setValueState(null);
			this._fnSetMinMaxForPhaseDates();

			if (oEvent.getSource().getDateValue()) {
				//try set StartDate of Next Phase to next day
				let iIndexThisPhase = parseInt(oEvent.getSource().getBindingContext("modelProjectDialog").getPath().split("/")[2], 10);
				let oNextPhase;
				if (typeof (iIndexThisPhase) === "number") oNextPhase = this._modelProjectDialog.getData().projectPhasesList[iIndexThisPhase + 1];
				if (oNextPhase) {
					oNextPhase.PhaseStartDate = this._fnAddOneDay(oEvent.getSource().getDateValue());
					this._fnSetMinMaxForPhaseDates();
				}
			}
		},


		/* ========================================== Field Validation Helper ========================================================= */

		__fnHelperSetFieldsValueStateComboFields: function (elm) {
			this._modelProjectDialog.getData().fieldValueStatesTab1[elm] = sap.ui.core.ValueState.None;
			this._modelProjectDialog.getData().fieldValueStateTextsTab1[elm] = "";
			if (!this._oView.byId(elm).getSelectedKey()) {
				this._modelProjectDialog.getData().fieldValueStatesTab1[elm] = sap.ui.core.ValueState.Error;
				this._modelProjectDialog.getData().fieldValueStateTextsTab1[elm] = this._oResourceBundle.getText(
					"Project.MsgError" + elm);
			}
		},

		__fnHelperSetFieldsValueStateTextFields: function (elm) {
			this._modelProjectDialog.getData().fieldValueStatesTab1[elm] = sap.ui.core.ValueState.None;
			this._modelProjectDialog.getData().fieldValueStateTextsTab1[elm] = "";
			if (!this._oView.byId(elm).getValue()) {
				this._modelProjectDialog.getData().fieldValueStatesTab1[elm] = sap.ui.core.ValueState.Error;
				this._modelProjectDialog.getData().fieldValueStateTextsTab1[elm] = this._oResourceBundle.getText(
					"Project.MsgError" + elm);
			}
		},

		__fnHelperSetFieldsValueStateIdFieldProjectType: function (elm) {
			this._modelProjectDialog.getData().fieldValueStatesTab1[elm] = sap.ui.core.ValueState.None;
			this._modelProjectDialog.getData().fieldValueStateTextsTab1[elm] = "";
			if (this._modelProjectDialog.getData().sInitiativeText === "Project") {
				if (!this._oView.byId(elm).getSelectedKey()) {
					this._modelProjectDialog.getData().fieldValueStatesTab1[elm] = sap.ui.core.ValueState.Error;
					this._modelProjectDialog.getData().fieldValueStateTextsTab1[elm] = this._oResourceBundle.getText(
						"Project.MsgError" + elm);
				}
			}
		},

		__fnHelperSetFieldsValueStateIdFieldGoLiveDate: function (elm) {
			if (this._modelProjectDialog.getData().sInitiativeText === "Project") this.__fnHelperSetFieldsValueStateDateGen(elm);
		},

		__fnHelperSetFieldsValueStateDateGen: function (elm) {
			this._modelProjectDialog.getData().fieldValueStatesTab2[elm] = sap.ui.core.ValueState.None;
			this._modelProjectDialog.getData().fieldValueStateTextsTab2[elm] = "";
			if (!this._oView.byId(elm).getDateValue()) {
				this._modelProjectDialog.getData().fieldValueStatesTab2[elm] = sap.ui.core.ValueState.Error;
				this._modelProjectDialog.getData().fieldValueStateTextsTab2[elm] = this._oResourceBundle.getText(
					"Project.MsgError" + elm);
			}
			if (!this._oView.byId(elm).getDateValue() || !this._oView.byId(elm).isValidValue()) {
				this._modelProjectDialog.getData().fieldValueStatesTab2[elm] = sap.ui.core.ValueState.Error;
				this._modelProjectDialog.getData().fieldValueStateTextsTab2[elm] = this._oResourceBundle.getText(
					"Project.MsgErrorNotValid" + elm, [Constants.getMediumDateFormat()]);
			}
		},


		_clearProjectDateIfNotValid: function (sProjectDateControlId) {
			if (!this._oView.byId(sProjectDateControlId).isValidValue()) {
				this._oView.byId(sProjectDateControlId).setDateValue(null);
			}
		},

		_setMinMaxDateForGoLive: function () {
			let dStartDate = this._oView.byId("idFieldStartDate").getDateValue(),
				dEndDate = this._oView.byId("idFieldEndDate").getDateValue(),
				bStartDateValid = this._oView.byId("idFieldStartDate").isValidValue(),
				bEndDateValid = this._oView.byId("idFieldEndDate").isValidValue();

			if (bStartDateValid && dStartDate instanceof Date) {
				this._modelProjectDialog.getData().minDateGoLive = this._fnAddOneDay(dStartDate);
			} else {
				this._modelProjectDialog.getData().minDateGoLive = null;
			}
			if (bEndDateValid && dEndDate instanceof Date) {
				this._modelProjectDialog.getData().maxDateGoLive = dEndDate;
			} else {
				this._modelProjectDialog.getData().maxDateGoLive = null;
			}
			this._modelProjectDialog.refresh();
		},

		_fnGetOneCustomerFromBE: function (sCustomerId, fnCallBack) {
			let entities = {};
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "PFCustomerSet";
			entities.filter = "(PartnerID eq '" + sCustomerId + "')";
			entities.callbackSuccess = (oData) => {
				fnCallBack(oData);
			};
			BaseRequest.handleRead(entities);
		},

		_fnShowProgressIndicator: function () {
			this._oDialogProgressIndicator = new Dialog({
				type: "Message",
				showHeader: false,
				state: this._bErrorSavingPhases ? "Warning" : "Information",
				content: new ProgressIndicator({
					displayAnimation: false,
					displayValue: "Saving Project",
					percentValue: 28,
					state: "Success",
					displayOnly: true
				})
			});
			if (this._modelProjectDialog.getData().projectPhasesList.length === 1) this._oDialogProgressIndicator.getContent()[0].setPercentValue(60);
			this._oDialogProgressIndicator.addStyleClass("sapUiSizeCompact");
			this._oDialogProgressIndicator.open();

		},

		_fnPrepareDataForSaveProjectDetails: function () {
			let dStartDate = this._oView.byId("idFieldStartDate").getDateValue(),
				dEndDate = this._oView.byId("idFieldEndDate").getDateValue(),
				dGoLiveDate = this._oView.byId("idFieldGoLiveDate").getDateValue(),
				sProjectType = this._oView.byId("idFieldProjectType").getSelectedKey();

			//for operations-project there is no goLive-Date and deploymentType
			if (this._modelProjectDialog.getData().sInitiativeId === Constants.getProjectInitiative().Operations) {
				dGoLiveDate = null;
				sProjectType = "";
			}
			let oData = {
				"ProjectName": this._oView.byId("idFieldProjectName").getValue(),
				"ProjectDescription": this._oView.byId("idFieldProjectDescription").getValue(),
				"ProjectMethodology": this._modelProjectDialog.getData().sInitiativeId,
				"ProjectType": sProjectType,
				"DeploymentType": this._oView.byId("idFieldDeploymentType").getSelectedKey(),
				"SapInvolvement": this._oView.byId("idFieldSapInvolvement").getSelectedKey(),
				"StatusID": this._oView.byId("idFieldProjectStatus").getSelectedKey(),
				"CaseRating": this._oView.byId("idFieldProjectRating").getSelectedKey(),
				"ParentCaseID": this._modelProjectDialog.getData().sEngCaseId,
				"ProjectStartDate": dStartDate === null ? null : dStartDate,
				"ProjectEndDate": dEndDate === null ? null : dEndDate,
				"ProjectGoLiveDate": dGoLiveDate === null ? null : dGoLiveDate,
			};

			if (this._oOldProjectData) {  //Edit-Dialog
				let sEmplIdSelected = this.EmployeeSelection2.fnGetEmployeeId(),
					sEmplRespId = sEmplIdSelected || this._oOldProjectData.EmplRespID;
				Object.assign(oData, {
					"EmplRespID": sEmplRespId,
					"CustomerID": this._oView.byId("idFieldCustomerNumber").getValue(),
					"GlobalUltimateID": this._modelProjectDialog.getData().sGlobalUltimateId,
					"ProjectGUID": this._modelProjectDialog.getData().sProjectGuid,
					"ProjectID": this._modelProjectDialog.getData().sProjectId,
					"TqmID": this._modelProjectDialog.getData().sTqmId
				})
			} else {  //Create-Dialog
				Object.assign(oData, {
					"EmplRespID": this._oContext.getOwnerComponent().getModel("appData").getData().oCrmUserData.UserId,
					"CustomerID": this.CustomerSelection2.fnGetCustomerId(),
					"ReasonCode": "ENG3" //"Customer Project/Initiative"
				});
			}
			return oData;
		},




	})
});
