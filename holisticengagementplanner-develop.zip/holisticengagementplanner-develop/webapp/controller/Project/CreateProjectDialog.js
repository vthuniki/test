sap.ui.define([
	"com/sap/ui/hep/controller/Project/BaseProjectDialog",
	"sap/ui/model/json/JSONModel",
	"com/sap/ui/hep/util/customerSelection/CustomerSelection",
	"com/sap/ui/hep/util/engagementSelection/EngagementSelection",
	"com/sap/ui/hep/reuse/BaseRequest",
	"com/sap/ui/hep/reuse/Constants"

], function (BaseProjectDialog, JSONModel, CustomerSelection, EngagementSelection, BaseRequest, Constants) {

	"use strict";

	return BaseProjectDialog.extend("com.sap.ui.hep.controller.Project.CreateProjectDialog", {

		fnCreateProjectDialogOpen: function (oContext, oResourceBundle, sCaseId) {
			this._oContext = oContext;
			this._oView = oContext.getView();
			this._oResourceBundle = oResourceBundle;
			this._parentEngCaseId = sCaseId;
			this._savePhasesFlag = true;
			this._PhasesAreInOrderFlag = true;

			this._initializeModels();

			this._triggerRequestsToBEForInitialSetup();

			this._pDialogCreateProject ??= this._loadFragment(this, oContext.getView(), "com.sap.ui.hep.view.Project.DialogCreateProject", () => {
				this._oView.byId("idFieldProjectName").addEventDelegate({
					onAfterRendering: this.fnSetFocusProjectName.bind(this)
				});
				this._oView.byId("idFieldStartDate").addEventDelegate({
					onAfterRendering: this.fnSetFocusDatePicker.bind(this)
				});
			});
			this._pDialogCreateProject.then(oDialog => {
				oDialog.setModel(this._modelProjectDialog, "modelProjectDialog");
				oDialog.setModel(this._modelVhFieldCustomerId, "modelVhFieldCustomerId");
				this._oView.byId("idIconTabBarNoIcons").setSelectedKey("keyTabProjectDetails");
				oDialog.open();
				this._fnAdjustTabDesign("idTabProjectDetails", false);
				this._fnAdjustTabDesign("idTabProjectDates", false);
				this._initializeFieldsAfterOpen();
			});
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ========================================== Initialization ========================================================= */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_initializeModels: function () {
			/* "_modelVhFieldCustomerId" is just a helper model, for the customer search dialog*/
			this._modelVhFieldCustomerId = new JSONModel({});
			this._modelVhFieldCustomerId.setSizeLimit(1000);

			this._initializeModelProjectDialog(); //_modelProjectDialog

			/* Localmodel inizialization */
			let oLocalModel = new JSONModel({});
			if (this._oView.getModel("localModel") === undefined) {
				this._oView.setModel(oLocalModel, "localModel");
			}
			this._oModel = this._oView.getModel("localModel");
			this._oData = this._oModel.getData();

			this._fnLoadProjectStatus();
		},

		_initializeFieldsAfterOpen: function () {
			this._modelProjectDialog.getData().busyCreateNewProject = false;
			this._modelProjectDialog.getData().minDateGoLive = null;
			this._modelProjectDialog.getData().maxDateGoLive = null;

			this._modelProjectDialog.getData().sEngCaseId = this._parentEngCaseId;
			this._modelProjectDialog.getData().busyEngCaseSearch = true;
			this._modelProjectDialog.getData().bStartDateAndEndDateIsSelected = false;

			this._modelProjectDialog.getData().sInitiativeId = Constants.getProjectInitiative().Project; //ZSPROMET04
			this._modelProjectDialog.getData().sInitiativeText = "Project";

			this._modelProjectDialog.getData().sEngCustomerId = '';
			this._modelProjectDialog.getData().sEngCustomerName = '';
			this._setUpCustomerSelectionModule1(this._modelProjectDialog.getData().sEngCustomerId);

			this._modelProjectDialog.refresh();

			//get initial values for Customer- and Engagement-Fields
			EngagementSelection.fnGetDetailsForEngagement(this._modelProjectDialog.getData().sEngCaseId, true, (oEngCasesFound) => {
				this._modelProjectDialog.getData().sEngCustomerId = "";
				this._modelProjectDialog.getData().sEngCustomerName = "";

				this._modelProjectDialog.getData().busyEngCaseSearch = false;
				if (oEngCasesFound.results.length === 1) {
					this._modelProjectDialog.getData().sEngCaseName = oEngCasesFound.results[0].ProjectName;
					this._modelProjectDialog.getData().sEngCustomerId = oEngCasesFound.results[0].CustomerID;
					this._modelProjectDialog.getData().sEngCustomerName = oEngCasesFound.results[0].CustomerName;
					this.fnEngContractBPGet("");
				} else {
					this._modelProjectDialog.getData().sEngCaseName = "Does not exist";
					this._parentEngCaseId = ""; //because it does not exist anyway
				}
				this._modelProjectDialog.refresh();
				this._fnSetFieldsValueState(["idFieldEngagementCase"]);
			});

			this._oView.byId("idFieldProjectName").setValue();
			this._oView.byId("idFieldProjectDescription").setValue();
			this._oView.byId("idFieldSapInvolvement").setSelectedKey(null);
			this._oView.byId("idFieldDeploymentType").setSelectedKey(null);
			this._oView.byId("idFieldProjectType").setSelectedKey(null);
			this._oView.byId("idFieldStartDate").setDateValue(null);
			this._oView.byId("idFieldEndDate").setDateValue(null);
			this._oView.byId("idFieldGoLiveDate").setDateValue(null);
			this._oView.byId("idFieldInitiativeTypeGroup").setSelectedIndex(0);

			this._oView.byId("idBtnCreate").setEnabled(false);
			this._oView.byId("idBtnCreate").setVisible(false);
			this._oView.byId("idBtnNext").setVisible(true);

			this._fnLoadProjectPhasesForInitiative();

			this._fnLoadProjectRatingsFromLocal();

			this._oContext.getView().byId("idFieldComboContractId").setSelectedKey("");
			this._oContext.getView().byId("idFieldComboCustomerId").setSelectedKey("");
			this._fnEngCaseContractsRead();

		},

		/* ========================================== Load Data (Locally) ========================================================= */
		_fnLoadProjectPhasesForInitiative: function () {
			let oPhases = {
				results: Constants.getProjectInitiativePhases()[this._modelProjectDialog.getData().sInitiativeId]
			};
			oPhases.results.forEach(function (elm) {
				elm.PhaseStartDate = null;
				elm.PhaseEndDate = null;
			});

			this._modelProjectDialog.getData().projectPhasesList = oPhases.results;
			this._modelProjectDialog.refresh();
		},

		_fnLoadProjectStatus: function () {
			this._modelProjectDialog.getData().projectStatusList = Constants.getItemStatus();
			this._modelProjectDialog.getData().projectStatusList.pop(); //removes the last entry: Closed, as it makes no sence to create a closed project - and BE thrwos error anyway...
			this._modelProjectDialog.refresh();
		},

		_fnEngCaseContractsRead: function () {
			let listOfContractsInEngagement = this._oContext.getView().getModel("engCaseContracts").getData().results;
			let listOfContracts = new JSONModel({
				result: []
			});
			listOfContractsInEngagement.forEach((oContract) => {
				listOfContracts.getData().result.push({
					"ContrId": oContract.ContrId,
					"ContrDesc": oContract.ContrDesc
				});
			});
			this._modelProjectDialog.getData().listOfContractForEngagement = listOfContracts.getData().result;
			this.fnEngContractBPGet("");
			this._modelProjectDialog.refresh();
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ============================================ Event Handler ======================================================== */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		fnSetFocusProjectName: function () {
			setTimeout(function () {
				this._oView.byId("idFieldProjectName").focus();
			}.bind(this), 500);
		},

		fnSetFocusDatePicker: function () {
			setTimeout(function () {
				this._oView.byId("idFieldStartDate").focus();
			}.bind(this), 500);
		},

		fnHandleNextPress: function () {
			this._fnValidateTab("idTabProjectDetails");
			if (!this._fnIsTabValid("idTabProjectDetails")) {
				this._fnAdjustTabDesign("idTabProjectDetails", true);
			} else {
				this._fnAdjustTabDesign("idTabProjectDetails", false);
			}
			this._oView.byId("idIconTabBarNoIcons").setSelectedKey("keyTabProjectDates");
			this._oView.byId("idBtnNext").setVisible(false);
			this._oView.byId("idBtnCreate").setVisible(true);
			this._oView.byId("idTabProjectDates").focus();
		},

		fnHandleCancelPress: function () {
			this._pDialogCreateProject.then(oDialog => oDialog.close());
		},

		fnHandleTabClicked: function (oEvent) {
			if (oEvent.getParameters().selectedKey !== oEvent.getParameters().previousKey) { //only if user has not clicked again on same tab...
				if (oEvent.getParameters().selectedKey.includes("TabProjectDates")) {
					this.fnHandleNextPress();
				} else {
					this._fnValidateTab("idTabProjectDates");
					if (!this._fnIsTabValid("idTabProjectDates")) {
						this._fnAdjustTabDesign("idTabProjectDates", true);
					} else {
						this._fnAdjustTabDesign("idTabProjectDates", false);
					}
				}
				this._fnSetMinMaxForPhaseDates();
			}
		},

		/* ============================================ Event Handler - Field Specific ========================================= */

		fnHandleInitiativeSelect: function (oEvent) {
			if (oEvent.getSource().getSelectedButton().getId().includes("idInitiativeOperations")) this._fnHandleInitiativeSelectOperations();
			if (oEvent.getSource().getSelectedButton().getId().includes("idInitiativeProject")) this._fnHandleInitiativeSelectProject();
			this._modelProjectDialog.refresh();
			this._fnSetFieldsValueState(["idFieldGoLiveDate"]);
			this._fnSetFieldsValueState(["idFieldProjectType"]);
			this._fnSetTabAndCreateBtnState("idTabProjectDetails");
			this._fnSetTabAndCreateBtnState("idTabProjectDates");
			this._fnSetMinMaxForPhaseDates();
		},

		_fnHandleInitiativeSelectOperations: function () {
			//initiative "Operations" selected
			this._modelProjectDialog.getData().sInitiativeId = Constants.getProjectInitiative().Operations; // ZSPROMET03
			this._modelProjectDialog.getData().sInitiativeText = "Operations";
			//backup data belonging to previous initiative "Project"
			this._modelProjectDialog.getData().sBackupOfProjectType = this._oView.byId("idFieldProjectType").getSelectedKey();
			this._modelProjectDialog.getData().sBackupOfGoLiveDate = this._oView.byId("idFieldGoLiveDate").getDateValue();
			this._modelProjectDialog.getData().aBackupOfInitiativeProjectPhases = Object.values($.extend(true, {}, this._modelProjectDialog.getData()
				.projectPhasesList));
			//load fresh phases table for the new initiative (Operations) from customizing
			this._fnLoadProjectPhasesForInitiative();
			//if already phases are backed up for "Operations", take them and overwrite the fresh phases and clear the backup
			if (this._modelProjectDialog.getData().aBackupOfInitiativeOperationsPhases?.length) {
				this._modelProjectDialog.getData().projectPhasesList = this._modelProjectDialog.getData().aBackupOfInitiativeOperationsPhases;
				this._modelProjectDialog.getData().aBackupOfInitiativeOperationsPhases = null;
			}
			//in case "start date of the first phase" is still empty, set it to the project start date, in case that exists
			if (this._oView.byId("idFieldStartDate").getDateValue() && !this._modelProjectDialog.getData().projectPhasesList[0].PhaseStartDate) {
				this._modelProjectDialog.getData().projectPhasesList[0].PhaseStartDate = this._oView.byId("idFieldStartDate").getDateValue();
			}
			//in case "end date of the last phase" is still empty, set it to the project end date, in case that exists
			if (this._oView.byId("idFieldEndDate").getDateValue() && !this._modelProjectDialog.getData().projectPhasesList[this._modelProjectDialog
				.getData().projectPhasesList.length - 1].PhaseEndDate) {
				this._modelProjectDialog.getData().projectPhasesList[this._modelProjectDialog.getData().projectPhasesList.length - 1].PhaseEndDate =
					this._oView.byId("idFieldEndDate").getDateValue();
			}
			//clear fields that do not exist for "Operations"
			this._oView.byId("idFieldProjectType").setSelectedKey(null);
			this._oView.byId("idFieldGoLiveDate").setDateValue(null);

		},
		_fnHandleInitiativeSelectProject: function () {
			//initiative "Project" selected
			this._modelProjectDialog.getData().sInitiativeId = Constants.getProjectInitiative().Project; //ZSPROMET04
			this._modelProjectDialog.getData().sInitiativeText = "Project";
			//backup data belonging to previous initiative "Operations"
			this._modelProjectDialog.getData().aBackupOfInitiativeOperationsPhases = Object.values($.extend(true, {}, this._modelProjectDialog
				.getData().projectPhasesList));
			//load fresh phases table for the new initiative (Project) from customizing
			this._fnLoadProjectPhasesForInitiative();
			//if already phases dates are backed up for "Project", take them and overwrite the fresh phases and clear the backup
			if (this._modelProjectDialog.getData().aBackupOfInitiativeProjectPhases?.length) {
				this._modelProjectDialog.getData().projectPhasesList = this._modelProjectDialog.getData().aBackupOfInitiativeProjectPhases;
				this._modelProjectDialog.getData().aBackupOfInitiativeProjectPhases = null;
			}
			//also apply backed up data for ProjectType and GoLiveDate
			if (this._modelProjectDialog.getData().sBackupOfProjectType) {
				this._oView.byId("idFieldProjectType").setSelectedKey(this._modelProjectDialog.getData().sBackupOfProjectType);
			}
			if (this._modelProjectDialog.getData().sBackupOfGoLiveDate) {
				this._oView.byId("idFieldGoLiveDate").setDateValue(this._modelProjectDialog.getData().sBackupOfGoLiveDate);
			}
			//in case "start date of the first phase" is still empty, set it to the project start date, in case that exists
			if (this._oView.byId("idFieldStartDate").getDateValue() && !this._modelProjectDialog.getData().projectPhasesList[0].PhaseStartDate) {
				this._modelProjectDialog.getData().projectPhasesList[0].PhaseStartDate = this._oView.byId("idFieldStartDate").getDateValue();
			}
			//in case "end date of the last phase" is still empty, set it to the project end date, in case that exists
			if (this._oView.byId("idFieldEndDate").getDateValue() && !this._modelProjectDialog.getData().projectPhasesList[this._modelProjectDialog
				.getData().projectPhasesList.length - 1].PhaseEndDate) {
				this._modelProjectDialog.getData().projectPhasesList[this._modelProjectDialog.getData().projectPhasesList.length - 1].PhaseEndDate =
					this._oView.byId("idFieldEndDate").getDateValue();
			}
		},

		fnHandleProjectNameChanged: function (oEvent) {
			this._oView.byId("idFieldProjectNameCounter").setText(80 - Number(oEvent.getParameter("value").length) +
				" characters remaining");
			this._fnSetFieldsValueState(["idFieldProjectName"]);
			this._fnSetTabAndCreateBtnState("idTabProjectDetails");
		},

		fnHandleProjectDescriptionChanged: function (oEvent) {
			this._oView.byId("idFieldProjectDescriptionCounter").setText(1333 - Number(oEvent.getParameter("value").length) +
				" characters remaining");
			this._fnSetFieldsValueState(["idFieldProjectDescription"]);
			this._fnSetTabAndCreateBtnState("idTabProjectDetails");
		},

		fnHandleProjectTypeChanged: function (oEvent) {
			this._fnSetFieldsValueState(["idFieldProjectType"]);
			this._fnSetTabAndCreateBtnState("idTabProjectDetails");
		},

		fnHandleDeploymentTypeChanged: function (evt) {
			this._fnSetFieldsValueState(["idFieldDeploymentType"]);
			this._fnSetTabAndCreateBtnState("idTabProjectDetails");
		},

		fnHandleSapInvolvementChanged: function (evt) {
			this._fnSetFieldsValueState(["idFieldSapInvolvement"]);
			this._fnSetTabAndCreateBtnState("idTabProjectDetails");
		},

		fnHandleEngCaseChanged: function (evt) {
			if (this._modelProjectDialog.getData().sEngCaseId && this._modelProjectDialog.getData().sEngCaseId.length > 0) {
				this._modelProjectDialog.getData().sEngCaseName = "";
				this._modelProjectDialog.getData().busyEngCaseSearch = true;
				this._modelProjectDialog.refresh();

				EngagementSelection.fnGetDetailsForEngagement(evt.getParameter("newValue"), false, (oEngCasesFound) => {
					this._modelProjectDialog.getData().busyEngCaseSearch = false;
					this._modelProjectDialog.refresh();
					if (oEngCasesFound.results.length === 1) {
						this._modelProjectDialog.getData().sEngCaseId = oEngCasesFound.results[0].ProjectID;
						this._modelProjectDialog.getData().sEngCaseName = oEngCasesFound.results[0].ProjectName;
						this._fnSetFieldsValueState(["idFieldEngagementCase"]);
					} else {
						//given ID not clear, open the Engagement-Selection Popup and prefill the given ID
						let oInitialFilterValues = {
							CaseId: this._modelProjectDialog.getData().sEngCaseId
						};
						this._fnSetFieldsValueState(["idFieldEngagementCase"]);
						this.fnOnValueHelpEngagementCase(undefined, oInitialFilterValues);
					}
				});
			} else {
				//user has emptied field EngCaseId...
				this._modelProjectDialog.getData().sEngCaseName = "";
				this._modelProjectDialog.refresh();
				this._fnSetFieldsValueState(["idFieldEngagementCase"]);
			}
			this._fnSetTabAndCreateBtnState("idTabProjectDetails");
		},

		fnHandleProjectStartDateChanged: function (evt) {
			if (evt.getParameter("valid") && evt.getParameter("value") !== "") {
				if (this._oView.byId("idFieldEndDate").getDateValue()) {
					this._modelProjectDialog.getData().projectPhasesList[0].PhaseStartDate = evt.getSource().getDateValue();
					this._modelProjectDialog.getData().projectPhasesList[this._modelProjectDialog.getData().projectPhasesList.length - 1].PhaseEndDate =
						this._oView.byId("idFieldEndDate").getDateValue();
					if (this._modelProjectDialog.getData().sInitiativeText === "Project" && this._oView.byId("idFieldGoLiveDate").getDateValue()) {
						this._modelProjectDialog.getData().projectPhasesList[4].PhaseEndDate = this._oView.byId("idFieldGoLiveDate").getDateValue();
					}
				}
				this._fnSetMinMaxForPhaseDates();
				this._oView.byId("idFieldEndDate").setMinDate(this._fnAddOneDay(this._oView.byId("idFieldStartDate").getDateValue()));
				this._modelProjectDialog.getData().bStartDateAndEndDateIsSelected = !!this._oView.byId("idFieldEndDate").getDateValue();
				this._modelProjectDialog.refresh();
				this._clearProjectDateIfNotValid("idFieldEndDate");
			} else {
				this._modelProjectDialog.getData().bStartDateAndEndDateIsSelected = false;
			}
			this._setMinMaxDateForGoLive();
			this._clearProjectDateIfNotValid("idFieldGoLiveDate");
			this._fnSetFieldsValueState(["idFieldStartDate"]);
			this._fnSetTabAndCreateBtnState("idTabProjectDates");
			this._modelProjectDialog.getData().aBackupOfInitiativeProjectPhases = null;
			this._modelProjectDialog.getData().aBackupOfInitiativeOperationsPhases = null;
		},

		fnHandleProjectEndDateChanged: function (evt) {
			if (evt.getParameter("valid") && evt.getParameter("value") !== "") {
				if (this._oView.byId("idFieldStartDate").getDateValue()) {
					this._modelProjectDialog.getData().projectPhasesList[0].PhaseStartDate = this._oView.byId("idFieldStartDate").getDateValue();
					this._modelProjectDialog.getData().projectPhasesList[this._modelProjectDialog.getData().projectPhasesList.length - 1].PhaseEndDate =
						evt.getSource().getDateValue();
					if (this._modelProjectDialog.getData().sInitiativeText === "Project" && this._oView.byId("idFieldGoLiveDate").getDateValue()) {
						this._modelProjectDialog.getData().projectPhasesList[4].PhaseEndDate = this._oView.byId("idFieldGoLiveDate").getDateValue();
					}
				}
				this._fnSetMinMaxForPhaseDates();
				this._modelProjectDialog.getData().bStartDateAndEndDateIsSelected = !!this._oView.byId("idFieldStartDate").getDateValue();
				this._modelProjectDialog.refresh();
			} else {
				this._modelProjectDialog.getData().bStartDateAndEndDateIsSelected = false;
			}
			this._setMinMaxDateForGoLive();
			this._clearProjectDateIfNotValid("idFieldGoLiveDate");
			this._fnSetFieldsValueState(["idFieldEndDate"]);
			this._fnSetTabAndCreateBtnState("idTabProjectDates");
			this._modelProjectDialog.getData().aBackupOfInitiativeProjectPhases = null;
			this._modelProjectDialog.getData().aBackupOfInitiativeOperationsPhases = null;
		},

		fnHandleProjectGoLiveDateChanged: function (evt) {
			this._fnSetFieldsValueState(["idFieldGoLiveDate"]);
			this._fnSetTabAndCreateBtnState("idTabProjectDates");

			if (evt.getParameter("valid") && evt.getParameter("value") !== "" && this._modelProjectDialog.getData().sInitiativeText === "Project" &&
				this._oView.byId("idFieldStartDate").getDateValue() && this._oView.byId("idFieldEndDate").getDateValue()) {
				// send end date of pre-last phase ("Deploy"-phase)
				this._modelProjectDialog.getData().projectPhasesList[4].PhaseEndDate = this._oView.byId("idFieldGoLiveDate").getDateValue();
				this._modelProjectDialog.refresh();
				this._fnSetMinMaxForPhaseDates();
				this._fnSetTabAndCreateBtnState("idTabProjectDates");
			}
		},

		/**
		 *  In case the user changes the start date of a phase, the requirement is that the end date of the
		 *  previous phase is also changed. The previous phase has to end the day before this phase starts now.
		 *
		 */
		fnHandlePhaseStartDateChange: function (oEvent) {
			this._fnHandlePhaseStartDateChange(oEvent);
			this._fnSetTabAndCreateBtnState("idTabProjectDates");
		},

		/**
		 *  In case the user changes the end date of a phase, the requirement is that the start date of the
		 *  next phase is also changed. The next phase has to start the day after this phase ends now.
		 *
		 */
		fnHandlePhaseEndDateChange: function (oEvent) {
			this._fnHandlePhaseEndDateChange(oEvent);
			this._fnSetTabAndCreateBtnState("idTabProjectDates");
		},

		fnHandleContractComboChange: function (oEvent) {
			let selectedContract = "";
			if (oEvent.getParameter("value") !== "") {
				selectedContract = oEvent.getSource().getSelectedKey();
			}
			this.fnEngContractBPGet(selectedContract);
		},

		fnHandleMainPartnerComboChange: function (oEvent) {
			let selectedBP = "";
			if (oEvent.getParameter("value") !== "") {
				selectedBP = oEvent.getSource().getSelectedKey();
			}
			this._modelProjectDialog.getData().sCustomerId = selectedBP;
			this.CustomerSelection2.fnSetCustomerIdNoHandle(selectedBP);
			this._modelProjectDialog.refresh();
			this._fnSetFieldsValueState(["idFieldComboCustomerId"]);
			this._fnSetTabAndCreateBtnState("idTabProjectDetails");
		},

		fnEngContractBPGet: function (sContractId) {
			let entities = {};
			if (sContractId === "") {
				let oCustomerListModel = new JSONModel({
					result: []
				});
				oCustomerListModel.getData().result.push({
					"BPID": this._modelProjectDialog.getData().sEngCustomerId,
					"comboValue": this._modelProjectDialog.getData().sEngCustomerId + " - " + this._modelProjectDialog.getData().sEngCustomerName,
					"comboAdditional": "Main Engagement Customer",
					"BPName": this._modelProjectDialog.getData().sEngCustomerName
				});
				this._modelProjectDialog.getData().listOfCustomerForContract = oCustomerListModel.getData().result;
				this._modelProjectDialog.refresh();
				this.fnSetDataForCustomerCombo(oCustomerListModel.getData().result, "");
				return;
			}

			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ContractSet";
			entities.entitySet = "ContractSet(CustomerID='0000000000',ContractID='" + sContractId + "')";
			entities.navigation = "toContractPartners";
			entities.oContext = this._oContext;
			entities.currentView = this._oContext.getView();
			entities.callbackSuccess = (oData) => {
				let oCustomerListModel = new JSONModel({
					result: []
				});
				let sKey = "";
				oData.results.forEach((oBP) => {
					if (oBP.PartnerFct === Constants.getPartnerFct().soldToParty || oBP.PartnerFct === Constants.getPartnerFct()
						.customerForCallOff)
						oCustomerListModel.getData().result.push({
							"BPID": oBP.PartnerNo,
							"comboValue": oBP.PartnerNo + " - " + oBP.Name,
							"comboAdditional": oBP.PartnerFctDesc,
							"BPName": oBP.Name
						});
					if (oBP.PartnerFct === Constants.getPartnerFct().soldToParty) {
						sKey = oBP.PartnerNo;
					}
				});
				this._modelProjectDialog.getData().listOfCustomerForContract = oCustomerListModel.getData().result;
				this._modelProjectDialog.refresh();
				this.fnSetDataForCustomerCombo(oCustomerListModel.getData().result, sKey);
				this._oContext.getView().getModel("engCaseContractsSearchHelp").refresh();
			};
			this._oContext.readBaseRequest(entities);
			this._modelProjectDialog.refresh();
		},

		fnSetDataForCustomerCombo: function (arrayOfBPs, selectedBP) {
			this._modelProjectDialog.getData().listOfCustomerForContract = arrayOfBPs;
			this._modelProjectDialog.refresh();
			this._oContext.getView().byId("idFieldComboCustomerId").setSelectedKey(selectedBP);
			this._modelProjectDialog.getData().fieldValueStatesTab1.fragmentFieldInputCustomerId = 'None';
			if (arrayOfBPs.length === 1 && selectedBP === "") {
				this._oContext.getView().byId("idFieldComboCustomerId").setSelectedKey(arrayOfBPs[0].BPID);
				this._modelProjectDialog.getData().sCustomerId = arrayOfBPs[0].BPID;
				this._modelProjectDialog.getData().sCustomerName = arrayOfBPs[0].BPName;
				this._modelProjectDialog.getData().fieldValueStatesTab1.fragmentFieldInputCustomerId = 'None';
				selectedBP = arrayOfBPs[0].BPID;
			}
			//get the single instance and then initialize
			if (!this.CustomerSelection2) this.CustomerSelection2 = new CustomerSelection();
			this.CustomerSelection2.fnSetCustomerIdNoHandle(selectedBP);

			this._fnSetFieldsValueState(["idFieldComboCustomerId"]);
			this._fnSetTabAndCreateBtnState("idTabProjectDetails");
		},

		fnOnProjectContractShowInformation: function (oEvent) {
			let oView = this._oView,
				oController = this._oView.getController(),
				oTextField = oView.byId("idFormProjectContractInfoIcon");
			this._pdPopover ??= this._loadFragment(oController, oView, "com.sap.ui.hep.view.Details.Project.fragment.ProjectContractInfoPopover");
			this._pdPopover.then(function (oPopover) {
				oPopover.openBy(oTextField);
			});
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ===========================================   Validation   ======================================================== */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		//************************************* */
		_fnSetFieldsValueState: function (aFields, bCheckTab1, bCheckTab2, fnCallBack) {
			const aFieldsTab1 = ["idFieldProjectName", "idFieldProjectDescription", "idFieldProjectType", "idFieldDeploymentType",
				"idFieldSapInvolvement", "idFieldProjectType", "idFieldCustomerNumber", "idFieldEngagementCase", "idFieldComboCustomerId"
			];
			const aFieldsTab2 = ["idFieldStartDate", "idFieldEndDate", "idFieldGoLiveDate"];

			if (bCheckTab1 && bCheckTab2) aFields = aFields.Tab1.concat(aFieldsTab2);
			else if (bCheckTab1) aFields = aFieldsTab1;
			else if (bCheckTab2) aFields = aFieldsTab2;
			else aFields = aFields || aFieldsTab1.concat(aFieldsTab2);

			aFields.forEach(elm => {
				switch (elm) {
					case "idFieldProjectName":
					case "idFieldProjectDescription":
						this.__fnHelperSetFieldsValueStateTextFields(elm);
						break;
					case "idFieldComboCustomerId":
					case "idFieldSapInvolvement":
					case "idFieldDeploymentType":
						this.__fnHelperSetFieldsValueStateComboFields(elm);
						break;
					case "idFieldProjectType":
						this.__fnHelperSetFieldsValueStateIdFieldProjectType(elm);
						break;
					case "idFieldEngagementCase":
						this.__fnHelperSetFieldsValueStateIdFieldEngagementCase(elm);
						break;
					case "idFieldStartDate":
					case "idFieldEndDate":
						this.__fnHelperSetFieldsValueStateDateGen(elm);
						break;
					case "idFieldGoLiveDate":
						this.__fnHelperSetFieldsValueStateIdFieldGoLiveDate(elm);
						break;
				}
			});
			this._modelProjectDialog.refresh();
		},

		__fnHelperSetFieldsValueStateIdFieldEngagementCase: function (elm) {
			this._modelProjectDialog.getData().fieldValueStatesTab1[elm] = "None";
			this._modelProjectDialog.getData().fieldValueStateTextsTab1[elm] = "";
			if (!this._oView.byId(elm).getValue()) {
				this._modelProjectDialog.getData().fieldValueStatesTab1[elm] = "Error";
				this._modelProjectDialog.getData().fieldValueStateTextsTab1[elm] = this._oResourceBundle.getText(
					"Project.MsgError" + elm);
			} else {
				//a number is entered, but is it a valid Engagement?
				this._modelProjectDialog.getData().busyEngCaseSearch = true;
				this._modelProjectDialog.refresh();
				EngagementSelection.fnGetDetailsForEngagement(this._oView.byId(elm).getValue(), true, (oData) => {
					this._modelProjectDialog.getData().busyEngCaseSearch = false;
					this._modelProjectDialog.refresh();
					if (oData.results.length !== 1) {
						this._modelProjectDialog.getData().fieldValueStatesTab1[elm] = "Error";
						this._modelProjectDialog.getData().fieldValueStateTextsTab1[elm] = "Entered value is not a valid Engagement Case";
						this._modelProjectDialog.refresh();
					} else {
						this._modelProjectDialog.getData().fieldValueStatesTab1[elm] = "None";
						this._modelProjectDialog.getData().fieldValueStateTextsTab1[elm] = "";
						this._modelProjectDialog.refresh();
					}
				});
			}
		},

		//************************************* */

		_fnIsAllProjectDataValid: function (oNewProjectSaveData) { //check both tabs
			return !!(this._fnIsTabValid("idTabProjectDetails") && this._fnIsTabValid("idTabProjectData"));
		},

		_fnIsTabValid: function (sTabId) { //check one Tab
			if (sTabId === "idTabProjectDetails") {
				for (let key in this._modelProjectDialog.getData().fieldValueStatesTab1) {
					if (this._modelProjectDialog.getData().fieldValueStatesTab1[key] === "Error") return false;
				}
			} else {
				for (let key in this._modelProjectDialog.getData().fieldValueStatesTab2) {
					if (this._modelProjectDialog.getData().fieldValueStatesTab2[key] === "Error") return false;
				}
			}
			return true;
		},

		_fnValidateTab: function (sTabId) { //check one Tab
			if (sTabId === "idTabProjectDetails") {
				this._fnSetFieldsValueState(null, true, false); //Check Tab1
			} else {
				this._fnSetFieldsValueState(null, false, true); //check Tab2
			}
		},

		_fnAllRequiredFieldsFilled: function () {
			if (this._modelProjectDialog.getData().sInitiativeText === "Project") {
				if (!!this._oView.byId("idFieldProjectName").getValue() && !!this._oView.byId("idFieldProjectDescription").getValue() &&
					!!this._oView.byId("idFieldSapInvolvement").getSelectedKey() && !!this._oView.byId("idFieldDeploymentType").getSelectedKey() &&
					!!this._oView.byId("idFieldProjectType").getSelectedKey() && !!this.CustomerSelection2.fnGetCustomerId() &&
					!!this._oView.byId("idFieldEngagementCase").getValue() && !!this._oView.byId("idFieldStartDate").getDateValue() &&
					!!this._oView.byId("idFieldEndDate").getDateValue() && !!this._oView.byId("idFieldGoLiveDate").getDateValue()) return true;
			} else if (!!this._oView.byId("idFieldProjectName").getValue() && !!this._oView.byId("idFieldProjectDescription").getValue() &&
				!!this._oView.byId("idFieldSapInvolvement").getSelectedKey() && !!this._oView.byId("idFieldDeploymentType").getSelectedKey() &&
				!!this.CustomerSelection2.fnGetCustomerId() && !!this._oView.byId("idFieldEngagementCase").getValue() &&
				!!this._oView.byId("idFieldStartDate").getDateValue() && !!this._oView.byId("idFieldEndDate").getDateValue()) return true;
			return false;
		},

		/* =================================================================================================================== */
		/*==================================================================================================================== */
		/*========================================= Search Help - Main BP from Btn  ========================================== */
		/* =================================================================================================================== */
		/* =================================================================================================================== */
		fnCustomerSelectionBtnDialogOpen: function (oEvent) {
			this.CustomerSelection2.fnCustomerSelectionDialogOpen(oEvent);
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* ============================================= Search Help - Customer ============================================== */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_setUpCustomerSelectionModule1: function (sInitialCustomerId) {
			let oCustomerSelectionCustomizing = {
				sInputFragmentId: "idFragmentCustomerIdDialogCreateProject",
				bInputFragmentHasTextField: true,
				sValueHelpFragmentId: "CustomerSelection2",
				sDialogWidth: "833px",
				sDialogHeight: "770px",
				sCustomerIdFieldGridSpan: "XL3 L3 M3 S3",
				sCustomerNameFieldGridSpan: "XL6 L6 M6 S6",
				bCustomerIdRequired: true,
				bCustomerTextFieldVisible: true,
				fnCallBackAfterValueChange: (oNewCustomer, sValueState) => {
					//define what needs to happen in your view controller, when the Customer has changed....
					this._modelProjectDialog.getData().fieldValueStatesTab1.fragmentFieldCustomerId = sValueState;

					this._modelProjectDialog.getData().sCustomerId = oNewCustomer.PartnerID;
					this._modelProjectDialog.getData().sCustomerName = oNewCustomer.FullName;
					let bpList = [];
					let bpFound = false;
					if (!bpFound) {
						bpList.push({
							"BPID": oNewCustomer.PartnerID,
							"comboValue": oNewCustomer.PartnerID + " - " + oNewCustomer.FullName,
							"comboAdditional": "Manual selection",
							"BPName": oNewCustomer.FullName
						});
					}
					this.fnSetDataForCustomerCombo(bpList, oNewCustomer.PartnerID);
					this._oContext.getView().byId("idFieldComboContractId").setSelectedKey("");

					this._fnSetTabAndCreateBtnState("idTabProjectDetails");
				}
			};

			//get the single instance and then initialize
			if (!this.CustomerSelection2) this.CustomerSelection2 = new CustomerSelection(); //get the instance and then initialize
			this.CustomerSelection2.fnInitialize(this._oView, oCustomerSelectionCustomizing, sInitialCustomerId);
		},

		/* =================================================================================================================== */
		/*=======================================================================================================================*/
		/*========================================= Search Help - Engagement Case ===============================================*/
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		fnOnValueHelpEngagementCase: function (oEvent, oInitialFilterValues) {
			let oResourceBundle = this._oResourceBundle;
			let oView = this._oView;

			let oFilterValues = {};
			Object.assign(oFilterValues, oInitialFilterValues, {
				CustomerBpId: this.CustomerSelection2.fnGetCustomerId(),
				CustomerName: this.CustomerSelection2.fnGetCustomerFullName(),
				sDialogWidth: "1200px",
				sDialogHeight: "770px",
				ExactCustomerId: true,
				DisableCustomerFields: false,
				DisableReasonCombo: true,
				ReasonCode: "ENG2" //default - allow no other option

			});
			this._modelProjectDialog.getData().busyEngCaseSearch = true;
			this._modelProjectDialog.refresh();
			EngagementSelection.fnEngagementSelectionDialogOpen(oView, oResourceBundle, oFilterValues, (oSelectedEngCase) => {
				this._modelProjectDialog.getData().busyEngCaseSearch = false;
				this._modelProjectDialog.refresh();
				if (oSelectedEngCase) {
					this._modelProjectDialog.getData().sEngCaseId = oSelectedEngCase.ProjectID;
					this._modelProjectDialog.getData().sEngCaseName = oSelectedEngCase.ProjectName;
					this._modelProjectDialog.refresh();
				} else {
					// user has cancelled the Eng-Selection-Dialog - nothing was selected, keep the current values - so do nothing

				}

				this._fnSetFieldsValueState(["idFieldEngagementCase"]);
				this._fnSetTabAndCreateBtnState("idTabProjectDetails");
			});
		},

		/* =================================================================================================================== */
		/*=====================================================================================================================*/
		/*=========================================   SAVE Project and Phases   ===============================================*/
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		fnHandleCreatePress: function (evt) {
			//show progress indicator
			this._fnShowProgressIndicator();

			//now start saving
			if (this._fnIsAllProjectDataValid()) {

				this._modelProjectDialog.getData().busyCreateNewProject = true;
				this._modelProjectDialog.refresh();
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = Constants.getEntities().ProjectEntity;
				entities.data = this._fnPrepareDataForSaveProjectDetails();
				entities.currentView = this._oView;
				entities.oContext = this._oContext;

				entities.errorMessage = this._oResourceBundle.getText("NewProject.SaveNewProject");
				entities.callbackSuccess = (oData) => {
					this._oContext.getOwnerComponent().trackEvent("Create_Project");
					this.newProjectID = oData.ProjectID; //needed to save the phases
					this._saveOneRowOfPhasesTable(0); //recursively save phases - better would be do be able to save all phases at once in BE
				};
				BaseRequest.handleCreate(entities);
			}
			//	}
		},

		/* recursivley save the phases for this project */
		_saveOneRowOfPhasesTable: function (rowNb) {
			let entities = {},
				itemsOfTable = this._oView.byId("idPhasesTable").getItems();

			// update progress indicator
			this._oDialogProgressIndicator.getContent()[0].setDisplayValue("Saving Phase " + parseInt(rowNb + 1, 10) + " / " + itemsOfTable.length +
				" ");
			if (itemsOfTable.length === 1) {
				this._oDialogProgressIndicator.getContent()[0].setPercentValue(60 + (parseInt(rowNb, 10) + 1) * 40);
			} else {
				this._oDialogProgressIndicator.getContent()[0].setPercentValue(28 + (parseInt(rowNb, 10) + 1) * 12);
			}

			if (rowNb >= itemsOfTable.length) {
				this._oDialogProgressIndicator.close();
				this._modelProjectDialog.getData().busyCreateNewProject = false;
				this._modelProjectDialog.refresh();
				this._pDialogCreateProject.then(oDialog => oDialog.close());
				this._oContext.fnHandleSearchForProjects();
			} else {
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = Constants.getEntities().ProjectPhasesEntity;
				entities.data = this._prepareDataForSaveOneRowOfProjectPhasesTable(rowNb, itemsOfTable);
				entities.currentView = this._oView;
				entities.oContext = this._oContext;

				entities.errorMessage = this._oResourceBundle.getText("NewProject.SavePhasesNewProject");
				entities.callbackSuccess = () => {
					this._saveOneRowOfPhasesTable(rowNb + 1);
				};
				BaseRequest.handleCreate(entities);
			}
		},

		_prepareDataForSaveOneRowOfProjectPhasesTable: function (rowNb, itemsOfTable) {
			let projectID = this.newProjectID,
				dataForOneRow = {},
				modelPhasesData = this._modelProjectDialog.getData().projectPhasesList,
				PhaseID = modelPhasesData[rowNb].PhaseID,
				PhaseStartDate = modelPhasesData[rowNb].PhaseStartDate,
				PhaseEndDate = modelPhasesData[rowNb].PhaseEndDate,
				//phaseNo = rowNb.toString(),
				phaseNo = modelPhasesData[rowNb].PhaseNo;

			dataForOneRow = {
				"ProjectID": projectID,
				"PhaseNo": phaseNo,
				"PhaseID": PhaseID,
				"PhaseStartDate": PhaseStartDate === null ? null : PhaseStartDate,
				"PhaseEndDate": PhaseEndDate === null ? null : PhaseEndDate
			};
			return dataForOneRow;
		},

		/* =================================================================================================================== */
		/* =================================================================================================================== */
		/* =========================================== Little Helpers ======================================================== */
		/* =================================================================================================================== */
		/* =================================================================================================================== */

		_fnSetTabAndCreateBtnState: function (sTabId) {
			this._fnAdjustTabDesign(sTabId, !this._fnIsTabValid(sTabId));
			this._fnAdjustCreateBtnState();
		},

		_fnAdjustTabDesign: function (sTabId, bRemindThatRequired) { //idTabProjectDates OR idTabProjectDetails
			if (bRemindThatRequired) {
				this._oView.byId(sTabId).setIconColor("Critical"); //makes it red
				this._oView.byId(sTabId).setText(this._oResourceBundle.getText("Project.TabRequiredDesignText." + sTabId));
			} else {
				this._oView.byId(sTabId).setIconColor("Default"); //makes it normal color
				this._oView.byId(sTabId).setText(this._oResourceBundle.getText("Project.TabDefaultDesignText." + sTabId));
			}
		},

		_fnAdjustCreateBtnState: function () {
			this._oView.byId("idBtnCreate").setEnabled(this._fnIsAllProjectDataValid() && this._fnAllRequiredFieldsFilled());
		},


		/**
		 *  Go from the BEGINING to the END of the phase table and set the Min- and Max-Dates for all fields.
		 *  Starting with the start date of the first phase, all fields get the project start date as their
		 *  Min-Date.
		 *  As soon as a field is filled, the Min-Date for the FOLLOWING fields is newly calculated, by
		 *  increasing the filled date by one day.
		 *  If a field contains a value that is not valid for its Min-Date, the field is emptied and set to Error( NOT SET TO ERROR, JUST EMPTIED)
		 *
		 *  While applying this logic for the Min-Date to all phases, also the Max-Dates of the fields are set.
		 *  However, for that, simply the Project Max is taken as Max-Date for all fields.
		 *  In case a field contains a date that is later than the Project Max-Date, it is emptied and set to Error (
		 *
		 *  As the Min-Date is permanently increasd, but the Max-Date stays the same, it can happen, that we
		 *  reach a phase, where the Min-Date would have to be increasd to a date, later than the Max-Date.
		 *  If this happens, the user cannot fill any more fiels, because all possible values would be later
		 *  than the project max-Date. If this happens, all following fields are disabled for input.
		 */
		_fnSetMinMaxForPhaseDates: function () {
			//set the min- and max-dates for all fields of the phases table
			// - and deletes existing values, in case they do not match
			let dMin = new Date(this._oView.byId("idFieldStartDate").getDateValue());

			this._modelProjectDialog.getData().projectPhasesList.forEach(oPhase => {
				oPhase.disabledSD = false;
				oPhase.disabledED = false;
				oPhase.valueStateSD = "None";
				oPhase.valueStateED = "None";

				if (oPhase.PhaseStartDate && oPhase.PhaseStartDate < dMin) oPhase.PhaseStartDate = null;

				oPhase.startDateMin = dMin;

				if (oPhase.PhaseStartDate) dMin = this._fnAddOneDay(oPhase.PhaseStartDate); //adjust dMin, in case startDate exists
				if (oPhase.PhaseEndDate && oPhase.PhaseEndDate < dMin) oPhase.PhaseEndDate = null;

				oPhase.endDateMin = dMin;

				if (oPhase.PhaseEndDate) dMin = this._fnAddOneDay(oPhase.PhaseEndDate); //adjust dMin, in case endDate exists

				//now the max-Values, but only considering the Project End Date, not start date of following phases,
				//which the user has maybe filled already - we expect the user to work from beginning to the end of
				//the phases table, not from the end backwards!

				//start Date of a phase can never be after Project End Date!
				this._validatePhaseStartNotAfterProjectEnd(oPhase);

				oPhase.startDateMax = this._oView.byId("idFieldEndDate").getDateValue();

				//also End Date of a phase can never be after Project End
				this._validatePhaseEndNotAfterProjectEnd(oPhase);

				oPhase.endDateMax = this._oView.byId("idFieldEndDate").getDateValue();

				if (oPhase.startDateMin > oPhase.startDateMax) oPhase.disabledSD = true;
				if (oPhase.endDateMin > oPhase.endDateMax) oPhase.disabledED = true;
			});

			this._modelProjectDialog.refresh();
		},

		_validatePhaseStartNotAfterProjectEnd: function (oPhase) {
			if (oPhase.PhaseStartDate && oPhase.PhaseStartDate > this._oView.byId("idFieldEndDate").getDateValue()) {
				oPhase.PhaseStartDate = null;
				oPhase.valueStateSD = "Error";
			}
		},

		_validatePhaseEndNotAfterProjectEnd: function (oPhase) {
			if (oPhase.PhaseEndDate && oPhase.PhaseEndDate > this._oView.byId("idFieldEndDate").getDateValue()) {
				oPhase.PhaseEndDate = null;
				oPhase.valueStateED = "Error";
			}
		}

	});
});
