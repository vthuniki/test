sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/ui/hep/reuse/BaseRequest",
	"com/sap/ui/hep/reuse/BaseTools",
	"com/sap/ui/hep/reuse/HandleSessionTimeout",
	"sap/m/Dialog",
	"sap/m/FormattedText",
	"sap/m/Button",
	"com/sap/ui/hep/reuse/Constants",
], function (Controller, BaseRequest, BaseTools, HandleSessionTimeout,
	Dialog, FormattedText, Button, Constants) {
	"use strict";

	return Controller.extend("com.sap.ui.hep.controller.BaseController", {

		_loadFragment: function (sFragmentPath, fnInitialCallback) {
			return BaseTools.loadFragment(this, undefined, sFragmentPath, fnInitialCallback);
		},

		_loadFragmentWithId: function(sFragmentPath, sFragmentId, fnInitialCallback){
			return BaseTools.loadFragmentWithId(this, sFragmentId, undefined, sFragmentPath, fnInitialCallback);
		},

		_fnNavigateToEngagement: function (sCaseId, sToTab = "") {
			BaseTools.fnNavigateToEngagement.call(this, sCaseId, sToTab);
		},

		_fnNavigateToProject: function (sProjectId, sProjectType, sProjectStatusId) {
			BaseTools.fnNavigateToProject.call(this, sProjectId, sProjectType, sProjectStatusId);
		},

		_fnGetAncestorView: function(oStartView, sAncestorViewNamePart){
			return BaseTools.fnGetAncestorView(oStartView, sAncestorViewNamePart);
		},

		_fnAddOneDay: function(dDate){
			return BaseTools.fnAddOneDay(dDate);
		},

		// Start ----------------------------------------- SO Group --------------------------------------------------
		onSearchSOGroup: function () {
			let oSOGModelData = this.getView().getModel("oSOGroupModel").getData();
			if (oSOGModelData.createdBy.trim().length > 0 || (oSOGModelData.description !== undefined && oSOGModelData.description.length >	0)) {
				oSOGModelData.showInfoMessage = false;
				this.getView().getModel("oSOGroupModel").refresh();
				if (oSOGModelData.description !== undefined && oSOGModelData.description.length > 0) {
					this._searchSOGCall();
				} else if (oSOGModelData.createdBy.trim().length > 0 && this._validUserSOGSearch(oSOGModelData.createdBy)) {
					oSOGModelData.valueStateCreatedBy = "None";
					this.getView().getModel("oSOGroupModel").refresh();
					this._searchSOGCall();
				} else {
					oSOGModelData.valueStateCreatedBy = "Error";
					this.getView().getModel("oSOGroupModel").refresh();
				}
			} else {
				oSOGModelData.showInfoMessage = true;
				this.getView().getModel("oSOGroupModel").refresh();
			}

		},

		_searchSOGCall: function () {
			this._oData.busySOGHelpTable = true;
			this._oModel.refresh();
			let entities = {};
			   entities.servicePath = Constants.getServicePath();
			entities.entitySet = "ServiceOrderGroupSet()";
			entities.filter = this._prepareFilterPayloadSearchServiceGroup();
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.busyIndicator = "busySOGHelpTable";

			entities.errorMessage = this.getResourceBundle().getText("SO.ReadServiceGroupError");
			entities.callbackSuccess = (data) => {
				this._handleSuccessServiceGroup(data);
			};
			this.readBaseRequest(entities);
		},

		/* preprare Filtere for the BE request for SOGroup data */
		_prepareFilterPayloadSearchServiceGroup: function () {
			let arrFilters = [],
				createdByFilter = "",
				oSOGModelData = this.getView().getModel("oSOGroupModel").getData(),
				descriptionFilter = "",
				oFilter;
			if (!!oSOGModelData.createdBy) {
				createdByFilter = `substringof('${oSOGModelData.createdBy.trim()}',CreatedBy)`;
				arrFilters.push(createdByFilter);
			}

			if (!!oSOGModelData.description) {
				descriptionFilter = `substringof('${oSOGModelData.description}',Description)`;
				arrFilters.push(descriptionFilter);
			}

			if (createdByFilter !== "" || descriptionFilter !== "") {
				oFilter = this._generateFilterParams(arrFilters);
			}
			return oFilter;
		},

		_handleSuccessServiceGroup: function (oResponse) {
			this.getView().getModel("oSOGroupModel").getData().results = oResponse.results;
			this.getView().getModel("oSOGroupModel").getData().numberOfGroups = oResponse.results.length;
			this.getView().getModel("oSOGroupModel").getData().valueStateCreatedBy = "None";
			this.getView().getModel("oSOGroupModel").refresh();
  			this._determineAndStoreMostFrequentlyUsed && this._determineAndStoreMostFrequentlyUsed();
			this._oData.busySOGHelpTable = false;
			this._oModel.refresh();
		},

		_validUserSOGSearch: function (sUserParam) {
			const aValidFirstChars = ["C", "D", "I", "c", "d", "i"];
			let sUser = sUserParam.trim();
			let isValid = sUser.length === 1 && aValidFirstChars.includes(sUser[0]);
			if (sUser.length > 0) {
				for (let index = 1; index < sUser.length; index++) {
					isValid = (!isNaN(parseInt(sUser[index], 10)) && aValidFirstChars.includes(sUser[0]));
					if (!isValid) break;
				}
			}
			return isValid;
		},

		/* Get live search proposals for SOG */
		searchAfterSOGAvailable: function (oEvent) {
			if (oEvent.getParameters().value.length >= 3) {
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "ServiceOrderGroupSet()";
				entities.filter = `substringof('${oEvent.getParameters().value}',Description)`;
				entities.currentView = this.getView();
				entities.oContext = this;
				entities.busyIndicator = "busySOGHelpTable";

				entities.errorMessage = this.getResourceBundle().getText("SO.ReadServiceGroupError");
				entities.callbackSuccess = (data) => {
					this.getView().getModel("oSOGSearch").getData().results = data.results;
					this.getView().getModel("oSOGSearch").getData().showWarningMessage = data.results.length === 0;
					this.getView().getModel("oSOGSearch").refresh();
				};
				this.readBaseRequest(entities);
			}
		},

		// End ----------------------------------------- SO Group --------------------------------------------------

		_prepareFilterPayloadSearchSOACP: function (modelROData, sBpFct) {
			let arrFilters = [];
			let firstNameFilter = "";
			let lastNamefilter = "";
			let emailFilter = "";
			let oFilter;
			if (modelROData.firstName !== undefined && modelROData.firstName !== "" && modelROData.firstName !== null) {
				firstNameFilter = "Firstname eq '*" + modelROData.firstName + "*'";
				arrFilters.push(firstNameFilter);
			}

			if (modelROData.lastName !== undefined && modelROData.lastName !== "" && modelROData.lastName !== null) {
				lastNamefilter = "Lastname eq '*" + modelROData.lastName + "*'";
				arrFilters.push(lastNamefilter);
			}

			if (modelROData.email !== undefined && modelROData.email !== "" && modelROData.email !== null) {
				emailFilter = "EmailAddr eq '" + modelROData.email + "'";
				arrFilters.push(emailFilter);
			}

			if (firstNameFilter !== "" || lastNamefilter !== "" || emailFilter !== "") {
				oFilter = this._generateFilterParams(arrFilters);
			}

			if (modelROData.HasEmail === true) {
				let sHasEmailFilter = "HasEmail eq true";
				arrFilters.push(sHasEmailFilter);
				oFilter = this._generateFilterParams(arrFilters);
			}
			if (sBpFct === "SVR") {
				arrFilters.push("IsSurveyRec eq true");
				oFilter = this._generateFilterParams(arrFilters);
			}
			return oFilter;
		},


		fnHandleShowDialogProjectIsNotInISDHub: function (sError) {
			const oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			if (!this.oDialogProjectIsNotInISDHub) {
				this.oDialogProjectIsNotInISDHub = new Dialog({
					type: "Message",
					title: "Warning",
					state: "Warning",
					content: new FormattedText({
						htmlText: oResourceBundle.getText("Project.WarningProjectNotInIsdHub")
					}),
					beginButton: new Button({
						type: "Emphasized",
						text: "OK",
						press: function () {
							this.oDialogProjectIsNotInISDHub.close();
						}.bind(this)
					})
				});
			}
			this.oDialogProjectIsNotInISDHub.open();
		},


		handleMessagePopoverPress: function (oEvent) {
			this.oMessagePopover.toggle(oEvent.getSource());
		},

		initializeMessageArea: function (oContext) {
			if (oContext.getView().getModel("messagesModel") === undefined) {
				oContext.messageHandler.initializeMsgHandlling(oContext);
			} else if (oContext.getView().getModel("messagesModel").getData().messages !== undefined) {
				const oButton = oContext.getView().byId("messagePopoverButton");
				oContext.oMessagePopover.openBy(oButton);
			}
		},

		handleClearAllMessages: function () {
			this.messageHandler.clearAllMessages();
		},


		_readRestrictedAccessReasons: function (oContext, oView) {
			return new Promise(function (resolve, reject) {
				const entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "DropDownListSet";
				entities.filter = "Type eq 'ProjectAccessReason'";
				entities.currentView = oView;
				entities.oContext = oContext;
				entities.callbackSuccess = (oData) => {
					resolve(oData);
				};
				this.readBaseRequest(entities);
			}.bind(this));
		},

		_updateProject: function (resolve, reject, oProject) {
			let entities = {};

			entities.servicePath = Constants.getServicePath();
			entities.function = "ChangeFavorite";
			entities.urlParameters = {
				"IsFavorite": this.bFavorite,
				"ProjectID": oProject.ProjectID
			};
			entities.oContext = this;
			entities.currentView = this.getView();
			entities.merge = false;
			entities.updateMethod = "POST";
			entities.busyIndicator = "busyIndicatorActivities";
			entities.callbackSuccess = (oData) => {

				let oResult = oData !== undefined ? oData : oProject;
				resolve(oResult);
			};
			this.callFunction(entities);
		},

		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		getAppData: function () {
			return this.getOwnerComponent().getModel("appData");
		},

		handleSessionTimeout: function (params, oContext) {
			HandleSessionTimeout.fnSessionTimeout(params, oContext);
		},

		createBaseRequest: function (entities) {
			BaseRequest.handleCreate(entities);
		},

		createBaseRequestSync: function (entities) {
			BaseRequest.handleCreateSync(entities);
		},

		createBaseRequest1: function (entities) {
			BaseRequest.handleCreate1(entities);
		},

		readBaseRequest: function (entities) {
			BaseRequest.handleRead(entities);
		},

		readBaseRequestRest: function (entities) {
			BaseRequest.handleReadRest(entities);
		},

		readUserData: function (entities) {
			BaseRequest.handleReadUserData(entities);
		},

		removeAttachmentsBaseRequest: function (entities) {
			BaseRequest.handleRemoveAttachments(entities);
		},

		updateBaseRequest: function (entities) {
			BaseRequest.handleUpdate(entities);
		},

		deleteBaseRequest: function (entities) {
			BaseRequest.handleDelete(entities);
		},

		initBatch: function () {
			BaseRequest.batchInit();
		},

		createBaseRequestBatch: function (params) {
			BaseRequest.handleBatchCreate(params);
		},

		updateBaseRequestBatch: function (params) {
			BaseRequest.handleBatchUpdate(params);
		},

		deleteBaseRequestBatch: function (params) {
			BaseRequest.handleBatchDelete(params);
		},

		submitBaseRequestBatch: function () {
			BaseRequest.handleBatchSubmit();
		},

		callFunction: function (params) {
			BaseRequest.handleFunctionCall(params);
		},

		getValidToken: function (oContext) {
			oContext._token = "";
			const apiKey = Constants.getAPIHeaders().APIKey,
				apiSecret = Constants.getAPIHeaders().APISecret;

			jQuery.ajax({
				url: Constants.getServicePath(),
				method: "GET",
				headers: {
					"X-Requested-With": "XMLHttpRequest",
					"Content-Type": "application/atom+xml",
					"DataServiceVersion": "2.0",
					"X-CSRF-Token": "Fetch",
					"APIKey": apiKey,
					"APISecret": apiSecret
				},
				success: (sData, sStatus, sResponse) => {
					oContext._token = sResponse.getResponseHeader("x-csrf-token");
				},
				error: (oEvent, sStatus, sError) => {
					oContext.messageHandler.addNewMessageseInsidePopover("errorReadingToken", "Error", "Error Reading Data ",
						"Please try again later!",
						"Please try again later!", oContext);
				}
			});

		}


	});
});