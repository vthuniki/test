sap.ui.define([

	"com/sap/ui/hep/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/sap/ui/hep/model/formatter",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"com/sap/ui/hep/util/Dates",
	"com/sap/ui/hep/util/Pagination",
	"com/sap/ui/hep/util/Variant",
	"com/sap/ui/hep/reuse/Constants",
	"com/sap/ui/hep/util/MessageHandlingPopover",
	"com/sap/ui/hep/util/Model",
	"com/sap/ui/hep/util/EmployeeDetails",
	"com/sap/ui/hep/util/TablePersoProjects",
	"com/sap/ui/hep/util/TablePersoEngagementCases",
	"com/sap/ui/hep/util/TablePersoServices",
	"sap/m/TablePersoController",
	"sap/ui/export/Spreadsheet",
	"sap/ui/core/SeparatorItem",
	"sap/ui/export/library",
	"com/sap/ui/hep/util/NavigationToExternalApps",
	"com/sap/ui/hep/controller/Engagement/CreateEngagementDialog",
	"com/sap/ui/hep/util/FilterHelper"

], function ( BaseController, JSONModel, Formatter, MessageBox,
	MessageToast, Dates, Pagination, Variant, Constants,  MessageHandlingPopover,
	Model, EmployeeDetails, TablePersoProjects, TablePersoEngagementCases, TablePersoServices,
	TablePersoController,  Spreadsheet, SeparatorItem, ExportLibrary, NavigationToExternalApps,
	CreateEngagementDialog, FilterHelper) {
	"use strict";

	return BaseController.extend("com.sap.ui.hep.controller.Home.Home", {
		formatter: Formatter,
		dates: Dates,
		pagination: Pagination,
		messageHandler: MessageHandlingPopover,
		model: Model,
		employeeDetails: EmployeeDetails,
		variant: Variant,
		_oCreateEngagementDialog: new CreateEngagementDialog,

		/* =================================================== General =========================================================== */

		_readConstants: function () {
			return Constants;
		},

		onInit: function () {
			this.getRouter().getRoute("Home").attachPatternMatched(this._handleRouteMatched, this);
			this.getRouter().getRoute("HomeFromCatalog").attachPatternMatched(this._handleRouteMatchedImportFromCatalog, this);
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			this.getView().byId("searchFieldProjects").addEventDelegate({
				onAfterRendering: function () {
					this.getView().byId("searchFieldProjects").focus();
				}.bind(this)
			});
		},

		onAfterRendering: function () {
			document.addEventListener("fullscreenchange", function (e) {
				if (document.fullscreenElement) {
					// enter full screen detected
					this.getView().getModel("localModel").setProperty("/fullscreen", true);
					this.getView().getModel("localModel").refresh();
				} else {
					// exit full screen detected
					this.getView().getModel("localModel").setProperty("/fullscreen", false);
					this.getView().getModel("localModel").refresh();
				}
			}.bind(this));
		},

		_handleRouteMatchedImportFromCatalog: function (oEvent) {
			let sImportPackageFromSSCId = oEvent.getParameters().arguments.sSCComponentId;
			let sMessageBoxTitle = this.getResourceBundle().getText("Home.ImportPackageWindow.Title", [sImportPackageFromSSCId]);
			let sMessageBoxText = this.getResourceBundle().getText("Home.ImportPackageWindow.Text");
			MessageBox.information(sMessageBoxText, {
				title: sMessageBoxTitle
			}
			);
			this.getOwnerComponent().getModel("appData").getData().oMyStorage.put("importPackageFromSSCId", sImportPackageFromSSCId);
			this.getOwnerComponent().getModel("appData").refresh();
			this._handleRouteMatched();
		},

		_handleRouteMatched: function () {
			this.getOwnerComponent().pCrmUserDataLoaded.then(()=> {
				let oTable = this.getView().byId("projectsTable");
				oTable.removeSelections();
				if (this.getView().getViewName().includes("Home") === true) {
					this._initialize();
					if (this.getView().getModel("oFilterRangeModel") === undefined) {
						this.initRangeModel();
					}
					if (this.getView().getModel("filterModel") === undefined) {
						this._initModelFilter();
					}
					this._initVariants();
				}
			});
		},

		_initialize: function () {
			let oLocalModel = new JSONModel({});
			this.getView().setModel(oLocalModel, "localModel");
			let oModelSearch = new JSONModel({});
			this.getView().setModel(oModelSearch, "ResultSearch");
			this._oView = this.getView();
			this._oModel = this._oView.getModel("localModel");
			this._oData = this._oModel.getData();

			this._oData.filtersSetted = false;
			this._oData.formEditMode = false;
			this._oData.numberOfDays = 11;
			this._oData.searchFieldBusy = false;
			this._oData.busyIndicatorProjects = true;
			this._oData.paginationNextBtnEnabled = true;
			this._oData.paginationPrevBtnEnabled = false;
			this._oData.placeholderSearch = this.getResourceBundle().getText("Home.SearchPlaceholderMyEngagements");
			this._oData.SearchInfoPopover = this.getResourceBundle().getText("Home.SearchThroughTextEngagements");
			this._oData.paginationClicks = 0;
			this._oData.paginationSkip = 0;
			this._oData.totalNumberOfProjects = 30;
			this._oData.paginationIntervalStart = 0;
			this._oData.paginationIntervalEnd = Constants.getPaginationTop();
			if(!this._scopeView){
				this._scopeView = Constants.getReasonOptions().engagement;
			}
			this._oData.scopeView = this._scopeView;
			this._oData.timeZone = Constants.getTimeZoneText();
			this._oData.hieracrhyVisRows = 10;
			let oSelectedKey = this.getView().byId("ProjectSearchRange").getSelectedKey();
			this._oData.searchMyProjects = oSelectedKey !== "all";
			this._oModel.refresh();
			let oModelProjects = new JSONModel({});
			this.getView().setModel(oModelProjects, "TileCollection");
			this.messageHandler.initializeMsgHandlling(this);
			this._initializeEngagementCasesTablePerso();
			this.getView().byId("idEngagementsTable").setContext(this);
			this._initializeProjectsTablePerso();
			this.getView().byId("projectsTable").setContext(this);
			this._initializeServicesSection();
			this.searchFilters = "";
			this.oStore = {};
			this.oEventS = {};
			this._mViewSettingsDialogs = {}
			this.lastFilters = [];
			this._oView.getModel("localModel").getData().filterTabSelected = "Range";
			this._destroyFilterDialog();
		},

		// ==================================== Projects Table Personalizaton ===================

		_destroyFilterDialog: function(){
				this.getView().byId("filterDialog")?.destroy();
		},

		_initializeProjectsTablePerso: function () {
			if (this._oTPCProjects === undefined) {
				this._oTPCProjects = new TablePersoController({
					table: this.getView().byId("projectsTable"),
					componentName: "projectsTable",
					persoService: TablePersoProjects
				}).activate();
			}
			TablePersoProjects.setContext(this);
		},

		onProjectsPersoButtonPressed: function (oEvent) {
			this._oTPCProjects.openDialog();
		},

		onProjectsTablePersoRefresh: function () {
			TablePersoProjects.resetPersData();
			this._oTPCProjects.refresh();
		},

		// ============================== Engagement Cases Table Personalizaton =================

		_initializeEngagementCasesTablePerso: function () {
			if (this._oTPCEngagementCases === undefined) {
				this._oTPCEngagementCases = new TablePersoController({
					table: this.getView().byId("idEngagementsTable"),
					componentName: "engagementsTable",
					persoService: TablePersoEngagementCases
				}).activate();
			}
			TablePersoEngagementCases.setContext(this);
		},

		onEngagementCasesPersoButtonPressed: function (oEvent) {
			this._oTPCEngagementCases.openDialog();
		},

		onEngagementCasesTablePersoRefresh: function () {
			TablePersoEngagementCases.resetPersData();
			this._oTPCEngagementCases.refresh();
		},

		// ============================== Services Table Personalizaton =================
		_initializeServicesTablePerso: function () {
			if (this._oTPCServices === undefined) {
				this._oTPCServices = new TablePersoController({
					table: this.getView().byId("servicesTable"),
					componentName: "servicesTable",
					persoService: TablePersoServices
				}).activate();
			}

			TablePersoServices.setContext(this);
		},

		onServicesPersoButtonPressed: function (oEvent) {
			this._oTPCServices.openDialog();
		},

		onServicesTablePersoRefresh: function () {
			TablePersoServices.resetPersData();
			this._oTPCServices.refresh();
		},

		/* ========================================== Table columns sort =============================================== */

		clearAllSortings: function (oEvent) {
			let oTable = this.byId("table");
			oTable.getBinding("rows").sort(null);
			this._resetSortingState();
		},

		onResetSortProjects: function () {
			let oTable = this.getView().byId("projectsTable");
			this.onResetSort(oTable);
		},

		onResetSortEngagements: function () {
			let oTable = this.getView().byId("idEngagementsTable");
			this.onResetSort(oTable);
		},

		onResetSortServices: function () {
			let oTable = this.getView().byId("servicesTable");
			this.onResetSort(oTable);
		},

		onResetSort: function (oTable) {
			oTable.resetSorting();
			this._oSort = null;
			this._readProjects(null);
		},



		/* ============================================= Read projects =========================================================== */

		fnHandleSearchForItems: function (oSort) {
			this._readProjects(false, oSort);
		},

		/**
		 *  When the users project are displayed, the model-property needs to be set correctly and
		 *	the select box has to be set to "My Projects"
		 *	@param {boolean} bClear - if the read happens after a clear
		 *  @param {object} oSort - sorting defined
		 */
		_readProjects: function (bClear, oSort) {
			let entities = {};
			if (oSort) {
				this._oSort = oSort;
			}
			this._buildReadProjectsSettings(entities);

			entities.callbackSuccess = (oData) => {
				let iNumberOfProjects = oData.__count;
				this._handleSuccessReadProjects(oData, iNumberOfProjects, this._oData.scopeView);
			};
			this.readBaseRequest(entities);
		},

		_handleSuccessReadProjects: function (oData, iNumberOfProjects, sScopeView) {
			const sModelName = sScopeView.includes("services") ? "spdDetails" : "TileCollection";

			this.getView().getModel(sModelName).getData().results = this._oData.scopeView === Constants.getReasonOptions().project ?
				oData.results : this._createHierarchy(oData.results);
			this.getView().getModel(sModelName).getData().numberOfProjects = iNumberOfProjects;
			this.getView().getModel(sModelName).refresh(true);
			this._handleSuccessReadProjectsCommonPart();

			this._oData.hieracrhyVisRows = 10;
			this._oModel.refresh();
			this._handlePaginationElements();
		},

		_buildReadProjectsSettings: function (entities) {
			switch (this._oData.scopeView) {
				case "services":
					this.getView().byId("servicesTable").resetSorting();
					break;
				case "ENG3":
					this.getView().byId("projectsTable").resetSorting();
					break;
				default:
					this.getView().byId("idEngagementsTable").resetSorting();
					break;
			}

			let bProjectSelection = this.getView().getModel("oFilterRangeModel").getData().defaultSelected === "" ?
				"mine" :
				this.getView().getModel("oFilterRangeModel").getData().defaultSelected;
			this._oData.searchMyProjects = bProjectSelection === "mine";
			this._oData.searchMyServices = this.getView().getModel("oFilterRangeModel").getData().defaultSelected === "createdByMe";
			this._oData.showFavoritesOnly = this.getView().getModel("oFilterRangeModel").getData().defaultSelected === "myFavorite";
			this._oData.busyIndicatorProjects = true;
			this._oModel.refresh();
			entities.servicePath = Constants.getServicePath();

			if (this._oData.scopeView === "services") {
				entities.entitySet = Constants.getEntities().ServiceItem;
				entities.filter = this._generateFilterParamsServices();
				// setting default sort item and order
				entities.sortItem = "StartDate";
				entities.sortOrder = "desc";
				this.getView().byId("srvtblStartDate").setSortIndicator(sap.ui.core.SortOrder.Descending);
			} else {
				entities.entitySet = Constants.getEntities().ProjectSetEntity;
				entities.filter = this._generateFilterParams();
				entities.expand = "toProjectCustomer";
			}

			if (this.searchFilters !== "")
				entities.filter = entities.filter + this.searchFilters;

			if (entities.filter === '(  )') {
				entities.filter = undefined;
			}

			entities.paginationTop = Constants.getPaginationTopServices();
			entities.paginationSkip = this._oData.paginationSkip;
			entities.inlineCount = "allpages";
			entities.errorMessage = this.getResourceBundle().getText("ProjectEntityPerUser.ErrorMessage");
			if (this._oSort) {
				//if the default sort order is overwritten, reset the table
				this.getView().byId("servicesTable").resetSorting();
				entities.sortItem = this._oSort.field;
				entities.sortOrder = Constants.getSortOrder()[this._oSort.order];
				this.getView().byId(this._oSort.column).setSortIndicator(this._oSort.order);
				this.getView().getModel("localModel").refresh();
			}
			entities.oContext = this;
			entities.currentView = this.getView();
			entities.busyIndicator = "busyIndicatorProjects";
		},

		_generateFilterParams: function () {
			let paramToCallBE = this._generateFilterParamsCommonPart();
			if (this._oData.scopeView === Constants.getReasonOptions().engagement) {
				let sReasonFilter =
					` and ( ReasonCode eq '${Constants.getReasonOptions().engagement}' or  ReasonCode eq '${Constants.getReasonOptions().globalEng}')`;
				paramToCallBE += sReasonFilter;
			} else if (!this.getView().getModel("filterModel").getData().searchTerm || this._oData.scopeView === Constants.getReasonOptions()
				.project) {
				let sProjectReasonString =
					` and ( ReasonCode eq '${Constants.getReasonOptions().project}' or  ReasonCode eq '${Constants.getReasonOptions().COEWatch}'` +
					` or  ReasonCode eq '${Constants.getReasonOptions().COETask}' or  ReasonCode eq '${Constants.getReasonOptions().COEWar}'` +
					` or  ReasonCode eq '${Constants.getReasonOptions().AdvRes}' or  ReasonCode eq '${Constants.getReasonOptions().MCC}'  or  ReasonCode eq '' )`;
				paramToCallBE += sProjectReasonString;
			}
			let sCaseFilter =
				` and ( CaseType eq '${Constants.getCaseTypes().caseType}')`;
			paramToCallBE += sCaseFilter;
			return `( ${paramToCallBE} )`;
		},

		_generateFilterParamsServices: function () {
			let paramToCallBE = this._generateFilterParamsCommonPart();

			return `( ${paramToCallBE} )`;
		},

		_handleSuccessReadProjectsCommonPart: function () {
			this._oData.busyIndicatorProjects = false;
			if (this._oData.bInitial === undefined) {
				this._oData.bInitial = !this.getView().getModel("filterModel").getData().searchTerm;
			}
			this._oModel.refresh();
			if (this._sSortItem) {
				let oSorter = this.model.createrSorter(this, this._sSortItem, this._sSortOrder);
				this.getView().byId("projectsTable").getBinding("rows").sort(oSorter);
			}
		},

		_handlePaginationElements: function () {
			let iNumberOfProjects = this.getView().getModel("TileCollection").getData().numberOfProjects ?
				this.getView().getModel("TileCollection").getData().numberOfProjects : this.getView().getModel("spdDetails").getData().numberOfProjects;

			this.pagination._paginationElements(this, iNumberOfProjects, null, null, true);

		},

		_createHierarchy: function (oData) {
			oData.forEach(elm => {
				if (elm.HasChildren) {
					elm.children = [{}];
				}
			});
			return oData;
		},

		_generateFilterParamsCommonPart: function () {
			let itemSearch = this.getView().getModel("filterModel").getData().searchTerm;
			const paramsToCallBE = [],
				filterStatuses = [];
			itemSearch &&= itemSearch.replace(/'/g, "''");

			let aItems = this.getView().byId("filterStatus").getSelectedItems().length ?
				this.getView().byId("filterStatus").getSelectedItems() :
				this.getView().byId("filterStatus").getItems();

			if (itemSearch) {
				if (this._oData.scopeView === "services") {
					paramsToCallBE.push(`Search eq '**${itemSearch}*'`);
				} else {
					paramsToCallBE.push(`Search eq '${itemSearch}'`);
				}
			}

			if (this._oData.searchMyProjects === true) {
				paramsToCallBE.push(this._oData.scopeView === "services" ? "MyInvolvement eq 'X'" : "MyProjects eq 'X'");
			} else if (this._oData.scopeView === "services" && this._oData.searchMyServices) {
				// in case services > Range > Created by Me is selected
				paramsToCallBE.push(`CreatedBy eq '${this.getOwnerComponent().getModel("appData").getData().oCrmUserData.UserId}'`);
			}

			if (this._oData.showFavoritesOnly === true) {
				paramsToCallBE.push("IsFavorite eq true");
			}

			const aFilterStatusItems = aItems.map(item => item.getKey());

			if (this._oData.scopeView === "services" && this.oStore["Status"]) {
				filterStatuses.push(...this.oStore["Status"].map(item => `StatusID eq '${item}'`));
			} else {
				filterStatuses.push(...aFilterStatusItems.map(item => `StatusID eq '${item}'`));
			}
			paramsToCallBE.push(`(${filterStatuses.join(" or ")})`);

			return paramsToCallBE.join(" and ");
		},

		fnHandleToggleHierarchy: function (oEvent) {
			let sPath = oEvent.getParameter("rowContext").sPath,
				oCase = oEvent.getSource().getModel("TileCollection").getProperty(sPath);
			if (oEvent.getParameter("expanded") === true) {
				this._oData.busyIndicatorProjects = true;
				this._oModel.refresh();
				let entities = {};
				entities.servicePath = Constants.getServicePath();
				entities.entitySet = "CaseHierarchySet()";
				entities.paginationTop = Constants.getPaginationTop();
				entities.paginationSkip = this._oData.paginationSkip;
				entities.inlineCount = "allpages";
				entities.filter = `(ProjectID eq '${oCase.ProjectID}')`;
				entities.errorMessage = this.getResourceBundle().getText("ProjectEntityPerUser.ErrorMessage");
				entities.oContext = this;
				entities.currentView = this.getView();
				entities.busyIndicator = "busyIndicatorProjects";
				entities.callbackSuccess = (data) => {
					this._handleSuccessReadChildren(data.results, oCase);
				};
				this.readBaseRequest(entities);
			} else {
				this._oData.hieracrhyVisRows = this._oData.hieracrhyVisRows - oCase.children.length;
				this._oModel.refresh();
			}
		},

		_handleSuccessReadChildren: function (oData, oCase) {
			oData.forEach(elm => {
				if (elm.HasChildren) {
					elm.children = [{}];
				}
			});
			oData.results = oData.results.filter(item => item.ReasonCode === "ENG1" || item.ReasonCode === "ENG2");
			oCase.children = oData;
			this._oData.hieracrhyVisRows = this._oData.hieracrhyVisRows + oData.length;
			this._oModel.refresh();
			this.getView().getModel("TileCollection").refresh();
			this._oData.busyIndicatorProjects = false;
			this._oModel.refresh();
		},

		// ----- Contract search popup --//
		fnAddEngagementCase: function () {
			this._oCreateEngagementDialog.fnCreateEnagagementDialogOpen(this, this.getResourceBundle());
		},

		fnEngCaseContractSearchPopupClose: function (oEvent) {
			this._oCreateEngagementDialog.fnEngCaseContractSearchPopupClose(oEvent);
		},

		fnEngCaseContractSearchPopupSearch: function (oEvent) {
			this._oCreateEngagementDialog.fnEngCaseContractSearchPopupSearch(oEvent);
		},

		fnEngCaseContractSearchPopupFilterBarClear: function (oEvent) {
			this._oCreateEngagementDialog.fnEngCaseContractSearchPopupFilterBarClear(oEvent);
		},

		navToPreviousRecords: function () {
			let pagination = this.pagination.goToPreviousPage(this, this._oData.paginationClicks, true);
			this._oData.paginationClicks = pagination.clicks;
			this._oData.paginationSkip = pagination.skip;
			this._readProjects(null);
		},

		navToNextRecords: function () {
			let pagination = this.pagination.goToNextPage(this, this._oData.paginationClicks, true);
			this._oData.paginationClicks = pagination.clicks;
			this._oData.paginationSkip = pagination.skip;
			this._readProjects(null);
		},

		fnShowEmployeeRespDetails: function (oEvent) {
			this.employeeDetails.displayEmployeePopover(oEvent, this.getView(), "TileCollection", "EmplRespID");
		},

		/* ================================================== Search ============================================================= */

		fnHandleSearchForProjects: function (oEvent) {
			this._oData.busyIndicatorProjects = true;
			this._oData.paginationClicks = 0;
			this._oData.paginationSkip = 0;
			this._oModel.refresh();

			if (oEvent.getParameter("suggestionItem") !== undefined) {
				this.getView().getModel("filterModel").getData().searchTerm = oEvent.getParameter("suggestionItem").getKey();
				this.getView().getModel("filterModel").refresh();
				this._readProjects(null);

			} else {
				this.getView().getModel("filterModel").getData().searchTerm = oEvent.getParameter("query");
				this.getView().getModel("filterModel").refresh();
				if (this.getView().getModel("filterModel").getData().searchTerm !== undefined) {
					if (this.getView().getModel("filterModel").getData().searchTerm === "") {
						if (oEvent.getParameters().clearButtonPressed) {
							let bClear = true;
							this._readProjects(bClear);
						} else {
							this._readProjects(null);
						}
					} else {
						this._readProjects(null);
					}
				} else {
					this._readProjects(null);
				}
			}

		},

		onSuggest: function (event) {
			this._oData.busyIndicatorProjects = false;
			this._oModel.refresh();
			let searchField = this.getView().byId("searchFieldProjects");
			let value = event.getParameter("suggestValue");
			if (value !== "") {
				let filters = [];
				if (value) {
					filters = [
						new sap.ui.model.Filter([
							new sap.ui.model.Filter("ProjectName", function (sText) {
								return (sText || "").toUpperCase().indexOf(value.toUpperCase()) > -1;
							})
						], false)
					];
				}
				searchField.getBinding("suggestionItems").filter(filters);
				searchField.suggest();
			}
		},



		openNoDataPopup: function (oEvent) {
			let oButton = oEvent.getSource();
			this._pfeedbackPopover ??= this._loadFragment("com.sap.ui.hep.view.Details.fragment.PopoverFeedbackData");
			this._pfeedbackPopover.then(function (oPopover) {
				oPopover.openBy(oButton);
			});
		},

		/* ==================================================== Sort =========================================================== */

		/**
		 * Sorts the table columns, ascending / descending, in batches of 10, by calling the back-end
		 * @param {object} oEvent the event triggered when a column's sorting direction changes
		 */
		sortColumns: function (oEvent) {
			this.getView().getModel("localModel").getData().busyIndicatorProjects = true;
			this.getView().getModel("localModel").refresh();

			this._sSortItem = oEvent.getParameter("column").getSortProperty();
			this._sSortOrder = Constants.getSortOrder()[oEvent.getParameter("sortOrder")];

			this._oData.paginationNextBtnEnabled = true;
			this._oData.paginationPrevBtnEnabled = false;
			this._oData.paginationClicks = 0;
			this._oData.paginationSkip = 0;
			this._oModel.refresh();

			this._readProjects(null);
		},


		/*============================== Favorites =========================*/

		_updateService: function (resolve, reject, oService) {
			let entities = {
				servicePath: Constants.getServicePathWithoutLangParam(),
				entitySet: `ServiceItemSet(guid'${oService.ItemGuid}')`,
				data: {
					"IsFavorite": this.bFavorite
				},
				oContext: this,
				currentView: this.getView(),
				merge: false,
				updateMethod: "PATCH",
				busyIndicator: "busyIndicatorActivities",
				callbackSuccess: (oData) => {
					let oResult = oData !== undefined ? oData : oService;
					resolve(oResult);
				}
			};
			this.updateBaseRequest(entities);
		},

		handleMakeItUnfavorite: function (oEvent) {
			this.bFavorite = false;
			if (this.getView().getModel("localModel").getData().scopeView === "services") {
				this._toggleFavoriteHomeService(oEvent);
			} else {
				this._toggleFavorite(oEvent);
			}
		},

		handleMakeItFavorite: function (oEvent) {
			this.bFavorite = true;
			if (this.getView().getModel("localModel").getData().scopeView === "services") {
				this._toggleFavoriteHomeService(oEvent);
			} else {
				this._toggleFavorite(oEvent);
			}
		},

		_toggleFavorite: function (oEvent) {
			this._oData.busyIndicatorActivities = true;
			this._oModel.refresh();

			let sPath = oEvent.getSource().getBindingContext("TileCollection").getPath();
			let oProject = this.getView().getModel("TileCollection").getProperty(sPath);

			return new Promise((resolve, reject) => {
				this._updateProject(resolve, reject, oProject);
			}).then((oData) => {
				let sText = this.bFavorite ?
					this.getResourceBundle().getText("Home.AddedToFavorites") :
					this.getResourceBundle().getText("Home.RemovedFromFavorites");
				MessageToast.show(sText);

				this.getView().getModel("TileCollection").getProperty(sPath).IsFavorite = this.bFavorite;
				this.getView().getModel("TileCollection").refresh();

				this._oData.busyIndicatorActivities = false;
				this._oModel.refresh();
			});
		},
		_toggleFavoriteHomeService: function (oEvent) {
			this._oData.busyIndicatorActivities = true;
			this._oModel.refresh();

			let oSource = oEvent.getSource(),
				sPath = oSource.getBindingContext("spdDetails").getPath(),
				oProject = this.getView().getModel("spdDetails").getProperty(sPath);
			this.getView().getModel("spdDetails").getProperty(sPath).IsFavorite = this.bFavorite;
			this.getView().getModel("spdDetails").refresh();
			return new Promise((resolve, reject) => {
				this._updateService(resolve, reject, oProject);
			}).then((oData) => {
				let sText = this.bFavorite ?
					this.getResourceBundle().getText("Home.Favorite") :
					this.getResourceBundle().getText("Home.Unfavorite");
				MessageToast.show(sText);
				this._oData.busyIndicatorActivities = false;
				this._oModel.refresh();
			});
		},

		/*============================== Filter Range =========================*/
		initRangeModel: function () {
			let sDefaultSelected = this.getView().getModel("oFilterRangeModel") ?
				this.getView().getModel("oFilterRangeModel").getData().defaultSelected : "";
			let oFilterRangeModel = new JSONModel({});
			this.getView().setModel(oFilterRangeModel, "oFilterRangeModel");
			let oRangeOption;
			if (this._oData.scopeView === Constants.getReasonOptions().project) {
				oRangeOption = Constants.getRangeFiltersHome().projectOptions;
			} else if (this._oData.scopeView === "services") {
				oRangeOption = Constants.getRangeFiltersHome().servicesOptions;
			} else {
				oRangeOption = Constants.getRangeFiltersHome().engagementsOptions;
			}
			this.getView().getModel("oFilterRangeModel").setData(oRangeOption);
			this.getView().getModel("oFilterRangeModel").getData().defaultSelected = sDefaultSelected || this.getView().getModel("oFilterRangeModel").getData().defaultSelected;
			this.getView().getModel("oFilterRangeModel").refresh();
		},

		/*============================== Variant Management =========================*/
		_initVariants: async function () {
			this.variant.context = this;
			this.variant.pageVariantID = "pageVariantID";
			this.getView().setModel(this.variant.variantModel, "variantModel");
			this.variant.variantSetName = "HEP_Home_" + this._oData.scopeView;
			this.variant.variantLoaded = () => {
				// Update view model from current variant
				this.getView().getModel("filterModel").getData().searchTerm = this.variant.currentVariant.filter.getData().searchTerm ===
					"undefined" ? "" : this.variant.currentVariant.filter.getData().searchTerm;
				this.getView().getModel("filterModel").getData().selectedKeysFilters = this.variant.currentVariant.filter.getData().statusSelected;
				this.getView().getModel("filterModel").refresh();
				this.getView().getModel("oFilterRangeModel").getData().defaultSelected = this.variant.currentVariant.filter.getData().rangeSelected;
				this.getView().getModel("oFilterRangeModel").refresh();
				if (this.variant.currentVariant.tablePerso.getData()) {
					this.getTablePerso().getPersoService().setPersData(this.variant.currentVariant.tablePerso.getData());
					this.getTablePerso().refresh();
				} else {
					this.getTablePerso().getPersoService().resetPersData();
					this.getTablePerso().refresh();
				}

				this.variant.currentVariant.filter.getData().hasBeenClicked = false;
				this._resetFilters();
				this.lastFiltersSetted = this.getView().getModel("filterModel").getData().selectedKeysFilters;
				this._oSort = this.variant.currentVariant.filter.getData().sortItem;
				if (this._oData.scopeView === "services" && this.variant.currentVariant.filter.getData().filtersetted) {
					this.searchFilters = this.variant.currentVariant.filter.getData().filtersetted;
					this.oStore = this.variant.currentVariant.filter.getData().filterlist;
				}

				if (this._oData.scopeView === "services") {
					this.onSPDDetailsFilterPressed(true);
				} else {
					this._readProjects(null);
				}

				this.getView().getModel("localModel").refresh();
			};

			// Copy initial filter data to standard variant
			this.variant.standardVariant.filter.getData().searchTerm = this.getView().getModel("filterModel").getData().searchTerm ===
				"undefined" ? "" : this.getView().getModel("filterModel").getData().searchTerm;
			this.variant.standardVariant.filter.getData().statusSelected = this.getView().getModel("filterModel").getData().selectedKeysFilters;
			this.variant.standardVariant.filter.getData().rangeSelected = this.getView().getModel("oFilterRangeModel").getData().defaultSelected;
			// Reset table personlization and save as assigne to standard variant
			await this.getTablePerso().getPersoService().resetPersData();
			this.getTablePerso().getPersoService().getPersData().done(function (oPersData) {
				for (const element of oPersData.aColumns) {
					// Standard setting use 'tablePerso'-IDs for some reason.
					// In order to reapply the standard personalization we need to harmonize that by using the componentName
					element.id = element.id.replace("tablePerso-", this.getTablePerso().getComponentName() + "-");
				}
				this.variant.standardVariant.tablePerso.setData(oPersData);
				this.variant.standardVariant.filter.getData().filtersetted = "";
				this.variant.standardVariant.filter.getData().filterlist = "";
				this.variant.standardVariant.filter.getData().sortItem = undefined;
				this.variant.standardVariant.filter.getData().hasBeenClicked = false;
			}.bind(this));

			this.variant.readVariants(null);
			this.getView().byId("homePageProjects")?.getHeader()?.rerender();
		},

		onVariantSave: function (oEvent) {
			this.variant.currentVariant.filter.getData().searchTerm = this.getView().getModel("filterModel").getData().searchTerm;
			this.variant.currentVariant.filter.getData().statusSelected = this.getView().getModel("filterModel").getData().selectedKeysFilters;
			this.variant.currentVariant.filter.getData().rangeSelected = this.getView().getModel("oFilterRangeModel").getData().defaultSelected;
			this.variant.currentVariant.filter.getData().filtersetted = this.searchFilters;
			this.variant.currentVariant.filter.getData().filterlist = this.oStore;
			this.variant.currentVariant.filter.getData().sortItem = this._oSort;

			this.getTablePerso().getPersoService().getPersData().done(function (oPersData) {
				this.variant.currentVariant.tablePerso.setData(oPersData);
				this.variant.onSave(oEvent);
				this.variant.standardVariant.filter.getData().filtersetted = "";
				this.variant.standardVariant.filter.getData().filterlist = "";
				this.variant.standardVariant.filter.getData().sortItem = undefined;
				this.variant.standardVariant.filter.getData().hasBeenClicked = false;
			}.bind(this));
		},

		onVariantSelect: function (oEvent) {
			this.variant.onSelect(oEvent);
		},

		onVariantManage: function (oEvent) {
			this.variant.onManage(oEvent);
		},

		getTablePerso: function () {
			switch (this._oData.scopeView) {
				case "services":
					return this._oTPCServices;
				case "ENG2":
					return this._oTPCEngagementCases;
				default:
					return this._oTPCProjects;
			}
		},

		setGridListModel: function (sPath) {
			let phaseList = this.getView().getModel("TileCollection").getProperty(sPath).PhasesToDrop
				.split(";");
			phaseList.pop();
			phaseList.forEach(function (oItems, i) {
				let value = oItems.split("=").pop();
				this.getView().getModel("gridListModel").getData().allPhases[i] = value === "true";
			}, this);
			this.getView().getModel("gridListModel").refresh(true);
		},



		_toggleBusyIndicatorsUpdateSPDItem: function (bForceTrue) {
			const oLocalModel = this.getView().getModel("localModel"),
				oData = oLocalModel.getData();

			oData.busyAddService = bForceTrue ? true : !oData.busyAddService;
			oData.busySPDetails = bForceTrue ? true : !oData.busySPDetails;

			oLocalModel.refresh();
		},

		_readItem: function (sItemGuid, fnCallback) {
			if (!sItemGuid) return;
			let entities = {};
			this.getView().getModel("localModel").getData().busySPDetails = true;
			this.getView().getModel("localModel").refresh();
			entities.servicePath = Constants.getServicePathSPD();
			entities.entitySet = `ServicePlanItemSet(ItemGuid=guid'${sItemGuid}',SpGuid=guid'00000000-0000-0000-0000-000000000000')`;
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.errorMessage = "Error reading List of Service Plan Items";
			entities.callbackSuccess = (oData) => {
				oData.ComponentUnknown = !(oData.ComponentID !== undefined && oData.ComponentID !== null && oData.ComponentID !== "");
				if (fnCallback) fnCallback(oData);
				this.getView().getModel("localModel").refresh();
			};
			this.readBaseRequest(entities);
		},







		_readItems: function () {
			let entities = {};
			this.getView().getModel("localModel").getData().busySPDetails = true;
			this.getView().getModel("localModel").refresh();
			entities.servicePath = Constants.getServicePathSPD();
			entities.entitySet = "ServicePlanHeaderSet(guid'" + this._SPDID + "')" + "/toServicePlanItem";
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.busyIndicator = "busySPListView";
			entities.errorMessage = "Error reading List of Service Plan Items";
			entities.callbackSuccess = (oData) => {
				this._handleSuccessReadItems(oData);
				this.getView().getModel("localModel").getData().busySPDetails = false;
				this.getView().getModel("localModel").refresh();
			};
			this.readBaseRequest(entities);
		},










		//*************************************************************************************************************************/
		//********************************************    All Sections START    ***************************************************/


		fnHandleSectionChange: function (oEvent) {
			this._resetFilters();
			this._oData.filtersSetted = false;
			this.getView().getModel("TileCollection").setData({});
			this.getView().getModel("TileCollection").refresh();
			this._oSort = null;
			if (oEvent.getSource().getSelectedKey().indexOf("engagement") > -1) {
				this._oData.scopeView = Constants.getReasonOptions().engagement;
			} else if (oEvent.getSource().getSelectedKey().indexOf("project") > -1) {
				this._oData.scopeView = Constants.getReasonOptions().project;
			} else if (oEvent.getSource().getSelectedKey().indexOf("services") > -1) {
				this._oData.scopeView = "services";
			}
			this._scopeView = this._oData.scopeView;
			this._oData.paginationClicks = 0;
			this._oData.paginationSkip = 0;
			this._oModel.refresh();
			this._adjustSearchFieldPlaceholder();
			this.initRangeModel();
			this._initModelFilter(true);
			this._initVariants();
		},

		fnHandleSearchInfoButtonPress: function () {
			//REMARK: gets the text to display from this._oData.SearchInfoPopover
			const oTextField = this.getView().byId("searchFieldProjects");
			this._pSearchInfoPopover ??= this._loadFragment("com.sap.ui.hep.view.Home.fragment.SearchInfoPopover");
			this._pSearchInfoPopover.then(function (oPopover) {
				oPopover.openBy(oTextField);
			});
		},

		fnHandleRangeInfoButtonPress: function () {
			const oView = this.getView(),
				oSource = oView.byId("ProjectSearchRange");
			this._pRangePopover = this._loadFragment("com.sap.ui.hep.view.Home.fragment.RangeInfoPopover");
			this._pRangePopover.then(function (oPopover) {
				const sScope = oView.getModel("localModel").getData().scopeView,
					oTextField = oView.byId("rangeInfoPopoverTextField"),
					i18nModel = oView.getModel("i18n");
				switch (sScope) {
					case "ENG2":
						// Engagements
						oTextField.setText(i18nModel.getResourceBundle().getText("Home.RangePlaceholderEngagements"));
						break;
					case "ENG3":
						// Projects
						oTextField.setText(i18nModel.getResourceBundle().getText("Home.RangePlaceholderProjects"));
						break;
					default:
						// Services
						oTextField.setText(i18nModel.getResourceBundle().getText("Home.RangePlaceholderServices"));
				}
				oPopover.openBy(oSource);
			});
		},

		handleMessagePopoverPress: function (oEvent) {
			this.oMessagePopover.toggle(oEvent.getSource());
		},

		//********************************************    All Sections END    *****************************************************/
		//*************************************************************************************************************************/


		//*************************************************************************************************************************/
		//********************************************    Excel Export START    ***************************************************/

		fnHandleExcelExport: function () {
			if (((this._oData.scopeView === "ENG3" || this._oData.scopeView === "ENG2") && this.getView().getModel("TileCollection").getData().numberOfProjects > 1000)
				|| (this._oData.scopeView === "services" && this.getView().getModel("spdDetails").getData().numberOfProjects > 1000)) {
				this._pDialogLimitExport ??= this._loadFragment("com.sap.ui.hep.view.Details.fragment.DialogExcelExportLimit");
				this._pDialogLimitExport.then(oDialog => oDialog.open());
			} else {
				this._pDialogUserExport = this._loadFragment("com.sap.ui.hep.view.Details.fragment.ExportUserDialog");
				this._pDialogUserExport.then(oDialog => oDialog.open());
			}
		},

		//for com.sap.ui.hep.view.Details.fragment.DialogExcelExportLimit
		fnHandleDiscardLimit: function (oEvent) {
			this._pDialogLimitExport.then(oDialog => oDialog.close());
		},

		//for com.sap.ui.hep.view.Details.fragment.DialogExcelExportLimit
		onCloseLimitDialog: function () {
			this._pDialogLimitExport.then(oDialog => oDialog.close());
		},

		// for com.sap.ui.hep.view.Details.fragment.ExportUserDialog
		fnHandleCloseDialogExcelExport: function (oEvent) {
			this._pDialogUserExport.then(oDialog => oDialog.close());
		},

		// for com.sap.ui.hep.view.Details.fragment.ExportUserDialog
		onCloseExportDialog: function () {
			this._pDialogUserExport.then(oDialog => oDialog.close());
		},

		onListViewExportSelected: function (oParam) {
			if (this._oData.scopeView === "services") {
				this._fnDownloadExcelFile(oParam, "SERVICES_EXPORT" + ".xlsx", "services", this._buildReadProjectsSettingsWithoutPagination);
			} else if (this._oData.scopeView === "ENG3") {
				this._fnDownloadExcelFile(oParam, "PROJECTS_EXPORT" + ".xlsx", "projects", this._buildExportProject);
			} else {
				this._fnDownloadExcelFile(oParam, "ENGAGEMENTS_EXPORT" + ".xlsx", "engagements", this._buildExportEngagement);
			}
		},

		_fnDownloadExcelFile: function (oParam, sFilename, sKind, fnBuildExportContent) {
			let aCols = this._fnCreateColumnConfigForExport(oParam, sKind),
				sExportFileName = sFilename,
				oTreeData = [];
			let entities = {};
			fnBuildExportContent.call(this, entities);
			entities.callbackSuccess = (oData) => {
				let results = oData.results;
				results.forEach(oItem => {
					oTreeData.push(oItem);
				});
				this._oSort = null;
				let oSettings = {
					workbook: {
						columns: aCols,
						hierarchyLevel: "Level",
						context: {
							sheetName: "Export from HEP"
						}
					},
					dataSource: oTreeData,
					fileName: sExportFileName
				};
				let oSheet = new Spreadsheet(oSettings);
				oSheet.build().finally(function () {
					oSheet.destroy();
				});
				this._oData.busyIndicatorProjects = false;
				this._oModel.refresh();
			};
			this.readBaseRequest(entities);
		},

		_fnCreateColumnConfigForExport: function (oParam, sKind) {
			let sTableId = "";
			let aCols = [];
			switch (sKind) {
				case "services":
					sTableId = "servicesTable";
					aCols.push({
						label: "Phase",
						property: "PhaseText",
						type: ExportLibrary.EdmType.String
					});
					break;
				case "projects":
					sTableId = "projectsTable";
					break;
				case "engagements":
					sTableId = "idEngagementsTable";
			}
			let aColumns = this.getView().byId(sTableId).getColumns();
			aColumns = oParam ? aColumns.filter(function (arg) {
				return arg.getProperty("visible") !== false;
			}) : aColumns;
			aColumns.forEach(function (arg) {
				if (arg.getHeader().getProperty("text") !== "Phase" && arg.getHeader().getProperty("text") !== "Actions") {
					aCols.push({
						label: arg.getHeader().getProperty("text"),
						property: arg.getProperty("sortField"),
						width: 10
					});
				}
			});
			return aCols;
		},

		_buildReadProjectsSettingsWithoutPagination: function (oEntities) {
			let sProjectSelection = this.getView().getModel("oFilterRangeModel").getData().defaultSelected === "" ?
				"mine" : this.getView().getModel("oFilterRangeModel").getData().defaultSelected;
			this._oData.searchMyProjects = sProjectSelection === "mine";
			this._oData.showFavoritesOnly = this.getView().getModel("oFilterRangeModel").getData().defaultSelected === "myFavorite";
			this._oData.busyIndicatorProjects = true;
			this._oModel.refresh();
			oEntities.servicePath = Constants.getServicePath();

			if (this._oData.scopeView === "services") {
				oEntities.entitySet = Constants.getEntities().ServiceItem;
				oEntities.filter = this._generateFilterParamsServices();
			} else {
				oEntities.entitySet = Constants.getEntities().ProjectSetEntity;
				oEntities.filter = this._generateFilterParams();
			}

			if (this.searchFilters !== "")
				oEntities.filter = oEntities.filter + this.searchFilters;
			this._oSort = {
				field: "PhaseText",
				order: "Ascending"
			};

			oEntities.inlineCount = "allpages";
			oEntities.errorMessage = this.getResourceBundle().getText("ProjectEntityPerUser.ErrorMessage");
			if (this._oSort) {
				oEntities.sortItem = this._oSort.field;
				oEntities.sortOrder = Constants.getSortOrder()[this._oSort.order];
			}
			oEntities.oContext = this;
			oEntities.currentView = this.getView();
			oEntities.busyIndicator = "busyIndicatorProjects";
		},

		_buildExportProject: function (oExportEntities) {
			const sMyFavorite = "myFavorite";
			const oFilterRangeModelData = this.getView().getModel("oFilterRangeModel").getData();
			let bProjectSelection = oFilterRangeModelData.defaultSelected === "" ? "mine" : oFilterRangeModelData.defaultSelected;
			this._oData.searchMyProjects = bProjectSelection === "mine";
			this._oData.showFavoritesOnly = oFilterRangeModelData.defaultSelected === sMyFavorite;
			this._oData.busyIndicatorProjects = true;
			this._oModel.refresh();
			oExportEntities.servicePath = Constants.getServicePath();
			if (this._oData.scopeView === "ENG3") {
				oExportEntities.entitySet = Constants.getEntities().ProjectSetEntity;
				oExportEntities.filter = this._generateFilterParams();
			} else {
				oExportEntities.entitySet = Constants.getEntities().ServiceItem;
				oExportEntities.filter = this._generateFilterParamsServices();

			}
			if (this.searchFilters !== "")
				oExportEntities.filter = oExportEntities.filter + this.searchFilters;

			oExportEntities.inlineCount = "allpages";
			oExportEntities.errorMessage = this.getResourceBundle().getText("ProjectEntityPerUser.ErrorMessage");
			if (this._oSort) {
				oExportEntities.sortItem = this._oSort.field;
				oExportEntities.sortOrder = Constants.getSortOrder()[this._oSort.order];
			}
			oExportEntities.oContext = this;
			oExportEntities.currentView = this.getView();
			oExportEntities.busyIndicator = "busyIndicatorProjects";
		},

		_buildExportEngagement: function (oExportEngagementEntities) {
			let bProjectSelection = this.getView().getModel("oFilterRangeModel").getData().defaultSelected === "" ?
				"mine" :
				this.getView().getModel("oFilterRangeModel").getData().defaultSelected;
			this._oData.searchMyProjects = bProjectSelection === "mine";
			this._oData.showFavoritesOnly = this.getView().getModel("oFilterRangeModel").getData().defaultSelected === "myFavorite";
			this._oData.busyIndicatorProjects = true;
			this._oModel.refresh();
			oExportEngagementEntities.servicePath = Constants.getServicePath();
			if (this._oData.scopeView === "services ") {
				oExportEngagementEntities.entitySet = Constants.getEntities().ServiceItem;
				oExportEngagementEntities.filter = this._generateFilterParamsServices();
			} else {
				oExportEngagementEntities.entitySet = Constants.getEntities().ProjectSetEntity;
				oExportEngagementEntities.filter = this._generateFilterParams();
			}
			if (this.searchFilters !== "")
				oExportEngagementEntities.filter = oExportEngagementEntities.filter + this.searchFilters;

			oExportEngagementEntities.inlineCount = "allpages";
			oExportEngagementEntities.errorMessage = this.getResourceBundle().getText("ProjectEntityPerUser.ErrorMessage");
			if (this._oSort) {
				oExportEngagementEntities.sortItem = this._oSort.field;
				oExportEngagementEntities.sortOrder = Constants.getSortOrder()[this._oSort.order];
			}
			oExportEngagementEntities.oContext = this;
			oExportEngagementEntities.currentView = this.getView();
			oExportEngagementEntities.busyIndicator = "busyIndicatorProjects";
		},
		//********************************************    Excel Export END    ***************************************************/
		//***********************************************************************************************************************/





		//***********************************************************************************************************************/
		//********************************************    Engagements Subsection START   ****************************************/

		//used when clicked on a result line in Engagements result list
		fnHandlePressEngagmentsResultList: function (oEvent) {
			let sCurrentSelectionPath = oEvent.getSource().getBindingContext("TileCollection").getPath(),
				sCaseId = oEvent.getSource().getModel("TileCollection").getProperty(sCurrentSelectionPath).ProjectID;
			this._fnNavigateToEngagement(sCaseId);
		},

		//used from the Dialog to create a new Engagement, when closing
		fnHandleEngResultListNavToParentEngagement: function (oEvent) {
			this._fnNavigateToEngagement(oEvent.getSource().getProperty("text"));
		},

		//used from the Dialog to create a new Engagement, when closing
		fnHandleNavToNewCreatedEngagement: function (sCaseId, sToTab) {
			this._fnNavigateToEngagement(sCaseId, sToTab);
		},

		//********************************************    Engagements Subsection END   ******************************************/
		//***********************************************************************************************************************/





		//***********************************************************************************************************************/
		//********************************************    Projects Subsection START   *******************************************/

		//used when clicked on a result line in Projects result list
		fnHandlePressProjectsResultList: function (oEvent) {
			const sCurrentSelectionPath = oEvent.getSource().getBindingContext("TileCollection").getPath();
			const oModel = oEvent.getSource().getModel("TileCollection");
			const sProjectId = oModel.getProperty(sCurrentSelectionPath).ProjectID;
			const sProjectType = oModel.getProperty(sCurrentSelectionPath).CaseType;
			const sProjectStatusId = oModel.getProperty(sCurrentSelectionPath).StatusID;
			this._oData.busyIndicatorProjects = true;
			this._oModel.refresh();
			this._fnNavigateToProject(sProjectId, sProjectType, sProjectStatusId);
			this._oData.busyIndicatorProjects = false;
			this._oModel.refresh();
		},

		//********************************************    Projects Subsection END   *********************************************/
		//***********************************************************************************************************************/



		//***********************************************************************************************************************/
		//***********************************************************************************************************************/
		//***********************************************************************************************************************/
		//***********************************************************************************************************************/
		//********************************************    Services Subsection START   *******************************************/
		//***********************************************************************************************************************/
		//***********************************************************************************************************************/
		//***********************************************************************************************************************/
		//***********************************************************************************************************************/

		_initializeServicesSection: function () {
			let oModelServices = new JSONModel({});
			this.getView().setModel(oModelServices, "spdDetails");
			this._oData.fullscreen = false;
			this._initializeServicesTablePerso();
			this.getView().byId("servicesTable").setContext(this);
			this._readPhasesListFromCRM();  //services
			this._readComponentStatusListFromCRM(); //services
			this._readHeaderStatusListFromCRM(); //services
		},

		_readPhasesListFromCRM: function () {
			let entities = {};
			this.getView().getModel("localModel").getData().busySPListView = true;

			this.getView().getModel("localModel").refresh();
			entities.servicePath = Constants.getServicePathSPD();
			entities.entitySet = "DropDownListSet";
			entities.filter = "Type eq 'PhaseID'";
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.busyIndicator = ["busySPDGeneralInformation", "busySPListView", "busySPDetails"];
			entities.errorMessage = "Error reading List of Service Plan Phases";
			entities.callbackSuccess = (oData) => {
				oData.results.push({
					"Type": "PhaseID",
					"DdlbKey": "None",
					"Value": "None"
				});
				this.getView().getModel("spdDetails").getData().phases = oData.results.sort(function (a, b) {
					if (a.Value === "None") return -1;
					else return 0;
				});
				this.getView().getModel("spdDetails").getData().phases.forEach(function (oPhase) {
					oPhase.Name = oPhase.Value;
				});
				this.getView().getModel("spdDetails").refresh();
				this.getView().getModel("localModel").getData().busySPListView = false;
				this.getView().getModel("localModel").refresh();
			};
			this.readBaseRequest(entities);
		},

		_readComponentStatusListFromCRM: function () {
			let entities = {};
			this.getView().getModel("localModel").getData().busySPListView = true;

			this.getView().getModel("localModel").refresh();
			entities.servicePath = Constants.getServicePath();
			entities.entitySet = "DropDownListSet";
			entities.filter = "Type eq 'ComponentStatus'";
			entities.currentView = this.getView();
			entities.oContext = this;
			entities.busyIndicator = ["busySPDGeneralInformation", "busySPListView", "busySPDetails"];
			entities.errorMessage = "Error reading List of Component Statuses";
			entities.callbackSuccess = (oData) => {
				let oModelSpdDetails = this.getView().getModel("spdDetails");
				oModelSpdDetails.getData().componentStatuses = oData.results;
				oModelSpdDetails.refresh();
				let oModelLocalModel = this.getView().getModel("localModel");
				oModelLocalModel.getData().busySPListView = false;
				oModelLocalModel.refresh();
			};
			this.readBaseRequest(entities);
		},

		_readHeaderStatusListFromCRM: function () {
			if (this._headerStatus) {
				this.getView().getModel("spdDetails").getData().headerStatus = this._headerStatus;
				this.getView().getModel("spdDetails").refresh();
				return;
			}
			this.getView().getModel("localModel").getData().busySPListView = true;
			this.getView().getModel("localModel").refresh();

			let entities = {
				servicePath: Constants.getServicePath(),
				entitySet: "DropDownListSet",
				filter: "Type eq 'Status'",
				currentView: this.getView(),
				oContext: this,
				errorMessage: "Error reading List of Component Statuses",
				callbackSuccess: oData => {
					this._headerStatus = [];
					oData.results.forEach(oItem => {
						if (oItem.Key !== "ZSK00001|E0018") {
							this._headerStatus.push(oItem);
						}
					});
					this.getView().getModel("spdDetails").getData().headerStatus = this._headerStatus;
					this.getView().getModel("spdDetails").refresh();
					this.getView().getModel("localModel").getData().busySPListView = false;
					this.getView().getModel("localModel").refresh();
				}
			}
			this.readBaseRequest(entities);
		},

		//********************************************    Event Handler Services Section   *******************************************/

		fnHandleToggleFullscreenButtonPress: function () {
			if (this.getView().getModel("localModel").getProperty("/fullscreen")) {
				document.exitFullscreen();
			} else {
				document.querySelector("html").requestFullscreen();
			}
		},

		fnHandleServicesResultListItemPress: function (oEvent) {
			const sBindingContextPath = oEvent.getSource().getBindingContextPath();
			this._pDialogMaintainItem ??= this._loadFragment("com.sap.ui.hep.view.Home.fragment.DialogServiceItemQuickView", () => {
				this.getView().byId("cancelButton").setText(this.getResourceBundle().getText("Close"));
				this.getView().byId("cancelButton").setType("Emphasized");
				this.getView().byId("saveButton").setVisible(false);

			});
			this._pDialogMaintainItem.then(oDialog => {
				oDialog.bindObject({
					path: "spdDetails>" + sBindingContextPath
				});
				oDialog.open();
			});
		},

		//for com.sap.ui.hep.view.Home.fragment.DialogServiceItemQuickView
		onDestroyDialog: function (oEvent) {
			this._pDialogMaintainItem.then(oDialog => oDialog.close());
		},

		//for com.sap.ui.hep.view.Home.fragment.DialogServiceItemQuickView
		fnHandleDiscardServiceChanges: function (oEvent) {
			this._pDialogMaintainItem.then(oDialog => oDialog.close());
		},

		//for com.sap.ui.hep.view.Home.fragment.DialogServiceItemQuickView
		onCloseDialog: function (oEvent) {
			this._pDialogMaintainItem.then(oDialog => oDialog.close());
		},

		//for com.sap.ui.hep.view.Home.fragment.DialogServiceItemQuickView
		onPressDisplayAnyServiceItem: function (oEvent) {
			let sPath = oEvent.getSource().getParent().getBindingContext("spdDetails").getPath();
			let oItem = this.getView().getModel("spdDetails").getProperty(sPath);

			if (oItem.ItemType === "ZSR1") this.fnHandleDisplayServiceRequest(oEvent);
			else this.fnHandleDisplayServiceOrder(oEvent);

		},

		fnHandleDisplayServiceRequest: function (oEvent) {
			let oSource = oEvent.getSource();
			let sID = oSource.getBindingContext("spdDetails").getProperty("ObjectID"),
				sProjectID = oSource.getBindingContext("spdDetails").getProperty("CaseID");
			NavigationToExternalApps.fnNavigateToSrsApp("Display", sID, sProjectID);
		},

		fnHandleDisplayServiceOrder: function (oEvent) {
			let sPath = oEvent.getSource().getParent().getBindingContext("spdDetails").getPath();
			let oItem = this.getView().getModel("spdDetails").getProperty(sPath);

			this.getRouter().navTo("ServiceOrderDisplay", {
				serviceOrderID: oItem.ObjectID
			});
		},

		fnHandleServiceProjectPressed: function (oEvent) {
			let sPath = oEvent.getSource().getParent().getBindingContext("spdDetails").getPath();
			let oItem = this.getView().getModel("spdDetails").getProperty(sPath);
			this._fnNavigateToProject(oItem.CaseID, oItem.CaseType, oItem.StatusID);
		},

		fnHandleServiceTableShowLegend: function (oEvent) {
			const oButton = oEvent.getSource();
			this._pLegendPopover ??= this._loadFragment("com.sap.ui.hep.view.Details.Project.SectionServicePlans.subViews.fragments.draftPlanHelper.PopoverLegend");
			this._pLegendPopover.then(function (oPopover) {
				oPopover.openBy(oButton);
			});
		},

		//********************************************    Services Subsection END   *********************************************/
		//***********************************************************************************************************************/


		/* ==================================================== Filter =========================================================== */

		filterbarReset: function (evt) {
			this.getView().getModel("filterModel").getData().searchTerm = "";
			this.getView().getModel("filterModel").refresh();
			this.getView().byId("filterStatus").removeAllSelectedItems();
			this._initModelFilter();
			// reset filterbar fields to initial visibility
			let oFilterGroupItems = this.getView().byId("filterbar");
			oFilterGroupItems.getFilterGroupItems().forEach(oFilterGroupItem => {
				oFilterGroupItem.setVisibleInFilterBar(true);
			});
			// reset range filter to gefault value
			this.getView().getModel("oFilterRangeModel").getData().defaultSelected = "mine";
			this.getView().getModel("oFilterRangeModel").refresh();
			this._readProjects();
		},

		_initModelFilter: function (bReset) {
			const selectedPreviousFilters = this.getView().byId("filterStatus").getSelectedKeys();
			const oFilterData = {
				status: [],
				phases: [],
				types: [],
				status2: [],
				rating: [],
				componentStatuses: []
			};

			if (this.getView().getModel("localModel").getData().scopeView === "services") {
				const serviceStatus = Constants.getServiceStatus();

				const soStatuses = Object.entries(serviceStatus.SO)
					.map(([key, value]) => {
						const contains = ["ZSK00001|E0007", "ZSK00001|E0005", "Draft / Transferred", "Restricted"]
							.includes(key);

						return {
							key,
							value,
							selected: !contains,
							groupBy: "Service Orders"
						};
					});
				const srStatuses = Object.entries(serviceStatus.SR)
					.map(([key, value]) => {
						const contains = ["ZSRQ0001|E0006", "ZSRQ0001|E0007"]
							.includes(key);

						return {
							key,
							value,
							selected: !contains,
							groupBy: "Service Request"
						};
					});
				oFilterData.status.push(...soStatuses, ...srStatuses);
			} else {
				const projectStatus = Constants.getProjectStatus();

				const projectStatuses = Object.entries(projectStatus)
					.map(([key, value]) => {
						return {
							key,
							value,
							selected: key !== "90"
						};
					});

				oFilterData.status.push(...projectStatuses);
			}

			const arrKeySelected = oFilterData.status
				.filter(status => status.selected)
				.map(status => status.key);

			if (selectedPreviousFilters.length === 0 || bReset) {
				oFilterData.selectedKeysFilters = arrKeySelected;
				this._previosSelectedKeysFilters = arrKeySelected;
			} else {
				oFilterData.selectedKeysFilters = selectedPreviousFilters;
			}


			oFilterData.types = Constants.getObjectTypes();
			oFilterData.rating = Constants.getRatingTypes();
			oFilterData.phases = this.getView().getModel("spdDetails").getData().phases;
			oFilterData.status2 = this.getView().getModel("spdDetails").getData().headerStatus;
			oFilterData.componentStatuses = this.getView().getModel("spdDetails").getData().componentStatuses;

			this.getView().setModel(new JSONModel(oFilterData), "filterModel");
			this._oData.bInitial = true;
			this._oModel.refresh();
		},

		getGroupHeader: function (oGroup) {
			return new SeparatorItem({
				text: oGroup.key
			});
		},

		handleFilterConfirm: function (oEvent) {
			this._oData.bInitial = false;
			this.getView().getModel("filterModel").getData().selectedKeysFilters = this.getView().byId("filterStatus").getSelectedKeys();
			this._oData.paginationClicks = 0;
			this._oData.paginationSkip = 0;
			this.refreshSPDStatusFilter();
			this._oModel.refresh();
			if (JSON.stringify(this.getView().getModel("filterModel").getData().selectedKeysFilters) === JSON.stringify(this.lastFiltersSetted))
				return;

			this.lastFiltersSetted = this.getView().getModel("filterModel").getData().selectedKeysFilters;
			this._readProjects(null);
		},

		_adjustSearchFieldPlaceholder: function () {
			let oSelectedKeyRange = this.getView().getModel("oFilterRangeModel").getData().defaultSelected;
			this.getView().getModel("oFilterRangeModel").getData().defaultSelected = oSelectedKeyRange;
			this.getView().getModel("oFilterRangeModel").refresh();

			if (this.getView().getModel("localModel").getData().scopeView === "ENG3") {
				this._oData.searchMyProjects = true;
				this._oData.placeholderSearch =
					oSelectedKeyRange === "mine" ?
						this.getResourceBundle().getText("Home.SearchPlaceholderMyProjects") :
						this.getResourceBundle().getText("Home.SearchPlaceholderAllProjects");
				this._oData.SearchInfoPopover = this.getResourceBundle().getText("Home.SearchThroughTextProjects");
			} else if (this.getView().getModel("localModel").getData().scopeView === "services") {
				this._oData.searchMyProjects = true;
				this._oData.searchMyServices = false;
				this._oData.placeholderSearch =
					oSelectedKeyRange === "mine" ?
						this.getResourceBundle().getText("Home.SearchPlaceholderMyServices") :
						this.getResourceBundle().getText("Home.SearchPlaceholderAllServices");
				this._oData.SearchInfoPopover = this.getResourceBundle().getText("Home.SearchThroughTextServices");
			} else {
				this._oData.searchMyProjects = false;
				this._oData.searchMyServices = false;
				this._oData.placeholderSearch = oSelectedKeyRange === "mine" ?
					this.getResourceBundle().getText("Home.SearchPlaceholderMyEngagements") : this.getResourceBundle().getText(
						"Home.SearchPlaceholderAllEngagements");
				this._oData.SearchInfoPopover = this.getResourceBundle().getText("Home.SearchThroughTextEngagements");
			}
			this._oData.showFavoritesOnly = oSelectedKeyRange === "myFavorite";
			this._oModel.refresh();
		},

		projectSearchRangeChanged: function () {
			this._oData.paginationClicks = 0;
			this._oData.paginationSkip = 0;
			this._oModel.refresh();

			this._adjustSearchFieldPlaceholder();
			this._readProjects(null);
		},

		_setSelectedFIlters: function(oModelFilterModel){
			if (oModelFilterModel.getData().selectedKeysFilters) {
				oModelFilterModel.getData().status.forEach(entry => {
					entry.selected = false;
					if (oModelFilterModel.getData().selectedKeysFilters.includes(entry.key)) {
						entry.selected = true;
					}
				});
			}
			oModelFilterModel.refresh();
		},

		_setSelectedStatusFiltersInPopUpIsPresses: function(){
			// Set Status in filter popup based on main filter area
			this.getView().byId("filterDialog").getFilterItems().forEach(entry => {
				if (entry.getProperty("text") === 'Status') {
					let aFilterStatusItems = [];
					if (this.oStore["Status"]) {
						this.oStore["Status"].forEach(oItem => {
							aFilterStatusItems.push(oItem);
						});
					} else {
						let aItems = this.getView().byId("filterStatus").getSelectedItems().length ?
							this.getView().byId("filterStatus").getSelectedItems() :
							this.getView().byId("filterStatus").getItems();
						aItems.forEach(oItem => {
							let sStatusID = oItem.getKey();
							aFilterStatusItems.push(sStatusID);
						});
					}
					entry.getItems().forEach(item => {
						if (aFilterStatusItems.includes(item.getProperty("key"))) {
							item.setSelected(true);
						} else {
							item.setSelected(false);
						}
					});
				}
			});
		},

		_setSelectedStatusFiltersInPopUpIsNotPresses: function(entry, oModelFilterModel){
			if (entry.getProperty("text") === 'Status') {
				let fItem = undefined;
				entry.getItems().forEach(item => {
					if (!item.getSelected()) {
						fItem = oModelFilterModel.getData().status.find(({
							key
						}) => key === item.getProperty("key"));
						if (fItem) {
							item.setSelected(fItem.selected);
						} else {
							item.setSelected(false);
						}
					}
				});
			}
		},

		onSPDDetailsFilterPressed: function (oParam) {

			let oModelFilterModel = this.getView().getModel("filterModel"),
				filterlist = this.variant.currentVariant.filter.getData().filterlist,
				hasBeenClicked = this.variant.currentVariant.filter.getData().hasBeenClicked;

			this._setSelectedFIlters(oModelFilterModel);

			FilterHelper.getViewSettingsDialog("com.sap.ui.hep.view.Details.fragment.DialogFilterHome", this, this._mViewSettingsDialogs)
				.then((oViewSettingsDialog) => {
					if (filterlist && !hasBeenClicked) {
						this.variant.currentVariant.filter.getData().hasBeenClicked = true;
						this.getView().byId("filterDialog").getFilterItems().forEach(entry => {
							if (entry.getCustomControl !== undefined && entry.getCustomControl().getValue)
								this.lastFilters.push(entry.getCustomControl().getValue());

							this.lastFilters = FilterHelper.handleCreationOfFilterPopUpFromVariantServices(entry, filterlist, this.lastFilters);

							this._setSelectedStatusFiltersInPopUpIsNotPresses(entry, oModelFilterModel);
						});
					} else {
						this._setSelectedStatusFiltersInPopUpIsPresses();
					}

					["dynamic-range", "dynamic-range2", "dynamic-range3"].forEach(oDateFilter => FilterHelper.buildOptionsForDateFilters(oDateFilter, this));

					//leave it like this, can be undefined
					oParam === true ? this.getView().byId("filterDialog").fireConfirm() : oViewSettingsDialog.open(this.getView().byId("filterDialog")._getPage1());
				});
		},

		_buildStatusFilterItems: function(aFilterStatusItems){
			this.oStore["Status"].forEach(oItem => {
				if (this.getView().getModel("filterModel").getData().selectedKeysFilters.includes(oItem) || !this._previosSelectedKeysFilters.includes(oItem))
					aFilterStatusItems.push(oItem);
			});
			if (this.getView().getModel("filterModel").getData().selectedKeysFilters) {
				this.getView().getModel("filterModel").getData().selectedKeysFilters.forEach(oItem => {
					if (!aFilterStatusItems.includes(oItem))
						aFilterStatusItems.push(oItem);
				});
			}

			this._previosSelectedKeysFilters = [];
			this.getView().getModel("filterModel").getData().selectedKeysFilters?.forEach(oItem => {
				this._previosSelectedKeysFilters.push(oItem);
			});

			return aFilterStatusItems;
		},

		refreshSPDStatusFilter: function () {
			if (this.getView().getModel("localModel").getData().scopeView !== "services") {
				return
			}
			let aFilterStatusItems = []
			if (this.oStore["Status"]) {

				aFilterStatusItems = this._buildStatusFilterItems(aFilterStatusItems);

			} else if (this.getView().getModel("filterModel").getData().selectedKeysFilters) {
				this.getView().getModel("filterModel").getData().selectedKeysFilters.forEach(oItem => {
					if (!aFilterStatusItems.includes(oItem)) aFilterStatusItems.push(oItem);
				});
			}
			this.oStore["Status"] = [];
			aFilterStatusItems.forEach(oItem => {
				this.oStore["Status"].push(oItem);
			});

			FilterHelper.refreshMultiInput(this);
		},

		onPhaseViewFilterPhaseSelectionChange: function (oEvent) {

			this._oData.paginationClicks = 0;
			this._oData.paginationSkip = 0;
			let aItemsSelected = oEvent.getParameters().filterItems;

			if (aItemsSelected === undefined) {
				aItemsSelected = this.getView().byId("filterDialog").getSelectedFilterItems();
			}

			let aParams = " and (";
			this.lastFilters = [];
			this.oStore = {};

			FilterHelper.refreshMultiInput(this);

			oEvent.getSource().getFilterItems().forEach(oFilterItem => {
				if (oFilterItem.getText().includes("Date")) {
						aParams = FilterHelper.generateFilterStringForDateFilters(oFilterItem, this, aParams);
				}

				if (oFilterItem.getCustomControl?.().getValue && !oFilterItem.getText().includes("Date")) {
					this.lastFilters.push(oFilterItem.getCustomControl().getValue());
				}

				if (oFilterItem.getCustomControl?.().getValue && oFilterItem.getCustomControl().getValue() !== "" && (!oFilterItem.getText().includes("Date"))) {

					aParams = FilterHelper.generateFilterStringForFreeText(oFilterItem, this, aParams, "services");
				}
			});

			if (aParams.length > 6) {
				aParams = aParams.substring(0, aParams.length - 4);
				aParams += ")";
			} else {
				aParams = aParams.substring(0, aParams.length - 5);
			}

			aParams = FilterHelper.generateFilterStringForStandardFiltersServices(aItemsSelected, this, aParams, "HomeServices");

			if (aParams.length !== 1) {
				this._handleFiltersSetted(aParams);
			} else {
				this._handleNoFiltersSetted();
			}

			this.getView().getModel("spdDetails").refresh();

		},

		_handleFiltersSetted: function(aParams){
			this.searchFilters = aParams;
				let entities = {};

				this._buildReadProjectsSettings(entities);
				this.getView().getModel("localModel").refresh();

				entities.callbackSuccess = (oData) => {
					let iNumberOfProjects = oData.__count;
					this._handleSuccessReadProjects(oData, iNumberOfProjects, this._oData.scopeView);
				};

				this.readBaseRequest(entities);
		},

		_handleNoFiltersSetted: function(){
			this.searchFilters = "";
			this._oData.paginationPrevBtnEnabled = false;
			this._oData.paginationClicks = 0;
			this._oData.paginationSkip = 0;
			this.getView().getModel("localModel").refresh();
			this._readProjects(null);
		},

		cancelInputs: function (oEvent) {
			FilterHelper.cancelInputs(oEvent, this, this.lastFilters, 5);
		},

		resetInputs: function (oEvent) {
			FilterHelper.resetInputs(oEvent);
		},

		eventFired: function (oEvent, sId) {
			FilterHelper.eventFired(oEvent, sId, this);
		},

		_resetFilters: function () {
			FilterHelper.resetFilters(this)
		},

		removeFilterFromBar: function (oEvent) {
			FilterHelper.removeFilterFromBar(oEvent, this);
		}
	});
});
