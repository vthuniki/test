/*eslint-env es6*/
/*eslint max-params: [2, 12]*/
sap.ui.define([
	"jquery.sap.global",
	"com/sap/ui/hep/controller/BaseController",
	"com/sap/ui/hep/util/NavigationToExternalApps"
], function (jQuery, BaseController, NavigationToExternalApps) {
	"use strict";

	return BaseController.extend("com.sap.ui.hep.controller.Unauthorized", {

		/* ============================================ General ==================================================== */

		onInit: function () {
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
		},

		requestTqm: function () {
			NavigationToExternalApps.fnHandleLinkNavigation(Constants.getRequestAuthorizationUrl().tqm);
		},

		requestBo: function () {
			NavigationToExternalApps.fnHandleLinkNavigation(Constants.getRequestAuthorizationUrl().bo);
		},
		
		requestCoE: function () {
			NavigationToExternalApps.fnHandleLinkNavigation(Constants.getRequestAuthorizationUrl().coe);
		},
		
		requestCSP: function () {
			NavigationToExternalApps.fnHandleLinkNavigation(Constants.getRequestAuthorizationUrl().csp);
		}

	});
});