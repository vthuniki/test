sap.ui.define([
	"jquery.sap.global",
	"com/sap/ui/hep/controller/BaseController",
	"sap/ui/model/json/JSONModel"
], function (jQuery, BaseController, JSONModel) {
	"use strict";
	return BaseController.extend("com.sap.ui.hephep.controller.App", {});
});