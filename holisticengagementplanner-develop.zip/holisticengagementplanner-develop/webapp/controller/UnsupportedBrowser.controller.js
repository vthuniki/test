sap.ui.define([
	"com/sap/ui/hep/controller/BaseController",
	"com/sap/ui/hep/util/NavigationToExternalApps"

], function (BaseController, NavigationToExternalApps) {
	"use strict";
	return BaseController.extend("com.sap.ui.hep.controller.UnsupportedBrowser", {

		/* ============================================ General ==================================================== */

		onInit: function () {
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			this.onWarningMessageDialogPress();
		},

		Checkboxselect: function (oEvent) {
			if (oEvent.getParameters().selected) {
				this.byId("closeunsupppoedbro").setEnabled(true);
			} else {
				this.byId("closeunsupppoedbro").setEnabled(false);
			}
		},
		onCloseDialog: function (event) {
			let unsuported = this.byId("unsuported");
			unsuported.close();
		},

		onWarningMessageDialogPress: function () {
			this._pUnsupportedBrowserFragment ??= this._fragmentLoad("com.sap.ui.hep.view.fragment.UnsupportedBrowserDailog");
			this._pUnsupportedBrowserFragment.then(oDialog => oDialog.open());
		},

		downloadChrome: function () {
			NavigationToExternalApps.fnHandleLinkNavigation(Constants.getSupportedBrowserDownloadUrl().chrome);
		},

		downloadEdge: function () {
			NavigationToExternalApps.fnHandleLinkNavigation(Constants.getSupportedBrowserDownloadUrl().edge);
		},
		ContinueBrowser: function () {
			this.getRouter().navTo("Home");
		}

	});
});