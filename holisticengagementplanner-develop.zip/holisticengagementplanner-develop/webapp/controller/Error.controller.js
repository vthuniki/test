/*eslint-env es6*/
/*eslint max-params: [2, 12]*/
sap.ui.define([
	"jquery.sap.global",
	"com/sap/ui/hep/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (jQuery, BaseController, JSONModel, MessageBox, MessageToast) {
	"use strict";

	return BaseController.extend("com.sap.ui.hep.controller.Error", {

		/* =================================================== General =========================================================== */
		onInit: function () {
			this.getRouter().getRoute("Error").attachPatternMatched(this._handleRouteMatched, this);
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
		},

		_handleRouteMatched: function () {
		},

		_initialize: function () {
			const oLocalModel = new JSONModel({});
			this.getView().setModel(oLocalModel, "localModel");

			this._oView = this.getView();
			this._oModel = this._oView.getModel("localModel");
			this._oData = this._oModel.getData();

			this._oData.formEditMode = false;
			this._oData.tilesView = true;
			this._oData.searchFieldBusy = false;
			this._oData.busyIndicatorProjects = true;
			this._oModel.refresh();
		},
		
		navToHome: function(oEvent) {
			this.getRouter().navTo("Home");
		}
	});
});