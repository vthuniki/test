sap.ui.define([
	"sap/ui/core/util/MockServer",
	"sap/base/util/UriParameters"
], function (MockServer, UriParameters, ) {
	"use strict";

	return {
		init: async function () {
			const sPath = sap.ui.require.toUrl("com/sap/ui/hep/");
			const oUriParameters = new UriParameters();
			const mockdata = sap.ui.require.toUrl("com/sap/ui/hep/localService/mockdata");
			const projectSet = await jQuery.getJSON(mockdata + "/ProjectSet.json");

			const oPostNewProject = {
				method: "POST",
				path: new RegExp(/ProjectSet\(\).*/),
				response: function (oXhr, sUrlParams) {
					const project = projectSet.d.results[1];
					const validOdataObject = {
						"d": project
					}
					oXhr.respondJSON(201, {
						"Content-Type": "application/json;charset=utf-8"
					}, JSON.stringify(validOdataObject));
					return true;
				}
			};
			// create
			const oMockServer = new MockServer({
				rootUri: "/int_ic/ZS_APP_HEP_SRV/"
			});

			// configure mock server with a delay
			MockServer.config({
				autoRespond: true,
				autoRespondAfter: oUriParameters.get("serverDelay") || 500
			});

			// simulate
			oMockServer.simulate(sPath + "/localService/metadata.xml", {
				"sMockdataBaseUrl": sPath + "/localService/mockdata",
				"bGenerateMissingMockData": true
			});

			// set Requests
			const aRequests = oMockServer.getRequests();
			aRequests.push(oPostNewProject);
			oMockServer.setRequests(aRequests);

			// start
			oMockServer.start();

			// MOCK SERVER FOR SPD

			// create
			const oSPDMockServer = new MockServer({
				rootUri: "/int_ic/ZS_APP_SPD_SRV/"
			});

			// configure mock server with a delay
			MockServer.config({
				autoRespond: true,
				autoRespondAfter: oUriParameters.get("serverDelay") || 500
			});

			// simulate
			oSPDMockServer.simulate(sPath + "/localService/metadataSPD.xml", {
				"sMockdataBaseUrl": sPath + "/localService/mockdata",
				"bGenerateMissingMockData": true
			});

			// start
			oSPDMockServer.start();
		}
	};

});
