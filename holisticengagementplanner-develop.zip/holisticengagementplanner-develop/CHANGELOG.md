# Changelog

## RD_02.23_v1.0 (25/02/2023)

#### Enhancements

- [**new feature**][**RD_02.23**]  27251: new link customer goal management [#1773](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1773)
- [**bug**][**new feature**][**RD_02.23**] 27262: Remove the Limit 10 in Customer Projects Export [#1762](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1762)
- [**new feature**][**RD_02.23**] 27310: Please enhance message on engagement [#1764](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1764)
- [**new feature**][**RD_02.23**] 26759:  Show Service Requests in status "SO created" [#1760](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1760)
- [**new feature**][**RD_04.23**] 26853: home screen Services Filter: Created by me [FE] [#1752](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1752)
- [**new feature**][**RD_02.23**] 26947: Customer Projects Excel Export Update [#1725](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1725)
- [**new feature**][**RD_02.22**]  26947: Excel Exports for All Projects, All Engagements and Customer Projects in Engagement [#1723](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1723)
- [**new feature**][**RD_02.22**] 27208: SR Description not displayed as alternative description in draft plan [#1722](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1722)
- [**new feature**][**RD_02.23**] Add header statuses + do not show cancelled SO's by default [#1721](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1721)

#### Bugfixes

- [**bug**][**RD_02.23**] 27322: SPD - after import of a package the drop down is still active [#1772](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1772)
- [**bug**][**RD_02.23**] 27320: Filter on HomeScreen Services not working as expected [#1769](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1769)
- [**bug**][**RD_02.23**] 27261: Excel Export Limit Popup [#1768](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1768)
- [**bug**][**RD_02.23**] 27309: Fix for sometimes not possible sending SO to delivery [#1767](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1767)
- [**bug**][**RD_02.23**] 27309: fix various issues SO maintenance [#1765](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1765)
- [**bug**][**RD_02.23**] 27303: Fix toggeling between List and Phase-View [#1761](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1761)
- [**bug**][**RD_02.23**] 27302: Pop-up for Create SR/SO - no PLUS symbol for effort [#1759](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1759)
- [**bug**][**RD_01.23**] 27271: HotFix: SOCreation hanging after successful save [#1757](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1757)
- [**bug**][**RD_02.23**] 27292: Phase view, title is cut too late [#1754](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1754)
- [**bug**][**RD_02.23**] 27279: Phase view, title is cut too late [#1751](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1751)
- [**bug**][**RD_02.22**] 27271: SO delivery was hanging, although successful [#1748](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1748)
- [**bug**][**RD_02.23**] 27261: Excel Export Limit Note [#1745](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1745)
- [**bug**][**RD_02.23**] 27264: excel export for engagements value of global case is missing [#1742](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1742)
- [**bug**][**RD_02.23**] 27240: HEP Bug with Variant Management [#1738](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1738)
- [**bug**][**RD_02.23**] 27260: HEP home screen - filter issue [#1735](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1735)
- [**bug**][**RD_02.23**] 27232: Fix draft plan ends infinite waiting loop #1726 [#1733](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1733)

#### Others

- [**unknown**] 26769: Attachments buttons confusing #1734 [#1743](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1743)
- [**unknown**] Merge RD_01.23 into DEV [#1720](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1720)
- [**RD_01.23**] Updated changelog for release RD_01.23_v3.1 [#1719](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1719)

---

## RD_01.23_v3.1 (28/01/2023)

#### Enhancements

- [**new feature**][**RD_01.23**] 27208: SR Description not displayed as alternative description in draft plan [#1718](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1718)
- [**bug**][**new feature**][**RD_01.23**] 27154: P2 SPD - add list of services: errors when entering multiple IDs [#1697](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1697)
- [**new feature**][**RD_01.23**] 27120: hide button "assign myself as consultant" if user already assigned (part3) [#1685](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1685)
- [**new feature**][**RD_02.23**] 26877: add 4 hidden columns to standard view [#1664](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1664)
- [**new feature**][**RD_02.23**] 27115: Implement Front-End Changes [#1663](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1663)
- [**new feature**][**RD_01.23**] 26863: improvements on UI for service order+assign myself as consultant [#1653](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1653)
- [**new feature**][**RD_01.23**] 25689: Add List of Services (199) (FE) [#1646](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1646)
- [**new feature**][**RD_01.23**] 26734: Add favorite [#1645](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1645)
- [**new feature**][**RD_01.23**] 26734: HEP2 - customer project list in engagements - add variants [#1644](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1644)
- [**new feature**][**RD_01.23**] 26734: customer project list in engagements - add filter and variants [#1642](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1642)
- [**new feature**][**RD_01.23**] 26976: Harmonize the width of the filter fields [#1640](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1640)
- [**new feature**][**RD_11.22**] 25966: ZCTF Flag on HEP UI [#1632](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1632)
- [**new feature**][**RD_01.23**] 26618: Indicate set list filters [#1630](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1630)
- [**new feature**] 26872: entry screen free text search add info which fields are taken into account [#1627](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1627)

#### Bugfixes

- [**bug**][**RD_01.23**] 27046: Do not display cancelled Service Plan items initially. [#1716](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1716)
- [**bug**][**RD_01.23**] 27209: Service order which was cancelled based on status new has action "assign myself" and "URL to ISD Hub" [#1717](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1717)
- [**bug**][**RD_01.23**] 27209: Service order which was cancelled based on status new has action "assign myself" and "URL to ISD Hub" [#1715](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1715)
- [**bug**][**RD_01.23**] 27207: changed creation of SR SO from batch to single calls with progress indicator [#1714](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1714)
- [**bug**][**RD_01.23**] 27165: Fix to open details popup also in phase view [#1712](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1712)
- [**bug**][**RD_01.23**] 27209: Service order which was cancelled based on status new has action "assign myself" and "URL to ISD Hub" [#1713](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1713)
- [**bug**][**RD_01.23**] 27183: https://jira.tools.sap/browse/KNGMHM02-27183 [#1709](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1709)
- [**bug**][**RD_01.23**] 27133: Engagement - change main contract - label shows wrong content [#1707](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1707)
- [**bug**][**RD_01.23**] 27183: Link to MCC [#1705](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1705)
- [**bug**][**RD_01.23**] 27171: Add list of services hangs on random input [#1703](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1703)
- [**bug**][**RD_01.23**] 27133: Engagement - change main contract - label shows wrong content [#1704](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1704)
- [**bug**][**RD_01.23**] 27133: Engagement - change main contract - label shows wrong content [#1701](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1701)
- [**bug**][**RD_01.23**] 27165: fix edit draft plan icon not working [#1700](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1700)
- [**bug**][**RD_01.23**] 27162: P3 "Add list of service" populates Alternative Description [#1698](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1698)
- [**bug**][**RD_01.23**] 27121: Change wording for "Customer for Call-Off" in info text [#1696](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1696)
- [**bug**][**RD_01.23**] KNGMHM02-27160: Parties Involved: Search UserID is case sensitive [#1695](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1695)
- [**bug**][**RD_01.23**] 27146: add list of services: after "cancel", stuck in the wrong window [#1692](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1692)
- [**bug**][**RD_01.23**] 27140: Add list of services - blank erroneously created entries do not vanish [#1688](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1688)
- [**bug**][**RD_01.23**] 27128: Engagement - customer projects - define variant - search - system does not come back [#1684](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1684)
- [**bug**][**RD_01.23**] 27133: Engagement - change main contract - label shows wrong content [#1682](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1682)
- [**bug**][**RD_01.23**] 27131: add list of services, without separator [#1683](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1683)
- [**bug**][**RD_01.23**] 27128: customer projects - define variant - search - system does not come back [#1681](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1681)
- [**bug**][**RD_01.23**] 27127: Home Screen - the bar to indicate the filter is not showing up again [#1677](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1677)
- [**bug**][**RD_01.23**] 27120:-only show three icons on Project Service Plan "Actions" column (part 2) [#1675](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1675)
- [**bug**][**RD_01.23**] 27116: Busy indicator lock on submitting the ComponentID [#1676](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1676)
- [**bug**][**RD_01.23**] 27120: remove underline in project service plan actions [#1672](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1672)
- [**bug**][**RD_01.23**] 27122: fix for components loading if bad master data in ss cor crm [#1674](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1674)
- [**bug**][**RD_01.23**] 27118: fix service plan list action buttons [#1662](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1662)
- [**bug**][**RD_01.23**] 27117: fix issue with service order messages - wrong longtext for first item [#1661](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1661)
- [**bug**][**RD_01.23**] 27097: fixed app hanging when closing a project and save [#1655](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1655)
- [**bug**][**RD_01.23**] 27098: "MaxAttention" badge in engagement header was not cleared after last contract deletion [#1656](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1656)
- [**bug**][**RD_01.23**] 27050: Issue with HEP PC sort in exec plan Call [#1657](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1657)
- [**bug**][**RD_01.23**] 26618: HEP2 - Home Screen - Indicate set list filters - Check on Themes [#1652](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1652)
- [**bug**] 26996: ContractLabel - Delay in updating on change of main contract [#1643](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1643)
- [**bug**][**RD_11.22**] 27000: Multiple SO Creation on HTTP 504 [#1639](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1639)
- [**bug**][**RD_01.23**] 27023: dark theme info icon of free text search almost not visible [#1641](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1641)
- [**bug**][**RD_01.23**] KAM_KNGMHM02-26932_ContractLabelVanishing [#1638](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1638)
- [**bug**][**RD_11.22**] 26913: Engagement Badge refresh after contract assignment changes [#1631](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1631)

#### Others

- [**RD_01.23**] Merge Dev into RD01 [#1691](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1691)
- [**unknown**] Merge rd11 hotfixes into dev [#1647](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1647)
- [**can be tested**][**RD_01.23**] 26769: attachment list limit & fix UI deprecated component  [#1637](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1637)
- [**RD_01.23**] 25805: improve ssc interface [#1634](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1634)
- [**unknown**] Merge rd11 into dev [#1633](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1633)
- [**unknown**] Merge rd10 into dev [#1626](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1626)
- [**RD_10.22**] Updated changelog for release RD_10.22_v2.7 [#1625](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1625)

---

## RD_10.22_v2.7 (28/10/2022)

#### Enhancements

- [**new feature**][**RD_10.22**] 26846: provide refresh button for project area [#1619](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1619)
- [**new feature**][**RD_10.22**] 26842: set GoLive-Date to end of Deploy Phase for CreateProject [#1615](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1615)
- [**new feature**][**RD_10.22**] 26831: bad phases prevent Save EditProject + column DocType Fix in TTE [#1608](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1608)
- [**new feature**][**RD_10.22**] 26815: changed wording for open plan selector button [#1601](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1601)
- [**new feature**][**RD_10.22**] 26830: Text in column DocumentType in TTE Dialog changed [#1599](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1599)
- [**new feature**][**RD_10.22**] 26821: adjust problems-with-phases warning in edit-project-dialog [#1592](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1592)
- [**new feature**][**RD_10.22**] 26815: Change Button to open selector on service plan tab [#1591](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1591)
- [**new feature**][**RD_10.22**] 26801: HEP home screen lists - adjust pagination [#1582](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1582)
- [**bug**][**new feature**][**RD_10.22**] 26800: Also open projects with EMPTY methodology (initiative) + FreqTools: SSC link update [#1580](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1580)
- [**new feature**][**RD_11.22**] 26729: add Top Issue ID to the result list [#1579](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1579)
- [**bug**][**new feature**][**RD_10.22**] 26795 edit phases reduce restrictions and more [#1574](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1574)
- [**new feature**][**RD_10.22**] 26801: HEP home screen lists - adjust pagination [#1569](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1569)
- [**new feature**][**RD_10.22**] 26566 projects update redesign part 2 [#1544](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1544)
- [**new feature**][**RD_10.22**] 26566 projects update redesign [#1543](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1543)
- [**new feature**][**RD_10.22**] 26678: Ensure SAVE of re-arrangements [#1542](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1542)
- [**new feature**][**RD_10.22**] 23694: change customer search [#1540](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1540)
- [**new feature**][**RD_08.22**] 26557: Changing the test environment URL to prod URL [#1539](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1539)
- [**new feature**][**RD_08.22**] 26557: Change color of status New for the Home screen. [#1538](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1538)
- [**new feature**][**RD_10.22**] 26725: Sold-To-Party No [#1537](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1537)
- [**new feature**][**RD_10.22**] 25135: Link to external apps [#1535](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1535)
- [**new feature**][**RD_10.22**] 25754 new dialog for creation of projects [#1534](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1534)
- [**new feature**][**RD_10.22**] 24231: enhance BP search for account contact on service order [#1532](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1532)
- [**new feature**][**RD_10.22**] 26196: Identify level of PE service contract [#1531](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1531)
- [**new feature**][**RD_10.22**] 26498: Remove fields for Journey Checks from SO creation/update UI (FE + BE) [#1530](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1530)
- [**new feature**][**RD_08.22**] 26557 : frequently used tools link to usage analyzer [#1527](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1527)
- [**new feature**][**RD_10.22**] 26616: Top Issues Link to CRM [#1526](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1526)
- [**new feature**][**RD_10.22**] 26284: extend session expiration of hep [#1520](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1520)
- [**new feature**][**RD_10.22**] 26590: open draft plan direct after creation [#1516](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1516)
- [**new feature**][**RD_10.22**] 23979: Add Button Search Task [#1514](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1514)
- [**new feature**][**RD_10.22**] 26011: HEP2 - Updates on projects - adjust service plan view + drag & drop [#1513](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1513)
- [**new feature**][**RD_10.22**] 26528: Services Home Sort Order [#1511](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1511)

#### Bugfixes

- [**bug**][**RD_10.22**] 26854: update mobile reporting PART2 [#1623](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1623)
- [**bug**][**RD_10.22**] 26854: update mobile reporting [#1622](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1622)
- [**bug**][**RD_10.22**] 26849: adjusted tooltip for operations projects [#1621](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1621)
- [**bug**][**RD_10.22**] 26847: Search criteria on project list on engagement do not work - 1 - "My favorite projects" [#1618](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1618)
- [**bug**][**RD_10.22**] 26844: Fixed rating coloring in engagements [#1616](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1616)
- [**bug**][**RD_10.22**] 26841: Create Project with field ReasonCode set [#1612](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1612)
- [**bug**][**RD_10.22**] 26830 Text in column DocumentType in TTE Dialog changed PART2 [#1610](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1610)
- [**bug**][**RD_10.22**] 26840: in same case the attachment is not downloaded on local pc #1603 [#1609](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1609)
- [**bug**][**RD_10.22**] 26832: HEP SPD draft plan with project phases WITH dates - only RUN phase offered [#1602](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1602)
- [**bug**][**RD_10.22**] 26826: Clean Up project service plan section when navigating to Engagemnts or Home [#1598](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1598)
- [**bug**][**RD_10.22**] 26815: Change Button to open selector on service plan tab FIX [#1594](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1594)
- [**bug**][**RD_10.22**] 26817: Item count in SR/SO creation window is not updated [#1593](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1593)
- [**bug**][**RD_10.22**] 26812: Harmonized List View shows Letters instead of rating [#1590](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1590)
- [**bug**][**RD_10.22**] 26814: fix for Home Services Free Text Search Field AND renamed ProjMetho to Intiative [#1585](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1585)
- [**bug**][**RD_10.22**] 26813: top issue list - no scroll bar [#1583](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1583)
- [**bug**][**RD_10.22**] KAM_KNGMHM02-26763_SendFeedbackOption [#1576](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1576)
- [**bug**][**RD_10.22**] 26808: Deleted Service Plan is still shown [#1578](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1578)
- [**bug**][**RD_10.22**] 26804: Harmonized List View shows Letters instead of rating [#1575](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1575)
- [**bug**][**RD_10.22**] 26678: Ensure SAVE of re-arrangements [#1556](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1556)
- [**bug**][**RD_08.22**] 26557: Fixing Formatter issue [#1541](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1541)
- [**bug**][**RD_10.22**] 26648: SAP User [#1536](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1536)
- [**bug**][**RD_10.22**] 26615: HEP draft plan Re-Arrange button not active [#1533](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1533)
- [**bug**][**RD_08.22**] 26659: Survey Recipient always mandatory - again [#1529](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1529)
- [**bug**][**RD_08.22**] 266601: Fix Service Item Search [#1528](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1528)
- [**bug**][**RD_10.22**] 26659: Survey Recipient always mandatory - again [#1524](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1524)
- [**bug**][**RD_10.22**] 26593: Busy Indicators Fix [#1522](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1522)
- [**bug**][**RD_10.22**] 26635: adding sessions to draft plan and clicking twice on save leads to duplicate sessions in the draft plan [#1521](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1521)
- [**bug**][**RD_10.22**] 26593: Fix the busy indicator issue on Service Plan tab (Project) while initial loading [#1519](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1519)
- [**bug**][**RD_10.22**] 26587: HEP Event-Bus Refactoring  [#1518](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1518)

#### Others

- [**RD_10.22**] 26566 Projects updates redesign PART 4 [#1559](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1559)
- [**RD_10.22**] 26566 projects update redesign part 3 [#1557](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1557)
- [**unknown**] Fix Issue User ID [#1551](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1551)
- [**RD_10.22**] Merge rd 08.22 into rd 10.22 [#1547](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1547)
- [**unknown**] 26644: Add statuses to drop down [#1525](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1525)
- [**unknown**] 26624: Column Sorting Fix [#1515](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1515)
- [**RD_08.22**][**RD_10.22**] Merge RD08 to DEV [#1512](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1512)
- [**RD_08.22**] Updated changelog for release RD_08.22_v1.0 [#1510](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1510)

---

## RD_08.22_v1.0 (27/08/2022)

#### Enhancements

- [**new feature**][**RD_08.22**] 26592: change message to Save items before re-arrange in Project Plan Draft [#1507](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1507)
- [**new feature**][**RD_08.22**] 26563: Sort Service Items after Phase and Date [#1490](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1490)
- [**new feature**][**RD_08.22**] 26519: Service plan version list - improvements [#1482](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1482)
- [**new feature**][**RD_08.22**] 26544: cancel of SO sessions and SO has several session [#1481](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1481)
- [**new feature**][**RD_08.22**] 26523: Phase view to use same excel export as list view [#1464](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1464)
- [**new feature**][**RD_08.22**] 26485 new project phases popup for editing [#1454](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1454)
- [**new feature**][**RD_08.22**] 26488: Adjust UI for Engagement Views (My Engagements/All Engagements) to show HigherLevelCaseID [#1438](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1438)
- [**new feature**][**RD_08.22**] 26205: Create Engagement with status "In process" FE+BE [#1444](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1444)
- [**new feature**][**can be tested**][**RD_08.22**] 25916: Authorization check [#1439](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1439)
- [**new feature**][**RD_08.22**] 25475: Harmonize List View [#1442](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1442)
- [**new feature**][**RD_08.22**] 26170: Harmonize List View-Manage Drafts-Sort Drafts [#1441](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1441)
- [**new feature**][**RD_08.22**] 25457: Harmonize Phase View 86-2 (FE) - Phase view [#1440](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1440)
- [**new feature**][**RD_08.22**] 26211: HEP2 - Harmonize List View 86-1 (FE) [#1435](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1435)

#### Bugfixes

- [**bug**][**RD_08.22**] 26600: Adapt column width [#1509](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1509)
- [**bug**][**RD_08.22**] 26598: substiuted Gantt-Chart-Tabs from Engagement and Global Engagement by simple lists [#1508](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1508)
- [**bug**][**RD_08.22**] 26588: Fixing Reverse Order [#1504](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1504)
- [**bug**][**RD_08.22**] 26586: add Single Service or add download Services from a package - SAVE button is missing [#1502](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1502)
- [**bug**][**RD_08.22**] 26585: Change and SAVE of project phase dates DEACTIVATES button "Select service plan version" [#1501](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1501)
- [**bug**][**RD_08.22**] 24534: Fixing the navigate to item issue in Engagement Home view [#1497](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1497)
- [**bug**][**RD_08.22**] 26571: Rapid clicking on "Create" creates multiple drafts [#1498](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1498)
- [**bug**][**RD_08.22**] 24534: Removing remaining Gantt artefacts [#1494](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1494)
- [**bug**][**RD_08.22**] 24534: Fixing the navigation back issue after sending SO to Delivery [#1491](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1491)
- [**bug**][**RD_08.22**] 26538: Toggling between versions - Two blue bars [#1486](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1486)
- [**bug**][**RD_08.22**] 26529: Only check for available contract for SPD Proposal items [#1479](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1479)
- [**bug**][**RD_08.22**] 26537: Draft Phase View - SO in status NEW - No move of session box to the correct phase after change of requested delivery date [#1477](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1477)
- [**bug**][**RD_08.22**] bug fix [#1475](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1475)
- [**bug**][**RD_08.22**] 26537: Github Issue #1466 : Draft Phase View [#1473](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1473)
- [**bug**][**RD_08.22**] 26506: Version selection screen deforms table #1445 [#1467](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1467)
- [**bug**] 26525: Fixed Breadcrumb Home-navigation in project details [#1465](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1465)
- [**bug**][**RD_08.22**] 26509: No return after unsuccessful SO cancellation attempt [#1462](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1462)
- [**bug**][**RD_08.22**] 26509: No return after unsuccessful SO cancellation attempt [#1452](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1452)
- [**bug**][**RD_08.22**] 25812: Harmonize List View [#1443](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1443)

#### Others

- [**unknown**] 26561: save of standard list display variant does not work [#1489](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1489)
- [**RD_07.22**] Merge changelog commit RD07 into dev [#1437](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1437)
- [**unknown**] Updated changelog for release RD_07.22_v1.0 [#1436](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1436)

---

## RD_07.22_v1.0 (01/08/2022)

#### Enhancements

- [**new feature**][**RD_07.22**] Change color of status New to a more readable one. [#1388](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1388)
- [**new feature**][**RD_07.22**] 26441: Add New to the opening selection window of New Partner [#1429](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1429)
- [**new feature**][**RD_08.22**] Update Variant [#1427](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1427)
- [**new feature**][**RD_08.22**] 23695: save named variant [#1414](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1414)
- [**new feature**][**RD_08.22**] KNGMHM02-25477: Harmonize List View [#1406](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1406)
- [**new feature**][**RD_08.22**] 25477: Harmonize List View 86- List view [#1405](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1405)
- [**new feature**][**RD_05.22**]  26190: update link to engagement health index  [#1404](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1404)
- [**new feature**][**RD_08.22**] 26210: Umbrella1 - SPEED improvements [#1401](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1401)
- [**new feature**][**RD_08.22**] 26210: Project service plan section Ubrella 1 fixes [#1400](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1400)
- [**new feature**] 26210 project service plan umbrella1 [#1399](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1399)
- [**new feature**][**RD_07.22**] 26282: Set-Up Mock-Server [#1398](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1398)
- [**new feature**][**RD_05.22**] 26190: Updated Link for Engagement Health Index [#1392](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1392)
- [**new feature**][**RD_07.22**] 26161: remaining filter [#1390](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1390)
- [**new feature**][**RD_07.22**] 26167: Do NOT display "Service Type" anymore [#1385](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1385)

#### Bugfixes

- [**bug**][**RD_07.22**] 26434: HEP Search for people only with * or first name entered [#1433](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1433)
- [**bug**][**RD_07.22**] 26441: Add New to the opening selection window of New Partner [#1432](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1432)
- [**bug**][**RD_07.22**] 24534: Change color of status New for the Home screen. [#1431](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1431)
- [**bug**][**RD_07.22**] 26441: Add New to the opening selection window of New Partner [#1430](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1430)
- [**bug**][**RD_05.22**] 26326: issue with hep pc spd gc assignment not [#1419](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1419)
- [**bug**][**RD_07.22**] 26379: Mandatory Fields Issue [#1418](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1418)
- [**bug**][**RD_05.22**]  26202: adding party involved gets stuck [#1417](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1417)
- [**bug**][**RD_07.22**] 26144 create so cbx refresh issue [#1411](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1411)
- [**bug**][**RD_07.22**] 26144 cbx not set correctly after SO creation [#1410](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1410)
- [**bug**][**RD_08.22**] 26360 account statement fixing leading zeros AND bulletproffing service selection in projects AND project solution scope double fragment fix [#1409](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1409)
- [**bug**][**critical**][**RD_07.22**] 26360 fix account statement link adding leading zeros and bulletproofing select service product for project [#1408](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1408)
- [**bug**][**critical**][**RD_05.22**] 26360 Account Statement fix leading zeros and bulletproofing add service selection for projects [#1407](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1407)
- [**bug**][**RD_05.22**] 26264: item sorted into to wrong phase - not phase information should be used but the dates [#1397](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1397)
- [**bug**][**RD_05.22**] KAM_KNGMHM02-26189_IssuesWithSurveyRec4_RD05 [#1395](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1395)
- [**bug**][**RD_05.22**] KAM_KNGMHM02-26189_IssuesWithSurveyRec2_RD05 [#1393](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1393)
- [**bug**][**RD_05.22**] 26189: Fix Issues with Survey Recipient and Send Feedback option [#1391](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1391)
- [**bug**][**RD_07.22**] 26191: Changing Component of Item in SPD [#1387](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1387)
- [**bug**][**RD_05.22**] 26189: Fix Issues with Survey Recipient and Send Feedback option [#1386](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1386)
- [**bug**][**RD_05.22**] Change status color shades [#1383](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1383)

#### Others

- [**unknown**] Merge rd07 into dev [#1434](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1434)
- [**RD_07.22**] Merge missing rd05 fix to rd07 [#1424](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1424)
- [**critical**][**RD_05.22**] fixes error introduced by original fix made for 26202 [#1423](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1423)
- [**RD_07.22**] Merge missing RD05 fix to RD07  [#1421](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1421)
- [**critical**][**RD_07.22**] 26244: Fix error Fragment 404 when opening Projects [#1403](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1403)
- [**critical**][**RD_05.22**] 26244 hot fix fragment error when loading project [#1402](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1402)
- [**can be tested**] 24661: Update recipient list in JenkinsFile [#1396](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1396)
- [**RD_05.22**] Update dev from RD_05.22 [#1342](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1342)
- [**RD_05.22**] Updated changelog for release RD_05.22_v1.1 [#1384](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1384)

---

## RD_05.22_v1.1 (20/05/2022)

#### Enhancements

- [**RD_05.22**][**new feature**] 26138: Guide the End Date Selection based on existing Start Date [#1376](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1376)
- [**RD_05.22**][**new feature**] 25156 mur fix part4 [#1362](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1362)
- [**RD_05.22**][**new feature**] 25156: fix for TEST-Environment [#1360](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1360)
- [**RD_05.22**][**new feature**] 25977 update mur events tracked part2 [#1358](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1358)

#### Bugfixes

- [**RD_05.22**][**bug**] 26154: Tile Height is varying with the status [#1382](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1382)
- [**RD_05.22**][**bug**] 26103: changes to Component ID field were not recongnized in some cases [#1381](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1381)
- [**RD_05.22**][**bug**] 26146: Phase view - no separation between boxes [#1379](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1379)
- [**RD_05.22**][**bug**] 25678: Phase Dates are not saved properly [#1378](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1378)
- [**RD_05.22**][**bug**] 26137: Criteria for sorting Engagements [#1377](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1377)
- [**RD_05.22**][**bug**] 25678: Phase Dates are not saved properly [#1375](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1375)
- [**RD_05.22**][**bug**] 26134 spdtte show remaining call off days [#1373](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1373)
- [**RD_05.22**][**bug**] 26139: Add one column to default view of "Services" in Home [#1372](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1372)
- [**RD_05.22**][**bug**] 26134: spdtte show remaining call off days [#1371](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1371)
- [**RD_05.22**][**bug**] 26134: implemented change to see remaining days in contract combo [#1369](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1369)
- [**RD_05.22**][**bug**] 26104: Improve upon the Phase selection issue [#1367](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1367)
- [**RD_05.22**][**bug**] 24534: Changing color of proposal SPD items and items in Scoping/Exception [#1366](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1366)
- [**RD_05.22**][**bug**] 26103: spd add service dialog component id pasting error [#1359](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1359)
- [**RD_05.22**][**bug**] 24661: Home - Fixing legend and status colouring + rename tab to Services [#1347](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1347)
- [**RD_05.22**][**bug**] 26126: SPD Tile descriptions are strangely truncated [#1363](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1363)
- [**RD_05.22**][**bug**] 26062: Github Issue #1317 [#1361](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1361)
- [**RD_05.22**][**bug**] 26095: Cannot Remove Altern. Description [#1356](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1356)
- [**RD_05.22**][**bug**] 26097: [Search SR/SO view] Updating SR in Quickview [#1357](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1357)
- [**RD_05.22**][**bug**] 26060: SPD contract issues [#1353](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1353)
- [**RD_05.22**][**bug**] 26095: Cannot Remove Altern. Description [#1352](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1352)

#### Others

- [**RD_05.22**] Update changelog [#1348](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1348)

---

## RD_05.22_v1.0 (12/05/2022)

#### Enhancements

- [**RD_05.22**][**new feature**] 26068: Remove / hide Actions column [#1337](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1337)
- [**RD_05.22**][**new feature**] 25156: track events for mobile reporting [#1280](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1280)
- [**RD_05.22**][**new feature**] 25810: Harmonize List View for Search Services FE [#1314](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1314)
- [**RD_05.22**][**new feature**] 26049: SR/SO Creation: In narrow windows the Dates cannot be read [#1316](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1316)
- [**RD_05.22**][**new feature**] 26038:Search SR/SO - ProjectName/Title not linked as requested [#1318](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1318)
- [**RD_05.22**][**new feature**] 25812: Harmonize List View for Search Services FE [#1294](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1294)
- [**RD_05.22**][**new feature**] 25957: HEP & SPD - FE Improvements - Date Conversion for SPD fields [#1293](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1293)
- [**RD_05.22**][**new feature**] 24534: Show alert if service is not matching based on customer contract [#1278](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1278)
- [**RD_05.22**][**new feature**] 25812:Harmonize List View for Search Services FE [#1279](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1279)
- [**RD_05.22**][**new feature**] Ser kngmhm02 24583 insufficient info for sr [#1273](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1273)
- [**RD_05.22**][**new feature**] 25849: EngCaseAssignedContractLinkToAccountStatementPART2 [#1275](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1275)
- [**RD_05.22**][**new feature**] 24799 enhanced integration with srs PART4 [#1271](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1271)
- [**RD_05.22**][**new feature**] 24799 enhanced integration with srs PART3 [#1270](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1270)
- [**RD_05.22**][**new feature**] 24799 enhanced integration with srs Part2 [#1267](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1267)
- [**RD_05.22**][**new feature**] 25690: HEP2 - Search SR/SO (198a) - BE+FE [#1269](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1269)
- [**RD_05.22**][**new feature**] 25849: Show new Icon account statement for in Eng-Contacts [#1268](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1268)
- [**RD_05.22**][**new feature**] 24799: enhanced integration with srs [#1255](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1255)
- [**RD_05.22**][**new feature**] 25690: Search SR/SO [#1266](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1266)
- [**RD_05.22**][**new feature**] KNGMHM02-25812: Harmonize List View for Search Services FE [#1265](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1265)
- [**RD_05.22**][**new feature**] 25794: Harmonize List View for search services [#1264](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1264)
- [**RD_05.22**][**new feature**]  25121: improve adding single items [#1262](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1262)
- [**RD_05.22**][**new feature**] 22625 Survey Recipient SH - Adapt filed logic and popup  [#1263](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1263)
- [**RD_05.22**][**new feature**] 23929: remove Q-Gates FE (2) [#1260](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1260)
- [**RD_05.22**][**new feature**] 25690: HEP2 - Search SR/SO (198a) - BE+FE (only Frame) [#1261](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1261)
- [**RD_05.22**][**new feature**] 25043: Remove Go-Live Date Field in (Global) Engagement Case [#1259](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1259)
- [**RD_05.22**][**new feature**] 23929: Remove Q Gates FE [#1258](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1258)
- [**RD_02.22**][**new feature**] 25434: Link from HEP SO to ISD Hub [#1251](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1251)
- [**RD_02.22**][**new feature**] 25434: Link from HEP SO to ISD Hub [#1250](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1250)
- [**RD_02.22**][**new feature**] 25434: Link from HEP SO to ISD Hub [#1249](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1249)
- [**RD_02.22**][**new feature**] 25609: HEP Parties Involved - Service Team wrong search behavior [#1246](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1246)

#### Bugfixes

- [**RD_05.22**][**bug**] 26077: SPD Missing Tool Tip after Contract Selection [#1346](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1346)
- [**RD_05.22**][**bug**] 24534: Suppress Drag&Drop message [#1344](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1344)
- [**RD_05.22**][**bug**] 26074: XSS Vulnerability Attachment Download [#1343](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1343)
- [**RD_05.22**][**bug**] 26072: AccountContractID undefined on empty submit [#1340](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1340)
- [**RD_05.22**][**bug**] 26070: SR/SO Creation from SPD - Service Order Group Flagged as Mandatory [#1338](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1338)
- [**RD_05.22**][**bug**] 26063: Phase selection grayed out [#1334](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1334)
- [**bug**] 24534: Changing the buttons in Quickview Maintenance view [#1332](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1332)
- [**RD_05.22**][**bug**] 26062: Github Issue #1317 [#1328](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1328)
- [**RD_05.22**][**bug**] 26052 mising account statement for main contract [#1325](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1325)
- [**RD_05.22**][**bug**][**critical**] 26055 - SPD - fix navigation to General- and List-Tab [#1327](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1327)
- [**RD_05.22**][**bug**] 26053: Search SR/SO - column width #1303 [#1326](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1326)
- [**RD_05.22**][**bug**] 26047 endless waiting when updating spd item PART2 [#1323](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1323)
- [**RD_05.22**][**bug**] 24534: Warning icon assignment [#1313](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1313)
- [**RD_05.22**][**bug**] 26044: Survey Recipient automatically copied [#1310](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1310)
- [**RD_05.22**][**bug**] 25530: P3 SPD list view - excel export - start and end date differ from UI #1197 [#1315](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1315)
- [**RD_05.22**][**bug**] 26047_fix_crash_when_endDate_not_filled [#1312](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1312)
- [**RD_05.22**][**bug**] 26038:Search SR/SO - in result list klick on line containing a SR - open pop-up klick on URL to SRS App [#1307](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1307)
- [**RD_05.22**][**bug**] 26036: Update Postman file [#1306](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1306)
- [**RD_05.22**][**bug**] bug fix [#1304](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1304)
- [**RD_05.22**][**bug**] Fixing Add item issue if contract check is positive. [#1305](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1305)
- [**RD_05.22**][**bug**] 24534: Fixing warning icon check [#1297](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1297)
- [**RD_05.22**][**bug**] 25858:Issue with File upload in Engagement Cases (Umlaute) [#1289](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1289)
- [**RD_05.22**][**bug**] 26021: urgent fixes in SPD controller to prevent hanging and crashes [#1290](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1290)
- [**RD_05.22**][**bug**] 25999: HEP2 - CIP - Improve phase layout, increase size of service plan items for big screens [#1277](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1277)
- [**RD_05.22**][**bug**] 25695: Fix for SPD Item deletion triggered Two DELETE-Requested to BE [#1276](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1276)
- [**RD_05.22**][**bug**] 25753: HEP2 - Search SR/SO - variants (198b) - BE+FE [#1272](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1272)
- [**RD_05.22**][**bug**] 25580: Remove 404 errors [#1256](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1256)
- [**RD_05.22**][**bug**] 25733: Github Issue: #1080 Set Header Busy [#1257](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1257)
- [**RD_05.22**][**bug**] 25678: Phase Dates are not saved properly [#1252](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1252)

#### Others

- [**RD_02.22**] Update dev from RD02 (hotfix) [#1254](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1254)
- [**RD_02.22**] Update dev from RD02 [#1253](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1253)
- [**RD_02.22**] Changelog Update RD_02.22 [#1248](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1248)

---

## RD_02.22_v1.0 (25/02/2022)

#### Enhancements

- [**new feature**] 24834: spd26 part2 logic adding packages [#1058](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1058)
- [**new feature**] 25090: Remove Popover for Engagement Case field [#1056](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1056)
- [**RD_02.22**][**new feature**] 25434: Link from HEP SO to ISD Hub [#1243](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1243)
- [**RD_02.22**][**new feature**]  25434: link from hep so to isd hub [#1234](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1234)
- [**RD_05.22**][**new feature**] 24602: Allow Phase Changes (Moving Services via Drag&Drop) [#1231](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1231)
- [**RD_02.22**][**new feature**] 25657: Guide the end date selection based on existing start date [#1233](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1233)
- [**RD_02.22**][**new feature**] 25273: SPD: Search Focus Package Dialog: Show sortIndicator on initial load … [#1229](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1229)
- [**RD_02.22**][**new feature**] 25655: SPD: when plan is in edit mode: Inform user via message toast that it… [#1228](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1228)
- [**RD_02.22**][**new feature**]  25434: link from hep so to isd hub [#1225](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1225)
- [**RD_02.22**][**new feature**] 25578: SO new CBX-combo entry - Evaluate Again [#1222](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1222)
- [**RD_02.22**][**new feature**] 25320: Link for Engagement Health Index [#1218](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1218)
- [**RD_02.22**][**new feature**] 23724: long texts in message area [#1204](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1204)
- [**RD_02.22**][**new feature**] KNGMHM02-25418 Hide SCP field in SO [#1203](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1203)
- [**RD_02.22**][**new feature**] 25144: Improve usage of End Date [#1201](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1201)
- [**RD_02.22**][**new feature**] 25310: Follow-up RD12.21 delivery (#1195) [#1196](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1196)
- [**RD_01.22**][**new feature**] 25310: Follow-up RD12.21 delivery [#1195](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1195)
- [**RD_02.22**][**new feature**] 25310: rd12 follow up AC5 sorting in focus package search [#1192](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1192)
- [**RD_02.22**][**new feature**]  25190: show field sap involvement in tables [#1193](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1193)
- [**RD_02.22**][**new feature**] 24582: shopping card function coming from ssc [#1191](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1191)
- [**RD_02.22**][**new feature**] 25190: Show field SAP Involvement in tables [#1189](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1189)
- [**RD_02.22**][**new feature**] 25315: HEP2 - SPD 42 - Allow select multiple items for deletion (179) - addendum [#1187](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1187)
- [**new feature**] 25312: Remove BETA from "Service Plan Drafts BETA" [#1182](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1182)
- [**new feature**] 25303: Item removal for SR/SO items in phase None [#1176](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1176)
- [**new feature**] 25305: Misleading Text in Header of Phase None [#1169](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1169)
- [**new feature**] 25303: Item removal for SR/SO items in phase None [#1168](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1168)
- [**new feature**] 25290: spd p1 some packages contain ps services [#1150](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1150)
- [**new feature**] 25238: Usability of Edit Mode in Service Plan Item [#1151](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1151)
- [**new feature**] 25243: Activate Phase View for all Project Methodologies and Show Message Strip [#1144](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1144)
- [**new feature**] 25243: SPD phase view for all methodology projects plus banner [#1132](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1132)
- [**new feature**] 25245: Removed the add button [#1113](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1113)
- [**new feature**] 24532: Phase View Add/Remove (114b) Big Picture/Umbrella [FE Only] [#1090](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1090)
- [**new feature**] 25255: Move Document ID & Link above the Service Scope Text [#1114](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1114)
- [**new feature**] 25225: SPD P3 inconsistent component description [#1097](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1097)
- [**new feature**] 25242: navigate to component in SSC on the add focus package component screen [#1106](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1106)
- [**new feature**] 25244: PoC Activate SPD Phase View for all Projects [#1110](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1110)
- [**new feature**] 25223: SPD P4 show number of selected components [#1095](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1095)
- [**new feature**] 25224: SPD -Add an item without saving, open item then button "save&request delivery" is activated  [#1096](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1096)

#### Bugfixes

- [**bug**] 25082: SPD bugfixes phase dates [#1057](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1057)
- [**bug**] 24501: Edit SP-item not only via in-place-edit [#1055](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1055)
- [**RD_02.22**][**bug**] 25681: Bug around the StartEnd date coupling [#1242](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1242)
- [**RD_02.22**][**bug**] 25676: SPD Phase Dates months are shown in different language [#1241](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1241)
- [**RD_02.22**][**bug**] 25677: Bug around the feature "Improve Usage of End Date" [#1240](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1240)
- [**RD_02.22**][**bug**] 25602: SPD hangs forever [#1236](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1236)
- [**RD_02.22**][**bug**] 25675: implemeting to allow 0.000 as effort when adding/changing an SPD [#1235](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1235)
- [**RD_02.22**][**bug**] 25538: Fix: field "Customer Name" was staying busy after entering a customer… [#1232](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1232)
- [**RD_02.22**][**bug**] 25658: HomeScreen Projects Tab: Fix sorting for column "Deployment Type" [#1230](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1230)
- [**RD_02.22**][**bug**] SPD: disable "Remove Services" and "Rearange Items" when no proposals… [#1227](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1227)
- [**RD_02.22**][**bug**] 25608: restore button on entry page [#1224](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1224)
- [**RD_02.22**][**bug**] 25622: Wrong default-effort for some components  [#1223](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1223)
- [**RD_02.22**][**bug**] 25601: SPD P2 Search for components not available [#1221](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1221)
- [**RD_02.22**][**bug**] 25600: Create Engagement - Remove leading zeros for BP search [#1219](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1219)
- [**RD_02.22**][**bug**] 25596: SPD Item cannot be saved anymore after user adjusted Start Date and the End Date was automatically adjusted [#1214](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1214)
- [**RD_02.22**][**bug**] 25546: Fix error message in Create SR/SO Start Date [#1202](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1202)
- [**RD_02.22**][**bug**] 25402: adjusted max attachment size to 10gb [#1190](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1190)
- [**RD_02.22**][**bug**] 25310: Follow-up RD12.21 delivery [#1188](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1188)
- [**bug**] 25273: sorting in fp components table [#1186](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1186)
- [**bug**] 25316: Effort was not updateable [#1185](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1185)
- [**bug**] 25316: Rearrange not Working [#1184](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1184)
- [**bug**] 25302: #1080 Slow default search for all components & Active "Go"-Button allows parallel search [#1183](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1183)
- [**bug**] 25309: Wrong phase dates displayed [#1179](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1179)
- [**bug**] 25309: Wrong phase dates displayed  [#1177](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1177)
- [**bug**] 25291: Update efforts failed [#1175](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1175)
- [**bug**] 25274: spd fp comp wrong sorting effort [#1172](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1172)
- [**bug**] 25308: column Create SR/SO in list view [#1174](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1174)
- [**bug**] 25244: SPD SO not created and no effort taken over for proposal [#1166](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1166)
- [**bug**] 25302: Slow default search for all components & Active "Go"-Button allows parallel search [#1159](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1159)
- [**bug**] 25301: RD12 - SPD P1 - Safari Usage [#1158](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1158)
- [**bug**] 25291: Wrong Efforts [#1154](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1154)
- [**bug**] 25300: RD12 - SPD: Confirmation during item removal #1148 [#1156](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1156)
- [**bug**] 25299: RD12.21 SPD P4 - F11+FullScreen prevents from using full screen height [#1155](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1155)
- [**bug**] 25296: HEP - Service Plan excel export empty dates [#1153](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1153)
- [**bug**] 25295: RD12.21 SPD P4 - Collapse / Expand Status Lost [#1152](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1152)
- [**bug**] 25287: Tile widths are impacted by hidden items in Phase None [#1146](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1146)
- [**bug**] 25283: Move of a service box pushes out a white proposal box from target phase [#1145](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1145)
- [**bug**] 25244: SPD SO not created and no effort taken over for proposal [#1143](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1143)
- [**bug**] 25272: spd p2 popup create srso not working properly part3 [#1140](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1140)
- [**bug**] 25272: PART2 spd p2 popup create srso not working properly [#1139](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1139)
- [**bug**] 25225: spd p3 inconsistent component description part2 [#1133](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1133)
- [**bug**] 25272: SPD P2 - Popup "Create SR/SO" not working properly [#1136](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1136)
- [**bug**] 25237: spd p2 list view item maintenance shows wrong buttons [#1138](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1138)
- [**bug**] 25263: SPD Tiles not Clickable [#1131](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1131)
- [**bug**] 25262: not possible to save some components new new [#1130](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1130)
- [**bug**] 25236: SPD P4 disable create srso button if nothing is selected [#1128](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1128)
- [**bug**] 25238: Usability in Edit Mode of Service Plan Item [#1111](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1111)
- [**bug**] 25042: HEP SO Creation [#1112](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1112)
- [**bug**] 25235: SPD P2 - Searching Package by "Package Description" is limited to only a "Package Name" search [#1101](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1101)
- [**bug**] 25209: Hyperlink from tile opens SO Maintenance in the same window #1069 [#1093](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1093)
- [**bug**] 25214: SPD P1 non_chronological_sequence_posible_and_saving_hang… [#1092](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1092)
- [**bug**] 25198: not all components show link [#1089](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1089)
- [**bug**] 25196: Vertical misalignment of Phase Header [#1079](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1079)
- [**bug**] 25210: Components with shorter description have a lower tile height #1071 [#1091](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1091)
- [**bug**] 25195: Unnecessary click when adding single item [#1078](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1078)
- [**bug**] 25191: Incomplete functionality of expand collapse buttons [#1076](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1076)
- [**bug**] 25194: Phase none second line in title missing [#1077](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1077)
- [**bug**] 25188: Link to Catalog is missing [#1075](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1075)
- [**bug**] 25169: Delete SPD Plan is not working as expected [#1062](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1062)

#### Others

- [**unknown**] Merge dev to RD12 [#1060](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1060)
- [**unknown**] Merge RD11 to dev [#1061](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1061)
- [**unknown**] Update dev from RD_11.21 [#1053](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1053)
- [**unknown**] Update changelog RD11.21 [#1051](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1051)
- [**unknown**] Added SAP Involvement Field in Project and Customer Projects Tab (#1193) [#1194](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1194)
- [**unknown**] Merge RD12 to dev [#1178](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1178)
- [**unknown**] 25291: Lost change - Changed binding to TotalEfforts and Efforts [#1160](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1160)
- [**unknown**] 25268: Text within Tiles must not be truncated [#1121](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1121)

---

## RD_11.21_v1.0 (19/11/2021)

#### Enhancements

- [**RD_11.21**][**new feature**] 25023: HEP - SPD - Fioriapp - Not all PE services shown in FE [#1045](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1045)
- [**RD_12.21**][**new feature**] 24502: SPD26 part1 - redesign adding FPs [#1036](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1036)
- [**RD_12.21**][**new feature**] 24533: spd27c phase view create srso(114c) [#1022](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1022)
- [**RD_12.21**][**new feature**] 24607: SPD 27a phase view design not scalable for large service plans [#1017](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1017)
- [**RD_12.21**][**new feature**] 24659: List View pop-up to edit an item (134b) - FE [#1014](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1014)
- [**RD_11.21**][**new feature**] 24815:Change assignment of Global Engagement case to Engagement Case [#1021](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1021)
- [**RD_11.21**][**new feature**] 22771: include field "SAP involvement" + add values [#1033](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1033)

#### Bugfixes

- [**RD_11.21**][**bug**] 25136: waterfall start date of last phase [#1047](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1047)
- [**RD_11.21**][**bug**] 25071: SPD BUG Add Item not working 2 [#1048](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1048)
- [**RD_11.21**][**bug**] 25102: PEA Link FLP side-effect which is only visible to FLP users. [#1046](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1046)
- [**RD_11.21**][**bug**] 25091: Extending the list of recipients as for dev branch. [#1043](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1043)
- [**RD_11.21**][**bug**] 25102: Adjust PEA link [#1035](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1035)
- [**RD_12.21**][**bug**] 24607: phase view not scalable bugfixes [#1020](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1020)
- [**RD_11.21**][**bug**] 25130: Github Issue #1042 [#1044](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1044)
- [**RD_11.21**][**bug**] 25042: HEP SO creation full scrolldown [#1040](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1040)
- [**RD_11.21**][**bug**] 25042: HEP SO creation full scrolldown not possible [#1037](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1037)
- [**RD_11.21**][**bug**] 25110 : SAP Involvement - change in customizing [#1038](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1038)
- [**RD_11.21**][**bug**] 25046: insert reduced postman testcases [#1039](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1039)
- [**RD_12.21**][**bug**] 25082: Bugfixes on SPD screen [#1034](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1034)
- [**RD_12.21**][**bug**] 24607: Phase View Design Bugfixes 2 [#1031](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1031)
- [**RD_11.21**][**bug**] 25071: SPD Bug Add Item not working [#1032](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1032)

#### Others

- [**unknown**] Dev revert [#1024](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1024)
- [**RD_11.21**] Update pull request template [#1018](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1018)
- [**RD 10.21**] changelog update rd10 [#1016](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1016)

---

## RD_10.21_v1.0 (22/10/2021)

#### Enhancements

- [**RD_11.21**][**new feature**] 24810: Project deployment type / new deployment type - add field to project list [#1013](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1013)
- [**RD 10.21**][**bug**][**new feature**] 24892: Parties Involved - Customer Competence Center > Value help does not work (closes #1007, #1005) [#1012](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1012)
- [**RD 10.21**][**new feature**] 24465: spd23 get effort and phase from ssc [#997](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/997)
- [**RD 10.21**][**new feature**] 24309: maintain parties involved [#983](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/983)
- [**RD 10.21**][**new feature**] 24668: Project_Deployment_Type [#986](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/986)
- [**RD_11.21**][**new feature**] 24501: Edit SP-Item not only via in-place-edit [#982](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/982)
- [**RD 10.21**][**new feature**] 23960: Ibase cloud data center [#977](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/977)
- [**new feature**] 23179: Jenkins Pipeline Update [#980](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/980)
- [**new feature**] 23179: Changed pipeline config [#971](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/971)
- [**new feature**] 23179: Updated karma.conf.js to use karma-ui5 [#959](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/959)
- [**RD 08.21**][**new feature**] 23296: Frequently Used Tools(2) (#957) [#963](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/963)
- [**RD 10.21**][**new feature**] 23409: SPD-18 Logging usage of Focus packages and Business scenarios[3] - BPRSD2018-2085 [#962](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/962)
- [**RD 08.21**][**new feature**] 23296: Frequently Used Tools(2) [#958](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/958)
- [**RD 08.21**][**new feature**] 23296: Frequently Used Tools(2) [#957](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/957)
- [**RD 10.21**][**new feature**] KAM_KNGMHM02-24458_IBaseEnhancementsCloud [#956](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/956)

#### Bugfixes

- [**RD 10.21**][**bug**] 24843: Issue with Alternative Requested Delivery [#1011](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1011)
- [**RD 10.21**][**bug**] 24861: SearchHelp CustomerCompetence Center not working (closes #1005) [#1006](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1006)
- [**RD 10.21**][**bug**] 24804: PartiesInvolved_Bugfixes [#1003](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1003)
- [**RD 10.21**][**bug**] 24819: RD.10 - HEP Parties Involved - Redundant Scroll Bar displayed [#1002](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1002)
- [**RD 10.21**][**bug**] 24801: rd10 spd - create so sr popup - check startdate <= enddate [#998](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/998)
- [**bug**] 24553: SO is created double [#979](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/979)
- [**bug**] 24493: Engagement Details cancel edit bugfix [#976](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/976)
- [**bug**] 24584: Fix of filter for search help in engagement case value help on project details screen [#978](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/978)
- [**bug**] 23179: Jenkins Pipeline configuration [#955](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/955)

#### Others

- [**RD 10.21**] release rd10 to dev [#1015](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/1015)
- [**RD 08.21**] 23296: Frequently Used Tools(2) (#957) [#994](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/994)
- [**unknown**] Woe kngmhm02 23179 karma conf [#966](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/966)

---

## RD_08.21_v1.0 (27/08/2021)

#### Enhancements

- [**RD 08.21**][**new feature**] 24508: Removed_account_statement_link [#950](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/950)
- [**RD 08.21**][**critical**][**new feature**] 23918: APIM Adjust all BE calls [#930](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/930)
- [**RD 08.21**][**new feature**] 23296: Frequently used tools [#932](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/932)
- [**new feature**] 23179: Integrate Jenkins pipeline [#925](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/925)

#### Bugfixes

- [**RD 08.21**][**bug**] 24519: Same note created multiple times [#953](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/953)
- [**RD 08.21**][**bug**] 24515: Attachment Security Improvements [#952](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/952)
- [**RD 08.21**][**bug**] 24527: Fixes attachment download failure [#951](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/951)
- [**RD 08.21**][**bug**] 24515: Security Improvements [#949](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/949)
- [**RD 08.21**][**bug**] 24499: Delete attachment not working [#948](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/948)
- [**RD 08.21**][**bug**][**critical**] 24499: Wrong error message while adding notes [#945](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/945)
- [**RD 08.21**][**bug**][**critical**] 23296: Frequently used links closes #933 [#934](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/934)
- [**RD 08.21**][**bug**] 24365: Implement Service Order Error Handling [#931](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/931)

#### Others

- [**unknown**] Kam kngmhm02 24382 batch init() [#926](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/926)

---

## RD_07.21_v1.0 (23/07/2021)

#### Enhancements

- [**RD 07.21**][**new feature**] 24207: Adjust search critera in eng case contract search [#912](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/912)
- [**RD 07.21**][**new feature**] 24191: Do EngContract main flag change with one BE call instead two [#909](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/909)
- [**RD 07.21**][**new feature**] 24208: Remove link from contract determination message [#908](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/908)
- [**RD 07.21**][**new feature**] 2416: Remove NoPhaseIcon in GantChart(s) [#905](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/905)
- [**RD 07.21**][**new feature**] 24062: Engagement Case Warning Correction: - show different warning depending on if contracts are assigned or not [#904](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/904)
- [**RD 07.21**][**new feature**] 24062: Updated warning message in engagement if no valid contract item is found [#893](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/893)
- [**RD 07.21**][**new feature**] 23403:contract determination info icon and warning icon [#888](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/888)
- [**RD 07.21**][**new feature**] 23838: Screen optimization in Service Plan Drafts  [#887](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/887)
- [**RD 07.21**][**new feature**] 23864: SPD improvements from CoE wishlist  [#886](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/886)
- [**RD 07.21**][**new feature**] 23031: Service Order, arrange RadioButtons horizontally in one line [#883](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/883)
- [**RD 07.21**][**new feature**] 23728: Field size for service questionnaire  [#882](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/882)

#### Bugfixes

- [**RD 07.21**][**bug**] 24186: Service Order Screen not shown [#902](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/902)
- [**RD 07.21**][**bug**] 24230: Minor text change (closes #913) [#922](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/922)
- [**RD 07.21**][**bug**] 24226:Improved wording for contract determination closes #911 [#918](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/918)
- [**RD 07.21**][**bug**] 24229:Improve Engagement Case Warning Message closes #914 [#915](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/915)
- [**RD 07.21**][**bug**] KAM_KNGMHM02-23923_SaveSOGroup [#880](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/880)
- [**RD 07.21**][**bug**] PET_KNGMHM02-23894 Consolidated i18n files [#881](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/881)

#### Others

- [**RD 07.21**] Release: Update dev from RD07.21 [#923](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/923)
- [**unknown**] Chris test [#897](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/897)
- [**unknown**] remove single quotes from stages [#896](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/896)
- [**unknown**] fix newman [#895](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/895)
- [**unknown**] disable newman [#890](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/890)
- [**RD 07.21**] 23551: Integrate Postman and Jenkins [#889](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/889)
- [**RD 07.21**] 23548: GW Client test cases [#885](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/885)
- [**unknown**] KAM_KNGMHM02-23336_NonProdSolMan [#866](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/866)

---

## RD_05.21v6.2 (26/05/2021)

#### Others

- [**RD 07.21**] Adjusted git relevant files [#876](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/876)

---

## RD_05.21_v6.1 (26/05/2021)
*No changelog for this release.*

---

## RD_05.21_v6.0 (26/05/2021)

#### Enhancements

- [**new feature**] KNGMHM02-23321 | PR template, issue templates, git administration [#874](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/874)
- [**RD 05.21**][**new feature**] PET_kngmhm02 22400 Introducing Journey Checks in Step 1 [#849](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/849)
- [**RD 05.21**][**new feature**] Ost kngmhm02 21985 eng case contracts [#820](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/820)
- [**RD 05.21**][**new feature**] LUT_KNGMHM02-23062_Column-Widths [#812](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/812)
- [**RD 05.21**][**new feature**] KAM_KNGMHM02-22918_UWS_Warning [#752](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/752)
- [**new feature**] PAS_KNGMHM02-21978_Edit-sections [#373](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/373)
- [**can be tested**][**new feature**] PAS_KNGMHM02-22264 SO Catalog  [#510](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/510)
- [**new feature**] SPD - first steps [#525](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/525)
- [**can be tested**][**new feature**] PAS_KNGMHM02-22478 SPD [#606](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/606)
- [**can be tested**][**new feature**] PAS_KNGMHM02-22536_Commerce [#644](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/644)
- [**new feature**] PAS_KNGMHM02-22013_Customer-projects [#372](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/372)
- [**new feature**] PAS_KNGMHM02-21970: Details pages improvements (another part) [#370](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/370)
- [**new feature**] PAS_KNGMHM-02_21728_Eng-case-vh [#369](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/369)
- [**new feature**] PAS_KNGMHM02-21974_Separate-eng-project-details_Part-2 [#366](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/366)
- [**new feature**] PAS_KNGMHM02-21974_Separate-Eng-Project-Details [#363](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/363)

#### Bugfixes

- [**RD 05.21**][**bug**][**critical**] KAM_KNGMHM02-23690_BillableStatusCode [#856](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/856)
- [**RD 05.21**][**bug**] LUT_KNGMHM02-23667_Wrong-error-message-when-creating-engagement-case   Lut kngmhm02 23667 wrong error message when creating engcase [#837](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/837)
- [**RD 05.21**][**bug**] [BUGFIX] #828 Error Message Corrected when edit engagement [#838](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/838)
- [**RD 05.21**][**bug**] KAM_KNGMHM02-23646_StandardVariantPersonalization - Column IDs [#835](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/835)
- [**bug**] LUT_KNGMHM02-23390_Fixed-effort-for-components [#800](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/800)
- [**bug**] LUT_KNGMHM02-23390_Maximum-Effort [#795](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/795)
- [**bug**] Deleted maximum effort #786 [#791](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/791)
- [**bug**][**can be tested**] WOE_KNGMHM02-23159: default date set to today [#749](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/749)
- [**bug**][**can be tested**] KAM_KNGMHM02-23126_FixAddingMemberItemss [#745](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/745)
- [**bug**][**can be tested**] Enlarged project description field [#593](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/593)
- [**bug**][**can be tested**] Ost kngmhm02 21960 fix ref obj popup not opening [#378](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/378)

#### Others

- [**RD 07.21**] Adjusted git relevant files [#876](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/876)
- [**unknown**] KAM_KNGMHM02-23336_NonProdSolMan [#866](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/866)
- [**RD 07.21**] KNGMHM02-23611: Restricted dialog for project details and SPD [#872](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/872)
- [**RD 05.21**] Update dev with hotfix from RD05.21 [#875](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/875)
- [**unknown**] Admin: Added codeowners [#870](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/870)
- [**RD 07.21**] PET_KNGMHM02-23750 Journey Checks - Description not displayed [#867](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/867)
- [**RD 07.21**] Mus build fixes [#865](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/865)
- [**RD 05.21**] Fix error that it is not possible to save SOs, for other services than JourneyChecks [#864](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/864)
- [**RD 05.21**] Merge RD05 release changes to dev [#862](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/862)
- [**RD 05.21**] PET_KNGMHM02 23581 8006942910 No edit possible for CBX orders and Journey Check fixes. [#863](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/863)
- [**RD 05.21**] Ost kngmhm02 23386 eng case no contracts warning [#861](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/861)
- [**RD 05.21**] PET_KNGMHM02-22400 - Journey Checks field label changes [#860](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/860)
- [**RD 05.21**] Ost kngmhm02 23689 correct label to global eng case [#852](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/852)
- [**RD 05.21**] PET_KNGMHM02-23063 UX changes in questionnaire area [#855](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/855)
- [**RD 05.21**] KAM_KNGMHM02-23639_NoSaveWithoutQualif [#853](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/853)
- [**RD 05.21**] MUS_Issue_851_850 [#854](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/854)
- [**RD 05.21**] Mus navigation issue 826 [#848](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/848)
- [**unknown**] Kam kngmhm02 23678 batch request missing refresh [#845](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/845)
- [**RD 05.21**] OST_KNGMHM02-23635 Fix overlapping texts in home screen project list [#842](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/842)
- [**RD 05.21**] OST_KNGMHM02-21985_EngCase_Contracts [#841](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/841)
- [**RD 07.21**] Integration Tests for tab Service Plan Drafts [#836](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/836)
- [**RD 05.21**] KAM_RefObjectMandatoryCheck [#806](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/806)
- [**RD 05.21**] Kam kngmhm02 18991 variant management [#813](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/813)
- [**RD 05.21**] Update Dev Branch from Release [#802](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/802)
- [**unknown**] Rd 02.21 SPD [#796](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/796)
- [**unknown**] You kngmhm02 23406 integration tests [#830](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/830)
- [**unknown**] Merge updates on dev to integration tests [#829](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/829)
- [**RD 05.21**] MUS-KNGMHM02-23429-Checkmarx [#819](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/819)
- [**RD 05.21**] PET_KNGMHM02-23585 - Extending Favorites feature [#811](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/811)
- [**RD 05.21**] LUT_KNGMHM02-23559_Rename-Tab [#810](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/810)
- [**RD 05.21**] Removed the mandatory qualification check and the star symbol next to… [#808](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/808)
- [**RD 05.21**] LUT_KNGMHM02-23432_One-China-Policy [#807](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/807)
- [**unknown**] OST_KNGMHM02_23368 remove multiselect property from SPD list view and phase view [#787](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/787)
- [**unknown**] Fix scrolling related errors on SPD Phase View [#792](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/792)
- [**unknown**] OST_allow appending to the end of the phase column with DragDrop [#793](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/793)
- [**unknown**] Ost kngmhm02 23408 spd user friendly error when ssc connection problem [#799](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/799)
- [**RD 05.21**] Small manual code adjustment during release to dev merge [#805](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/805)
- [**unknown**] MUS-Bugfix Issue 772: text change, removed unused legend item [#794](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/794)
- [**can be tested**] MUS-Bugfix Issue 684 RD SPD [#761](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/761)
- [**unknown**] LUT_UnitTest-NewEngagement [#804](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/804)
- [**RD 05.21**] LUT_KNGMHM02-23040_Global-engagement-case-detail-screen [#803](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/803)
- [**unknown**] Rd 02.21 spd [#797](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/797)
- [**unknown**] MUS-Bugfix-Issue-772 [#789](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/789)
- [**can be tested**] OST_KNGMHM02-23249 show 6th phase for waterfall projects [#746](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/746)
- [**RD 05.21**][**can be tested**] OST_KNGMHM02-23149 timing issue when loading projects [#744](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/744)
- [**can be tested**] OST_KNGMHM02-22863_no_SCP_in_SO. [#695](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/695)
- [**can be tested**] OST_KNGMHM02-22842_questionnaire_text_field_length_0 [#602](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/602)
- [**can be tested**] OST_KNGMHM02_22710 SO [#596](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/596)
- [**can be tested**] Kam kngmhm02 21187 service component selection [#590](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/590)
- [**can be tested**] PET_KNGMHM02-22024_Field_Description [#572](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/572)
- [**can be tested**] MIL_KNGMHM02_22596-Gantt [#585](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/585)
- [**unknown**] FAN_KNGMHM02-22323_ShowContractandContractItem:display contractID and… [#524](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/524)
- [**can be tested**] OST_KNGMHM02-22342: console error related to SID in RefObjPopup [#519](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/519)
- [**can be tested**] Ost kngmhm02 22207(2) so message handling [#514](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/514)
- [**can be tested**] OST_KNGMHM02-22207 SO message handling [#511](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/511)
- [**can be tested**] OST_KNGMHM02-22207-SO_message_handling: [#509](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/509)
- [**can be tested**] SO details fields empty in Display mode [#357](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/357)
- [**can be tested**] KAM_KNGMHM02-21812_SysSolManMandatory [#349](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/349)
- [**unknown**] KAM_KNGMHM02-20305_System_SolMan_Mandatory [#254](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/254)
- [**unknown**] KAM KNGMHM02 19562: Service hierarchy search [#116](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/116)
- [**can be tested**] Ost kngmhm02 22673 so save button new behaviour [#592](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/592)
- [**can be tested**] OST_KNGMHM02-22504 [#535](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/535)
- [**can be tested**] Ost kngmhm02 21494 cross app navigation to srs and pea [#355](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/355)
- [**unknown**] PAS_KNGMHM02-21817_Layout-changes-home-screen-details-screen (Part 1) [#346](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/346)
- [**can be tested**] PAS_KNGMHM02-21860_Home-filters [#350](https://github.wdf.sap.corp/customerexperience/holisticengagementplanner/pull/350)
