 
# Holistic Engagement Planner
Access this [url](https://fiorilaunchpad.sap.com/sites#holisticengagementplanner-Display) to see the live application and share your feedback with us!

## Introduction

Repository of the Holistic Engagement Planner, most information about this repo is stored [here](https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=2513309842).



    
