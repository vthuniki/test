---
name: "Feature Request"
about: Something works as designed, but another approach is likely better; missing or needed functionality to be added in the future
labels: new feature

---

## Current Implementation
<!-- Describe or point to the current scope that you would like to see improved -->

## Suggested Enhancement | New Feature
<!-- Outline the idea of your enhancement, what should be changed and how -->

## Expected Benefits
<!-- Summarize the benefits of this feature -->