---
name: "Bug Report"
about: Something does not work, behavior differs from user story (e.g. acceptance critera not met)
labels: bug

---

## Technical details, if appicable

Environment (Dev, Test, Prod):
Browser:
User: 
Engagement: 
Project: 
Service Plan:

## Describe the bug

## Steps to reproduce the issue

<!-- include screenshots, logs, code or other info to help explain your problem, whatever is available to you -->

<!--
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error
-->

## Expected behaviour

<!-- A description of what you expected to happen. -->

## Additional context

<!-- Add any other context about the problem here. -->