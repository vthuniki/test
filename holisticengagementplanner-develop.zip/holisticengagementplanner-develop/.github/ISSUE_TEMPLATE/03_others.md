---
name: "Other"
about: A type of issue that neither fits into bug or feature category, possibly discussion topics, questions etc.

---

* [ ] None of the other issue templates apply to this issue.

## Description

