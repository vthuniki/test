void call(Map params) {
    //safely check if PR or not
    def changeId = false
    try {
        changeId = CHANGE_ID
    } catch (MissingPropertyException e) {
        echo 'Source is not a pull request, skipping checkmarx in build stage'
    } catch (Exception e) {
        echo 'Unexpected error during central build extension'
    }
    //access stage name
    echo "Start - Extension for stage: ${params.stageName}"

    //access config
    echo "Current stage config: ${params.config}"
    echo "CHANGE ID PARAM: ${changeId}"
    echo "ENV Param: ${env}"

    //execute original stage as defined in the template
    params.originalStage()
    echo "CHANGE ID PARAM: ${changeId}"
    if (changeId) {
        echo 'Pull request found, executing checkmarx & whitesource'
        checkmarxExecuteScan script: this
        whitesourceExecuteScan script:this
    } else {
        echo 'Source is not a pull request, skipping checkmarx & whitesource in build stage'
    }

    //access overall pipeline script object
    echo "Branch: ${params.script.commonPipelineEnvironment.gitBranch}"
    echo "Pipe environment: ${params.script.commonPipelineEnvironment}"
    echo "End - Extension for stage: ${params.stageName}"
}
return this
//Don't forget the `return this`, which is required at the end of _all_ extension scripts.
