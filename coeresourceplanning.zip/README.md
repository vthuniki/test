# Personal / Team Calendar

These Apps will help you to easily access, review, and maintain your calendar for planning and scheduling purposes so that your Team Lead or responsible staffer can see when you are available to be assigned to services.

More details can be found on our [JAM page](https://jam4.sapjam.com/groups/iDrRymI7rWhoNrog2NpHea/overview_page/aJKvNDSHghNxMj7E7pEHXr).

## Technical Names
**Repository Name:** coeplanningcalendar

**Name in sapitcloudt:** planningcalendar

**FLP Name:** Personal Calendar - CoE Time Schedule, Team Calendar - CoE Team Planning

## Deployments
Deployed Version No: 1.19

Ver 1.19 - Bugfix - Retrieve User Info in the CFLP

Ver 1.18 - Revert to old usage tracking id

Ver 1.17 - Update usage tracking id, add tracking events for creating allocations

Ver 1.12 - Update component to read reuselib
