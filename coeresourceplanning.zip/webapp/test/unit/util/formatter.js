sap.ui.define([
    "sap/coe/rpa/util/formatter",
    "sap/ui/thirdparty/sinon",
    "sap/ui/thirdparty/sinon-qunit"
], function(oFormatter) {
    "use strict";
    var sandbox = sinon.sandbox.create();

    QUnit.module("Utils - Formatter", {
        afterEach: function() {
            sandbox.restore();
        }
    });

    QUnit.test("Should be possible to import an instance", function(assert) {
        assert.ok(oFormatter, "Was possible to import the instance");
    });

    QUnit.test("getDescription: Should return a string with qualification text or the item description", function(assert) {
        var sAType = "ASG",
            iColorCode = 6,
            sQualText = "OSD: SAP Fiori",
            sIDesc = "ONSITE TEAM MEMBER";
        var sDesc = oFormatter.getDescription(sAType, iColorCode, sQualText, sIDesc),
            sExpectedResult = "OSD: SAP Fiori";

        assert.strictEqual(sDesc, sExpectedResult, "The function returned the string 'OSD: SAP Fiori'");
    });

    QUnit.test("getDescription: Should return a string with qualification text or the item description", function(assert) {
        var sAType = "ASG",
            iColorCode = 3,
            sQualText = "OSD: SAP Fiori",
            sIDesc = "DEA MISC 1 WEEKEND IRE";
        var sDesc = oFormatter.getDescription(sAType, iColorCode, sQualText, sIDesc),
            sExpectedResult = "DEA MISC 1 WEEKEND IRE";

        assert.strictEqual(sDesc, sExpectedResult, "The function returned the string 'DEA MISC 1 WEEKEND IRE'");
    });


});
