sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/coe/capacity/reuselib/controls/TimeZoneSelect/TimeZoneSettings"
], function(Controller, TimeZoneSettings) {
    "use strict";

    return Controller.extend("sap.coe.rpa.view.Main", {

	onInit: function() {
		if (sap.ui.Device.support.touch === false) {
			this.getView().addStyleClass("sapUiSizeCompact");
		}
		TimeZoneSettings._setTimeZoneModelToView(this, "sap.coe.capacity.reuselib");
		sap.ui.getCore().getConfiguration().getFormatSettings().setFirstDayOfWeek(1);
	},

	onBeforeRendering: function(){
		TimeZoneSettings._setAppSettingButtons(this);
		TimeZoneSettings._getUserTimeZone(this);
	}

    });

});