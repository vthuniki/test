---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

**Current Situation**
A clear and concise description of what the current situation/usage of the spp is. Ex. I'm always frustrated when [...]
Give a clear and concise description of what you want to happen.

**Business Impact**
How this new feature/functionality (or lack of) will affects users and their work.

**Additional context**
Add any other context or screenshots about the feature request here.
