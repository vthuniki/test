sap.ui.define([
	"sap/support/boost/controller/App.controller",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(App) {
	"use strict";

	QUnit.module("App - request again", {
		beforeEach: function() {
			
		},
		afterEach: function() {
		}
	});
	
	// QUnit.test("onSelectTeam - Should show data of selected team on the chart when user selected a team", function(assert){
	// });

});