sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"dlc/dcd/contractxray/model/models",
	"sap/ui/model/json/JSONModel",
	"sapit/util/UsageTracking"
], function (UIComponent, Device, models, JSONModel, UsageTracking) {
	"use strict";

	return UIComponent.extend("dlc.dcd.contractxray.Component", {

		metadata: {
			manifest: "json",
			config: {
				fullWidth: true
			},
			"includes": ["css/style.css"]
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// Application Usage Tracking
			UsageTracking.startUsageTracking(this);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			//set AppConfigModel
			this.setModel(new JSONModel(models.createAppConfigData()), "appConfigModel");
			//set current user Model 
			this.setModel(models.createUserModel(), "userModel");
		}
	});
});