sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		createUserModel: function () {
			var oModel = new JSONModel("/services/userapi/currentUser");
			return oModel;
		},
		createAppConfigData: function () {
			var root = jQuery.sap.getModulePath("dlc.dcd.contractxray");
			var oAppConfigModel = {
				"revenueType": 0,
				"visibleCanvas": true,
				"editHighlightingButtons": true,
				"fullScreenButton": false,
				"resizeSlider": false,
				"results": [],
				"oldValues": {},
				"oldHighlightData": {},
				"currentPageNo": 0,
				"msgStripVisible": false,
				"pageNo": 0,
				"currPageNo": 0,
				"totalPages": 0,
				"totalResults": 0,
				"fileName": "",
				"documentId": "",
				"newFileName": "",
				"newDocumentId": "",
				"pageBack": false,
				"pageNext": false,
				"AdminAccess": false,
				"visibleColumn": true,
				"visibleTable": false,
				"possibleValueTextbox": "",
				"possibleValueAddButtonEnable": false,
				"protocol": "https://",
				"url": ".wdf.sap.corp/",
				"crmUrlCase": "sap/bc/webdynpro/sap/zv_cms_rcm_wda_case?CASE_ID=",
				"crmUrlCaseMode": "&CASE_MODE=D&sap-wd-configid=ZV_CMS_RCM_WAC_CASE&sap-accessibility=&sap-theme=#",
				"PDFFile": "",
				"ContractxrayImg": root + "/images/CXR_img.PNG",
				"ContractxrayVideo": root + "/images/HPFA_CXR_Video.mp4",
				"disclaimer": null,
				"flag" : true,
				"flpUrlProd": "fiorilaunchpad.sap.com",
				"flpArm": "/sites#arm-Create&/createRequest",
				"SalesOrgList" : [],
				"Profile" : "",
				"BasicRole" : ""
			};
			return oAppConfigModel;
		}

	};
});