sap.ui.define([
	"dlc/dcd/contractxray/test/unit/controller/ContractMaster.controller"
], function () {
	"use strict";
});