/*global QUnit*/

sap.ui.define([
	"dlc/dcd/contractxray/controller/ContractMaster.controller"
], function (Controller) {
	"use strict";

	QUnit.module("ContractMaster Controller");

	QUnit.test("I should test the ContractMaster controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});