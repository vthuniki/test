sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"dlc/dcd/contractxray/js/pdfjs/build/pdf.worker",
	'sap/ui/Device',
	'sap/ui/model/Sorter',
	'sap/ui/core/Fragment',
	'sap/ui/export/library',
	'sap/ui/export/Spreadsheet',
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/library",
	"sap/m/MessageBox",
	"sap/m/Popover",
	"sap/m/MessageToast",
	"sap/ushell/Container"
], function (Controller, JSONModel, PdfWorker, Device, Sorter, Fragment, ExportLibrary, Spreadsheet, DateFormat, coreLibrary, MessageBox,
	Popover, MessageToast, Container) {
	"use strict";

	return Controller.extend("dlc.dcd.contractxray.controller.ContractMaster", {
		onInit: function () {
			this._mViewSettingsDialogs = {};
			this.pdfjsLib = window["pdfjs-dist/build/pdf"];
			this.pdfjsLib.GlobalWorkerOptions.workerSrc = PdfWorker;
			this._getSystemInfo();
			// code changes start for US ITSDEDLC-1205
			this.getAdminAccess();
			// code changes end for US ITSDEDLC-1205
			// to check the basic auth and list of sales orgs assigned to user , so that user can view only assgined ones.
			//ITSDEDLC-560 begin code
			var that = this;
			var oModelAppConfig = that.getOwnerComponent().getModel("appConfigModel");
			var oModel = that.getOwnerComponent().getModel();
			oModel.callFunction("/CheckRole", {
				method: "GET",
				success: function (data, response) {
					var oResourceBundle = that.getOwnerComponent().getModel("i18n").getResourceBundle();
					var status = {};
					var oArray = [];
					var SalesOrgArrayList = [];
					status = data;
					if (status.results) {
						for (var i = 0; i < status.results.length; i++) {
							if (status.results[i].Role === "No") {
								that.getOwnerComponent().getModel("appConfigModel").setProperty("/Role", "No");
								// Code Changes start by C5250760 for US ITSDEDLC-1089
								var sResponsivePaddingClasses =
									"sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer";
								MessageBox.error(
									oResourceBundle.getText("noauthorization"), {
										id: "serviceErrorMessageBox",
										details: "<p>Please visit <a href='https://wiki.one.int.sap/wiki/pages/viewpage.action?pageId=3011050889' target='_top'>DCD Wiki</a> for details and request the required roles.",
										styleClass: sResponsivePaddingClasses,
										actions: [MessageBox.Action.CLOSE],
										onClose: function () {
											this._bMessageOpen = false;
										}.bind(this)
									}
								);
								// code Changes end by C5250760 for US ITSDEDLC-1089
								// MessageBox.error(oResourceBundle.getText("BasicAuthErrorMsg"), {
								// 	icon: MessageBox.Icon.ERROR,
								// 	title: "Error",
								// 	actions: [sap.m.MessageBox.Action.OK],
								// 	onClose: function (oAction) {
								// 		if (oAction === "OK") {
								// 			window.history.go('URL');
								// 		}
								// 	}.bind(this)
								// });
								break;
							} else if (status.results[i].Profile === "0000") {
								that.getOwnerComponent().getModel("appConfigModel").setProperty("/BasicRole", "Yes");
								that.getOwnerComponent().getModel("appConfigModel").setProperty("/Profile", "Global");
								that.AfterBasicRoleSuccess();
								break;
							} else {
								that.getOwnerComponent().getModel("appConfigModel").setProperty("/BasicRole", "Yes");
								oArray = status.results[i].Profile;
								SalesOrgArrayList.push(oArray);
								that.AfterBasicRoleSuccess();
							}

						}
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/SalesOrgList", SalesOrgArrayList);
					}
				}
			});
			oModel.setUseBatch(false);
			//var oRole = this.getOwnerComponent().getModel("appConfigModel").getProperty("/BasicRole");
			/*if (oModelAppConfig.getProperty("/disclaimer") === null) {
				oModel.read("/InformationDNDSet", {
					success: function (oData, response) {
						if (oData.results.length > 0) {
							oModelAppConfig.setProperty("/disclaimer", oData.results[0]);
							oModelAppConfig.setProperty("/flag", false);

							if (oModelAppConfig.getProperty("/disclaimer/Notification") !== "X") {
								that.openDisclaimer();
							} else {
								that.openLoginDialog();
							}
						} else if (oData.results.length === 0) {
							that.openDisclaimer();
							that.openLoginDialog();
						}
					},
					error: function (error) {}
				});
			}*/

		},
		Index_cases: function (oEvent) {
			if (oEvent.getSource().getPressed()) {

				this.byId("thumbnailSplit").setSize("0%");
			} else {

				this.scale = 3;
				this.byId("thumbnailSplit").setSize("50%");

				this.getOwnerComponent().getModel("appConfigModel").setProperty("/fullScreenButton", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/resizeSlider", true);

				var that = this;
				var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDCD_COCKPIT_CV_SRV/", true);
				// var a = this.getView().byId("smartFilterBar").getFilterData().CaseId.items[1].text;

				// var CASE_ID = this.getView().byId("smartFilterBar").getFilterData().CaseId.items;
				var a = this.getView().byId("smartFilterBar").getFilterData().CaseId.items.length;

				var CASE_ID_range = this.getView().byId("smartFilterBar").getFilterData().CaseId.ranges.length;

				if (a !== 0) {

					var CASE_ID = this.getView().byId("smartFilterBar").getFilterData().CaseId.items;
					var link = "/UpdateMLXraySet?$filter=";
					var length = CASE_ID.length;
					var case_all = "CASE_ID eq '" + CASE_ID[0].text + "'";
					var i = 1;
					var cas;
					while (i < length) {
						cas = " or CASE_ID eq '" + CASE_ID[i].text + "'";
						case_all = case_all.concat(cas);
						i++
					}

				} else {
					// alert("test second block ");
					var CASE_ID_range = this.getView().byId("smartFilterBar").getFilterData().CaseId.ranges;
					var link = "/UpdateMLXraySet?$filter=";
					var length = CASE_ID_range.length;
					var case_all = "CASE_ID eq '" + CASE_ID_range[0].value1 + "'";
					var i = 1;
					var cas;
					while (i < length) {
						cas = " or CASE_ID eq '" + CASE_ID_range[i].value1 + "'";
						case_all = case_all.concat(cas);
						i++
					}
				}

				// var link = "/UpdateMLXraySet?$filter=";
				// var length =  CASE_ID.length;
				// var case_all = "CASE_ID eq '" + CASE_ID[0].text + "'";
				// var i = 1;
				// var cas;
				// while (i < length)
				// {
				// 	cas = " or CASE_ID eq '" + CASE_ID[i].text + "'";
				// 	case_all=case_all.concat(cas);
				// 	i++
				// }
				var full_link = link.concat(case_all);

				oModel.read(full_link, null, null, false,
					function (oDataCMS) {
						var t = new sap.ui.model.json.JSONModel(oDataCMS);
						that.getView().setModel(t, "T");

				// if (a !== 0 ) {
				// 	alert("first");
				// 	var CASE_ID = this.getView().byId("smartFilterBar").getFilterData().CaseId.items;
				// 	var link = "/UpdateMLXraySet?$filter=";
				// 	var length = CASE_ID.length;
				// 	var case_all = "CASE_ID eq '" + CASE_ID[0].text + "'";
				// 	var i = 1;
				// 	var cas;
				// 	while (i < length) {
				// 		cas = " or CASE_ID eq '" + CASE_ID[i].text + "'";
				// 		case_all = case_all.concat(cas);
				// 		i++
				// 	}
				// 		var full_link = link.concat(case_all);
						
				// 		if (CASE_ID_range !== 0){
				// 				var CASE_ID_range = this.getView().byId("smartFilterBar").getFilterData().CaseId.ranges;
					
				// 	var length_CASE_ID_range= CASE_ID_range.length;
				// 	var case_all_range = "CASE_ID eq '" + CASE_ID_range[0].value1 + "'";
				// 	var i = 1;
				// 	var cases;
				// 	var test = " or ";
				// 	while (i < length_CASE_ID_range) {
				// 		cases = " or CASE_ID eq '" + CASE_ID_range[i].value1 + "'";
				// 		case_all_range = case_all_range.concat(cases);
				// 		i++
				// 	}
				// 		}
						
				
				// 	var final = test.concat(case_all_range);
				// 	var finals = full_link.concat(final);
				// 		oModel.read(finals, null, null, false,
				// 	function (oDataCMS) {
				// 		var t = new sap.ui.model.json.JSONModel(oDataCMS);
				// 		that.getView().setModel(t, "T");
					});
			}

		},

		AfterBasicRoleSuccess: function () {
			var that = this;
			var oModelAppConfig = that.getOwnerComponent().getModel("appConfigModel");
			var oModel = that.getOwnerComponent().getModel();
			if (oModelAppConfig.getProperty("/disclaimer") === null && that.getOwnerComponent().getModel("appConfigModel").getProperty(
					"/BasicRole") === "Yes") {
				oModel.read("/InformationDNDSet", {
					success: function (oData, response) {
						if (oData.results.length > 0) {
							oModelAppConfig.setProperty("/disclaimer", oData.results[0]);
							oModelAppConfig.setProperty("/flag", false);

							if (oModelAppConfig.getProperty("/disclaimer/Notification") !== "X") {
								that.openDisclaimer();
							} else {
								that.openLoginDialog();
							}
						} else if (oData.results.length === 0) {
							that.openDisclaimer();
							that.openLoginDialog();
						}
					},
					error: function (error) {}
				});
			}

		},
		onBeforeRendering: function () {

		},

		//code changes start for US ITSDEDLC-1094
		onInitialized: function () {
			var end = new Date();
			end.setDate(end.getDate() - 365);
			this.getView().byId("signDatePicker").setValue(sap.ui.core.format.DateFormat.getInstance({
				pattern: "yyyy-MM-dd",
				calendarType: sap.ui.core.CalendarType.Gregorian
			}).format(end));
			this.getView().byId("endDatePicker").setValue(sap.ui.core.format.DateFormat.getInstance({
				pattern: "yyyy-MM-dd",
				calendarType: sap.ui.core.CalendarType.Gregorian
			}).format(new Date()));
			var smartFilterBar = this.getView().byId("smartFilterBar");
			if (smartFilterBar) {
				smartFilterBar.setFilterData({
					_CUSTOM: {
						signDatePicker: this.getView().byId("signDatePicker").getDateValue(),
						endDatePicker: this.getView().byId("endDatePicker").getDateValue()
					}
				});
			}

		},
		handleChange: function (oEvent) {
			var smartFilterBar = this.getView().byId("smartFilterBar");
			if (smartFilterBar) {
				var oCtrl = oEvent.getSource();

				if (oCtrl) {
					if (oCtrl.getId().includes("signDatePicker")) {
						smartFilterBar.setFilterData({
							_CUSTOM: {
								signDatePicker: oCtrl.getDateValue(),
								endDatePicker: this.getView().byId("endDatePicker").getDateValue()
							}
						});
					} else if (oCtrl.getId().includes("endDatePicker")) {
						smartFilterBar.setFilterData({
							_CUSTOM: {
								signDatePicker: this.getView().byId("signDatePicker").getDateValue(),
								endDatePicker: oCtrl.getDateValue()
							}
						});

					}
				}
			}
		},
		// Code changes end for US ITSDEDLC-1094
		onAfterRendering: function () {
			//code comment start for US ITSDEDLC-1094
			// var CalendarType = coreLibrary.CalendarType,
			// 	oFormatYyyymmdd = DateFormat.getInstance({
			// 		pattern: "yyyy-MM-dd",
			// 		calendarType: CalendarType.Gregorian
			// 	});
			// var todayDate = oFormatYyyymmdd.format(new Date());
			// var lowDate = new Date();
			// lowDate.setDate(lowDate.getDate() - 365);
			// this.getView().byId("dateRangeDefaultValue").setHigh(todayDate);
			// this.getView().byId("dateRangeDefaultValue").setLow(oFormatYyyymmdd.format(lowDate));

			// Code comments end for US ITSDEDLC-1094
		},
		//Open Login Dialog pop-up
		openLoginDialog: function () {
			var that = this;
			var oModel = that.getOwnerComponent().getModel();
			oModel.callFunction("/CXRLoginHandler", {
				method: "GET",
				success: function (oData, resposne) {
					if (oData.CXRLoginHandler.Enabled == true) {
						that.openLoginScreen();
						that.getOwnerComponent().getModel().refresh();
					}
				},
				error: function (oError) {
					MessageToast.show(oError);
				}

			});
		},
		//Open disclaimerInfo pop-up
		openDisclaimer: function () {
			if (!this.oInfoDialog) {
				this.oInfoDialog = sap.ui.xmlfragment(this.getView().getId(), "dlc.dcd.contractxray.fragment.information", this);
				this.getView().addDependent(this.oInfoDialog);
			}
			this.oInfoDialog.open();

		},
		openLoginScreen: function () {
			//open login screen popup
			if (!this.oLoginDialog) {
				this.oLoginDialog = sap.ui.xmlfragment(this.getView().getId(), "dlc.dcd.contractxray.fragment.Login", this);
				this.getView().addDependent(this.oLoginDialog);
			}
			this.oLoginDialog.open();
			var userId = this.getOwnerComponent().getModel("userModel").getData().name;
			var userPrefix = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			this.getView().byId("uName").setValue(userPrefix.getText("usernamePrefix") + userId);
		},
		onLoginSubmit: function () {
			var that = this;
			var ouserName = this.getView().byId("uName").getValue();
			var opwd = this.getView().byId("pwd");
			var opassword = this.getView().byId("pwd").getValue();
			var oVText = this.getView().byId("validationText");
			var odisplayName = this.getOwnerComponent().getModel("userModel").getData().displayName;
			var oresourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			if (opassword === "" || opassword === null) {
				oVText.setText(oresourceBundle.getText("passwordText"));
				oVText.setVisible(true);
			} else {
				var oModel = that.getOwnerComponent().getModel();
				oModel.callFunction("/CXRLoginValidator", {
					method: "GET",
					urlParameters: {
						username: ouserName,
						password: opassword
					},
					success: function (oData, resposne) {
						if (oData.CXRLoginValidator.login == true) {
							MessageToast.show(odisplayName + "Logged in Successfully", {
								duration: 5000,
								width: "25em"
							});
							that.oLoginDialog.close();
						} else {
							oVText.setText(oresourceBundle.getText("passwordText"));
							oVText.setVisible(true);
							opwd.setValue();
						}
						that.getOwnerComponent().getModel().refresh();
					},
					error: function (oError) {
						MessageToast.show(oError);
					}

				});
			}

		},
		//on close of disclaimerInfo and InfoDialog
		onInfoCancel: function (oEvent) {
			var Infoflag = this.getOwnerComponent().getModel("appConfigModel").getProperty("/flag");
			if (Infoflag === false) {} else if (this.getView().byId("dndCheckBox").getSelected()) {
				var that = this;
				var oModel = that.getOwnerComponent().getModel();
				var oObject = {};
				oObject.Notification = "X";
				oObject.Userid = this.getOwnerComponent().getModel("userModel").getData().name;
				oModel.setUseBatch(false);
				oModel.update("/InformationDNDSet('" + oObject.Userid + "')", oObject, {
					success: function (oData, response) {
						sap.m.MessageToast.show("Response Acknowledged!, Disclaimer will not be shown until further updates.", {
							duration: 5000,
							width: "25em"
						});
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/flag", false);
						that.getView().byId("dndCheckBox").setVisible(false);
					},
					error: function (error) {}
				});
			} else {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/flag", false);
			}
			this.oInfoDialog.close();
		},
		// code changes for us ITSDEDLC-1093 to open deedback URL
		onFeedbackPress: function () {
			var fUrl =
				"https://sap-it-cloud-sapitcf-feedback-feedback-approuter.cfapps.eu10.hana.ondemand.com/cp.portal/site?sap-ushell-config=standalone#feedback-Display&/topic/ef9fd39e-6902-4b88-a43f-e70bd01245c0";
			sap.m.URLHelper.redirect(fUrl, true);
			// window.open("{i18n>anyfeedback}","_blank");
		},
		// code changes end for US ITSDEDLC-1093
		//information pop up
		onInfoPress: function (evt) {
			if (!this.oInfoDialog) {
				this.oInfoDialog = sap.ui.xmlfragment("dlc.dcd.contractxray.fragment.information", this);
				this.getView().addDependent(this.oInfoDialog);
			}
			this.oInfoDialog.open();
		},
		//Open Contract Xray video
		onPressOverviewImg: function () {
			sap.m.URLHelper.redirect(this.getOwnerComponent().getModel("appConfigModel").getProperty("/ContractxrayVideo"), true);
		},
		//Get Authorization for Contractxray
		getAuthorization: function () {
			var appConfigModel = this.getOwnerComponent().getModel("appConfigModel");
			var sHTTPS = appConfigModel.getProperty("/protocol");
			var flpUrl = appConfigModel.getProperty("/flpUrlProd");
			var flpArm = appConfigModel.getProperty("/flpArm");
			var sUrl = sHTTPS + flpUrl + flpArm;
			sap.m.URLHelper.redirect(sUrl, true);
		},
		onFilterSearch: function (oEvent) {
			var that = this;
			// this.getView().byId("rightContainer").setBusy(true);
			var oBusyDialog = new sap.m.BusyDialog();
			oBusyDialog.open();
			var CalendarType = coreLibrary.CalendarType,
				oFormatYyyymmdd = DateFormat.getInstance({
					pattern: "yyyy-MM-dd",
					calendarType: CalendarType.Gregorian
				});
			this.onPressFullScreenTable();
			var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			// var sSearchValue = oEvent.getSource().getBasicSearchControl().getValue();
			var sSearchValue = this.getView().byId("searchField").getValue();
			for (var a in oEvent.getSource().getFilterData()) {
				if (a === "CaseId") {
					var caseID = oEvent.getSource().getFilterData().CaseId.items;
				}
				if (a === "CustNo") {
					var accountID = oEvent.getSource().getFilterData().CustNo.items;
				}
			}
			if (sSearchValue === "" && caseID == undefined && accountID == undefined) {
				MessageBox.error(
					"Searching with an empty text field is restricted due to memory limitation. To proceed, fill in either the Case ID or Account filter before trying again."
				)
				this.getView().byId("MasterTable").setVisible(false);
				oBusyDialog.close();
			} else {
				var appConfigmodel = this.getOwnerComponent().getModel("appConfigModel");
				var sSystemID = appConfigmodel.getProperty("/SystemsInfo/Sysid");
				var sIndexName;

				if (sSystemID === 'ISD') {
					sIndexName = "ist-demo-index";

				} else if (sSystemID === 'IST') {
					sIndexName = "ist-demo-index";
				} else {
					//sIndexName = "isp-demo-index";
					sIndexName = "isp-prod-index"; //ITSDEDLC-557
				}

				// var sFrom = (oEvent.getSource().getControlByKey("CustomFilterField").getSelectedKey() === "") ? 0 : oEvent.getSource().getControlByKey(
				// 	"CustomFilterField").getSelectedKey();
				// var sSize = (oEvent.getSource().getControlByKey("CustomFilterField1").getSelectedKey() === "") ? 10000 : oEvent.getSource().getControlByKey(
				// 	"CustomFilterField1").getSelectedKey();

				var oResultsBatch = oEvent.getSource().getControlByKey("CustomFilterField")._getSelectedItemText();
				var oResultBatchKey = oEvent.getSource().getControlByKey("CustomFilterField").getSelectedKey();

				// var oHeadlines = oEvent.getSource().getControlByKey("CustomFilterField2").getSelectedKey()
				var oController = this;
				var aFilters = [],
					should = [],
					term = {},
					wildcard = {},
					c = "*",
					b = "*",
					range = {};
				var oLabels = {
					"Country": "case_country",
					"LobId": "case_revenue_type",
					"Language": "case_language",
					"SalesOrg": "case_sales_organisation",
					"CaseId": "case_id",
					"BpId": "case_account_id",
					"CustNo": "case_consumer_id",
					"DocAttribute": "case_document_classification" //ITSDEDLC-511
				};

				for (var a in oEvent.getSource().getFilterData()) {

					// if (a === "signDate") {
					// 	// Code Changes start for US ITSDEDLC-1094
					if (a === '_CUSTOM') {
						range["case_signature_date"] = {
							"gte": oFormatYyyymmdd.format(new Date(oEvent.getSource().getFilterData()['_CUSTOM'].signDatePicker)),
							"lte": oFormatYyyymmdd.format(new Date(oEvent.getSource().getFilterData()['_CUSTOM'].endDatePicker))
						};
						aFilters.push({
							"range": range
						});
						// 	// Code Changes end for US ITSDEDLC-1094
					} else {
						//ITSDEDLC-827 New filter format has been defined
						var aData;
						if (a != "Headlines") {
							if (oEvent.getSource().getFilterData()[a].ranges.length > 0 && oEvent.getSource().getFilterData()[a].items.length == 0) {
								oEvent.getSource().getFilterData()[a].ranges.forEach(function (i) {
									if (!isNaN(parseInt(i.key, 10))) {
										if (a === "LobId") {
											aData = {
												'case_revenue_type.keyword': i.value1.toUpperCase()
											};
										}

										//ITSDEDLC-956
										//ITLT-1039 re structuring the code as from backend all the values are made camel case
										// if (a === "Act_doc") {
										// 	if (i.value1 === "GTC") {
										// 		aData = {
										// 			'case_document_classification.keyword': i.key
										// 		};
										// 	} else if (i.value1 === "PURCH_ORD") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*PurchaseOrder*'
										// 		};
										// 	} else if (i.value1 === "SLA") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*ServiceLevelAggrement*'
										// 		};
										// 	} else if (i.value1 === "SUPPORTPOLC") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*SupportPolicy*'
										// 		};
										// 	} else if (i.value1 === "ADDENDUM") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*Amendment*'
										// 		};
										// 	} else if (i.value1 === "DEALAPPROVAL") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*DealApproval*'
										// 		};
										// 	}  else if (i.key === "DOCUSIGN") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*DocuSign*'
										// 		};
										// 	}  else if (i.value1 === "CHANGEREQ") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*ChangeRequest*'
										// 		};
										// 	} else {
										// 		aData = {
										// 			'case_document_classification.keyword': i.key.charAt(0).toUpperCase() + i.key.slice(1).toLowerCase()
										// 		};
										// 	}
										// }
											if (a === "Act_doc") {
											if (i.key === "GTC") {
												aData = {
													// 'case_document_classification.keyword': i.key
													'case_document_classification.keyword': '*GTC*'
												};
											} else if (i.key === "Purchase Order") {
												aData = {
													'case_document_classification.keyword': '*PurchaseOrder*'
												};
											} else if (i.key === "SLA") {
												aData = {
													'case_document_classification.keyword': '*ServiceLevelAggrement*'
												};
											} else if (i.key === "Support Policy") {
												aData = {
													'case_document_classification.keyword': '*SupportPolicy*'
												};
											}  else if (i.key === "Cover Letter") {
												aData = {
													'case_document_classification.keyword': '*CoverLetter*'
												};
											}  else if (i.key === "DPA") {
												aData = {
													'case_document_classification.keyword': '*Dpa*'
												};
											}  else if (i.key === "Amendment") {
												aData = {
													'case_document_classification.keyword': '*Amendment*'
												};
											} else if (i.key === "Deal Approval") {
												aData = {
													'case_document_classification.keyword': '*DealApproval*'
												};
											} else if (i.key === "DOCUSIGN") {
												aData = {
													'case_document_classification.keyword': '*DocuSign*'
												};
											} else if (i.key === "Order Form") {
												aData = {
													'case_document_classification.keyword': '*Orderform*'
												};
											} else if (i.key === "Addendum") {
												aData = {
													'case_document_classification.keyword': '*Addendum*'
												};
											} else if (i.key === "Appendix") {
												aData = {
													'case_document_classification.keyword': '*Appendix*'
												};
											} else if (i.key === "Change Request") {
												aData = {
													'case_document_classification.keyword': '*ChangeRequest*'
												};
											} else {
												aData = {
													// 'case_document_classification.keyword': c + i.key.charAt(0).toUpperCase() + i.key.slice(1).toLowerCase() + b
														'case_document_classification.keyword': c + i.key + b
												};
											}
										}
									
										//ITSDEDLC-805 Healines Filter - Begin 
										if (a === "Headlines") {
											if (i.value1 === "Headlines only") {
												aData = {
													'paragraph_type.keyword': 'section_header'
												};
											} else if (i.value1 === "Body only") {
												aData = {
													'paragraph_type.keyword': 'clause_body'
												};
											}
										}
										//ITSDEDLC-805 - End
										should.push({
											// 'term': aData
											'wildcard': aData
										});
									} else {
										if (a === "SalesOrg") {
											aData = {
												'case_sales_organisation.keyword': i.value1
											};
										}
										if (a === "CaseId") {
											if (i.value1.length < 12) {
												aData = {
													'case_id.keyword': i.value1.toString().padStart(12, '0')
												};
											} else {
												aData = {
													'case_id.keyword': i.value1
												};
											}
										}

										if (a === "CustNo") {
											aData = {
												'case_consumer_id.keyword': i.value1
											};
										}
										if (a === "Language") {
											aData = {
												'case_language.keyword': i.value1
											};
										}
										if (a === "Country") {
											aData = {
												'case_country.keyword': i.value1
											};
										}
										should.push({
											// 'term': aData 
											'wildcard': aData

										});
									}
								});
							} else {
								oEvent.getSource().getFilterData()[a].items.forEach(function (i) {
									if (isNaN(parseInt(i.key, 10))) {
										if (a === "LobId") {
											aData = {
												'case_revenue_type.keyword': i.key.toUpperCase()
											};
										}
//ITLT-1039
										// if (a === "Act_doc") {
										// 	if (i.key === "GTC") {
										// 		aData = {
										// 			// 'case_document_classification.keyword': i.key
										// 			'case_document_classification.keyword': '*GTC*'
										// 		};
										// 	} else if (i.key === "PURCH_ORD") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*PurchaseOrder*'
										// 		};
										// 	} else if (i.key === "SLA") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*ServiceLevelAggrement*'
										// 		};
										// 	} else if (i.key === "SUPPORTPOLC") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*SupportPolicy*'
										// 		};
										// 	} else if (i.key === "ADDENDUM") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*Amendment*'
										// 		};
										// 	} else if (i.key === "DEALAPPROVAL") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*DealApproval*'
										// 		};
										// 	}  else if (i.key === "DOCUSIGN") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*DocuSign*'
										// 		};
										// 	}  else if (i.key === "CHANGEREQ") {
										// 		aData = {
										// 			'case_document_classification.keyword': '*ChangeRequest*'
										// 		};
										// 	} else {
										// 		aData = {
										// 			'case_document_classification.keyword': c + i.key.charAt(0).toUpperCase() + i.key.slice(1).toLowerCase() + b
										// 		};
										// 	}
										// }
											if (a === "Act_doc") {
											if (i.key === "GTC") {
												aData = {
													// 'case_document_classification.keyword': i.key
													'case_document_classification.keyword': '*GTC*'
												};
											} else if (i.key === "Purchase Order") {
												aData = {
													'case_document_classification.keyword': '*PurchaseOrder*'
												};
											} else if (i.key === "SLA") {
												aData = {
													'case_document_classification.keyword': '*ServiceLevelAggrement*'
												};
											} else if (i.key === "Support Policy") {
												aData = {
													'case_document_classification.keyword': '*SupportPolicy*'
												};
											}  else if (i.key === "Cover Letter") {
												aData = {
													'case_document_classification.keyword': '*CoverLetter*'
												};
											}  else if (i.key === "DPA") {
												aData = {
													'case_document_classification.keyword': '*Dpa*'
												};
											}  else if (i.key === "Amendment") {
												aData = {
													'case_document_classification.keyword': '*Amendment*'
												};
											} else if (i.key === "Deal Approval") {
												aData = {
													'case_document_classification.keyword': '*DealApproval*'
												};
											} else if (i.key === "DOCUSIGN") {
												aData = {
													'case_document_classification.keyword': '*DocuSign*'
												};
											} else if (i.key === "Order Form") {
												aData = {
													'case_document_classification.keyword': '*Orderform*'
												};
											} else if (i.key === "Addendum") {
												aData = {
													'case_document_classification.keyword': '*Addendum*'
												};
											} else if (i.key === "Appendix") {
												aData = {
													'case_document_classification.keyword': '*Appendix*'
												};
											} else if (i.key === "Change Request") {
												aData = {
													'case_document_classification.keyword': '*ChangeRequest*'
												};
											} else {
												aData = {
													// 'case_document_classification.keyword': c + i.key.charAt(0).toUpperCase() + i.key.slice(1).toLowerCase() + b
														'case_document_classification.keyword': c + i.key + b
												};
											}
										}
									
										if (a === "Language") {
											aData = {
												'case_language.keyword': i.key
											};
										}
										if (a === "Country") {
											aData = {
												'case_country.keyword': i.key
											};
										}

										should.push({
											// 'term': aData wildcard
											'wildcard': aData
										});

									} else {
										if (a === "CaseId") {
											if (i.key.length < 12) {
												aData = {
													'case_id.keyword': i.key.toString().padStart(12, '0')
												};
											} else {
												aData = {
													'case_id.keyword': i.key
												};
											}
										}
										if (a === "LobId") {
											aData = {
												'case_revenue_type.keyword': i.key.toUpperCase()
											};
										}
										if (a === "SalesOrg") {
											aData = {
												'case_sales_organisation.keyword': i.key
											};
										}
										if (a === "CustNo") {
											aData = {
												'case_consumer_id.keyword': i.key
											};
										}
										should.push({
											// 'term': aData
											'wildcard': aData
										});
									}
								});
							}
						} else {
							oEvent.getSource().getFilterData()[a].items.forEach(function (i) {
								if (isNaN(parseInt(i.key, 10))) {
									//ITSDEDLC-805 Healines Filter - Begin 
									if (a === "Headlines") {
										if (i.key === "Headlines only") {
											aData = {
												'paragraph_type.keyword': 'section_header'
											};
										} else if (i.key === "Body only") {
											aData = {
												'paragraph_type.keyword': 'clause_body'
											};
										}
									}
									//ITSDEDLC-805 - End
									should.push({
										// 'term': aData
										'wildcard': aData
									});
								}
							});
						}
						// } else {
						// 	var aData = [];
						// 	oEvent.getSource().getFilterData()[a].items.forEach(function (i) {
						// 		if (isNaN(parseInt(i.key, 10))) {
						// 			aData.push(i.key.toLowerCase());
						// 		} else {
						// 			aData.push(i.key);
						// 		}
						// 	});
						// 	oEvent.getSource().getFilterData()[a].ranges.forEach(function (i) {
						// 		if (isNaN(parseInt(i.value1, 10))) {
						// 			aData.push(i.value1.toLowerCase());
						// 		} else {
						// 			aData.push(i.value1);
						// 		}
						// 	});
						// 	if (a === "CaseId") {
						// 		var prefixSubstitute = "000000000000";
						// 		for (var i = 0; i < aData.length; i++) {
						// 			aData[i] = prefixSubstitute.substr(aData[i].length) + aData[i];
						// 		}
						// 	}
						// term["should"] = should;
						// term["minimum_should_match"] = 1;
						// aFilters.push({
						// 	"bool": term,

						// });
						// term = {};
						// should = [];
						wildcard["should"] = should;
						wildcard["minimum_should_match"] = 1;
						aFilters.push({
							"bool": wildcard,

						});
						wildcard = {};
						should = [];
					}
				}
				this.getView().byId("togglebutton1").setVisible(true);
				//get filters value
				// AJAX call to ML Service

				$.ajax({
					"url": "/ml_api/search",
					"async": true,
					"method": "POST",
					"headers": {
						"Content-Type": "application/json"
					},
					"data": JSON.stringify({
						"index_name": sIndexName,
						"arr_index_from": 0,
						"num_results": 10000,
						"query_text": sSearchValue,
						"filters": aFilters,
						"fields": [
							"orig_paragraph",
							"doc_name",
							"bbox_coords",
							"page_number",
							"case_id",
							"case_signature_date",
							"case_country",
							"case_language",
							"case_sales_organisation",
							"case_sales_organisation_description",
							"case_consumer_id",
							"case_contract_scenario",
							"case_contract_scenario_description",
							"case_contract_type",
							"case_contract_type_description",
							"case_document_id",
							"case_account_id",
							//ITSDEDLC-511
							"case_revenue_type",
							"case_revenue_type_description",
							"case_document_classification",
							"case_account_name",
							"paragraph_type" //ITSDEDLC-805 
						],
						"_source": false
					}),
					success: function (oData) {
						//ITSDEDLC-560 begin code
						var mModel = new JSONModel(oData);
						var localdata = [];
						var saleslist = [];
						var oProfile = "";
						saleslist = that.getOwnerComponent().getModel("appConfigModel").getProperty("/SalesOrgList");
						oProfile = that.getOwnerComponent().getModel("appConfigModel").getProperty("/Profile");
						var oNodeModel = new sap.ui.model.json.JSONModel();
						oController.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleTable", true);
						if (oProfile == !"Global") {
							for (var i = 0; i < mModel.oData.payload.length; i++) {
								if (saleslist.includes(oData.payload[i].case_sales_organisation)) {
									localdata.push(mModel.oData.payload[i]);
								}
							}
							oNodeModel.setData(localdata);
							//ITSDEDLC-808 New function is impletmented for Result Bach Filter
							oController.getOwnerComponent().getModel("appConfigModel").setProperty("/oResultModel", oNodeModel);
							that.checkResultsBatch(oNodeModel);
							//oController.getView().setModel(oNodeModel, "dataModel");

						} else {

							for (var j = 0; j < mModel.oData.payload.length; j++) {
								localdata.push(mModel.oData.payload[j]);
							}
							oNodeModel.setData(localdata);
							//ITSDEDLC-808 New function is impletmented for Result Bach Filter
							oController.getOwnerComponent().getModel("appConfigModel").setProperty("/oResultModel", oNodeModel);
							that.checkResultsBatch(oNodeModel);
							//oController.getView().setModel(oNodeModel, "dataModel");
							// oController.getView().setModel(mModel, "dataModel");
						}
						// oController.getView().byId("rightContainer").setBusy(false);
						oBusyDialog.close();
					},
					error: function (oError) {
						MessageBox.error(oResourceBundle.getText("searchAPIError"));
						// oController.getView().byId("rightContainer").setBusy(false);
						oBusyDialog.close();
					}
				});
				// code change start for ITSDEDLC-1115
				this.getView().byId("MasterTable").getInfoToolbar().setVisible(false);
				this.getView().byId("caseIdAsc").setProperty("type", "Transparent");
				this.getView().byId("caseIdDsc").setProperty("type", "Transparent");
				this.getView().byId("caseAccAsc").setProperty("type", "Transparent");
				this.getView().byId("caseAccDsc").setProperty("type", "Transparent");
				this.getView().byId("summaryAsc").setProperty("type", "Transparent");
				this.getView().byId("summaryDsc").setProperty("type", "Transparent");
				this.getView().byId("salesOrgAsc").setProperty("type", "Transparent");
				this.getView().byId("salesOrgDsc").setProperty("type", "Transparent");
				this.getView().byId("scoreAsc").setProperty("type", "Transparent");
				this.getView().byId("scoreDsc").setProperty("type", "Transparent");
				// code change end for ITSDEDLC-1115
			}
		},
		onClearfiltersort: function () {
			// code change start for ITSDEDLC-1115
			var oTable = this.byId("MasterTable"),
				oBinding = oTable.getBinding("items");
			var oItems = oTable.getBinding("items");
			this.getView().byId("MasterTable").getInfoToolbar().setVisible(false);
			this.getView().byId("caseIdAsc").setProperty("type", "Transparent");
			this.getView().byId("caseIdDsc").setProperty("type", "Transparent");
			this.getView().byId("caseAccAsc").setProperty("type", "Transparent");
			this.getView().byId("caseAccDsc").setProperty("type", "Transparent");
			this.getView().byId("summaryAsc").setProperty("type", "Transparent");
			this.getView().byId("summaryDsc").setProperty("type", "Transparent");
			this.getView().byId("salesOrgAsc").setProperty("type", "Transparent");
			this.getView().byId("salesOrgDsc").setProperty("type", "Transparent");
			this.getView().byId("scoreAsc").setProperty("type", "Transparent");
			this.getView().byId("scoreDsc").setProperty("type", "Transparent");

			oBinding.sort(null);
			var ofilterData = oItems.filter(null);
			var oresultLength = ofilterData.getCount();
			var oResultsValue = "0-999" + " out of " + oresultLength;
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			// code change end for ITSDEDLC-1115
		},
		//ITSDEDLC-808 New function is impletmented for Result Batch Filter
		checkResultsBatch: function (data) {
			var oResultData;
			var oResultModel;
			var oExactMatch = [];
			var oResultValue;
			var oExactValue = this.getView().byId("exactMatchesId").getSelectedKey();
			if (data.getData().slice(0, 999).length > 0 && data.getData().slice(1000, 1999).length > 0 && data.getData().slice(2000, 2999).length >
				0 && data.getData().slice(3000, 3999).length > 0 && data.getData().slice(4000, 4999).length > 0 && data.getData().slice(5000,
					5999)
				.length > 0 && data.getData().slice(6000, 6999).length > 0 && data.getData().slice(7000, 7999).length > 0 && data.getData().slice(
					8000, 8999).length > 0 && data.getData().slice(9000, 9999).length > 0) {

				if (oExactValue == "A") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score === 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else if (oExactValue == "B") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score !== 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else {
					oExactMatch = data.getData();
				}

				oResultData = oExactMatch.slice(0, 999);
				oResultModel = new sap.ui.model.json.JSONModel();
				oResultModel.setData(oResultData);
				this.getView().setModel(oResultModel, "dataModel");
				oResultValue = '0-999' + " out of " + oExactMatch.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultValue);
				this.checkVisibility(oExactMatch);

			} else if (data.getData().slice(0, 999).length > 0 && data.getData().slice(1000, 1999).length > 0 && data.getData().slice(2000,
					2999).length > 0 && data.getData().slice(3000, 3999).length > 0 && data.getData().slice(4000, 4999).length > 0 && data.getData()
				.slice(
					5000, 5999).length > 0 && data.getData().slice(6000, 6999).length > 0 && data.getData().slice(7000, 7999).length > 0 && data.getData()
				.slice(8000, 8999).length > 0) {

				if (oExactValue == "A") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score === 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else if (oExactValue == "B") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score !== 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else {
					oExactMatch = data.getData();
				}
				oResultData = oExactMatch.slice(0, 999);
				oResultModel = new sap.ui.model.json.JSONModel();
				oResultModel.setData(oResultData);
				this.getView().setModel(oResultModel, "dataModel");
				oResultValue = '0-999' + " out of " + oExactMatch.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultValue);
				this.checkVisibility(oExactMatch);

			} else if (data.getData().slice(0, 999).length > 0 && data.getData().slice(1000, 1999).length > 0 && data.getData().slice(2000,
					2999).length > 0 && data.getData().slice(3000, 3999).length > 0 && data.getData().slice(4000, 4999).length > 0 && data.getData()
				.slice(
					5000, 5999).length > 0 && data.getData().slice(6000, 6999).length > 0 && data.getData().slice(7000, 7999).length > 0) {

				if (oExactValue == "A") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score === 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else if (oExactValue == "B") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score !== 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else {
					oExactMatch = data.getData();
				}

				oResultData = oExactMatch.slice(0, 999);
				oResultModel = new sap.ui.model.json.JSONModel();
				oResultModel.setData(oResultData);
				this.getView().setModel(oResultModel, "dataModel");
				oResultValue = '0-999' + " out of " + oExactMatch.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultValue);
				this.checkVisibility(oExactMatch);

			} else if (data.getData().slice(0, 999).length > 0 && data.getData().slice(1000, 1999).length > 0 && data.getData().slice(2000,
					2999).length > 0 && data.getData().slice(3000, 3999).length > 0 && data.getData().slice(4000, 4999).length > 0 && data.getData()
				.slice(
					5000, 5999).length > 0 && data.getData().slice(6000, 6999).length > 0) {

				if (oExactValue == "A") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score === 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else if (oExactValue == "B") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score !== 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else {
					oExactMatch = data.getData();
				}

				oResultData = oExactMatch.slice(0, 999);
				oResultModel = new sap.ui.model.json.JSONModel();
				oResultModel.setData(oResultData);
				this.getView().setModel(oResultModel, "dataModel");
				oResultValue = '0-999' + " out of " + oExactMatch.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultValue);
				this.checkVisibility(oExactMatch);

			} else if (data.getData().slice(0, 999).length > 0 && data.getData().slice(1000, 1999).length > 0 && data.getData().slice(2000,
					2999).length > 0 && data.getData().slice(3000, 3999).length > 0 && data.getData().slice(4000, 4999).length > 0 && data.getData()
				.slice(
					5000, 5999).length > 0) {
				if (oExactValue == "A") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score === 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else if (oExactValue == "B") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score !== 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else {
					oExactMatch = data.getData();
				}

				oResultData = oExactMatch.slice(0, 999);
				oResultModel = new sap.ui.model.json.JSONModel();
				oResultModel.setData(oResultData);
				this.getView().setModel(oResultModel, "dataModel");
				oResultValue = '0-999' + " out of " + oExactMatch.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultValue);
				this.checkVisibility(oExactMatch);

			} else if (data.getData().slice(0, 999).length > 0 && data.getData().slice(1000, 1999).length > 0 && data.getData().slice(2000,
					2999).length > 0 && data.getData().slice(3000, 3999).length > 0 && data.getData().slice(4000, 4999).length > 0) {

				if (oExactValue == "A") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score === 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else if (oExactValue == "B") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score !== 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else {
					oExactMatch = data.getData();
				}

				oResultData = oExactMatch.slice(0, 999);
				oResultModel = new sap.ui.model.json.JSONModel();
				oResultModel.setData(oResultData);
				this.getView().setModel(oResultModel, "dataModel");
				oResultValue = '0-999' + " out of " + oExactMatch.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultValue);
				this.checkVisibility(oExactMatch);

			} else if (data.getData().slice(0, 999).length > 0 && data.getData().slice(1000, 1999).length > 0 && data.getData().slice(2000,
					2999).length > 0 && data.getData().slice(3000, 3999).length > 0) {

				if (oExactValue == "A") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score === 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else if (oExactValue == "B") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score !== 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else {
					oExactMatch = data.getData();
				}
				oResultData = oExactMatch.slice(0, 999);
				oResultModel = new sap.ui.model.json.JSONModel();
				oResultModel.setData(oResultData);
				this.getView().setModel(oResultModel, "dataModel");
				oResultValue = '0-999' + " out of " + oExactMatch.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultValue);
				this.checkVisibility(oExactMatch);

			} else if (data.getData().slice(0, 999).length > 0 && data.getData().slice(1000, 1999).length > 0 && data.getData().slice(2000,
					2999).length > 0) {

				if (oExactValue == "A") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score === 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else if (oExactValue == "B") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score !== 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else {
					oExactMatch = data.getData();
				}

				oResultData = oExactMatch.slice(0, 999);
				oResultModel = new sap.ui.model.json.JSONModel();
				oResultModel.setData(oResultData);
				this.getView().setModel(oResultModel, "dataModel");
				oResultValue = '0-999' + " out of " + oExactMatch.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultValue);
				this.checkVisibility(oExactMatch);

			} else if (data.getData().slice(0, 999).length > 0 && data.getData().slice(1000, 1999).length > 0) {

				if (oExactValue == "A") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score === 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else if (oExactValue == "B") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score !== 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else {
					oExactMatch = data.getData();
				}

				oResultData = oExactMatch.slice(0, 999);
				oResultModel = new sap.ui.model.json.JSONModel();
				oResultModel.setData(oResultData);
				this.getView().setModel(oResultModel, "dataModel");
				oResultValue = '0-999' + " out of " + oExactMatch.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultValue);
				this.checkVisibility(oExactMatch);

			} else if (data.getData().slice(0, 999).length > 0) {

				if (oExactValue == "A") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score === 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else if (oExactValue == "B") {
					for (var i = 0; i < data.getData().length; i++) {
						if (data.getData()[i].threshold_score !== 5) {
							oExactMatch.push(data.getData()[i]);
						}
					}
				} else {
					oExactMatch = data.getData();
				}

				oResultData = oExactMatch.slice(0, 999);
				oResultModel = new sap.ui.model.json.JSONModel();
				oResultModel.setData(oResultData);
				this.getView().setModel(oResultModel, "dataModel");
				oResultValue = '0-999' + " out of " + oExactMatch.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultValue);
				this.checkVisibility(oExactMatch);

			} else {
				oResultData = data.getData();
				oResultModel = new sap.ui.model.json.JSONModel();
				oResultModel.setData(oResultData);
				this.getView().setModel(oResultModel, "dataModel");
				oResultValue = '0-999' + " out of " + data.getData().length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultValue);
				this.checkVisibility(oExactMatch);
			}
		},

		checkVisibility: function (oValue) {
			if (oValue.length < 0) {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
			} else if (oValue.length > 0 && oValue.length <= 1000) {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
			} else if (oValue.length >= 1000 && oValue.length <= 2000) {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
			} else if (oValue.length >= 2000 && oValue.length <= 3000) {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
			} else if (oValue.length >= 3000 && oValue.length <= 4000) {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
			} else if (oValue.length >= 4000 && oValue.length <= 5000) {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
			} else if (oValue.length >= 5000 && oValue.length <= 6000) {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
			} else if (oValue.length >= 6000 && oValue.length <= 7000) {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
			} else if (oValue.length >= 7000 && oValue.length <= 8000) {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
			} else if (oValue.length >= 8000 && oValue.length <= 9000) {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
			} else {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", true);
			}

		},
		onPressFullScreenTable: function (oEvent) {
			this.byId("thumbnailSplitter").setSize("0%");
			this.byId("thumbnailSplitterData").setSize("0%");
			this.byId("thumbnailSplit").setSize("0%");
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleColumn", true);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/fullScreenButton", false);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/resizeSlider", false);
			this.getView().byId("MasterTable").removeSelections(true);
		},
		onPressRow: function (oEvent) {
			this.getView().byId("thumbnailDisplay").setBusy(true);
			var that = this;
			this.scale = 3;
			this.byId("thumbnailSplitter").setSize("50%");
			this.byId("thumbnailSplitterData").setSize("0%");
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/fullScreenButton", true);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/resizeSlider", true);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/showThumbnail", false);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pressedThumbnail", false);

			var pressedRowObject = oEvent.getParameter("listItem").getBindingContext("dataModel").getObject();
			var iPageNo = parseInt(pressedRowObject.page_number, 10);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/selectedDocId", pressedRowObject.case_document_id);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/selectedCaseId", pressedRowObject.case_id);
			// if (this.getOwnerComponent().getModel("pdfmodel").getProperty("/docId") !== pressedRowObject.case_document_id) {
			if (!(this.getOwnerComponent().getModel("pdfmodel").getProperty("/" + pressedRowObject.case_id))) {
				this.getOwnerComponent().getModel("pdfmodel").setProperty("/" + pressedRowObject.case_id, {});
			}
			if (!(pressedRowObject.case_document_id === this.getOwnerComponent().getModel("pdfmodel").getData()[pressedRowObject.case_id].docId)) {
				var aFilter = [];
				aFilter.push(new sap.ui.model.Filter("CaseId", "EQ", pressedRowObject.case_id));
				aFilter.push(new sap.ui.model.Filter("DocumentId", "EQ", pressedRowObject.case_document_id));
				this.getOwnerComponent().getModel().read("/DocReadSet", {
					filters: aFilter,
					success: function (oData) {
						// Code chnages start for US ITSDEDLC-1156
						var oPdfModel = new sap.ui.model.json.JSONModel();
						oPdfModel.setData({
							filename: pressedRowObject.doc_name,
							content: oData.results[0].FileContents
						});
						that.getView().byId("downloadPDF").setModel(oPdfModel);
						// code changes end for US ITSDEDLC-1156
						var oBBox = pressedRowObject.bbox_coords.join();
						var sBase64pdf1 = atob(oData.results[0].FileContents);
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/fileName", pressedRowObject.doc_name);
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleColumn", false);
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/selectedPageNumber", iPageNo);
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/selectedBBox", oBBox);
						that.pdfjsLib.getDocument({
							"data": sBase64pdf1
						}).then(function (sPdf) {
							var sProcessedDoc = sPdf;
							// that.getOwnerComponent().getModel("pdfmodel").setData({
							// 	pdffile: sBase64pdf1,
							// 	processedDoc: sProcessedDoc,
							// 	docId: pressedRowObject.case_document_id
							// });
							that.getOwnerComponent().getModel("pdfmodel").setProperty("/" + pressedRowObject.case_id, {
								pdffile: sBase64pdf1,
								processedDoc: sProcessedDoc,
								docId: pressedRowObject.case_document_id
							});

							that.fnRenderPage(iPageNo, oBBox);
							// that.appendthumb(iPageNo);
						});
					}
				});
			} else {
				var oBBox = pressedRowObject.bbox_coords.join();
				that.getOwnerComponent().getModel("appConfigModel").setProperty("/fileName", pressedRowObject.doc_name);
				that.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleColumn", false);
				that.getOwnerComponent().getModel("appConfigModel").setProperty("/selectedPageNumber", iPageNo);
				that.getOwnerComponent().getModel("appConfigModel").setProperty("/selectedBBox", oBBox);
				that.fnRenderPage(iPageNo, oBBox);
				// that.appendthumb(iPageNo);
			}
		},
		_deScaleCoordinates: function (oBoundingBox) {
			oBoundingBox[2] = (parseFloat(oBoundingBox[2], 10) + parseFloat(oBoundingBox[0], 10));
			oBoundingBox[3] = (parseFloat(oBoundingBox[3], 10) + parseFloat(oBoundingBox[1], 10));
			oBoundingBox[0] = parseFloat(oBoundingBox[0], 10) / this.renderedPageWidth;
			oBoundingBox[1] = parseFloat(oBoundingBox[1], 10) / this.renderedPageHeight;
			oBoundingBox[2] = oBoundingBox[2] / this.renderedPageWidth;
			oBoundingBox[3] = oBoundingBox[3] / this.renderedPageHeight;
			return oBoundingBox;
		},

		/*
			Scale the coordinates according the convas size
			@param(Array)An array of highlighting coordinates
			@return(Array) Array of scaled coordinates
			Called inside fnRenderPage() function
			*/
		_scaleCoordinates: function (oBoundingBox) {
			oBoundingBox[0] = oBoundingBox[0] * this.renderedPageWidth;
			oBoundingBox[1] = oBoundingBox[1] * this.renderedPageHeight;
			oBoundingBox[2] = (oBoundingBox[2] * this.renderedPageWidth) - oBoundingBox[0];
			oBoundingBox[3] = (oBoundingBox[3] * this.renderedPageHeight) - oBoundingBox[1];
			return oBoundingBox;
		},

		/* Rendering the requested page from the file
			and displaying it in canvas
			INPUT - PageNumber and BoundingBox
			OUTPUT - Display the pdf page with highlighted section */
		fnRenderPage: function (iPageNo, oBBox) {
			var that = this;
			var iScale = this.scale;
			var oCanvas = jQuery.sap.byId("the-canvas1")[0];
			var oCanvasContext = oCanvas.getContext("2d");
			var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var sSelDocId = this.getOwnerComponent().getModel("appConfigModel").getProperty("/selectedCaseId");
			var sPdf = this.getOwnerComponent().getModel("pdfmodel").getProperty("/" + sSelDocId).processedDoc;
			var iTotalPages = sPdf.numPages;
			if (iPageNo > iTotalPages) {
				iPageNo = 0;
				MessageBox.information(oResourceBundle.getText("pageNumPDFerror"));
			}
			that.pageNo = iPageNo;
			if (isNaN(iPageNo) || iPageNo === 0) {
				that.pageNo = 1;
				iPageNo = 1;
				oBBox = "";
				that.newBbox = "";
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/msgStripVisible", true);
				that.editFlag = 1;
			} else {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/msgStripVisible", false);
			}
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNo", iPageNo);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/currPageNo", iPageNo);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalPages", iTotalPages);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageBack", (iPageNo === 1) ? false : true);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNext", (iPageNo === iTotalPages) ? false : true);
			sPdf.getPage(that.pageNo).then(function (oPage) {
				var viewport = oPage.getViewport(iScale);
				oCanvas.height = viewport.height;
				oCanvas.width = viewport.width;
				that.renderedPageHeight = oCanvas.height;
				that.renderedPageWidth = oCanvas.width;
				var oRenderContext = {
					canvasContext: oCanvasContext,
					viewport: viewport
				};
				that.renderCanvas = oPage.render(oRenderContext);
				that.renderCanvas.then(function () {
					oCanvas.style.border = "1px solid black";
					if (oBBox) {
						var oBoundingBox = oBBox.split(",");
						oCanvasContext.beginPath();
						oBoundingBox = that._scaleCoordinates(oBoundingBox);
						oCanvasContext.rect(oBoundingBox[0], oBoundingBox[1], oBoundingBox[2], oBoundingBox[3]);
						oCanvasContext.fillStyle = "rgba(236,245,114,0.6)";
						oCanvasContext.fill();
					}
					that.getView().byId("thumbnailDisplay").setBusy(false);
				}).catch(function (oError) {
					MessageBox.error(oResourceBundle.getText("pageRenderError"));
					that.getView().byId("thumbnailDisplay").setBusy(false);
				});
			}).catch(function () {
				MessageBox.error(oResourceBundle.getText("pageNotFoundError"));
				that.getView().byId("thumbnailDisplay").setBusy(false);
			});
		},
		getViewSettingsDialog: function (sDialogFragmentName) {
			var pDialog = this._mViewSettingsDialogs[sDialogFragmentName];

			if (!pDialog) {
				pDialog = Fragment.load({
					id: this.getView().getId(),
					name: sDialogFragmentName,
					controller: this
				}).then(function (oDialog) {
					if (Device.system.desktop) {
						oDialog.addStyleClass("sapUiSizeCompact");
					}
					return oDialog;
				});
				this._mViewSettingsDialogs[sDialogFragmentName] = pDialog;
			}
			return pDialog;
		},
		// handleSortButtonPressed: function () {
		// 	this.getViewSettingsDialog("dlc.dcd.contractxray.fragment.SortDialog")
		// 		.then(function (oViewSettingsDialog) {
		// 			oViewSettingsDialog.open();
		// 		});
		// },

		//ITSDEDLC-929 Ascending and Dscending order 
		handleSort: function (oEvent) {
			var sortkey;
			var paired_button;
			var bDescending;
			var aSorters = [];
			var oTable = this.byId("MasterTable"),
				oBinding = oTable.getBinding("items");
			if (oEvent.getSource().getIdForLabel().includes("caseIdAsc") == true) {
				sortkey = "case_id";
				bDescending = false;
				paired_button = "caseIdDsc";
			} else if (oEvent.getSource().getIdForLabel().includes("caseIdDsc") == true) {
				sortkey = "case_id";
				bDescending = true;
				paired_button = "caseIdAsc";
			} else if (oEvent.getSource().getIdForLabel().includes("caseAccAsc") == true) {
				sortkey = "case_account_id";
				bDescending = false;
				paired_button = "caseAccDsc";
			} else if (oEvent.getSource().getIdForLabel().includes("caseAccDsc") == true) {
				sortkey = "case_account_id";
				bDescending = true;
				paired_button = "caseAccAsc";
			} else if (oEvent.getSource().getIdForLabel().includes("summaryAsc") == true) {
				sortkey = "orig_paragraph";
				bDescending = false;
				paired_button = "summaryDsc";
			} else if (oEvent.getSource().getIdForLabel().includes("summaryDsc") == true) {
				sortkey = "orig_paragraph";
				bDescending = true;
				paired_button = "summaryAsc";
			} else if (oEvent.getSource().getIdForLabel().includes("salesOrgAsc") == true) {
				sortkey = "case_sales_organisation";
				bDescending = false;
				paired_button = "salesOrgDsc";
			} else if (oEvent.getSource().getIdForLabel().includes("salesOrgDsc") == true) {
				sortkey = "case_sales_organisation";
				bDescending = true;
				paired_button = "salesOrgAsc";
			} else if (oEvent.getSource().getIdForLabel().includes("scoreAsc") == true) {
				sortkey = "threshold_score";
				bDescending = false;
				paired_button = "scoreDsc";
			} else {
				sortkey = "threshold_score";
				bDescending = true;
				paired_button = "scoreAsc";
			}

			aSorters.push(new Sorter(sortkey, bDescending));

			// apply the selected sort and group settings
			oBinding.sort(aSorters);
			//code changes start for US ITSDEDLC-1115
			if (oEvent.getSource().getProperty("type") === "Transparent") {
				oEvent.getSource().setProperty("type", "Emphasized");
				this.getView().byId(paired_button).setProperty("type", "Transparent");
			} else {
				oEvent.getSource().setProperty("type", "Transparent");
			}
			//code changes end for US ITSDEDLC-1115
		},

		//ITSDEDLC-806 - Code for Filtering on the Table columns
		handleFilter: function (oEvent) {
			var that = this;
			var oLabelText;
			var oView = that.getView();
			var oTable = this.getView().byId("MasterTable");
			var oLabel = new sap.m.Label().addStyleClass("labelStyle");
			var oInput = new sap.m.Input({
				width: "90%",
				change: function (oEvent) {
					var oValue = oEvent.getParameter("value");
					var oBindingPath = that.getOwnerComponent().getModel("appConfigModel").getProperty("/bindingValue");
					if (oBindingPath === "threshold_score") {
						var oFilter = new sap.ui.model.Filter(oBindingPath, "EQ", oValue);
					} else {
						var oFilter = new sap.ui.model.Filter(oBindingPath, "Contains", oValue);
					}
					var oItems = oTable.getBinding("items");
					var ofilterData = oItems.filter(oFilter);
					var oresultLength = ofilterData.getCount();
					var oResultsValue = "0-999" + " out of " + oresultLength;
					that.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
					oResposivePopover.close();
					// code change by C5250760 for US ITSDEDLC-1115
					var filtername = oEvent.getSource().getProperty('name');
					that.getView().byId("MasterTable").getInfoToolbar().setVisible(true);
					that.getView().byId("MasterTable").getInfoToolbar().getContent()[0].setProperty("text", "Filtered By: " + filtername);
					// code change by C5250760 for US ITSDEDLC-1115
				}
			});

			oLabel.setLabelFor(oInput);
			var oHBox = new sap.m.HBox({
				items: [oLabel, oInput]
			}).addStyleClass("HBoxStyle");
			var oResposivePopover = new sap.m.ResponsivePopover({
				title: "Filter",
				placement: "Bottom",
				content: [oHBox]
			});

			if (oEvent.getSource().getIdForLabel().includes("caseIdFilter") === true) {
				oLabelText = "Case ID:";
				oLabel.setText(oLabelText);
				oInput.setName("Case ID");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/bindingValue", "case_id");
			} else if (oEvent.getSource().getIdForLabel().includes("caseAccFilter") === true) {
				oLabelText = "DCD Cockpit:";
				oLabel.setText(oLabelText);
				oInput.setName("DCD Cockpit");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/bindingValue", "case_account_id");
			} else if (oEvent.getSource().getIdForLabel().includes("summaryFilter") === true) {
				oLabelText = "Summary:";
				oLabel.setText(oLabelText);
				oInput.setName("Summary");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/bindingValue", "orig_paragraph");
			} else if (oEvent.getSource().getIdForLabel().includes("salesOrgFilter") === true) {
				oLabelText = "Sales Org:";
				oLabel.setText(oLabelText);
				oInput.setName("Sales Org");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/bindingValue", "case_sales_organisation");
			} else {
				oLabelText = "Score:";
				oLabel.setText(oLabelText + "");
				oInput.setName("Score");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/bindingValue", "threshold_score");
			}
			oResposivePopover.openBy(oEvent.getSource());
		},

		createColumnConfig: function () {
			var aCols = [];
			var EdmType = ExportLibrary.EdmType;
			aCols.push({
				label: 'Case ID',
				type: EdmType.String,
				property: 'case_id'
			});
			aCols.push({
				label: 'ERP Number',
				type: EdmType.String,
				property: 'case_consumer_id'
			});
			aCols.push({
				label: 'BP Number',
				type: EdmType.String,
				property: 'case_account_id'
			});
			aCols.push({
				label: 'Summary Paragraph',
				type: EdmType.String,
				property: 'orig_paragraph'
			});
			//ITSDEDLC-758 - Added new cloumn Page Number for export excelsheet, also repositioned the cloumns Filename, Page Number, and Thersold Score after the Summary Paragraph
			aCols.push({
				label: 'Filename',
				type: EdmType.String,
				property: 'doc_name'
			});

			aCols.push({
				label: 'Page Number',
				type: EdmType.String,
				property: 'page_number'
			});
			aCols.push({
				label: 'Threshold Score',
				type: EdmType.Decimal,
				property: 'threshold_score'
			});
			aCols.push({
				label: 'Sales Org',
				type: EdmType.String,
				property: 'case_sales_organisation'
			});
			aCols.push({
				label: 'Sales Org Description',
				type: EdmType.String,
				property: 'case_sales_organisation_description'
			});
			aCols.push({
				label: 'Contract Type',
				type: EdmType.String,
				property: 'case_contract_type'
			});
			aCols.push({
				label: 'Contract Type Description',
				type: EdmType.String,
				property: 'case_contract_type_description'
			});
			aCols.push({
				label: 'Contract Scenario',
				type: EdmType.String,
				property: 'case_contract_scenario'
			});
			aCols.push({
				label: 'Contract Scenario Description',
				type: EdmType.String,
				property: 'case_contract_scenario_description'
			});
			aCols.push({
				label: 'Sign Date',
				type: EdmType.String,
				property: 'case_signature_date'
			});
			aCols.push({
				label: 'Country',
				type: EdmType.String,
				property: 'case_country'
			});
			aCols.push({
				label: 'Language',
				type: EdmType.String,
				property: 'case_language'
			});

			return aCols;
		},
		onExport: function () {
			var aCols, oRowBinding, oSettings, oSheet, oTable, oFilterData, signDatepicker, endDatepicker, length;
			var revenueType = [];
			var caseID = [];
			var salesOrg = [];
			var language = [];
			var country = [];
			var act_Doc = [];
			var custNum = [];
			var that = this;
			var date = new Date();
			var dateDay = date.getDate();
			var date1 = dateDay.toFixed().length;
			var dateMonth = date.getMonth();
			var month1 = dateMonth.toFixed().length;
			var dateYear = date.getFullYear();
			if (date1 === 1) {
				dateDay = "0" + dateDay;
			}
			if (month1 === 1) {
				dateMonth = "0" + dateMonth;
			}
			date = dateYear + "_" + dateMonth + "_" + dateDay;
			var file = "Contract_XRay_Data" + "_" + date + ".xlsx";
			oFilterData = that.getView().byId("smartFilterBar").getControlConfiguration()[0].getParent().getFilterData();
			signDatepicker = oFilterData._CUSTOM.signDatePicker.toDateString();
			endDatepicker = oFilterData._CUSTOM.endDatePicker.toDateString();
			if (oFilterData.LobId !== undefined) {
				length = oFilterData.LobId.items.length - 1;
				for (var i = 0; i <= length; i++) {
					revenueType.push(oFilterData.LobId.items[i].text);
				}
				var revenue = revenueType.toLocaleString();
			}
			if (oFilterData.CaseId !== undefined) {
				length = oFilterData.CaseId.items.length - 1;
				for (i = 0; i <= length; i++) {
					caseID.push(oFilterData.CaseId.items[i].text);
				}
				var caseId = caseID.toLocaleString();
			}
			if (oFilterData.SalesOrg !== undefined) {
				length = oFilterData.SalesOrg.items.length - 1;
				for (i = 0; i <= length; i++) {
					salesOrg.push(oFilterData.SalesOrg.items[i].text);
				}
				var salesOrgz = salesOrg.toLocaleString();
			}
			if (oFilterData.Language !== undefined) {
				length = oFilterData.Language.items.length - 1;
				for (i = 0; i <= length; i++) {
					language.push(oFilterData.Language.items[i].text);
				}
				var lang = language.toLocaleString();
			}
			if (oFilterData.Country !== undefined) {
				length = oFilterData.Country.items.length - 1;
				for (i = 0; i <= length; i++) {
					country.push(oFilterData.Country.items[i].text);
				}
				var ctry = country.toLocaleString();
			}
			if (oFilterData.Act_doc !== undefined) {
				length = oFilterData.Act_doc.items.length - 1;
				for (i = 0; i <= length; i++) {
					act_Doc.push(oFilterData.Act_doc.items[i].text);
				}
				var actDoc = act_Doc.toLocaleString();
			}
			if (oFilterData.CustNo !== undefined) {
				length = oFilterData.CustNo.items.length - 1;
				for (i = 0; i <= length; i++) {
					custNum.push(oFilterData.CustNo.items[i].text);
				}
				var custNumb = custNum.toLocaleString();
			}
			if (!this._oTable) {
				this._oTable = this.byId('MasterTable');
			}
			oTable = this._oTable;
			oRowBinding = oTable.getBinding('items');
			aCols = this.createColumnConfig();
			oSettings = {
				workbook: {
					columns: aCols,
					hierarchyLevel: 'Level',
					context: {
						sheetName: "Results",
						metaSheetName: "Search Query",
						metainfo: [{
							name: 'Search Information',
							items: [{
								key: 'Search Query : ',
								value: that.getView().byId("searchField").getValue()
							}, {
								key: 'Start Date : ',
								value: signDatepicker
							}, {
								key: 'End Date : ',
								value: endDatepicker
							}, {
								key: 'CaseID : ',
								value: caseId
							}, {
								key: 'Sales Org : ',
								value: salesOrgz
							}, {
								key: 'Revenue Type : ',
								value: revenue
							}, {
								key: 'Language : ',
								value: lang
							}, {
								key: 'Country : ',
								value: ctry
							}, {
								key: 'Account(Name or ID) : ',
								value: custNumb
							}, {
								key: 'DCD Document Category : ',
								value: actDoc
							}]
						}]
					}
				},
				dataSource: oRowBinding,
				fileName: file,
				worker: false // We need to disable worker because we are using a MockServer as OData Service
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function () {
				oSheet.destroy();
			});
		},

		_getSystemInfo: function () {
			var that = this;
			this.getOwnerComponent().getModel().callFunction("/GetServer", {
				method: "GET",
				urlParameters: {},
				success: jQuery.proxy(function (oData, response) {
					if (oData.GetServer) {
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/SystemsInfo", oData.GetServer);
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/NavigationEnabled", true);
					}
				}, this),
				error: function (oError) {
					sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		// code changes start for US ITSDEDLC-1205
		//getAdminAccess info
		getAdminAccess: function () {
			var that = this;
			this.getOwnerComponent().getModel().callFunction("/GetAdminAccess", {
				method: "GET",
				urlParameters: {},
				success: jQuery.proxy(function (oData, response) {
					if (oData.GetAdminAccess) {
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/AdminAccess", oData.GetAdminAccess.ADMIN);
					}
				}, this),
				error: function (oError) {
					sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},
		//event handler to open the menu dropdown
		onMenuAction: function (oEvent) {
			var key = oEvent.getParameter("item").getKey();
			switch (key) {
			case "0":
				this.onInfoEditPress();
				break;
			default:
				return;
			}
		},
		//Info tab edit
		onInfoEditPress: function (evt) {
			if (!this.oInfoEditDialog) {
				this.oInfoEditDialog = sap.ui.xmlfragment("dlc.dcd.contractxray.fragment.informationEdit", this);
				this.getView().addDependent(this.oInfoEditDialog);
			}
			this.oInfoEditDialog.open();
		},

		//Info tab cancel
		onInfoEditCancel: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();
			var that = this;
			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("pendingChangesMsg"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.resetChanges();
								that.oInfoEditDialog.close();
							}
						}
					}
				);
			} else {
				this.oInfoEditDialog.close();
			}
		},
		//overview tab  preview
		onOverviewPreview: function () {
			sap.ui.getCore().byId("previewOverviewButton").setVisible(false);
			sap.ui.getCore().byId("editOverviewButton").setVisible(true);

			sap.ui.getCore().byId("overviewTabInfo").setVisible(true);
			sap.ui.getCore().byId("overviewTabInfoEdit").setVisible(false);
		},

		//overview tab edit
		onOverviewEdit: function () {
			sap.ui.getCore().byId("previewOverviewButton").setVisible(true);
			sap.ui.getCore().byId("editOverviewButton").setVisible(false);

			sap.ui.getCore().byId("overviewTabInfo").setVisible(false);
			sap.ui.getCore().byId("overviewTabInfoEdit").setVisible(true);
		},
		//overview tab  save
		onOverviewSave: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();
			var oModelAppConfig = this.getOwnerComponent().getModel("appConfigModel");
			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("overviewSaveConfirmMsg"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.submitChanges({
									success: function () {
										var errorText = oModelAppConfig.getProperty("/errorText");
										if (errorText === "") {
											MessageToast.show(i18nModel.getText("overviewSaveSuccessMsg"));
										}
										oModelAppConfig.setProperty("/errorText", "");
									},
									error: function (error) {
										MessageToast.error(i18nModel.getText("overviewSaveErrorMsg"));
									}
								});
							}
						}
					}
				);
			} else {
				MessageToast.show(i18nModel.getText("noPendingChangesMsg"));
			}
		},

		//authorization preview 
		onAuthPreview: function () {
			sap.ui.getCore().byId("previewAuthButton").setVisible(false);
			sap.ui.getCore().byId("editAuthButton").setVisible(true);

			sap.ui.getCore().byId("authTabInfo").setVisible(true);
			sap.ui.getCore().byId("authTabInfoEdit").setVisible(false);
		},

		//authorization edit 
		onAuthEdit: function () {
			sap.ui.getCore().byId("previewAuthButton").setVisible(true);
			sap.ui.getCore().byId("editAuthButton").setVisible(false);

			sap.ui.getCore().byId("authTabInfo").setVisible(false);
			sap.ui.getCore().byId("authTabInfoEdit").setVisible(true);
		},

		//authorization save 
		onAuthSave: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oModel = this.getOwnerComponent().getModel();
			var oModelAppConfig = this.getOwnerComponent().getModel("appConfigModel");
			if (!jQuery.isEmptyObject(oModel.getPendingChanges())) {
				MessageBox.confirm(
					i18nModel.getText("authSaveConfirmMsg"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								oModel.submitChanges({
									success: function () {
										var errorText = oModelAppConfig.getProperty("/errorText");
										if (errorText === "") {
											MessageToast.show(i18nModel.getText("authSaveSuccessMsg"));
										}
										oModelAppConfig.setProperty("/errorText", "");
									},
									error: function (error) {
										MessageToast.error(i18nModel.getText("authSaveErrorMsg"));
									}
								});
							}
						}
					}
				);
			} else {
				MessageToast.show(i18nModel.getText("noPendingChangesMsg"));
			}
		},

		// code changes end for US ITSDEDLC-1205
		onCaseIdPress: function (oEvent) {
			var oCaseId = oEvent.getSource().getText();
			var prefixSubstitute = "000000000000";
			oCaseId = prefixSubstitute.substr(oCaseId.length) + oCaseId;
			var appConfigmodel = this.getOwnerComponent().getModel("appConfigModel");
			var sHTTPS = appConfigmodel.getProperty("/protocol");
			var sSystemID = appConfigmodel.getProperty("/SystemsInfo/Sysid");
			var url = appConfigmodel.getProperty("/url");
			var crmUrlCase = appConfigmodel.getProperty("/crmUrlCase");
			var crmUrlCaseMode = appConfigmodel.getProperty("/crmUrlCaseMode");

			var sUrl = sHTTPS + sSystemID + url + crmUrlCase + oCaseId + crmUrlCaseMode;
			sap.m.URLHelper.redirect(sUrl, true);
		},
		//ITSDEDLC-753 Begin code - Fetching caseid 
		onErpIdPress: function (oEvent) {
			var that = this;
			var erp_case = [];
			var oCaseId;
			var oAccountId;
			var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			for (var i = 0; i < this.getView().getModel("dataModel").getData().length; i++) {
				erp_case.push((this.getView().getModel("dataModel").getData()[i].case_account_id + ',' + this.getView().getModel("dataModel").getData()[
					i].case_id));
			}
			var oErpNumber = oEvent.getSource().getText();
			for (var i = 0; i < erp_case.length; i++) {
				for (var j = 0; j < erp_case[i].split(',').length; j++) {
					if (oErpNumber == erp_case[i].split(',')[j]) {
						oCaseId = erp_case[i].substring(11);
					}
				}
			}
			this.getOwnerComponent().getModel().callFunction("/GetAccount", {
				method: "GET",
				urlParameters: {
					CASE_ID: oCaseId,
					ACCOUNT_ID: "",
					ACCOUNT_NAME: ""

				},
				success: function (oData, response) {
					if (oData.results.length > 0 && oData.results[0].ACCOUNT_ID !== "") {
						oAccountId = oData.results[0].ACCOUNT_ID;
						that.openDCDCockpit(oErpNumber, oAccountId);
					} else {
						MessageToast.show(oResourceBundle.getText("accountErrorMsg"));
					}
				}, // callback function for success
				error: function (oError) {
						MessageToast.show(oResourceBundle.getText("accountFetchErrorMsg"));
					} // callback function for error
			});

		},
		//Open DCD Cockpit Application 
		openDCDCockpit: function (oValue1, oValue2) {
			var oErpNumber = (oValue1 * 1).toString();
			var oAccountId = oValue2;
			var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNav.isIntentSupported(["c2rdcd-Display"])
				.done(function (aResponses) {

				})
				.fail(function () {
					MessageToast(oResourceBundle.getText("navigationErrorMsg"));
				});
			var hash = (oCrossAppNav && oCrossAppNav.hrefForExternal({
				target: {
					// shellHash: "c2rdcd-Display"
					shellHash: "c2rdcd-Display&/CustomerDataEntitySet/" + oAccountId + "/" + oErpNumber
				}
			})) || "";
			//Generate a  URL for the second application
			var url = window.location.href.split('#')[0] + hash;
			//Navigate to second app
			sap.m.URLHelper.redirect(url, true);
		},

		//ITSDEDLC-753 end code
		//expand
		onExpand: function (oEvent) {
			var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			if (oEvent.getParameter("pressed")) {
				this.getView().byId("thumbnailSplitter").setSize("100%");
				oEvent.getSource().setIcon("sap-icon://exit-full-screen");
				oEvent.getSource().setTooltip(oResourceBundle.getText("exitFullScreen"));
			} else {
				this.getView().byId("thumbnailSplitter").setSize("50%");
				oEvent.getSource().setIcon("sap-icon://full-screen");
				oEvent.getSource().setTooltip(oResourceBundle.getText("enterFullScreen"));
			}
		},
		onExpands: function (oEvent) {
			var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			if (oEvent.getParameter("pressed")) {
				this.getView().byId("thumbnailSplit").setSize("100%");
				oEvent.getSource().setIcon("sap-icon://exit-full-screen");
				oEvent.getSource().setTooltip(oResourceBundle.getText("exitFullScreen"));
			} else {
				this.getView().byId("thumbnailSplit").setSize("50%");
				oEvent.getSource().setIcon("sap-icon://full-screen");
				oEvent.getSource().setTooltip(oResourceBundle.getText("enterFullScreen"));
			}
		},

		//zoom in
		onZoomIn: function (oEvent) {
			var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var sPageId = this.getView().byId("thumbnailDisplay").getId(),
				sPageWidth = jQuery.sap.byId(sPageId)[0].offsetWidth,
				sCanvasWidth = jQuery.sap.byId("the-canvas1")[0].width;
			if ((sPageWidth - sCanvasWidth) >= 200) {
				this.scale += 0.25;
				var iPageNo = parseInt(this.getOwnerComponent().getModel("appConfigModel").getProperty("/pageNo"), 10);
				var iCurrPage = this.getOwnerComponent().getModel("appConfigModel").getProperty("/selectedPageNumber");
				var sCurrCoordinates = this.getOwnerComponent().getModel("appConfigModel").getProperty("/selectedBBox");
				if (iCurrPage === iPageNo) {
					this.fnRenderPage(iCurrPage, sCurrCoordinates);
				} else {
					this.fnRenderPage(iPageNo);
				}
			} else {
				MessageBox.warning(oResourceBundle.getText("maxZoomWarning"));
			}
		},

		//zoom out
		onZoomOut: function (oEvent) {
			if (this.scale && this.scale > 1) {
				this.scale -= 0.25;
				var iPageNo = parseInt(this.getOwnerComponent().getModel("appConfigModel").getProperty("/pageNo"), 10);
				var iCurrPage = this.getOwnerComponent().getModel("appConfigModel").getProperty("/selectedPageNumber");
				var sCurrCoordinates = this.getOwnerComponent().getModel("appConfigModel").getProperty("/selectedBBox");
				if (iCurrPage === iPageNo) {
					this.fnRenderPage(iCurrPage, sCurrCoordinates);
				} else {
					this.fnRenderPage(iPageNo);
				}
			}
		},
		// code changes start by C5250760 for US ITSDEDLC-1156
		onDownloadDoc: function (oEvent) {

			var oPdfModel = oEvent.getSource().getModel();
			if (oPdfModel) {
				var data = oPdfModel.getData();
				if (data.filename && data.content) {
					var element = document.createElement("a");
					element.setAttribute("href", "data:application/pdf;base64," + data.content);
					element.setAttribute("download", data.filename);
					document.body.appendChild(element);
					element.click();
					document.body.removeChild(element);
				}
			}
		},
		//Code change end by C5250760 for US ITSDEDLC-1156

		changePage: function (iPageNo) {
			// var iTotalPages = this.getOwnerComponent().getModel("pdfmodel").getProperty("/processedDoc").numPages;
			var iTotalPages = this.getOwnerComponent().getModel("appConfigModel").getProperty("/totalPages");
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNo", iPageNo);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/currPageNo", iPageNo);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageBack", (iPageNo === 1) ? false : true);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNext", (iPageNo === iTotalPages) ? false : true);
			var iCurrPage = this.getOwnerComponent().getModel("appConfigModel").getProperty("/selectedPageNumber");
			var sCurrCoordinates = this.getOwnerComponent().getModel("appConfigModel").getProperty("/selectedBBox");
			if (iCurrPage === iPageNo) {
				this.fnRenderPage(iCurrPage, sCurrCoordinates);
			} else {
				this.fnRenderPage(iPageNo);
			}
		},
		// Load the previous page of te PDF
		onPageBack: function (oEvent) {
			var iPageNo = parseInt(this.getOwnerComponent().getModel("appConfigModel").getProperty("/pageNo"), 10) - 1;
			this.changePage(iPageNo);
			// this.appendthumb(iPageNo);
		},
		// Load the Next page of te PDF
		onPageNext: function (oEvent) {
			var iPageNo = parseInt(this.getOwnerComponent().getModel("appConfigModel").getProperty("/pageNo"), 10) + 1;
			this.changePage(iPageNo);
			// this.appendthumb(iPageNo);
		},
		/*
			Called when user enter a specific page number and press enter
			Render the PDF page requested by user
			@param(Source of the input field for page number)
		*/
		onChangePageNumber: function (oEvent) {
			var iPageNo = parseInt(this.getOwnerComponent().getModel("appConfigModel").getProperty("/pageNo"), 10);
			var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			// var iTotalPages = this.getOwnerComponent().getModel("pdfmodel").getProperty("/processedDoc").numPages;
			var iTotalPages = this.getOwnerComponent().getModel("appConfigModel").getProperty("/totalPages");
			var iCurrPageNo = this.getOwnerComponent().getModel("appConfigModel").getProperty("/currPageNo");
			if (iPageNo > iTotalPages || iPageNo < 1) {
				MessageBox.error(oResourceBundle.getText("wrongPageNumberErr"));
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNo", iCurrPageNo);
			} else {
				var iCurrPage = this.getOwnerComponent().getModel("appConfigModel").getProperty("/selectedPageNumber");
				var sCurrCoordinates = this.getOwnerComponent().getModel("appConfigModel").getProperty("/selectedBBox");
				if (iCurrPage === iPageNo) {
					this.fnRenderPage(iCurrPage, sCurrCoordinates);
				} else {
					this.fnRenderPage(iPageNo);
				}
				// this.appendthumb(iPageNo);
			}
		},
		//expand thumbnail view
		onExpandThumbnail: function (oEvent) {
			if (oEvent.getParameter("pressed")) {
				this.byId("thumbnailSplitterData").setSize("10%");
			} else {
				this.byId("thumbnailSplitterData").setSize("0%");
			}
		},
		appendthumb: function (pageNo) {
			var current = "";
			var sSelDocId = this.getOwnerComponent().getModel("appConfigModel").getProperty("/selectedCaseId");
			var sPdf = this.getOwnerComponent().getModel("pdfmodel").getProperty("/" + sSelDocId).processedDoc;
			// var sPdf = this.getOwnerComponent().getModel("pdfmodel").getProperty("/processedDoc");
			jQuery.sap.byId("thumbViewer")[0].innerHTML = "";
			var pages = [];
			var that = this;
			while (pages.length < sPdf.numPages) {
				pages.push(pages.length + 1);
			}
			return Promise.all(pages.map(function (num) {
				// create a div for each page and build a small canvas for it
				var div = document.createElement("div");
				div.addEventListener("click", function (oEvent) {
					if (current) {
						current.style.border = "none";
					}
					current = div;
					div.style.border = "3px solid #447bcf";
					that.changePage(num);
				});
				div.style.margin = "5px";
				div.style.textAlign = "center";
				div.style.paddingBottom = "10px";
				if (num == pageNo) {
					current = div;
					div.style.border = "3px solid #447bcf";
				}
				jQuery.sap.byId("thumbViewer")[0].appendChild(div);
				return sPdf.getPage(num).then(that.makeThumb)
					.then(function (thumbCanvas) {
						var p1 = document.createElement('p');
						p1.innerHTML = num;
						p1.style.textAlign = "center";
						p1.style.margin = "0";
						div.appendChild(thumbCanvas);
						div.appendChild(p1);

					});
				// MessageBox.error("Thumbnail Created");
				// MessageBox.information("Thumbnail Created");
			}));
		},

		makeThumb: function (page) {
			// draw page to fit into 96x96 canvas
			var vp = page.getViewport(1);
			var canvas = document.createElement("canvas");
			canvas.width = canvas.height = 96;
			var scale = Math.min(canvas.width / vp.width, canvas.height / vp.height);
			return page.render({
				canvasContext: canvas.getContext("2d"),
				viewport: page.getViewport(scale)
			}).promise.then(function () {
				return canvas;
			});
		},
		onGenerateThumbnail: function () {
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/showThumbnail", true);
			this.appendthumb(this.getOwnerComponent().getModel("appConfigModel").getProperty("/selectedPageNumber"));
		},
		onScoreInfoPress: function (oEvent) {
			var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			if (!this.oDefaultMessageDialog) {
				this.oDefaultMessageDialog = new Popover({
					title: "Score Calculation",
					placement: "HorizontalPreferredRight",
					content: [new sap.m.Text({
						text: i18nModel.getText("SearchText")
					})]
				});
			}
			this.oDefaultMessageDialog.addStyleClass("sapUiContentPadding");
			this.oDefaultMessageDialog.openBy(oEvent.getSource());
		},

		//ITSDEDLC-808 New function is implemented for Result Bach Filter and Exact Matches 
		onHandleResultsChange: function (oEvent) {
			var oResultsValue;
			var oSelectedText;
			var oExact = [];
			var oSelectedKey = oEvent.getSource().getSelectedKey();
			var oResultsBatchId = this.getView().byId("exactMatchesId").getSelectedKey();
			var oData = this.getOwnerComponent().getModel("appConfigModel").getProperty("/oResultModel");
			var oResultData = new sap.ui.model.json.JSONModel();

			if (oSelectedKey == "1" && oResultsBatchId == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(0, 999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");

			} else if (oSelectedKey == "1" && oResultsBatchId == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(0, 999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			} else if (oSelectedKey == "1" && oResultsBatchId == "C") {
				oResultData.setData(oData.oData.slice(0, 999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			}
			if (oSelectedKey == "2" && oResultsBatchId == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}

				oResultData.setData(oExact.slice(1000, 1999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");

			} else if (oSelectedKey == "2" && oResultsBatchId == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}

				oResultData.setData(oExact.slice(1000, 1999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			} else if (oSelectedKey == "2" && oResultsBatchId == "C") {

				oResultData.setData(oData.oData.slice(1000, 1999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			}
			if (oSelectedKey == "3" && oResultsBatchId == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(2000, 2999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			}
			if (oSelectedKey == "3" && oResultsBatchId == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(2000, 2999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");

			} else if (oSelectedKey == "3" && oResultsBatchId == "C") {
				oResultData.setData(oData.oData.slice(2000, 2999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			}
			if (oSelectedKey == "4" && oResultsBatchId == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(3000, 3999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");

			} else if (oSelectedKey == "4" && oResultsBatchId == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(3000, 3999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			} else if (oSelectedKey == "4" && oResultsBatchId == "C") {
				oResultData.setData(oData.oData.slice(3000, 3999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			}
			if (oSelectedKey == "5" && oResultsBatchId == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(4000, 4999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");

			} else if (oSelectedKey == "5" && oResultsBatchId == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(4000, 4999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			} else if (oSelectedKey == "5" && oResultsBatchId == "C") {
				oResultData.setData(oData.oData.slice(4000, 4999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			}
			if (oSelectedKey == "6" && oResultsBatchId == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(5000, 5999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");

			} else if (oSelectedKey == "6" && oResultsBatchId == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(5000, 5999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			} else if (oSelectedKey == "6" && oResultsBatchId == "C") {
				oResultData.setData(oData.oData.slice(5000, 5999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			}
			if (oSelectedKey == "7" && oResultsBatchId == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(6000, 6999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");

			} else if (oSelectedKey == "7" && oResultsBatchId == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(6000, 6999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			} else if (oSelectedKey == "7" && oResultsBatchId == "C") {
				oResultData.setData(oData.oData.slice(6000, 6999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			}
			if (oSelectedKey == "8" && oResultsBatchId == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(7000, 7999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");

			} else if (oSelectedKey == "8" && oResultsBatchId == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(7000, 7999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			} else if (oSelectedKey == "8" && oResultsBatchId == "C") {
				oResultData.setData(oData.oData.slice(7000, 7999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			}
			if (oSelectedKey == "9" && oResultsBatchId == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(8000, 8999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");

			} else if (oSelectedKey == "9" && oResultsBatchId == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(8000, 8999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			} else if (oSelectedKey == "9" && oResultsBatchId == "C") {
				oResultData.setData(oData.oData.slice(8000, 8999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			}
			if (oSelectedKey == "10" && oResultsBatchId == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(9000, 9999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");

			} else if (oSelectedKey == "10" && oResultsBatchId == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}
				oResultData.setData(oExact.slice(9000, 9999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			} else if (oSelectedKey == "10" && oResultsBatchId == "C") {
				oResultData.setData(oData.oData.slice(9000, 9999));
				oSelectedText = oEvent.getSource().getSelectedItem().getText();
				oResultsValue = oSelectedText + " out of " + oData.oData.length;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
				this.getView().setModel(oResultData, "dataModel");
			}
		},

		//ITSDEDLC-804 - Exact matches with blank, Exact match only, Not exact match 
		onHandleExactChange: function (oEvent) {
			var oExact = [];
			var oResultsValue;
			var oResultsBatchId = this.getView().byId("resultsBatchID").getSelectedKey();
			var oResultsBatchText = this.getView().byId("resultsBatchID").getSelectedItem().getText();
			var oExactMatch = oEvent.getSource().getSelectedKey();
			var oData = this.getOwnerComponent().getModel("appConfigModel").getProperty("/oResultModel");
			var oResultData = new sap.ui.model.json.JSONModel();

			if (oResultsBatchId == "1" && oExactMatch == "B") {
				if (oData === undefined) {

					oExact.push(this.getView().byId("exactMatchesId")._getSelectedItemText());
				}
				if (oData !== undefined) {
					for (var i = 0; i < oData.oData.length; i++) {
						if (oData.oData[i].threshold_score !== 5) {
							oExact.push(oData.oData[i]);
						}
					}
				}

				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);

			} else if (oResultsBatchId == "1" && oExactMatch == "A") {
				if (oData === undefined) {
					oExact.push(this.getView().byId("exactMatchesId")._getSelectedItemText());
				}
				if (oData !== undefined) {
					for (var i = 0; i < oData.oData.length; i++) {
						if (oData.oData[i].threshold_score === 5) {
							oExact.push(oData.oData[i]);
						}
					}
				}
				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);

			} else if (oResultsBatchId == "1" && oExactMatch == "C") {
				this.getView().byId("exactMatchesId").setSelectedKey("C");
				this.checkResultsBatch(this.getOwnerComponent().getModel("appConfigModel").getProperty("/oResultModel"));
			}
			if (oResultsBatchId == "2" && oExactMatch == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}

				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "2" && oExactMatch == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "2" && oExactMatch == "C") {
				this.checkResultsBatch(this.getOwnerComponent().getModel("appConfigModel").getProperty("/oResultModel"));
			}
			if (oResultsBatchId == "3" && oExactMatch == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}

				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "3" && oExactMatch == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "3" && oExactMatch == "C") {
				this.checkResultsBatch(this.getOwnerComponent().getModel("appConfigModel").getProperty("/oResultModel"));
			}
			if (oResultsBatchId == "4" && oExactMatch == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}

				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "4" && oExactMatch == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "4" && oExactMatch == "C") {
				this.checkResultsBatch(this.getOwnerComponent().getModel("appConfigModel").getProperty("/oResultModel"));
			}
			if (oResultsBatchId == "5" && oExactMatch == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}

				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
				}

				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "5" && oExactMatch == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				if (oExact.length > 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "5" && oExactMatch == "C") {
				this.checkResultsBatch(this.getOwnerComponent().getModel("appConfigModel").getProperty("/oResultModel"));
			}
			if (oResultsBatchId == "6" && oExactMatch == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}

				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);

				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "6" && oExactMatch == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					ooResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true)
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true)
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "6" && oExactMatch == "C") {
				this.checkResultsBatch(this.getOwnerComponent().getModel("appConfigModel").getProperty("/oResultModel"));
			}
			if (oResultsBatchId == "7" && oExactMatch == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}

				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "7" && oExactMatch == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "7" && oExactMatch == "C") {
				this.checkResultsBatch(this.getOwnerComponent().getModel("appConfigModel").getProperty("/oResultModel"));
			}
			if (oResultsBatchId == "8" && oExactMatch == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}

				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "8" && oExactMatch == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "8" && oExactMatch == "C") {
				this.checkResultsBatch(this.getOwnerComponent().getModel("appConfigModel").getProperty("/oResultModel"));
			}
			if (oResultsBatchId == "9" && oExactMatch == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}

				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "9" && oExactMatch == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "9" && oExactMatch == "C") {
				this.checkResultsBatch(this.getOwnerComponent().getModel("appConfigModel").getProperty("/oResultModel"));
			}
			if (oResultsBatchId == "10" && oExactMatch == "B") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score !== 5) {
						oExact.push(oData.oData[i]);
					}
				}

				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = oResultsBatchText + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "10" && oExactMatch == "A") {
				for (var i = 0; i < oData.oData.length; i++) {
					if (oData.oData[i].threshold_score === 5) {
						oExact.push(oData.oData[i]);
					}
				}
				if (oExact.length >= 0 && oExact.length < 999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 1000 && oExact.length < 1999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 2000 && oExact.length < 2999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 3000 && oExact.length < 3999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 4000 && oExact.length < 4999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 5000 && oExact.length < 5999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 6000 && oExact.length < 6999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 7000 && oExact.length < 7999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", false);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 8000 && oExact.length < 8999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", false);
				}
				if (oExact.length > 9000 && oExact.length < 9999) {
					oResultData.setData(oExact.slice(0, 999));
					oResultsValue = '0-999' + " out of " + oExact.length;
					this.getView().byId("resultsBatchID").setSelectedKey(1);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem1", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem2", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem3", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem4", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem5", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem6", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem7", true);
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleItem8", true);
				}
				this.getView().setModel(oResultData, "dataModel");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalResults", oResultsValue);
			} else if (oResultsBatchId == "10" && oExactMatch == "C") {
				this.checkResultsBatch(this.getOwnerComponent().getModel("appConfigModel").getProperty("/oResultModel"));
			}
		}
	});
});