sap.ui.define(
    ["sap/ovp/app/Component"],
    function (Component) {
        "use strict";

        return Component.extend("com.sap.zapmoverview.zapmoverview.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);