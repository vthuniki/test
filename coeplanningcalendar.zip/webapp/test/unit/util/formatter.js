sap.ui.define([
    "sap/coe/planning/calendar/util/formatter",
    "sap/ui/thirdparty/sinon",
    "sap/ui/thirdparty/sinon-qunit"
], function(oFormatter) {
    "use strict";
    var sandbox = sinon.sandbox.create();

    QUnit.module("Util - formatter", {
        afterEach: function() {
            sandbox.restore();
        }
    });

    QUnit.test("Should be possible to import an instance", function(assert) {
        assert.ok(oFormatter, "Was possible to import the instance");
    });

    QUnit.test("StaffingLevel: Should return the correct Staffing Level from its key value", function(assert) {
        oFormatter.getModel = function() {};
        var oUtilsModel = new sap.ui.model.json.JSONModel(),
            stubGetModel;
        oUtilsModel.loadData(jQuery.sap.getModulePath("sap.coe.planning.calendar") + "/model/utilsModel.json", "", false);
        stubGetModel = sandbox.stub(oFormatter, "getModel");
        stubGetModel.withArgs("UtilsModel").returns(oUtilsModel);

        var sStaffingLevel = oFormatter.staffingLevel("A"),
            sExpectedStaffingLevel = "Not Staffed";

        assert.strictEqual(sStaffingLevel, sExpectedStaffingLevel, "It was returned the right Staffing Level");
    });

    QUnit.test("Date: Should return an string with format 'MMM d,YYYY'", function(assert) {
        var oDateTest = new Date(2016, 5, 13),
            sDate = oFormatter.date(oDateTest),
            sExpectedDate = "Jun 13,2016";

        assert.strictEqual(sDate, sExpectedDate, "The date was correctly formatted");
    });

    QUnit.test("Date: Should not fail when a null date is given", function(assert) {
        var oDateTest = null,
            sDate = oFormatter.date(oDateTest);

        assert.ok(true, "The method didn't fail");
    });

    QUnit.test("Date: Should not fail when a no date object is given", function(assert) {
        var oDateTest = "0",
            sDate = oFormatter.date(oDateTest);

        assert.ok(true, "The method didn't fail");
    });

});
