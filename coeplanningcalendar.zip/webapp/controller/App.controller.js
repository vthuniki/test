sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/coe/capacity/reuselib/controls/TimeZoneSelect/TimeZoneSettings"
], function(Controller, TimeZoneSettings) {
    "use strict";

    return Controller.extend("sap.coe.planning.calendar.controller.App", {
        aSplitRoutes: ["planningCalendar"],

        onInit: function(oEvent) {
            var oSource = oEvent.getSource(),
                oAppView = oSource.byId("idAppControl"),
                oSplitView = oSource.byId("idSplitAppControl"),
                oRouter = this.getOwnerComponent().getRouter();

            oRouter.attachRouteMatched(function(oRouterEvent) {
                if (this.aSplitRoutes.indexOf(oRouterEvent.getParameter("name")) !== -1) {
                    oAppView.setVisible(false);
                    oSplitView.setVisible(true);
                    oSplitView.removeStyleClass("sapUiHidden");
                } else {
                    oSplitView.addStyleClass("sapUiHidden");
                    oAppView.setVisible(true);
                }
            }, this);

            TimeZoneSettings._setTimeZoneModelToView(this, "sap.coe.capacity.reuselib");
            sap.ui.getCore().getConfiguration().getFormatSettings().setFirstDayOfWeek(1);
        },

        onBeforeRendering: function() {
            TimeZoneSettings._setAppSettingButtons(this);
            TimeZoneSettings._getUserTimeZone(this);
        }

    });
});
