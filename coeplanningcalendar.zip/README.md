# Resource Demand List

CoE Team Lead and responsible Staffers can use these Apps to review the incoming demands (services) and assign resources to them.

More details can be found on our [JAM page](https://jam4.sapjam.com/groups/iDrRymI7rWhoNrog2NpHea/overview_page/eRxEi3ldOwNv12C4RB3H1g).

## Technical Names
**Repository Name:** coereourceplanning

**Name in sapitcloudt:** resourceplanning

**FLP Name:** Resource Demand List - CoE Worklist

## Deployments
Deployed Version No: 1.23

Ver 1.23 - Bugfix - Retrieve User Info in the CFLP

Ver 1.22 - Revert to old usage tracking id

Ver 1.21 - Add Event tracking for p13n settings

Ver 1.19 - Add new usage tracking id

Ver 1.18 - Update layout for details page

Ver 1.16 - Bugfix - Changed user status canceled key

Ver 1.9 - 8007287801 - Issue with 'planningcalendar (Resource Supply Planning)' - Unable to delete variant value

Ver 1.8 - Update component to read reuselib
