sap.m.Table.extend("com.sap.globalit.mur.report.TrackingTable", {

	metadata: {
		properties: {
			"csvDownload": {
				type: "object"
			},
			valueSuffix: {
				type: "string",
				defaultValue: ""
			},
			filter: {
				type: "string[]",
				defaultValue: []
			}
		}
	},

	renderer: {},

	init: function() {
		if (sap.m.Table.prototype.init) {
			sap.m.Table.prototype.init.apply(this, arguments);
		}
		
		var self = this;

		this.bindAggregation("columns", "/columns", new sap.m.Column({
			vAlign: sap.ui.core.VerticalAlign.Middle,
			width: "6em",
			header: new sap.m.Label({
				text: "{name}"
			}),
			visible: {
				path: "/",
				formatter: function() {
					var obj = this.getModel().getProperty(this.getBindingContext().sPath);
					var isVisible = true;
					if (self.getFilter().length !== 0) {
						if ($.inArray(atob(obj.key), self.getFilter()) === -1) {
							isVisible = false;
						}
					}
					return isVisible;
				}
			}
		}));

		this.bindAggregation("items", "/tableData", function($, i) {
			var result = new sap.m.ColumnListItem({
				cells: [new sap.m.ObjectIdentifier({
					title: "{" + i.getModel().getData().columns[0].key + "}"
				})]
			});

			var formatterFunction = function(fValue) {
				if (fValue === -1) {
					return "-";
				}
				return fValue + this.getValueSuffix();
			}.bind(this);

			for (var counter = 1; counter < i.getModel().oData.columns.length; counter++) {
				var vorlage = i.getModel().oData.columns[counter];
				result.addCell(new sap.m.Text({
					text: {
						path: vorlage.key
					}
				}));
			}
			return result;
		});

		this.setHeaderToolbar(new sap.m.Toolbar({
			content: [new sap.m.ToolbarSpacer({}), new sap.m.Button({
				text: "Open in Excel",
				icon: "sap-icon://excel-attachment",
				press: [this.onCsvDownload, this]
			})]
		}));

		this.setGrowing(true);
		this.setGrowingThreshold(100);
		this.setGrowingScrollToLoad(true);
	},

	onCsvDownload: function() {
		// 1 -> generate csv
		$.ajax({
			url: this.getCsvDownload().url,
			type: "POST",
			data: this.getCsvDownload().data,
			dataType: "text"
		}).done(function(response) {
			// 2 -> trigger download
			window.location.href = Backend.api("internal/report/v2/CSVExport?uuid=" + response);
		});
	},

	onAfterRendering: function() {

		// enable horizontal scrolling in table
		$("#detail--page-scroll").css("overflow", "visible");
		$("#detail--page-cont").css("overflow", "auto");
	}

});