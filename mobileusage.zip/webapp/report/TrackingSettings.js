sap.ui.define([
    "sap/ui/base/Object",
    "com/sap/globalit/mur/report/TimeUtils"
], function (Object, TimeUtils) {
    "use strict";
    return Object.extend("com.sap.globalit.mur.report.TrackingSettings", {

        isReady: null,
        settingsObj: null,

        init: function () {
            sap.ui.base.Object.apply(this, arguments);

            jQuery.sap.require("sap.ui.core.format.DateFormat");

            this.settingsObj = new sap.ui.model.json.JSONModel({});
            this.settingsObj.loadData(Backend.api("reporting/settings"), null);

            if (this.isReady === null) {
                this.isReady = $.Deferred();
            }

            this.settingsObj.attachRequestCompleted({}, function () {
                var currentData = this.getData();

                var dateFormatter = sap.ui.core.format.DateFormat.getDateInstance({UTC: true});

                var timeString = dateFormatter.format(new Date(currentData.timeFrom)) + ' - ' + dateFormatter.format(new Date(currentData.timeTo));

                currentData.timeString = timeString;

                new TimeUtils().snapTime(currentData);
                this.setData(currentData);

                this.isReady.resolve();
            }, this);

        },

        onReady: function (callback) {
            if (this.isReady === null) {
                this.isReady = $.Deferred();
            }
            this.isReady.done(callback.bind(this));
        },

        getURLParameter: function (name) {
            return decodeURIComponent((new RegExp('[?|&]' + name + '='
                    + '([^&;]+?)(&|#|;|$)').exec("?" + location.search) || [, ""])[1]
                    .replace(/\+/g, '%20'))
                || null;
        },

        updateRange: function () {
        },

        /**
         returns an Array, containing only the App ID as a String
         e.g. ["EasyConnect","LeaveRequest",...]
         **/
        getSelectedApps: function () {
            return this.settingsObj.getProperty("/applications");
        },

        getData: function () {
            return this.settingsObj.getData();
        },

        setData: function (newData) {
            this.settingsObj.setData(newData);
            this.updateUserSettingsInBackend();
        },

        setTimeSettings: function (from, to, timeString, interval) {
            this.settingsObj.setProperty("/timeFrom", from);
            this.settingsObj.setProperty("/timeTo", to);
            this.settingsObj.setProperty("/timeInterval", interval);
            this.settingsObj.setProperty("/timeString", timeString);
            this.updateUserSettingsInBackend();
        },

        getReport: function () {
            return this.settingsObj.getProperty("/reportId");
        },

        getView: function () {
            return this.settingsObj.getProperty("/viewId");
        },

        setReportAndView: function (report, view) {
            this.settingsObj.setProperty("/reportId", report);
            this.settingsObj.setProperty("/viewId", view);
            this.updateUserSettingsInBackend();
        },

        getStartDate: function () {
            return this.settingsObj.getProperty("/timeFrom");
        },

        getEndDate: function () {
            return this.settingsObj.getProperty("/timeTo");
        },

        getInterval: function () {
            return this.settingsObj.getProperty("/timeInterval");
        },

        setSelectedApps: function (selectedApps) {
            this.settingsObj.setProperty("/applications", selectedApps);
            this.updateUserSettingsInBackend();
        },

        updateUserSettingsInBackend: function () {

            var userSettings = {
                "type": "USER",
                "applications": this.getSelectedApps(),
                "reportId": this.getReport(),
                "viewId": this.getView(),
                "timeFrom": this.getStartDate(),
                "timeTo": this.getEndDate(),
                "timeInterval": this.getInterval()
            };

            $.ajax({
                type: "POST",
                url: Backend.api("reporting/settings"),
                data: JSON.stringify(userSettings),
                contentType: "application/json",
                error: function (response) {
                    $.sap.log.error("Error:" + response.statusText + " (" + response.status + ")");
                },
                success: function () {
                    $.sap.log.info("User Settings updated!");
                }
            });
        }

    });
});


(function ($) {
    var re = /([^&=]+)=?([^&]*)/g;
    var decodeRE = /\+/g; // Regex for replacing addition symbol with a space
    var decode = function (str) {
        return decodeURIComponent(str.replace(decodeRE, " "));
    };
    $.parseParams = function (query) {
        var params = {}, e;
        while (e = re.exec(query)) {
            var k = decode(e[1]), v = decode(e[2]);
            if (k.substring(k.length - 2) === '[]') {
                k = k.substring(0, k.length - 2);
                (params[k] || (params[k] = [])).push(v);
            } else
                params[k] = v;
        }
        return params;
    };
})(jQuery);