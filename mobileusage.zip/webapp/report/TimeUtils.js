sap.ui.define([
    "sap/ui/base/Object"
], function (Object) {
    "use strict";
    return Object.extend("com.sap.globalit.mur.report.TimeUtils", {
        init: function () {
            sap.ui.base.Object.apply(this, arguments);

        },

        snapTime: function (newData) {

            if (newData.timeFrom === undefined) {
                return;
            }

            var startMoment = moment.utc(newData.timeFrom);
            var endMoment = moment.utc(newData.timeTo);

            // snap start and end based on time interval
            var snapInterval = newData.timeInterval;
            if(snapInterval === "WEEK")
            	snapInterval = "ISOWEEK";
            
            startMoment = startMoment.startOf(snapInterval);
            endMoment = endMoment.endOf(snapInterval);

            //console.log("snapped Start: " + startMoment.format());
            //console.log("snapped End  : " + endMoment.format());

            // todo don´t display future days
            var maxEnd = moment.utc().endOf(snapInterval);
            if (endMoment.isAfter(maxEnd)) {
                endMoment = maxEnd;
            }

            // convert to miliseconds
            newData.timeFrom = startMoment.valueOf();
            newData.timeTo = endMoment.valueOf();

        }


    });
});