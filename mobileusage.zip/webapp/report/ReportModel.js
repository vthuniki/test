sap.ui.define([
	"sap/ui/model/json/JSONModel"
], function(JSONModel) {
	"use strict";
	return JSONModel.extend("com.sap.globalit.mur.report.ReportModel", {
		constructor: function() {
			sap.ui.model.json.JSONModel.apply(this, arguments);
			
			// TODO convert this to a promise
			this.loadData(Backend.api("reporting/master/reports"),"", false);
		},

		getReport: function(reportId) {

			var report = null;

			this.getProperty("/").forEach(function(entry) {
				if (entry.id === reportId) {
					report = entry;
				}
			});

			return report;
		}
	});
});