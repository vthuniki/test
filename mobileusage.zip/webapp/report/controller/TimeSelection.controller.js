sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/globalit/mur/report/TimeUtils"
], function(Controller, TimeUtils) {
	"use strict";
	return Controller.extend("com.sap.globalit.mur.report.controller.TimeSelection", {

		radioButtons: null,

		viewModel: new sap.ui.model.json.JSONModel(),

		dateFormatter: sap.ui.core.format.DateFormat.getDateInstance({
			UTC: true
		}),

		onInit: function() {
			this.getView().setModel(this.viewModel);

			var comp = this.getOwnerComponent();

			this.radioButtons = [this.byId("rb-0"), this.byId("rb-1"), this.byId("rb-2"), this.byId("rb-3"), this.byId("rb-4"), this.byId("rb-5")];

			comp.settings.onReady(this.onOpen.bind(this));
		},

		onOpen: function() {

			this.viewModel.setData(this.getOwnerComponent().settings.getData());

			// toggle radio buttons
			// currently not possible using data binding in a nice
			// way...
			this.radioButtons.forEach(function(button) {
				var text = button.getText().toUpperCase();
				var timeInterval = this.viewModel.getProperty("/timeInterval");
				button.setSelected(text === timeInterval);
			}.bind(this));
		},

		onApply: function() {

			var newData = jQuery.extend(true, {}, this.getView().getModel().getData());

			// apply timeInterval
			this.radioButtons.forEach(function(button) {
				if (button.getSelected()) {
					newData.timeInterval = button.getText().replace(" (BETA)","").toUpperCase();
				}
			});

			// parse time selection string

			var n = newData.timeString.lastIndexOf(" - ");
			var fromString = newData.timeString.substring(0, n);
			var toString = newData.timeString.substring(n + 3, newData.timeString.length);

			newData.timeFrom = moment.utc(this.dateFormatter.parse(fromString).getTime());
			newData.timeTo = moment.utc(this.dateFormatter.parse(toString).getTime());

			this.applyAndSetNewTimeSettings(newData);
		},

		applyAndSetNewTimeSettings: function(newData) {
			var comp = this.getOwnerComponent();

			new TimeUtils().snapTime(newData);

			// update propably snapped start end end
			newData.timeString = this.dateFormatter.format(new Date(newData.timeFrom)) + " - " + this.dateFormatter.format(new Date(newData.timeTo));

			// update data, trigger update
			this.getView().getModel().setData(newData);
			comp.settings.setTimeSettings(newData.timeFrom, newData.timeTo, newData.timeString, newData.timeInterval);

			this.getOwnerComponent().getEventBus().publish("time-selection", "change");

			// refresh (might have changed to to auto snap to boundaries
			this.onOpen();
		},

		onCancle: function() {
			this.onOpen();
		},
		
		/* Quick Time Selections */
		onLast30D: function() {
			this.applyAndSetNewTimeSettings({
				timeFrom: moment.utc().subtract(30, 'days'),
				timeTo: moment.utc(),
				timeInterval: "DAY"
			});
		},
		onLast12W: function() {
			this.applyAndSetNewTimeSettings({
				timeFrom: moment.utc().subtract(12, 'weeks'),
				timeTo: moment.utc(),
				timeInterval: "WEEK"
			});
		},
		onLast12M: function() {
			this.applyAndSetNewTimeSettings({
				timeFrom: moment.utc().subtract(12, 'months'),
				timeTo: moment.utc(),
				timeInterval: "MONTH"
			});
		}

	});
});