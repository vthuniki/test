sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("com.sap.globalit.mur.report.controller.AppSelection", {

		selectionChanged: function() {
			jQuery.sap.log.info("onSelectionChanged");

			var component = this.getOwnerComponent();

			var result = [];
			var allApps = component.getModel("appListModel").getProperty("/");
			allApps.forEach(function(app) {
				if (app.selected) {
					result.push(app.id);
				}
			});
			component.settings.setSelectedApps(result);

			component.getEventBus().publish("app-selection", "change");
		},

		liveChange: function(oEvt) {
			// add filter for search
			var aFilters = [];
			var sQuery = oEvt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new sap.ui.model.Filter("displayName",
					sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}

			// update list binding
			var list = this.byId("list");
			var binding = list.getBinding("items");
			binding.filter(aFilters, "Application");
		},

		selectAll: function(event) {
			this.byId("list").selectAll();
			this.selectionChanged();
		},

		selectNone: function(event) {
			this.byId("list").removeSelections(true);
			this.selectionChanged();
		},

		requestAdditionalAccess: function(evt) {
			this.getOwnerComponent().getRouter().navTo("request");
		}

	});
});