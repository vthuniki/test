sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
    "use strict";
    return Controller.extend("com.sap.globalit.mur.report.controller.ReportSelection", {
        onInit: function () {
            this.getView().setHeight("100%");
        },

        onReportSelected: function (event) {

            var path = event.getParameter("listItem").getBindingContextPath("reports");
            var report = this.getOwnerComponent().getModel("reports").getProperty(path);

            // open external link
            if (report.views[0].type === "LINK") {
                var url = report.views[0].url;
                window.open(url, '_blank');
                return;
            }

            var comp = this.getOwnerComponent();

            comp.settings.setReportAndView(report.id, comp.settings.getView());

            comp.getEventBus().publish("report-selection", "change");

/*
            if (app.getCurrentPage().sId === "master") {
                app.toDetail("detail");
            }
  
  */          
            /*
            var detailPage = app.getCurrentDetailPage().getController();
            detailPage.displayReportAndView(report.id, report.views[0].id);
            */
        },

        whatsNewFragment: null,

        openMailSubscriptionDialog: function (view) {
            if (this.whatsNewFragment === null) {
                this.whatsNewFragment = sap.ui
                    .xmlfragment(
                        "com.sap.globalit.mur.report.UpdateSubscription",
                        this);

                // init model

                this.getView().addDependent(this.whatsNewFragment);
            }

            this.whatsNewFragment.setModel(ModelLocator.getMonthlyUpdateSubscriptionModel());

            this.whatsNewFragment.open();

        },

        onDialogCloseButton: function (oEvent) {
            this.whatsNewFragment.close();
        },

        onSubscriptionSwitchChanged: function (event) {
            var path = event.getSource().getParent()
                .getBindingContextPath();
            var model = event.getSource().getModel();

            var elem = model.getProperty(path);

            $
                .ajax({
                    type: "POST",
                    url: Backend.api("reporting/newsletter/updateSubscription"),
                    data: JSON.stringify(elem),
                    contentType: "application/json",
                    error: function (response) {
                        sap.m.MessageToast
                            .show("Error occured: "
                                + response.statusText
                                + " ("
                                + response.status + ")");
                    }
                });

        },

        onRequestNewReport: function () {
            sap.m.URLHelper
                .triggerEmail(
                    "DL_5322C8C6DF15DB06CA003BD9@exchange.sap.corp",
                    "[MUR] Report Request",
                    "We try to improve the framework, we really do ;) But sometimes we need your help. You think that a specific report is missing? Tell us, which data you want to see. Please also explain, why your new report should be added!");
        },

        getGroupHeader: function (context) {
            var sSupplier = context.getProperty("views/0/mode");
            return {
                key: sSupplier,
                text: sSupplier
            };
        }
    });
});