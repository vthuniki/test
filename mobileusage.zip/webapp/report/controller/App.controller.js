sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("com.sap.globalit.mur.report.controller.App", {

		deviceModel: new sap.ui.model.json.JSONModel({
			singleScreen: false
		}),

		onInit: function() {

			var comp = this.getOwnerComponent();

			// determine device settings
			var appView = this.getView().byId("app");
			var currentlyDisplayed = appView.getCurrentPage(false).getViewName();
			if (currentlyDisplayed === "com.sap.globalit.mur.report.view.Settings") {
				this.deviceModel.setProperty("/singleScreen", true);
				this.showDetail();
			}
			comp.setModel(this.deviceModel, "device");

			comp.getEventBus().subscribe("time-selection", "change", this.onSomethingChanged.bind(this));
			comp.getEventBus().subscribe("app-selection", "change", this.onSomethingChanged.bind(this));
			comp.getEventBus().subscribe("report-selection", "change", this.onSomethingChanged.bind(this));

			//this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);

		},

		onRouteMatched: function(oEvent) {
			var sName = oEvent.getParameter("name");
			
			jQuery.sap.log.info("App.controller -> onRouteMatched");
			
			/*
			//Load the detail view in desktop
			this.getRouter().myNavToWithoutHash({
				currentView: this.getView(),
				targetViewName: "sap.ui.demo.tdg.view.Detail",
				targetViewType: "XML"
			});

			//Wait for the list to be loaded once
			this.waitForInitialListLoading(function() {

				//On the empty hash select the first item
				this.selectFirstItem();

			});
			*/

		},

		onSomethingChanged: function() {
			if (this.deviceModel.getProperty("/singleScreen")) {
				this.showDetail();
			}
		},

		showDetail: function() {
			var appView = this.getView().byId("app");
			appView.to(appView.getDetailPages()[0]);
		}
	});
});