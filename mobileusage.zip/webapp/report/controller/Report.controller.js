sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/viz/ui5/controls/VizFrame",
	"sap/viz/ui5/data/FlattenedDataset",
	"sap/viz/ui5/controls/common/feeds/FeedItem",
	"com/sap/globalit/mur/report/TrackingTable"
], function(Controller, VizFrame, FlattenedDataset, FeedItem, TrackingTable) {
	"use strict";
	return Controller.extend("com.sap.globalit.mur.report.controller.Report", {

		pendingRequest: null,

		displayModel: new sap.ui.model.json.JSONModel({
			pageTitle: "Mobile Usage Reporting"
		}),

		reportModel: new sap.ui.model.json.JSONModel({
			title: "Active Devices",
			description: "",
			views: []
		}),

		viewModel: new sap.ui.model.json.JSONModel({
			id: "",
			icon: "sap-icon://line-chart",
			type: "CHART",
			mode: "MULTIPLE",
			url: Backend.api("internal/report/ActiveDevices/ByApp")
		}),

		viewState: new sap.ui.model.json.JSONModel({
			loading: true
		}),

		dataModel: null,

		content: null,

		comp: null,

		/**
		 * Called when a controller is instantiated and its View controls (if
		 * available) are already created. Can be used to modify the View before it
		 * is displayed, to bind event handlers and do other one-time
		 * initialization.
		 *
		 * @memberOf newui.Detail
		 */
		onInit: function() {

			this.comp = this.getOwnerComponent();

			this.getView().setModel(this.displayModel, "displayModel");
			this.comp.setModel(this.viewModel, "viewModel");
			this.comp.setModel(this.reportModel, "reportModel");
			this.getView().setModel(this.viewState, "viewState");
			this.dataModel = new sap.ui.model.json.JSONModel();

			this.comp.getEventBus().subscribe("time-selection", "change", this.onSomethingChanged.bind(this));
			this.comp.getEventBus().subscribe("app-selection", "change", this.onSomethingChanged.bind(this));
			this.comp.getEventBus().subscribe("report-selection", "change", this.onSomethingChanged.bind(this));

			// trigger dispay as soon as settings is available
			this.comp.settings.onReady(this.onSomethingChanged.bind(this));
		},

		toSettings: function() {
			var appView = this.getView().getParent().getParent();
			appView.to(appView.getMasterPages()[0]);
		},
		
		openFAQ: function(){
			window.open("https://trackingshallwe.hana.ondemand.com/documentation/faq", "_blank");
		},

		onSomethingChanged: function() {
			this.displayReportAndView(this.comp.settings.getReport(), this.comp.settings.getView());
		},

		displayReportAndView: function(reportId, viewId) {

			var comp = this.getOwnerComponent();
			
			// add usage event
			sap.git.usage.Reporting.addEvent(comp,"Report View");

			var report = comp.getModel("reports").getReport(reportId);

			this.reportModel.setData(report);
			this.reportModel.updateBindings(true);

			// send event to backend
			// TODO RE-ADD
			//GIT_TRACKING.postEvent("Report/" + report.title);

			// select button on the ui
			var segmentedButton = this.byId("segmentedButton");
			for (var i = 0; i < segmentedButton.getButtons().length; i++) {
				var button = segmentedButton.getButtons()[i];
				if (button.data("viewId") === viewId)
					segmentedButton.setSelectedButton(button);
			}

			// clear current data
			this.dataModel.setData({});

			var view = report.views[0];
			// select view
			report.views.forEach(function(viewObj) {
				if (viewId === viewObj.id) {
					view = viewObj;
				}
			});

			this.viewModel.setData(view);
			this.viewModel.updateBindings(true);

			//comp.settings.setReportAndView(reportId, viewId);

			var page = this.byId("page");
			page.removeAllContent();

			// are apps selected?
			var selectedApps = comp.settings.getSelectedApps();
			if (selectedApps.length === 0) {
				// add error content
				this.displayError("Please select at least one application using the 'Application' tab in the top left corner!");
				return;
			}

			this.content = null;

			if (view.mode === "SINGLE") {
				var selectedApps = comp.settings.getSelectedApps();
				if (selectedApps.length > 1) {
					// TODO handle this case properly
					comp.settings.setSelectedApps([selectedApps[0]]);
				}
				
				// change report title
				var appId = comp.settings.getSelectedApps()[0];
				// resolve app object
				comp.appModelP.then(function(allApps){
					var app = $.grep(allApps, function(o) {
						return o.id === appId;
					})[0];
					if (app) {
						// change title
						this.displayModel.setProperty("/pageTitle", app.displayName + " - " + this.reportModel.getProperty("/title"));
					}
				}.bind(this));
				
			} else {
				// change title
				this.displayModel.setProperty("/pageTitle", this.reportModel
					.getProperty("/title"));
			}

			if (view.type === "CHART" || view.type === "BAR") {
				this.content = this.getChartViewForType(view.type);
				var oVizFrame = this.content;
				this.refresh(function(data) {
					this.applyDatasetBasedOnDataToVizFrame(oVizFrame, data);
				}.bind(this));

				this.content.setModel(this.dataModel);
				page.setEnableScrolling(false);
			} else {
				page.setEnableScrolling(true);

				this.content = new TrackingTable({
					csvDownload: {
						url: Backend.api(this.viewModel.getProperty("/url") + "/csv?" + this.generateURLQuery()),
						data: this.getSelectedApps()
					}
				});

				// append suffix if available
				if (view.valueSuffix !== undefined) {
					this.content.setValueSuffix(view.valueSuffix);
				}

				// set filter if available
				if (view.filter !== undefined) {
					this.content.setFilter(view.filter);
				}

				this.refresh();

				this.content.setModel(this.dataModel);
			}

			page.addContent(this.content);

		},

		applyDatasetBasedOnDataToVizFrame: function(vizFrame, data) {
			var datasetData = {
				dimensions: [],
				measures: [],
				data: {
					path: "/chartData"
				}
			};

			var feedValueData = {
				uid: "valueAxis",
				type: "Measure",
				values: []
			};

			var feedCategoryData = {
				uid: "categoryAxis",
				type: "Dimension",
				values: []
			};

			data.measures.forEach(function(d) {

				// TODO investigate why the backend sends this
				if (!d.key || d.key === "null") {
					return;
				}

				datasetData.measures.push({
					name: d.name,
					value: "{" + d.key + "}"
				});
				feedValueData.values.push(d.name);
			});

			data.dimensions.forEach(function(d) {
				datasetData.dimensions.push({
					name: d.name,
					value: "{" + d.key + "}"
				});
				feedCategoryData.values.push(d.name);

			});
			var flattenedDataset = new sap.viz.ui5.data.FlattenedDataset(datasetData);
			vizFrame.setDataset(flattenedDataset);
			vizFrame.addFeed(new sap.viz.ui5.controls.common.feeds.FeedItem(feedCategoryData));
			vizFrame.addFeed(new sap.viz.ui5.controls.common.feeds.FeedItem(feedValueData));
		},

		getChartViewForType: function(type) {
			var vizType = "line";
			if (type === "BAR") {
				vizType = "bar";
			}

			/* http://veui5infra.dhcp.wdf.sap.corp:8080/demokit/docs/vizdocs/index.html#reference/chartProperty/Charts/Line%20%20(3)/Line%20Chart/ */
			return new sap.viz.ui5.controls.VizFrame({
				width: "100%",
				height: "100%",
				vizType: vizType,
				vizProperties: {
					general: {
						layout: {
							padding: 0.02
						}
					},
					valueAxis: {
						axisTick: {
							visible: true
						},
						axisLine: {
							visible: true
						},
						title: {
							visible: false
						}
					},
					categoryAxis: {
						title: {
							visible: false
						}
					},
					title: {
						visible: false
					},
					plotArea: {
						gridline: {
							size: 1,
							visible: true
						}
					},
					legend: {
						isScrollable: true,
						order: function(a, b) {
							return a.toLowerCase().localeCompare(b.toLowerCase());
						}
					}
				}
			});
		},

		onDataRequestSent: function() {
			jQuery.sap.log.info("onDataRequestSent");
			this.viewState.setProperty("/loading", true);

			this.getView().setBusy(true);
		},

		onDataRequestFinished: function() {
			jQuery.sap.log.info("onDataRequestFinished");
			this.viewState.setProperty("/loading", false);
			this.getView().setBusy(false);
		},

		/**
		 * tabbed button on the ui selected
		 *
		 * @param event
		 */
		onViewButtonSelected: function(event) {
			var id = event.getParameter("id");
			var index = id.charAt(id.length - 1);

			var comp = this.getOwnerComponent();

			var r = comp.getModel("reports").getReport(comp.settings.getReport());

			this.displayReportAndView(r.id, r.views[index].id);
		},

		generateURLQuery: function() {
			var settings = this.getOwnerComponent().settings;

			// convert dst to standard offset -> java expects standard
			// offset!

			var query = "interval=" + settings.getInterval() + "&start=" + settings.getStartDate().valueOf() + "&end=" + settings.getEndDate().valueOf();

			// var appFilter = settings.getSelectedApps();

			// if (appFilter.length > 0)
			// query += "&appfilter=" + appFilter.join("|");

			return query;
		},

		getSelectedApps: function() {
			var settings = this.getOwnerComponent().settings;

			var appFilter = settings.getSelectedApps();

			if (appFilter.length === 0)
				return "";

			return appFilter.join("|");
		},

		refresh: function(callback) {
			jQuery.sap.log.info("Refresh!");

			var url = Backend.api(this.viewModel.getProperty("/url") + "?" + this.generateURLQuery());

			var model = this.dataModel;

			var appFilter = this.getSelectedApps();

			if (this.pendingRequest)
				this.pendingRequest.abort();

			this.pendingRequest = $.ajax({
				url: url,
				type: "POST",
				data: appFilter,
				dataType: "json",
				beforeSend: function() {
					this.onDataRequestSent();
				}.bind(this)
			}).done(function(response) {

				// check the response
				// either, is there table data
				// or, is there chart data
				if (!(response.chartData || response.tableData)  || (response.measures && response.measures.length === 0)) {
					
					var settings = this.getOwnerComponent().settings;
					
					var start = moment(settings.getStartDate()).utc().format("MMM Do YYYY");
					var end = moment(settings.getEndDate()).utc().format("MMM Do YYYY");
					
					this.displayError("No data between " + start + " and " + end + " available");
					return;
				}

				// prevent that some entries are not displayed due to 100 as default limit
				model.setSizeLimit(Number.MAX_VALUE);
				model.setData(response);

				if (callback) {
					callback(response);
				}

			}.bind(this)).fail(function(jqXHR, textStatus, errorThrown) {

				if (textStatus === "abort") {
					return;
				}

				// id service login request? -> session timed out
				if (jqXHR.status === 200 && jqXHR.getResponseHeader("com.sap.cloud.security.login") === "login-request") {
					this.displayError("Your session timed out! Would you mind reloading your browser?");
					return;
				}

				if (jqXHR.status === 503) {
					// Service Unavailable
					this.displayError(
						"The application is currently not available! If the error persists, please contact DL GlobalIT MobileCoE Reporting");
					return;
				}

				this.displayError("Sorry, an Error ocurred! If the error persists, please contact DL GlobalIT MobileCoE Reporting");

			}.bind(this)).always(function() {
				this.onDataRequestFinished();
			}.bind(this));

			// this.dataModel.loadData(url);
		},

		displayError: function(errorText) {
			// add error content
			var page = this.byId("page");
			page.removeAllContent();
			page.addContent(
				new sap.m.FlexBox({
					items: [
						new sap.m.Text({
							text: errorText
						}).addStyleClass("errorText")
					],
					justifyContent: sap.m.FlexJustifyContent.SpaceAround,
					alignItems: sap.m.FlexAlignItems.Center,
					height: "100%"
				})
			);
		},

		whatsNewFragment: null,

		onDialogCloseButton: function(oEvent) {
			this.whatsNewFragment.close();

			if (this.supportsLocalStorage()) {
				localStorage.setItem("MUR_FEATURE_PROMPT", PROJECT_VERSION);
			}

			// force reset of button styling
			this.getView().byId("whatsNewButton").setProperty("type", sap.m.ButtonType.Default);
		},

		showWhatsNew: function(view) {
			if (this.whatsNewFragment === null) {
				this.whatsNewFragment = sap.ui.xmlfragment("com.sap.globalit.mur.WhatsNewFragment", this);
				// init model
				this.getView().addDependent(this.whatsNewFragment);
			}

			this.whatsNewFragment.open();
		},

		supportsLocalStorage: function() {
			return typeof Storage !== "undefined"
		},

		whatsNewFormatter: function(version) {
			if (this.supportsLocalStorage()) {
				var lastDisplayedVersion = localStorage.getItem("MUR_FEATURE_PROMPT");
				if (lastDisplayedVersion === null || lastDisplayedVersion !== PROJECT_VERSION) {
					// new changelog available
					return sap.m.ButtonType.Reject;
				} else {
					// user already knows changes
					return sap.m.ButtonType.Default;
				}
			} else {
				return sap.m.ButtonType.Default;
			}
		}

	});
});