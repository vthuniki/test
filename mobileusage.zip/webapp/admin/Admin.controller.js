sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("com.sap.globalit.mur.admin.Admin", {
		model: ModelLocator.getAuthorizationStatusList(),

		viewState: new sap.ui.model.json.JSONModel({
			generateMail: true
		}),

		onInit: function() {
			this.getView().setModel(this.model);

			this.getView().setModel(this.viewState, "state");

			this.getOwnerComponent().getRouter().attachRoutePatternMatched(this.onRouteMatched, this);
		},

		onRouteMatched: function(oEvent) {
			var sName = oEvent.getParameter("name");

			jQuery.sap.log.info("App.controller -> onRouteMatched " + sName);

			if (sName === "admin-by-user") {
				jQuery.sap.log.info("Filter By User");

				var userId = oEvent.getParameter("arguments").userId;

				this.byId("authTable")
					.getBinding("items")
					.filter(
						[new sap.ui.model.Filter({
							path: "userId",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: userId
						})]);
			}

			if (sName === "admin-by-status") {
				jQuery.sap.log.info("Filter By User");

				var status = oEvent.getParameter("arguments").status;
				
				this.byId("authTable")
					.getBinding("items")
					.filter(
						[new sap.ui.model.Filter({
							path: "status",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: status
						})]);
			}

		},

		onAcceptPressed: function() {
			this.onActionButtonPressed("APPROVED");
		},

		onRejectPressed: function() {
			this.onActionButtonPressed("REJECTED");
		},

		onActionButtonPressed: function(newState) {
			jQuery.sap.log.info("Performing Decission | " + newState);

			var table = this.byId("authTable");

			// get selected items
			var selectedItems = table.getSelectedItems();

			for (var i = 0; i < selectedItems.length; i++) {
				var request = this.model
					.getProperty(selectedItems[i]
						.getBindingContextPath());

				this.modifyItem(request, newState);
			}

			// generate mail -> using timeout because chrome handles
			// this as navigation -> would cancel all requests....
			if (newState === "APPROVED") {
				setTimeout($.proxy(function() {
					this.generateMailIfApplicable(selectedItems);
				}, this), 1000);
			}

			// deselect all items
			selectedItems.forEach(function(item) {
				table.setSelectedItem(item, false);
			});

			this.model.loadData(
				Backend.api("sa-internal/authorization/getAll")
			);
		},

		generateMailIfApplicable: function(selectedItems) {

			var justToOneUser = true;
			var user = null;

			for (var i = 0; i < selectedItems.length; i++) {
				var request = this.model
					.getProperty(selectedItems[i]
						.getBindingContextPath());

				// initialize user if not already done
				if (user === null)
					user = request.userId;

				if (user !== request.userId)
					justToOneUser = false;
			}

			if (justToOneUser && this.viewState.getProperty("/generateMail")) {
				var recipient = user + "@exchange.sap.corp";
				var subject = "Access to GlobalIT Mobile Usage Reporting granted";
				var cc = "DL_5322C8C6DF15DB06CA003BD9@exchange.sap.corp";
				var body = "Dear user, \n\n" +
					"your access request to the GlobalIT Mobile Usage Reporting was approved. You can access the reports using the following link:\n" +
					"https://fiorilaunchpad.sap.com/sites#MU-Reporting \n\n" + 
					"Please keep in mind that the application will only show up in the reports as soon as the first usage has been recorded successfully. \n\n"+
					"Best regards,\n" + 
					"Platform CoE Team";

				sap.m.URLHelper.triggerEmail(recipient, subject,
					body, cc);
			}
		},

		modifyItem: function(item, decission) {
			jQuery.sap.log.info("Item | " + item + " | " + decission);

			var data = {
				type: "SINGLE",
				authId: item.authId,
				status: decission
			};

			// send request to backend
			$.ajax({
				context: this,
				type: "POST",
				url: Backend.api("sa-internal/authorization/decide"),
				data: JSON.stringify(data),
				contentType: "application/json",
				async: false,
				error: function(response) {
					sap.m.MessageToast
						.show("Error occured: " + response.statusText + " (" + response.status + ")");
				},
				success: function() {
					sap.m.MessageToast
						.show("Approve/Reject successful!");
				}
			});
		},

		onSelectionChanged: function(evt) {
			var selectedItems = evt.getSource().getSelectedItems();

			// enable or disable action buttons
			this.byId("buttonApprove").setEnabled(
				selectedItems.length > 0);
			this.byId("buttonReject").setEnabled(
				selectedItems.length > 0);
		},

		stateFormatter: function(value) {
			switch (value) {
				case "PENDING":
					return "sap-icon://pending";
				case "APPROVED":
					return "sap-icon://accept";
				case "REJECTED":
					return "sap-icon://sys-cancel";
				default:
					return "sap-icon://question-mark";
			}
		},

		colorFormatter: function(value) {
			switch (value) {
				case "PENDING":
					return "#33B5E5";
				case "APPROVED":
					return "#669900";
				case "REJECTED":
					return "#CC0000";
				default:
					return "#FFFFFF";
			}
		},

		dateFormatter: function(longValue) {
			return moment(longValue).format("D.MM.YYYY");
		}
	});
});