sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("com.sap.globalit.mur.request.RequestAuthorization", {
		
		whoAmI: $.ajax({
			type: "GET",
			url: Backend.api("internal/authorization/whoami")
		}),

		busyDialog: null,

		suggestionModel: new sap.ui.model.json.JSONModel([]),

		viewState: new sap.ui.model.json.JSONModel({
			forOtherUser: false,
			user: null,
			reason: ""
		}),

		onInit: function() {

			// notice....
			this.byId("userNotice").setContent(
				'<div style="background-color: rgba(255,255,255,0.8);padding: 1rem 0.75rem;"><h1>Important Notice</h1><p>The Mobile Usage Reporting provides insights into the usage of some internal applications. If you are interested in the usage statistics, feel free to request access via the following form.</p><p> It is <u>not required</u> to request access via this page if you only want to use the applications!</p><p></p></div>'
			);
			
			this.getView().setModel(this.suggestionModel, "suggestion");
			this.getView().setModel(this.viewState, "viewState");

			// initialize user
			this._resetToOwnUser();
			
			// listen on view state
			var binding = new sap.ui.model.PropertyBinding(this.viewState, "user");
			binding.getValue = function() {
				return this.getModel().getProperty("/" + this.getPath());
			};
			binding.attachChange(function(evt) {
				var value = evt.getSource().getValue();
				this.userChanged(new sap.ui.base.Event("", "", {
					newValue: value
				}));
			}.bind(this));
		},
		
		_resetToOwnUser: function(){
			this.whoAmI.done(function(respObj) {
				this.viewState.setProperty("/user", respObj.id);
			}.bind(this));
		},

		onCheckboxChange: function(evt) {
			var isSelected = evt.getParameter("selected");
			if (!isSelected) {
				this._resetToOwnUser();
			}
		},

		requestAuthorization: function() {
			
			var requestBody = {
				apps: [],
				reason: null,
				userId: null
			};
			
			// add selected apps
			var selectedItems = this.suggestionModel.getData();
			for (var i = 0; i < selectedItems.length; ++i) {
				var app = selectedItems[i];
				if (app.selected) {
					requestBody.apps.push(app.id);
				}
			}
			if (requestBody.apps.length === 0) {
				sap.m.MessageToast.show("Please select at least one application");
				this.byId("list").setValueState("Error");
				return;
			}
			
			// add reason
			requestBody.reason = this.viewState.getProperty("/reason");
			if (requestBody.reason === "") {
				this.byId("input-reason").setValueState("Error");
				return;
			}
			
			// add user id
			requestBody.userId = this.viewState.getProperty("/user");
			
			// break if no or more than one user
			if (requestBody.userId === "" || requestBody.userId.match(/^([dic]\d+)$/ig) === null) {
				this.byId("input-user").setValueState("Error");
				return;
			}

			this.busyDialog = new sap.m.BusyDialog();
			this.busyDialog.open();

			// send request to backend
			var req = $.ajax({
				type: "POST",
				url: Backend.api("internal/authorization/request"),
				data: JSON.stringify(requestBody),
				contentType: "application/json",
				context: this
			});
			req.fail(this.onRequestFailure);
			req.done(this.onRequestReturned);
		},

		onRequestReturned: function(resp) {
			this.hideDialog();
			this.getOwnerComponent().getRouter().navTo("request-success");
		},

		onRequestFailure: function(response) {
			this.hideDialog();
			sap.m.MessageToast.show("Error occured: " + response.responseJSON + " (RC " + response.status + ")");
		},

		hideDialog: function() {
			this.busyDialog.close();
			this.busyDialog = null;
		},

		liveChange: function(oEvt) {
			// add filter for search
			var aFilters = [];
			var sQuery = oEvt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new sap.ui.model.Filter("displayName",
					sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			// update list binding
			var list = this.byId("list");
			var binding = list.getBinding("items");
			binding.filter(aFilters, "Application");
		},

		userChanged: function(oEvt) {
			jQuery.sap.log.info("userChanged: " + oEvt);
			var newValue = oEvt.getParameter("newValue");
			this.suggestionModel.loadData(Backend.api("internal/authorization/apps/" + newValue));
		}
	});
});