sap.ui.define([
	"sap/m/library-preload",
	"sap/ui/layout/library-preload",
	"sap/viz/library-preload",
	"sap/ui/core/UIComponent",
	"sap/ui/core/theming/Parameters",
	"com/sap/globalit/mur/report/ReportModel",
	"com/sap/globalit/mur/report/TrackingSettings",
	"sap/m/routing/Router"
], function(MLib, UILib, VizLib, UIComponent, Parameters, ReportModel, TrackingSettings, Router) {
	"use strict";
	return UIComponent.extend("com.sap.globalit.mur.Component", {
		metadata: {
			manifest: "json",

			name: "Mobile Usage Reporting",
			version: "1.1.0",
			dependencies: {
				libs: ["sap.ui.core", "sap.m"]
			},
			config: {
				fullWidth: true,
				titleResource: "Mobile Usage Reporting",
				resourceBundle: "i18n/i18n.properties",
				reportingId: "Reporting",
				appName: "mobileusage",
				ignoreComponent: true,
				supportTeam: "fabian.kajzar@sap.com",
				reportingHosts: ["trackingshallwe.hana.ondemand.com", "mobileusage-sapitcloud.dispatcher.hana.ondemand.com",
					"fiorilaunchpad.sap.com"
				]
			},
			includes: [
				"css/style.css",
				"all-reporting.js"
				/*,
				 "../../js/moment.min.js",
				 "../../js/ModelLocator.js"
				 */
			],
			rootView: "com.sap.globalit.mur.MUR",
			routing: {
				config: {
					routerClass: sap.m.routing.Router,
					viewType: "XML",
					clearTarget: true
				},
				routes: [{
					pattern: "",
					name: "main",
					view: "com.sap.globalit.mur.report.view.App",
					targetAggregation: "pages",
					targetControl: "root"
				}, {
					pattern: "request",
					name: "request",
					view: "com.sap.globalit.mur.request.RequestAccess",
					targetAggregation: "pages",
					targetControl: "root",
					subroutes: [{
						pattern: "success",
						name: "request-success",
						view: "com.sap.globalit.mur.request.RequestCreated",
						targetAggregation: "pages"
					}]
				}, {
					pattern: "admin",
					name: "admin",
					view: "com.sap.globalit.mur.admin.Admin",
					targetAggregation: "pages",
					targetControl: "root",
					subroutes: [{
						pattern: "admin/user/{userId}",
						name: "admin-by-user"
					}, {
						pattern: "admin/status/{status}",
						name: "admin-by-status"
					}]
				}]
			}
		},

		appModelP: $.Deferred(),
		settings: null,

		init: function() {
			jQuery.sap.log.setLevel(jQuery.sap.log.Level.INFO);

			this.settings = new TrackingSettings({});
			this.settings.init();

			// call the init function of the parent
			UIComponent.prototype.init.apply(this, arguments);

			this.getRouter().initialize();

			this.setModel(new ReportModel({}), "reports");
			this.setModel(new sap.ui.model.json.JSONModel([]), "appListModel");

			$.ajax({
				url: Backend.api("reporting/master/apps"),
				type: "GET",
				success: this.appModelP.resolve
			});

			this.appModelP.then(function(response) {
				// check if user has access to at least one application
				// if not redirect to app request screen
				if (response.length === 0) {
					this.getRouter().navTo("request");
					return;
				}

				// add selected property
				var settings = this.settings;

				response.forEach(function(entry) {
					entry["selected"] = $.inArray(entry.id, settings.getSelectedApps()) !== -1;
				});

				this.getModel("appListModel").setData(response);
			}.bind(this));

			// init mobile usage reporting
			// @formatter:off
			/* Mobile Usage Reporting */
			/* Version v3 */
			sap.git=sap.git||{},sap.git.usage=sap.git.usage||{},sap.git.usage.Reporting={_lp:null,_load:function(a){this._lp=this._lp||sap.ui.getCore().loadLibrary("sap.git.usage",{url:"https://trackingshallwe.hana.ondemand.com/web-client/v3",async:!0}),this._lp.then(function(){a(sap.git.usage.MobileUsageReporting)},this._loadFailed)},_loadFailed:function(a){jQuery.sap.log.warning("[sap.git.usage.MobileUsageReporting]","Loading failed: "+a)},setup:function(a){this._load(function(b){b.setup(a)})},addEvent:function(a,b){this._load(function(c){c.addEvent(a,b)})},setUser:function(a,b){this._load(function(c){c.setUser(a,b)})}};
			// @formatter:on
			sap.git.usage.Reporting.setup(this);

			// request user id for reporting
			$.ajax({
				url: Backend.api("internal/authorization/whoami"),
				method: "GET",
				dataType: "json",
				context: this /* Component */
			}).then(function(user) {
				var userId = user.id;
				sap.git.usage.Reporting.setUser(this, userId);
			});

			// show FLP dialog if opend on trackingshallwe.hana.ondemand.com
			if (Backend.getParameterByName("origin") === "fromLegacyUI") {
				var oDialogFragment = sap.ui.xmlfragment("com.sap.globalit.mur.report.view.FlpDialog");
				oDialogFragment.setModel(new sap.ui.model.json.JSONModel({
					image: $.sap.getModulePath("com.sap.globalit.mur", "/images/flp-tile.PNG")
				}));
				oDialogFragment.open();
				oDialogFragment.getEndButton().attachPress(function() {
					oDialogFragment.close();
				});
			}

		}
	});
});