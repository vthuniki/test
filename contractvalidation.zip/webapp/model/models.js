sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		createAppConfigData: function () {
			var oAppConfigModel = {
				"revenueType": 0,
				"visibleCanvas": false,
				"editHighlightingButtons": true,
				"results": [],
				"oldValues": {},
				"oldHighlightData": {},
				"currentPageNo": 0,
				"msgStripVisible": false,
				"pageNo": 0,
				"currPageNo": 0,
				"totalPages": 0,
				"fileName": "",
				"documentId": "",
				"newFileName":"",
				"newDocumentId":"",
				"pageBack": false,
				"pageNext": false,
				"AdminAccess": false,
				"possibleValueTextbox": "",
				"possibleValueAddButtonEnable": false,
				"PDFFile": "",
				"protocol": "https://",
				"url": ".wdf.sap.corp/",
				"crmUrl": "sap(bD1lbiZjPTAwMSZkPW1pbiZpPTE=)/crm_logon/default.htm?crm-object-type=",
				"crmUrlCase": "sap/bc/webdynpro/sap/zv_cms_rcm_wda_case?CASE_ID=",
				"crmUrlAction": "&crm-object-action=",
					"crmUrlValue": "&crm-object-value=",
				"crmUrlKeyName": "&crm-object-keyname=",
					"sapRole": "&saprole=ZSM_GENERAL",
						"flpUrlDev": "flpsandbox-br339jmc4c.dispatcher.int.sap.eu2.hana.ondemand.com",
				"flpUrlTest": "fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com",
				"flpUrlProd": "fiorilaunchpad.sap.com",
				"flpHarmony": "/sites?sap-ushell-config=standalone#harmonyquote-Display&",
				"flpArm": "/sites#arm-Create&/createRequest",
				"flpOpp": "/Opportunity/",
				"flpQuote": "/Quotedetails/",
				"crmUrlCaseMode": "&CASE_MODE=D&sap-wd-configid=ZV_CMS_RCM_WAC_CASE&sap-accessibility=&sap-theme=#"

			};
			return oAppConfigModel;
		},
		createUserModel: function () {
			var oModel = new JSONModel("/services/userapi/currentUser");
			return oModel;
		}

	};
});