sap.ui.define([], function () {
	"use strict";

	return {
		
		//Convert the thrushold value from string to float
		//@param(string) thrushold value in string format
		//@return(Float)thrushold value in number format
		numberUnitParse: function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue);
		},
		//row highlighter for lock
		//if not locked - Green
		//if locked by current user -  Yellow
		//if locked by different user - Red
		rowLockHighlight: function (sStatus, sLockedApplication, sCurrentUser, sLockedByUser) {
			var sColor;
			if ((sStatus && sLockedApplication === 'CV') && (sCurrentUser === sLockedByUser)) {
				sColor = "Warning";
			} else if ((sStatus && sLockedApplication === 'CV') && (sCurrentUser !== sLockedByUser)) {
				sColor = "Error";
			} else {
				sColor = "Success";
			}
			return sColor;
		}
	};

});