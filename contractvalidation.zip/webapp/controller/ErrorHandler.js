sap.ui.define([
	"sap/ui/base/Object",
	"sap/m/MessageBox",
], function (UI5Object, MessageBox) {
	"use strict";
	return UI5Object.extend("DCD.contractvalidation.controller.ErrorHandler", {
		constructor: function (oComponent) {
				this._oResourceBundle = oComponent.getModel("i18n").getResourceBundle();
			this._oComponent = oComponent;
			this._oModel = oComponent.getModel();
			this._bMessageOpen = false;
			this._sErrorText = this._oResourceBundle.getText("errorText");
			this._oModel.attachMetadataFailed(function (oEvent) {
				var oParams = oEvent.getParameters();
				this._showServiceError(oParams.response);
			}, this);
			this._oModel.attachRequestFailed(function (oEvent) {
				var oParams = oEvent.getParameters();
				var oLockEntity = oParams.url.indexOf("ZDCD_COCKPIT_CV");
				// An entity that was not found in the service is also throwing a 404 error in oData.
				// We already cover this case with a notFound target so we skip it here.
				// A request that cannot be sent to the server is a technical error that we have to handle though
				if (oParams.response.statusCode !== "404" || (oParams.response.statusCode === 404 && oParams.response.responseText.indexOf(
						"Cannot POST") === 0)) {
				if (oLockEntity !== -1) {
						this._showLockServiceError(oParams.response);
					} else {
						this._showServiceError(oParams.response);
					}
				}
			}, this);
		},
			_showLockServiceError: function (sDetails) {
			var that = this;
			if (this._bMessageOpen) {
				return;
			}
			this._bMessageOpen = true;
			var errorText;
			if (sDetails.responseText) {
				var responseText = JSON.parse(sDetails.responseText);
				errorText = responseText.error.message.value;
			} else {
				errorText = this._sErrorText;
			}
			if (errorText === "Database Table Is Locked By Another User, Please Try After Sometime") {
				this._oComponent.getRouter().getTargets().display("CaseLockedView");
				that._bMessageOpen = false;
			} else if (errorText === "System Failure Occured, Please Try After Sometime" || errorText ===
				"An Unknown Error Occurred, Please Try After Sometime" || errorText === "Document not available.") {
				MessageBox.error(errorText, {
					actions: [MessageBox.Action.CLOSE],
					onClose: function (sAction) {
						that._oComponent.getRouter().navTo("ContractMaster");
						that._bMessageOpen = false;
					}
				});
			} else {
				this._bMessageOpen = false;
				this._showServiceError(sDetails);
				
			}
		},
		_showServiceError: function (sDetails) {
			var that = this;
			if (this._bMessageOpen) {
				return;
			}
			this._bMessageOpen = true;
			var errorText;
			if (sDetails.responseText) {
				var responseText = JSON.parse(sDetails.responseText);
				errorText = responseText.error.message.value;
			} else {
				errorText = this._sErrorText;
			}
			MessageBox.error(
				errorText, {
					id: "serviceErrorMessageBox",
					//details: responseText.error.message.value,
					actions: [MessageBox.Action.CLOSE],
					onClose: function () {
						if(errorText === "No Documents available."){
							that._oComponent.getRouter().navTo("ContractMaster");
						}
						that._bMessageOpen = false;
					}.bind(this)
				}
			);

		}
	});
});