sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("DCD.contractvalidation.controller.BaseController", {
		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},
		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},
		/**
		 * Getter for the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		//getSystem Info 
		_getSystemInfo: function () {
			var that = this;
			this.getOwnerComponent().getModel().callFunction("/GetServer", {
				method: "GET",
				urlParameters: {},
				success: jQuery.proxy(function (oData, response) {
					if (oData.GetServer) {
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/SystemsInfo", oData.GetServer);
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/NavigationEnabled", true);
					}
				}, this),
				error: function (oError) {
					sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},

		//	Case Id Press
		onCaseIdPress: function (oEvent) {
			var oCaseId = oEvent.getSource().getText();
			var prefixSubstitute = "000000000000";
			oCaseId = prefixSubstitute.substr(oCaseId.length) + oCaseId;
			var appConfigmodel = this.getOwnerComponent().getModel("appConfigModel");
			var sHTTPS = appConfigmodel.getProperty("/protocol");
			var sSystemID = appConfigmodel.getProperty("/SystemsInfo").SYSID;
			var url = appConfigmodel.getProperty("/url");
			var crmUrlCase = appConfigmodel.getProperty("/crmUrlCase");
			var crmUrlCaseMode = appConfigmodel.getProperty("/crmUrlCaseMode");

			var sUrl = sHTTPS + sSystemID + url + crmUrlCase + oCaseId + crmUrlCaseMode;
			sap.m.URLHelper.redirect(sUrl, true);
		},

		onQuoteIDPress: function (oEvent) {
			if (oEvent.getSource().getBindingContext() === undefined) {
				var oObject = this.getOwnerComponent().getModel("appConfigModel").getProperty("/quoteData");
			} else {
				var oObject = oEvent.getSource().getBindingContext().getObject();
			}
			this.openQuoteID(oObject);
		},
		openQuoteID: function (oObject) {
			var oRevenueType = oObject.LineOfBusiness;
			var oProcessType = oObject.ProcessType;
			var appConfigModel = this.getOwnerComponent().getModel("appConfigModel");
			var sHTTPS = appConfigModel.getProperty("/protocol");
			var sSystemID = appConfigModel.getProperty("/SystemsInfo").CRMSYS;
			var eSystemID = appConfigModel.getProperty("/SystemsInfo").SYSID;
			var url = appConfigModel.getProperty("/url");
			var crmUrl = appConfigModel.getProperty("/crmUrl");
			var crmUrlAction = appConfigModel.getProperty("/crmUrlAction");
			var crmUrlValue = appConfigModel.getProperty("/crmUrlValue");
			var crmUrlKeyName = appConfigModel.getProperty("/crmUrlKeyName");
			var sapRole = appConfigModel.getProperty("/sapRole");
			var flpUrl;
			if (sSystemID === "ICD" || eSystemID === "ISD") {
				flpUrl = appConfigModel.getProperty("/flpUrlDev");
			} else if (sSystemID === "ICT" || eSystemID === "IST") {
				flpUrl = appConfigModel.getProperty("/flpUrlTest");
			} else if (sSystemID === "ICP" || eSystemID === "ISP") {
				flpUrl = appConfigModel.getProperty("/flpUrlProd");
			}
			var flpHarmony = appConfigModel.getProperty("/flpHarmony");
			var flpOpp = appConfigModel.getProperty("/flpOpp");
			var flpQuote = appConfigModel.getProperty("/flpQuote");
			var sUrl;

			if (oProcessType === "" || oProcessType === null || oProcessType === "W") {
				var oMissingSourceMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("errorTextMissingSource");
				MessageBox.error(oMissingSourceMsg);
				return;
			}

			var oMissingLinkMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("errorTextMissingLink");
			var prefixSubstitute = "000000000000";
			var oQuoteId = oObject.QuoteId;

			if (oRevenueType === "CL") {
				if (oProcessType === "H") {
					sUrl = sHTTPS + sSystemID + url + crmUrl + "BT116_SRVQ" + crmUrlAction + "B" + crmUrlValue +
						oObject.QuoteId + crmUrlKeyName + "OBJECT_ID" + sapRole;
				} else if (oProcessType === "C") {
					oQuoteId = prefixSubstitute.substr(oQuoteId.length) + oQuoteId;
					sUrl = sHTTPS + flpUrl + flpHarmony + flpOpp + oObject.OppId + flpQuote + oQuoteId;
				}
				sap.m.URLHelper.redirect(sUrl, true);
			} else if (oRevenueType === "OP" || oRevenueType === "SE") {
				if (oProcessType === "H") {
					sUrl = sHTTPS + sSystemID + url + crmUrl + "ERPQUOTATION" + crmUrlAction + "B" + crmUrlValue +
						oObject.QuoteId + crmUrlKeyName + "VBELN" + sapRole;
				} else if (oProcessType === "C") {
					oQuoteId = prefixSubstitute.substr(oQuoteId.length) + oQuoteId;
					sUrl = sHTTPS + flpUrl + flpHarmony + flpOpp + oObject.OppId + flpQuote + oQuoteId;
				}
				sap.m.URLHelper.redirect(sUrl, true);
			} else {
				MessageBox.error(oMissingLinkMsg);
				return;
			}
		}

	});

});