sap.ui.define([
	"DCD/contractvalidation/controller/BaseController",
	"sap/ui/core/mvc/Controller",
	"DCD/contractvalidation/model/formatter",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function (BaseController, Controller, formatter, MessageToast, MessageBox) {
	"use strict";

	return BaseController.extend("DCD.contractvalidation.controller.ContractMaster", {
		formatter: formatter,
		onInit: function () {
			var oRouter = this.getRouter();
			oRouter.getRoute("ContractMaster").attachPatternMatched(this.onRoutePatternMatched, this);
		},

		/* Calling PDF.js Library and reading the pdf file
			also setting the PDF file to the model */
		onRoutePatternMatched: function (oEvent) {
			this.getView().byId("LineItemsSmartTable").rebindTable();
			this._getSystemInfo();
		},
		onNavtoClauseDetail: function (oEvent) {
			var caseID = oEvent.getParameters().listItem.getBindingContext().getObject("CaseId"),
				caseGUID = oEvent.getParameters().listItem.getBindingContext().getObject("CaseGuid"),
				quoteId = oEvent.getParameters().listItem.getBindingContext().getObject("QuoteId");
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/quoteData", {
				LineOfBusiness: oEvent.getParameters().listItem.getBindingContext().getObject("LineOfBusiness"),
				ProcessType: oEvent.getParameters().listItem.getBindingContext().getObject("ProcessType"),
				QuoteId: oEvent.getParameters().listItem.getBindingContext().getObject("QuoteId"),
				OppId: oEvent.getParameters().listItem.getBindingContext().getObject("OppId")
			});
			if (quoteId === undefined) {
				quoteId = "";
			}
			this.getOwnerComponent().getRouter().navTo("ClauseDetail", {
				caseId: caseID,
				caseGUID: caseGUID,
				quoteId: quoteId
			});
		},
		onPressArchive: function (oEvent) {
			var oResourceBundle = this.getResourceBundle();
			var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNav.isIntentSupported(["dcdacvarch-Display"])
				.done(function (aResponses) {

				})
				.fail(function () {
					MessageToast(oResourceBundle.getText("navigationErrorMsg"));
				});
			var hash = (oCrossAppNav && oCrossAppNav.hrefForExternal({
				target: {
					shellHash: "dcdacvarch-Display"
				}
			})) || "";
			//Generate a  URL for the second application
			var url = window.location.href.split('#')[0] + hash;
			//Navigate to second app
			sap.m.URLHelper.redirect(url, true);
		}

	});
});