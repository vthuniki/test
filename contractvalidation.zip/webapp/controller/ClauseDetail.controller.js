sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"DCD/contractvalidation/controller/BaseController",
	"sap/ui/core/BusyIndicator",
	"sap/m/PDFViewer",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageStrip",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"DCD/contractvalidation/js/pdfjs/build/pdf.worker",
	"DCD/contractvalidation/model/formatter",
	"DCD/contractvalidation/model/models",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/library"
], function (Controller, BaseController, BusyIndicator, PDFViewer, JSONModel, MessageStrip, MessageBox, MessageToast, PdfWorker,
	formatter, models,
	DateFormat, coreLibrary) {
	"use strict";

	return BaseController.extend("DCD.contractvalidation.controller.ClauseDetail", {
		formatter: formatter,
		models: models,
		onInit: function () {
			var oRouter = this.getRouter();
			oRouter.getRoute("ClauseDetail").attachPatternMatched(this.onRoutePatternMatched, this);
		},
		onRoutePatternMatched: function (oEvent) {
			/*To disable the launchpad back button*/
			if (sap.ushell) {
				sap.ushell.Container.getRenderer("fiori2").hideHeaderItem("backBtn", false);
			}
			this.selectionFlag = true;
			this.getView().byId("clauseDetailSmartTable").setBusy(true);
			this.getView().byId("clauseDetailSmartTable").applyVariant({});
			this.getView().byId("smartFilterBar").clear();

			this.oCaseData = oEvent.getParameter("arguments");
			// this.getView().byId("clauseDetailSmartTable").setBusy(false);
			this.checkDoc(this.oCaseData);
			this._getSystemInfo();

		},

		// Select first row of the table by default
		defaultSelection: function () {
			if (this.selectionFlag) {
				var table = this.getView().byId("clauseTable");
				table.setSelectedItem(table.getItems()[0], true);
				// this.sPath = table.getSelectedContextPaths()[0];
				table.fireSelectionChange({
					listItem: table.getItems()[0],
					selected: true
				});
			}
		},

		onBeforeRebindTable: function (oEvent) {
			var that = this;
			var oBinding = oEvent.getParameter("bindingParams");
			oEvent.getSource().attachEvent("dataReceived", function (oData) {
				that.getView().byId("clauseDetailSmartTable").setBusy(false);
				that.defaultSelection();
			}, this);
			if (this.getModel("documentModel") !== undefined) {
				var oFilter = new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.EQ, this.oCaseData.caseId);
				oBinding.filters.push(oFilter);
				var oFilter1 = new sap.ui.model.Filter("CaseGuid", sap.ui.model.FilterOperator.EQ, this.oCaseData.caseGUID);
				oBinding.filters.push(oFilter1);
			}
			//	oBinding.sorter.push(new sap.ui.model.Sorter("DataField"));
		},
		checkDoc: function (oCaseData) {
			var that = this;
			var oResourceBundle = this.getResourceBundle();
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("CaseGuid", "EQ", oCaseData.caseGUID));
			this.getOwnerComponent().getModel().read("/ZDCD_I_CMSDOCS", {
				filters: aFilter,
				success: function (oData) {
					if (oData.results.length > 0) {
						that.onEnqueue(oCaseData);
						//Begin of Extracting Final and Executed Documents seperately with count
						var oDocument = {
							Final: [],
							Executed: [],
							ExecutedTotal: 0
						};
						oData.results.forEach(function (val) {
							oDocument[val.StatusDescription].push(val);
						});
						oDocument.ExecutedTotal = oDocument.Executed.length;
						var jModel = new sap.ui.model.json.JSONModel(oDocument);
						that.setModel(jModel, "documentModel");
						//End of Extracting Final and Executed Documents seperately with count
						that.getView().byId("clauseDetailSmartTable").rebindTable();
						// that.resetAllData();
						that.pdfjsLib = window["pdfjs-dist/build/pdf"];
						that.pdfjsLib.GlobalWorkerOptions.workerSrc = PdfWorker;
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/caseId", that.oCaseData.caseId);
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/quoteId", that.oCaseData.quoteId);
						var oModel = that.getOwnerComponent().getModel();
						that.setModel(oModel);
						var oCanvas = jQuery.sap.byId("the-canvas1")[0];
						if (oCanvas) {
							var oCanvasContext = oCanvas.getContext("2d");
							oCanvasContext.clearRect(0, 0, oCanvas.width, oCanvas.height);
							oCanvas.style.border = "none";
							that.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleCanvas", false);
						}
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/fileName", that.getModel("documentModel").getProperty(
							"/Executed/0/FileName"));
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/documentId", that.getModel("documentModel").getProperty(
							"/Executed/0/DocumentID"));
						that.byId("rightContainer").setBusy(false);
					} else {
						that.resetAllData();
						MessageBox.error(oResourceBundle.getText("docNotFoundError"), {
							actions: ["Go Back"],
							onClose: function (sAction) {
								that.getRouter().navTo("ContractMaster");
							}
						});
					}

				},
				error: function (oError) {}
			});
		},
		// Lock - Enqueue of CaseId
		onEnqueue: function (oCaseData) {
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("CaseId", "EQ", oCaseData.caseId));
			aFilter.push(new sap.ui.model.Filter("Identifier", "EQ", "E"));
			this.getOwnerComponent().getModel().read("/ZDCD_C_CONT_VAL", {
				filters: aFilter
			});
		},
		// Unlock - Dequeue of CaseId
		onDequeue: function () {
			var that = this;
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("CaseId", "EQ", this.oCaseData.caseId));
			aFilter.push(new sap.ui.model.Filter("Identifier", "EQ", "D"));
			this.getOwnerComponent().getModel().read("/ZDCD_C_CONT_VAL", {
				filters: aFilter,
				success: function (oData) {
					//to do
					that.getRouter().navTo("ContractMaster");
				}
			});
		},
		// Reset app config model
		resetAllData: function () {
			this.getOwnerComponent().getModel("appConfigModel").setData(this.models.createAppConfigData());
			this.newBbox = "";
			this.pageNo = 0;
			this.editFlag = 0;
			if (this.getView().byId("clauseTable")) {
				this.getView().byId("clauseTable").removeSelections();
			}
		},
		onPressMasterBack: function () {
			var that = this;
			var oResourceBundle = this.getResourceBundle();
			if (Object.keys(this.getOwnerComponent().getModel().getPendingChanges()).length === 0) {
				that.onDequeue();
			} else {
				MessageBox.confirm(
					oResourceBundle.getText("discardChanges"), {
						onClose: function (sAction) {
							if (sAction !== "OK") {
								return;
							} else {
								that.getOwnerComponent().getModel().resetChanges();
								that.onDequeue();
							}
						}
					}
				);
			}
		},
		/*
			Scale the coordinates back to the ratio value between 0 to 1
			@param(Array)Array of highlighting coordinates according to the canvas size on UI
			@return(Array)Array of coordinates in the ratio between 0 to 1 to save back to the database
			Called inside saveHighlight() function
		*/
		_deScaleCoordinates: function (oBoundingBox) {
			oBoundingBox[2] = (parseFloat(oBoundingBox[2], 10) + parseFloat(oBoundingBox[0], 10));
			oBoundingBox[3] = (parseFloat(oBoundingBox[3], 10) + parseFloat(oBoundingBox[1], 10));
			oBoundingBox[0] = parseFloat(oBoundingBox[0], 10) / this.renderedPageWidth;
			oBoundingBox[1] = parseFloat(oBoundingBox[1], 10) / this.renderedPageHeight;
			oBoundingBox[2] = oBoundingBox[2] / this.renderedPageWidth;
			oBoundingBox[3] = oBoundingBox[3] / this.renderedPageHeight;
			return oBoundingBox;
		},
		/*
			Convert the page number into 3 digit string
			@param(Number)Page number of type number
			@return(String)A 3 character string for the page number
			Called inside saveHighlight() function
		*/
		paddingInteger: function (pageNo) {
			var sPageNo = String(pageNo);
			while (sPageNo.length < 3) {
				sPageNo = "0" + sPageNo;
			}
			return sPageNo;
		},
		/*
			Scale the coordinates according the convas size
			@param(Array)An array of highlighting coordinates
			@return(Array) Array of scaled coordinates
			Called inside fnRenderPage() function
			*/
		_scaleCoordinates: function (oBoundingBox) {
			oBoundingBox[0] = oBoundingBox[0] * this.renderedPageWidth;
			oBoundingBox[1] = oBoundingBox[1] * this.renderedPageHeight;
			oBoundingBox[2] = (oBoundingBox[2] * this.renderedPageWidth) - oBoundingBox[0];
			oBoundingBox[3] = (oBoundingBox[3] * this.renderedPageHeight) - oBoundingBox[1];
			return oBoundingBox;
		},

		/* Rendering the requested page from the file
			and displaying it in canvas
			INPUT - PageNumber and BoundingBox
			OUTPUT - Display the pdf page with highlighted section */
		fnRenderPage: function (iPageNo, oBBox) {
			var that = this;
			var initPageNo = iPageNo;
			// var scale;
			var iScale = this.scale;
			var oCanvas = jQuery.sap.byId("the-canvas1")[0];
			var oCanvasContext = oCanvas.getContext("2d");
			var oResourceBundle = this.getResourceBundle();
			var sPdf = this.getOwnerComponent().getModel("pdfmodel").getProperty("/processedDoc");
			var iTotalPages = sPdf.numPages;
			if (iPageNo > iTotalPages) {
				iPageNo = 0;
				MessageBox.information(oResourceBundle.getText("pageNumPDFerror"));
			}
			that.pageNo = iPageNo;
			if (isNaN(iPageNo) || iPageNo === 0) {
				that.pageNo = 1;
				iPageNo = 1;
				oBBox = "";
				that.newBbox = "";
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/msgStripVisible", true);
				that.editFlag = 1;
			} else {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/msgStripVisible", false);
			}
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNo", iPageNo);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/currPageNo", iPageNo);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalPages", iTotalPages);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageBack", (iPageNo === 1) ? false : true);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNext", (iPageNo === iTotalPages) ? false : true);
			// $(oCanvas).off("mousedown");
			sPdf.getPage(that.pageNo).then(function (oPage) {
				var viewport = oPage.getViewport(iScale);
				oCanvas.height = viewport.height;
				oCanvas.width = viewport.width;
				that.renderedPageHeight = oCanvas.height;
				that.renderedPageWidth = oCanvas.width;
				var oRenderContext = {
					canvasContext: oCanvasContext,
					viewport: viewport
				};
				that.renderCanvas = oPage.render(oRenderContext);
				that.renderCanvas.then(function () {
					oCanvas.style.border = "1px solid black";
					if (oBBox) {
						var oBoundingBox = oBBox.split(",");
						oCanvasContext.beginPath();
						oBoundingBox = that._scaleCoordinates(oBoundingBox);
						oCanvasContext.rect(oBoundingBox[0], oBoundingBox[1], oBoundingBox[2], oBoundingBox[3]);
						oCanvasContext.fillStyle = "rgba(236,245,114,0.6)";
						oCanvasContext.fill();
					}
					that.getView().byId("clauseDetailSmartTable").setBusy(false);
				}).catch(function (oError) {
					MessageBox.warning(oResourceBundle.getText("pageRenderError"), {
						onClose: function (sAction) {
							that.fnRenderPage(initPageNo, oBBox);
						}
					});
					that.getView().byId("clauseDetailSmartTable").setBusy(false);
				});
			}).catch(function () {
				MessageBox.error(oResourceBundle.getText("pageNotFoundError"));
				that.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleCanvas", false);
				that.getView().byId("clauseDetailSmartTable").setBusy(false);
			});
		},
		/* Dynamically Gererate MessageStrip
			Called internally from onPressRow function*/
		_generateMsgStrip: function () {
			var oVC = this.getView().byId("msgStrip"),
				oMsgStrip = new MessageStrip("msgStrip", {
					text: this.getResourceBundle().getText("noHighlightErrorMsg"),
					showCloseButton: false,
					showIcon: true,
					type: "Warning"
				});
			oVC.addItem(oMsgStrip);
		},

		/*
			Internal function called to load the specific pdf page(called inside onPressRow() function)
			@param(source of the data field table)
			@param(binding context of the pressed row)
		*/
		_loadPdfPage: function (source, pressedRowObject) {
			var oResourceBundle = this.getResourceBundle();
			var that = this;
			this.currentItem = source.getSelectedItem();
			var sBase64pdf1;
			if (this.getModel("documentModel")) {
				this.selectionFlag = false;
				var aDocuments = this.getModel("documentModel").getProperty("/Executed");
				for (var i = 0; i < aDocuments.length; i++) {
					var oVal = aDocuments[i];
					if (oVal.DocumentID === pressedRowObject.DocumentId) {
						if (oVal.Data !== "") {
							sBase64pdf1 = atob(oVal.Data);
							break;
						} else {
							// MessageBox.error(oVal.Message);
							// return;
						}
					}
				}
				var iPageNo = parseInt(pressedRowObject.PageNo.substring(8), 10);
				var oBBox = pressedRowObject.HighlightedCoordinates.substring(7, (pressedRowObject.HighlightedCoordinates.length - 1)).split(", ")
					.join(
						",");

				// if (!(this.getOwnerComponent().getModel("appConfigModel").getProperty("/oldHighlightData")[this.currentRow.substr(1)])) {
				// 	this.getOwnerComponent().getModel("appConfigModel").setProperty("/oldHighlightData" + this.currentRow, {
				// 		pageNo: iPageNo,
				// 		bBox: oBBox,
				// 		docName: pressedRowObject.DocumentUsed,
				// 		docId: pressedRowObject.DocumentId,
				// 		valid: sBase64pdf1 === undefined ? false : true

				// 	});
				// }
				pressedRowObject.HighlightedCoordinates = oBBox;
				pressedRowObject.PageNo = iPageNo;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleCanvas", true);
				source.getBusy(true);

				if (sBase64pdf1 === undefined) {
					if (this.getView().getModel("documentModel").getProperty("/Executed").length === 0) {
						MessageBox.error(oResourceBundle.getText("noExecutedDoc"));
						this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleCanvas", false);
						source.getBusy(false);
					} else {
						MessageBox.error(oResourceBundle.getText("noPdfError"));
						oVal = this.getModel("documentModel").getProperty(
							"/Executed")[0];
						sBase64pdf1 = atob(oVal.Data);
						pressedRowObject.HighlightedCoordinates = "";
						pressedRowObject.PageNo = 0;
					}
				}
				that.getOwnerComponent().getModel("appConfigModel").setProperty("/fileName", oVal.FileName);
				that.getOwnerComponent().getModel("appConfigModel").setProperty("/documentId", oVal.DocumentID);
				that.pdfjsLib.getDocument({
					"data": sBase64pdf1
				}).then(function (sPdf) {
					var sProcessedDoc = sPdf;
					BusyIndicator.hide();
					that.getOwnerComponent().getModel("pdfmodel").setData({
						pdffile: sBase64pdf1,
						processedDoc: sProcessedDoc
					});
					that.fnRenderPage(pressedRowObject.PageNo, pressedRowObject.HighlightedCoordinates);
					// that.appendthumb(pressedRowObject.PageNo === 0 ? 1 : pressedRowObject.PageNo);
				});
			}
		},
		/* Called when table row is clicked
				Fetch page number and BoundingBox from table row
				and pass to fnRenderPage function to display the page*/
		onPressRow: function (oEvent) {
			this.scale = 3;
			var source = oEvent.getSource();
			// var oResourceBundle = this.getResourceBundle();
			var pressedRow = oEvent.getParameter("listItem").getBindingContext();
			this.rowPath = pressedRow.getPath();
			var pressedRowObject = pressedRow.getObject();
			// if (pressedRowObject.ApprovalStatus === "02") {
			// 	this.getOwnerComponent().getModel("appConfigModel").setProperty("/editHighlightingButtons", false);
			// } else {
			// 	this.getOwnerComponent().getModel("appConfigModel").setProperty("/editHighlightingButtons", true);
			// }
			var that = this;
			this.currentRow = pressedRow.getPath();

			// this.sPath = pressedRow.getPath();
			that._loadPdfPage(source, pressedRowObject);
		},
		onCopyDetails: function (oEvent) {
			var oSmartTable = this.getView().byId("clauseDetailSmartTable");
			var allItems = oSmartTable.getTable().getItems();
			var aTableData = [];
			for (var i = 0; i < allItems.length; i++) {
				var oItem = oSmartTable.getTable().getItems()[i].getBindingContext().getObject();
				var oValues = {
					dataField: "",
					predictedValue: "",
					quoteValue: ""
				};
				if (oItem.ApprovalStatus === '03') {
					oValues.dataField = oItem.DataFieldDesc;
					oValues.predictedValue = oItem.PredictedValue;
					oValues.quoteValue = oItem.quoteValue;
					aTableData.push(oValues);
				}
			}
			var oTableData = {
				oData: aTableData
			};
			var oTableModel = new JSONModel(oTableData);
			if (!this.oCopyDetailsFragment) {
				this.oCopyDetailsFragment = sap.ui.xmlfragment("DCD.contractvalidation.fragment.CopyDetails", this);
				this.getView().addDependent(this.oCopyDetailsFragment);
			}
			this.getOwnerComponent().setModel(oTableModel, "unApprovedData");
			// this.oCopyDetailsFragment.setModel(oTableModel);
			this.oCopyDetailsFragment.open();
			// var sData = JSON.stringify(aTableData);
		},
		onCloseCopyFragment: function (oEvent) {
			this.oCopyDetailsFragment.close();
		},

		onCopyDetailsFinal: function (oEvent) {
			// var sDetails = JSON.stringify(this.getOwnerComponent().getModel("unApprovedData").getData().oData);
			var sDetails = "";
			var oVal = this.getOwnerComponent().getModel("unApprovedData").getData().oData;
			for (var i = 0; i < oVal.length; i++) {
				sDetails = sDetails + "Data Field = " + oVal[i].dataField + ", " + "Predicted Value = " + oVal[i].predictedValue + ", " +
					"Quote Value = " + oVal[i].quoteValue + "\n";
			}
			const cb = navigator.clipboard;
			var that = this;
			var oResourceBundle = this.getResourceBundle();
			cb.writeText(sDetails).then(function () {
				MessageToast.show(oResourceBundle.getText("copyToClipboardText"));
				that.oCopyDetailsFragment.close();

			});
		},
		/* Reset te changes made in the table on click on RESET button */
		onResetPage: function () {
			this.getOwnerComponent().getModel().resetChanges();
		},
		/* Save te changes made in the table on click on SAVE button */
		onSubmitPage: function () {
			var filters = [];
			filters.push(new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.EQ, this.oCaseData.caseId));
			filters.push(new sap.ui.model.Filter("CaseGuid", sap.ui.model.FilterOperator.EQ, this.oCaseData.caseGUID));
			var oResourceBundle = this.getResourceBundle();
			// var oController = this;
			// for (var sKey in this.getOwnerComponent().getModel().getPendingChanges()) {
			// 	if (this.getOwnerComponent().getModel().getPendingChanges()[sKey].ApprovalStatus === "true") {
			// 		this.getOwnerComponent().getModel().setProperty("/" + sKey + "/ConfidenceLevel", "1.0");
			// 		this.getOwnerComponent().getModel().setProperty("/" + sKey + "/ApprovalStatus", "02");
			// 	}
			// }
			this.getOwnerComponent().getModel().submitChanges({
				success: function (oArg) {
					MessageToast.show(oResourceBundle.getText("saveChangesSuccessMsg"));
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/oldHighlightData", {});
					var that = this;
					that.getOwnerComponent().getModel().read("/ZDCD_I_CONTVAL/$count", {
						filters: filters,
						success: function (oData, response) {
							if (response.body === "0") {
								that.onDequeue();
							}
						}

					});
				}.bind(this)
			});
		},
		onChangeApprovalStatus: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext().getPath();
			this.getOwnerComponent().getModel().setProperty(sPath + "/ApprovalStatus", (oEvent.getSource().getState()) ? "02" : "03");
		},

		changePage: function (iPageNo) {
			var iTotalPages = this.getOwnerComponent().getModel("pdfmodel").getProperty("/processedDoc").numPages;
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNo", iPageNo);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/currPageNo", iPageNo);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageBack", (iPageNo === 1) ? false : true);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNext", (iPageNo === iTotalPages) ? false : true);
			var currentHighlight = this.getOwnerComponent().getModel().getData(this.currentRow);
			var iCurrPage = parseInt(currentHighlight.PageNo.substring(8), 10);
			var sCurrCoordinates = currentHighlight.HighlightedCoordinates.substring(7, (currentHighlight.HighlightedCoordinates.length - 1)).split(
				", ").join(
				",");
			if (iCurrPage === iPageNo) {
				this.fnRenderPage(iCurrPage, sCurrCoordinates);
			} else {
				this.fnRenderPage(iPageNo);
			}
		},
		// Load the previous page of te PDF
		onPageBack: function (oEvent) {
			var iPageNo = parseInt(this.getOwnerComponent().getModel("appConfigModel").getProperty("/pageNo"), 10) - 1;
			this.changePage(iPageNo);
		},
		// Load the Next page of te PDF
		onPageNext: function (oEvent) {
			var iPageNo = parseInt(this.getOwnerComponent().getModel("appConfigModel").getProperty("/pageNo"), 10) + 1;
			this.changePage(iPageNo);
		},
		/*
			Called when user enter a specific page number and press enter
			Render the PDF page requested by user
			@param(Source of the input field for page number)
		*/
		onChangePageNumber: function (oEvent) {
			var iPageNo = parseInt(this.getOwnerComponent().getModel("appConfigModel").getProperty("/pageNo"), 10);
			var iTotalPages = this.getOwnerComponent().getModel("pdfmodel").getProperty("/processedDoc").numPages;
			var iCurrPageNo = this.getOwnerComponent().getModel("appConfigModel").getProperty("/currPageNo");
			if (iPageNo > iTotalPages || iPageNo < 1) {
				MessageBox.error(this.getResourceBundle().getText("wrongPageNumberErr"));
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNo", iCurrPageNo);
			} else {
				var currentHighlight = this.getOwnerComponent().getModel().getData(this.currentRow);
				var iCurrPage = parseInt(currentHighlight.PageNo.substring(8), 10);
				var sCurrCoordinates = currentHighlight.HighlightedCoordinates.substring(7, (currentHighlight.HighlightedCoordinates.length - 1)).split(
					", ").join(
					",");
				if (iCurrPage === iPageNo) {
					this.fnRenderPage(iCurrPage, sCurrCoordinates);
				} else {
					this.fnRenderPage(iPageNo);
				}
			}
		}

	});

});