sap.ui.define([
	"DCD/contractvalidation/controller/BaseController",
], function (BaseController) {
	"use strict";

	return BaseController.extend("DCD.contractvalidation.controller.CaseLockedView", {
		onInit: function () {
		},
		onLinkPressed: function () {
			this.getRouter().navTo("ContractMaster");
		}
	});

});