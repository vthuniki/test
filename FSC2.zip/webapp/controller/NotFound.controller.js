sap.ui.define([
	'sap/support/fsc2/controller/BaseController',
], function (BaseController) {
   "use strict";
   return BaseController.extend("sap.support.fsc2.controller.NotFound", {
      onInit: function () {
      }
   });
});