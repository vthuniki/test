sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function(Controller, JSONModel, MessageToast) {
	"use strict";
	return Controller.extend("sap.support.boostm.controller.Main", {
		_oStaffingModel: {},
		nDay: {},
		nMonth: {},
		nYear: {},
		nDayInWeek: {},
		selectedRegion: {},
		BACKND_SYS_ICP: "ICP",
		BACKND_SYS_ICT: "ICT",
		BACKND_SYS_ICD: "ICD",
		BMSTFF_ASSIGNMENTS: "BM Staffing Assignments",

		onInit: function() {
			this._oStaffingModel = this.getOwnerComponent().getModel();
			this._setDateModel();
			this._setRegionModel();
			this._getDateData();
			this._getRegionData();
			this.onSearchData();
		},

		getFilter: function(nDayInWeek, nYear, nMonth, nDay, selectedRegion) {
			var aFiltersVbox = [];
			var oFiltersVboxDate,
				oFiltersVboxRegion,
		     	oFiltersVboxTeam1,
				oFiltersVboxTeam2,
				oFiltersVboxTeam3,
				oFiltersVboxTeam4 = null; 

			var FilterOperator = sap.ui.model.FilterOperator;

			var datetime = nYear + "-" + nMonth + "-" + nDay + "T12:00:00";
			oFiltersVboxDate = new sap.ui.model.Filter("Date", FilterOperator.EQ, datetime);
			oFiltersVboxRegion = new sap.ui.model.Filter("Region", FilterOperator.EQ, selectedRegion);

			switch (selectedRegion) {
				
				case "EMEA BACKOFFICE":
					if (nDayInWeek === 0 || nDayInWeek === 6) {
						/*oFiltersVboxTeam1 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Control Center");
						oFiltersVboxTeam2 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "CIM");
						aFiltersVbox.push(oFiltersVboxTeam1);
						aFiltersVbox.push(oFiltersVboxTeam2);*/
					} else {
						oFiltersVboxTeam1 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Control Center");
						oFiltersVboxTeam2 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Team Lead Ireland");
						oFiltersVboxTeam3 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Team Lead");
						oFiltersVboxTeam4 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Team 2 Ireland Lead");
						aFiltersVbox.push(oFiltersVboxTeam1);
						aFiltersVbox.push(oFiltersVboxTeam2);
						aFiltersVbox.push(oFiltersVboxTeam3);
						aFiltersVbox.push(oFiltersVboxTeam4);
					}
					break;

				case "APJ GCN BACKOFFICE":
					if (nDayInWeek === 0 || nDayInWeek === 6) {
					/*	oFiltersVboxTeam1 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Control Center");
						aFiltersVbox.push(oFiltersVboxTeam1);*/
					} else {
						oFiltersVboxTeam1 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Control Center");
						oFiltersVboxTeam2 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Team Lead ECS Extended");
						aFiltersVbox.push(oFiltersVboxTeam1);
						aFiltersVbox.push(oFiltersVboxTeam2);
					}
					break;

			 case "LAC BACKOFFICE":
					//Some problem with weekend
			/*		if (nDayInWeek === 0 || nDayInWeek === 6) {
						oFiltersVboxTeam1 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Team Lead MX");
						oFiltersVboxTeam2 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Control Center LA");
						aFiltersVbox.push(oFiltersVboxTeam1);
						aFiltersVbox.push(oFiltersVboxTeam2);
					} else {
						oFiltersVboxTeam1 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Team Lead MX");
						oFiltersVboxTeam2 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Control Center LA");
						oFiltersVboxTeam3 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Team Lead OMF");
						aFiltersVbox.push(oFiltersVboxTeam1);
						aFiltersVbox.push(oFiltersVboxTeam2);
						aFiltersVbox.push(oFiltersVboxTeam3);
					} */
						oFiltersVboxTeam1 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Control Center");
						aFiltersVbox.push(oFiltersVboxTeam1);
					break; 
				case "NA BACKOFFICE":
					if (nDayInWeek === 0 || nDayInWeek === 6) {
					/*	oFiltersVboxTeam1 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Control Center");
						aFiltersVbox.push(oFiltersVboxTeam1);*/
					} else {
						oFiltersVboxTeam1 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Control Center");
						oFiltersVboxTeam2 = new sap.ui.model.Filter("Team_Id", FilterOperator.EQ, "Back Office Team 2");
						aFiltersVbox.push(oFiltersVboxTeam1);
						aFiltersVbox.push(oFiltersVboxTeam2);
					}
					break;
			} 

			aFiltersVbox.push(oFiltersVboxDate);
			aFiltersVbox.push(oFiltersVboxRegion);
			return aFiltersVbox;
		},

		formatDate: function(dateValue) {
			var day = dateValue.getDate();
			var month = dateValue.getMonth() + 1;
			var year = dateValue.getFullYear();
			var dayinweek = dateValue.getDay();

			if (day <= 9) {
				day = "0" + day;
			}

			if (month <= 9) {
				month = "0" + month;
			}

			return [dayinweek, year, month, day];
		},

	/*	onSearchData: function() {
			var ofilters = this.getFilter(this.nDayInWeek, this.nYear, this.nMonth, this.nDay, this.selectedRegion);
			var that = this;
			this._oStaffingModel.read("/Staffing", {
				filters: ofilters,
				success: function(oData) {
					for (var i in oData.results) {
						// Set header text
						oData.results[i].headerText = {};
						if (oData.results[i].empId === "") {
							oData.results[i].headerText = oData.results[i].Role + " " + "Slot Empty";
						} else {
							oData.results[i].headerText = oData.results[i].Role + " " + oData.results[i].First_Name + " " + oData.results[i].Last_Name;
						}
						// Set item visible
						oData.results[i].visible = {};
						switch (oData.results[i].Region) {
							case "EMEA BACKOFFICE":
								if (oData.results[i].Role === "Backoffice Head IRE:") {
									oData.results[i].visible = false;
								} else {
									oData.results[i].visible = true;
								}
								break;
							case "APJ GCN BACKOFFICE":
								if (oData.results[i].Role === "HEC TLO") {
									oData.results[i].visible = false;
								} else {
									oData.results[i].visible = true;
								}
								break;
							case "LAC BACKOFFICE":
								if (oData.results[i].Role !== "Backoffice Head LA:" && oData.results[i].Role !== "Team 1 Lead MX:" && oData.results[i].Role !==
									"Team 1 Lead BR:" && oData.results[i].Role !== "Team 2 Lead BR:" && oData.results[i].Role !== "Head of Backoffice" && oData.results[i].Role !== "BD/PE  Lead BR" 
									&& oData.results[i].Role !== "xTec Lead" && oData.results[i].Role !== "BD/PE Lead MX" && oData.results[i].Role !== "Q&D Member 4pm – 9pm (CET)" && oData.results[i].Role !== "Q&D Member 9pm – 1am (CET)"
									&& oData.results[i].Role !== "Admin" && oData.results[i].Role !== "Q&D Member 1" && oData.results[i].Role !== "Q&D Member 2" ) {
									oData.results[i].visible = false;
								} else {
									oData.results[i].visible = true;
								}
								break;
							case "NA BACKOFFICE":
							//	if (oData.results[i].Role !== "BO Head:" && oData.results[i].Role !== "Duty Manager:" && oData.results[i].Role !==
							//		"Team Lead 1:" && oData.results[i].Role !== "Team Lead Midshift:" && oData.results[i].Role !==
							//		"Team 1 Lead IRE:" && oData.results[i].Role !== "Team 2 Lead:" && oData.results[i].Role !== "RCA Lead Weekend US:" && oData.results[
							//			i].Role !== "RCA Lead Weekend IRE:") {
								if (oData.results[i].Role !== "Regional Head" && oData.results[i].Role !== "Duty Manager" && oData.results[i].Role !== "Team Lead (US)"
									&& oData.results[i].Role !== "Team Co-Lead (US)" && oData.results[i].Role !== "Team 2 Lead (US)" && oData.results[i].Role !== "Team Lead (US late shift)" 
									&& oData.results[i].Role !== "Hub Lead (IRE)" && oData.results[i].Role !== "Team Lead (IRE)" && oData.results[i].Role !== "RCA Lead Weekend (US)" 
									&& oData.results[i].Role !== "RCA Lead Weekend (IRE)" && oData.results[i].Role !== "Regional Head:" && oData.results[i].Role !== "Duty Manager:" && oData.results[i].Role !== "Team Lead (US)"
									&& oData.results[i].Role !== "Team Co-Lead (US):" && oData.results[i].Role !== "Team 2 Lead (US):" && oData.results[i].Role !== "Team Lead (US late shift):" 
									&& oData.results[i].Role !== "Hub Lead (IRE):" && oData.results[i].Role !== "Team Lead (IRE):" && oData.results[i].Role !== "RCA Lead Weekend (US):" 
									&& oData.results[i].Role !== "RCA Lead Weekend (IRE):" && oData.results[i].Role !== "Head of Backoffice" && oData.results[i].Role !== "Business Down Lead" 
									&& oData.results[i].Role !== "Business Down Lead Mid" && oData.results[i].Role !== "Business Down Lead IRE" && oData.results[i].Role !== "x-Tec Lead" 
									&& oData.results[i].Role !== "Q&D Lead / MCC SWAT Lead" && oData.results[i].Role !== "Q&D DEA" && oData.results[i].Role !== "IOC SWAT Comms" && oData.results[i].Role !== "IOC SWAT Comms Mid"
								) {
									oData.results[i].visible = false;
								} else {
									oData.results[i].visible = true;
								}
								break;
						}

					}
						// Staffing Data filtered
					var odata1 = oData.results.filter(function (item) {
						return (item.Assignmentstartdate !== null &&
							that.formatDate(item.Assignmentstartdate)[1] + that.formatDate(item.Assignmentstartdate)[2] + that.formatDate(item.Assignmentstartdate)[
								3] <=
							that.formatDate(item.Date)[1] + that.formatDate(item.Date)[2] + that.formatDate(item.Date)[3] &&
							that.formatDate(item.Assignmentenddate)[1] + that.formatDate(item.Assignmentenddate)[2] + that.formatDate(item.Assignmentenddate)[
								3] >=
							that.formatDate(item.Date)[1] + that.formatDate(item.Date)[2] + that.formatDate(item.Date)[3]);

					});
					var odata2 = oData.results.filter(function (item) {
						return (item.Assignmentstartdate === null);
					});
					oData.results = jQuery.merge(odata1, odata2);
					
					var oStaffingModel = new JSONModel();
					oStaffingModel.setData(oData);
					that.getView().setModel(oStaffingModel, "StaffingData");
				},
				error: function() {

				}
			});
		},*/
		
		// Getting staffing data and CCT data from all regions
		onSearchData: function() {
			var ofilters = this.getFilter(this.nDayInWeek, this.nYear, this.nMonth, this.nDay, this.selectedRegion);
            
            var oEMEACCTFilterOperator = sap.ui.model.FilterOperator;
            var aFilterEMEACCT = [];
			var datetime = this.nYear + "-" + this.nMonth + "-" + this.nDay + "T12:00:00";
			var oEMEACCTDate = new sap.ui.model.Filter("Date", oEMEACCTFilterOperator.EQ, datetime);
			if(this.selectedRegion === "EMEA BACKOFFICE"){
			    var oEMEACCTRegion = new sap.ui.model.Filter("Region", oEMEACCTFilterOperator.EQ, "EMEA CCT");
			//  var oEMEACCTTeam = new sap.ui.model.Filter("Team_Id",oEMEACCTFilterOperator.EQ,"Control Center MCC EMEA");
		    }
		    else if(this.selectedRegion === "APJ GCN BACKOFFICE"){
		    	var oEMEACCTRegion = new sap.ui.model.Filter("Region", oEMEACCTFilterOperator.EQ, "APJ GCN CCT");
			//  var oEMEACCTTeam = new sap.ui.model.Filter("Team_Id",oEMEACCTFilterOperator.EQ,"Control Center MCC APJ/GCN");
		    }
		    else if(this.selectedRegion === "NA BACKOFFICE"){
		    	var oEMEACCTRegion = new sap.ui.model.Filter("Region", oEMEACCTFilterOperator.EQ, "NA CCT");
			//  var oEMEACCTTeam = new sap.ui.model.Filter("Team_Id",oEMEACCTFilterOperator.EQ,"Control Center MCC NA");
		    }
		    else if(this.selectedRegion === "LAC BACKOFFICE"){
		    	var oEMEACCTRegion = new sap.ui.model.Filter("Region", oEMEACCTFilterOperator.EQ, "LAC CCT");
			//  var oEMEACCTTeam = new sap.ui.model.Filter("Team_Id",oEMEACCTFilterOperator.EQ,"Control Center MCC LAC");
		    }
			aFilterEMEACCT.push(oEMEACCTDate);
			aFilterEMEACCT.push(oEMEACCTRegion);
		//	aFilterEMEACCT.push(oEMEACCTTeam);
           
			this._oStaffingModel.read("/Staffing",{
			filters: aFilterEMEACCT,
			success: function(oData){
				this.oEMEACCTdataFilter = oData.results.filter(function(item){
					return(item.DisplayOnBm === "X");
				});

				this._oStaffingModel.read("/Staffing", {
				filters: ofilters,
				success: function(oData) {
				var that = this;
				var oEMEACCTdataFiltred = that.oEMEACCTdataFilter;
			//	if(that.selectedRegion === "EMEA BACKOFFICE"){
					jQuery.merge(oData.results,oEMEACCTdataFiltred);
		    //	}
		    	oData.results = oData.results.filter(function(item){return(item.DisplayOnBm === "X");});
		    
		    // Filtered data based on date filelds.	
		    /*	oData.results = oData.results.filter(function (item) {
				return (item.Assignmentstartdate !== null &&
					Number(that.formatDate(item.Assignmentstartdate)[1]+that.formatDate(item.Assignmentstartdate)[2]+that.formatDate(item.Assignmentstartdate)[3]) <= Number(that.formatDate(item.Date)[1]+that.formatDate(item.Date)[2]+that.formatDate(item.Date)[3]) &&
					Number(that.formatDate(item.Assignmentenddate)[1]+that.formatDate(item.Assignmentenddate)[2]+that.formatDate(item.Assignmentenddate)[3]) >= Number(that.formatDate(item.Date)[1]+that.formatDate(item.Date)[2]+that.formatDate(item.Date)[3])
				);
			});*/
					for (var i in oData.results) {
						// Set header text
						oData.results[i].headerText = {};
						if (oData.results[i].empId === "") {
							oData.results[i].headerText = oData.results[i].Role + " " + "Slot Empty";
						} else {
							oData.results[i].headerText = oData.results[i].Role + " " + oData.results[i].First_Name + " " + oData.results[i].Last_Name;
						}
						// Set item visible
						oData.results[i].visible = {};
						switch (oData.results[i].Region) {
							case "EMEA CCT":
							    if(oData.results[i].DisplayOnBm === "X"){
							    	oData.results[i].visible = true;
							    }else{
							    	oData.results[i].visible = false;
							    }
							    break;
							case "APJ GCN CCT":
							    if(oData.results[i].DisplayOnBm === "X"){
							    	oData.results[i].visible = true;
							    }else{
							    	oData.results[i].visible = false;
							    }
							    break;
							case "NA CCT":
							    if(oData.results[i].DisplayOnBm === "X"){
							    	oData.results[i].visible = true;
							    }else{
							    	oData.results[i].visible = false;
							    }
							    break;
							case "LAC CCT":
							    if(oData.results[i].DisplayOnBm === "X"){
							    	oData.results[i].visible = true;
							    }else{
							    	oData.results[i].visible = false;
							    }
							    break;
							case "EMEA BACKOFFICE":
								if (/*oData.results[i].Role === "Backoffice Head IRE:"*/ oData.results[i].DisplayOnBm !== "X") {
									oData.results[i].visible = false;
								} else {
									oData.results[i].visible = true;
								}
								break;
							case "APJ GCN BACKOFFICE":
								if (/*oData.results[i].Role === "HEC TLO"*/ oData.results[i].DisplayOnBm !== "X") {
									oData.results[i].visible = false;
								} else {
									oData.results[i].visible = true;
								}
								break;
							case "LAC BACKOFFICE":
								/*if (oData.results[i].Role !== "Backoffice Head LA:" && oData.results[i].Role !== "Team 1 Lead MX:" && oData.results[i].Role !==
									"Team 1 Lead BR:" && oData.results[i].Role !== "Team 2 Lead BR:" && oData.results[i].Role !== "Head of Backoffice" && oData.results[i].Role !== "BD/PE  Lead BR" 
									&& oData.results[i].Role !== "xTec Lead" && oData.results[i].Role !== "BD/PE Lead MX" && oData.results[i].Role !== "Q&D Member 4pm – 9pm (CET)" && oData.results[i].Role !== "Q&D Member 9pm – 1am (CET)"
									&& oData.results[i].Role !== "Admin" && oData.results[i].Role !== "Q&D Member 1" && oData.results[i].Role !== "Q&D Member 2" ) {
									oData.results[i].visible = false;
								}*/ if(oData.results[i].DisplayOnBm !== "X"){
									oData.results[i].visible = false;
								} else {
									oData.results[i].visible = true;
								}
								break;
							case "NA BACKOFFICE":
								/*if (oData.results[i].Role !== "BO Head:" && oData.results[i].Role !== "Duty Manager:" && oData.results[i].Role !==
									"Team Lead 1:" && oData.results[i].Role !== "Team Lead Midshift:" && oData.results[i].Role !==
									"Team 1 Lead IRE:" && oData.results[i].Role !== "Team 2 Lead:" && oData.results[i].Role !== "RCA Lead Weekend US:" && oData.results[
										i].Role !== "RCA Lead Weekend IRE:") {*/
								if (/*oData.results[i].Role !== "Regional Head" && oData.results[i].Role !== "Duty Manager" && oData.results[i].Role !== "Team Lead (US)"
									&& oData.results[i].Role !== "Team Co-Lead (US)" && oData.results[i].Role !== "Team 2 Lead (US)" && oData.results[i].Role !== "Team Lead (US late shift)" 
									&& oData.results[i].Role !== "Hub Lead (IRE)" && oData.results[i].Role !== "Team Lead (IRE)" && oData.results[i].Role !== "RCA Lead Weekend (US)" 
									&& oData.results[i].Role !== "RCA Lead Weekend (IRE)" && oData.results[i].Role !== "Regional Head:" && oData.results[i].Role !== "Duty Manager:" && oData.results[i].Role !== "Team Lead (US)"
									&& oData.results[i].Role !== "Team Co-Lead (US):" && oData.results[i].Role !== "Team 2 Lead (US):" && oData.results[i].Role !== "Team Lead (US late shift):" 
									&& oData.results[i].Role !== "Hub Lead (IRE):" && oData.results[i].Role !== "Team Lead (IRE):" && oData.results[i].Role !== "RCA Lead Weekend (US):" 
									&& oData.results[i].Role !== "RCA Lead Weekend (IRE):" && oData.results[i].Role !== "Head of Backoffice" && oData.results[i].Role !== "Business Down Lead" 
									&& oData.results[i].Role !== "Business Down Lead Mid" && oData.results[i].Role !== "Business Down Lead IRE" && oData.results[i].Role !== "x-Tec Lead" 
									&& oData.results[i].Role !== "Q&D Lead / MCC SWAT Lead" && oData.results[i].Role !== "Q&D DEA" && oData.results[i].Role !== "IOC SWAT Comms" && oData.results[i].Role !== "IOC SWAT Comms Mid"
								*/oData.results[i].DisplayOnBm !== "X") {
									oData.results[i].visible = false;
								} else {
									oData.results[i].visible = true;
								}
								break;
						}

					}
					// Staffing Data filtered
					var odata1 = oData.results.filter(function (item) {
						return (item.Assignmentstartdate !== null &&
							that.formatDate(item.Assignmentstartdate)[1] + that.formatDate(item.Assignmentstartdate)[2] + that.formatDate(item.Assignmentstartdate)[
								3] <=
							that.formatDate(item.Date)[1] + that.formatDate(item.Date)[2] + that.formatDate(item.Date)[3] &&
							that.formatDate(item.Assignmentenddate)[1] + that.formatDate(item.Assignmentenddate)[2] + that.formatDate(item.Assignmentenddate)[
								3] >=
							that.formatDate(item.Date)[1] + that.formatDate(item.Date)[2] + that.formatDate(item.Date)[3]);

					});
					var odata2 = oData.results.filter(function (item) {
						return (item.Assignmentstartdate === null);
					});
					oData.results = jQuery.merge(odata1, odata2);
					
					var oStaffingModel = new JSONModel();
					oStaffingModel.setData(oData);
					that.getView().setModel(oStaffingModel, "StaffingData");
					this.trackEvent(this.getOwnerComponent(),this.BMSTFF_ASSIGNMENTS);
				
				}.bind(this),
				error: function() {
                    
				}.bind(this)
			});	
			
			}.bind(this),
			error : function(){
				
			}.bind(this)	
				
			});
		},

		//Event handler
		handleDateRegionChange: function(oEvent) {
			var tempDate = this.byId("dp").getDateValue();

			var values = this.formatDate(tempDate);
			this.nDay = values[3];
			this.nMonth = values[2];
			this.nYear = values[1];
			this.nDayInWeek = values[0];

			this.selectedRegion = this.byId("dropdown").getSelectedKey();

			this.onSearchData();
		},

		onPressInfoIcon: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("mccguidelines", true);
		},

		_setDateModel: function() {
			var dateValue = new Date();
			var data = {
				dateValue: dateValue
			};
			var oModel = new JSONModel();
			oModel.setData(data);
			this.getView().setModel(oModel, "DateModel");
		},

		_setRegionModel: function() {
			var regionList = {
				"items": [{

					"key": "EMEA BACKOFFICE",
					"text": "EMEA"
				}, {
					"key": "APJ GCN BACKOFFICE",
					"text": "APJ GCN"
				}, {
					"key": "LAC BACKOFFICE",
					"text": "LAC"
				}, {
					"key": "NA BACKOFFICE",
					"text": "NA"
				}]
			};

			var mModel = new JSONModel();
			mModel.setData(regionList);
			this.getView().setModel(mModel, "RegionListModel");
		},

		_getDateData: function() {
			var dateValue = this.getView().getModel("DateModel").getData().dateValue;
			var values = this.formatDate(dateValue);
			this.nDay = values[3];
			this.nMonth = values[2];
			this.nYear = values[1];
			this.nDayInWeek = values[0];
		},

		_getRegionData: function() {
			this.selectedRegion = this.getView().byId("dropdown").getSelectedKey();
		},

		_getValueById: function(evt) {
			return sap.ui.getCore().byId(evt.getParameter("id")).getValue();
		},

		onEmailPress: function(evt) {
			sap.m.URLHelper.triggerEmail(this._getValueById(evt));
		},

		onPhonePress: function(evt) {
			sap.m.URLHelper.triggerTel(this._getValueById(evt));
		},
		
		onOverflow: function(evt) {
			if (!this._actionSheet) {
				this._actionSheet = sap.ui.xmlfragment("sap.support.boostm.view.actionSheet", this);
				this.getView().addDependent(this._actionSheet);
			}
			this._actionSheet.openBy(evt.getSource());
		},
		
		onOPALinkPress: function() {
			sap.m.URLHelper.redirect("ht" + "tps://flpnwc-agsdev.dispatcher.hana.ondemand.com/sites/MCCProductSupport#Shell-home", true);
		},
		
		onMCCLinkPress: function() {
		//	sap.m.URLHelper.redirect("ht" + "tps://mccactivities-supportportal.dispatcher.hana.ondemand.com/", true);
			sap.m.URLHelper.redirect("ht" + "tps://fiorilaunchpad.sap.com/sites#mccsos-Display", true);
		},
		getSystemLandscapeInfo: function () {
			var sSystem = "ICP"; // Default - Production
			if (window.location.host.toLowerCase().includes("br339jmc4c")) {
				sSystem = "ICD";
			} else if (window.location.host.toLowerCase().includes("sapitcloudt")) {
				sSystem = "ICT";
			}
			return sSystem;
		},
		 trackEvent: function (component, sEventName) {
			try {
				if(this.getSystemLandscapeInfo() === this.BACKND_SYS_ICP){
					sap.git.usage.Reporting.addEvent(component, sEventName);
				}
			} catch (err) {
				console.log("Error while triggering event: "+sEventName);
			}
		}
	});
});