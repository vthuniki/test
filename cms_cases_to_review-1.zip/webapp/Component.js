sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"c2r/o2c/cms_cases_to_review/model/models",
	"sapit/util/UsageTracking"
], function (UIComponent, Device, models, UsageTracking) {
	"use strict";

	return UIComponent.extend("c2r.o2c.cms_cases_to_review.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);
			// Application Usage Tracking
			UsageTracking.startUsageTracking(this);
			// enable routing
			this.getRouter().initialize();
			//Activating XOlytics for this app
			// var appId = ["01", "02", "32"];
			// var entityToBeMonitored = ["CMSWorklistSet"];
			// this.XOlytics = new XOlyticsServiceModel(this, appId, entityToBeMonitored);
			// this.XOlytics = new XOlyticsServiceModel(this);
			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			// enable routing
			//	this.getRouter().initialize();

			//set current user Model 
			this.setModel(models.createUserModel(), "userModel");
		}
	});
});