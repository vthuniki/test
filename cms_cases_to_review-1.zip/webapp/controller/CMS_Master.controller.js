sap.ui.define([
	"c2r/o2c/cms_cases_to_review/controller/Base.controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"c2r/o2c/cms_cases_to_review/utils/Constants",
	"c2r/o2c/cms_cases_to_review/control/BusinessObjectHyperLink",
	"sap/ui/util/Storage",
	"sap/m/SuggestionItem",
	"c2r/o2c/cms_cases_to_review/model/formatter",
	"sap/base/util/UriParameters",
		"sap/ui/core/Fragment"


], function (Controller, Filter, FilterOperator, Sorter, MessageToast, MessageBox, Constants, BusinessObjectHyperLink, Storage,
	SuggestionItem, formatter, UriParameters, Fragment) {
	"use strict";

	return Controller.extend("c2r.o2c.cms_cases_to_review.controller.CMS_Master", {
		formatter: formatter,
		
		
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf c2r.o2c.cms_cases_to_review.view.CMS_Master
		 */

		onInit: function () {
			this.getOwnerComponent().getModel("AppConfig").setProperty("/HeaderVisiblitySettings", {
				"AllCases": true,
				"MyCases": false,
				"NotAssigned": false
			});

			this.activateWebAnalytics('9e66a325-9da0-544c-e32b-6e80e42503b1');

			/*this.activateWebAnalytics("d1ca96f1-d4ca-71a7-1c71-3d21b12c37df");*/
			// token for qa-tracker
			this._oBusinessObjectHyperLink = new BusinessObjectHyperLink();
			this.getOwnerComponent().getModel("AppConfig").setProperty("/root", jQuery.sap.getModulePath("c2r.o2c.cms_cases_to_review"));
			this.getOwnerComponent().getModel("AppConfig").setProperty("/Material", false);
			this.getOwnerComponent().getModel("AppConfig").setProperty("/Customer", false);
			this.getOwnerComponent().getModel("AppConfig").setProperty("/somquoteFlag", 'X');
			this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
			this._oFilterBars = {};
			this._oSmartTables = {};
			this.initialLoad = 0;

			//Controlling All/My CMS Cases based on Uri parameter..used in OVP Card navigation
			var sParam = UriParameters.fromQuery(window.location.href).get("CMSCaseType");
			if (sParam)
				this.getOwnerComponent().getModel("AppConfig").setProperty("/SelectedCase", sParam);
			else
				this.getOwnerComponent().getModel("AppConfig").setProperty("/SelectedCase", "AllCases");
			// this.getOwnerComponent().getModel("AppConfig").setProperty("/SelectedCase", "AllCases");
			this.getOwnerComponent().getModel("AppConfig").setProperty("/StartBookingFlag", false);
			this.getOwnerComponent().getModel("AppConfig").setProperty("/BookingFlag", false);
			this._oMessageManager = sap.ui.getCore().getMessageManager();
			var oMessageModel = this._oMessageManager.getMessageModel();
			this.getView().setModel(oMessageModel, "message");
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oMessage = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			this._ErrorMessage = [];
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.attachRouteMatched(function (oEvent) {
				this.onViewSelection();
			}, this);
		},

		onAfterRendering: function () {
			this.getView().getModel().attachRequestCompleted(null, this.monitorBatchRequestCompleted, this);
		},

		monitorBatchRequestCompleted: function (data) {
			//Code to save Xolytics parameters
			if (this.gopress) {
				this.gopress = false;
				var oModel = this.getOwnerComponent().getModel();
				var response = data.getParameters().response;
				response.requestUri = data.getParameters().url;
				// this.savePerformanceMatrixXOlytics(oModel, response);
			}
			var oTable = this.getOwnerComponent().getModel("AppConfig").getProperty("/oTable");
			var sUrl = data.getParameter("url");
			if (sUrl.indexOf("AssignCMSCaseToUser") !== -1) {
				var aServerSideMessage = this.getView().getModel("message").getData();
				oTable.setBusy(false);
				for (var i = 0; i < aServerSideMessage.length; i++) {
					if (aServerSideMessage[i].type === "Information" && (aServerSideMessage[i].description.indexOf("success") !== -1)) {
						aServerSideMessage[i].type = "Success";
					}
				}
				this._aServerSideMessage = aServerSideMessage;
				this.getView().getModel("message").setData(aServerSideMessage);
				this.getView().getModel("message").refresh();
				oTable.rebindTable();
			} else if (sUrl.indexOf("CmsWorklistSet") !== -1) {
				if (!this._bExportExcel) {
					this._bExportExcel = false;
					this.arrangeColumns();
					//this._getActiveTable().getTable().setBusy(false);
					if (this._aServerSideMessage && this._aServerSideMessage.length) {
						this.getView().getModel("message").setData(this._aServerSideMessage);
						this.getView().getModel("message").refresh();
						jQuery.sap.delayedCall(10000, this, function () {
							this._aServerSideMessage = [];
						});
					}
				}
			}
		},

		arrangeColumns: function () {
			var oTable = this._getCurrentActiveSmartTable();
			if (oTable && !oTable.getCurrentVariantId()) {
				oTable.getTable().getColumns().forEach(function (oColumn) {
					if (Constants.oColumnsWidth.hasOwnProperty(oColumn.getLabel().getText().replace(/ /g, ''))) {
						oColumn.setWidth(Constants.oColumnsWidth[oColumn.getLabel().getText().replace(/ /g, '')] + "em");
					}
					if (oColumn.getLabel().getText().replace(/ /g, '') === "ERPSoldTo") {
						oColumn.setSortProperty("PartyName");
					}
					if (oColumn.getLabel().getText().replace(/ /g, '') === "ContractAdmin") {
						oColumn.setSortProperty("AdminName");
					}
				});
			}
		},

		onViewSelection: function () {
			var sCase_View, oHeaderVisiblitySettings = {
				"AllCases": false,
				"MyCases": false,
				"NotAssigned": false
			};

			sCase_View = this.getView().getModel("AppConfig").getProperty("/SelectedCase");
			oHeaderVisiblitySettings[sCase_View] = true;
			if (!this._oFilterBars[sCase_View]) {
				this._oFilterBars[sCase_View] = sap.ui.xmlfragment(this.getView().getId(),
					"c2r.o2c.cms_cases_to_review.view.fragment.SmartFilterBar." + sCase_View, this);
				this.getView().byId("CmsMasterDynamicPageHeader").addContent(this._oFilterBars[sCase_View]);
			}

			if (!this._oSmartTables[sCase_View]) {
				this._oSmartTables[sCase_View] = sap.ui.xmlfragment(this.getView().getId(),
					"c2r.o2c.cms_cases_to_review.view.fragment.SmartTable." + sCase_View, this);
				this.getView().byId("CmsMasterPageContent").addItem(this._oSmartTables[sCase_View]);

				// if (sCase_View !== "AllCases") {
				// if (!this.getView().byId("CmsSmartTable_" + sCase_View).getEnableAutoBinding()) {
				// 	this.getView().byId("CmsSmartTable_" + sCase_View).setEntitySet("CmsWorklistSet");
				// 	this.getView().byId("CmsSmartTable_" + sCase_View).setEnableAutoBinding(true);
				// }
				// }
			}

			this.getOwnerComponent().getModel("AppConfig").setProperty("/HeaderVisiblitySettings", oHeaderVisiblitySettings);
			var sSelCase = this.getSelectedCase();
			var sSelRows = this._getSelectedMasterTableItems();

			switch (sCase_View) {
			case 'AllCases':
				this.readFeedbackQues("01");
				var sAllView = this.getView().getModel("AppConfig").getProperty("/AllCaseView");
				if (sAllView === sSelCase) {
					this.getView().getModel("AppConfig").setProperty("/Material", true);

				} else {
					this.getView().getModel("AppConfig").setProperty("/Material", false);
				}
				if (sSelRows.length === 1)
					this.getView().getModel("AppConfig").setProperty("/Customer", true);
				else
					this.getView().getModel("AppConfig").setProperty("/Customer", false);
				break;
			case 'MyCases':
				this.readFeedbackQues("02");
				var sMycase = this.getView().getModel("AppConfig").getProperty("/MyCaseView");
				if (sMycase === sSelCase) {
					this.getView().getModel("AppConfig").setProperty("/StartBookingFlag", true);
					this.getView().getModel("AppConfig").setProperty("/BookingFlag", true);
					this.getView().getModel("AppConfig").setProperty("/Material", true);
				} else {
					this.getView().getModel("AppConfig").setProperty("/Material", false);
					this.getView().getModel("AppConfig").setProperty("/StartBookingFlag", false);
					this.getView().getModel("AppConfig").setProperty("/BookingFlag", false);
				}
				if (sSelRows.length === 1)
					this.getView().getModel("AppConfig").setProperty("/Customer", true);
				else
					this.getView().getModel("AppConfig").setProperty("/Customer", false);
				break;
			case 'NotAssigned':
				this.readFeedbackQues("32");
				var sNotAssign = this.getView().getModel("AppConfig").getProperty("/NotAssignView");
				if (sNotAssign === sSelCase) {
					this.getView().getModel("AppConfig").setProperty("/Material", true);
				} else {
					this.getView().getModel("AppConfig").setProperty("/Material", false);
				}
				if (sSelRows.length === 1)
					this.getView().getModel("AppConfig").setProperty("/Customer", true);
				else
					this.getView().getModel("AppConfig").setProperty("/Customer", false);
				break;

			}
		},

		onTabSelection: function () {
			this.onViewSelection();
		},
		onBeforeCMS_RebindTable_AllCases: function (oEvent) {
			//this.passFunctIdToXOlytics("Go", null, "01");
			var mBindingParams = oEvent.getParameter("bindingParams");
			this.updateSearchFieldSuggestion(mBindingParams, oEvent.getSource().getSmartFilterId(), "ALL");
			this.onBeforeCMS_RebindTable(mBindingParams);
		},
		onBeforeCMS_RebindTable_MyCases: function (oEvent) {
			//this.passFunctIdToXOlytics("Go", null, "02");
			var mBindingParams = oEvent.getParameter("bindingParams");
			this.updateSearchFieldSuggestion(mBindingParams, oEvent.getSource().getSmartFilterId(), "My");
			this.onBeforeCMS_RebindTable(mBindingParams);
		},

		onBeforeCMS_RebindTable_NotAssigned: function (oEvent) {
			//this.passFunctIdToXOlytics("Go", null, "32");
			var mBindingParams = oEvent.getParameter("bindingParams");
			this.updateSearchFieldSuggestion(mBindingParams, oEvent.getSource().getSmartFilterId(), "NA");
			this.onBeforeCMS_RebindTable(mBindingParams);
		},

		onBeforeCMS_RebindTable: function (mBindingParams) {
			mBindingParams.filters.push(new Filter("CmsCase", FilterOperator.EQ, this.getSelectedCase()));
			if (this.flagE === true) {
				mBindingParams.filters.push(new Filter("RunInBg", FilterOperator.EQ, "E"));
				this.flagE = false;
			} else if (this.flagA === true) {
				mBindingParams.filters.push(new Filter("RunInBg", FilterOperator.EQ, "A"));
				this.flagA = false;
			} else {
				mBindingParams.filters.push(new Filter("RunInBg", FilterOperator.EQ, ""));
			}
			this.getView().getModel("AppConfig").setProperty("/StartBookingFlag", false);
			this.getView().getModel("AppConfig").setProperty("/BookingFlag", false);
			this.getView().getModel("AppConfig").setProperty("/Material", false);
			this.getView().getModel("AppConfig").setProperty("/Customer", false);
			mBindingParams.sorter.push(new Sorter("SalesOrg", false, function (oContext) {
				var sSalesOrg = oContext.getProperty("SalesOrg");
				return {
					key: sSalesOrg,
					text: "Sales Document: " + sSalesOrg
				};
			}));
		},
		onRunViaEmailPress: function () {
			var oTable, oCase = this.getSelectedCase();
			if (oCase === "3") {
				this.flagE = true;
				oTable = this.getView().byId("CmsSmartTable_AllCases");
				oTable.rebindTable();
			} else if (oCase === "1") {
				this.flagE = true;
				oTable = this.getView().byId("CmsSmartTable_MyCases");
				oTable.rebindTable();
			} else if (oCase === "2") {
				this.flagE = true;
				oTable = this.getView().byId("CmsSmartTable_NotAssigned");
				oTable.rebindTable();
			}
			var msg = this.oMessage.getText("runbackmsgtoast");
			MessageToast.show(msg);
		},
		onAppPress: function () {
			var oTable, oCase = this.getSelectedCase();
			if (oCase === "3") {
				this.flagA = true;
				oTable = this.getView().byId("CmsSmartTable_AllCases");
				oTable.rebindTable();
			} else if (oCase === "1") {
				this.flagA = true;
				oTable = this.getView().byId("CmsSmartTable_MyCases");
				oTable.rebindTable();
			} else if (oCase === "2") {
				this.flagA = true;
				oTable = this.getView().byId("CmsSmartTable_NotAssigned");
				oTable.rebindTable();
			}
			var msg = this.oMessage.getText("runinAppbackmsgtoast");
			MessageToast.show(msg);
			this.navBackgroundJobDashboard();
		},
		navBackgroundJobDashboard: function () {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "o2cbackgroundreport",
					action: "Display"
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},
		getSelectedCase: function () {
			var sCase;
			switch (this.getView().getModel("AppConfig").getProperty("/SelectedCase")) {
			case "AllCases":
				sCase = "3";
				this.getView().getModel("AppConfig").setProperty("/CaseTab", "01");
				break;
			case "MyCases":
				sCase = "1";
				this.getView().getModel("AppConfig").setProperty("/CaseTab", "02");
				break;
			case "NotAssigned":
				sCase = "2";
				this.getView().getModel("AppConfig").setProperty("/CaseTab", "32");
				break;
			default:
				sCase = "3";
			}
			return sCase;
		},
		openQuotation: function () {
			var aSelectedItems = this._getSelectedMasterTableItems();
			var oSelectedRow = aSelectedItems[0].getObject();
			this._oBusinessObjectHyperLink._openQuotation({
				"Deal": oSelectedRow.Oppn,
				"type": oSelectedRow.QuoteFlag,
				"id": oSelectedRow.RefQuote
			});
		},

		updateLOS: function (oSmartFilter) {
			oSmartFilter.getControlByKey("Los").getBinding("items").filter(new sap.ui.model.Filter("Lob", sap.ui.model.FilterOperator.EQ,
				oSmartFilter.getControlByKey("Lob").getSelectedKeys()));
			// multipleLobs
		},

		addNavigationToTable: function (oTable) {
			var fnPress = this.showLinkedObjects.bind(this);
			var oTemplate = new sap.ui.table.RowAction({
				items: [
					new sap.ui.table.RowActionItem({
						text: 'Linked Objects',
						press: fnPress,
						visible: true
					})
				]
			});
			oTable.setRowActionTemplate(oTemplate);
			oTable.setRowActionCount(1);
		},
		afterVariantLobAllCasesLoad: function () {
			var oSmartFilter = this.getView().byId("CMS_SmartFilterBar_AllCases");
			this.updateLOS(oSmartFilter);
		},
		afterVariantLobMyCasesLoad: function () {
			var oSmartFilter = this.getView().byId("CMS_SmartFilterBar_MyCases");
			this.updateLOS(oSmartFilter);
		},
		afterVariantLobNotAssignedLoad: function () {
			var oSmartFilter = this.getView().byId("CMS_SmartFilterBar_NotAssigned");
			this.updateLOS(oSmartFilter);
		},
		onInitAllCasesSmartFilter: function () {
			var oSmartFilter = this.getView().byId("CMS_SmartFilterBar_AllCases");
			oSmartFilter.setFilterData(Constants.StandardVariantFBData.CMS_SmartFilterBar_AllCases);
			oSmartFilter.getControlByKey("Lob").attachSelectionChange(null, function () {
				oSmartFilter.getControlByKey("Los").setSelectedKeys([]);
				oSmartFilter.getControlByKey("Los").fireSelectionChange({
					changedItem: {
						key: ""
					},
					selected: true
				});
				this.getView().getModel("AppConfig").setProperty("/SelectedLob", oSmartFilter.getControlByKey("Lob").getSelectedKeys());
				if (oSmartFilter.getControlByKey("Lob").getSelectedKeys().length > 1) {
					oSmartFilter.getControlByKey("Los").setEnabled(false);
				} else {
					oSmartFilter.getControlByKey("Los").setEnabled(true);
				}
				// multipleLobs
				this.updateLOS(oSmartFilter);
			}, this);
			this.addSuggestionForBasicSearch(oSmartFilter, "ALL");
		},

		onInitMyCasesSmartFilter: function () {
			var oSmartFilter = this.getView().byId("CMS_SmartFilterBar_MyCases");
			oSmartFilter.setFilterData(Constants.StandardVariantFBData.CMS_SmartFilterBar_MyCases);
			this.getView().getModel("AppConfig").setProperty("/SelectedLob", "SR");
			oSmartFilter.getControlByKey("Lob").attachSelectionChange(null, function () {
				oSmartFilter.getControlByKey("Los").setSelectedKeys([]);
				oSmartFilter.getControlByKey("Los").fireSelectionChange({
					changedItem: {
						key: ""
					},
					selected: true
				});
				if (oSmartFilter.getControlByKey("Lob").getSelectedKeys().length > 1) {
					oSmartFilter.getControlByKey("Los").setEnabled(false);
				} else {
					oSmartFilter.getControlByKey("Los").setEnabled(true);
				}
				// multipleLobs
				this.updateLOS(oSmartFilter);
			}, this);
			this.addSuggestionForBasicSearch(oSmartFilter, "My");
		},

		onInitNotAssignedSmartFilter: function () {
			var oSmartFilter = this.getView().byId("CMS_SmartFilterBar_NotAssigned");
			oSmartFilter.setFilterData(Constants.StandardVariantFBData.CMS_SmartVariant_NotAssigned);
			oSmartFilter.getControlByKey("Lob").attachSelectionChange(null, function () {
				oSmartFilter.getControlByKey("Los").setSelectedKeys([]);
				oSmartFilter.getControlByKey("Los").fireSelectionChange({
					changedItem: {
						key: ""
					},
					selected: true
				});
				if (oSmartFilter.getControlByKey("Lob").getSelectedKeys().length > 1) {
					oSmartFilter.getControlByKey("Los").setEnabled(false);
				} else {
					oSmartFilter.getControlByKey("Los").setEnabled(true);
				}
				// multipleLobs
				this.updateLOS(oSmartFilter);
			}, this);
			this.addSuggestionForBasicSearch(oSmartFilter, "NA");
		},

		addSuggestionForBasicSearch: function (oSmartFilter, storageFor) {
			var storageName = "CMS_" + storageFor;
			var aSuggestedItems = Storage.get(storageName);
			aSuggestedItems = JSON.parse(aSuggestedItems ? aSuggestedItems : '[]');
			this.getView().getModel("AppConfig").setProperty("/SFB_BasicSearch_Suggestions" + storageFor, aSuggestedItems);
			var oSearchField = oSmartFilter.getBasicSearchControl();
			oSearchField.setEnableSuggestions(true);
			oSearchField.attachSuggest(null, this.onSearchFieldSuggest, this);
			oSearchField.bindAggregation("suggestionItems", {
				path: "AppConfig>/SFB_BasicSearch_Suggestions" + storageFor,
				template: new SuggestionItem({
					key: "{AppConfig>text}",
					text: "{AppConfig>text}"
				})
			});
		},

		updateSearchFieldSuggestion: function (mBindingParams, FilterBarId, storageFor) {
			if (mBindingParams.parameters && mBindingParams.parameters.custom) {
				var sSearchvalue = mBindingParams.parameters.custom.search;
				if (sSearchvalue) {
					var checkIfExisting = false;
					var aSuggestedItems = this.getView().getModel("AppConfig").getProperty("/SFB_BasicSearch_Suggestions" + storageFor);
					for (var i = 0; i < aSuggestedItems.length; i++) {
						if (aSuggestedItems[i].text === sSearchvalue) {
							checkIfExisting = true;
							break;
						}
					}
					if (!checkIfExisting) {
						if (aSuggestedItems.length > 9) {
							aSuggestedItems.splice(0, 1);
						}
						aSuggestedItems.push({
							"text": sSearchvalue
						});
						Storage.put("CMSRequiringAttention", JSON.stringify(aSuggestedItems));
						this.getView().getModel("AppConfig").setProperty("/SFB_BasicSearch_Suggestions" + storageFor, aSuggestedItems);
					}
				}
			}
		},

		onSearchFieldSuggest: function (event) {
			var sValue = event.getParameter("suggestValue"),
				aFilters = [];
			if (sValue) {
				aFilters = [
					new Filter("text", function (sDes) {
						return (sDes || "").toUpperCase().indexOf(sValue.toUpperCase()) > -1;
					})
				];
			}
			event.getSource().getBinding("suggestionItems").filter(aFilters);
			event.getSource().suggest();
		},

		showAssignToME: function (sCases) {
			return sCases === "MyCases" ? false : false;
		},
      //start ITSDEDLC-2355 
      	onBeforeExport: function (oEvt) {
	        	var length = this.getView().byId("CmsSmartTable_AllCases")._getRowBinding().aKeys['length'];
	        	var Max = 54;
	        	if (length <= Max) {
	        	
	        			this._bExportExcel = true;
			var appid = this.getView().getModel("AppConfig").getProperty("/CaseTab");
			//this.passFunctIdToXOlytics("Excel", "003", appid);
			var mExcelSettings = oEvt.getParameter("exportSettings");
			var mUserExcelSettings = oEvt.getParameter("userExportSettings");
			mExcelSettings.dataSource.dataUrl = mExcelSettings.dataSource.dataUrl + Constants.ExpandQuery;
			var hasCurrency = false,
				hasServicontr,
				hasPCC,
				hasSOMuote,
				hasSOMPc,
				iCurrencyIndex;
			if (mExcelSettings.url) {
				return;
			}
			for (var j = 0; j < mExcelSettings.workbook.columns.length; j++) {
				if (mExcelSettings.workbook.columns[j].property === "MultiServiceContr") {
					mExcelSettings.workbook.columns.splice(j, 1);
					hasServicontr = "X";
					j = j - 1;
				} else if (mExcelSettings.workbook.columns[j].property === "SomQuoteGuid") {
					mExcelSettings.workbook.columns.splice(j, 1);
					hasSOMuote = "X";
					j = j - 1;
				} else if (mExcelSettings.workbook.columns[j].property === "SomPcGuid") {
					mExcelSettings.workbook.columns.splice(j, 1);
					hasSOMPc = "X";
					j = j - 1;
				}
			}
			for (var i = 0; i < mExcelSettings.workbook.columns.length; i++) {
				if (mExcelSettings.workbook.columns[i].property === "TargetValue") {
					mExcelSettings.workbook.columns[i].displayUnit = false;
					hasCurrency = true;
					iCurrencyIndex = i;
				}
				if (mExcelSettings.workbook.columns[i].property === "ChangedDate") {
					mExcelSettings.workbook.columns[i].property = ["ChangedDate"];
					mExcelSettings.workbook.columns[i].type = "Date";
				}
				if (mExcelSettings.workbook.columns[i].property === "SwStatusDesc") {
					mExcelSettings.workbook.columns[i].label = "SO Booking Status Desc";
				}
				if (mExcelSettings.workbook.columns[i].property === "PartyName") {
					mExcelSettings.workbook.columns[i].label = "ERP Sold To Name";
				}
				if (mExcelSettings.workbook.columns[i].property === "CtypeTxt") {
					mExcelSettings.workbook.columns[i].label = "Contract Type Description";
				}
				if (mExcelSettings.workbook.columns[i].property === "ChangedByName") {
					mExcelSettings.workbook.columns[i].label = "Changed By Name";
				}
				if (mExcelSettings.workbook.columns[i].property === "AdminName") {
					mExcelSettings.workbook.columns[i].label = "Contract Admin Name";
				}
				if (mExcelSettings.workbook.columns[i].property === "Notes") {
					mExcelSettings.workbook.columns[i].label = "Notes";
				}
				if (mExcelSettings.workbook.columns[i].property === "ExecName") {
					mExcelSettings.workbook.columns[i].label = "Account Executive Name";
				}
				if (mExcelSettings.workbook.columns[i].property === "DealTypDesc") {
					mExcelSettings.workbook.columns[i].label = "HCP Deal Type Desc";
				}
				if (mExcelSettings.workbook.columns[i].property === "SalesGrpDesc") {
					mExcelSettings.workbook.columns[i].label = "Sales Group Desc";
				}
				if (mExcelSettings.workbook.columns[i].property === "SalesOffDesc") {
					mExcelSettings.workbook.columns[i].label = "Sales Office Desc";
				}
				if (mExcelSettings.workbook.columns[i].property === "SalesOrgDesc") {
					mExcelSettings.workbook.columns[i].label = "Sales Organization";
				}
				if (mExcelSettings.workbook.columns[i].property === "ExtRefTypeDesc") {
					mExcelSettings.workbook.columns[i].label = "External Ref Type Desc";
				}
				if (mExcelSettings.workbook.columns[i].property === "ProviderContractOnPrem") {
					mExcelSettings.workbook.columns[i].label = "Provider Contract OnPrem";
					hasPCC = "X";
				}
				if (mExcelSettings.workbook.columns[i].property === "BookingTime") {
					mExcelSettings.workbook.columns[i].type = sap.ui.export.EdmType.Time; //ExemptToDate
					mExcelSettings.workbook.columns[i].width = 10;
					mExcelSettings.workbook.columns[i].inputFormat = sap.ui.core.format.DateFormat.getTimeInstance({
						pattern: "hh:mm:ss a"
					});
				}
			}
			// if (hasCurrency) {
			// 	mExcelSettings.workbook.columns.splice(iCurrencyIndex + 1, 0, {
			// 		"displayUnit": false,
			// 		"label": "Currency",
			// 		"property": "Currency",
			// 		"textAlign": "Right",
			// 		"type": "string",
			// 		"width": 3
			// 	});
			// }
			if (hasPCC === "X") {
				mExcelSettings.workbook.columns.push({
					"displayUnit": false,
					"label": "Provider Contract Cloud",
					"property": "ProviderContractCloud",
					"textAlign": "Right",
					"type": "string",
					"width": 12
				});
			}
			if (hasServicontr === "X") {
				mExcelSettings.workbook.columns.push({
					"label": "Service Contract",
					"property": "MultiSCId",
					"textAlign": "Right",
					"type": "string",
					"width": 12
				});
			}
			if (hasSOMuote === "X") {
				mExcelSettings.workbook.columns.push({
					"label": "Som Quote Number",
					"property": "SomQuoteNumber",
					"textAlign": "Right",
					"type": "string",
					"width": 12
				});
			}
			if (hasSOMPc === "X") {
				mExcelSettings.workbook.columns.push({
					"label": "Som Provider Contract",
					"property": "SomPc",
					"textAlign": "Right",
					"type": "string",
					"width": 12
				});
			}
			if (mUserExcelSettings.splitCells) {
				mExcelSettings.workbook.columns.push({
					"displayUnit": false,
					"label": "Note Date",
					"property": "ToGetCaseNotes/results/0/CreatedDate",
					"textAlign": "Left",
					"type": "Date",
					"width": 10
				});
				mExcelSettings.workbook.columns.push({
					"displayUnit": false,
					"label": "Note",
					"property": "ToGetCaseNotes/results/0/Content",
					"textAlign": "Left",
					"type": "string",
					"width": 30
				});
				mExcelSettings.workbook.columns.push({
					"displayUnit": false,
					"label": "Note Modified By",
					"property": "ToGetCaseNotes/results/0/PersonName",
					"textAlign": "Left",
					"type": "string",
					"width": 25
				});

				// mExcelSettings.workbook.columns.push({
				// 	"displayUnit": false,
				// 	"label": "Note",
				// 	"property": ["ToGetCaseNotes/results/0/PersonName", "ToGetCaseNotes/results/0/Content"],
				// 	"template": "{1}, {0}",
				// 	"textAlign": "Left",
				// 	"type": "string",
				// 	"width": 100
				// });
			} else {
				MessageToast.show(this._getResourceBundleText("ExcelExportNotesMsg"), {
					"duration": 10000
				});
				this.getView().getModel("message").setData([{
					description: this._getResourceBundleText("ExcelExportNotesMsg"),
					type: "Information",
					title: this._getResourceBundleText("ExcelExportNotesMsgTitle")
				}]);
				if (hasCurrency) {
					mExcelSettings.workbook.columns.splice(iCurrencyIndex + 1, 0, {
						"displayUnit": false,
						"label": "Currency",
						"property": "Currency",
						"textAlign": "Right",
						"type": "string",
						"width": 3
					});
				}
			}
	        	}
	        	else {
	        	
	        			if (!this.pDialog) {
				this.pDialog = this.loadFragment({
					name: "c2r.o2c.cms_cases_to_review.view.Excelexport"
				});
			} 
			this.pDialog.then(function(oDialog) {
				oDialog.open();
			});

	        	}
	
	
		
		},
			onCloseDialog : function () {
			// note: We don't need to chain to the pDialog promise, since this event-handler
			// is only called from within the loaded dialog itself.
			this.byId("helloDialog").close();
		},

		// onBeforeExport: function (oEvt) {
		// 	this._bExportExcel = true;
		// 	var appid = this.getView().getModel("AppConfig").getProperty("/CaseTab");
		// 	//this.passFunctIdToXOlytics("Excel", "003", appid);
		// 	var mExcelSettings = oEvt.getParameter("exportSettings");
		// 	var mUserExcelSettings = oEvt.getParameter("userExportSettings");
		// 	mExcelSettings.dataSource.dataUrl = mExcelSettings.dataSource.dataUrl + Constants.ExpandQuery;
		// 	var hasCurrency = false,
		// 		hasServicontr,
		// 		hasPCC,
		// 		hasSOMuote,
		// 		hasSOMPc,
		// 		iCurrencyIndex;
		// 	if (mExcelSettings.url) {
		// 		return;
		// 	}
		// 	for (var j = 0; j < mExcelSettings.workbook.columns.length; j++) {
		// 		if (mExcelSettings.workbook.columns[j].property === "MultiServiceContr") {
		// 			mExcelSettings.workbook.columns.splice(j, 1);
		// 			hasServicontr = "X";
		// 			j = j - 1;
		// 		} else if (mExcelSettings.workbook.columns[j].property === "SomQuoteGuid") {
		// 			mExcelSettings.workbook.columns.splice(j, 1);
		// 			hasSOMuote = "X";
		// 			j = j - 1;
		// 		} else if (mExcelSettings.workbook.columns[j].property === "SomPcGuid") {
		// 			mExcelSettings.workbook.columns.splice(j, 1);
		// 			hasSOMPc = "X";
		// 			j = j - 1;
		// 		}
		// 	}
		// 	for (var i = 0; i < mExcelSettings.workbook.columns.length; i++) {
		// 		if (mExcelSettings.workbook.columns[i].property === "TargetValue") {
		// 			mExcelSettings.workbook.columns[i].displayUnit = false;
		// 			hasCurrency = true;
		// 			iCurrencyIndex = i;
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "ChangedDate") {
		// 			mExcelSettings.workbook.columns[i].property = ["ChangedDate"];
		// 			mExcelSettings.workbook.columns[i].type = "Date";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "SwStatusDesc") {
		// 			mExcelSettings.workbook.columns[i].label = "SO Booking Status Desc";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "PartyName") {
		// 			mExcelSettings.workbook.columns[i].label = "ERP Sold To Name";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "CtypeTxt") {
		// 			mExcelSettings.workbook.columns[i].label = "Contract Type Description";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "ChangedByName") {
		// 			mExcelSettings.workbook.columns[i].label = "Changed By Name";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "AdminName") {
		// 			mExcelSettings.workbook.columns[i].label = "Contract Admin Name";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "Notes") {
		// 			mExcelSettings.workbook.columns[i].label = "Notes";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "ExecName") {
		// 			mExcelSettings.workbook.columns[i].label = "Account Executive Name";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "DealTypDesc") {
		// 			mExcelSettings.workbook.columns[i].label = "HCP Deal Type Desc";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "SalesGrpDesc") {
		// 			mExcelSettings.workbook.columns[i].label = "Sales Group Desc";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "SalesOffDesc") {
		// 			mExcelSettings.workbook.columns[i].label = "Sales Office Desc";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "SalesOrgDesc") {
		// 			mExcelSettings.workbook.columns[i].label = "Sales Organization";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "ExtRefTypeDesc") {
		// 			mExcelSettings.workbook.columns[i].label = "External Ref Type Desc";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "ProviderContractOnPrem") {
		// 			mExcelSettings.workbook.columns[i].label = "Provider Contract OnPrem";
		// 			hasPCC = "X";
		// 		}
		// 		if (mExcelSettings.workbook.columns[i].property === "BookingTime") {
		// 			mExcelSettings.workbook.columns[i].type = sap.ui.export.EdmType.Time; //ExemptToDate
		// 			mExcelSettings.workbook.columns[i].width = 10;
		// 			mExcelSettings.workbook.columns[i].inputFormat = sap.ui.core.format.DateFormat.getTimeInstance({
		// 				pattern: "hh:mm:ss a"
		// 			});
		// 		}
		// 	}
		// 	// if (hasCurrency) {
		// 	// 	mExcelSettings.workbook.columns.splice(iCurrencyIndex + 1, 0, {
		// 	// 		"displayUnit": false,
		// 	// 		"label": "Currency",
		// 	// 		"property": "Currency",
		// 	// 		"textAlign": "Right",
		// 	// 		"type": "string",
		// 	// 		"width": 3
		// 	// 	});
		// 	// }
		// 	if (hasPCC === "X") {
		// 		mExcelSettings.workbook.columns.push({
		// 			"displayUnit": false,
		// 			"label": "Provider Contract Cloud",
		// 			"property": "ProviderContractCloud",
		// 			"textAlign": "Right",
		// 			"type": "string",
		// 			"width": 12
		// 		});
		// 	}
		// 	if (hasServicontr === "X") {
		// 		mExcelSettings.workbook.columns.push({
		// 			"label": "Service Contract",
		// 			"property": "MultiSCId",
		// 			"textAlign": "Right",
		// 			"type": "string",
		// 			"width": 12
		// 		});
		// 	}
		// 	if (hasSOMuote === "X") {
		// 		mExcelSettings.workbook.columns.push({
		// 			"label": "Som Quote Number",
		// 			"property": "SomQuoteNumber",
		// 			"textAlign": "Right",
		// 			"type": "string",
		// 			"width": 12
		// 		});
		// 	}
		// 	if (hasSOMPc === "X") {
		// 		mExcelSettings.workbook.columns.push({
		// 			"label": "Som Provider Contract",
		// 			"property": "SomPc",
		// 			"textAlign": "Right",
		// 			"type": "string",
		// 			"width": 12
		// 		});
		// 	}
		// 	if (mUserExcelSettings.splitCells) {
		// 		mExcelSettings.workbook.columns.push({
		// 			"displayUnit": false,
		// 			"label": "Note Date",
		// 			"property": "ToGetCaseNotes/results/0/CreatedDate",
		// 			"textAlign": "Left",
		// 			"type": "Date",
		// 			"width": 10
		// 		});
		// 		mExcelSettings.workbook.columns.push({
		// 			"displayUnit": false,
		// 			"label": "Note",
		// 			"property": "ToGetCaseNotes/results/0/Content",
		// 			"textAlign": "Left",
		// 			"type": "string",
		// 			"width": 30
		// 		});
		// 		mExcelSettings.workbook.columns.push({
		// 			"displayUnit": false,
		// 			"label": "Note Modified By",
		// 			"property": "ToGetCaseNotes/results/0/PersonName",
		// 			"textAlign": "Left",
		// 			"type": "string",
		// 			"width": 25
		// 		});

		// 		// mExcelSettings.workbook.columns.push({
		// 		// 	"displayUnit": false,
		// 		// 	"label": "Note",
		// 		// 	"property": ["ToGetCaseNotes/results/0/PersonName", "ToGetCaseNotes/results/0/Content"],
		// 		// 	"template": "{1}, {0}",
		// 		// 	"textAlign": "Left",
		// 		// 	"type": "string",
		// 		// 	"width": 100
		// 		// });
		// 	} else {
		// 		MessageToast.show(this._getResourceBundleText("ExcelExportNotesMsg"), {
		// 			"duration": 10000
		// 		});
		// 		this.getView().getModel("message").setData([{
		// 			description: this._getResourceBundleText("ExcelExportNotesMsg"),
		// 			type: "Information",
		// 			title: this._getResourceBundleText("ExcelExportNotesMsgTitle")
		// 		}]);
		// 		if (hasCurrency) {
		// 			mExcelSettings.workbook.columns.splice(iCurrencyIndex + 1, 0, {
		// 				"displayUnit": false,
		// 				"label": "Currency",
		// 				"property": "Currency",
		// 				"textAlign": "Right",
		// 				"type": "string",
		// 				"width": 3
		// 			});
		// 		}
		// 	}
		// },
// End ITSDEDLC-2355 
		onAfterVariantLobMyCasesSave: function () {
			this.saveVariantDatatoBackend("CMS_SmartFilterBar_MyCases", "02", {
				"CmsCase": "1"
			});
		},

		onAfterVariantLobAllCasesSave: function () {
			this.saveVariantDatatoBackend("CMS_SmartFilterBar_AllCases", "01", {
				"CmsCase": "3"
			});
		},

		onAfterVariantLobNotAssignedSave: function () {
			this.saveVariantDatatoBackend("CMS_SmartFilterBar_NotAssigned", "32", {
				"CmsCase": "2"
			});
		},

		_getSelectedMasterTableItems: function () {
			var oTable = this._getCurrentActiveSmartTable().getTable();
			var Indices = oTable.getSelectedIndices(),
				row, aSelectedRows = [];
			for (var i = 0; i < Indices.length; i++) {
				row = oTable.getContextByIndex(Indices[i]);
				aSelectedRows.push(row);
			}
			return aSelectedRows;
		},

		_getCurrentActiveSmartTable: function () {
			var oTable, oCase = this.getOwnerComponent().getModel("AppConfig").getProperty("/HeaderVisiblitySettings");
			if (oCase.AllCases) {
				oTable = this.getView().byId("CmsSmartTable_AllCases");
				this.getOwnerComponent().getModel("AppConfig").setProperty("/oTable", oTable);
			} else if (oCase.MyCases) {
				oTable = this.getView().byId("CmsSmartTable_MyCases");
				this.getOwnerComponent().getModel("AppConfig").setProperty("/oTable", oTable);
			} else {
				oTable = this.getView().byId("CmsSmartTable_NotAssigned");
				this.getOwnerComponent().getModel("AppConfig").setProperty("/oTable", oTable);
			}
			return oTable;
		},

		_getCurrentActiveSmartVariant: function () {
			var oVM, oCase = this.getOwnerComponent().getModel("AppConfig").getProperty("/HeaderVisiblitySettings");
			if (oCase.AllCases) {
				oVM = this.getView().byId("CMS_SmartVariant_AllCases");
			} else if (oCase.MyCases) {
				oVM = this.getView().byId("CMS_SmartVariant_MyCases");
			} else {
				oVM = this.getView().byId("CMS_SmartVariant_NotAssigned");
			}
			return oVM;
		},

		openCMSAttachPopover: function (oEvent) {
			this._CMSId = oEvent.getSource().getBindingContext().getObject().CaseId;
			this._CMSGuid = oEvent.getSource().getBindingContext().getObject().CaseGuid;
			if (!this._CMSAttachmentPopover) {
				this._CMSAttachmentPopover = sap.ui.xmlfragment(this.getView().getId(),
					"c2r.o2c.cms_cases_to_review.view.fragment.popover.attachments", this);
				this.getView().addDependent(this._CMSAttachmentPopover);
				this._CMS_ContractAttachmentsTable_Template = this.getView().byId("idCMSAttachmentTableTemplate").clone();
				this._CMSAttachmentPopover.attachBeforeClose(null, function () {
					this.getView().byId("idCMSattachTable").destroyItems();
				}, this);

				this._CMSAttachmentPopover.attachBeforeOpen(null, function (oPopoverEvent) {
					var oBinding = {};
					oBinding.path = "/CmsWorklistSet(CaseId='" + this._CMSId + "',CaseGuid='" + this._CMSGuid + "')/ToCmsDocuments";
					oBinding.template = this._CMS_ContractAttachmentsTable_Template;
					oBinding.templateShareable = true;
					this.getView().byId("idCMSattachTable").bindItems(oBinding);
				}, this);
			}
			this._CMSAttachmentPopover.openBy(oEvent.getSource());
		},

		openCMSNotesPopover: function (oEvent) {
			this._CMSId = oEvent.getSource().getBindingContext().getObject().CaseId;
			this._CMSGuid = oEvent.getSource().getBindingContext().getObject().CaseGuid;
			if (!this._CMSNotesPopover) {
				this._CMSNotesPopover = sap.ui.xmlfragment(this.getView().getId(),
					"c2r.o2c.cms_cases_to_review.view.fragment.popover.notes", this);
				this.getView().addDependent(this._CMSNotesPopover);
				this._CMS_ContractNotesTable_Template = this.getView().byId("idCMSNotesTableTemplate").clone();
				this._CMSNotesPopover.attachBeforeClose(null, function () {
					this.getView().byId("idCMSNotesTable").destroyItems();
				}, this);

				this._CMSNotesPopover.attachBeforeOpen(null, function (oPopoverEvent) {
					var oBinding = {},
						aFilters = [];
					aFilters.push(new Filter("CaseGuid", FilterOperator.EQ, this._CMSGuid));
					oBinding.path = "/GetCaseNotesSet";
					oBinding.filters = aFilters;
					oBinding.template = this._CMS_ContractNotesTable_Template;
					oBinding.templateShareable = true;
					this.getView().byId("idCMSNotesTable").bindItems(oBinding);
				}, this);
			}
			this._CMSNotesPopover.openBy(oEvent.getSource());
		},

		onCMSAttachmentDownload: function (oEvent) {
			var oModelUrl = oEvent.getSource().getBindingContext().getObject();
			oModelUrl = oModelUrl.__metadata.uri;
			//oModelUrl = oModelUrl.replace("ic", "is");
			oModelUrl = oModelUrl.replace("CmsDocumentsSet", "CmsAttachmentSet");
			oModelUrl = oModelUrl + "/$value";
			window.open(oModelUrl, "_blank");
		},

		_Assign: function () {
			if (!this._oPopoverAssign) {
				this._oPopoverAssign = sap.ui.xmlfragment("c2r.o2c.cms_cases_to_review.view.fragment.AssignUser", this);
				this.getView().addDependent(this._oPopoverAssign);
			}
			return this._oPopoverAssign;
		},

		onCaseAssign: function (oEvent, sUserId, assignId) {
			var appid = this.getView().getModel("AppConfig").getProperty("/CaseTab");
			//	this.passFunctIdToXOlytics("id", "005", appid); //Xolytics

			var aSelectedItems = this._getSelectedMasterTableItems();
			var id = assignId ? assignId : oEvent.getSource()._getText();
			if (sUserId) {
				this.getView().getModel("AppConfig").setProperty("/UserId", sUserId);
			}
			if (aSelectedItems.length === 0) {
				MessageToast.show(this._getResourceBundleText("noSelection"));
				return;
			} else {
				if (id === "Assign to Me") {
					this.getView().getModel("AppConfig").setProperty("/Assign", "Me");
					//this.passFunctIdToXOlytics("id", "005", appid);
				} else if (id === "Remove Assignment") {
					this.getView().getModel("AppConfig").setProperty("/Assign", "Remove");
					//this.passFunctIdToXOlytics("id", "007", appid);
				}
				this._Assign().open();
				sap.ui.getCore().byId("id1").getBinding("items");
				this.getView().getModel("AppConfig").setProperty("/SelectedItems", aSelectedItems);
				var sConts = [];
				for (var j = 0; j < aSelectedItems.length; j++) {
					sConts.push({
						item: aSelectedItems[j].getProperty("CaseId")
					});
				}
				this.getView().getModel("AppConfig").setProperty("/selectedCases", sConts);
			}
		},
		onok: function (oEvent) {

			var R = sap.ui.getCore().byId("R1").getSelected();
			var contPer = R ? "28" : "09";
			var id = this.getView().getModel("AppConfig").getProperty("/Assign");
			if (id === "User") {
				if (contPer === "28")
					this.getView().getModel("AppConfig").setProperty("/ContPer", "28");
				else
					this.getView().getModel("AppConfig").setProperty("/ContPer", "09");
			}
			var oUserId = (id === "Me" ? "myuser" : id === "User" ? this.getView().getModel("AppConfig").getProperty("/UserId") : "");
			var aSelectedItems = this.getView().getModel("AppConfig").getProperty("/SelectedItems");
			this._Assign().close();
			this.getView().getModel("AppConfig").setProperty("/showAssignToMe", false);
			var oModel = this.getOwnerComponent().getModel();
			var oEntry = {};
			oEntry.Operation = (id === "Me" ? "M" : id === "User" ? "U" : "R");
			oEntry.UserId = oUserId;
			oEntry.ScType = contPer;
			oEntry.CaseInfo = [];
			for (var i = 0; i < aSelectedItems.length; i++) {
				oEntry.CaseInfo.push({
					"CaseId": aSelectedItems[i].getObject().CaseId,
					"CaseGuid": aSelectedItems[i].getObject().CaseGuid
				});
			}
			oEntry.CaseInfo = JSON.stringify(oEntry.CaseInfo);
			oModel.callFunction("/AssignCMSCaseToUser", {
				method: "POST",
				urlParameters: oEntry,
				//Begin of changes by I353877 for XOlytice Performance
				success: function (data, response) {
					//this.savePerformanceMatrixXOlytics(oModel, response);
				}
			});
			this._getCurrentActiveSmartTable().getTable().clearSelection();
			this._getCurrentActiveSmartTable().setBusy(true);
			// }
		},

		handleLinkPress: function (oEvent) {
			this.getView().getModel("AppConfig").setProperty("/showAssignToMe", true);
		},

		onAssignCancel: function (oEvent) {
			this.getView().getModel("AppConfig").setProperty("/showAssignToMe", false);
			this._Assign().close();
		},

		_AssignContract: function () {
			if (!this._oPopoverAssignContract) {
				this._oPopoverAssignContract = sap.ui.xmlfragment("c2r.o2c.cms_cases_to_review.view.fragment.AssignUserContract", this);
				this.getView().addDependent(this._oPopoverAssignContract);
			}
			return this._oPopoverAssignContract;
		},

		onSubmit: function (oEvent) {
			var aSelectedItems = this._getSelectedMasterTableItems();
			if (aSelectedItems.length === 0) {
				MessageToast.show(this.oMessage.getText("noSelection"));
				return;
			} else {
				var id = oEvent.getSource()._getText();
				if (id === "Assign to User") {
					this.getView().getModel("AppConfig").setProperty("/Assign", "User");
				}
				this.onCaseAssignToUser(oEvent);
			}
		},

		// _onok: function (oEvent) {
		// 	this._AssignContract().close();
		// 	var id = this.getView().getModel("AppConfig").getProperty("/Assign");
		// 	var R = sap.ui.getCore().byId("R_1").getSelected();
		// 	var contPer = R ? "28" : "09";
		// 	if (id === "User") {
		// 		if (contPer === "28")
		// 			this.getView().getModel("AppConfig").setProperty("/ContPer", "28");
		// 		else
		// 			this.getView().getModel("AppConfig").setProperty("/ContPer", "09");

		// 		this.onCaseAssignToUser(oEvent, contPer);
		// 	}
		// },

		onCaseAssignToUser: function (oEvent, contPer) {
			var appid = this.getView().getModel("AppConfig").getProperty("/CaseTab");
			//this.passFunctIdToXOlytics("id", "006", appid); //Xolytics

			if (!this._oUserSelectionDialog) {
				this._oUserSelectionDialog = sap.ui.xmlfragment(this.getView().getId(),
					"c2r.o2c.cms_cases_to_review.view.fragment.UserSelection", this);
				this.getView().byId("CmsMasterDynamicPageHeader").addContent(this._oUserSelectionDialog);
			}
			this._oUserSelectionDialog.open();
		},

		// onRemoveAssignment: function (oEvent, contPer) {

		// 	this.passFunctIdToXOlytics("id", "007"); //Xolytics

		// 	var aSelectedItems = this._getSelectedMasterTableItems();
		// 	if (aSelectedItems.length === 0) {
		// 		MessageToast.show(this.oMessage.getText("allContReview.noSelection"));
		// 		return;
		// 	} else {
		// 		var sConts = "";
		// 		sConts = "<ul>";
		// 		for (var i = 0; i < aSelectedItems.length; i++) {
		// 			sConts += "<li> " + aSelectedItems[i].getProperty("CaseId") + "</li>";
		// 		}
		// 		sConts += "</ul>";
		// 		var oPopUpText = this.oMessage.getText("allContReview.removeAssign.confirm.message");
		// 		var oPopUpTitle = this.oMessage.getText("allContReview.removeAssign");
		// 		this.updateBackend(oPopUpText, oPopUpTitle, sConts, aSelectedItems, "R", " ", contPer);
		// 	}
		// },

		onStartBooking: function () { // Button Acton Start Booking 

			//this.passFunctIdToXOlytics("id", "008", "02"); //Xolytics
			this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", true);
			this.oModel = this.getOwnerComponent().getModel();
			var aSelectedItems = this._getSelectedMasterTableItems();
			var oSelectedRow = aSelectedItems[0].getObject();
			var bChangeBookingStatus = false;
			var oModel = this.getOwnerComponent().getModel();
			// C4C Opportunity number URL 
			if (oSelectedRow.C4cOppFlag) {
				this._oBusinessObjectHyperLink._openC4CSystem({
					"id": oSelectedRow.Oppn
				});
				this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
			} else {
				// if (oSelectedRow.QuoteFlag === "CPQ") {
				// 	this._oBusinessObjectHyperLink._openCMSCase(oSelectedRow.CaseGuid);
				// 	this._oBusinessObjectHyperLink._openQuotation({
				// 		"Deal": oSelectedRow.Oppn,
				// 		"type": oSelectedRow.QuoteFlag,
				// 		"id": oSelectedRow.RefQuote
				// 	});
				if (oSelectedRow.QuoteFlag === "CPQ" && (oSelectedRow.SwStatus === "ZCC7" || oSelectedRow.SwStatus ===
						"ZO2C" || oSelectedRow.SwStatus ===
						"REST")) {
					bChangeBookingStatus = true;
					if (bChangeBookingStatus) {
						var oEntry = {};
						oEntry.CaseId = oSelectedRow.CaseId;
						oEntry.CaseGuid = oSelectedRow.CaseGuid;
						oEntry.SwStatus = oSelectedRow.SwStatus;
						oEntry.RefQuote = oSelectedRow.RefQuote;
						oEntry.CmsCase = "S";
						oModel.update(aSelectedItems[0].getPath(), oEntry, {
							success: function (data, response) {
								MessageToast.show(this._getResourceBundleText("allContReview.StartBookSucess"));
								this._oBusinessObjectHyperLink._openCMSCase(oSelectedRow.CaseGuid);
								this._oBusinessObjectHyperLink._openQuotation({
									"Deal": oSelectedRow.Oppn,
									"type": oSelectedRow.QuoteFlag,
									"id": oSelectedRow.RefQuote
								});
								this.openContractValidationOnBooking(oSelectedRow.Cmsstatus, oSelectedRow.CaseGuid, oSelectedRow.CaseId, oSelectedRow.RefQuote);
								this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
							}.bind(this),
							error: function (oError) {
								MessageToast.show(this._getResourceBundleText("allContReview.StartBookFail"));
								this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
							}.bind(this)
						});
					} else {
						MessageToast.show(this._getResourceBundleText("allContReview.StartBook.StatusMsg"));
						this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
					}
					//	}
				} else if (oSelectedRow.QuoteFlag === "Q2C") {
					switch (oSelectedRow.Lob) {
					case "OP": // On_Primen LOB Old Environment Process
						if (oSelectedRow.SwStatus === "REQU" || oSelectedRow.SwStatus === "ZO2C") {
							bChangeBookingStatus = true;
							if (bChangeBookingStatus) {
								this.getBookinginfo(aSelectedItems, oSelectedRow, "S", "allContReview.StartBookSucess");
							}
						} else {
							this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
						}
					case "CL":
						if (oSelectedRow.SwStatus === "REQU" || oSelectedRow.SwStatus === "REST") {
							bChangeBookingStatus = true;
							if (bChangeBookingStatus) {
								this.getBookinginfo(aSelectedItems, oSelectedRow, "S", "allContReview.StartBookSucess");
							} else {
								MessageToast.show(this._getResourceBundleText("allContReview.StartBook.StatusMsg"));
								this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
							}
						} else {
							this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
						}
						break;
					case "SR": // Serivice LOB Old Environment
						this.openStartBookingTriggers(oSelectedRow, "S");
						break;
					case "AL": // Serivice LOB Old Environment 
						MessageBox.error(this._getResourceBundleText("allContReview.StartBook.LobMsg"));
						this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
						break;
					default:
						this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
						break;
					}
				} else {
					if (oSelectedRow.Lob === "OP") {
						sap.m.URLHelper.redirect(Constants.HTTP + this._oBusinessObjectHyperLink._getCRMDomain() + Constants.URLYMON, true);
					}
					this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
				}

				this._getCurrentActiveSmartTable().getTable().clearSelection();
				this.getView().getModel("AppConfig").setProperty("/StartBookingFlag", false);
			}
		},

		openStartBookingTriggers: function (oSelectedRow, sFlag) {
			if (sFlag === "S") {
				if (oSelectedRow.QuoteGuid) {
					this._oBusinessObjectHyperLink._openQuotation({
						"Deal": oSelectedRow.Oppn,
						"type": oSelectedRow.QuoteFlag,
						"guid": oSelectedRow.QuoteGuid
					});
				} else if (oSelectedRow.RefQuote) {
					this._oBusinessObjectHyperLink._openERPQuotation({
						"id": oSelectedRow.RefQuote
					});
				}
			} else {
				if (oSelectedRow.Lob === 'CL') {
					this._oBusinessObjectHyperLink._openProviderContract({
						LOB: '',
						guid: oSelectedRow.ProviderContractCloudGuid //oSource.data("guid")
					});
				} //else {  // code changes commented start for US ITSDEDLC-1133
				// 	this._oBusinessObjectHyperLink._openProviderContract({
				// 		LOB: '',
				// 		guid: oSelectedRow.ProviderContractOnPremGuid //oSource.data("guid")
				// 	});
				// } code changes commented end for US ITSDEDLC-1133
			}
			this._oBusinessObjectHyperLink._openCMSCase(oSelectedRow.CaseGuid);
			this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
		},

		onHeaderTableSelectionChange: function (oEvent) {
			if (oEvent.getSource().getSelectedIndices().length === 1) {
				this.getView().getModel("AppConfig").setProperty("/StartBookingFlag", true);
				this.getView().getModel("AppConfig").setProperty("/BookingFlag", true);
			} else {
				this.getView().getModel("AppConfig").setProperty("/StartBookingFlag", false);
				this.getView().getModel("AppConfig").setProperty("/BookingFlag", false);
			}
			this.OnRowSelection(oEvent);
		},

		updateBackend: function (oPopUpText, oPopUpTitle, oPopUpdetails, aSelectedItems, oCmsCase, oUserId, contPer) {
			MessageBox.confirm(oPopUpText, {
				icon: MessageBox.Icon.CONFIRM,
				title: oPopUpTitle,
				details: oPopUpdetails,
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				onClose: function (oAction) {
					if (oAction === "YES") {
						var oModel = this.getOwnerComponent().getModel();
						var oEntry = {};
						oEntry.Operation = oCmsCase;
						oEntry.UserId = oUserId;
						oEntry.ScType = contPer;
						oEntry.CaseInfo = [];
						for (var i = 0; i < aSelectedItems.length; i++) {
							oEntry.CaseInfo.push({
								"CaseId": aSelectedItems[i].getObject().CaseId,
								"CaseGuid": aSelectedItems[i].getObject().CaseGuid
							});
						}
						oEntry.CaseInfo = JSON.stringify(oEntry.CaseInfo);
						oModel.callFunction("/AssignCMSCaseToUser", {
							method: "POST",
							urlParameters: oEntry,

							//Begin of changes by I353877 for XOlytice Performance
							// success: function (data, response) {
							// 		 this.savePerformanceMatrixXOlytics(oModel, response);
							// 	}
							//End of changes by I353877 for XOlytice Performance
						});
						this._getCurrentActiveSmartTable().getTable().clearSelection();
						this._getCurrentActiveSmartTable().setBusy(true);
					}
				}.bind(this)
			});
		},

		handleUserSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oBinding = oEvent.getSource().getBinding("items");
			var oFilter;
			if (isNaN(Number(sValue.substr(1)))) {
				oFilter = new Filter("FullName", FilterOperator.Contains, sValue);
			} else {
				sValue = sValue.toLocaleUpperCase();
				oFilter = new Filter("UserId", FilterOperator.Contains, sValue);
			}
			oBinding.filter(oFilter);
		},

		onUserSelectionAssignment: function (oEvent) {
			var sUserId = oEvent.getParameter("selectedItem").getBindingContext().getProperty("UserId");
			oEvent.getSource().getBinding("items").filter([]);
			var aSelectedItems = this._getSelectedMasterTableItems();
			var id = this.getView().getModel("AppConfig").getProperty("/Assign");
			if (aSelectedItems.length === 0) {
				MessageToast.show(this._getResourceBundleText("noSelection"));
				return;
			} else {
				this.onCaseAssign(oEvent, sUserId, id);
				// var sConts = "";
				// this.oModel = this.getOwnerComponent().getModel();
				// sConts = "<ul>";
				// for (var i = 0; i < aSelectedItems.length; i++) {
				// 	sConts += "<li> " + aSelectedItems[i].getProperty("CaseId") + "</li>";
				// }
				// sConts += "</ul>";
				// var oPopUpText = this._getResourceBundleText("allContReview.assignToUser.confirm.message", [sUserId]);
				// var oPopUpTitle = this._getResourceBundleText("allContReview.assignToUser", [sUserId]);
				// this.updateBackend(oPopUpText, oPopUpTitle, sConts, aSelectedItems, "U", sUserId, conPerson);
			}
		},

		onFilterChange: function (oEvent) {
			var oTable = this.getView().byId("CmsSmartTable_AllCases");
			oTable.setBusy(false);
			oTable.setBlocked(false);
			oTable.getTable().setBusy(false);
			oTable.getTable().setBlocked(false);
		},

		getProviderContractTextForTable: function (ProviderContractOnPrem, ProviderContractCloud) {
			if (ProviderContractOnPrem && ProviderContractCloud) {
				return "Multiple PC's";
			} else if (ProviderContractOnPrem) {
				return ProviderContractOnPrem;
			} else if (ProviderContractCloud) {
				return ProviderContractCloud;
			}
			return "";
		},

		getserviceContract: function (ServiceContractDetails) {
			var serviceContractDetails = new Array();
			var temp;
			var elements = ServiceContractDetails.split(",");
			for (var element in elements) {
				temp = elements[element].split(":");
				serviceContractDetails.push({
					item: temp[1],
					guid: temp[0]
				});
			}
			return serviceContractDetails;
		},
		getsomQuote: function (SomQuoteDetails) {
			var somQuoteDetails = new Array();
			var temp;
			var elements = SomQuoteDetails.split(",");
			for (var element in elements) {
				temp = elements[element].split(":");
				somQuoteDetails.push({
					item: temp[1],
					guid: temp[0]
				});
			}
			return somQuoteDetails;
		},
		getServiceContractTextForTable: function (ServiceContractDetails) {
			var that = this;
			if (ServiceContractDetails) {
				var servicecontractDetails = that.getserviceContract(ServiceContractDetails);
				if (servicecontractDetails.length > 1) {
					return "Multiple SC's";
				} else {
					return servicecontractDetails[0].item;
				}
			}

			// if (ServiceContractId && ServiceContractId2) {
			// 	return "Multiple SC's";
			// } else if (ServiceContractId) {
			// 	return ServiceContractId;
			// } else if (ServiceContractId2) {
			// 	return ServiceContractId2;
			// }
			return "";
		},
		getSomQuoteTextForTable: function (SomQuoteDetails, flag) {

			var that = this;
			if (SomQuoteDetails) {
				var somquoteDetails = that.getsomQuote(SomQuoteDetails);
				if (somquoteDetails.length > 1) {
					if (flag === 'X') {
						return "Multiple SOM Quote's";
					} else {
						return "Multiple SOM PC's";
					}

				} else {
					return somquoteDetails[0].item;
				}
			}
			return "";
		},

		openProviderContract: function (oEvent) {
			var oSource = oEvent.getSource();
			if (oSource.getText().indexOf("Multiple") !== -1) {
				if (!this._PCLinks) {
					this._PCLinks = sap.ui.xmlfragment(this.getView().getId(),
						"c2r.o2c.cms_cases_to_review.view.fragment.popover.ProviderContractsList", this);
					this.getView().addDependent(this._PCLinks);
				}
				this._PCLinks.openBy(oSource);
				this.getView().getModel("AppConfig").setProperty("/CurrentPC_Onprem", {
					LOB: '',
					id: oSource.getBindingContext().getProperty("ProviderContractOnPrem"),
					guid: oSource.getBindingContext().getProperty("ProviderContractOnPremGuid")
				});
				this.getView().getModel("AppConfig").setProperty("/CurrentPC_Cloud", {
					LOB: '',
					id: oSource.getBindingContext().getProperty("ProviderContractCloud"),
					guid: oSource.getBindingContext().getProperty("ProviderContractCloudGuid")
				});
			} else {
				this._oBusinessObjectHyperLink._openProviderContract({
					LOB: '',
					guid: oSource.data("guid")
				});
			}
		},

		openServiceContract: function (oEvent) {

			var oSource = oEvent.getSource();
			if (oSource.getText().indexOf("Multiple") !== -1) {
				if (!this._SCLinks) {
					this._SCLinks = sap.ui.xmlfragment(this.getView().getId(),
						"c2r.o2c.cms_cases_to_review.view.fragment.popover.ServiceContractsList", this);
					this.getView().addDependent(this._SCLinks);
				}
				this._SCLinks.openBy(oSource);
				var servicecontractDetails = this.getserviceContract(oSource.getBindingContext().getProperty("MultiServiceContr"));
				this.getView().getModel("AppConfig").setProperty("/CurrentSC", {
					LOB: 'SR',
					id: servicecontractDetails,
					guid: servicecontractDetails
				});
			} else {
				this._oBusinessObjectHyperLink._openProviderContract({
					LOB: 'SR',
					guid: oSource.data("guid")
				});
			}
		},

		openSomQuote: function (oEvent, mflag) {
			var oSource = oEvent.getSource();
			if (oSource.getText().indexOf("Multiple") !== -1) {

				if (mflag === 'quote') {
					if (!this._SQLinks) {
						this._SQLinks = sap.ui.xmlfragment(this.getView().getId(),
							"c2r.o2c.cms_cases_to_review.view.fragment.popover.SOMQuoteList", this);
						this.getView().addDependent(this._SQLinks);
					}
					this._SQLinks.openBy(oSource);
					var somquoteDetails = this.getsomQuote(oSource.getBindingContext().getProperty("SomQuoteGuid"));
				} else {
					if (!this._PCLinks) {
						this._PCLinks = sap.ui.xmlfragment(this.getView().getId(),
							"c2r.o2c.cms_cases_to_review.view.fragment.popover.SOMPcList", this);
						this.getView().addDependent(this._PCLinks);
					}
					this._PCLinks.openBy(oSource);
					somquoteDetails = this.getsomQuote(oSource.getBindingContext().getProperty("SomPcGuid"));
				}

				this.getView().getModel("AppConfig").setProperty("/CurrentSQ", {
					LOB: '',
					id: somquoteDetails,
					guid: somquoteDetails
				});
			} else {
				this._oBusinessObjectHyperLink._openSomQuote({
					LOB: '',
					guid: oSource.data("guid"),
					flag: mflag
				});
			}
		},

		getProviderContractguid: function (onPremGuid, cloudGuid) {
			if (onPremGuid && cloudGuid) {
				return "";
			} else if (onPremGuid) {
				return onPremGuid;
			} else if (cloudGuid) {
				return cloudGuid;
			}
			return "";
		},

		getServiceContractguid: function (guidDetails) {
			if (guidDetails) {
				var servicecontractDetails = this.getserviceContract(guidDetails);
				if (servicecontractDetails.length > 1) {
					return "Multiple";
				} else {
					return servicecontractDetails[0].guid;
				}
			}
			// var numguid1 = Number(guid1);
			// if (isNaN(numguid1)) {
			// 	numguid1 = guid1.length;
			// }
			// var numguid2 = Number(guid2) && guid2.length;
			// if (isNaN(numguid2)) {
			// 	numguid2 = guid2.length;
			// }
			// if (numguid1 && numguid2) {
			// 	return "Multiple";
			// } else if (numguid1) {
			// 	return guid1;
			// } else if (numguid2) {
			// 	return guid2;
			// }
			return "";
		},

		getSomQuoteguid: function (guidDetails) {
			if (guidDetails) {
				var somquoteDetails = this.getsomQuote(guidDetails);
				if (somquoteDetails.length > 1) {
					return "Multiple";
				} else {
					return somquoteDetails[0].guid;
				}
			}

			return "";
		},

		// Smart Filter Bar Go Event
		// OnGoPress: function () {
		// 	this.gopress = true;
		// },

		handleUserSearchClose: function (oEvent) {
			oEvent.getSource().removeAllItems();
		},
		OnRequWithExcep: function () { // Button Action Book 
			var that = this;
			this.oModel = this.getOwnerComponent().getModel();
			this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", true);
			var aSelectedItems = this._getSelectedMasterTableItems();
			var oSelectedRow = aSelectedItems[0].getObject();
			var bChangeBookingStatus = false;
			// code change start for ITSDEDLC-1077
			var mainpricelckExcep = oSelectedRow.MaintnPriceLock;
			if (mainpricelckExcep === "X") {
				var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				MessageBox.confirm(oResourceBundle.getText("Maintpricelck"), {
					icon: MessageBox.Icon.CONFIRM,
					title: oResourceBundle.getText("Opopupmainprclck"),
					// details: oPopUpdetails,
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === "YES") {
							if (oSelectedRow.QuoteFlag === "CPQ" && (oSelectedRow.SwStatus === "ZCC7" || oSelectedRow.SwStatus ===
									"ZO2C" || oSelectedRow.SwStatus === "INPR" || oSelectedRow.SwStatus === "REST")) {
								bChangeBookingStatus = true;
								if (bChangeBookingStatus) {
									that.getBookinginfo(aSelectedItems, oSelectedRow, "Z", "allContReview.BookExcepSucess");
								}
							} else {
								that.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
							}
							that._getCurrentActiveSmartTable().getTable().clearSelection();
							that.getView().getModel("AppConfig").setProperty("/BookingFlag", false);
						}
						that.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
						that._getCurrentActiveSmartTable().getTable().clearSelection();
					}.bind(this)
				});
			} else {
				if (oSelectedRow.QuoteFlag === "CPQ" && (oSelectedRow.SwStatus === "ZCC7" || oSelectedRow.SwStatus ===
						"ZO2C" || oSelectedRow.SwStatus === "INPR" || oSelectedRow.SwStatus === "REST")) {
					bChangeBookingStatus = true;
					if (bChangeBookingStatus) {
						this.getBookinginfo(aSelectedItems, oSelectedRow, "Z", "allContReview.BookExcepSucess");
					}
				} else {
					this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
				}
				this._getCurrentActiveSmartTable().getTable().clearSelection();
				this.getView().getModel("AppConfig").setProperty("/BookingFlag", false);

			}
			// code changes end for ITSDEDLC-1077
		},

		OnRequForBooking: function () { // Button Acton Booking 
			var that = this;
			this.oModel = this.getOwnerComponent().getModel();
			this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", true);
			var aSelectedItems = this._getSelectedMasterTableItems();
			var oSelectedRow = aSelectedItems[0].getObject();
			var bChangeBookingStatus = false;
			// code change start for IITSDEDLC-1077
			var mainpricelck = oSelectedRow.MaintnPriceLock;
			if (mainpricelck === "X") {
				var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				MessageBox.confirm(oResourceBundle.getText("Maintpricelck"), {
					icon: MessageBox.Icon.CONFIRM,
					title: oResourceBundle.getText("Opopupmainprclck"),
					// details: oPopUpdetails,
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === "YES") {
							if (oSelectedRow.QuoteFlag === "CPQ" && (oSelectedRow.SwStatus === "ZCC7" || oSelectedRow.SwStatus ===
									"ZO2C" || oSelectedRow.SwStatus === "INPR" || oSelectedRow.SwStatus === "REST")) {
								bChangeBookingStatus = true;
								if (bChangeBookingStatus) {
									that.getBookinginfo(aSelectedItems, oSelectedRow, "Q", "allContReview.BookSucess");
								}
							} else {
								that.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
							}
							that._getCurrentActiveSmartTable().getTable().clearSelection();
							that.getView().getModel("AppConfig").setProperty("/BookingFlag", false);
						}
						that.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
						that._getCurrentActiveSmartTable().getTable().clearSelection();
					}.bind(this) 
				});
			} else {
				if (oSelectedRow.QuoteFlag === "CPQ" && (oSelectedRow.SwStatus === "ZCC7" || oSelectedRow.SwStatus ===
						"ZO2C" || oSelectedRow.SwStatus === "INPR" || oSelectedRow.SwStatus === "REST")) {
					bChangeBookingStatus = true;
					if (bChangeBookingStatus) {
						this.getBookinginfo(aSelectedItems, oSelectedRow, "Q", "allContReview.BookSucess");
					}
				} else {
					this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
				}
				this._getCurrentActiveSmartTable().getTable().clearSelection();
				this.getView().getModel("AppConfig").setProperty("/BookingFlag", false);

			}
			// code changes end for ITSDEDLC-1077
		},
		getBookinginfo: function (aSelectedItems, oSelectedRow, CmsCase, aText) {
			var oModel = this.getOwnerComponent().getModel();
			var oEntry = {};
			oEntry.CaseId = oSelectedRow.CaseId;
			oEntry.CaseGuid = oSelectedRow.CaseGuid;
			oEntry.SwStatus = oSelectedRow.SwStatus;
			oEntry.RefQuote = oSelectedRow.RefQuote;
			oEntry.CmsCase = CmsCase;
			oModel.update(aSelectedItems[0].getPath(), oEntry, {
				success: function (data, response) {
					MessageToast.show(this._getResourceBundleText(aText));
					this.openStartBookingTriggers(oSelectedRow, CmsCase);
				}.bind(this),
				error: function (oError) {
					MessageToast.show(this._getResourceBundleText("allContReview.StartBookFail"));
					this.getOwnerComponent().getModel("AppConfig").setProperty("/myCasesTableBusy", false);
				}.bind(this)
			});
			//	
		},
		//ITSDEDLC-559
		OnRowSelection: function (oEvent) {
			var aSelectedItems = this._getSelectedMasterTableItems();
			if (aSelectedItems.length === 0) {
				this.getView().byId("idcontractvalidation").setEnabled(false);
				this.getView().byId("idgtsblock").setEnabled(false);
			}
			// var oSelectedRow = aSelectedItems[0].getObject();
			var iSelect = oEvent.getSource().getSelectedIndices().length;
			var sCase_View = this.getView().getModel("AppConfig").getProperty("/SelectedCase");
			if (iSelect > 0) {
				switch (sCase_View) {
				case 'AllCases':
					this.getView().getModel("AppConfig").setProperty("/AllCaseView", this.getSelectedCase());
					if (aSelectedItems.length > 1) {
						this.getView().byId("idcontractvalidation").setEnabled(false);
						this.getView().byId("idgtsblock").setEnabled(false);
					} else if (aSelectedItems.length === 1) {
						this.getView().byId("idcontractvalidation").setEnabled(true);
						this.getView().byId("idgtsblock").setEnabled(true);
					}
					break;
				case 'MyCases':
					this.getView().getModel("AppConfig").setProperty("/MyCaseView", this.getSelectedCase());
					this.getView().getModel("AppConfig").setProperty("/StartBookingFlag", true);
					this.getView().getModel("AppConfig").setProperty("/BookingFlag", true);
					if (aSelectedItems.length > 1) {
						this.getView().byId("idcontractvalidation").setEnabled(false);
						this.getView().byId("idgtsblock").setEnabled(false);
					} else if (aSelectedItems.length === 1) {
						this.getView().byId("idcontractvalidation").setEnabled(true);
						this.getView().byId("idgtsblock").setEnabled(true);
					}
					var oSelectedRow = aSelectedItems[0].getObject();
					if (oSelectedRow.QuoteSource === "CPQ Quote" && iSelect === 1) {
						this.getView().getModel("AppConfig").setProperty("/BookingFlag", true);
					} else {
						this.getView().getModel("AppConfig").setProperty("/BookingFlag", false);
					}
					break;
				case 'NotAssigned':
					this.getView().getModel("AppConfig").setProperty("/NotAssignView", this.getSelectedCase());
					if (aSelectedItems.length > 1) {
						this.getView().byId("idcontractvalidation").setEnabled(false);
						this.getView().byId("idgtsblock").setEnabled(false);
					} else if (aSelectedItems.length === 1) {
						this.getView().byId("idcontractvalidation").setEnabled(true);
						this.getView().byId("idgtsblock").setEnabled(true);
					}
					break;
				}
				this.getView().getModel("AppConfig").setProperty("/Material", true);
				if (iSelect === 1) {

					this.getView().getModel("AppConfig").setProperty("/Customer", true);
				} else {

					this.getView().getModel("AppConfig").setProperty("/Customer", false);
				}
			} else {
				switch (sCase_View) {
				case 'AllCases':
					this.getView().getModel("AppConfig").setProperty("/AllCaseView", '');
					break;
				case 'MyCases':
					this.getView().getModel("AppConfig").setProperty("/MyCaseView", '');
					break;
				case 'NotAssigned':
					this.getView().getModel("AppConfig").setProperty("/NotAssignView", '');
					break;
				}
				this.getView().getModel("AppConfig").setProperty("/Material", false);
				this.getView().getModel("AppConfig").setProperty("/Customer", false);

			}
		},

		_Status: function () {
			if (!this._oPopoverMaterial) {
				this._oPopoverMaterial = sap.ui.xmlfragment("c2r.o2c.cms_cases_to_review.view.fragment.CheckMaterialStatus", this);
				this.getView().addDependent(this._oPopoverMaterial);
			}
			return this._oPopoverMaterial;
		},
		onCancel: function (oEvent) {
			var oMMTable = sap.ui.getCore().byId("CMS_MaterialTable");
			sap.ui.getCore().byId("idCreateMMticket").setEnabled(false);
			sap.ui.getCore().byId("idAssignMMticket").setEnabled(true);
			oMMTable.removeSelections(true);
			this._Status().close();
		},
		onCheckMaterialStatus: function (oEvent) {
			var appid = this.getView().getModel("AppConfig").getProperty("/CaseTab");
			//this.passFunctIdToXOlytics("id", "021", appid); //Xolytics
			var aSelectedItems = this._getSelectedMasterTableItems();
			var sQuote = "";
			var aFilters = [];
			this.getView().getModel("AppConfig").setProperty("/SelectedItems", aSelectedItems);
			for (var i = 0; i < aSelectedItems.length; i++) {
				sQuote = aSelectedItems[i].getProperty("RefQuote");
				if (sQuote) {
					aFilters.push(new Filter("RefQuote", FilterOperator.EQ, sQuote));
				}
			}
			this._Status().open();
			sap.ui.getCore().byId("CMS_MaterialTable").getBinding("items").filter(aFilters);

		},
		onAssignMMTicket: function (oEvent) {
			var that = this;
			var aSelectedItems = this.getView().getModel("AppConfig").getProperty("/SelectedItems");
			var oMMTable = sap.ui.getCore().byId("CMS_MaterialTable");
			var oMMSelectedItems = oMMTable.getSelectedItems();
			if (oMMTable.getItems().length === 0) {
				MessageToast.show(this._getResourceBundleText("Nodata"));
			} else if (aSelectedItems.length > 1 && oMMSelectedItems.length === 0) {
				MessageBox.error(this._getResourceBundleText("AssignMmTicketErrorMsg1"));
			} else {
				for (var j = 0; j < aSelectedItems.length; j++) {
					this.oSRefquote = aSelectedItems[j].getProperty("RefQuote");
					this.oSMmticket = aSelectedItems[j].getProperty("Mmticketnum");
					if ((this.oSQuote === this.oSRefquote)) {
						this.caseGuiId = aSelectedItems[j].getProperty("CaseGuid");
						if (this.oSMmticket) {
							MessageBox.error(this._getResourceBundleText("MmTicketErrorMsg"));
							break;
						}
						if (!this.oAssignMmTicket) {
							this.oAssignMmTicket = sap.ui.xmlfragment(this.getView().getId(), "c2r.o2c.cms_cases_to_review.view.fragment.AssignMmTicket",
								this);
							this.getView().addDependent(this.oAssignMmTicket);
						}
						this.oAssignMmTicket.openBy(oEvent.getSource());
					}
					if ((aSelectedItems.length === 1 && oMMSelectedItems.length === 0)) {
						this.caseGuiId = aSelectedItems[0].getProperty("CaseGuid");
						this.oSMmticket = aSelectedItems[0].getProperty("Mmticketnum");
						if (this.oSMmticket) {
							MessageBox.error(this._getResourceBundleText("MmTicketErrorMsg"));
							break;
						}
						if (!this.oAssignMmTicket) {
							this.oAssignMmTicket = sap.ui.xmlfragment(this.getView().getId(), "c2r.o2c.cms_cases_to_review.view.fragment.AssignMmTicket",
								this);
							this.getView().addDependent(this.oAssignMmTicket);
						}
						this.oAssignMmTicket.openBy(oEvent.getSource());
					}
				}
			}

		},
		handleAssignMmSubmitPress: function (oEvent) {
			var that = this;
			var MmticketId = this.getView().byId("idMMinput").getValue();
			if (MmticketId) {
				that._Status().close();
				var Mmflag = "A";
				that.OnMmTicket(MmticketId, Mmflag);
			} else {
				MessageBox.error(that._getResourceBundleText("AssignMmTicketErrorMsg"));
			}

		},
		onCreateMMTicket: function (oEvent) {
			var that = this;
			var sMaterial = this.oMaterials.join();
			var sQuote = this.oSQuote;
			var oUser = sap.ushell.Container.getService("UserInfo").getId();
			var aSelectedItems = this.getView().getModel("AppConfig").getProperty("/SelectedItems");
			for (var j = 0; j < aSelectedItems.length; j++) {
				this.oSRefquote = aSelectedItems[j].getProperty("RefQuote");
				this.oSMmticket = aSelectedItems[j].getProperty("Mmticketnum");
				if ((this.oSQuote === this.oSRefquote)) {
					this.caseGuiId = aSelectedItems[j].getProperty("CaseGuid");
					if (this.oSMmticket) {
						MessageBox.error(this._getResourceBundleText("MmTicketErrorMsg"));
						break;
					} else {
						this._Status().close();
						var Headerdata = {};
						Headerdata.Scenario = this._getResourceBundleText("MMScenario");
						Headerdata.ConcLines = this._getResourceBundleText("MMConcLines", [sMaterial, sQuote]);
						Headerdata.Reporter = oUser;
						Headerdata.Requestor = oUser;
						Headerdata.Prio = this._getResourceBundleText("MMPrio");
						Headerdata.CatId = this._getResourceBundleText("MMCatId");
						Headerdata.Description = this._getResourceBundleText("MMDescription", [sQuote]);
						var oSalesDirectModel = this.getOwnerComponent().getModel("salesDirectModel");
						oSalesDirectModel.create("/Generic_Api_HeaderSet", Headerdata, {
							success: function (oData) {
								var MmticketId = oData.ObjectId;
								that.OnMmTicket(MmticketId);
							}
						});
					}
				}
			}
		},
		OnMmTicket: function (MmticketId, Mmflag) {
			var that = this;
			var oMMTable = sap.ui.getCore().byId("CMS_MaterialTable");
			var oMMTicketDetails = {};
			oMMTicketDetails.MMTicket = MmticketId;
			oMMTicketDetails.CaseGuid = that.caseGuiId;
			var oModel = that.getOwnerComponent().getModel();
			oModel.callFunction("/AssignMMTicketToCase", {
				method: "POST",
				urlParameters: oMMTicketDetails,
				success: function (oData) {
					if (Mmflag === "A") {
						MessageToast.show(that._getResourceBundleText("SalesDirectNumberAssign", [oMMTicketDetails.MMTicket]));
						that.getView().byId("idMMinput").setValue(null);
						that.getView().byId("idMMinput").setValueState(sap.ui.core.ValueState.None);
					} else {
						MessageToast.show(that._getResourceBundleText("SalesDirectNumber", [oMMTicketDetails.MMTicket]));
					}
					sap.ui.getCore().byId("idCreateMMticket").setEnabled(false);
					oMMTable.removeSelections(true);
					that.getOwnerComponent().getModel().refresh();
				}
			});
			that._getCurrentActiveSmartTable().getTable().clearSelection();
		},
		onOpenMMTicket: function (oEvent) {
			var MmTicketId = oEvent.getSource().getText();
			this._oBusinessObjectHyperLink._openMmTicketNew(MmTicketId);

		},
		onLiveChangeMmticket: function (oEvent) {
			var oInputMM = oEvent.getSource(),
				oInputValue = oInputMM.getValue(),
				iValueLength = oInputValue.length,
				iMaxLength = 10,
				iRemainingLength = iMaxLength - iValueLength,
				sStateText = "NumbersLeft " + iRemainingLength,
				sStateText1 = "please enter less than 10 Digits only",
				sState;
			if ((iValueLength === iMaxLength) || (iValueLength === (iMaxLength - 1))) {
				sState = 'Success';
				this.getView().byId("idButtonAssignMM").setEnabled(true);
				oInputMM.setValueState(sState);
				oInputMM.setValueStateText(sStateText);

			} else if ((iValueLength < (iMaxLength - 1))) {
				sState = 'Warning';
				this.getView().byId("idButtonAssignMM").setEnabled(true);
				oInputMM.setValueState(sState);
				oInputMM.setValueStateText(sStateText);
			} else if ((iValueLength > iMaxLength)) {
				sState = 'Error';
				this.getView().byId("idButtonAssignMM").setEnabled(false);
				oInputMM.setValueState(sState);
				oInputMM.setValueStateText(sStateText1);
			}

		},
		onChangeSelection: function (oEvent) {
			var that = this;
			var oMMTable = sap.ui.getCore().byId("CMS_MaterialTable");
			var oMMSelectedItems = oMMTable.getSelectedItems();
			var aSelectedItems = this.getView().getModel("AppConfig").getProperty("/SelectedItems");
			this.oMaterials = [];
			var oSQuotes = [];
			for (var i = 0; i < oMMSelectedItems.length; i++) {
				this.oMaterial = oMMSelectedItems[i].getBindingContext().getObject("MaterialNum");
				this.oSQuote = oMMSelectedItems[i].getBindingContext().getObject("RefQuote");
				this.oMaterials = this.oMaterials.concat(this.oMaterial);
				oSQuotes = oSQuotes.concat(this.oSQuote);
				if (oSQuotes[i - 1] === undefined || oSQuotes[i - 1] === oSQuotes[i]) {
					sap.ui.getCore().byId("idCreateMMticket").setEnabled(true);
					sap.ui.getCore().byId("idAssignMMticket").setEnabled(true);
				} else if ((oSQuotes[i - 1] !== oSQuotes[i])) {
					MessageToast.show(this._getResourceBundleText("MmTicketQuoteErrorMsg"));
					sap.ui.getCore().byId("idCreateMMticket").setEnabled(false);
					sap.ui.getCore().byId("idAssignMMticket").setEnabled(false);
					break;
				}
			}
			if (aSelectedItems.length >= 1 && oMMSelectedItems.length === 0) {
				sap.ui.getCore().byId("idCreateMMticket").setEnabled(false);
				sap.ui.getCore().byId("idAssignMMticket").setEnabled(true);
			}
		},

		_Overall: function () {
			if (!this._oPopoverOverall) {
				this._oPopoverOverall = sap.ui.xmlfragment("c2r.o2c.cms_cases_to_review.view.fragment.CheckCustomerStatus", this);
				this.getView().addDependent(this._oPopoverOverall);
			}
			return this._oPopoverOverall;
		},
		onClose: function () {
			this._Overall().close();
		},
		filterBlockedValue: function (blockedValues) {
			var block = [];
			var that = this;
			Object.keys(blockedValues).map(function (value, index) {
				if (value.indexOf("blk") > -1 || value.indexOf("block") > -1 || value.indexOf("Blockofsupport") > -1) {
					if (blockedValues[value] === "Blocked" || blockedValues[value] === "Blocked via Blacklist" || blockedValues[value] ===
						"Block of Support") {
						block.push({
							blk: that.oMessage.getText(value)
						});
					}
				}
			});
			return block;
		},
		onCheckCustomerStatus: function () {
			var appid = this.getView().getModel("AppConfig").getProperty("/CaseTab");
			//this.passFunctIdToXOlytics("id", "022", appid); //Xolytics
			var aFilters = [];
			var that = this;
			var aSelectedItems = that._getSelectedMasterTableItems();
			var sSalesOrg = aSelectedItems[0].getProperty("SalesOrg");
			var sErpNo = aSelectedItems[0].getProperty("PartnerId");
			var sReseller = aSelectedItems[0].getProperty("ResellerId");
			var sCaseGuid = aSelectedItems[0].getProperty("CaseGuid");
			if (sErpNo === "")
				MessageToast.show(that._getResourceBundleText("nodata"));
			else {
				//ITSDEDLC-855 New sales org has been added
				// if (sSalesOrg === "0008"  || sSalesOrg === "0009" || sSalesOrg === "0065" || sSalesOrg === "0265" || sSalesOrg === "0750" ||
				// 	sSalesOrg === "0450" || sSalesOrg === "0855" || sSalesOrg === "0016" || sSalesOrg === "0029" || sSalesOrg === "0004" || sSalesOrg ===
				// 	"0007" || sSalesOrg === "0023" || sSalesOrg === "0002" || sSalesOrg === "0003") {
				// 	MessageToast.show(that._getResourceBundleText("salesdata")); 
				// } else {    
			//testing
					if (sSalesOrg) {
						aFilters.push(new Filter("Bukrs", FilterOperator.EQ, sSalesOrg));
					}
					if (sErpNo) {
						aFilters.push(new Filter("Kunnr", FilterOperator.EQ, sErpNo));
					}
					if (sReseller) {
						aFilters.push(new Filter("Kunnr", FilterOperator.EQ, sReseller));
					}
					if (sCaseGuid) {
						aFilters.push(new Filter("CaseGuid", FilterOperator.EQ, sCaseGuid));
					}
					this.getOwnerComponent().getModel().read("/CustomerBlockSet", {
						method: "GET",
						filters: aFilters,
						success: function (oData, response) {
							var results = oData.results;
							if (results.length === 0)
								MessageToast.show(that._getResourceBundleText("nodata"));
							else {
								var custData = {};
								var resData = {};
								for (var i = 0; i < results.length; i++) {
									if (results[i].Flag !== "X") {
										custData.Bukrs = results[i].Bukrs;
										custData.Kunnr = results[i].Kunnr;
										custData.Compname = results[i].Compname + ' (' + results[i].Kunnr + ')';
										custData["block"] = that.filterBlockedValue(results[i]);
										custData.UrlVisible = false;
										var block = that.filterBlockedValue(results[i]).find(function (o) {
											if (o.blk === 'Block of Support') {
												return true;
											}
										});
										if (block) {
											custData.UrlVisible = true;
										}
									} else {
										resData.Bukrs = results[i].Bukrs;
										resData.Kunnr = results[i].Kunnr;
										resData.Compname = results[i].Compname + ' (' + results[i].Kunnr + ')';
										resData["block"] = that.filterBlockedValue(results[i]);
									}
								}
								that.getView().getModel("AppConfig").setProperty("/custData", custData);
								that.getView().getModel("AppConfig").setProperty("/resData", resData);

								if (Object.keys(custData).length > 0 && custData.block.length !== 0 || Object.keys(resData).length > 0 && resData.block.length !==
									0) {
									if (Object.keys(resData).length > 0 && resData.block.length !== 0) {
										that.getView().getModel("AppConfig").setProperty("/resellerData", true);
									} else {
										that.getView().getModel("AppConfig").setProperty("/resellerData", false);
									}

									if (Object.keys(custData).length > 0 && custData.block.length !== 0) {
										that.getView().getModel("AppConfig").setProperty("/customerData", true);
									} else {
										that.getView().getModel("AppConfig").setProperty("/customerData", false);
									}
									this._Overall().open();
								} else
									MessageToast.show(this._getResourceBundleText("nodata"));
							}
						}.bind(this)
					});
				// }
			}
		},

		/****************************************************************************************/
		/*************************** Section XOlytics starts here *******************************/
		/****************************************************************************************/

		passFunctIdToXOlytics: function (type, info, appId) {
			// creating XOlytics reffernece inside application controller
			// try {
			// 	if (!this._refXOlytics) {
			// 		this._refXOlytics = this.getOwnerComponent().XOlytics;
			// 	}

			// 	// Custom logic start here
			// 	var FuncId = "";
			// 	if (type === "id") {
			// 		FuncId = info;
			// 	} else if (type === "Go" || type === "Excel") {

			// 		var VM = this._getCurrentActiveSmartVariant();
			// 		var bHasVariant = VM.getCurrentVariantId();
			// 		if (type === "Go") {
			// 			if (bHasVariant) {
			// 				FuncId = "002";
			// 			} else {
			// 				FuncId = "001";
			// 			}

			// 		} else {
			// 			if (bHasVariant) {
			// 				FuncId = "004";
			// 			} else {
			// 				FuncId = "003";
			// 			}
			// 		}
			// 	}

			// 	this._refXOlytics.addInteractionPoint(FuncId, appId);
			// } catch (err) {
			// 	return;
			// }
		},

		openXolyticsUserFeedback: function (oEvent) {
			// if (!this._refXOlytics) {
			// 	this._refXOlytics = this.getOwnerComponent().XOlytics; //added
			// }
			// if (this.initialLoad === 0) {
			// 	for (var i in this._refXOlytics._UserFeedBackModel.getData().FeedBackSet) {
			// 		if (this._refXOlytics._UserFeedBackModel.getData().FeedBackSet[i].Appid === "01") {
			// 			this._refXOlytics._UserFeedBackModel.getData().FeedBackSet[i].Question = this._refXOlytics._UserFeedBackModel.getData().FeedBackSet[
			// 				i].Question.concat(" (AllCMS)");
			// 		} else if (this._refXOlytics._UserFeedBackModel.getData().FeedBackSet[i].Appid === "02") {
			// 			this._refXOlytics._UserFeedBackModel.getData().FeedBackSet[i].Question = this._refXOlytics._UserFeedBackModel.getData().FeedBackSet[
			// 				i].Question.concat(" (MyCMS)");
			// 		} else {
			// 			this._refXOlytics._UserFeedBackModel.getData().FeedBackSet[i].Question = this._refXOlytics._UserFeedBackModel.getData().FeedBackSet[
			// 				i].Question.concat(" (NACMS)");
			// 		}
			// 	}
			// 	this.initialLoad = 1;
			// }
			// this._refXOlytics.openInteractionFeedback(this, oEvent);
		},
		//ITSDEDLC-559
		openContractValidation: function (oEvent) {
			var that = this;
			var aSelectedItems = that._getSelectedMasterTableItems();
			var sCaseID = aSelectedItems[0].getProperty("CaseId");
			var oModel = this.getOwnerComponent().getModel();
			oModel.callFunction("/GetCase", {
				method: "GET",
				urlParameters: {
					"STATUS": sCaseID
				},
				success: function (data, response) {
					var status = data.STATUS;
					if (status === "Yes") {
						that.openContractValidationApp();
					} else {
						var oResourceBundle = that.getOwnerComponent().getModel("i18n").getResourceBundle();
						MessageBox.error(oResourceBundle.getText("ContractValidationErrorMsg"));
					}
				}
			});
		},
		// Open Contract Validation Application in new tab on click of the button in Main Page title bar
		//ITSDEDLC-559
		openContractValidationApp: function (oEvent) {
			var that = this;
			var appid = this.getView().getModel("AppConfig").getProperty("/CaseTab");
			var aSelectedItems = that._getSelectedMasterTableItems();
			var sCaseID = aSelectedItems[0].getProperty("CaseId");
			var sCaseGuid = aSelectedItems[0].getProperty("CaseGuid");
			var sQuote = aSelectedItems[0].getProperty("RefQuote");
			//this.passFunctIdToXOlytics("id", "023", appid); //Xolytics
			var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNav.isIntentSupported(["contractvalidation-display"])
				.done(function (aResponses) {

				})
				.fail(function () {
					MessageToast(oResourceBundle.getText("navigationErrorMsg"));
				});
			var hash = (oCrossAppNav && oCrossAppNav.hrefForExternal({
				target: {
					// shellHash: "contractvalidation-Display"
					shellHash: "contractvalidation-Display&/ClauseDetail/" + sCaseID + "," + sCaseGuid + "," + sQuote
				}
			})) || "";
			//Generate a  URL for the second application
			var url = window.location.href.split('#')[0] + hash;
			//Navigate to second app
			sap.m.URLHelper.redirect(url, true);
		},
		openContractValidationOnBooking: function (sStatus, sCaseGuid, sCaseID, sQuote) {
			var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			var oCrossAppNavArchive = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNav.isIntentSupported(["contractvalidation-display"])
				.done(function (aResponses) {

				})
				.fail(function () {
					MessageToast(oResourceBundle.getText("navigationErrorMsg"));
				});
			oCrossAppNavArchive.isIntentSupported(["dcdacvarch-Display"])
				.done(function (aResponses) {

				})
				.fail(function () {
					MessageToast(oResourceBundle.getText("navigationErrorMsg"));
				});
			var hash;
			if (sStatus === '01') {
				hash = (oCrossAppNav && oCrossAppNav.hrefForExternal({
					target: {
						shellHash: "contractvalidation-Display&/ClauseDetail/" + sCaseID + "," + sCaseGuid + "," + sQuote
					}
				})) || "";
			} else if (sStatus === '02') {
				hash = (oCrossAppNavArchive && oCrossAppNavArchive.hrefForExternal({
					target: {
						shellHash: "dcdacvarch-Display&/ClauseDetail/" + sCaseID + "," + sCaseGuid + "," + sQuote
					}
				})) || "";
			} else {
				hash = (oCrossAppNav && oCrossAppNav.hrefForExternal({
					target: {
						shellHash: "contractvalidation-Display&/notFound"
					}
				})) || "";
			}
			//Generate a  URL for the second application
			var url = window.location.href.split('#')[0] + hash;
			//Navigate to second app
			sap.m.URLHelper.redirect(url, true);
		},
		//ITSDEDLC-266 GTS Block Check
		openGTSBlock: function (oEvent) {
			var that = this;
			var aSelectedItems = that._getSelectedMasterTableItems();
			var oErpCustomer = aSelectedItems[0].getProperty("PartnerId");
			var oCaseGuid = aSelectedItems[0].getProperty("CaseGuid");
			var oCaseId = aSelectedItems[0].getProperty("CaseId");
			var oOpportunity = aSelectedItems[0].getProperty("Oppn");
			var oErpName = aSelectedItems[0].getProperty("PartyName");
			var oProviderContractName = aSelectedItems[0].getProperty("ProviderContractCloud");
			var oRefQuote = aSelectedItems[0].getProperty("RefQuote");
			var oModel = this.getOwnerComponent().getModel();
			oModel.callFunction("/PartnerGTSCheck", {
				method: "GET",
				urlParameters: {
					"BpNumber": oErpCustomer,
					"CaseGuid": oCaseGuid //ITSDEDLC-881 - Case Guid 
				},
				success: function (data, response) {
					var status = data.GTS_Status;
					if (status === true) {
						that.getView().byId("idgtsblock").setEnabled(true);
						that.openGTSMail(oErpCustomer, oCaseGuid, oCaseId, oOpportunity, oErpName, oProviderContractName, oRefQuote);
					} else {
						var oResourceBundle = that.getOwnerComponent().getModel("i18n").getResourceBundle();
						MessageBox.information(oResourceBundle.getText("GTSErrorMsg"));
						that.getView().byId("idgtsblock").setEnabled(false);
					}
				},
				error: function (oError) {
					MessageToast.show("Error while fetching the details, please try later");

				}
			});
		},
		//GTS Mail 
		openGTSMail: function (oValue1, oValue2, oValue3, oValue4, oValue5, oValue6, oValue7) {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			oModel.callFunction("/PartnerGTSEmail", {
				method: "GET",
				urlParameters: {
					"PartnerId": oValue1,
					"CaseGuid": oValue2,
					"CaseId": oValue3,
					"Oppn": oValue4,
					"PartyName": oValue5,
					"ProviderContractCloud": oValue6,
					"RefQuote": oValue7
				},
				success: function (data, response) {
					var date = data.WF_Date;
					var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
						formatOptions: {
							style: 'short',
							source: {
								pattern: 'dd.mm.yyyy'
							}
						}
					});
					var dateFormatted = dateFormat.format(date);
					sap.m.MessageBox.information("GTS Mail has been Successful on " + dateFormatted);
					that.getOwnerComponent().getModel().refresh();
				},
				error: function (oError) {
					MessageToast.show("GTS Mail Error");
				}
			});

		}

		/****************************************************************************************/
		/*************************** Section XOlytics ends here *******************************/
		/****************************************************************************************/
	});

});