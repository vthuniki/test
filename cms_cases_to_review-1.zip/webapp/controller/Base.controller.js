sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/model/FilterOperator"
], function (Controller, Filter, MessageToast, FilterOperator) {
	"use strict";

	return Controller.extend("c2r.o2c.cms_cases_to_review.controller.Base", {

		activateWebAnalytics: function (pubToken) {
			var swa = {
				pubToken: pubToken,
				baseUrl: 'https://webanalytics.cfapps.eu10.hana.ondemand.com/tracker/',
				/*baseUrl: 'https://qa-tracker.cfapps.sap.hana.ondemand.com/tracker/',*/
				owner: null
			};
			window.swa = swa;
			(function () {
				var d = document,
					g = d.createElement('script'),
					s = d.getElementsByTagName('script')[0];
				g.type = 'text/javascript';
				g.defer = true;
				g.async = true;
				window.setTimeout(function () {
					g.src = swa.baseUrl + 'js/privacy.js';
				}, 20000);
				s.parentNode.insertBefore(g, s);
			})(); // SAP Web Analytics 
		},

		_getVariantTypeFilterToken: function (item, maxlength) {
			var filterObject = {
				sign: "I",
				option: "EQ",
				low: "",
				high: ""
			};
			var maxStrLow = "",
				maxStrHigh = "";
			if (item.exclude) {
				filterObject.sign = "E";
			}
			if (item.operation) {
				filterObject.option = item.operation;
				if (filterObject.option === "Contains") {
					filterObject.option = "CP";
				}
			}
			if (item.value1) {
				filterObject.low = item.value1;
			}
			if (item.key) {
				filterObject.low = item.key;
			}
			if (item.value2) {
				filterObject.high = item.value2;
			}
			if (maxlength) {
				while (maxlength) {
					maxStrLow = maxStrLow + "0";
					maxStrHigh = maxStrHigh + "0";
					maxlength--;
				}
				if (filterObject.low) {
					filterObject.low = maxStrLow.substr(0, maxStrLow.length - filterObject.low.length) + filterObject.low;
				}
				if (filterObject.high) {
					filterObject.high = maxStrHigh.substr(0, maxStrHigh.length - filterObject.high.length) + filterObject.high;
				}
			}
			return filterObject;
		},

		_getVariantTypeDateRangeToken: function (oDate) {
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				style: "long",
				pattern: "yyyyMMdd"
			});
			var filterObject = {
					operation: ""
				},
				value1, value2;
			filterObject.operation = oDate.operation;
			value1 = oDate.value1;
			if (value1) {
				if (Object.prototype.toString.call(value1) === '[object Date]') {
					filterObject.dateValue = oDateFormat.format(value1);
				} else {
					filterObject.dateValue = value1;
				}
			}
			value2 = oDate.value2;
			if (value2) {
				if (Object.prototype.toString.call(value2) === '[object Date]') {
					filterObject.secondDateValue = oDateFormat.format(value2);
				} else {
					filterObject.secondDateValue = value2;
				}
			}
			return filterObject;
		},

		GetFilterString: function (smartFilterId, oAdditionalParams, oProperiesForMaxLen) {
			var oSmartFilter = this.getView().byId(smartFilterId);
			var oFilterData = oSmartFilter.getFilterData();
			var oFilterDataAsFlatStruct = {},
				iMaxLength;
			for (var property in oFilterData) {
				if (oProperiesForMaxLen && oProperiesForMaxLen[property]) {
					iMaxLength = oProperiesForMaxLen[property];
				} else {
					iMaxLength = 0;
				}
				if (oFilterData.hasOwnProperty(property)) {
					try {
						if (oFilterData[property].hasOwnProperty("ranges") || oFilterData[property].hasOwnProperty("items")) {
							oFilterDataAsFlatStruct[property] = [];
							if ((oFilterData[property].hasOwnProperty("ranges") && Array.isArray(oFilterData[property].ranges)) && !oFilterData[property].hasOwnProperty(
									"conditionTypeInfo")) {
								for (var i = 0; i < oFilterData[property].ranges.length; i++) {
									oFilterDataAsFlatStruct[property].push(this._getVariantTypeFilterToken(oFilterData[property].ranges[i], iMaxLength));
								}
							}

							if (oFilterData[property].hasOwnProperty("conditionTypeInfo")) {
								oFilterDataAsFlatStruct[property] = this._getVariantTypeDateRangeToken(oFilterData[property].conditionTypeInfo.data);
							}
							if (oFilterData[property].hasOwnProperty("items") && Array.isArray(oFilterData[property].items)) {
								for (i = 0; i < oFilterData[property].items.length; i++) {
									oFilterDataAsFlatStruct[property].push(this._getVariantTypeFilterToken(oFilterData[property].items[i], iMaxLength));
								}
							}
						} else if (oFilterData[property].hasOwnProperty("low")) {
							oFilterDataAsFlatStruct[property] = {};
							oFilterDataAsFlatStruct[property] = [this._getVariantTypeFilterToken(oFilterData[property], iMaxLength)];
						} else {
							oFilterDataAsFlatStruct[property] = [this._getVariantTypeFilterToken({
								"key": oFilterData[property]
							}, iMaxLength)];
						}
					} catch (err) {
						continue;
					}
				}
			}
			if (oAdditionalParams) {
				for (property in oAdditionalParams) {
					if (oAdditionalParams.hasOwnProperty(property)) {
						oFilterDataAsFlatStruct[property] = [this._getVariantTypeFilterToken({
							"key": oAdditionalParams[property]
						}, iMaxLength)];
					}
				}
			}
			return JSON.stringify(oFilterDataAsFlatStruct);
		},
		
		onNotes: function (oEvent) {
			this.sPath = oEvent.getSource().getBindingContext().getPath();
			var Note = oEvent.getSource().getBindingContext().getObject("Notes");
			if (!this.oNotes) {
				this.oNotes = sap.ui.xmlfragment(this.getView().getId(), "c2r.o2c.cms_cases_to_review.view.fragment.notes", this);
				this.getView().addDependent(this.oNotes);
			}
			this.getView().getModel("AppConfig").setProperty("/Notes", Note);
			this.oNotes.openBy(oEvent.getSource());

		},
		handleSubmitPress: function (oEvent) {
			var that = this;
			this.getOwnerComponent().getModel().setUseBatch(true);
			var sSelectedItem = this.getView().getModel("AppConfig").getProperty("/Notes");
			this.getOwnerComponent().getModel().setProperty(this.sPath + "/Notes", sSelectedItem);
			var msg = this._getResourceBundleText("NotessavedSuccessfully");
			this.getOwnerComponent().getModel().submitChanges({
				success: function (oData) {
					MessageToast.show(msg);
					that.getOwnerComponent().getModel().setUseBatch(false);
				}
			});
			this.oNotes.close();

		},
		saveVariantDatatoBackend: function (smartFilterId, labelId, oAdditionalParams, oProperiesForMaxLen) {
			var oParams = {};
			var oUser = new sap.ushell.services.UserInfo();
			var oSmartFilter = this.getView().byId(smartFilterId);
			var VM = oSmartFilter._oSmartVariantManagement;
			if (VM.getDefaultVariantKey() === VM.getCurrentVariantId()) {
				oParams.LabelId = labelId;
				oParams.CreatedBy = oUser.getId();
				oParams.FilterStr = this.GetFilterString(smartFilterId, oAdditionalParams, oProperiesForMaxLen);
				oParams.IsVariantSet = "X";
				this.getOwnerComponent().getModel().update("/VariantCountSet(" + "'" + oParams.LabelId + "'" + ")", oParams);
			}
		},

		_getMessagePopover: function () {
			if (!this._oMessagePopover) {
				this._oMessagePopover = sap.ui.xmlfragment(this.getView().getId(),
					"c2r.o2c.cms_cases_to_review.view.fragment.popover.MessagePopover", this);
				this.getView().addDependent(this._oMessagePopover);
			}
			return this._oMessagePopover;
		},

		onMessagePopoverPress: function (oEvent) {
			this._getMessagePopover().openBy(oEvent.getSource());
		},

		_getResourceBundleText: function (sKeyText, aParamters) {
			if (!this._i18TextBundle) {
				this._i18TextBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			}
			return this._i18TextBundle.getText(sKeyText, aParamters);
		},

		readFeedbackQues: function (sLableId) {
			this.getView().getModel().read("/FeedBackQuestSet", {
				method: "GET",
				filters: [new Filter("Appid", FilterOperator.EQ, sLableId)],
				success: jQuery.proxy(function (oData, response) {
					this.getView().getModel("AppConfig").setProperty("/FeedBackQues", oData.results);
				}, this)
			});
		},
		submitFeedBack: function () {
			var data = this.getView().getModel("AppConfig").getProperty("/FeedBackQues");
			for (var i = 0; i < data.length; i++) {
				if (!data[i].Answer) {
					MessageToast.show("Please rate all functionalities");
					return;
				}
			}
			this.getView().getModel().callFunction("/SaveExperienceFeedback", {
				method: "POST",
				urlParameters: {
					"JSONString": JSON.stringify(data)
				},
				success: jQuery.proxy(function (oData, response) {
					MessageToast.show("Thankyou for your valuable Feedback !");
				}, this)
			});
			this._FeedBackPopover.close();
		},
		CnacelFeedBack: function () {
			this._FeedBackPopover.close();
		},
		ClearBeforeClose: function () {
			var data = this.getView().getModel("AppConfig").getProperty("/FeedBackQues");
			for (var i = 0; i < data.length; i++) {
				if (data[i].Answer) {
					data[i].Answer = 0;
				}
			}
			this.getView().getModel("AppConfig").refresh();
		}
	});
});