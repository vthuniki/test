sap.ui.define(
	function () {
		"user strict";
		var Constants = {};
		Constants.HTTP = "https://";
		Constants.ISD = "ISD";
		Constants.IST = "IST";
		Constants.ISP = "ISP";
		Constants.ICD = "ICD";
		Constants.ICT = "ICT";
		Constants.ICP = "ICP";
		Constants.VA23 = ".wdf.sap.corp/sap/bc/gui/sap/its/webgui/?sap-client=001&sap-language=en&~transaction=va23%20VBAK-VBELN=";
		Constants.nosplash = "&~NOSPLASH=1";
		Constants.OBJTYP = ".wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?crm-object-type=";
		Constants.OBJTYPGUID=".wdf.sap.corp/sap(bD1lbiZjPTAwMSZ0PXNhcF9jb3JidSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?crm-object-type=";
		Constants.OBJVAL = "&crm-object-action=B&crm-object-value=";
		Constants.OBJID="OBJECT_ID";
		Constants.OBJ_VALUE="&crm-object-value=";
		Constants.KEYGUID = "&crm-key-name=GUID.";
		Constants.KEYNAME = "&crm-object-action=B&crm-object-keyname=";
		Constants.BT116_SRVQ = "BT116_SRVQ";
		Constants.BT116_SRVO = "BT116_SRVO"; // CRM Sales Order
		Constants.VBAK_VBELN = ".wdf.sap.corp/sap/bc/gui/sap/its/webgui/?sap-client=001&sap-language=en&~transaction=va23%20VBAK-VBELN=";
		Constants.OKCODE = "&~OKCODE=ENT2";
		Constants.URLYMON = ".wdf.sap.corp/sap/bc/gui/sap/its/webgui/?sap-client=001&sap-language=en&~transaction=YMON";
		Constants.CRMWEBUI = ".wdf.sap.corp/sap/bc/bsp/sap/crm_ui_start/default.htm?crm-object-type=";

		Constants.CMSCASE =
			".wdf.sap.corp/sap/bc/webdynpro/sap/zv_cms_rcm_wda_case?sap-language=EN&sap-wd-configId=ZV_CMS_RCM_WAC_CASE&CASE_MODE=D&case_guid=";

		Constants.CalOppt =
			"flpsandbox-br339jmc4c.dispatcher.int.sap.eu2.hana.ondemand.com/sites?sap-ushell-config=standalone#harmonyquote-Display&/Opportunity/";
		Constants.CalOpptT =
			"fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites?sap-ushell-config=standalone#harmonyquote-Display&/Opportunity/";
		Constants.CalOpptP = "fiorilaunchpad.sap.com/sites?sap-ushell-config=standalone#harmonyquote-Display&/Opportunity/";
		Constants.BT111_OPPT = "BT111_OPPT";

		Constants.CPQDEV =
			"flpsandbox-br339jmc4c.dispatcher.int.sap.eu2.hana.ondemand.com/sites?sap-ushell-config=standalone#harmonyquote-Display&/";
		Constants.CPQTEST = "fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites?sap-ushell-config=standalone#harmonyquote-Display&/";
		Constants.CPQPROD = "fiorilaunchpad.sap.com/sites?sap-ushell-config=standalone#harmonyquote-Display&/";
		Constants.Opportunity = "Opportunity/";
		Constants.Quote = "/Quotedetails/";

		Constants.ERPQUOT =
			".wdf.sap.corp/sap/crm_logon/default.htm?crm-object-type=ERPQUOTATION&crm-object-action=B&crm-object-keyname=QUOTE&crm-object-value=";

		Constants.BT112_SC = "BT112_SC";
		Constants.BT266_PRVC = "BT266_PRVC";
		Constants.BT116_SRVQ = "BT116_SRVQ";
		Constants.ENTOK = "&~OKCODE=ENT2";
		
		Constants.VA03 = ".wdf.sap.corp/sap/bc/gui/sap/its/webgui/?sap-client=001&sap-language=en&~transaction=va03 VBAK-VBELN=";
		Constants.VA23 = ".wdf.sap.corp/sap/bc/gui/sap/its/webgui/?sap-client=001&sap-language=en&~transaction=va23 VBAK-VBELN=";
		Constants.ERPContrct = ".wdf.sap.corp/sap/bc/gui/sap/its/webgui/?sap-client=001&sap-language=en&~transaction=va43 VBAK-VBELN=";
		Constants.BT100_CSPC = "BT100_CSPC";
		Constants.ENTOK = "&~OKCODE=ENT2";
		Constants.CRMOBJ = "&crm-object-action=B&crm-object-value=";
		
		// C4C Opportunity URL constants
		Constants.C4COppDev = "my344308";
		Constants.C4COppTest = "my338727";
		Constants.C4COppProd = "my341943";
		Constants.C4COpp1 = ".crm.ondemand.com/sap/public/byd/runtime?bo_ns=";
		Constants.C4COpp2 = "sap.com/thingTypes&bo=COD_GENERIC&node=Root&operation=OnExtInspect&param.InternalID=";
		Constants.C4COpptab = "&param.Type=COD_OPPORTUNITY_THINGTYPE&sapbyd-agent=TAB";

		//ERP Sold to
		Constants.ERP_SOLDTO="reporting.ondemand.com/sap/crp/cdo?type=crp_c&id=";		
		Constants.ITDirect = "fiorilaunchpad.sap.com/sites#Help-Inbox&/create/ZGCR/ZGCO_MDT_LMUNBLOCK/Material%20";
		Constants.Material = "%20blocked%20Quote%20";
		
		// Constants.SFAOpenMmTicket = "sfa.bss.net.sap/sap/bc/bsp/sap/crm_ui_start/default.htm";
		Constants.SFAOpenMmTicketTestSystem = "fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites#Help-Inbox&/detail/";
		Constants.SFAOpenMmTicketProdSystem ="fiorilaunchpad-sapitcloud.dispatcher.hana.ondemand.com/sites#Help-Inbox&/detail/";
		Constants.ZCR ="/ZGCR";
		
		
		return Constants;
	}, /* bExport= */ true);