sap.ui.define([
	"sap/ui/core/Control",
	"sap/m/ObjectStatus",
	"sap/m/MessageToast",
	"c2r/o2c/cms_cases_to_review/control/ConstantsHyperLinkLib"
], function (Control, Link, MessageToast, Constants) {
	"use strict";
	return Control.extend("c2r.o2c.cms_cases_to_review.control.BusinessObjectHyperLink", {
		metadata: {
			properties: {
				text: {
					type: "string",
					defaultValue: ""
				},
				type: {
					type: "string",
					defaultValue: ""
				},
				state: {
					type: "string",
					defaultValue: "Information"
				},
				tooltip: {
					type: "string",
					defaultValue: ""
				},
				params: {
					type: "string",
					defaultValue: ""
				}
			},
			aggregations: {
				_Link: {
					type: "sap.m.ObjectStatus",
					multiple: false
				}
			}
		},

		init: function () {
			this.setAggregation("_Link", new Link({
				press: this._openBusinessObject.bind(this),
				active: true,
				state: "Information"
			}));
			this._system = this.findCurrentSystem();
		},

		setText: function (sText) {
			this.setProperty("text", sText, true);
			this.getAggregation("_Link").setText(sText);
		},

		setState: function (sState) {
			this.setProperty("state", sState, true);
			this.getAggregation("_Link").setState(sState);
		},

		setTooltip: function (sTooltip) {
			this.setProperty("tooltip", sTooltip, true);
			this.getAggregation("_Link").setTooltip(sTooltip);
		},

		_openBusinessObject: function (oEvent) {

			var mParameters = this._getJson(oEvent.getSource().getParent().getParams());
			switch (oEvent.getSource().getParent().getType()) {
			case "CMSCase":
				this._openCMSCase(mParameters.guid);
				break;
			case "SomQuoteGuid":
				this._openSomQuote(mParameters);
				break;
			case "ServiceContract":
				this._openServiceContract(mParameters.guid);
				break;
			case "SolutionContract":
				this._openSolutionContract(mParameters);
				break;
			case "ProviderContract":
				this._openProviderContract(mParameters);
				break;
			case "ERPContract":
				this._openERPContract(mParameters);
				break;
			case "SalesOrder":
				if (mParameters.hasOwnProperty("ReplStatus") && mParameters.ReplStatus === "false") {
					if (mParameters.LOB.indexOf('SR') !== -1) {
						this._openServiceContract(mParameters.guid);
					} else {
						this._openCRMSalesOrder(mParameters);
					}
				} else {
					this._openSalesOrder(mParameters);
				}
				break;
			case "CRMSalesOrder":
				this._openCRMSalesOrder(mParameters);
				break;
			case "Opportunity":
				this._openOpportunity(mParameters);
				break;
			case "Quotation":
				this._openQuotation(mParameters);
				break;
			case "PartnerId":
				this._openPartner(mParameters);
				break;
			default:
				MessageToast.show("Navigation unkown");
				break;
			}
		},

		_getJson: function (sParams) {
			var mParameters = "{" + sParams + "}";
			mParameters = JSON.parse(mParameters);
			if (mParameters.hasOwnProperty("guid")) {
				mParameters.guid = mParameters.guid.replace(/-/gi, "");
				mParameters.guid = mParameters.guid.toLocaleUpperCase();
			}
			return mParameters;
		},

		_openURL: function (sURL) {
			if (sURL) {
				sap.m.URLHelper.redirect(sURL, true);
			} else {
				MessageToast.show("Navigation unkown");
			}
		},

		_openCMSCase: function (guid) {
			var surl;
			if (guid) {
				surl = Constants.HTTP + this._getERPDomain() + Constants.CMSCASE + guid;
				this._openURL(surl);
			} else {
				MessageToast.show("CMS Case guid, is not found");
			}
		},
		_openMmTicket: function (mParameters) {

			var surl;
			surl = Constants.HTTP + Constants.ITDirect + mParameters.Material + Constants.Material + mParameters.Quote;
			this._openURL(surl);
		},
		_openMmTicketNew : function (MmTicketId) {
			var surl;
			if((this._system === "DSystem") || (this._system === "TSystem")){
				surl = Constants.HTTP + Constants.SFAOpenMmTicketTestSystem + MmTicketId + Constants.ZCR;
			}else {
				surl = Constants.HTTP + Constants.SFAOpenMmTicketProdSystem + MmTicketId + Constants.ZCR;
			}
			sap.m.URLHelper.redirect(surl ,true);
			
		},
		_openC4CSystem: function (mParameters) {
			var sUrl;
			switch (this._oBusinessObjectHyperLink._system) {
			case "DSystem":
				sUrl = Constants.HTTP + Constants.C4COppDev + Constants.C4COpp1 + Constants.HTTP + Constants.C4COpp2 + mParameters.id + Constants.C4COpptab; // C4C Opportunity URL 
				break;
			case "TSystem":
				sUrl = Constants.HTTP + Constants.C4COppTest + Constants.C4COpp1 + Constants.HTTP + Constants.C4COpp2 + mParameters.id + Constants
					.C4COpptab; // C4C Opportunity URL 
				break;
			case Constants.ISP:
				sUrl = Constants.HTTP + Constants.C4COppProd + Constants.C4COpp1 + Constants.HTTP + Constants.C4COpp2 + mParameters.id + Constants
					.C4COpptab; // C4C Opportunity URL 
				break;
			}
			if (sUrl) {
				sap.m.URLHelper.redirect(sUrl, true);
			}
		},

		_openServiceContract: function (guid) {
			
			var surl;
			surl = Constants.HTTP + this._getCRMDomain() + Constants.OBJTYP + Constants.BT112_SC + Constants.OBJVAL + guid;
			this._openURL(surl);
		},

		_openSomQuote: function (mParameters) {
			var surl;
			if (mParameters.flag === 'quote') {
				surl = Constants.HTTP + this._getERPDomain() + Constants.OBJTYP + Constants.BT116_SRVQ + Constants.OBJVAL + mParameters.guid;
			}
			else
			{
				surl = Constants.HTTP + this._getERPDomain() + Constants.OBJTYP + Constants.BT266_PRVC + Constants.OBJVAL + mParameters.guid;
			}
			this._openURL(surl);
		},
		_openSolutionContract: function (mParameters) {
			var surl;
			if (mParameters.guid) {
				// crm object url
				surl = Constants.HTTP + this._getCRMDomain() + Constants.CRMWEBUI + Constants.BT100_CSPC + Constants.CRMOBJ + mParameters.guid; // + Constants.QUOTURL1;
			} else {
				// erp object url
				this._openERPContract(mParameters);
				return;
			}
			this._openURL(surl);
		},

		_openProviderContract: function (mParameters) {
			var surl;
			if (mParameters.LOB.indexOf("SR") !== -1) { //service contract
				surl = Constants.HTTP + this._getCRMDomain() + Constants.CRMWEBUI + Constants.BT112_SC + Constants.CRMOBJ + mParameters.guid; // + Constants.QUOTURL1;
			} else { //provider contract
				surl = Constants.HTTP + this._getCRMDomain() + Constants.CRMWEBUI + Constants.BT266_PRVC + Constants.CRMOBJ + mParameters.guid; // + Constants.QUOTURL1;
			}
			this._openURL(surl);
		},

		_openERPContract: function (mParameters) { //ERP contract press
			var surl = Constants.HTTP + this._getERPDomain() + Constants.ERPContrct + mParameters.id + Constants.ENTOK;
			this._openURL(surl);
		},

		_openSalesOrder: function (mParameters) { // ERP Sales Order
			var surl = Constants.HTTP + this._getERPDomain() + Constants.VA03 + mParameters.id + Constants.ENTOK;
			this._openURL(surl);
		},

		_openERPQuotation: function (mParameters) { // ERP Quotation
			var surl = Constants.HTTP + this._getERPDomain() + Constants.VA23 + mParameters.id + Constants.ENTOK;
			this._openURL(surl);
		},

		_openCRMSalesOrder: function (mParameters) { // CRM Sales Order
			var sUrl = Constants.HTTP + this._getCRMDomain() + Constants.OBJTYP + Constants.BT116_SRVO + Constants.OBJVAL + mParameters.guid;
			this._openURL(sUrl);
		},

		_openOpportunity: function (mParameters) {
			var surl;
			try {
				if (mParameters.type === "CPQ") {
					surl = Constants.HTTP + this._getFLP_URL() + mParameters.id;
				} else {
					if (mParameters.guid) {
						surl = Constants.HTTP + this._getCRMDomain() + Constants.OBJTYP + Constants.BT111_OPPT + Constants.OBJVAL + mParameters.guid; // + Constants.OPPTURL1;
					}
				}
			} catch (err) {}
			if (surl) {
				this._openURL(surl);
			}
		},

		_openQuotation: function (mParameters) {
			var sUrl, oQuote = mParameters.id;
			if (mParameters.type === "CPQ") {
				if (mParameters.Deal) {
					var prefixSubstitue = "000000000000";
					oQuote = prefixSubstitue.substr(mParameters.id.length) + oQuote;
					sUrl = Constants.HTTP + this._getFLP_URL() + mParameters.Deal + Constants.Quote + oQuote;
				} else {
					MessageToast.show("Opportunity No, doesnot exist");
				}
				// } else if (mParameters.type === "Q2C") {
				// 	sUrl = Constants.HTTP + this._getCRMDomain() + Constants.OBJTYPGUID + Constants.BT116_SRVQ + Constants.KEYNAME + Constants.OBJID +
				// 		Constants.OBJ_VALUE + oQuote;
			} else {
				if (mParameters.guid) { //16-digit guid ERP 
					sUrl = Constants.HTTP + this._getCRMDomain() + Constants.OBJTYP + Constants.BT116_SRVQ + Constants.OBJVAL + mParameters.guid;
				} else { //32-digit guid ERP
					//	sUrl = Constants.HTTP + this._getCRMDomain() + Constants.ERPQUOT + oQuote;
					sUrl = Constants.HTTP + this._getERPDomain() + Constants.VBAK_VBELN + oQuote + Constants.OKCODE;
				}
			}
			if (sUrl) {
				this._openURL(sUrl);
			}
		},

		_getCRMDomain: function () {
			if (this._system === "DSystem") {
				return Constants.ICD;
			} else if (this._system === "TSystem") {
				return Constants.ICT;
			} else {
				return Constants.ICP;
			}
		},

		_getERPDomain: function () {
			if (this._system === "DSystem") {
				return Constants.ISD;
			} else if (this._system === "TSystem") {
				return Constants.IST;
			} else {
				return Constants.ISP;
			}
		},

		_getFLP_URL: function () {
			if (this._system === "DSystem") {
				return Constants.CalOppt;
			} else if (this._system === "TSystem") {
				return Constants.CalOpptT;
			} else {
				return Constants.CalOpptP;
			}
		},

		renderer: function (oRM, oControl) {
			oRM.write("<div");
			oRM.writeControlData(oControl);
			oRM.write(">");
			oRM.renderControl(oControl.getAggregation("_Link"));
			oRM.write("</div>");
		},

		findCurrentSystem: function () {
			switch (["sapitcloudd.", "fiorilaunchpad.", "backuplaunchpad.", "sapitcloud.", "sapitcloudt.", "br339jmc4c.",
				"fiori.dispatcher.int.sap.hana.ondemand.com", "fiori.dispatcher.cert.hana.ondemand.com", "localhost"
			].find(function (e) {
				return window.location.hostname.indexOf(e) >= 0;
			})) {
			case "sapitcloudd.":
			case "br339jmc4c.":
			case "fiori.dispatcher.int.sap.hana.ondemand.com":
			case "fiori.dispatcher.cert.hana.ondemand.com":
				return "DSystem";
			case "localhost":
			case "sapitcloudt.":
				return "TSystem";
			case "sapitcloud.":
			case "fiorilaunchpad.":
			case "backuplaunchpad.":
				return "PSystem";
			default:
				return jQuery.sap.log.error("findCurrentSystem: Current System not found!"), null;
			}
		},

		_openPartner: function (mParameters) {
			var surl;
			var bpNumber = mParameters.bpNumber,
				surl = Constants.HTTP + Constants.ERP_SOLDTO + bpNumber;
			if (bpNumber !== "") {
				this._openURL(surl);
			}
		}
	});
});