sap.ui.define([], function () {
	"use strict";

	return {

		//format booking time
		bookingDateFormatter: function (bookingDate, bookingTime) {
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: "KK:mm:ss a"
			});
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
			if (bookingTime !== null) {
				var formattedTime = timeFormat.format(new Date(bookingTime.ms + TZOffsetMs));
			}
			if (bookingDate === null) {
				formattedTime = "";

			}
			return formattedTime;
		},

		getChangeReqFlagForTable: function (sValue) {
			if (sValue === "NCR") {
				return "Error";
			} else if (sValue === "CR") {
				return "Success";
			} else if (sValue === "ZCR") {
				return "Information";
			} else {
				return "None";
			}
		},

		autoContractValidationFlag: function (sValue) {
			var root = this.getOwnerComponent().getModel("AppConfig").getProperty("/root");
			if (sValue === '01') {
				return root + "/images/roboRed.png";
			} else if (sValue === '02') {
				return root + "/images/roboGreen.png";
			} else if (sValue === '03') {
				return root + "/images/roboGrey.png";
				///ITSDEDLC-873 - New status 05 with roboBlue color
			} else if (sValue === '05') {
				return root + "/images/roboBlue.png";
			} else {
				return "#";
			}
		},
		tooltipTextImage: function (sValue) {
			var i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			if (sValue === '01') {
				return i18n.getText("RedRobotText");
			} else if (sValue === '02') {
				return i18n.getText("GreenRobotText");
			} else if (sValue === '03') {
				return i18n.getText("GreyRobotText");
			} else {
				return "#";
			}
		}
	};
});