sap.ui.define(['jquery.sap.global'],
	function (jQuery) {
		"use strict";
		var Constants = {};
		Constants.ExpandQuery = "%2CToGetCaseNotes%2FContent%2CToGetCaseNotes%2FCreatedDate%2CToGetCaseNotes%2FPersonName&$expand=ToGetCaseNotes";
		Constants.oColumnsWidth = {
			"CMSCaseNo.": "10",
			"QuoteSource": "7",
			"SOBookingStatus": "12",
			"Description": "20",
			"ERPSoldTo": "10",
			"TargetValue": "10",
			"SalesOrg.": "12",
			"ContractAdmin": "15",
			"ChangedBy": "10",
			"ContractValidator":"15",
			"BookingTime":"10",
			"BookingDate":"10",
			"SomQuoteStatus":"15"
		};
        Constants.appId = "01";
		Constants.StandardVariantFBData = {};
		Constants.StandardVariantFBData.CMS_SmartFilterBar_AllCases = {
			// Lob: "AL",
			Lob: {
				items: [{
					key: "AL"
				}]
			},
			Los: {
				items: [{
					key: "AL"
				}]
			},
			SwStatus: {
				items: [{
					key: "ZCC7",
					text: "Signed Contract in Validation (ZCC7)"
				}]
			}
		};
		Constants.StandardVariantFBData.CMS_SmartFilterBar_MyCases = {
			// Lob: "AL",
			Lob: {
				items: [{
					key: "AL"
				}]
			},
			Los: {
				items: [{
					key: "AL"
				}]
			},
			SwStatus: {
				items: [{
					key: "ZCC7",
					text: "Signed Contract in Validation (ZCC7)"
				}]
			}
		};
		Constants.StandardVariantFBData.CMS_SmartVariant_NotAssigned = {
			// Lob: "AL",
			Lob: {
				items: [{
					key: "AL"
				}]
			},
			Los: {
				items: [{
					key: "AL"
				}]
			},
			SwStatus: {
				items: [{
					key: "ZCC7",
					text: "Signed Contract in Validation (ZCC7)"
				}]
			}
		};
		return Constants;
	}, /* bExport= */ true);