sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press"
], function (Opa5, Press) {
	"use strict";
	var sViewName = "CMS_Master";
	var sviewId = "__xmlview0";
	var sfragmentId = "fragment";
	Opa5.createPageObjects({
		onTheAppPage: {

			actions: {
				iSeeMyCMSCases: function () {
					return this.waitFor({
						viewId: sviewId,
						viewName: sViewName,
						fragmentId: sfragmentId,
						success: function (oEvent) {
							var addButton = oEvent[2].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});

				},
				iSeeNotAssignedCases: function () {
					return this.waitFor({
						viewId: sviewId,
						viewName: sViewName,
						fragmentId: sfragmentId,
						success: function (oEvent) {
							var addButton = oEvent[4].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});

				},
				iSeeAllCMSCases: function () {
					return this.waitFor({
						viewId: sviewId,
						viewName: sViewName,
						fragmentId: sfragmentId,
						success: function (oEvent) {
							var addButton = oEvent[0].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});

				}
			},

			assertions: {

				iShouldSeeTheApp: function () {
					return this.waitFor({
						id: "app",
						viewId: sviewId,
						viewName: sViewName,
						success: function () {
							Opa5.assert.ok(true, "The Base view is displayed");
						},
						errorMessage: "Did not find the Base view"
					});
				},
				iShouldSeeMyCMSCases: function () {
					return this.waitFor({
						autoWait: true,
						viewId: sviewId,
						viewName: sViewName,
						id: "CmsSmartTable_MyCases",
						success: function (oEvent) {
							Opa5.assert.ok(true, "My CMS cases are displayed");
						},
						errorMessage: "Did not find My CMS Case"

					});
				},
				iShouldSeeNotAssignedCases: function () {
					return this.waitFor({
						autoWait: true,
						viewId: sviewId,
						viewName: sViewName,
						id: "CmsSmartTable_NotAssigned",

						success: function (oEvent) {

							Opa5.assert.ok(true, "Not Assigned cases are displayed");
						},
						errorMessage: "Did not find Not Assigned case"

					});
				},
				iShouldSeeAllCMSCases: function () {
					return this.waitFor({
						autoWait: true,
						viewId: sviewId,
						viewName: sViewName,
						id: "CmsSmartTable_AllCases",
						success: function (oEvent) {
							Opa5.assert.ok(true, "Not Assigned cases are displayed");
						},
						errorMessage: "Did not find Not Assigned case"

					});
				}
			}
		}
	});

});