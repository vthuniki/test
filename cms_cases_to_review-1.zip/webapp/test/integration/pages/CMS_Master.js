sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press"
], function (Opa5, Press) {
	"use strict";
	var sViewName = "CMS_Master";
	var sviewId = "__xmlview0";
	var sfragmentId = "fragment";

	Opa5.createPageObjects({
		onTheCMS_MasterPage: {

			actions: {
				// iSeeMaterialStatus: function () {
				// 	return this.waitFor({
				// 		autoWait: true,
				// 		viewId: sviewId,
				// 		viewName: sViewName,
				// 		fragmentId: sfragmentId,
				// 		success: function (oEvent) {
				// 			var addButton = oEvent[26].getId();
				// 			return this.waitFor({
				// 				id: addButton,
				// 				actions: new Press()

				// 			});
				// 		},
				// 		errorMessage: "Control not found"
				// 	});
				// },

				// },
				iclickonAssigntoMe: function () {
					return this.waitFor({
						autoWait: true,
						viewId: sviewId,
						viewName: sViewName,
						fragmentId: sfragmentId,
						success: function (oEvent) {
							var addButton = oEvent[28].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iclickonAssigntoUser: function () {
					return this.waitFor({
						autoWait: true,
						viewId: sviewId,
						viewName: sViewName,
						fragmentId: sfragmentId,
						success: function (oEvent) {
							var addButton = oEvent[29].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iclickonRemoveAssignment: function () {
					return this.waitFor({
						autoWait: true,
						viewId: sviewId,
						viewName: sViewName,
						fragmentId: sfragmentId,
						success: function (oEvent) {
							var addButton = oEvent[30].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				}

			},
			assertions: {
				// iShouldSeeMaterialStatus: function () {
				// 	return this.waitFor({
				// 		autoWait: false,
				// 		viewId: sviewId,
				// 		viewName: sViewName,
				// 		controlType: "sap.m.Dialog",
				// 		success: function (posDialog) {
				// 			var addButton = posDialog[0].getEndButton().getId();
				// 			return this.waitFor({
				// 				id: addButton,
				// 				actions: new Press(),
				// 				success: function() {
				// 				Opa5.assert.ok(true, "The Material Status is displayed");	
				// 				}
				// 			});

				// 		},
				// 		errorMessage: "Did not find Material Status"
				// 	});
				// },
				iclickedonAssigntoMe: function () {
					return this.waitFor({
						autoWait: false,
						viewId: sviewId,
						viewName: sViewName,

						check: function () {

							return Opa5.getJQuery()(".sapMMessageToast").length > 0;
						},
						success: function () {
							Opa5.assert.ok(true, "Case assign to me");
						},
						errorMessage: "Case is not assigned to me"

					});

				},
				iclickedonAssigntoUser: function () {
					return this.waitFor({
						autoWait: false,
						viewId: sviewId,
						viewName: sViewName,

						check: function () {

							return Opa5.getJQuery()(".sapMMessageToast").length > 0;
						},
						success: function () {
							Opa5.assert.ok(true, "Case assign to user");
						},
						errorMessage: "Case is not assigned to user"

					});

				},
				iclickedonRemoveAssignment: function () {
					return this.waitFor({
						autoWait: false,
						viewId: sviewId,
						viewName: sViewName,

						check: function () {

							return Opa5.getJQuery()(".sapMMessageToast").length > 0;
						},
						success: function () {
							Opa5.assert.ok(true, "Case assign to me");
						},
						errorMessage: "Case is not assigned to me"

					});
				}
			}
		}
	});

});