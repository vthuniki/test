	sap.ui.define([
		"sap/ui/test/opaQunit",
		"./pages/CMS_Master"
	], function (opaTest) {
		"use strict";

		QUnit.module("CMS_Master Journey");
		// opaTest("Should see the Material status", function (Given, When, Then) {
		// 	// Arrangements
		// 	// Given.iStartMyApp();

		// 	// Action
		// 	When.onTheCMS_MasterPage.iSeeMaterialStatus();

		// 	// Assertions
		// 	Then.onTheCMS_MasterPage.iShouldSeeMaterialStatus();

		// });
		opaTest("Should Assign the cases to Me", function (Given, When, Then) {

			// Action
			When.onTheCMS_MasterPage.iclickonAssigntoMe();

			// Assertions
			Then.onTheCMS_MasterPage.iclickedonAssigntoMe();

		});
		opaTest("Should Assign the cases to User", function (Given, When, Then) {

			// Action
			When.onTheCMS_MasterPage.iclickonAssigntoUser();

			// Assertions
			Then.onTheCMS_MasterPage.iclickedonAssigntoUser();

		});
		opaTest("Should Remove Assignment", function (Given, When, Then) {

			// Action
			When.onTheCMS_MasterPage.iclickonRemoveAssignment();

			// Assertions
			Then.onTheCMS_MasterPage.iclickedonRemoveAssignment();

			//Cleanup
			Then.iTeardownMyApp();
		});
	});