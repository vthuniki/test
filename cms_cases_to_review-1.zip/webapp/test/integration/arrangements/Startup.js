// sap.ui.define([
// 	"sap/ui/test/Opa5"
// ], function (Opa5) {
// 	"use strict";

// 	return Opa5.extend("c2r.o2c.cms_cases_to_review.test.integration.arrangements.Startup", {

// 		iStartMyApp: function (oOptionsParameter) {
// 			var oOptions = oOptionsParameter || {};

// 			// start the app with a minimal delay to make tests fast but still async to discover basic timing issues
// 			oOptions.delay = oOptions.delay || 50;

// 			// start the app UI component
// 			this.iStartMyUIComponent({
// 				componentConfig: {
// 					name: "c2r.o2c.cms_cases_to_review",
// 					async: true
// 				},
// 				hash: oOptions.hash,
// 				autoWait: oOptions.autoWait
// 			});
// 		}
// 	});
// });
sap.ui.define([
			"sap/ui/test/Opa5",
			"c2r/o2c/cms_cases_to_review/localService/mockserver"
		], function (Opa5, mockserver) {
			"use strict";

			function getFrameUrl(sHash, sUrlParameters) {
				var sUrl = jQuery.sap.getResourcePath("c2r/o2c/cms_cases_to_review/mockServer", ".html");
				sUrlParameters = sUrlParameters ? "?" + sUrlParameters : "";
					return sUrl + sUrlParameters ;
	}

				return Opa5.extend("c2r.o2c.cms_cases_to_review.test.integration.arrangements.Startup", {

					iStartMyApp: function (oOptions) {
						var sUrlParameters;
						oOptions = oOptions || {};

						// Start the app with a minimal delay to make tests run fast but still async to discover basic timing issues
						var iDelay = oOptions.delay || 50;

						sUrlParameters = "serverDelay=" + iDelay;

						this.iStartMyAppInAFrame(getFrameUrl(oOptions.hash, sUrlParameters));
					},
					// var oOptions = oOptionsParameter || {};

					// // start the app with a minimal delay to make tests fast but still async to discover basic timing issues
					// oOptions.delay = oOptions.delay || 50;

					// // start the app UI component
					// this.iStartMyUIComponent({
					// 	componentConfig: {
					// 		name: "c2r.o2c.cms_cases_to_review",
					// // 		async: true
					// 	},
					// 	hash: oOptions.hash,
					// 	autoWait: oOptions.autoWait
					// });
					// iStartMyAppOnADesktopToTestErrorHandler: function (sParam) {
					// 	this.iStartMyAppInAFrame(getFrameUrl("", sParam));
					// },

					// iRestartTheAppWithTheRememberedItem: function (oOptions) {
					// 	var sObjectId;
					// 	this.waitFor({
					// 		success: function () {
					// 			sObjectId = this.getContext().currentItem.id;
					// 		}
					// 	});

					// 	return this.waitFor({
					// 		success: function () {
					// 			oOptions.hash = "/tableDatSet/" + encodeURIComponent(sObjectId);
					// 			this.iStartMyApp(oOptions);
					// 		}
					// 	});
					// }
				});
			});