	/*global QUnit*/

	sap.ui.define([
		"sap/ui/test/opaQunit",
		"./pages/Base"
	], function (opaTest) {
		"use strict";

		QUnit.module("Navigation Journey");

		opaTest("Should see the initial page of the app", function (Given, When, Then) {
			// Arrangements
			Given.iStartMyApp();

			// Assertions
			Then.onTheAppPage.iShouldSeeTheApp();

		});
		opaTest("Should see the My CMS Cases", function (Given, When, Then) {

			//action
			When.onTheAppPage.iSeeMyCMSCases();

			// Assertions
			Then.onTheAppPage.iShouldSeeMyCMSCases();

		});
		opaTest("Should see the Not Assigned Cases", function (Given, When, Then) {

			//action
			When.onTheAppPage.iSeeNotAssignedCases();

			// Assertions
			Then.onTheAppPage.iShouldSeeNotAssignedCases();

		});
		opaTest("Should see All CMS Cases", function (Given, When, Then) {

			//action
			When.onTheAppPage.iSeeAllCMSCases();

			// Assertions
			Then.onTheAppPage.iShouldSeeAllCMSCases();

			//Cleanup
			// Then.iTeardownMyApp();
		});

	});