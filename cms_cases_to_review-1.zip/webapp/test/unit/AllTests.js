sap.ui.define([
	"c2r/o2c/cms_cases_to_review/test/unit/controller/Base.controller"
], function () {
	"use strict";
});