/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"c2r/o2c/cms_cases_to_review/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});