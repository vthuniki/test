/* global Uint8Array */
sap.ui.define([
	"c2r/dcd/dcdai/controller/BaseController",
	"sap/ui/core/BusyIndicator",
	"sap/m/PDFViewer",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageStrip",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"c2r/dcd/dcdai/js/pdfjs/build/pdf.worker",
	"c2r/dcd/dcdai/model/formatter",
	"c2r/dcd/dcdai/model/models",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/library"
], function (BaseController, BusyIndicator, PDFViewer, JSONModel, MessageStrip, MessageBox, MessageToast, PdfWorker, formatter, models,
	DateFormat, coreLibrary) {
	"use strict";
	return BaseController.extend("c2r.dcd.dcdai.controller.ClauseDetail", {
		formatter: formatter,
		models: models,
		onInit: function () {
			var oRouter = this.getRouter();
			oRouter.getRoute("ClauseDetail").attachPatternMatched(this.onRoutePatternMatched, this);
		},

		/*To re-enable the launchpad back button*/
		onExit: function () {
			if (sap.ushell) {
				sap.ushell.Container.getRenderer("fiori2").showHeaderItem("backBtn", false);
			}
			this.onDequeue();
		},

		/* Calling PDF.js Library and reading the pdf file
			also setting the PDF file to the model */
		onRoutePatternMatched: function (oEvent) {
			/*To disable the launchpad back button*/
			if (sap.ushell) {
				sap.ushell.Container.getRenderer("fiori2").hideHeaderItem("backBtn", false);
			}
			this.selectionFlag = true;
			this.getView().byId("clauseDetailSmartTable").setBusy(true);
			this.oCaseData = oEvent.getParameter("arguments");
			if (this.oCaseData.furtherReview === undefined) {
				this.oCaseData.furtherReview = "";
			}
			this.checkDoc(this.oCaseData);
			var smartFilterBar = this.getView().byId("smartFilterBar");
			if (smartFilterBar.isInitialised()) {
				var field = smartFilterBar.getControlByKey("FurtherReview");
				field.setSelectedKey(this.oCaseData.furtherReview);
			}
			this._getSystemInfo();

		},
		// Select first row of the table by default
		defaultSelection: function () {
			if (this.selectionFlag) {
				var table = this.getView().byId("clauseTable");
				table.setSelectedItem(table.getItems()[0], true);
				// this.sPath = table.getSelectedContextPaths()[0];
				table.fireSelectionChange({
					listItem: table.getItems()[0],
					selected: true
				});
			}
		},

		// Lock - Enqueue of CaseId
		onEnqueue: function (oCaseData) {
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("CaseId", "EQ", oCaseData.caseData));
			aFilter.push(new sap.ui.model.Filter("Identifier", "EQ", "E"));
			this.getOwnerComponent().getModel().read("/ZDCD_C_ACTIONINDEX", {
				filters: aFilter
			});
		},

		// Unlock - Dequeue of CaseId
		onDequeue: function () {
			var that = this;
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("CaseId", "EQ", this.oCaseData.caseData));
			aFilter.push(new sap.ui.model.Filter("Identifier", "EQ", "D"));
			this.getOwnerComponent().getModel().read("/ZDCD_C_ACTIONINDEX", {
				filters: aFilter,
				success: function (oData) {
					//to do
					that.getRouter().navTo("ContractMaster");
				}
			});
		},

		//expand
		onExpand: function (oEvent) {
			var oResourceBundle = this.getResourceBundle();
			if (oEvent.getParameter("pressed")) {
				this.getView().byId("splitterData").setSize("0%");
				oEvent.getSource().setIcon("sap-icon://exit-full-screen");
				oEvent.getSource().setTooltip(oResourceBundle.getText("exitFullScreen"));
			} else {
				this.getView().byId("splitterData").setSize("53%");
				oEvent.getSource().setIcon("sap-icon://full-screen");
				oEvent.getSource().setTooltip(oResourceBundle.getText("enterFullScreen"));
			}
		},

		//zoom in
		onZoomIn: function (oEvent) {
			var oResourceBundle = this.getResourceBundle();
			var sPageId = this.getView().byId("rightHandPage").getId(),
				sPageWidth = jQuery.sap.byId(sPageId)[0].offsetWidth,
				sCanvasWidth = jQuery.sap.byId("the-canvas1")[0].width;
			if ((sPageWidth - sCanvasWidth) >= 200) {
				this.scale += 0.25;
				var iPageNo = parseInt(this.getOwnerComponent().getModel("appConfigModel").getProperty("/pageNo"), 10);
				var currentHighlight = this.getOwnerComponent().getModel().getData(this.currentRow);
				var iCurrPage = parseInt(currentHighlight.PageNo.substring(8), 10);
				var sCurrCoordinates = currentHighlight.HighlightedCoordinates.substring(8, (currentHighlight.HighlightedCoordinates.length - 1)).split(
					", ").join(
					",");
				if (iCurrPage === iPageNo) {
					this.fnRenderPage(iCurrPage, sCurrCoordinates);
				} else {
					this.fnRenderPage(iPageNo);
				}
			} else {
				MessageBox.warning(oResourceBundle.getText("maxZoomWarning"));
			}
		},

		//zoom out
		onZoomOut: function (oEvent) {
			if (this.scale && this.scale > 1) {
				this.scale -= 0.25;
				var iPageNo = parseInt(this.getOwnerComponent().getModel("appConfigModel").getProperty("/pageNo"), 10);
				var currentHighlight = this.getOwnerComponent().getModel().getData(this.currentRow);
				var iCurrPage = parseInt(currentHighlight.PageNo.substring(8), 10);
				var sCurrCoordinates = currentHighlight.HighlightedCoordinates.substring(8, (currentHighlight.HighlightedCoordinates.length - 1)).split(
					", ").join(
					",");
				if (iCurrPage === iPageNo) {
					this.fnRenderPage(iCurrPage, sCurrCoordinates);
				} else {
					this.fnRenderPage(iPageNo);
				}
			}
		},

		//Check if Doc is available 
		checkDoc: function (oCaseData) {
			var that = this;
			var oResourceBundle = this.getResourceBundle();
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("CaseGuid", "EQ", oCaseData.caseGUID));
			this.getOwnerComponent().getModel().read("/ZDCD_I_CMSDOCS", {
				filters: aFilter,
				success: function (oData) {
					if (oData.results.length > 0) {
						that.onEnqueue(oCaseData);
						//Begin of Extracting Final and Executed Documents seperately with count
						var oDocument = {
							Final: [],
							Executed: [],
							FinalTotal: 0,
							ExecutedTotal: 0
						};
						oData.results.forEach(function (val) {
							oDocument[val.StatusDescription].push(val);
						});
						oDocument.FinalTotal = oDocument.Final.length;
						oDocument.ExecutedTotal = oDocument.Executed.length;
						var jModel = new sap.ui.model.json.JSONModel(oDocument);
						that.setModel(jModel, "documentModel");
						//End of Extracting Final and Executed Documents seperately with count
						that.getView().byId("clauseDetailSmartTable").rebindTable();
						that.resetAllData();
						that.pdfjsLib = window["pdfjs-dist/build/pdf"];
						that.pdfjsLib.GlobalWorkerOptions.workerSrc = PdfWorker;
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/caseId", that.oCaseData.caseData);
						var oModel = that.getOwnerComponent().getModel();
						that.setModel(oModel);
						var oCanvas = jQuery.sap.byId("the-canvas1")[0];
						if (oCanvas) {
							var oCanvasContext = oCanvas.getContext("2d");
							oCanvasContext.clearRect(0, 0, oCanvas.width, oCanvas.height);
							oCanvas.style.border = "none";
							that.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleCanvas", false);
						}
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/fileName", that.getModel("documentModel").getProperty(
							"/Final/0/FileName"));
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/documentId", that.getModel("documentModel").getProperty(
							"/Final/0/DocumentID"));
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/newFileName", that.getModel("documentModel").getProperty(
							"/Final/0/FileName"));
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/newDocumentId", that.getModel("documentModel").getProperty(
							"/Final/0/DocumentID"));
						that.byId("rightContainer").setBusy(false);
					} else {
						that.resetAllData();
						MessageBox.error(oResourceBundle.getText("docNotFoundError"), {
							actions: ["Go Back"],
							onClose: function (sAction) {
								that.getRouter().navTo("ContractMaster");
							}
						});
					}

				},
				error: function (oError) {}
			});
		},

		/*Remove highlighting on the PDF*/
		removeHighlight: function () {
			var page = this.pageNo;
			this.fnRenderPage(page);
			this.newBbox = "";
			this.saveHighlight("removeHighlighting");
			this.editFlag = 1;
		},

		/*Revert highlighting on the PDF*/
		resetHighlight: function () {
			var oHighlightData = this.getOwnerComponent().getModel("appConfigModel").getProperty("/oldHighlightData" + this.currentRow);
			if (!oHighlightData.valid) {
				var defaultFile = this.getModel("documentModel").getProperty(
					"/Executed")[0];
				oHighlightData.bBox = "";
				oHighlightData.pageNo = 0;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/fileName", defaultFile.FileName);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/documentId", defaultFile.DocumentID);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/newFileName", defaultFile.FileName);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/newDocumentId", defaultFile.DocumentID);
				this.appendthumb(1);
			}
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/newFileName", oHighlightData.docName);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/newDocumentId", oHighlightData.docId);
			var sBase64pdf1;
			var that = this;
			var aDocuments = this.getModel("documentModel").getProperty("/Final").concat(this.getModel("documentModel").getProperty(
				"/Executed"));
			for (var i = 0; i < aDocuments.length; i++) {
				var oVal = aDocuments[i];
				if (oVal.DocumentID === oHighlightData.docId) {
					if (oVal.Data !== "") {
						sBase64pdf1 = atob(oVal.Data);
						break;
					}
				}
			}
			if (sBase64pdf1 === undefined) {
				oVal = this.getModel("documentModel").getProperty(
					"/Executed")[0];
				sBase64pdf1 = atob(oVal.Data);
			}
			this.pdfjsLib.getDocument({
				"data": sBase64pdf1
			}).then(function (sPdf) {
				var sProcessedDoc = sPdf;
				BusyIndicator.hide();
				that.getOwnerComponent().getModel("pdfmodel").setData({
					pdffile: sBase64pdf1,
					processedDoc: sProcessedDoc
				});
				that.fnRenderPage(oHighlightData.pageNo, oHighlightData.bBox);
				that.appendthumb(oHighlightData.pageNo === 0 ? 1 : oHighlightData.pageNo);
			});
			// this.fnRenderPage(oHighlightData.pageNo, oHighlightData.bBox);
			this.pageNo = oHighlightData.pageNo;
			this.newBbox = oHighlightData.bBox;
			this.saveHighlight("revertHighlighting");
		},
		/*
			Scale the coordinates back to the ratio value between 0 to 1
			@param(Array)Array of highlighting coordinates according to the canvas size on UI
			@return(Array)Array of coordinates in the ratio between 0 to 1 to save back to the database
			Called inside saveHighlight() function
		*/
		_deScaleCoordinates: function (oBoundingBox) {
			oBoundingBox[2] = (parseFloat(oBoundingBox[2], 10) + parseFloat(oBoundingBox[0], 10));
			oBoundingBox[3] = (parseFloat(oBoundingBox[3], 10) + parseFloat(oBoundingBox[1], 10));
			oBoundingBox[0] = parseFloat(oBoundingBox[0], 10) / this.renderedPageWidth;
			oBoundingBox[1] = parseFloat(oBoundingBox[1], 10) / this.renderedPageHeight;
			oBoundingBox[2] = oBoundingBox[2] / this.renderedPageWidth;
			oBoundingBox[3] = oBoundingBox[3] / this.renderedPageHeight;
			return oBoundingBox;
		},

		/*Save highlighting on the PDF*/
		saveHighlight: function (messageDisplay) {
			var that = this;
			var msgSuccess = messageDisplay;
			if (!messageDisplay) {
				msgSuccess = "newHighlightingSaveText";
			}
			var oResourceBundle = this.getResourceBundle();
			if (this.newBbox && this.newBbox.split(",").length === 4) {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/msgStripVisible", false);
			}
			if (!this.newBbox) {
				that.getOwnerComponent().getModel().setProperty(that.currentRow + "/HighlightedCoordinates", '"pos": [' + "" +
					']');
				that.getOwnerComponent().getModel().setProperty(that.currentRow + "/PageNo", '"page": 00' + 0);
				that.getOwnerComponent().getModel().setProperty(that.currentRow + "/DocumentUsed", that.getOwnerComponent()
					.getModel("appConfigModel").getProperty("/oldHighlightData" + that.currentRow).docName);
				that.getOwnerComponent().getModel().setProperty(that.currentRow + "/DocumentId", that.getOwnerComponent()
					.getModel("appConfigModel").getProperty("/oldHighlightData" + that.currentRow).docId);
				MessageToast.show(oResourceBundle.getText(msgSuccess));
				that.editFlag = 0;
			} else {
				var oBoundingBox = this.newBbox.split(",");
				if (oBoundingBox[0] > 1) {
					oBoundingBox = that._deScaleCoordinates(oBoundingBox);
					this.newBbox = oBoundingBox.join();
				}
				this.getOwnerComponent().getModel().setProperty(this.currentRow + "/HighlightedCoordinates", '"pos": [' + this.newBbox + ']');
				this.getOwnerComponent().getModel().setProperty(this.currentRow + "/PageNo", '"page": ' + this.paddingInteger(this.pageNo));
				this.getOwnerComponent().getModel().setProperty(this.currentRow + "/DocumentUsed", this.getOwnerComponent().getModel(
					"appConfigModel").getProperty("/newFileName"));
				this.getOwnerComponent().getModel().setProperty(this.currentRow + "/DocumentId", this.getOwnerComponent().getModel(
					"appConfigModel").getProperty("/newDocumentId"));
				MessageToast.show(oResourceBundle.getText(msgSuccess));
				this.editFlag = 0;
			}
			this.handlePreApprovedChanges("highlighting");
		},
		/*
			Convert the page number into 3 digit string
			@param(Number)Page number of type number
			@return(String)A 3 character string for the page number
			Called inside saveHighlight() function
		*/
		paddingInteger: function (pageNo) {
			var sPageNo = String(pageNo);
			while (sPageNo.length < 3) {
				sPageNo = "0" + sPageNo;
			}
			return sPageNo;
		},
		/*
			Scale the coordinates according the convas size
			@param(Array)An array of highlighting coordinates
			@return(Array) Array of scaled coordinates
			Called inside fnRenderPage() function
			*/
		_scaleCoordinates: function (oBoundingBox) {
			oBoundingBox[0] = oBoundingBox[0] * this.renderedPageWidth;
			oBoundingBox[1] = oBoundingBox[1] * this.renderedPageHeight;
			oBoundingBox[2] = (oBoundingBox[2] * this.renderedPageWidth) - oBoundingBox[0];
			oBoundingBox[3] = (oBoundingBox[3] * this.renderedPageHeight) - oBoundingBox[1];
			return oBoundingBox;
		},

		/* Rendering the requested page from the file
			and displaying it in canvas
			INPUT - PageNumber and BoundingBox
			OUTPUT - Display the pdf page with highlighted section */
		fnRenderPage: function (iPageNo, oBBox) {
			var that = this;
			var initPageNo = iPageNo;
			var scale;
			var iScale = this.scale;
			var oCanvas = jQuery.sap.byId("the-canvas1")[0];
			var oCanvasContext = oCanvas.getContext("2d");
			var oResourceBundle = this.getResourceBundle();
			var sPdf = this.getOwnerComponent().getModel("pdfmodel").getProperty("/processedDoc");
			var iTotalPages = sPdf.numPages;
			if (iPageNo > iTotalPages) {
				iPageNo = 0;
				MessageBox.information(oResourceBundle.getText("pageNumPDFerror"));
			}
			that.pageNo = iPageNo;
			if (isNaN(iPageNo) || iPageNo === 0) {
				that.pageNo = 1;
				iPageNo = 1;
				oBBox = "";
				that.newBbox = "";
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/msgStripVisible", true);
				that.editFlag = 1;
			} else {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/msgStripVisible", false);
			}
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNo", iPageNo);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/currPageNo", iPageNo);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/totalPages", iTotalPages);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageBack", (iPageNo === 1) ? false : true);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNext", (iPageNo === iTotalPages) ? false : true);
			$(oCanvas).off("mousedown");
			sPdf.getPage(that.pageNo).then(function (oPage) {
				var viewport = oPage.getViewport(iScale);
				oCanvas.height = viewport.height;
				oCanvas.width = viewport.width;
				that.renderedPageHeight = oCanvas.height;
				that.renderedPageWidth = oCanvas.width;
				var oRenderContext = {
					canvasContext: oCanvasContext,
					viewport: viewport
				};
				that.renderCanvas = oPage.render(oRenderContext);
				that.renderCanvas.then(function () {
					oCanvas.style.border = "1px solid black";
					if (!oBBox) {
						var isDrawing = false;
						var startX;
						var startY;
						var flag = 0;
						//Mousedown
						$(oCanvas).on("mousedown", function (e) {
							if (that.editFlag === 1) {
								var pos;
								if (isDrawing && flag === 1) {
									pos = that.getMousePos(oCanvas, e);
									isDrawing = false;
									oCanvasContext.beginPath();
									that.newBbox = "" + startX + "," + startY + "," + (pos.x - startX) + "," + (pos.y - startY);
									that.pageNo = iPageNo;
									oCanvasContext.rect(startX, startY, pos.x - startX, pos.y - startY);
									oCanvasContext.fillStyle = "rgba(236,245,114,0.6)";
									oCanvasContext.fill();
									oCanvas.style.cursor = "default";
									$(oCanvas).off("mousedown");
									that.editFlag = 1;
									flag = 0;
									that.saveHighlight();
								} else {
									pos = that.getMousePos(oCanvas, e);
									isDrawing = true;
									startX = pos.x;
									startY = pos.y;
									oCanvas.style.cursor = "crosshair";
								}
							}
						});
						$(oCanvas).on("mousemove", function (evt) {
							if (isDrawing && flag === 0 && !(evt.pageX === startX && evt.pageY === startY)) {
								flag = 2;
							}
						});
						$(oCanvas).on("mouseup", function (e) {
							if (isDrawing && flag === 0) {
								flag = 1;
							}
							if (isDrawing && flag === 2 && that.editFlag === 1) {
								var pos = that.getMousePos(oCanvas, e);
								isDrawing = false;
								oCanvasContext.beginPath();
								that.newBbox = "" + startX + "," + startY + "," + (pos.x - startX) + "," + (pos.y - startY);
								that.pageNo = iPageNo;
								oCanvasContext.rect(startX, startY, pos.x - startX, pos.y - startY);
								oCanvasContext.fillStyle = "rgba(236,245,114,0.6)";
								oCanvasContext.fill();
								oCanvas.style.cursor = "default";
								$(oCanvas).off("mousedown");
								that.editFlag = 1;
								flag = 0;
								that.saveHighlight();
							}
						});
					} else {
						var oBoundingBox = oBBox.split(",");
						oCanvasContext.beginPath();
						oBoundingBox = that._scaleCoordinates(oBoundingBox);
						oCanvasContext.rect(oBoundingBox[0], oBoundingBox[1], oBoundingBox[2], oBoundingBox[3]);
						oCanvasContext.fillStyle = "rgba(236,245,114,0.6)";
						oCanvasContext.fill();
					}
					that.getView().byId("clauseDetailSmartTable").setBusy(false);
				}).catch(function (oError) {
					MessageBox.warning(oResourceBundle.getText("pageRenderError"), {
						onClose: function (sAction) {
							that.fnRenderPage(initPageNo, oBBox);
						}
					});
					that.getView().byId("clauseDetailSmartTable").setBusy(false);
				});
			}).catch(function () {
				MessageBox.error(oResourceBundle.getText("pageNotFoundError"));
				that.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleCanvas", false);
				that.getView().byId("clauseDetailSmartTable").setBusy(false);
			});
		},

		/*To get mouse current coordinates for new highlighting*/
		getMousePos: function (canvas, evt) {
			var rect = canvas.getBoundingClientRect();
			return {
				x: (evt.clientX - rect.left) / (rect.right - rect.left) * canvas.width,
				y: (evt.clientY - rect.top) / (rect.bottom - rect.top) * canvas.height
			};
		},
		/* Route Back to ContractMaster Page on click of Back Button */
		onPressMasterBack: function () {
			var that = this;
			var smartFilterBar = this.getView().byId("smartFilterBar");
			var field = smartFilterBar.getControlByKey("FurtherReview");
			field.setSelectedKey(null);
			var oResourceBundle = this.getResourceBundle();
			if (Object.keys(this.getOwnerComponent().getModel().getPendingChanges()).length === 0) {
				that.onDequeue();
			} else {
				MessageBox.confirm(
					oResourceBundle.getText("discardChanges"), {
						onClose: function (sAction) {
							if (sAction !== "OK") {
								return;
							} else {
								that.getOwnerComponent().getModel().resetChanges();
								that.onDequeue();
							}
						}
					}
				);
			}
		},

		/* Dynamically Gererate MessageStrip
			Called internally from onPressRow function*/
		_generateMsgStrip: function () {
			var oVC = this.getView().byId("msgStrip"),
				oMsgStrip = new MessageStrip("msgStrip", {
					text: this.getResourceBundle().getText("noHighlightErrorMsg"),
					showCloseButton: false,
					showIcon: true,
					type: "Warning"
				});
			oVC.addItem(oMsgStrip);
		},
		/*
			Internal function called to load the specific pdf page(called inside onPressRow() function)
			@param(source of the data field table)
			@param(binding context of the pressed row)
		*/
		_loadPdfPage: function (source, pressedRowObject) {
			var oResourceBundle = this.getResourceBundle();
			var that = this;
			this.currentItem = source.getSelectedItem();
			var sBase64pdf1;
			if (this.getModel("documentModel")) {
				this.selectionFlag = false;
				var aDocuments = this.getModel("documentModel").getProperty("/Final").concat(this.getModel("documentModel").getProperty(
					"/Executed"));
				for (var i = 0; i < aDocuments.length; i++) {
					var oVal = aDocuments[i];
					if (oVal.DocumentID === pressedRowObject.DocumentId) {
						if (oVal.Data !== "") {
							sBase64pdf1 = atob(oVal.Data);
							break;
						} else {
							// MessageBox.error(oVal.Message);
							// return;
						}
					}
				}
				var iPageNo = parseInt(pressedRowObject.PageNo.substring(8), 10);
				var oBBox = pressedRowObject.HighlightedCoordinates.substring(8, (pressedRowObject.HighlightedCoordinates.length - 1)).split(", ")
					.join(
						",");

				if (!(this.getOwnerComponent().getModel("appConfigModel").getProperty("/oldHighlightData")[this.currentRow.substr(1)])) {
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/oldHighlightData" + this.currentRow, {
						pageNo: iPageNo,
						bBox: oBBox,
						docName: pressedRowObject.DocumentUsed,
						docId: pressedRowObject.DocumentId,
						valid: sBase64pdf1 === undefined ? false : true

					});
				}
				pressedRowObject.HighlightedCoordinates = oBBox;
				pressedRowObject.PageNo = iPageNo;
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleCanvas", true);
				source.getBusy(true);

				if (sBase64pdf1 === undefined) {
					if (this.getView().getModel("documentModel").getProperty("/Executed").length === 0) {
						MessageBox.error(oResourceBundle.getText("noExecutedDoc"));
						this.getOwnerComponent().getModel("appConfigModel").setProperty("/visibleCanvas", false);
						source.getBusy(false);
					} else {
						MessageBox.error(oResourceBundle.getText("noPdfError"));
						oVal = this.getModel("documentModel").getProperty(
							"/Executed")[0];
						sBase64pdf1 = atob(oVal.Data);
						pressedRowObject.HighlightedCoordinates = "";
						pressedRowObject.PageNo = 0;
					}
				}
				that.getOwnerComponent().getModel("appConfigModel").setProperty("/fileName", oVal.FileName);
				that.getOwnerComponent().getModel("appConfigModel").setProperty("/documentId", oVal.DocumentID);
				that.getOwnerComponent().getModel("appConfigModel").setProperty("/newFileName", oVal.FileName);
				that.getOwnerComponent().getModel("appConfigModel").setProperty("/newDocumentId", oVal.DocumentID);
				that.pdfjsLib.getDocument({
					"data": sBase64pdf1
				}).then(function (sPdf) {
					var sProcessedDoc = sPdf;
					BusyIndicator.hide();
					that.getOwnerComponent().getModel("pdfmodel").setData({
						pdffile: sBase64pdf1,
						processedDoc: sProcessedDoc
					});
					that.fnRenderPage(pressedRowObject.PageNo, pressedRowObject.HighlightedCoordinates);
					that.appendthumb(pressedRowObject.PageNo === 0 ? 1 : pressedRowObject.PageNo);
				});
			}
		},
		/* Called when table row is clicked
				Fetch page number and BoundingBox from table row
				and pass to fnRenderPage function to display the page*/
		onPressRow: function (oEvent) {
			this.scale = 3;
			var source = oEvent.getSource();
			var oResourceBundle = this.getResourceBundle();
			var pressedRow = oEvent.getParameter("listItem").getBindingContext();
			this.rowPath = pressedRow.getPath();
			var pressedRowObject = pressedRow.getObject();
			if (pressedRowObject.ApprovalStatus === "02") {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/editHighlightingButtons", false);
			} else {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/editHighlightingButtons", true);
			}
			var that = this;
			this.currentRow = pressedRow.getPath();

			// this.sPath = pressedRow.getPath();
			that._loadPdfPage(source, pressedRowObject);
		},
		/* To create and open the popover
			for Executed Documents 
			Called on click on Executed Document Link */
		exeDocPopover: function (oEvent) {
			if (!this.oExeDocPopover) {
				this.oExeDocPopover = sap.ui.xmlfragment("c2r.dcd.dcdai.fragment.exeDoc", this);
				this.getView().addDependent(this.oExeDocPopover);
			}
			this.oExeDocPopover.openBy(oEvent.getSource());
		},

		/* To create and open the popover
			for Final Documents 
			Called on click on Final Document Link */
		finalDocPopover: function (oEvent) {
			if (!this.oFinalDocPopover) {
				this.oFinalDocPopover = sap.ui.xmlfragment("c2r.dcd.dcdai.fragment.finalDoc", this);
				this.getView().addDependent(this.oFinalDocPopover);
			}
			this.oFinalDocPopover.openBy(oEvent.getSource());
		},

		/* Load the PDF file and
			Display it in PDFViewer 
			Called on click of File Name in Executed or Final Documents*/
		onFilenamePress: function (oEvent) {
			if (oEvent.getParameter("item").getBindingContext("documentModel").getObject().Data !== "") {
				var sBase64pdf1 = atob(oEvent.getParameter("item").getBindingContext("documentModel").getObject().Data);
				if (sBase64pdf1) {
					var aByteArray = new Uint8Array(sBase64pdf1.length);
					for (var i = 0; i < sBase64pdf1.length; i++) {
						aByteArray[i] = sBase64pdf1.charCodeAt(i);
					}
					var oBlob = new Blob([aByteArray.buffer], {
						type: "application/pdf"
					});
					var pdfurl = URL.createObjectURL(oBlob);
					jQuery.sap.addUrlWhitelist("blob");
					var oPdfViewer = new PDFViewer();
					this.getView().addDependent(oPdfViewer);
					oPdfViewer.setSource(pdfurl);
					oPdfViewer.setTitle(this.getResourceBundle().getText("PdfViewerTitle"));
					oPdfViewer.open();
				} else {
					MessageBox.error(this.getResourceBundle().getText("noDocumentFoundErrorText"));
				}
			} else {
				MessageBox.error(oEvent.getParameter("item").getBindingContext("documentModel").getObject().Message);
			}
		},

		/* Display possible values popover */
		onChangePrediction: function (oEvent) {
			var aResults = [];
			var that = this;
			var buttonSource = oEvent.getSource();
			var oldValData = this.getOwnerComponent().getModel("appConfigModel").getProperty("/oldValues");
			var sInputValue = oEvent.getSource().getBindingContext().getObject();
			this.sPath = oEvent.getSource().getBindingContext().getPath(); //get Binding Path
			// this.oSelectedRow = oEvent.getSource().getParent().getParent();
			var sDataField = sInputValue.DataField;
			this.getOwnerComponent().getModel().read("/ZDCD_I_MLDTFLD_PSVL('" + sDataField + "')", {
				success: function (oResult) {
					var possibleValues = oResult.PossibleValues;
					possibleValues.split(",").forEach(function (val) {
						aResults.push({
							newValue: val
						});
					});
					if (possibleValues === "Date") {
						if (!that.oCorrectedValuePopoverD) {
							that.oCorrectedValuePopoverD = sap.ui.xmlfragment("c2r.dcd.dcdai.fragment.predictedValueHelpDate", that);
							that.getView().addDependent(that.oCorrectedValuePopoverD);
						}
						that.oCorrectedValuePopoverD.openBy(buttonSource);
						oldValData = {
							predictedValue: sInputValue.PredictedValue,
							correctedValue: sInputValue.CorrectedValue
						};
						that.getModel("appConfigModel").setProperty("/oldValues", oldValData);
					} else if (possibleValues !== "Text") {
						if (!that.oCorrectedValuePopoverDD) {
							that.oCorrectedValuePopoverDD = sap.ui.xmlfragment("c2r.dcd.dcdai.fragment.predictedValuehelp", that);
							that.getView().addDependent(that.oCorrectedValuePopoverDD);
						}
						that.oCorrectedValuePopoverDD.openBy(buttonSource);
						oldValData = {
							predictedValue: sInputValue.PredictedValue,
							correctedValue: sInputValue.CorrectedValue
						};
						that.getModel("appConfigModel").setProperty("/oldValues", oldValData);
					} else {
						if (!that.oCorrectedValuePopoverFT) {
							that.oCorrectedValuePopoverFT = sap.ui.xmlfragment("c2r.dcd.dcdai.fragment.predictedValuehelpFreeText", that);
							that.getView().addDependent(that.oCorrectedValuePopoverFT);
						}
						that.oCorrectedValuePopoverFT.openBy(buttonSource);
						oldValData = {
							predictedValue: sInputValue.PredictedValue,
							correctedValue: sInputValue.CorrectedValue
						};
						that.getModel("appConfigModel").setProperty("/oldValues", oldValData);
					}
					that.getOwnerComponent().getModel("appConfigModel").setProperty("/results", aResults);
				},
				error: function (oError) {
					if (oError.statusText === "Not Found") {
						MessageBox.error(that.getResourceBundle().getText("noPossibleValueErrorText"));
					}
				}
			});
		},

		/* Set the corrected value choosen by user
			to the predicted value input field 
			Called on selecting item in dropdown popover*/
		handleSelection: function (oEvent) {
			var sSelectedItem = oEvent.getSource().getProperty("title");
			if (sSelectedItem) {
				this.getOwnerComponent().getModel().setProperty(this.sPath + "/CorrectedValue", sSelectedItem);
			}
			this.handlePreApprovedChanges();
			this.oCorrectedValuePopoverDD.close();
		},

		handleCalendarSelect: function (oEvent) {
			var oCalendar = oEvent.getSource(),
				aSelectedDates = oCalendar.getSelectedDates(),
				oDate = aSelectedDates[0].getStartDate(),
				CalendarType = coreLibrary.CalendarType,
				oFormatYyyymmdd = DateFormat.getInstance({
					pattern: "yyyyMMdd",
					calendarType: CalendarType.Gregorian
				}),
				sDate = oFormatYyyymmdd.format(oDate);
			this.getOwnerComponent().getModel().setProperty(this.sPath + "/CorrectedValue", sDate);
			this.handlePreApprovedChanges();
			this.oCorrectedValuePopoverD.close();
		},
		/* Set the corrected value choosen by user
			to the predicted value input fields 
			Called on selecting item in dropdown popover*/
		handleSubmitPress: function (oEvent) {
			var sSelectedItem = oEvent.getSource().data().value;
			if (!sSelectedItem) {
				sSelectedItem = '-';
			}
			this.getOwnerComponent().getModel().setProperty(this.sPath + "/CorrectedValue", sSelectedItem);
			if (sSelectedItem === "-") {
				this.getOwnerComponent().getModel().setProperty(this.sPath + "/ApprovalStatus", "03");
				// this.oSelectedRow.getCells()[4].getItems()[0].setState(false);
				// this.aApprovedRows.splice(this.aApprovedRows.indexOf(this.sPath), 1);
			}
			this.handlePreApprovedChanges();
			this.oCorrectedValuePopoverFT.close();
		},
		changePage: function (iPageNo) {
			var iTotalPages = this.getOwnerComponent().getModel("pdfmodel").getProperty("/processedDoc").numPages;
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNo", iPageNo);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/currPageNo", iPageNo);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageBack", (iPageNo === 1) ? false : true);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNext", (iPageNo === iTotalPages) ? false : true);
			var currentHighlight = this.getOwnerComponent().getModel().getData(this.currentRow);
			var iCurrPage = parseInt(currentHighlight.PageNo.substring(8), 10);
			var sCurrCoordinates = currentHighlight.HighlightedCoordinates.substring(8, (currentHighlight.HighlightedCoordinates.length - 1)).split(
				", ").join(
				",");
			if (iCurrPage === iPageNo) {
				this.fnRenderPage(iCurrPage, sCurrCoordinates);
			} else {
				this.fnRenderPage(iPageNo);
			}
		},
		// Load the previous page of te PDF
		onPageBack: function (oEvent) {
			var iPageNo = parseInt(this.getOwnerComponent().getModel("appConfigModel").getProperty("/pageNo"), 10) - 1;
			this.changePage(iPageNo);
			this.appendthumb(iPageNo);
		},
		// Load the Next page of te PDF
		onPageNext: function (oEvent) {
			var iPageNo = parseInt(this.getOwnerComponent().getModel("appConfigModel").getProperty("/pageNo"), 10) + 1;
			this.changePage(iPageNo);
			this.appendthumb(iPageNo);
		},

		/* Reset te changes made in the table on click on RESET button */
		onResetPage: function () {
			this.getOwnerComponent().getModel().resetChanges();
		},

		/* Save te changes made in the table on click on SAVE button */
		onSubmitPage: function () {
			var filters = [];
			filters.push(new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.EQ, this.oCaseData.caseData));
			filters.push(new sap.ui.model.Filter("CaseGuid", sap.ui.model.FilterOperator.EQ, this.oCaseData.caseGUID));
			var oResourceBundle = this.getResourceBundle();
			var oController = this;
			for (var sKey in this.getOwnerComponent().getModel().getPendingChanges()) {
				if (this.getOwnerComponent().getModel().getPendingChanges()[sKey].ApprovalStatus === "true") {
					this.getOwnerComponent().getModel().setProperty("/" + sKey + "/ConfidenceLevel", "1.0");
					this.getOwnerComponent().getModel().setProperty("/" + sKey + "/ApprovalStatus", "02");
				}
			}
			this.getOwnerComponent().getModel().submitChanges({
				success: function (oArg) {
					MessageToast.show(oResourceBundle.getText("saveChangesSuccessMsg"));
					this.getOwnerComponent().getModel("appConfigModel").setProperty("/oldHighlightData", {});
					var that = this;
					that.getOwnerComponent().getModel().read("/ZDCD_I_ACTNINDEX/$count", {
						filters: filters,
						success: function (oData, response) {
							if (response.body === "0") {
								that.onDequeue();
							}
						}

					});
				}.bind(this)
			});
		},
		// Change the approval status and corresspondingly further review
		onChangeApprovalStatus: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext().getPath();
			this.getOwnerComponent().getModel().setProperty(sPath + "/ApprovalStatus", (oEvent.getSource().getState()) ? "true" : "03");
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/editHighlightingButtons", (oEvent.getSource().getState()) ? false :
				true);
			if (oEvent.getSource().getState()) {
				this.getOwnerComponent().getModel().setProperty(sPath + "/FurtherReview", false);
			}
		},
		// Change further review and corressponding approval status values
		onChangeFurtherReview: function (oEvent) {
			if (oEvent.getSource().getSelected()) {
				this.getOwnerComponent().getModel().setProperty(oEvent.getSource().getParent().getBindingContextPath() + "/ApprovalStatus", "03");
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/editHighlightingButtons", true);
			}
			this.sPath = oEvent.getSource().getParent().getBindingContextPath();
			this.handlePreApprovedChanges();
		},
		// Reset app config model
		resetAllData: function () {
			this.getOwnerComponent().getModel("appConfigModel").setData(this.models.createAppConfigData());
			this.newBbox = "";
			this.pageNo = 0;
			this.editFlag = 0;
			if (this.getView().byId("clauseTable")) {
				this.getView().byId("clauseTable").removeSelections();
			}
		},
		// Rebind the Data field smart table
		onBeforeRebindTable: function (oEvent) {
			var that = this;
			var smartFilterBar = this.getView().byId("smartFilterBar");
			var field = smartFilterBar.getControlByKey("FurtherReview");
			var oBinding = oEvent.getParameter("bindingParams");
			this.oCaseData.furtherReview = field.getSelectedKey();
			oEvent.getSource().attachEvent("dataReceived", function (oData) {
				that.getView().byId("clauseDetailSmartTable").setBusy(false);
				that.defaultSelection();
			}, this);
			if (this.getModel("documentModel") !== undefined) {
				var oFilter = new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.EQ, this.oCaseData.caseData);
				oBinding.filters.push(oFilter);
				var oFilter1 = new sap.ui.model.Filter("CaseGuid", sap.ui.model.FilterOperator.EQ, this.oCaseData.caseGUID);
				oBinding.filters.push(oFilter1);
				if (this.oCaseData.furtherReview) {
					var oFilter2 = new sap.ui.model.Filter("FurtherReview", sap.ui.model.FilterOperator.EQ, this.oCaseData.furtherReview);
					oBinding.filters.push(oFilter2);
				}
			}
			oBinding.sorter.push(new sap.ui.model.Sorter("DataFieldDesc"));
		},
		/*
			Called when user enter a specific page number and press enter
			Render the PDF page requested by user
			@param(Source of the input field for page number)
		*/
		onChangePageNumber: function (oEvent) {
			var iPageNo = parseInt(this.getOwnerComponent().getModel("appConfigModel").getProperty("/pageNo"), 10);
			var iTotalPages = this.getOwnerComponent().getModel("pdfmodel").getProperty("/processedDoc").numPages;
			var iCurrPageNo = this.getOwnerComponent().getModel("appConfigModel").getProperty("/currPageNo");
			if (iPageNo > iTotalPages || iPageNo < 1) {
				MessageBox.error(this.getResourceBundle().getText("wrongPageNumberErr"));
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/pageNo", iCurrPageNo);
			} else {
				var currentHighlight = this.getOwnerComponent().getModel().getData(this.currentRow);
				var iCurrPage = parseInt(currentHighlight.PageNo.substring(8), 10);
				var sCurrCoordinates = currentHighlight.HighlightedCoordinates.substring(8, (currentHighlight.HighlightedCoordinates.length - 1)).split(
					", ").join(
					",");
				if (iCurrPage === iPageNo) {
					this.fnRenderPage(iCurrPage, sCurrCoordinates);
				} else {
					this.fnRenderPage(iPageNo);
				}
				this.appendthumb(iPageNo);
			}
		},
		/*
			Called while user is typing the text in the free text possible value text area
			to check if the user exceed the maximum character limit
		*/
		onLiveChangeTextAreaValue: function (oEvent) {
			var oTextArea = oEvent.getSource(),
				iValueLength = oTextArea.getValue().length,
				iMaxLength = oTextArea.getMaxLength(),
				sState = iValueLength > iMaxLength ? "Warning" : "None",
				bEnabled = iValueLength > iMaxLength ? false : true;

			oTextArea.setValueState(sState);
			oEvent.getSource().getParent().getFooter().getContent()[1].setEnabled(bEnabled);
		},
		/*
			to clear the text area value state and enable the submit button on close of free text area possible value popover
		*/
		onClosePossibleValuePopover: function (oEvent) {
			oEvent.getSource().getContent()[2].setValueState("None");
			oEvent.getSource().getFooter().getContent()[1].setEnabled(true);
		},

		//expand thumbnail view
		onExpandThumbnail: function (oEvent) {
			if (oEvent.getParameter("pressed")) {
				this.byId("thumbnailSplitter").setSize("10%");
			} else {
				this.byId("thumbnailSplitter").setSize("0%");
			}
		},

		//handle changes
		handlePreApprovedChanges: function (detail) {
			var path;
			var sCurrentPath;
			if (!detail) {
				sCurrentPath = this.sPath;
				path = this.sPath.substring(1);
			} else {
				sCurrentPath = this.rowPath;
				path = this.rowPath.substring(1);
			}
			this.getOwnerComponent().getModel().setProperty(sCurrentPath + "/ApprovalStatus", "03");
			var aChanges = this.getOwnerComponent().getModel().getPendingChanges();
			// var path = this.sPath.substring(1);
			if (aChanges[path] && aChanges[path].ApprovalStatus === "03" && Object.keys(aChanges[path]).length === 2) {
				this.getOwnerComponent().getModel().setProperty(sCurrentPath + "/ApprovalStatus", "02");
			}
		},

		appendthumb: function (pageNo) {
			var current = "";
			var sPdf = this.getOwnerComponent().getModel("pdfmodel").getProperty("/processedDoc");
			jQuery.sap.byId("thumbViewer")[0].innerHTML = "";
			var pages = [];
			var that = this;
			while (pages.length < sPdf.numPages) {
				pages.push(pages.length + 1);
			}
			return Promise.all(pages.map(function (num) {
				// create a div for each page and build a small canvas for it
				var div = document.createElement("div");
				div.addEventListener("click", function (oEvent) {
					if (current) {
						current.style.border = "none";
					}
					current = div;
					div.style.border = "3px solid #447bcf";
					that.changePage(num);
				});
				div.style.margin = "5px";
				div.style.textAlign = "center";
				div.style.paddingBottom = "10px";
				if (num == pageNo) {
					current = div;
					div.style.border = "3px solid #447bcf";
				}
				jQuery.sap.byId("thumbViewer")[0].appendChild(div);
				return sPdf.getPage(num).then(that.makeThumb)
					.then(function (thumbCanvas) {
						var p1 = document.createElement('p');
						p1.innerHTML = num;
						p1.style.textAlign = "center";
						p1.style.margin = "0";
						div.appendChild(thumbCanvas);
						div.appendChild(p1);
					});
			}));
		},

		makeThumb: function (page) {
			// draw page to fit into 96x96 canvas
			var vp = page.getViewport(1);
			var canvas = document.createElement("canvas");
			canvas.width = canvas.height = 96;
			var scale = Math.min(canvas.width / vp.width, canvas.height / vp.height);
			return page.render({
				canvasContext: canvas.getContext("2d"),
				viewport: page.getViewport(scale)
			}).promise.then(function () {
				return canvas;
			});
		},

		onChangeDocument: function (oEvent) {
			var buttonSource = oEvent.getSource();
			if (!this.ExecutedDocumentList) {
				this.ExecutedDocumentList = sap.ui.xmlfragment("c2r.dcd.dcdai.fragment.executedDocumentList", this);
				this.getView().addDependent(this.ExecutedDocumentList);
			}
			this.ExecutedDocumentList.openBy(buttonSource);
		},

		onChangeFileName: function (oEvent) {
			var sSelectedDocId = oEvent.getSource().getSelectedKey(),
				sSelectedItemId = oEvent.getSource().getSelectedItemId(),
				iSelectedIndex = parseInt(sSelectedItemId.substr(sSelectedItemId.lastIndexOf("-") + 1), 10),
				sBase64pdf1,
				that = this,
				sOldDocId = this.getOwnerComponent().getModel("appConfigModel").getProperty("/documentId"),
				currentHighlight = this.getOwnerComponent().getModel().getData(this.currentRow),
				iCurrPage = parseInt(currentHighlight.PageNo.substring(8), 10),
				sCurrCoordinates = currentHighlight.HighlightedCoordinates.substring(8, (currentHighlight.HighlightedCoordinates.length - 1)).split(
					", ").join(
					",");
			if (this.getModel("documentModel")) {
				this.selectionFlag = false;
				var oVal = this.getModel("documentModel").getProperty("/Executed/" + iSelectedIndex);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/newDocumentId", oVal.DocumentID);
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/newFileName", oVal.FileName);
				var sData = oVal.Data;
				sBase64pdf1 = atob(sData);
				this.pdfjsLib.getDocument({
					"data": sBase64pdf1
				}).then(function (sPdf) {
					var sProcessedDoc = sPdf;
					BusyIndicator.hide();
					that.getOwnerComponent().getModel("pdfmodel").setData({
						pdffile: sBase64pdf1,
						processedDoc: sProcessedDoc
					});
					if (sOldDocId === sSelectedDocId) {
						that.fnRenderPage(iCurrPage, sCurrCoordinates);
						that.appendthumb(iCurrPage === 0 ? 1 : iCurrPage);
					} else {
						that.fnRenderPage(0);
						that.appendthumb(1);
					}

				});
			}
			this.ExecutedDocumentList.close();
		},

		onMarkOutOfScope: function (oEvent) {
			if (!this.CommentDailog) {
				this.CommentDailog = sap.ui.xmlfragment("c2r.dcd.dcdai.fragment.CommentDialog", this);
				this.getView().addDependent(this.CommentDailog);
			}
			this.CommentDailog.open();
		},
		onLiveChangeCommentValue: function (oEvent) {
			var oTextArea = oEvent.getSource(),
				iValueLength = oTextArea.getValue().length,
				iMaxLength = oTextArea.getMaxLength(),
				sState = iValueLength > iMaxLength ? "Warning" : "None",
				bEnabled = iValueLength > iMaxLength ? false : (iValueLength === 0) ? false : true;

			oTextArea.setValueState(sState);
			oEvent.getSource().getParent().getBeginButton().setEnabled(bEnabled);
		},
		OnCommentDialogClose: function () {
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/CaseComment", "");
			this.CommentDailog.close();
		},
		onConfirmOutOfScope: function () {
			var comment = this.getOwnerComponent().getModel("appConfigModel").getProperty("/CaseComment");
			var that = this;
			var oResourceBundle = this.getResourceBundle();
			var filters = [];
			filters.push(new sap.ui.model.Filter("CaseId", sap.ui.model.FilterOperator.EQ, this.oCaseData.caseData));
			filters.push(new sap.ui.model.Filter("CaseGuid", sap.ui.model.FilterOperator.EQ, this.oCaseData.caseGUID));
			this.getOwnerComponent().getModel().resetChanges();
			this.getView().byId("clauseDetailSmartTable").getTable().getItems().forEach(function (oRow) {
				that.getOwnerComponent().getModel().setProperty(oRow.getBindingContextPath() + "/CaseComment", comment);
				that.getOwnerComponent().getModel().setProperty(oRow.getBindingContextPath() + "/ApprovalStatus", "02");
			});
			this.getOwnerComponent().getModel().submitChanges({
				success: function (oArg) {
					that.CommentDailog.close();
					MessageToast.show(oResourceBundle.getText("CaseMarkedOutOfScopeMsg"));
					that.getOwnerComponent().getModel("appConfigModel").setProperty("/oldHighlightData", {});
					that.getOwnerComponent().getModel().read("/ZDCD_I_ACTNINDEX/$count", {
						filters: filters,
						success: function (oData, response) {
							if (response.body === "0") {
								that.onDequeue();
							}
						}
					});
				}
			});
		}
	});

});