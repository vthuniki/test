sap.ui.define([
	"c2r/dcd/dcdai/controller/BaseController",
], function (BaseController) {
	"use strict";

	return BaseController.extend("c2r.dcd.dcdai.controller.CaseLockedView", {
		onInit: function () {
		},
		onLinkPressed: function () {
			this.getRouter().navTo("ContractMaster");
		}
	});

});