sap.ui.define([
	"c2r/dcd/dcdai/controller/BaseController",
], function (BaseController) {
	"use strict";

	return BaseController.extend("c2r.dcd.dcdai.controller.ObjectNotFound", {
		onLinkPressed: function () {
			this.getRouter().navTo("ContractMaster");
		}
	});

});