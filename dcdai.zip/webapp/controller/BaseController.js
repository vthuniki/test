sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("c2r.dcd.dcdai.controller.BaseController", {
		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},
		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},
		/**
		 * Getter for the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		//getSystem Info 
		_getSystemInfo: function () {
			var that = this;
			this.getOwnerComponent().getModel().callFunction("/GetServer", {
				method: "GET",
				urlParameters: {},
				success: jQuery.proxy(function (oData, response) {
					if (oData.GetServer) {
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/SystemsInfo", oData.GetServer);
						that.getOwnerComponent().getModel("appConfigModel").setProperty("/NavigationEnabled", true);
					}
				}, this),
				error: function (oError) {
					sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},

		//Case Id Press
		onCaseIdPress: function (oEvent) {
			var oCaseId = oEvent.getSource().getText();
			var prefixSubstitute = "000000000000";
			oCaseId = prefixSubstitute.substr(oCaseId.length) + oCaseId;
			var appConfigmodel = this.getOwnerComponent().getModel("appConfigModel");
			var sHTTPS = appConfigmodel.getProperty("/protocol");
			var sSystemID = appConfigmodel.getProperty("/SystemsInfo").SYSID;
			var url = appConfigmodel.getProperty("/url");
			var crmUrlCase = appConfigmodel.getProperty("/crmUrlCase");
			var crmUrlCaseMode = appConfigmodel.getProperty("/crmUrlCaseMode");

			var sUrl = sHTTPS + sSystemID + url + crmUrlCase + oCaseId + crmUrlCaseMode;
			sap.m.URLHelper.redirect(sUrl, true);
		},

		// //getAdminAccess info
		getAdminAccess: function () {
			this.getOwnerComponent().getModel().callFunction("/GetAdminAccess", {
				method: "GET",
				urlParameters: {},
				success: jQuery.proxy(function (oData, response) {
					if (oData.GetAdminAccess) {
						this.getOwnerComponent().getModel("appConfigModel").setProperty("/AdminAccess", oData.GetAdminAccess.ADMIN);
					}
				}, this),
				error: function (oError) {
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		}
	});

});