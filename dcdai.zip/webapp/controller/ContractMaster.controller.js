sap.ui.define([
	"c2r/dcd/dcdai/controller/BaseController",
	"sap/ui/core/mvc/Controller",
	"c2r/dcd/dcdai/model/formatter",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function (BaseController, Controller, formatter, MessageToast, MessageBox) {
	"use strict";
	var posPath;
	return BaseController.extend("c2r.dcd.dcdai.controller.ContractMaster", {
		formatter: formatter,
		onInit: function () {
			var oRouter = this.getRouter();
			oRouter.getRoute("ContractMaster").attachPatternMatched(this.onRoutePatternMatched, this);
		},

		/* Calling PDF.js Library and reading the pdf file
			also setting the PDF file to the model */
		onRoutePatternMatched: function (oEvent) {
			if (sap.ushell) {
				sap.ushell.Container.getRenderer("fiori2").showHeaderItem("backBtn", false);
			}
			this.getView().byId("LineItemsSmartTable").rebindTable();
			this._getSystemInfo();
			this.getAdminAccess();
		},
		//navigate from the ContractMaster page to the Clause detail page
		onNavtoClauseDetail: function (oEvent) {
			this.getOwnerComponent().getModel().resetChanges();
			var caseID = oEvent.getParameters().listItem.getBindingContext().getObject("CaseId"),
				caseGUID = oEvent.getParameters().listItem.getBindingContext().getObject("CaseGuid"),
				smartFilterBar = this.getView().byId("smartFilterBar");
			var field = smartFilterBar.getControlByKey("FurtherReview");
			var furtherReview = field.getSelectedKey();
			this.getOwnerComponent().getRouter().navTo("ClauseDetail", {
				caseData: caseID,
				caseGUID: caseGUID,
				furtherReview: furtherReview
			});
		},

		//open the admin dialog on click of admin button
		onOpenAdminDialog: function (evt, bShowAdmin) {
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/revenueType", 0);
			if (!this.oAdminDialog) {
				this.oAdminDialog = sap.ui.xmlfragment("c2r.dcd.dcdai.fragment.admin", this);
				this.getView().addDependent(this.oAdminDialog);
			}
			this.oAdminDialog.getContent()[0].getItems()[0].getItems()[0].rebindTable();
			this.oAdminDialog.open();
		},

		onPressArchive: function (oEvent) {
			var oResourceBundle = this.getResourceBundle();
			var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNav.isIntentSupported(["archievedaicases-display"])
				.done(function (aResponses) {

				})
				.fail(function () {
					MessageToast(oResourceBundle.getText("navigationErrorMsg"));
				});
			var hash = (oCrossAppNav && oCrossAppNav.hrefForExternal({
				target: {
					shellHash: "archievedaicases-Display"
				}
			})) || "";
			//Generate a  URL for the second application
			var url = window.location.href.split('#')[0] + hash;
			//Navigate to second app
			sap.m.URLHelper.redirect(url, true);
		},
		//close the admin dialog
		onAdminCancel: function () {
			var that = this;
			var oResourceBundle = this.getResourceBundle();
			if (Object.keys(this.getOwnerComponent().getModel().getPendingChanges()).length) {
				MessageBox.confirm(
					oResourceBundle.getText("discardChanges"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								that.getOwnerComponent().getModel().resetChanges();
								MessageToast.show(oResourceBundle.getText("resetChangesMsg"));
								that.oAdminDialog.close();
							}
						}
					}
				);
			} else {
				this.oAdminDialog.close();
			}
		},

		//show the possible value dialog on click of edit button
		onOpenPossibleValueDialog: function (oEvent, bShowPosValue) {
			var oBindingContext = oEvent.getSource().getBindingContext();
			var oCorrectedValues = oBindingContext.getObject().PossibleValues.split(","),
				oCorrectedValuesArr = [];
			posPath = oBindingContext.getPath();
			oCorrectedValues.forEach(function (item, index) {
				var oObj = {};
				oObj["item"] = oCorrectedValues[index];
				oCorrectedValuesArr.push(oObj);
			});
			this.getOwnerComponent().getModel("possibleValueModel").setData({
				posValueData: oCorrectedValuesArr
			});
			// if (!this.posValueDialog) {
			this.posValueDialog = sap.ui.xmlfragment("c2r.dcd.dcdai.fragment.possibleValue", this);
			this.getView().addDependent(this.posValueDialog);

			// }
			this.posValueDialog.setModel(this.getModel("possibleValueModel"));
			this.posValueDialog.open();
		},

		//close the possible value dialog
		onPosValueCancel: function () {
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/possibleValueTextbox", "");
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/possibleValueAddButtonEnable", false);
			this.posValueDialog.close();
			this.posValueDialog.destroy();
		},

		//drag and drop functionality for possible value dialog
		onReorderItems: function (oEvent) {
			var oDraggedItem = oEvent.getParameter("draggedControl"),
				oDroppedItem = oEvent.getParameter("droppedControl"),
				sDropPosition = oEvent.getParameter("dropPosition"),
				oList = oEvent.getSource().getParent(),
				// get the index of dragged item
				iDraggedIndex = oList.indexOfItem(oDraggedItem),
				// get the index of dropped item
				iDroppedIndex = oList.indexOfItem(oDroppedItem),
				// get the new dropped item index
				iNewDroppedIndex = iDroppedIndex + (sDropPosition === "Before" ? 0 : 1) + (iDraggedIndex < iDroppedIndex ? -1 : 0);

			// remove the dragged item
			oList.removeItem(oDraggedItem);
			// insert the dragged item on the new drop index
			oList.insertItem(oDraggedItem, iNewDroppedIndex);
			var posValue = [],
				listItems = oList.getItems();
			for (var i = 0; i < listItems.length; i++) {
				posValue.push({
					"item": listItems[i].getTitle()
				});
			}
			this.getOwnerComponent().getModel("possibleValueModel").setData({
				posValueData: posValue
			});
		},
		//On adding new posssible value list item
		onPosValueAdd: function (oEvent) {
			var enteredPossibleValue = this.getOwnerComponent().getModel("appConfigModel").getProperty("/possibleValueTextbox"),
				possibleValues = [];
			possibleValues = this.getModel("possibleValueModel").getData();
			var oObj = {};
			oObj["item"] = enteredPossibleValue;

			possibleValues.posValueData.push(oObj);
			this.getOwnerComponent().getModel("possibleValueModel").setData({
				posValueData: possibleValues.posValueData
			});
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/possibleValueTextbox", "");
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/possibleValueAddButtonEnable", false);
		},
		//on possibleValueSave
		onPosValueSave: function (oEvent) {
			var possibleValue = this.getOwnerComponent().getModel("possibleValueModel").getData();
			var sPossibleValues = "",
				aPossibleValues = [];
			possibleValue.posValueData.forEach(function (oVal) {
				aPossibleValues.push(oVal.item.trim());
			});
			sPossibleValues = aPossibleValues.join();
			var oModel = this.getOwnerComponent().getModel();
			oModel.setProperty(posPath + "/PossibleValues", sPossibleValues);
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/possibleValueTextbox", "");
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/possibleValueAddButtonEnable", false);
			this.posValueDialog.close();
			this.posValueDialog.destroy();
		},
		//on change on slider
		onChangeConfidenceLevel: function (oEvent) {
			var newValue = oEvent.getSource().getValue().toString();
			var sPath = oEvent.getSource().getBindingContext().getPath();
			var oModel = this.getOwnerComponent().getModel();
			oModel.setProperty(sPath + "/CurrentThreshold", newValue);
			oModel.setProperty(sPath + "/NewThreshold", newValue);
		},
		//on Admin save
		onAdminSave: function () {
			var oResourceBundle = this.getResourceBundle();
			var that = this;
			if (Object.keys(this.getOwnerComponent().getModel().getPendingChanges()).length) {
				MessageBox.confirm(
					oResourceBundle.getText("saveChanges"), {
						onClose: function (sAction) {
							if (sAction === "OK") {
								that.getOwnerComponent().getModel().submitChanges({
									success: function (oArg) {
										var flag = true;
										oArg.__batchResponses.forEach(function (oVal) {
											if (oVal.statusCode) {} else if (oVal.__changeResponses[0].statusCode === "204") {} else {
												flag = false;
											}
										});
										if (flag) {
											MessageToast.show(oResourceBundle.getText("saveChangesSuccessMsg"));
										}
										that.oAdminDialog.close();
									},
									error: function (oError) {
										// MessageBox.error(JSON.parse(oError.responseText).error.message.value);
									}
								});
							}
						}
					}
				);
			} else {
				MessageToast.show(oResourceBundle.getText("noChangeMsg"));
				this.oAdminDialog.close();
			}
		},
		onPosValueChange: function (oEvent) {
			if (oEvent.getSource().getValue() !== "") {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/possibleValueAddButtonEnable", true);
			} else {
				this.getOwnerComponent().getModel("appConfigModel").setProperty("/possibleValueAddButtonEnable", false);
			}
		},

		onBeforeRebindTable: function (oEvent) {
			if (this.getOwnerComponent().getModel("appConfigModel").getProperty("/revenueType") !== 0) {
				var oBinding = oEvent.getParameter("bindingParams");
				var sRevenueType = (this.getOwnerComponent().getModel("appConfigModel").getProperty("/revenueType") === 1) ? "CL" : "OP";
				var oFilter = new sap.ui.model.Filter("RevenueType", sap.ui.model.FilterOperator.EQ, sRevenueType);
				oBinding.filters.push(oFilter);
			}
		},
		onChangeRevenueType: function (oEvent) {
			var iSelectedIndex = oEvent.getSource().getSelectedIndex();
			this.getOwnerComponent().getModel("appConfigModel").setProperty("/revenueType", iSelectedIndex);
			oEvent.getSource().getParent().getParent().rebindTable();
		}
	});
});