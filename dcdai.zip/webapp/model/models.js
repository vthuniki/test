sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		createAppConfigData: function () {
			var oAppConfigModel = {
				"revenueType": 0,
				"visibleCanvas": false,
				"editHighlightingButtons": true,
				"results": [],
				"oldValues": {},
				"oldHighlightData": {},
				"currentPageNo": 0,
				"msgStripVisible": false,
				"pageNo": 0,
				"currPageNo": 0,
				"totalPages": 0,
				"fileName": "",
				"documentId": "",
				"newFileName":"",
				"newDocumentId":"",
				"pageBack": false,
				"pageNext": false,
				"AdminAccess": false,
				"possibleValueTextbox": "",
				"possibleValueAddButtonEnable": false,
				"protocol": "https://",
				"url": ".wdf.sap.corp/",
				"crmUrlCase": "sap/bc/webdynpro/sap/zv_cms_rcm_wda_case?CASE_ID=",
				"crmUrlCaseMode": "&CASE_MODE=D&sap-wd-configid=ZV_CMS_RCM_WAC_CASE&sap-accessibility=&sap-theme=#",
				"PDFFile": ""
			};
			return oAppConfigModel;
		},
		createUserModel: function () {
			var oModel = new JSONModel("/services/userapi/currentUser");
			return oModel;
		}

	};
});