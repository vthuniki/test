sap.ui.define([
	"sap/ui/test/Opa5",
	"./arrangements/Arrangement",
	"./ContractMasterJourney",
	"./NavigationJourney",
	"./ClauseDetailJourney"
], function (Opa5, Arrangement) {
	"use strict";

	Opa5.extendConfig({
		arrangements: new Arrangement(),
		viewNamespace: "c2r.dcd.dcdai.view.",
		autoWait: true
	});
});