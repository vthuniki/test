/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"c2r/dcd/dcdai/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});