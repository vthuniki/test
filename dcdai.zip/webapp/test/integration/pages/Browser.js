sap.ui.define([
	"sap/ui/test/Opa5",
	"./Common"
], function (Opa5, Common) {
	"use strict";

	Opa5.createPageObjects({
		onTheBrowser: {
			baseClass: Common,
			actions: {
				iPressOnTheBackwardsButton: function () {
					return this.waitFor({
						success: function () {
							// manipulate history directly for testing purposes
							Opa5.getWindow().history.back();
						}
					});
				},

				iChangeTheHashToTheRememberedItem: function () {
					return this.waitFor({
						success: function () {
							var sObjectId1 = this.getContext().currentItem.id1;
							var sObjectId2 = this.getContext().currentItem.id2;
							Opa5.getHashChanger().setHash("/ClauseDetail/" + sObjectId1 + "," + sObjectId2+","+"false");
						}
					});
				}
			},
			assertions: {}
		}
	});
});