sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/PropertyStrictEquals"
], function(Opa5, Press, PropertyStrictEquals) {
	"use strict";

	return {

		createActions : function (sViewName) {
			return {

			};
		},

		createAssertions : function (sViewName) {
			return {


			};

		}

	};

});