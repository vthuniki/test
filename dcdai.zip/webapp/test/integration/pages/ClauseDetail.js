sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./Common",
	"./shareOptions"
], function (Opa5, Press, EnterText, AggregationLengthEquals, AggregationFilled, PropertyStrictEquals, Common, shareOptions) {
	"use strict";

	var sViewName = "ClauseDetail",
		sTableId = "clauseTable";

	function createWaitForBPItemAtPosition(oOptions) {
		var iPosition = oOptions.position;
		return {
			id: sTableId,
			viewName: sViewName,
			matchers: function (oTable) {
				return oTable.getItems()[2].getCells()[0];
				//return oTable.getItems()[iPosition];
			},
			actions: oOptions.actions,
			success: oOptions.success,
			// success: function (oEvent) {
			// 	// debugger;
			// 	// oEvent.setSelectedItem(oEvent.getItems()[2], true);
			// 	// // this.sPath = table.getSelectedContextPaths()[0];
			// 	// oEvent.fireSelectionChange({
			// 	// 	listItem: oEvent.getItems()[2],
			// 	// 	selected: true
			// 	// });
			// },
			errorMessage: "Table in view '" + sViewName + "' does not contain an Item at position '" + iPosition + "'"
		};
	}

	Opa5.createPageObjects({
		onTheClauseDetail: {
			baseClass: Common,

			actions: jQuery.extend({
				iPressBPItemAtPosition: function (iPosition) {
					return this.waitFor(createWaitForBPItemAtPosition({
						position: iPosition,
						actions: new Press()

					}));
				},

				iPressThePossibleValueDropdown: function () {
					return this.waitFor({
						id: sTableId,
						viewName: sViewName,
						matchers: function (oTable) {
							return oTable.getItems()[0].getCells()[1].getItems()[1];
							//return oTable.getItems()[iPosition];
						},
						actions: new Press(),
						errorMessage: "Control not found"
					});
				},
				iPressThePossibleValueTextarea: function () {
					return this.waitFor({
						id: sTableId,
						viewName: sViewName,
						matchers: function (oTable) {
							return oTable.getItems()[2].getCells()[1].getItems()[1];
							//return oTable.getItems()[iPosition];
						},
						actions: new Press(),
						errorMessage: "Control not found"
					});
				},
				iChooseCorrectedeValue: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Popover",
						autoWait: false,
						success: function (posDialog) {
							var addButton = posDialog[0].getContent()[2].getItems()[0].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iAddcorrectedeValue: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Popover",
						autoWait: false,
						success: function (posDialog) {
							var textAdded = "Text";
							posDialog[0].getContent()[2].setValue(textAdded);
							var addButton = posDialog[0].getFooter().getContent()[1].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iPressDcoumentChange: function () {
					return this.waitFor({
						id: "detailPageContainer",
						viewName: sViewName,
						matchers: function (oEvent) {
							return oEvent.getItems()[0].getItems()[2];
						},
						actions: new Press(),
						errorMessage: "Control not found"
					});
				},
				iPressDocumentName: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Popover",
						autoWait: false,
						success: function (posDialog) {
							var addButton = posDialog[0].getContent()[0].getItems()[1].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iPressExecutedDocuments: function () {
					return this.waitFor({
						id: "detailPageContainer",
						viewName: sViewName,
						matchers: function (oEvent) {
							return oEvent.getItems()[1].getItems()[1];
						},
						actions: new Press(),
						errorMessage: "Control not found"
					});
				},
				iPressFinalDocuments: function () {
					return this.waitFor({
						id: "detailPageContainer",
						viewName: sViewName,
						matchers: function (oEvent) {
							return oEvent.getItems()[2].getItems()[1];
						},
						actions: new Press(),
						errorMessage: "Control not found"
					});
				},
				iChooseFinalDocument: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Popover",
						autoWait: false,
						success: function (posDialog) {
							var addButton = posDialog[0].getContent()[0].getItems()[0].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iPressResetButton: function () {
					return this.waitFor({
						id: "resetButton",
						viewName: sViewName,
						actions: new Press(),
						errorMessage: "Control not found"
					});
				},
				iPressSaveButton: function () {
					return this.waitFor({
						id: "submitButton",
						viewName: sViewName,
						actions: new Press(),
						errorMessage: "Control not found"
					});
				},
				iPressOutOfScopeButton: function () {
					return this.waitFor({
						id: "outOfScopeButton",
						viewName: sViewName,
						actions: new Press(),
						errorMessage: "Control now found"
					});
				},
				iAddTheComment: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (posDialog) {
							var textAdded = "Case is marked as out of scope";
							posDialog[0].getContent()[0].setValue(textAdded);
							posDialog[0].getBeginButton().setEnabled(true);
							var addButton = posDialog[0].getBeginButton().getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iPressNextPageButton: function () {
					return this.waitFor({
						id: "canvasContainer",
						viewName: sViewName,
						success: function (oEvent) {
							var addButton = oEvent.getItems()[0].getItems()[1].getItems()[3].getId();

							return this.waitFor({
								id: addButton,
								timeout: 400,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iPressPreviousPageButton: function () {
					return this.waitFor({
						id: "canvasContainer",
						viewName: sViewName,
						success: function (oEvent) {
							var addButton = oEvent.getItems()[0].getItems()[1].getItems()[0].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iPressExpandpdf: function () {
					return this.waitFor({
						id: "canvasContainer",
						viewName: sViewName,
						success: function (oEvent) {
							var addButton = oEvent.getItems()[0].getItems()[0].getItems()[0].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iPressclosepdf: function () {
					return this.waitFor({
						id: "canvasContainer",
						viewName: sViewName,
						success: function (oEvent) {
							var addButton = oEvent.getItems()[0].getItems()[0].getItems()[0].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iPressZoomOut: function () {
					return this.waitFor({
						id: "canvasContainer",
						viewName: sViewName,
						success: function (oEvent) {
							var addButton = oEvent.getItems()[0].getItems()[0].getItems()[2].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iPressZoomIn: function () {
					return this.waitFor({
						id: "canvasContainer",
						viewName: sViewName,
						success: function (oEvent) {
							var addButton = oEvent.getItems()[0].getItems()[0].getItems()[1].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iTypePageNumber: function () {
					return this.waitFor({
						id: "canvasContainer",
						viewName: sViewName,
						success: function (oEvent) {
							oEvent.getItems()[0].getItems()[1].getItems()[1].setValue(3);
							oEvent.getItems()[0].getItems()[1].getItems()[1].fireSubmit();
						},
						errorMessage: "Control not found"
					});
				},
				iPressRemoveHighlighting: function () {
					return this.waitFor({
						id: "canvasContainer",
						viewName: sViewName,
						success: function (oEvent) {
							var addButton = oEvent.getItems()[0].getItems()[2].getItems()[1].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iPressRevertHighlighting: function () {
					return this.waitFor({
						id: "canvasContainer",
						viewName: sViewName,
						success: function (oEvent) {
							var addButton = oEvent.getItems()[0].getItems()[2].getItems()[0].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				},
				iPressExpandThumbnail: function () {
					return this.waitFor({
						id: "canvasContainer",
						viewName: sViewName,
						success: function (oEvent) {
							var addButton = oEvent.getItems()[0].getItems()[2].getItems()[2].getId();
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						},
						errorMessage: "Control not found"
					});
				}
			}, shareOptions.createActions(sViewName)),

			assertions: jQuery.extend({
					theViewIsNotBusyAnymore: function () {
						return this.waitFor({
							id: "synamice",
							viewName: sViewName,
							matchers: function (oPage) {
								return !oPage.getBusy();
							},
							autoWait: false,
							success: function (oPage) {
								Opa5.assert.ok(!oPage.getBusy(), "The object view is not busy");
							},
							errorMessage: "The object view is busy"
						});
					},
					thePdfIsRendered: function () {
						return this.waitFor({
							id: "canvasContainer",
							viewName: sViewName,
							success: function (oEvent) {
								if (oEvent.getItems()[1]._getPropertiesToPropagate().oModels.pdfmodel.getData().processedDoc.numPages === 4) {
									Opa5.assert.ok("The PDF page is rendered");
								}
							},
							errorMessage: "The PDF page is not rendered"
						});
					},
					theTableShouldHaveAllEntries: function () {

						var aAllEntities,
							iExpectedNumberOfItems;

						// retrieve all CustomerDataEntitySet to be able to check for the total amount
						this.waitFor(this.createAWaitForAnEntitySet({
							entitySet: "ZDCD_I_ACTNINDEX",
							success: function (aEntityData) {
								aAllEntities = aEntityData;
							}
						}));

						return this.waitFor({
							id: sTableId,
							viewName: sViewName,
							matchers: function (oTable) {
								// If there are less items in the list than the growingThreshold, only check for this number.
								iExpectedNumberOfItems = Math.min(oTable.getGrowingThreshold(), aAllEntities.length);
								return new AggregationLengthEquals({
									name: "items",
									length: iExpectedNumberOfItems
								}).isMatching(oTable);
							},
							success: function (oTable) {
								Opa5.assert.strictEqual(oTable.getItems().length, iExpectedNumberOfItems, "The growing Table has " +
									iExpectedNumberOfItems +
									" items");
							},
							errorMessage: "Table does not have all entries."
						});
					},
					iShouldSeeThePossibleValueDropdown: function () {
						return this.waitFor({
							searchOpenDialogs: true,
							controlType: "sap.m.Popover",
							autoWait: false,
							success: function (oDialog) {
								var overview_content = oDialog[0].getId();
								return this.waitFor({
									id: overview_content,
									success: function (oItem) {
										Opa5.assert.ok(oItem, "Found the Corrected value help Popover");
									},
									errorMessage: "Cannot find Corrected value help Popover"
								});
							}
						});
					},
					iShouldSeeThePossibleValueTextarea: function () {
						return this.waitFor({
							searchOpenDialogs: true,
							controlType: "sap.m.Popover",
							autoWait: false,
							success: function (oDialog) {
								var overview_content = oDialog[0].getId();
								return this.waitFor({
									id: overview_content,
									success: function (oItem) {
										Opa5.assert.ok(oItem, "Found the Corrected value help Popover");
									},
									errorMessage: "Cannot find Corrected value help Popover"
								});
							}
						});
					},
					iSeeTheCorrectedValue: function () {
						return this.waitFor({
							id: sTableId,
							viewName: sViewName,
							success: function (oTable) {
								var slistItem = oTable.getItems()[2].getCells()[1].getItems()[0].getText();
								if (slistItem === "Text") {
									Opa5.assert.ok("The Corected value is added in the column");
								}
							},
							errorMessage: "The Corected value is not added in the column"
						});
					},
					iSeeTheCorrectedValueForDropdown: function () {
						return this.waitFor({
							id: sTableId,
							viewName: sViewName,
							success: function (oTable) {
								var slistItem = oTable.getItems()[0].getCells()[1].getItems()[0].getText();
								if (slistItem === "Yes") {
									Opa5.assert.ok("The Corected value is changed in the column");
								}
							},
							errorMessage: "The Corected value is not changed in the column"
						});
					},
					iSeeExecutedDocuments: function () {
						return this.waitFor({
							searchOpenDialogs: true,
							controlType: "sap.m.Popover",
							autoWait: false,
							success: function (oDialog) {
								var overview_content = oDialog[0].getId();
								return this.waitFor({
									id: overview_content,
									success: function (oItem) {
										Opa5.assert.ok(oItem, "Found the executed documents Popover");
									},
									errorMessage: "Cannot find the executed documents Popover"
								});
							}
						});
					},
					iSeeListOfDocuments: function () {
						return this.waitFor({
							searchOpenDialogs: true,
							controlType: "sap.m.Popover",
							autoWait: false,
							success: function (oDialog) {
								var overview_content = oDialog[0].getId();
								return this.waitFor({
									id: overview_content,
									success: function (oItem) {
										Opa5.assert.ok(oItem, "Found the documents list Popover");
									},
									errorMessage: "Cannot find the documents list Popover"
								});
							}
						});
					},
					iSeeChangedDocument: function () {
						return this.waitFor({
							id: "canvasContainer",
							viewName: sViewName,
							success: function (oEvent) {
								if (oEvent.getItems()[1]._getPropertiesToPropagate().oModels.pdfmodel.getData().processedDoc.numPages === 4) {
									Opa5.assert.ok("The PDF page is rendered");
								}
							},
							errorMessage: "The PDF page is not rendered"
						});
					},
					iSeeFinalDocuments: function () {
						return this.waitFor({
							searchOpenDialogs: true,
							controlType: "sap.m.Popover",
							autoWait: false,
							success: function (oDialog) {
								var overview_content = oDialog[0].getId();
								return this.waitFor({
									id: overview_content,
									success: function (oItem) {
										Opa5.assert.ok(oItem, "Found the Final documents Popover");
									},
									errorMessage: "Cannot find the final documents Popover"
								});
							}
						});
					},
					iSeeFinalDocumentDialog: function () {
						return this.waitFor({
							searchOpenDialogs: true,
							controlType: "sap.m.PDFViewer",
							autoWait: false,
							success: function (oDialog) {
								var overview_content = oDialog[0].getId();
								return this.waitFor({
									id: overview_content,
									success: function (oItem) {
										Opa5.assert.ok(oItem, "Found the document pdf Viewer");
										oDialog[0].exit();
									},
									errorMessage: "Cannot find the document pdf Viewer"
								});
							}
						});
					},
					iSeeTheResetChanges: function () {
						return this.waitFor({
							id: sTableId,
							viewName: sViewName,
							success: function (oEvent) {
								if (!Object.keys(oEvent.getModel().getPendingChanges()).length) {
									Opa5.assert.ok("All changes have been reset");
								}
							},
							errorMessage: "Cannot reset changes"
						});
					},
					iSeeTheSavedChanges: function () {
						return this.waitFor({
							id: sTableId,
							viewName: sViewName,
							success: function (oEvent) {
								if (!Object.keys(oEvent.getModel().getPendingChanges()).length) {
									Opa5.assert.ok("All changes have been saved");
								}
							},
							errorMessage: "Cannot save changes"
						});
					},
					iSeeTheNextPage: function () {
						return this.waitFor({
							id: "canvasContainer",
							viewName: sViewName,
							success: function (oEvent) {
								if (oEvent.getItems()[0].getItems()[1].getItems()[1].getValue() == 2) {
									Opa5.assert.ok("The next page is rendered");
								}
							},
							errorMessage: "The next page is not rendered"
						});
					},
					iSeeThePreviousPage: function () {
						return this.waitFor({
							id: "canvasContainer",
							viewName: sViewName,
							success: function (oEvent) {
								if (oEvent.getItems()[0].getItems()[1].getItems()[1].getValue() == 1) {
									Opa5.assert.ok("The previous page is rendered");
								}
							},
							errorMessage: "The previous page is not rendered"
						});
					},
					iSeeTheExpandedpdf: function () {
						return this.waitFor({
							id: "canvasContainer",
							viewName: sViewName,
							success: function (oEvent) {
								if (oEvent.getItems()[1]._getPropertiesToPropagate().oModels.pdfmodel.getData().processedDoc.numPages === 4) {

									Opa5.assert.ok("The pdf is expanded");
								}
							},
							errorMessage: "The pdf is not expanded"
						});
					},
					iSeeTheClosedpdf: function () {
						return this.waitFor({
							id: "canvasContainer",
							viewName: sViewName,
							success: function (oEvent) {
								if (oEvent.getItems()[1]._getPropertiesToPropagate().oModels.pdfmodel.getData().processedDoc.numPages === 4) {

									Opa5.assert.ok("The pdf is expanded");
								}
							},
							errorMessage: "The pdf is not expanded"
						});
					},
					iSeeTheZoomOut: function () {
						return this.waitFor({
							id: "canvasContainer",
							viewName: sViewName,
							success: function (oEvent) {
								if (oEvent.getItems()[1]._getPropertiesToPropagate().oModels.appConfigModel.getData().pageNo === 2) {

									Opa5.assert.ok("The pdf is zoomed out");
								}
							},
							errorMessage: "Cannot Zoom Out"

						});
					},
					iSeeTheZoomIn: function () {

						var oOrderNowButton = null;
						this.waitFor({
							searchOpenDialogs: true,
							controlType: "sap.m.Button",
							check: function (aButtons) {
								return aButtons.filter(function (oButton) {
									if (oButton.getText() !== 'ok') {
										return false;
									}
									oOrderNowButton = oButton;
									return true;
								});
							},
							actions: new sap.ui.test.actions.Press(),
							errorMessage: "Did not find the ok button"
						});
						return this.waitFor({
							id: "canvasContainer",
							viewName: sViewName,
							success: function (oEvent) {
								if (oEvent.getItems()[1]._getPropertiesToPropagate().oModels.appConfigModel.getData().pageNo === 2) {

									Opa5.assert.ok("The pdf is expanded");
								}
							},
							errorMessage: "Cannot Zoom In"

							// },

						});
					},
					iSeeThePage: function () {
						return this.waitFor({
							id: "canvasContainer",
							viewName: sViewName,
							success: function (oEvent) {
								if (oEvent.getItems()[0].getItems()[1].getItems()[1].getValue() === '3') {
									Opa5.assert.ok("The previous page is rendered");
								}
							},
							errorMessage: "The previous page is not rendered"
						});
					},
					iSeeNoHighlighting: function () {
						return this.waitFor({

							autoWait: false,
							check: function () {

								return Opa5.getJQuery()(".sapMMessageToast").length > 0;
							},
							success: function () {
								Opa5.assert.ok(true, "The highlighting is removed");
							},
							errorMessage: "The highlighting is not removed"
						});
					},
					iSeeTheRevertedChanges: function () {
						return this.waitFor({

							autoWait: false,
							check: function () {
								// Locate the message toast using its class name in a jQuery function
								return Opa5.getJQuery()(".sapMMessageToast").length > 0;
							},
							success: function () {
								Opa5.assert.ok(true, "The highlighting is reverted");
							},
							errorMessage: "The highlighting is not reverted"
						});
					},
					iSeeCommentDialog: function () {
						return this.waitFor({
							searchOpenDialogs: true,
							controlType: "sap.m.Dialog",
							autoWait: false,
							success: function (oDialog) {
								Opa5.assert.ok("Found the Comment dialog for out of scope cases");
							},
							errorMessage: "Cannot find the the Comment dialog for out of scope cases"
						});
					},
					iSeeCaseOutOfScope: function(){
						return this.waitFor({

							autoWait: false,
							check: function () {
								// Locate the message toast using its class name in a jQuery function
								return Opa5.getJQuery()(".sapMMessageToast").length > 0;
							},
							success: function () {
								Opa5.assert.ok(true, "The highlighting is reverted");
							},
							errorMessage: "The Case is not marked as out of scope"
						});
					},
					iSeeTheExpandedThumbnail: function () {
						return this.waitFor({
							id: sTableId,
							viewName: sViewName,
							success: function (oEvent) {
								if (Object.keys(oEvent.getModel().getPendingChanges()).length) {
									Opa5.assert.ok("The PDF thumbnail expanded");
								}
							},
							errorMessage: "The PDF thumbnail not expanded"
						});
					}
				},
				shareOptions.createAssertions(sViewName))
		}

	});

});