sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"./Common",
	"./shareOptions"
], function (Opa5, Press, EnterText, AggregationLengthEquals, AggregationFilled, PropertyStrictEquals, Common, shareOptions) {
	"use strict";
	var sViewName = "ContractMaster",
		sTableId = "table",
		sAdminMenu = "adminButton",
		sSmartTableId = "LineItemsSmartTable";

	function createWaitForItemAtPosition(oOptions) {
		var iPosition = oOptions.position;
		return {
			id: sTableId,
			viewName: sViewName,
			matchers: function (oTable) {
				return oTable.getItems()[iPosition];
			},
			actions: oOptions.actions,
			success: oOptions.success,
			errorMessage: "Table in view '" + sViewName + "' does not contain an Item at position '" + iPosition + "'"
		};
	}
	Opa5.createPageObjects({
		onTheContractMasterPage: {
			baseClass: Common,
			actions: jQuery.extend({
				iRememberTheItemAtPosition: function (iPosition) {
					return this.waitFor(createWaitForItemAtPosition({
						position: iPosition,
						success: function (oTableItem) {
							var oBindingContext = oTableItem.getBindingContext();

							// Don't remember objects just strings since IE will not allow accessing objects of destroyed frames
							this.getContext().currentItem = {
								bindingPath: oBindingContext.getPath(),
								id1: oBindingContext.getProperty("CaseId"),
								name1: oBindingContext.getProperty("CaseId"),
								id2: oBindingContext.getProperty("CaseGuid"),
								name2: oBindingContext.getProperty("CaseGuid")
							};
						}
					}));
				},
				iSeetheItemContainTheAccountId: function (iPosition) {
					return this.waitFor({
						id: sSmartTableId,
						viewName: sViewName,
						matchers: function (oTable) {
							var sLink =
								"isd.wdf.sap.corp/sap/bc/webdynpro/sap/zv_cms_rcm_wda_case?CASE_ID=CaseId%201&CASE_MODE=D&sap-wd-configid=ZV_CMS_RCM_WAC_CASE&sap-accessibility=&sap-theme=#",
								sAccount = encodeURIComponent(oTable.getItems()[1].getItems()[0].getBindingContext().getObject().CaseId),
								sGeneratedLink =
								"isd.wdf.sap.corp/sap/bc/webdynpro/sap/zv_cms_rcm_wda_case?CASE_ID=" +
								sAccount + "&CASE_MODE=D&sap-wd-configid=ZV_CMS_RCM_WAC_CASE&sap-accessibility=&sap-theme=#";

							return sLink === sGeneratedLink;
						},
						actions: new Press(),
						errorMessage: "Table in view '" + sViewName + "' does not contain an Item at position '" + iPosition + "'"
					});
				},
				iPressTheAdminTab: function () {
					return this.waitFor({
						viewName: sViewName,
						success: function (oEvent) {
							oEvent[0].getModel("appConfigModel").setProperty("/AdminAccess", true);
							return this.waitFor({
								id: sAdminMenu,
								viewName: sViewName,
								actions: new Press()
							});
						},
						errorMessage: "Failed to find search field in ContractMaster view.'"
					});
				},
				iAddPossibleValue: function () {
					var oDialog;
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (posDialog) {
							var textAdded = "Test";
							oDialog = posDialog[1].getContent()[1];
							oDialog.getItems()[0].setValue(textAdded);
							var addButton = oDialog.getItems()[1].getId();
							oDialog.getItems()[1].setEnabled(true);
							return this.waitFor({
								id: addButton,
								actions: new Press()
							});
						}
					});
				},
				iClickOnTheOkButton: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (posDialog) {
							return this.waitFor({
								id: "savePossibleValue",
								actions: new Press()
							});
						}
					});
				},
				iChangeTheNewThrushold: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (oTable) {
							oTable[0].getContent()[0].getItems()[0].getItems()[0].getItems()[1].getItems()[0].getCells()[2].setValue(0.20);
							oTable[0].getContent()[0].getItems()[0].getItems()[0].getItems()[1].getItems()[0].getCells()[2].fireChange();
						}
					});
				}
			}, shareOptions.createActions(sViewName)),

			assertions: {
				theTableShouldHaveAllEntries: function () {

					var aAllEntities,
						iExpectedNumberOfItems;

					// retrieve all CustomerDataEntitySet to be able to check for the total amount
					this.waitFor(this.createAWaitForAnEntitySet({
						entitySet: "ZDCD_C_ACTIONINDEX",
						success: function (aEntityData) {
							aAllEntities = aEntityData;
						}
					}));

					return this.waitFor({
						id: sTableId,
						viewName: sViewName,
						matchers: function (oTable) {
							// If there are less items in the list than the growingThreshold, only check for this number.
							iExpectedNumberOfItems = Math.min(oTable.getGrowingThreshold(), aAllEntities.length);
							return new AggregationLengthEquals({
								name: "items",
								length: iExpectedNumberOfItems
							}).isMatching(oTable);
						},
						success: function (oTable) {
							Opa5.assert.strictEqual(oTable.getItems().length, iExpectedNumberOfItems, "The growing Table has " + iExpectedNumberOfItems +
								" items");
						},
						errorMessage: "Table does not have all entries."
					});
				},
				iShouldSeeTheTable: function () {
					return this.waitFor({
						id: sTableId,
						viewName: sViewName,
						success: function (oTable) {
							Opa5.assert.ok(oTable, "Found the object Table");
						},
						errorMessage: "Can't see the master Table."
					});
				},
				iShouldSeeTheAdminMenu: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (oDialog) {
							var overview_content = oDialog[0].getId();
							return this.waitFor({
								id: overview_content,
								success: function (oItem) {
									Opa5.assert.ok(oItem, "Found the admin dialog");
								}
							});
						}
					});
				},
				iPressTheEditIcon: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (oDialog) {
							// var editButton = oDialog[0].getContent()[0].getItems()[0].getItems()[0].getItems()[1].getItems()[0].getCells()[3].getItems()[0].getId();
							var editButton = oDialog[0].getContent()[0].getItems()[0].getItems()[0].getItems()[1].getItems()[0].getCells()[3].getItems()[0].getId();
							return this.waitFor({
								id: editButton,
								actions: new Press(),
								success: function (oEdit) {
									return this.waitFor({
										searchOpenDialogs: true,
										controlType: "sap.m.Dialog",
										autoWait: false,
										success: function (editDialog) {
											Opa5.assert.ok("Found the possible Value dialog");
										}
									});
								}
							});
						}
					});
				},
				iSeeTheValueOnList: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (oDialog) {
							var listItem = oDialog[1].getContent()[2].getItems(),
								listFlag = false;
							for (var i = 0; i < listItem.length; i++) {
								if (listItem[i].getTitle() === "Test") {
									listFlag = true;
								}
							}
							if (listFlag) {
								Opa5.assert.ok("The possible value is added in the list");
							}
						}
					});
				},
				iSeethePossibleValueDialogClosed: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: true,
						success: function (oDialog) {
							Opa5.assert.strictEqual(oDialog.length, 1, "possible value dialog is closed");
						}
					});
				},
				iClickOnTheCloseButtonAndCloseIt: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (posDialog) {
							return this.waitFor({
								id: "closeAdmin",
								actions: new Press(),
								autoWait: true,
								success: function () {
									Opa5.assert.ok("The admin dialog is closed");
								}
							});
						}
					});
				},
				iShouldSeeNewWindow: function () {
					return this.waitFor({
						id: sSmartTableId,
						viewName: sViewName,
						success: function (oTable) {
							Opa5.assert.ok(oTable, "Found the account details");
						},
						errorMessage: "Can't see the account details."
					});
				},
				iSeeTheNewCurrentThrushold: function () {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Dialog",
						autoWait: false,
						success: function (oTable) {
							var fThrusholdValue = oTable[0].getContent()[0].getItems()[0].getItems()[0].getItems()[1].getItems()[0].getCells()[2].getValue();
							if(fThrusholdValue === 0.2)
							{
								Opa5.assert.ok("The thrushold value is changed");
							}
						}
					});
				}
			}
		}
	});

});