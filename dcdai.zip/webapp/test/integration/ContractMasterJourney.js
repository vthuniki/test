/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit",
	"./pages/ContractMaster",
	"./pages/App"
], function (opaTest) {
	"use strict";

	QUnit.module("ContractMaster");

	opaTest("Should see the table with all entries", function (Given, When, Then) {
		// Arrangements
		Given.iStartMyApp();

		// Assertions
		Then.onTheContractMasterPage.theTableShouldHaveAllEntries();

		// Cleanup
		// Then.iTeardownMyAppFrame();
	});
	opaTest("The link contains the correct Case Id", function (Given, When, Then) {
		// // Arrangements
		// Given.iStartMyApp();
		//Actions
		// When.onTheWorklistPage.iPressTheDialogCloseButton();
		When.onTheContractMasterPage.iSeetheItemContainTheAccountId(1);
		// Assertions
		Then.onTheContractMasterPage.iShouldSeeNewWindow();
		// Cleanup
		// Then.iTeardownMyAppFrame();
	});
	opaTest("Should open the admin menu", function (Given, When, Then) {
		// Arrangements
		// Given.iStartMyApp();
		//Actions
		When.onTheContractMasterPage.iPressTheAdminTab();
		// Assertions
		Then.onTheContractMasterPage.iShouldSeeTheAdminMenu();
		// Cleanup
		// Then.iTeardownMyAppFrame();
	});
	opaTest("Should open the possible Value dialog", function (Given, When, Then) {
		// Arrangements
		// Given.iStartMyApp();
		//Actions
		Then.onTheContractMasterPage.iPressTheEditIcon();
		// Assertions
		// Cleanup
		// Then.iTeardownMyAppFrame();
	});
	opaTest("Should add the possible value in list", function (Given, When, Then) {
		// Arrangements
		// Given.iStartMyApp();
		//Actions
		When.onTheContractMasterPage.iAddPossibleValue();
		// Assertions
		Then.onTheContractMasterPage.iSeeTheValueOnList();
		// Cleanup
		// Then.iTeardownMyAppFrame();
	});
	opaTest("Should save the possible values on click of ok button", function (Given, When, Then) {
		// Arrangements
		// Given.iStartMyApp();
		//Actions
		When.onTheContractMasterPage.iClickOnTheOkButton();
		// Assertions
		Then.onTheContractMasterPage.iSeethePossibleValueDialogClosed();
		// Cleanup
		// Then.iTeardownMyAppFrame();
	});
	opaTest("Should change the thrushold value of data field", function (Given, When, Then) {
		// Arrangements
		// Given.iStartMyApp();
		//Actions
		When.onTheContractMasterPage.iChangeTheNewThrushold();
		// Assertions
		Then.onTheContractMasterPage.iSeeTheNewCurrentThrushold();
	});
	opaTest("Should close the admin  popover on close", function (Given, When, Then) {
		// Arrangements
		// Given.iStartMyApp();
		// Assertions
		Then.onTheContractMasterPage.iClickOnTheCloseButtonAndCloseIt();

		// Cleanup
		Then.iTeardownMyAppFrame();
	});

});