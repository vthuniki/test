/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit",
	"./pages/ClauseDetail",
	"./pages/App"
], function (opaTest) {
	"use strict";

	QUnit.module("ClauseDetail");

	opaTest("Should see the table with all entries", function (Given, When, Then) {

		// Arrangements
		Given.iStartMyApp();

		// Assertions
		When.onTheContractMasterPage.iRememberTheItemAtPosition(0);
		When.onTheBrowser.iChangeTheHashToTheRememberedItem();
		Then.onTheClauseDetail.theTableShouldHaveAllEntries();
	});
	opaTest("Should open the possible value help popover", function (Given, When, Then) {
		//Actions
		When.onTheClauseDetail.iPressThePossibleValueDropdown();
		// Assertions
		Then.onTheClauseDetail.iShouldSeeThePossibleValueDropdown();
	});
	opaTest("Should choose the corrected value in list", function (Given, When, Then) {
		//Actions
		When.onTheClauseDetail.iChooseCorrectedeValue();
		// Assertions
		Then.onTheClauseDetail.iSeeTheCorrectedValueForDropdown();
	});
	opaTest("Should open the FREE TEXT corrected value help popover", function (Given, When, Then) {
		//Actions
		When.onTheClauseDetail.iPressThePossibleValueTextarea();
		// Assertions
		Then.onTheClauseDetail.iShouldSeeThePossibleValueTextarea();
	});
	opaTest("Should add the corrected value in textArea", function (Given, When, Then) {
		//Actions
		When.onTheClauseDetail.iAddcorrectedeValue();
		// Assertions
		Then.onTheClauseDetail.iSeeTheCorrectedValue();
	});
	opaTest("Should react on row click and open the PDF page on right hand side of the page", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressBPItemAtPosition(2);
		// Assertions
		Then.onTheClauseDetail.thePdfIsRendered();
	});
	opaTest("Should open the document change dropdown", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressDcoumentChange();
		// Assertions
		Then.onTheClauseDetail.iSeeListOfDocuments();
	});
	opaTest("Should change the document on right hand side of page", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressDocumentName();
		// Assertions
		Then.onTheClauseDetail.iSeeChangedDocument();
	});
	opaTest("Should open the executed documents popover", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressExecutedDocuments();
		// Assertions
		Then.onTheClauseDetail.iSeeExecutedDocuments();
	});
	opaTest("Should open the executed document in PDF Viewer", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iChooseFinalDocument();
		// Assertions
		Then.onTheClauseDetail.iSeeFinalDocumentDialog();
	});
	opaTest("Should open the final documents popover", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressFinalDocuments();
		// Assertions
		Then.onTheClauseDetail.iSeeFinalDocuments();
	});
	opaTest("Should open the final document PDF Viewer", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iChooseFinalDocument();
		// Assertions
		Then.onTheClauseDetail.iSeeFinalDocumentDialog();
	});

	opaTest("Should open the next page of the PDF", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressNextPageButton();
		// Assertions
		Then.onTheClauseDetail.iSeeTheNextPage();
	});
	opaTest("Should open the previous page of the PDF", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressPreviousPageButton();
		// Assertions
		Then.onTheClauseDetail.iSeeThePreviousPage();
	});
	opaTest("Should go to the specific page of the PDF on typing page number", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iTypePageNumber();
		// Assertions
		Then.onTheClauseDetail.iSeeThePage();
	});
	opaTest("Should remove the highlighting from the pdf", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressRemoveHighlighting();
		// Assertions
		Then.onTheClauseDetail.iSeeNoHighlighting();
		// Then.iTeardownMyAppFrame();
	});
	opaTest("Should restore the highlighting on the pdf", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressRevertHighlighting();
		// Assertions
		Then.onTheClauseDetail.iSeeTheRevertedChanges();
		// Then.iTeardownMyAppFrame();
	});
	opaTest("Should expand the PDF thumbnail", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressExpandThumbnail();
		// Assertions
		Then.onTheClauseDetail.iSeeTheExpandedThumbnail();
	});
	opaTest("Should open the pdf in full screen", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressExpandpdf();
		// Assertions
		Then.onTheClauseDetail.iSeeTheExpandedpdf();
	});
	opaTest("Should Zoom Out", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressZoomOut();
		// Assertions
		Then.onTheClauseDetail.iSeeTheZoomOut();
	});
	opaTest("Should Zoom In", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressZoomIn();
		// Assertions
		Then.onTheClauseDetail.iSeeTheZoomIn();
	});
	opaTest("Should close the pdf in full screen", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressclosepdf();
		// Assertions
		Then.onTheClauseDetail.iSeeTheClosedpdf();
	});
	opaTest("Should reset all the changes in the oData", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressResetButton();
		// Assertions
		Then.onTheClauseDetail.iSeeTheResetChanges();
	});
	opaTest("Should save all the changes in the oData", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressSaveButton();
		// Assertions
		Then.onTheClauseDetail.iSeeTheSavedChanges();

	});
	opaTest("Should see the comment dialog for Out of Scope Cases", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iPressOutOfScopeButton();
		// Assertions
		Then.onTheClauseDetail.iSeeCommentDialog();

	});
	opaTest("Should add the comment and submit case as out of scope", function (Given, When, Then) {
		// Actions
		When.onTheClauseDetail.iAddTheComment();
		// Assertions
		Then.onTheClauseDetail.iSeeCaseOutOfScope();

	});
	opaTest("Should go to the previous page on back button press", function (Given, When, Then) {
		// Actions
		When.onTheBrowser.iPressOnTheBackwardsButton();
		// Assertions
		Then.onTheContractMasterPage.iShouldSeeTheTable();
		Then.iTeardownMyAppFrame();

	});

});