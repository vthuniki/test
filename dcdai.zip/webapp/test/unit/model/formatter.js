/*global QUnit*/

sap.ui.define([
	"c2r/dcd/dcdai/model/formatter"
], function (formatter) {
	"use strict";
	QUnit.module("Number unit parse");
	function numberUnitParseValueTestCase(assert, sValue, fExpectedNumber) {
		// Act
		var fNumber = formatter.numberUnitParse(sValue);

		// Assert
		assert.strictEqual(fNumber, fExpectedNumber, "The rounding was correct");
	}
	QUnit.test("Should round down a 3 digit number", function (assert) {
		numberUnitParseValueTestCase.call(this, assert, "3.123", 3.123);
	});
	QUnit.test("Should round up a 3 digit number", function (assert) {
		numberUnitParseValueTestCase.call(this, assert, "3.128", 3.128);
	});
	QUnit.test("Should round an empty string", function (assert) {
		numberUnitParseValueTestCase.call(this, assert, "", "");
	});
	QUnit.test("Should round a zero", function (assert) {
		numberUnitParseValueTestCase.call(this, assert, "0", 0.00);
	});
	QUnit.test("Should round a single digit number", function (assert) {
		numberUnitParseValueTestCase.call(this, assert, "1", 1.00);
	});
	QUnit.test("Should round a one decimal digit number", function (assert) {
		numberUnitParseValueTestCase.call(this, assert, "1.7", 1.70);
	});
	
	QUnit.module("Row Highlighting for Lock Status");
	function rowHighlightingTestCase(assert, sStatus, sCurrentUser, sLockedByUser, sExpectedColor) {
		// Act
		var sColor = formatter.rowLockHighlight(sStatus, sCurrentUser, sLockedByUser);

		// Assert
		assert.strictEqual(sColor, sExpectedColor, "The row highlighting for lock status is correct");
	}
	
	QUnit.test("Should show the lock status as free", function (assert) {
		rowHighlightingTestCase.call(this, assert, false, "C5292571", "","Success");
	});
	QUnit.test("Should show the lock status as locked by other user", function (assert) {
		rowHighlightingTestCase.call(this, assert, true, "C5292571", "","Error");
	});
	QUnit.test("Should show the lock status as locked by same user", function (assert) {
		rowHighlightingTestCase.call(this, assert, true, "C5292571", "C5292571","Warning");
	});
});